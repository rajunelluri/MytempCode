package backend.mapping.config;

import com.fundtech.jndi.JmsConfigKeysInterface;
/**
 * @author guys 14/03/2003
 * <br>
 * app-server-config.xml keu emuneration to be used in conjunction with the ASConfigurationFileMapper 
 */
public interface AppServerConfigKeysInterface extends JmsConfigKeysInterface
{
	//elements 
    public static final String RESOURCES_DATASOURCES_DATASOURCE = "app-server-config.resources.datasources.datasource" ;
    public static final String TRACE_MAX_SIZE = "app-server-config.trace.max-size" ;
    public static final String TRACE_ROOT_DIR = "app-server-config.trace.root-dir" ;
    public static final String TRACE_LEVEL = "app-server-config.trace.level" ;
 
    //values
    public static final String DATA_SOURCE_ID_ACTIVE = "active" ;
    public static final String DATA_SOURCE_ID_HISTORY = "history" ;
    public static final String DATA_SOURCE_ID_REPORTING = "reporting" ;
    public static final String DEFAULT_JMS_RESOURCE_ID = "default" ;
    public static final String POC_JMS_RESOURCE_ID = "poc" ;
    public static final String CITI_FP_GUI_ACTIONS_CONNECTION_FACTORY_ID = "citi_fp_gui_actions" ; 
    
}//EOI
