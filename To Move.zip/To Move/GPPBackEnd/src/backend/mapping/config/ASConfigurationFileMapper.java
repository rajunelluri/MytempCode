package backend.mapping.config;

import java.io.File;
import java.io.InputStream;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.mapping.AbstractConfigProxy;
import com.fundtech.mapping.AbstractPropertyFileMapper;
import com.fundtech.mapping.AbstractValidatingPropertyFileMappper;
import com.fundtech.util.ExceptionController;

/**
 * Title:
 * Description:   Configuration file mapper
 * Company:       Fundtech Israel
 * @author        Yaron Mizrahi
 * @date          20 March 2003
 */
public class ASConfigurationFileMapper extends AbstractValidatingPropertyFileMappper
{

	private static final Logger logger = LoggerFactory.getLogger (ASConfigurationFileMapper.class);
    private static final String SCHEMA_FILE_PATH  = "resources/app-server-config-definition.xsd" ;
	
	private static AbstractPropertyFileMapper  theInstance;

	
	protected ASConfigurationFileMapper()
	{
		super();
	}
	
	/**
	 * Returns the singltone instance of this class.
	 */
	public static AbstractPropertyFileMapper getInstance()
	{
		if(theInstance == null)
		{
            theInstance = new ASConfigurationFileMapper();
		}
		
		return theInstance;
	}
        
    protected void logTrace(String sMessage){
    	logger.info(sMessage);
    }//EOM 
	
  
    protected void handleException(Exception e) { 
        ExceptionController.getInstance().handleException(e, this.getClass()) ;
    }//EOM
    
    protected InputStream getSchemaFileStream() { 
        return this.getClass().getResourceAsStream(SCHEMA_FILE_PATH)  ; 
    }//EOM
    
    @Override
    protected final File getConfigFile() { return AbstractConfigProxy.getInstance().getConfigFile() ; }//EOM
    
    public String getDatasourceJndiAlias(String sDatasourceId) { 
        Map map = this.getMultipleResourceValue(AppServerConfigKeysInterface.RESOURCES_DATASOURCES_DATASOURCE) ;
        Map mpDatasourceMap = (Map) map.get(sDatasourceId) ;
        if(mpDatasourceMap == null)//in case no datasource id was found return null;
        {
        	return null;
        }
        return (String) mpDatasourceMap.get(AppServerConfigKeysInterface.JNDI_KEY) ;
    }//EOM
    
    public Map getJmsConfigElement(String sJmsResourceId) { 
        Map map = this.getMultipleResourceValue(AppServerConfigKeysInterface.RESOURCES_JMS_RESOURCES_JMS_RESOURCE) ; 
        Map mpJmsResourceMap = (Map) map.get(sJmsResourceId) ;
        return mpJmsResourceMap ;
    }//EOM
    
}
