/*
 * Created on May 16, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package backend.dataaccess.dto;
import com.fundtech.datacomponent.response.*;

/**
 * Title:			DTOBoolean
 * date:			16-05-2005		 
 * Description:		Class which contains Feedback and boolean value
 * Company:			Fundtech Israel
 * @author			RajuG
 * @version			1.0
 */
 
public class DTOBoolean extends DTOBasic 
{
	/** value to hold the boolean value*/	 
	boolean m_bValue;
	boolean m_bIsEmpty;
	
	/**
	 * constructor
	 * Creates FeedBack class member.
	 */
	public DTOBoolean()
	{
		super();		
		
		m_bIsEmpty = true;		
	}
		
	/**
	 * sets the FeedBack class member.
	 */
	public void setFeedback(Feedback feedback)
	
	{
		this.m_FeedBack = feedback;		
	}
		
	/**
	 * sets the boolean value to dtoboolean member
	 *   
	 */
	
	public void setValue(boolean bValue)
	{
		m_bValue = bValue;
		m_bIsEmpty = false;		
	}

	/**
	 * Provides the DTOBoolean class member.
	 * @return boolean 
	 */
	public boolean getValue()
	{
		return m_bValue;
	}
	
	public boolean isEmpty()
	{
		return m_bIsEmpty;
	}

	/**
	 * @return string presentation of the object
	 */
	public String toString()
	{
		return toString(m_bIsEmpty,Boolean.toString(m_bValue));
	}
}
