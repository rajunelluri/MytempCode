package backend.dataaccess.dto;

import java.util.HashMap;
import java.util.Set;

/*
 * Description: Hold data from the DB in a HashMap structure
 * Company:		Fundtech Israel
 * Author:		Yaron Mizrahi
 * Date:		September 5 2006
 */

public class DTOHashMap extends DTOBasic
{
    private HashMap m_hm;
    boolean m_bIsEmpty;
    
    /**
     * 
     */
    public DTOHashMap() 
    {
        super();

        m_hm = new HashMap();
        m_bIsEmpty = true;        
    }
    
    public String put(String sKey, String sValue)
    {
        m_bIsEmpty = false;    	
    	return (String)m_hm.put(sKey, sValue);
    }
    
    public String get(String sKey)
    {
    	return (String)m_hm.get(sKey);
    }
    
    public boolean isEmpty()
    {
    	return m_bIsEmpty;
    }
    /**
     * Removes an entry 
     * @param sKey - key to be removed
     * @return removed value 
     * or null in the case where key not found or null is the real value
     */
    public String remove(String sKey)
    {
    	return (String)m_hm.remove(sKey);
    }
    
    public Set entrySet()
    {
    	return m_hm.entrySet();
    }
}
