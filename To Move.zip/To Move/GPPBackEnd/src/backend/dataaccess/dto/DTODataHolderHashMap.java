/**
 * Maps a data holder to a data holder
 * @autor Yaron Mizrahi
 * @date 12 aug 2005
 * Not in use currently !!!
 */
package backend.dataaccess.dto;

import java.util.HashMap;

/**
 * @author YaronM
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class DTODataHolderHashMap extends DTOBasic 
{
	private HashMap m_hm;
	
	public DTODataHolderHashMap()
	{
		super();
		
		m_hm = new HashMap();
	}
	
	public DTODataHolder put(DTODataHolder dataHolderKey, DTODataHolder dataHolderValue)
	{
		return (DTODataHolder)m_hm.put(dataHolderKey, dataHolderValue);
	}

	/** Just to make the class compile */
	public boolean isEmpty()
	{
		return true;
	}
}
