package backend.dataaccess.dto;

import java.io.Serializable;

import com.fundtech.datacomponent.response.*;
import com.fundtech.util.GlobalConstants;
/**
 * Title:			DTOBasic
 * date:			05-04-2005		 
 * Description:		Base class for DTO<module-name> classes.
 * Company:			Fundtech Israel
 * @author			Ehud Tavor
 * @version			1.0
 */
public abstract class DTOBasic implements Serializable
{
	/**
     * 
     */
    private static final long serialVersionUID = 1504491124563096163L;

    /** FeedBack to hold the status of the reply*/
	Feedback m_FeedBack = null;
	
	/** Finals for the toString() method */
	static final protected String STRING_EMPTY = "Empty = ";
	static final protected String STRING_VALUE = "Value = ";
	
	/**
	 * constractor
	 * Creates FeedBack class member.
	 */
	public DTOBasic()
	{
		m_FeedBack = new Feedback();
	}
	
	/**
	 * Provides the FeedBack class member.
	 * @return DTOFeedBack.. 
	 */
	public Feedback getFeedBack()
	{
		return m_FeedBack;
	}
	
	public void setFeedback(Feedback feedback)
	{
	    m_FeedBack = feedback;
	}
	
	/**
	 * Check if the status of the reply is SUCCESS.
	 * @return boolean.
	 */
	public boolean isFeedBackSuccess()
	{
		return m_FeedBack.isSuccessful();
	}
	
	public abstract boolean isEmpty();
	
	/**
	 * String presentation of the object
	 * @param bEmpty - whether object holds a value
	 * @param sValue - value string presentation
	 * @return string presentation of the object
	 */
	protected String toString(boolean bEmpty, String sValue)
	{
		StringBuffer sb = new StringBuffer(STRING_EMPTY);
		
		sb.append(bEmpty).append(GlobalConstants.COMMA).append(GlobalConstants.SPACE)
		.append(STRING_VALUE).append(sValue);
		
		return sb.toString();
	}
}