package backend.dataaccess.dto;

import java.util.HashMap;
import com.fundtech.lang.Table;

/**
 * @author RonenM
 * @version=1.0
 * The DTODataTable class is a Table in a database orientation.
 * It has a Table object that contains the data.
 * It contains methods to retrieve field values by the field name. (If JDBC driver provide table name then
 *              it is possible to retrive field info also in 'TABLE.FIELD' format.)
 * NOTE! all values are stored in strings. null values are autoamitc stored as empty string, so no null check is required.
 * It also provides some metadata for each field.
 * DAOBasic contains getDataTable method that populate the Table with data.
 *
 * Example of use:
 *
 * dtoTable.getValue("ACC_NO") //get value of field 'ACC_NO' from the current position
 * dtoTable.getValue(5,"ACC_NO") //get value of field 'ACC_NO' from row 5
 * dtoTable.getValue("ACCOUNTS.ACC_NO") //get the type of field 'ACC_NO'
 * dtoTable.getFieldType("ACC_NO") //get the type of field 'ACC_NO'
 *
 */

public class DTODataTable extends DTOBasic
{

    private Table m_table;
    private HashMap m_hmFieldsIndex;
    static final public int FIELD_INDEX = 0;
    static final public int FIELD_TYPE = 1;
    static final public int FIELD_SIZE = 2;
    static final public int FIELD_TABLE = 3;

    /**
     *
     * Constractor
     */
    public DTODataTable()
    {
        super();
        m_hmFieldsIndex = new HashMap();
    }

    /**
     * Set a table object into the DTODataTable
     * @param table - A table object.
     */
    public void setTable(Table table)
    {
        m_table = table;
    }

    /**
     * get reference the the table object
     * @return
     */
    public Table getTable()
    {
        return m_table;
    }

    /**
     * get refernce to a hashmap object that contains information on the fields. (like field's index position in the table,
     * source table,data type and size)
     * @return HashMap
     */
    public HashMap getFieldsInfo()
    {
        return m_hmFieldsIndex;
    }

    /**
     * set refernce to a hashmap object that contains information on the fields. (like field's index position in the table,
     * source table,data type and size)
     */
    public void setFieldsInfo(HashMap fieldPosition)
    {
        m_hmFieldsIndex = fieldPosition;
    }

    /**
     * @return true is no rows retived from the database.
     */
    public boolean isEmpty()
    {
        boolean bRetVal = true;

        if (m_table != null && !m_table.isEmpty())
        {
            bRetVal = false;
        }
        return bRetVal;
    }

    /**
     * Get a value of a specific field on the current row position
     * @param sFieldName - the name of the field to retrive it's value
     * @return the value of the field
     */
    public String getValue(String sFieldName)
    {
        Object[] arrFieldInfo = (Object[]) m_hmFieldsIndex.get(sFieldName);
        int i = ((Integer) arrFieldInfo[FIELD_INDEX]).intValue();
        String sValue = (String) m_table.getValue(i);
        return sValue;
    }

    /**
     * Get a value of a specific field on the iRow row position.
     * @param iRow - the row of the requested value.
     * @param sFieldName - the name of the field to retrive it's value.
     * @return the value of the field.
     */
    public String getValue(int iRow, String sFieldName)
    {
        Object[] arrFieldInfo = (Object[]) m_hmFieldsIndex.get(sFieldName);
        int i = ((Integer) arrFieldInfo[FIELD_INDEX]).intValue();
        String sValue = (String) m_table.getValue(iRow, i);
        return sValue;
    }

    /**
     * Get the type of a specific field.
     * @param sFieldName - the name of the field to retrive it's type.
     * @return int contains the type of the field.
     */
    public int getFieldType(String sFieldName)
    {
        Object[] arrFieldInfo = (Object[]) m_hmFieldsIndex.get(sFieldName);
        int i = ((Integer) arrFieldInfo[FIELD_TYPE]).intValue();
        int iValue = ((Integer) m_table.getValue(i)).intValue();
        return iValue;
    }

    /**
     * Get the name of the table that the field is belong to.
     * NOTE !! Not all JDBC drivers get this information from database server.
     * @param sFieldName - the name of the field to retrive it's source table.
     * @return
     */
    public String getFieldSourceTable(String sFieldName)
    {
        Object[] arrFieldInfo = (Object[]) m_hmFieldsIndex.get(sFieldName);
        int i = ((Integer) arrFieldInfo[FIELD_TABLE]).intValue();
        String sValue = (String) m_table.getValue(i);
        return sValue;
    }

    /**
     * Find a value in a specific column.
     * @param sFieldName = the name of the field to search the value
     * @param cOperator = the operator to use (currently only '=' implemented)
     * @param oValue = The value to seach for.
     * @param cDirection = Direction from the cursor ('F'=Forward otherwise backwards)
     * @param iStartRow = which row to start from.
     * @return
     */
    public boolean find(String sFieldName, char cOperator, Object oValue, char cDirection, int iStartRow)
    {
        return m_table.find(((Integer) m_hmFieldsIndex.get(sFieldName)).intValue(), cOperator, oValue,
                cDirection, iStartRow);
    }

    /**
     *  @return a string contains all rows of the Data table.
     */
    public String toString()
    {
        return m_table.toString();
    }
}
