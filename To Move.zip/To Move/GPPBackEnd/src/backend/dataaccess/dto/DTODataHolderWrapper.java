package backend.dataaccess.dto;

/**
 * Is used in order to use as a data holder and to wrap 
 * a second data holder
 * @author YaronM
 */
public class DTODataHolderWrapper extends DTODataHolder 
{
	/** Internal dto */
	private DTOBasic m_dtoWrapped;
	
	/**
	 * C'tor 
	 * @param dtoOriginal - original dto 
	 * @param dtoWrapped - wrapped dto
	 */
	public DTODataHolderWrapper(DTODataHolder dtoOriginal, DTOBasic dtoWrapped)
	{
		// Set this object to replace original dto
		m_alDataRows = dtoOriginal.getDataAL();
		m_dtoWrapped = dtoWrapped;
	}
		
	/**
	 * @return internal dto
	 */
	public DTOBasic getInternalDataHolder()
	{
		return m_dtoWrapped;
	}
}
