package backend.dataaccess.dto;



import java.math.BigDecimal;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.lang.FTFormater;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalXMLTextUtil;
import com.fundtech.util.MetaDataHolder;
/**
 * Title:			DTODataHolder
 * date:			05-04-2005
 * Description:		Base class for DTO<module-name> classes which need to return data.
 * Company:			Fundtech Israel
 * @author			Ehud Tavor
 * @version			1.0
 */
public class DTODataHolder extends DTOBasic
{
	private final static Logger logger = LoggerFactory.getLogger(DTODataHolder.class);
	protected static final Map EMPTY_MAP = new HashMap() ;
	
    /* Data rows container - Hold a row from the DB in each of its entries. */
    protected ArrayList m_alDataRows;

    /**
     * C'ror
     */
    public DTODataHolder()
    {
        m_alDataRows = new ArrayList();
    }

    /**
     * Add a data row to the container.
     * @return void.
     * @param hmDataRow - HashMap which represents a data row.
     */
    public void addDataRow(Map hmDataRow)
    {
        m_alDataRows.add(hmDataRow);
    }

    /**
     * provides a data row from the container according to location.
     * @return HashMap which represents a data row.
     * @param iRowLocation - Location of the row which will be retrieved.
     */
    public HashMap getDataRow(int iRowLocation)
    {
        return (HashMap) m_alDataRows.get(iRowLocation);
    }

    /**
     * @return the first data row
     */
    public HashMap getDataRow()
    {
        return (HashMap) (!m_alDataRows.isEmpty() ? m_alDataRows.get(0) : EMPTY_MAP) ;
    }
    
    /**
     * @param sColumnNAme - column to retrive
     * @return a string representation of a column or null
     * if the column is not found or the object is empty
     */
    public String getColumnData(String sColumnNAme)
    {
        String sRetVal = null;

        if (!m_alDataRows.isEmpty())
        {
            sRetVal = (String) ((HashMap) m_alDataRows.get(0)).get(sColumnNAme);
        }
        
        if(sRetVal == null)
        {
          sRetVal=GlobalConstants.EMPTY_STRING;
        }
        
        return sRetVal;
    }

    /**
     * @param sColumnNAme - column name to put
     * @param sColumnValue - column value to put
     */
    public void addColumn(String sColumnNAme, String sColumnValue)
    {
        HashMap rowData = (HashMap) m_alDataRows.get(0);
        rowData.put(sColumnNAme, sColumnValue);
        m_alDataRows.set(0, rowData);
    }

    /**
     * @param sColumnNAme - column to retrive
     * @return a string representation of a column or null
     * if the column is not found or the object is empty
     */
    public String getColumnDataByRow(String sColumnNAme, int iRowNum)
    {
        String sRetVal = null;

        if (!m_alDataRows.isEmpty())
        {
            sRetVal = (String) ((HashMap) m_alDataRows.get(iRowNum)).get(sColumnNAme);
        }

        return sRetVal;
    }

    /**
     * Provides the number of rows in the container.
     * @return Number of rows in the container.
     */
    public int getRowsNumber()
    {
        return m_alDataRows.size();
    }

    /**
     * Returns the ArrayList class member.
     * @return returns the ArrayList class member.
     * @author AsafL
     *
     * TODO To change the template for this generated type comment go to
     * Window - Preferences - Java - Code Style - Code Templates
     */
    public ArrayList getDataAL()
    {
        return m_alDataRows;
    }

    /**
     * Sets the 'm_alDataRows' class member.
     * @param alDataRows the ArrayList to set.
     */
    public void setDataAL(ArrayList alDataRows)
    {
        m_alDataRows = alDataRows;
    }

    /**
     * Replace a data row to the container based on the row location.
     * @return void.
     * @param hmDataRow - HashMap which represents a data row.
     * @param iRowLocation - RowLocation which represents row location.
     */
    public void setDataRow(int iRowLocation, HashMap hmDataRow)
    {
        m_alDataRows.set(iRowLocation, hmDataRow);
    }

    /**
     * @param sColumnName - column name to set value
     * @param sColumnValue - column value
     */
    public void setColumnData(String sColumnName, String sColValue)
    {
        if (!m_alDataRows.isEmpty())
        {
            String sRetVal = (String) ((HashMap) m_alDataRows.get(0)).put(sColumnName, sColValue);
        }
    }

    /**
     * @param sColumnName - column name to set value
     * @param sColValue - column value
     * @param iRowNum - row number
     */
    public void setColumnDataByRow(String sColumnName, String sColValue, int iRowNum)
    {
        if (!m_alDataRows.isEmpty())
        {
        	((HashMap) m_alDataRows.get(iRowNum)).put(sColumnName, sColValue);
        }
    }
 
    /**
     *
     * return true if there is data, false if no.
     */
    public boolean isEmpty()
    {
        return m_alDataRows.size() == 0;
    }
    
    
    /**
     * Returns a matrix of this instances m_alDataRows content. 
     * as the column data within each of the row is ordered by its hash value and not nessecarily 
     * the required one, the option is given to provide this method with the order. 
     * Only the values of the columns set provided to this methods would be retruned  
     * If the  arrColumnNamesOrder is null - 
     * @param arrColumnNamesOrder String[] containing the order inwhich the columns data would be ordered 
     *        within the matrix second level 
     * @return Object[][] containing the row content of this instance 
     * @throws IllegalArgumentException if a column name passed in within the formal args was not found 
     */
    public Object[][] getRowsMatrix(String[] arrColumnNamesOrder) throws IllegalArgumentException{ 
        final String COLUMN_WAS_NOT_FOUND_MSG = "column {0} does not exist within this data holder" ;
               
        int iColumnQuantity = arrColumnNamesOrder.length ;
        int iRowsQuantity = this.m_alDataRows.size() ; 
        
        Object[][] arrMatrix = new Object[iRowsQuantity][iColumnQuantity] ;
        Map mRowContent = null  ;
        
        //iterate over the rows, fetch the values  and for each 
        //iterate over the formal args' column names and put them in the matrix 
        for(int iRowCursor=0;  iRowCursor < iRowsQuantity; iRowCursor++) { 
           mRowContent = (Map) this.m_alDataRows.get(iRowCursor) ;
           
          
           //now iterate over the formal args' column names and put them in the matrix 
           for(int iColumnCursor=0; iColumnCursor < iColumnQuantity; iColumnCursor++)
           {
             // TODO: The encode should be done only on CHAR/VRACHAR columns...
             arrMatrix[iRowCursor][iColumnCursor] = GlobalXMLTextUtil.encode((String)mRowContent.get(arrColumnNamesOrder[iColumnCursor])) ;
           }///EO while there are more columns to retrieve from each of the lines 
        }//EO while there are more rows  
        
        return arrMatrix ; 
    }//EOM

    public boolean isColumnExist(String sColumnName)
    {
        return !m_alDataRows.isEmpty() && ((HashMap) m_alDataRows.get(0)).containsKey(sColumnName);
    }
    /**
     *
     * return true if sCompareValue is equal to the data holder value
     * This method consider the type of the field.
     */
    public boolean equals(String sColumnNAme, String sTableName, String sCompareValue)
    {
      boolean b = false;
      
      String sOldValue = (getColumnData(sColumnNAme) == null) ? GlobalConstants.EMPTY_STRING : getColumnData(sColumnNAme);
      
      int iType = MetaDataHolder.getColumnType(sTableName, sColumnNAme);
      
      if(sOldValue.equals(GlobalConstants.EMPTY_STRING) && sCompareValue.equals(GlobalConstants.EMPTY_STRING))
      {
        iType = Types.VARCHAR;
      }
      
      switch (iType)
      {
        case Types.INTEGER:
        case Types.DECIMAL:
        case Types.DOUBLE:
        case Types.FLOAT:
        case Types.NUMERIC:
        case Types.REAL:
        case Types.SMALLINT:
        case Types.TINYINT:
        {
          // Either database value is empty OR sent value is empty --> the field was modified. 
          if(   (   sOldValue.equals(GlobalConstants.EMPTY_STRING)
                 && !sCompareValue.equals(GlobalConstants.EMPTY_STRING))
             || (  !sOldValue.equals(GlobalConstants.EMPTY_STRING)
                 && sCompareValue.equals(GlobalConstants.EMPTY_STRING)))
          {
            b = false;
          }
          
          // Both values are not empty; perform numeric comparison.
          // Note: both value are for sure not empty because of the setting to VARCHAR type
          //       in case they are both empty, whihc is done before the 'switch' clause starts.
          else
          {
            //CR# 90838 : Changed Float objects to BigDecimal in the else block
        	BigDecimal bdOldValue = new BigDecimal(sOldValue);
            BigDecimal bdCompareValue = new BigDecimal(sCompareValue);
            b = bdOldValue.compareTo(bdCompareValue)==0;
          }
          break;
        }
        case Types.CHAR:
        case Types.VARCHAR:
        case Types.LONGVARCHAR:
        case Types.BOOLEAN:
        {
            b = sOldValue.equals(sCompareValue);
            break;
        }
  
        case Types.TIMESTAMP:
        case Types.DATE:
        {
            Date dateOldValue = FTFormater.string2date(sOldValue);
            Date dateCompareValue = FTFormater.string2date(sCompareValue);
            int i = dateOldValue == null || dateCompareValue == null ? 
                    sOldValue.compareTo(sCompareValue) : 
                    dateOldValue.compareTo(dateCompareValue);
            b = (i == 0);
            break;
        }
        default:
        break;
      }

      return b;
    }
    
    /**
     * Sorts the container according to specific column
     * @param sColumnName - Column Name to order by
     **/
    public void sortPerColumn(String sColumnName)
    {
    	sortPerColumn(null, sColumnName);
    }
    
    /**
     * Sorts the container according to specific column
     * @param sTableName - Table Name prefix of the column to order by
     * @param sColumnName - Column Name to order by
     **/
    public void sortPerColumn(String sTableName, String sColumnName)
    {
    	if (!m_alDataRows.isEmpty())
    	{
    		DTOComparator comparator = new DTOComparator(sTableName, sColumnName);
    		try
    		{
    			Collections.sort(m_alDataRows, (Comparator)comparator);
    		}
    		catch(Exception e)
    		{
    			logger.error(e.getMessage());
    		}
    	}
    }
    
    private class DTOComparator implements Comparator
    { 
    	private String m_sTableName;
        private String m_sColumnName;
         
        public DTOComparator(String sTableName, String sColumnName) 
        { 
            m_sTableName = sTableName; 
            m_sColumnName = sColumnName;
        }
            	
    	public int compare(Object arg1, Object arg2) 
    	{
    		int iReturn = 0;
    		int iType = (m_sTableName!=null)
    			? MetaDataHolder.getColumnType(m_sTableName, m_sColumnName) : Types.VARCHAR;//- returned type value is int; if column is not found, returned value is '-1'.
            
    		switch (iType)
            {
                case Types.INTEGER:
                case Types.DECIMAL:
                case Types.DOUBLE:
                case Types.FLOAT:
                case Types.NUMERIC:
                case Types.REAL:
                case Types.SMALLINT:
                case Types.TINYINT:
                {
                	Float sValue1 = (Float) ((Map)arg1).get(m_sColumnName);
                	Float sValue2 = (Float) ((Map)arg2).get(m_sColumnName);
                	iReturn = sValue1.compareTo(sValue2);
                    break;
                }
                case Types.CHAR:
                case Types.VARCHAR:
                case Types.LONGVARCHAR:
                case Types.BOOLEAN:
                {
                	String sValue1 = (String) ((Map)arg1).get(m_sColumnName);
            		String sValue2 = (String) ((Map)arg2).get(m_sColumnName);
            		iReturn = sValue1.compareTo(sValue2);
                    break;
                }

                case Types.DATE:
                {
                	Date sValue1 = (Date) ((Map)arg1).get(m_sColumnName);
                	Date sValue2 = (Date) ((Map)arg2).get(m_sColumnName);
            		iReturn = sValue1.compareTo(sValue2);
                    break;
                }
                default:
                    break;
            }
    		
    		return iReturn;
    	}
    } 
    

}
