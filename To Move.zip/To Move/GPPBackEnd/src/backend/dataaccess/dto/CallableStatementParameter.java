package backend.dataaccess.dto;

import com.fundtech.core.general.StatementParameter;
import com.fundtech.util.GlobalConstants;

public class CallableStatementParameter extends StatementParameter
{
    // Properties of a parameter.
    public static final String INPUT_ONLY = "INPUT_ONLY";
    public static final String OUTPUT_ONLY = "OUTPUT_ONLY";
    public static final String INPUT_AND_OUTPUT = "INPUT_AND_OUTPUT";

    // Used for success/failure, (values are usually 0/1/2; see also the OUTPUT_ERROR_CODE property).
    public static final String OUTPUT_RETURN_CODE = "OUTPUT_RETURN_CODE";

    // Used for holding error codes from the ERRCODES table; when the application server
    // gets a value in this output parameter, it should get the matching error message
    // from the table.
    public static final String OUTPUT_ERROR_CODE = "OUTPUT_ERROR_CODE";

    public static final String OUTPUT_ERROR_TEXT = "OUTPUT_ERROR_TEXT";

    private static final String IN_OUT="Input/Output=";
    private static final String VALUE="Value=";
    private static final String RES_VALUE="Result Value=";


    private String m_sParameterProperty;
    private String m_ResultValue = GlobalConstants.EMPTY_STRING;

    /**
     * C'tor
     */
    public CallableStatementParameter()
    {
        super();
        m_sParameterProperty = new String(INPUT_ONLY);
    }

    /**
     * C'tor
     * @param sDirection - Direction of the parameter.
     */
    public CallableStatementParameter(String sParameterPropertie)
    {
        super();
        m_sParameterProperty = new String(sParameterPropertie);
    }

    /**
     * C'tor
     * @param sDirection - Direction of the parameter.
     * @param oPArameter - statement parameter
     * @param iTargetSqlType - parameter type
     */
    public CallableStatementParameter(String sParameterPropertie, Object oPArameter, int iTargetSqlType)
    {
        super(oPArameter, iTargetSqlType);
        m_sParameterProperty = new String(sParameterPropertie);
    }

    /**
     * @return Returns the m_sParameterProperty.
     */
    public String getParameterProperty()
    {
        return m_sParameterProperty;
    }

    /**
     * @param parameterProperty The m_sParameterProperty to set.
     */
    public void set_ParameterProperty(String parameterProperty)
    {
        m_sParameterProperty = parameterProperty;
    }

    /**
     * Check if a parameter is an input parameter.
     * @return boolean.
     */
    public boolean isInputParameter()
    {
        boolean bIsInputParameter = false;

        if (m_sParameterProperty.equals(INPUT_ONLY) || m_sParameterProperty.equals(INPUT_AND_OUTPUT))
        {
            bIsInputParameter = true;
        }

        return bIsInputParameter;
    }

    /**
     * Check if a parameter is an input parameter.
     * @return boolean.
     */
    public boolean isOutputParameter()
    {
        boolean bIsOutputParameter = false;

        if (m_sParameterProperty.equals(OUTPUT_ONLY) || m_sParameterProperty.equals(INPUT_AND_OUTPUT)
                || m_sParameterProperty.equals(OUTPUT_RETURN_CODE)
                || m_sParameterProperty.equals(OUTPUT_ERROR_CODE)
                || m_sParameterProperty.equals(OUTPUT_ERROR_TEXT))
        {
            bIsOutputParameter = true;
        }

        return bIsOutputParameter;
    }

    /**
     * @return Returns the m_ResultValue.
     */
    public String getResultValue()
    {
        return m_ResultValue;
    }

    /**
     * @param resultValue The m_ResultValue to set.
     */
    public void setResultValue(String resultValue)
    {
        m_ResultValue = resultValue;
    }

    /**
     * Init the object with a string based parameter
     * @param sDirection - Direction of the parameter.
     * @param oPArameter - statement parameter
     * @param iTargetSqlType - parameter type
     */
    public void init(String sParameterPropertie, String sPArameter, int iTargetSqlType)
    {
        super.init(sPArameter, iTargetSqlType);
        m_sParameterProperty = new String(sParameterPropertie);
    }

    public String toString()
    {
        StringBuffer sb = new StringBuffer(GlobalConstants.EMPTY_STRING);
        sb.append(GlobalConstants.OPENING_SQUARE_BRACKET).append(IN_OUT).append(m_sParameterProperty).append(GlobalConstants.CLOSING_SQUARE_BRACKET).append(GlobalConstants.SEMI_COLON).
        append(GlobalConstants.OPENING_SQUARE_BRACKET).append(VALUE).append(m_oParameter).append(GlobalConstants.CLOSING_SQUARE_BRACKET).append(GlobalConstants.SEMI_COLON).
                    append(GlobalConstants.OPENING_SQUARE_BRACKET).append(RES_VALUE).append(m_ResultValue).append(GlobalConstants.CLOSING_SQUARE_BRACKET);
        return sb.toString();
    }
}
