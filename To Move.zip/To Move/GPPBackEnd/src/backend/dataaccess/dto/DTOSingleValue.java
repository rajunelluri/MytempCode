package backend.dataaccess.dto;

/*
 * Description: Cheap data holder to hold a single value
 * Company:		Fundtech Israel
 * Author:		Yaron Mizrahi
 * Date:		Apr 25, 2005
 */

public class DTOSingleValue extends DTOBasic
{
    private Object m_value;
    boolean m_bIsEmpty;
    
    /**
     * 
     */
    public DTOSingleValue() 
    {
        super();
        m_bIsEmpty = true;        
    }

    public DTOSingleValue(Object sValue) 
    {
        this();
        
        m_value = sValue;
        m_bIsEmpty = false;        
    }

    public void setValue(Object sValue)
    {
        m_value = sValue;
        m_bIsEmpty = false;        
    }
    
    public String getValue()
    {
        return (String) m_value;
    }
    
    public Object getRawValue()
    {
        return  m_value;
    }
    
    public boolean isEmpty()
    {
    	return m_bIsEmpty;
    }
}
