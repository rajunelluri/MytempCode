package backend.dataaccess.dto;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import com.fundtech.core.security.Admin;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class IterableResultSet implements Iterable<Map> { 

	private final static Logger logger = LoggerFactory.getLogger(IterableResultSet.class);
	
	private static final String UNSUPPORTED_OPERATION_ERR_MSG = "Unsupported Method"  ;
	
	private ResultSetMapWrapper m_mapWrapper; 
	
	public IterableResultSet(ResultSet rs) { 
		this.m_mapWrapper = new ResultSetMapWrapper(rs) ; 
	}//EOM 
	
	public Iterator<Map> iterator() {
		return new Iterator<Map>(){ 
								
			public boolean hasNext() {  return m_mapWrapper.next() ; }//EOM
			
			public Map next() { return m_mapWrapper ; }//EOM 
			
			public void remove() {
				throw new UnsupportedOperationException(UNSUPPORTED_OPERATION_ERR_MSG) ;
			}//EOM 
			
		}; //EO new iterator 
	}//EOM 
	 		
	public static final class ResultSetMapWrapper implements java.util.Map<String, Object> { 
		
		private ResultSet m_rs; 
		private final Set<String> m_setColumns ; 
		
		public ResultSetMapWrapper(ResultSet rs) { 
			this.m_rs = rs ; 
			try{ 
				this.m_setColumns = new HashSet<String>() ;
				final ResultSetMetaData rsmd = this.m_rs.getMetaData() ; 
				
				for(int i=1; i <= rsmd.getColumnCount(); i++) { 
					this.m_setColumns.add(rsmd.getColumnLabel(i)) ;
				}//EO while there are more columns
			}catch(Exception e) { 
				throw new RuntimeException(e) ; 				
			}//EO catch block 
		}//EOC 
		
		public final boolean next() { 
			try{ 
				return this.m_rs.next() ;
			}catch(SQLException e) { 
				logger.error(e.getMessage());
				return false ; 
			}//EO catch block 
		}//EOM 
		
		public Object get(Object key){
			try{  
				if(!this.m_setColumns.contains(key)) return null ;
				else return this.m_rs.getObject((String)key) ;
			}catch(SQLException e) { 
				logger.error("Key {} not not found in resultset", key);
				return null ; 
			}//EO catch block 
		}//EOM 
		
		public int size() {
			throw new UnsupportedOperationException(UNSUPPORTED_OPERATION_ERR_MSG) ;
		}//EOM 
		
		public void clear() {
			throw new UnsupportedOperationException(UNSUPPORTED_OPERATION_ERR_MSG) ;
		}//EOM 
		
		public boolean containsKey(Object key) { 
			throw new UnsupportedOperationException(UNSUPPORTED_OPERATION_ERR_MSG) ;
		}//EOM
		
		public boolean containsValue(Object value) {
			throw new UnsupportedOperationException(UNSUPPORTED_OPERATION_ERR_MSG) ;
		}//EOM 
		
		public Set<String> keySet() {
			throw new UnsupportedOperationException(UNSUPPORTED_OPERATION_ERR_MSG) ;
		}//EOM
		
		public Set entrySet() {
			throw new UnsupportedOperationException(UNSUPPORTED_OPERATION_ERR_MSG) ;
		}//EOM 
					
		public boolean isEmpty() {
			throw new UnsupportedOperationException(UNSUPPORTED_OPERATION_ERR_MSG) ;
		}//EOM 
		
		public Object put(String key, Object value) {
			throw new UnsupportedOperationException(UNSUPPORTED_OPERATION_ERR_MSG) ;
		}//EOM 
		
		public void putAll(java.util.Map<? extends String, ? extends Object> m) {
			throw new UnsupportedOperationException(UNSUPPORTED_OPERATION_ERR_MSG) ;
		}//EOM			
		
		public Object remove(Object key) {
			throw new UnsupportedOperationException(UNSUPPORTED_OPERATION_ERR_MSG) ;
		}//EOM 
		
		public Collection<Object> values() {
			throw new UnsupportedOperationException(UNSUPPORTED_OPERATION_ERR_MSG) ;
		}//EOM
		
		
	}//EO inner-inner class ResultSetMapWrapper
	
}//EO inner class
