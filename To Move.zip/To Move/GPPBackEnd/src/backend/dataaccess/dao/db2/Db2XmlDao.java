package backend.dataaccess.dao.db2;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlObjectBase;
import org.w3c.dom.Document;

import com.fundtech.cache.entities.LogicalFields;
import com.fundtech.core.paymentprocess.data.das.DASInterface.XmlLocationType;
import com.fundtech.core.paymentprocess.data.paymenttypes.PaymentType;

import backend.dataaccess.dao.AbstractXmlDao;
import backend.dataaccess.dao.AbstractXmlDao.CommandInfo.NodeGroupInfo;
import backend.dataaccess.dao.AbstractXmlDao.CommandInfo.NodeInfo;
import backend.util.ServerConstants;

/**
 * @author guys
 * 
 * DB2 XML column types handling class. 
 * 
 * Provides the means to perform the following actions: 
 * 1. Single String value extraction  
 * 2. XML Subset or column recrod content extraction 
 * 3. XML node updates.
 *
 *  NOTE:
 *  All XML nodes are considered fullly qualified and comprised of two parts : <namespace>:<local element name>. 
 *	Thus in order too access a given element, the default behaviour dictates that the namespace (or a prefix alias 
 *	which might be nothing if so declared in the xmlns prolog) must be defined along with the element name. 
 *	In order to emulate a namespce unaware behaviour, all elments must be prefixed by one of the following delerations: 
 *	1.  *:<element local name> - defines the element as belonging to all namespaces. 
 *	2.  *[local-name()="<element local name>"]
 *	3.  *[name()="<element local name>"]
 *	As writing and maintaing xpaths containing such declarations is unreasonably tedious, all methods in this class 
 *	provide the following facility: 
 *		If the namespce is provided, the methods will declare it as the default element namespace thus alliviating 
 *		the neeed for namespace prefix.
 *		Otherwise if the namespace was not provided, the methods will modify all xpath queries provided 
 *		to include either the first or the third aforementioned option. 
 *		Please adhere be the following rules while developing an xpath query: 
 *		1. xpath might already be enriched by the '*:' namespace, in which case, the methods will not modify the xpath. 
 *		   This behaviour is applied to each xpath element individually (i.e. those nodes declared without the 
 *		   prefix would be modified while those containing the declaration will not). 
 *		2. xpath must not contain the local() or local-name() declaration in conjunction with null namespace 
 *		   as the methods will not check for the existence of the constructs, and will hence render the xpath 
 *		   query invalid by adding the construct again.
 *		   In other words, when providing no namespace, provide xpath queries that do not contain 
 *		   namespace declaration. The various method will ensure that those are added.
 *		 
 *	 	Note: currently, a single namespace declaration is supported through this method. Nevertheless, as the db syntax 
 *	 	 * 		 supports multiple namespace declarations, if the need arises, the method could be altered to accomodate it.
 *	 	 * 		 The current implementation, for convenience sake, decalres a no-prefix namespace so that the elementXPath
 *		 * 		 value should not be altered to include the namespace prefix.
 *  
 *  
 */
public class Db2XmlDao extends AbstractXmlDao {
	
	/**
	 * Constants and formatter templates used in the process of query construction
	 */

   protected static final String SINGLE_VALUE_SELECT_STATEMENT_TEMPLATE = 
        "char(xmlserialize(content xmlquery('%s $doc%s' passing %s %s as \"doc\" %s) as varchar(4000)))" ;

	/*
	 * 1 - column name
	 */
	private static final String XML_COLUMN_UPDATE_TEMPLATE = "%s = xmlquery(' " ;
	
	
	/*
	 * 
	 * 1- column name 
	 */
	private static final String PASSING_BY_REF_TEMPLATE = " passing by ref %s as \"doc\"" ;
	/*
	 * 1- xpath
	 */
	private static final String NODE_GROUP_START_TEMPLATE = " for $e in $newDoc%s return (" ;
	private static final String NODE_GROUP_END_TEMLATE = ") return $newDoc' " + PASSING_BY_REF_TEMPLATE ; 
	private static final String COPY_DOC_AND_MODIFY_TEMPLATE = " copy $newDoc := $doc modify( " ; 
	/*
	 * 1 - xpath relative to the context root xpath 
	 * 2 - binding variable reference name  
	 */
	private static final String REPLACE_VALUE_OF_TEMPLATE = "do replace value of $e%s with %s" ; 
	/*
	 * 1 - variable binding reference name
	 */
	private static final String BOUND_PARAMETER_REF_TEMPLATE = " cast(? as varchar(2000)) as \"%s\"";  
	
 	
 	private static final String PASSING_BY_REF_TYPE = "by ref"  ;
 		
	/**
	 * Utility method used to construct an update sql/xml query.
	 * @param ctx ProcessingContext instance containing all data required for query construction.  
	 * @return 
	 * @see update() for more information on the ProcessingContext content and query syntax.
	 */
	@Override
	protected final String constructUpdateQueryInnerHook(final ProcessingContext ctx) { 
		
		 final CommandInfo commandInfo = ctx.getCommandInfo() ; 
		 
		//constrsuct the update statement 
		ctx.getOvrllBldr().append(
				String.format(XML_COLUMN_UPDATE_TEMPLATE, 
						commandInfo.getColumnname())) ; 
		
		//constructs and appends the namespace delaration
		//if the namespace is null (not provided) modify all xpath elements to include the 
		//any-namespace declaration
		String sNsDecleration = null ;
		
		if(commandInfo.getNamespace() != null) { 
			sNsDecleration = String.format(NS_DECLAREATION_TEMPLATE, commandInfo.getNamespace()) ;
		}else { 
			sNsDecleration = ServerConstants.EMPTY_STRING ; 
		}//EO else if the namespace was not provided 
		
		ctx.getOvrllBldr().append(sNsDecleration) ;
		
		//appends the copy document to variable and modify keyword part. 
		ctx.getOvrllBldr().append(COPY_DOC_AND_MODIFY_TEMPLATE) ; 
		
		//constructs and appends all node group updates
		Iterator<NodeGroupInfo> iterator = commandInfo.nodeGroupIterator() ; 
		
		while(iterator.hasNext()) { 
			
			ctx.setCurrentNodeGroupInfo(iterator.next()) ;  
									
			//constrcuts and appends the parent foreach using the root xpath 
			this.constructNodeGroupUpdate(ctx) ;  
						
			//close the for loop's return parenthesys 
			ctx.getOvrllBldr().append(") ") ; 
			
			//if there are more node groups append a ','
			if(iterator.hasNext()) ctx.getOvrllBldr().append(',');
					
		}//EO while there are more node groups to process 
		
		//close the node group block 
		ctx.getOvrllBldr().append(
				String.format(NODE_GROUP_END_TEMLATE, ctx.getCommandInfo().getColumnname())) ;
		
		//append the variable reference declarations 
		ctx.getOvrllBldr().append(',').append(
						ctx.valuesRefDeclarationBuilder().toString()) ; 		
									
		//append the ') from <tableName>' of the complete xml query
		ctx.getOvrllBldr().append(')') ; 
		
		return ctx.getOvrllBldr().toString() ;  		
	}//EOM 
	
	/**
	 * Utility method used to construct a set of node updates logically grouped under a single context parent xpath.
	 * 
	 * @param ctx ProcessingContext instance containing all data required for query construction.  
	 * @see update() for more information on the ProcessingContext content and query syntax.
	 */
	private final void constructNodeGroupUpdate(final ProcessingContext ctx) { 
		
		Iterator<NodeInfo> iterator = ctx.getCurrentNodeGroupInfo().nodeInfoIterator() ;
		
		NodeInfo nodeInfo = null ;  
		
		//if the namespace delcaration was missing, modify the xpath  
		//to prefix each xpath element with the any-namspace declaration on each 
		String sParentXPath = ( ctx.getCommandInfo().getNamespace() != null ?
				ctx.getCurrentNodeGroupInfo().m_sParentXPath :
				this.modifyXpathToIgnoreNamespace(ctx.getCurrentNodeGroupInfo().m_sParentXPath) 
				) ; 
		
		//constructs the for each statement 
		final String sforEachStatement = String.format(NODE_GROUP_START_TEMPLATE, sParentXPath) ; 
		
		//appends the for each statement to the overall query 
		ctx.getOvrllBldr().append(sforEachStatement);
		
		//as batches are unrelated, checks for the existance of a previous one and current one 
		//and if found to be  true delimits the batches
		if(ctx.valuesRefDeclarationBuilder().length() > 0 &&
		   iterator.hasNext() ) ctx.valuesRefDeclarationBuilder().append(',') ;
		
		while(iterator.hasNext()) { 
			
			nodeInfo = iterator.next() ;  
							
			//constructs and appends the node value assignments
			this.constructNodeValueAssignment(nodeInfo, ctx)  ;
			
			//if this is the not last parameter, append ','
			if(iterator.hasNext()) { 
				ctx.getOvrllBldr().append(',') ; 
				ctx.valuesRefDeclarationBuilder().append(',') ;
			}//EO if there are more column name-value tuples 
		}//EO while there are more node groups
					
	}//EOM 
	
	/**
	 * Utility method used to construct a single node update. 
	 * 
	 * @param nodeInfo NodeInfo instance for which to construct a 'do replace value of' and a corresponding binding parameter reference clauses.s
	 * @param ctx ProcessingContext instance containing all data required for query construction.  
	 * @see update() for more information on the ProcessingContext content and query syntax.
	 */
	private final void constructNodeValueAssignment(final NodeInfo nodeInfo, final ProcessingContext ctx) { 
			
		String sReference =  null ; 
		
		sReference = ctx.getNextRefVarName() ;  
		
		//if the namespace delcaration was missing, modify the xpath  
		//to prefix each xpath element with the any-namspace declaration on each 
		String sRelativeColumnXpath = ( ctx.getCommandInfo().getNamespace() != null ?
				nodeInfo.getRelativeColumnXPath() :
				this.modifyXpathToIgnoreNamespace(nodeInfo.getRelativeColumnXPath()) 
				) ; 
		
		ctx.getOvrllBldr().append(
				String.format(REPLACE_VALUE_OF_TEMPLATE, sRelativeColumnXpath, '$' + sReference)) ; 
		
		ctx.valuesRefDeclarationBuilder().append( 
				String.format(BOUND_PARAMETER_REF_TEMPLATE, sReference)) ;
		
		//add the value to the m_listParameterValues
		ctx.addBindingParamValue(nodeInfo.getValue()) ; 
					 
	}//EOM 
	  
	/**
	 * Hook method used in the getXML() 
	 * @return The context specific type of the passing by clause 
	 * 
	 * Possible context values: 
	 * DB2:    'by ref' 
	 */
	@Override
	public String getXQueryPassingByTypeString() {
		return PASSING_BY_REF_TYPE ; 
	}//EOM 
	
	/**
	 * Hook method used in the getXML() 
	 * @return The context specific 'Return' block of the 'passing' clasue.
	 * 
	 * Possible context values: 
	 * DB2:    empty String 
	 */
	@Override
	protected String getXQueryPassingReturnClasueString() { 
		return ServerConstants.EMPTY_STRING ; 
	}//EOM
		
	/**
	 * 
	 * Hook method used in the getXML() 
	 * 
	 * Extracts and returns an input stream containing XML data.
	 * 
	 * Note: does not close the ResultSet. 
	 * 
	 * @param rs opened ResultSet to extract the xml input stream from.
	 * @param sColumnName Column name in which the xml data is stored.
	 * @return xml DOM Document. 
	 * @throws SQLException
	 */
	@Override
	protected Document getDomDocument(ResultSet rs, String sColumnName)
			throws Exception {

		//use the getXMLInputStream hook method to retrieve the input stream which 
		//would be used to create the DOM document 
		final InputStream in =  rs.getBinaryStream(sColumnName) ; 
		
		final DocumentBuilder documentBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder() ;
		return documentBuilder.parse(in) ;  
	}//EOM
	
	public XmlObjectBase getColumnContent(ResultSet rs, String sColumnName) throws Exception{
		return (XmlObjectBase) PaymentType.m_contextXchemaTypeLoader.parse(rs.getBinaryStream(sColumnName), null,null) ;   
	}//EOM 
	
	/**
	 * @return int repersentation of the prorietary data type (java.sql.Types.OTHER)
	 */
	@Override
	protected int getXmlColumnDataType() { 
		return java.sql.Types.OTHER ; 
	}//EOM
	
	public final String generateSingleExtractValueClause(final LogicalFields logicalFieldMetadata, final boolean bIsMultiOccurrenceClasue, 
 			final XmlLocationType enumDbColumnName, final String sXPath, String sXpathAppendum, final PaymentType enumPaymentType , 
			final boolean bXmlTypeBelongsToCommonTypes ) { 
		
		final String ANY_ATTRIBUTE_XPATH_ELEMENT = "@*" ;
		
		//if the column is to be constructed for a whereclause and the path ends with '@*' add "/text()" 
		//if(sXPath.endsWith(ANY_ATTRIBUTE_XPATH_ELEMENT)) sXpathAppendum = "/text()"  ;
		sXpathAppendum = "/text()"  ;
		
		//payment type declared namepaces
		//optional common types namespace 
		//XML_MSG, XML_ORIG_MSG 
		//xpath 
		//multi occurrence predicate or /text() 
		//datatype
		//final String sExtractValueTemplate =  "XMLCAST(XMLQUERY( 'declare default element namespace \"%s\" ;%s$%s%s%s') AS %s)" ; 
		final String sExtractValueTemplate =  "XMLCAST(XMLQUERY( '%s%s$%s%s%s') AS %s)" ;
		
		//ns prefix 
		//namespace
		final String COMMON_TYPES_NS_DECLERATION = "declare namespace %s=\"%s\";" ;
		
		return String.format(sExtractValueTemplate, 
				//enumPaymentType.getSchemaNamespace(),
				enumPaymentType.getXpathlNamespaceCaluse().replaceAll("'", "\""), 
				(bXmlTypeBelongsToCommonTypes ? "" : String.format(COMMON_TYPES_NS_DECLERATION, COMMON_TYPES_NS_PREFIX, COMMON_TYPES_NS)), 
				enumDbColumnName, 
				sXPath, 
				sXpathAppendum, 
				logicalFieldMetadata.getDataType().getSqlTypeCastString(logicalFieldMetadata.getMaxLength(),logicalFieldMetadata.getLocationType())
			); 
	}//EOM 
	
	@Override
	public final void bindXmlColumn(final int iColIndex, final XmlObject xmlBeanRoot, final PreparedStatement ps) throws SQLException, IOException{
//		final InputStream in =   xmlBeanRoot.newInputStream() ;
		if (xmlBeanRoot == null)
		{
			setNullToXmlColumn(ps, iColIndex);
		}
		else
		{
			InputStream is = new ByteArrayInputStream(xmlBeanRoot.toString().getBytes());
			ps.setBinaryStream(iColIndex, is, is.available()) ;
		}
		
	}//EOM 
     
    @Override
    public final void bindXmlColumn(final int iColIndex, final String xml, final PreparedStatement ps) throws SQLException, IOException{
		if (xml == null)
		{
			setNullToXmlColumn(ps, iColIndex);
		}
		else
		{
	    	final InputStream in =   new ByteArrayInputStream(xml.getBytes()) ; 
	        ps.setBinaryStream(iColIndex, in, in.available()) ;
		}
    }//EOM 

    @Override
    public final void bindXmlColumn(final int iColIndex, final InputStream is, final PreparedStatement ps) throws SQLException, IOException{
		if (is == null)
		{
			setNullToXmlColumn(ps, iColIndex);
		}
		else
		{
			ps.setBinaryStream(iColIndex, is, is.available()) ;
		}
    }//EOM 

	@Override
	public void setNullToXmlColumn(PreparedStatement ps, int inx) throws SQLException 
	{
		ps.setBinaryStream(inx, null, 0) ;
	}
    
}//EOC
