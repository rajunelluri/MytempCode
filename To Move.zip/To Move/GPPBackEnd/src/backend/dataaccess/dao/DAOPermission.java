package backend.dataaccess.dao;

import java.sql.Types;

import com.fundtech.core.general.StatementParameter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.dataaccess.dto.DTODataHolder;
import backend.dataaccess.dto.DTOSingleValue;

/*
 * Description: DAO for permission handling 
 * Company:		Fundtech Israel
 * Author:		Yaron Mizrahi
 * Date:		Apr 25, 2005
 */
public class DAOPermission extends DAOBasic
{

  private final static Logger logger = LoggerFactory.getLogger(DAOPermission.class);
  private static final String COMMA_SPACE = ", ";
  private static final String STAR_SPACE = "* ";
  
  private static final String SELECT_STATEMENT_START = "SELECT ";
  
  private static final String SELECT_STATEMENT_GET_ACCS_LVL_ACTIVE_VALUE = "SELECT ACTIVE FROM ACCS_LVL WHERE FIELD_NAME = ?";
  
  /** 
   * 
   */ 
  public DTODataHolder getProfileAccessLevelData()
  {
    final String SELECT_STATEMENT = "SELECT PROFILE_ID, ACCS_LVL FROM PROFILE_CTRL WHERE REC_STATUS = 'AC' ORDER BY PROFILE_ID";
    
    return getData(SELECT_STATEMENT, 0);
  }

  /** 
   * 
   */ 
  public DTODataHolder getTaskAccessLevelData()
  {
    final String SELECT_STATEMENT = "SELECT TASKCODE, ACCS_LVL FROM TASKS ORDER BY TASKCODE";
    
    return getData(SELECT_STATEMENT, 0);
  }
  
  public DTODataHolder getMenuItemsAccessLevelData()
  {
    final String SELECT_STATEMENT = "SELECT ITEM_ID, ACCS_LVL FROM MENU_GENERAL_ITEMS ORDER BY ITEM_ID";
    
    return getData(SELECT_STATEMENT, 0);
  }
  
  
  /** 
   * Returns the value of the ACTIVE column for the passed access level.
   */ 
  public DTOSingleValue getAccessLevel_ACTIVE_Value(String sAccessLevel)
  {
    
    
    StatementParameter[] arrParameters = {new StatementParameter(sAccessLevel, Types.VARCHAR)};
    DTOSingleValue dtoSingleValue = getSingleValue(SELECT_STATEMENT_GET_ACCS_LVL_ACTIVE_VALUE, arrParameters, null);

    
    
    return dtoSingleValue;
  }
}
