package backend.dataaccess.dao;

import static com.fundtech.util.GlobalConstants.EMPTY_STRING;
import static com.fundtech.util.GlobalUtils.isNullOrEmpty;

import java.io.StringReader;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.concurrent.ConcurrentHashMap;

import javax.naming.Context;
import javax.naming.NamingException;
import javax.persistence.Column;
import javax.sql.DataSource;

import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlOptions;
import org.apache.xmlbeans.impl.values.XmlObjectBase;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.core.module.security.businessobjects.UserEntitlementData;
import backend.dataaccess.dto.CallableStatementParameter;
import backend.dataaccess.dto.DTOBasic;
import backend.dataaccess.dto.DTOBoolean;
import backend.dataaccess.dto.DTODataHolder;
import backend.dataaccess.dto.DTODataTable;
import backend.dataaccess.dto.DTOSingleValue;
import backend.mapping.config.AppServerConfigKeysInterface;
import backend.paymentprocess.erroraudit.ErrorAuditUtils;
import backend.services.cache.entitlements.EntitlementsDataFactory;
import backend.staticdata.module.layout.factory.StaticDataProfileFactory;
import backend.util.ServerConstants;
import backend.util.ServerUtils;

import com.fundtech.cache.entities.LogicalFields;
import com.fundtech.cache.infrastructure.misshandlers.CacheMissHandlerInterface.MissValue;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.general.PluginFactory;
import com.fundtech.core.general.StatementParameter;
import com.fundtech.core.paymentprocess.data.das.DASInterface;
import com.fundtech.core.paymentprocess.data.fields.DataType;
import com.fundtech.core.paymentprocess.errorhandling.ProcessError;
import com.fundtech.core.security.Admin;
import com.fundtech.core.security.Admin.CallSource;
import com.fundtech.datacomponent.request.Filter;
import com.fundtech.datacomponent.request.FilterElement;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.datacomponent.response.layout.LayoutConstants;
import com.fundtech.datacomponent.response.selectlist.ColumnMetaData;
import com.fundtech.errors.ProcessErrorConstants;
import com.fundtech.jndi.ServiceLocator;
import com.fundtech.lang.Table;
import com.fundtech.mapping.AbstractConfigProxy;
import com.fundtech.util.BindingParameter;
import com.fundtech.util.ExceptionController;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalDateTimeUtil;
import com.fundtech.util.GlobalUtils;
import com.fundtech.util.MetaDataHolder;


/**
 * Title: DAOBasic date: 05-04-2005 Description: Base class for DAO<module-name> classes. Company: Fundtech Israel
 * 
 * @author Ehud Tavor
 * @version 1.0
 */
public class DAOBasic implements AppServerConfigKeysInterface {

	private final static Logger logger = LoggerFactory.getLogger(DAOBasic.class);

	private static final String SEQ_SQL_SUFFIX = ".NEXTVAL FROM DUAL";
	private static final String SEQ_SQL_PREFIX = "SELECT ";
	// private static final String SEQ_NAME_PREFIX = "SEQ_";

	// Constants.
	final protected static String SPCAE = " ";
	final protected static String PLACE_HOLDER = "?";
	final protected static String OPEN_GROUP = "(";
	final protected static String CLOSE_GROUP = ")";
	final protected static String SEPERATOR = ",";
	final protected static String AND = " AND ";
	final protected static String OR = " OR ";
	final protected static String CONDITION_ALL = "ALL";
	final public static String ORDER_BY = " ORDER BY ";
	final protected static String SELECT = "SELECT ";
	final protected static String FROM = " FROM ";
	final protected static String TRACE_RELEASE_RS = "Failed to release ResultSet";
	final protected static String TRACE_RELEASE_STMT = "Failed to release statement";
	final protected static String TRACE_RELEASE_CON = "Failed to release connection";
	final protected static String STRING_SELECT_STAR_FROM = "SELECT * FROM ";
	final protected static String STRING_WHERE_1_EQUALS_2 = " WHERE 1 = 2";
	// private static final String CONFIG_DATA_SOURCE = "AS_CONFIG.DATABASE.DATA_SOURCE.0";
	private static final String STRING_INSERT_INTO = "INSERT INTO ";
	private static final String STRING_INSERT_VALUES = ") VALUES (";
	private static final String CALLABLE_STATEMENT_SUCCESS = "0";
	private static final String PARAMETER = "PARAMETER";
	protected static final String ROWNUM = " AND ROWNUM <= ";

	private static final String m_sDataSourceActiveName;
	private static final String m_sDataSourceHistoryName;
	private static final String m_sDataSourceReportingName;

	// Constants for select/update statements tracing.
	private static final String STATEMENT_CONTENT_GET_DATA_1 = "DAOBasic.getData(String, int) - select statement content:\n";
	// private static final String STATEMENT_CONTENT_GET_DATAROWS = "DAOBasic.getDataRows(String, int) - select statement content:\n";
	private static final String STATEMENT_CONTENT_GET_DATA_2 = "DAOBasic.getData(String, StatementParameter[], int) - select statement content:\n";
	private static final String STATEMENT_CONTENT_GET_SINGLE_VALUE_1 = "DAOBasic.getSingleValue(String, StatementParameter[], Connection) - select statement content:\n";
	private static final String STATEMENT_CONTENT_GET_SINGLE_VALUE_2 = "DAOBasic.getSingleValue(String, Connection) - select statement content:\n";
	private static final String STATEMENT_CONTENT_DO_UPDATE_VALUE = "DAOBasic.doUpdate() - update statement content:\n";
	private static final String TRACE_DB_TYPE_SET_MSG_TEMPLATE = "Database was identified as {}, using proprietary syntax.";

	/** SQL format for date and time */
	public static final String SQL_FORMAT_DATE_TIME = "YYYY-MM-dd HH24:MI:SS";
	public static final String SQL_FORMAT_TIME_STAMP = "YYYY-MM-dd HH24:MI:SS.FF3";
	protected static final String SQL_FORMAT_DATE = "YYYY-MM-DD";
	protected static final String SQL_FORMAT_TIME = "HH24:MI:SS";
	protected static final String SQL_FORMAT_TIME_NO_SECONDS = "HH24:MI";
	protected static final String SQL_FORMAT_TIME_SECONDS_AND_MILLISECONDS = "HH24:MI.FF3";

	protected static final String DEFAULT_KEYWORD = "default";
	private static final String NULL = "NULL";

	/**
	 * Factory for tables columns types Key: table name, Values: hash map where key: column name, value: SQL type
	 */
	private static Map<String, Map<String, ColumnMetaData>> m_hmColumnMetaData;
	private static Map<String, Method> m_mapJPASetterMethods; 

	// Constant for the max number of rows to be retrieved by a select statement.
	protected static final int MAX_ROW_NUMBER = 1500;

	/**
	 * flag indicating whether to use the reporting db or its failover the active one the flag would be set to true once, on the first name not found
	 * exception for the jndi lookup of the reporting datasource.
	 */
	private static boolean m_bReportingDataSourceNotDefined = false;

	/**
	 * Application server JNDI environment prefix. to be used for all data source lookups
	 */
	private static final String JNDI_ENV_PREFIX = "java:comp/env/";
	/**
	 * Syntax dependent keywords section. The values would be initialised within the static constructor
	 */
	public static String ROWNUM_VARIABLE = "";
	public static String WHERE_CLAUSE_ROW_NUM = "";
	public static String NULL_VALUE = "";

	public static DBType ms_DBType;

	// HashSet which includes stored procedure names for which we don't need to check
	// the return code because it might have different values than '0' for success
	// and '1' for failure.
	private static Set<String> HS_SP_NAMES_NO_RET_CODE_CHECK_REQUIRED = new HashSet<String>();
	private static final String SP_MSG_LOCK = "SP_MSG_LOCK";
	
	//protected static BackendTracer GlobalTracer = GlobalTracer;
	
	protected static final String SYS_TIMESTAMP_COLUMN ; 
	
	protected static final String FORMATTED_SYSTIME_COLUMN ;  
			
	/**
	 * static intialization.
	 */
	static
	{		
		final AbstractConfigProxy configProxy = AbstractConfigProxy.getInstance() ; 
		m_mapJPASetterMethods = new ConcurrentHashMap<String,Method>() ; 
		
		m_sDataSourceActiveName = configProxy.getDatasourceJndiAllias(DATA_SOURCE_ID_ACTIVE);
		//@TODO Remove reporting datasource?
		m_sDataSourceReportingName = configProxy.getDatasourceJndiAllias(DATA_SOURCE_ID_REPORTING);
		//@TODO Remove history datasource?
		m_sDataSourceHistoryName = configProxy.getDatasourceJndiAllias(DATA_SOURCE_ID_HISTORY);

		m_hmColumnMetaData = new HashMap<String, Map<String, ColumnMetaData>>();

		HS_SP_NAMES_NO_RET_CODE_CHECK_REQUIRED.add(SP_MSG_LOCK);

		// Determine the current active database type and configure required
		// system resources to that affect.
		configureDBType(null);
		
		//initialize the timestamp query resources 
		SYS_TIMESTAMP_COLUMN = " ((TRUNC(" + ms_DBType.getCurrentTimestampKeyword() + ") "
			+ "- TO_DATE('1970-01-01','YYYY-MM-DD'))*24*60*60*1000)" + "+ROUND(((" + ms_DBType.getExtractHoursFormat() + "*60*60 "
			+ "+ EXTRACT(MINUTE FROM " + ms_DBType.getCurrentTimestampKeyword() + ")*60 " + "+ EXTRACT(SECOND FROM "
			+ ms_DBType.getCurrentTimestampKeyword() + ")))*1000,0) " ;  
		
		FORMATTED_SYSTIME_COLUMN = " TO_CHAR(" + ms_DBType.getCurrentTimestampKeyword() + ",'" + SQL_FORMAT_TIME_STAMP + "') " ;

		// Define Oracle's type mapping
		// this should be declared so rs.getObject(..) method will return the correct type

		Connection connection = null ; 
		try
		{
			connection = getDataSource().getConnection();
			writeDBMetaData(connection);
			initIdentities(connection, "GPP") ; 
			
			//load the share sql connection proxy into memory, which would cause it to be registed with the shared resources proxy 
			Class.forName("backend.businessobject.sharedresources.proxies.SharedSQLConnectionProxy") ; 
		}catch (Exception e)
		{
			IllegalStateException ise = new IllegalStateException("DAOBasic: Static initialization error");
			ise.initCause(e);
			throw ise;
		}finally { 
			try{ 
				connection.close() ; 
			}catch(Exception e) { 
				IllegalStateException ise = new IllegalStateException("DAOBasic: Static initialization error");
				ise.initCause(e);
				throw ise;
			}//EO catch block 
		}//EO catch block 
		
	}//EO static block 
	
	private static final void initIdentities(final Connection conn, final String sApplicationID) throws SQLException{ 
		PreparedStatement ps = null ;   
		ResultSet rs = null ;
		int iApplicationID;
		int iJVMID;
		String sJVMID = "";
		
		try{ 
			if(Admin.m_appCallsourceContext == CallSource.CacheServer){ 
				//retrieve without counter
				ps = conn.prepareStatement("select value_code from fields_values where field_type = 'APP_ID' and value_descr = ?") ;
				ps .setObject(1, sApplicationID) ; 
				rs = ps.executeQuery() ; 
				rs.next() ; 
				
				iApplicationID = rs.getInt(1) ; 
				sJVMID = "-1"  ;
				GlobalUtils.setApplicationID(iApplicationID) ;
				GlobalUtils.setJVMID(sJVMID) ;			
			}
			else
			{
				//retrieve with counter
				ps = conn.prepareStatement("select value_code, seq_jvm_id.nextval from fields_values where field_type = 'APP_ID' and value_descr = ?") ;
				ps .setObject(1, sApplicationID) ; 
				rs = ps.executeQuery() ; 
				rs.next() ; 
				
				iApplicationID = rs.getInt(1) ; 
				iJVMID = rs.getInt(2)  ;
				GlobalUtils.setApplicationID(iApplicationID) ;
				GlobalUtils.setJVMID(iJVMID) ;
				sJVMID = Integer.toString(iJVMID);
			}
		}
		finally{  
			releaseResources(rs, ps) ;
		}//EO catch block 
		
		logger.info("*****************************************Application[ Name={},ID={},JVM ID={},Context={} ]*****************************************", 
				new Object[]{sApplicationID, 
				iApplicationID, 
				sJVMID,Admin.m_appCallsourceContext.name()}) ; 
	}//EOM

	/**
	 * @param connection
	 * @throws SQLException
	 */
	private static void writeDBMetaData(Connection connection) throws SQLException {
		final String DB_NAME_SELECT = " SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI')  as  sys_date  FROM dual";
		Statement statement = connection.createStatement();
		ResultSet rs = statement.executeQuery(DB_NAME_SELECT);
		rs.next();
		Date dDBDate = GlobalDateTimeUtil.string2date(rs.getString(1));
		writeServerDBTimeDiff(dDBDate);
		writeWebDBConnectionData(connection);
	}

	/**
	 * @param connection
	 * @throws SQLException
	 */
	public static void writeWebDBConnectionData(Connection connection) throws SQLException {
		final String TRACE_WORKING_DB = "*****************************\nWorking DB is:\nHost: {}\nSID: {}\nUser/Scheama: {}\nVersion: {}\n*****************************";
		DatabaseMetaData dbMetaData = connection.getMetaData();
		String sSid = getData(ms_DBType.getSID(),connection);
		String sHost =getData(ms_DBType.getHostName(),connection);
		String sUserSchemaName =getData(ms_DBType.getSchemaOrUser(),connection);
		logger.info(TRACE_WORKING_DB, new Object[]{sHost, sSid, sUserSchemaName, dbMetaData.getDatabaseProductVersion()});
	}
	
	private static String getData(String select, Connection connection) throws SQLException {
		Statement stmnt = null ;  
		ResultSet rs = null ;
		try{ 
			stmnt = connection.createStatement() ;
			rs = stmnt.executeQuery(select);
			boolean isResultExists = rs.next();
			return  isResultExists ? rs.getString(1) : EMPTY_STRING;
		}finally{ 
			
			try{
				stmnt.close();
			}catch(Exception e){
				logger.error(e.getMessage());
			}//EOM
			
			try{
				rs.close() ; 
			}catch(Exception e){
				logger.error(e.getMessage());
			}//EOM
		}//EO catch block 
	}//EOM 

	/**
	 * @param date
	 * @return
	 */
	private static void writeServerDBTimeDiff(Date dDBDate) {
		Calendar cServerCal = Calendar.getInstance();
		Calendar cDBCal = Calendar.getInstance();
		cDBCal.setTime(dDBDate);
		int iHoursDiff = cServerCal.get(Calendar.HOUR_OF_DAY) - cDBCal.get(Calendar.HOUR_OF_DAY);
		int iMinutesDiff = cServerCal.get(Calendar.MINUTE) - cDBCal.get(Calendar.MINUTE);
		logger.info("**The offset of the trace files compared with the DB is: {} hours and {} minutes **", iHoursDiff, iMinutesDiff);

	}

	/**
	 * Nov 26, 2007 guys Singleton method which determines the application's database type<br>
	 * and sets it in the ms_DBType.<br>
	 * Defaults to Oracle in case of an error.
	 * 
	 * @param explicitDBType An explicit DBType which should be used as the system wide database type.
	 */
	private static final void configureDBType(final DBType explicitDBType) {
		// get the data source and create a connection off of it
		Connection connection = null;
		try
		{
			if (explicitDBType == null)
			{

				DataSource source = getDataSource();
				connection = source.getConnection();
				ms_DBType = DBType.parse(connection.getMetaData().getDatabaseProductName());

			}
			else
			{
				ms_DBType = explicitDBType;
			}// EO if the explicitDBType is not null
		}
		catch (Throwable e)
		{
			// set the current db type as an oracle default
			ms_DBType = DBType.Oracle;
			ExceptionController.getInstance().handleException(e, null);

		}
		finally
		{
			try
			{
				if (connection != null) connection.close();
			}
			catch (Throwable e)
			{
				ExceptionController.getInstance().handleException(e, null);
			}// EO catch block

			// set the syntax specific keywords here
			ROWNUM_VARIABLE = ms_DBType.getRowNumValue();
			NULL_VALUE = ms_DBType.getNullValue();

			logger.debug(TRACE_DB_TYPE_SET_MSG_TEMPLATE, ms_DBType);
			GlobalConstants.setDbType(ms_DBType);
		}// EO catch block
	}// EOM

	private static DataSource getDataSource() throws NamingException {
		DataSource source;
		final Context context = ServiceLocator.getInstance().getContext();
		try
		{
			source = (DataSource) context.lookup(m_sDataSourceActiveName);
		}
		catch (Exception e)
		{
			source = (DataSource) context.lookup(JNDI_ENV_PREFIX + m_sDataSourceActiveName);
		}// EO catch block
		return source;
	}
	/**
	 * Constractor.
	 */
	public DAOBasic(){
		
	}

	/**
	 * @param rsmd
	 * @param sProfileID
	 * @return HashMap where key: column name, Value: SQL type
	 */
	private Map<String, ColumnMetaData> createColumnMetaDataHM(ResultSetMetaData rsmd, String sTableName) {
		int i = 0;
		Map<String, ColumnMetaData> hmRetVal = new HashMap<String, ColumnMetaData>();

		try
		{
			for (i = 1; i <= rsmd.getColumnCount(); i++)
			{
				String sColumnName = rsmd.getColumnName(i);

				int iColumnType = rsmd.getColumnType(i);

				int iColumnSize = (iColumnType == Types.NUMERIC || iColumnType == Types.DECIMAL || iColumnType == Types.INTEGER || iColumnType == Types.SMALLINT) ? rsmd
						.getPrecision(i)
						: rsmd.getColumnDisplaySize(i);

				hmRetVal.put(rsmd.getColumnName(i), new ColumnMetaData(sColumnName, iColumnType, iColumnSize));
			}
		}
		catch (Exception e)
		{
			ExceptionController.getInstance().handleException(e, this);
		}

		return hmRetVal;
	}

	/**
	 * @param sProfileID
	 * @return a hash table with column name and column type combination for specific profile ID.
	 */
	public Map<String, ColumnMetaData> getColumnsMetaDataHM(String sTableName, Connection conn) {
		// Try to get it from the factory first
		Map<String, ColumnMetaData> hmRetVal = m_hmColumnMetaData.get(sTableName);

		if (hmRetVal == null)
		{ // Is not found in the factory
			hmRetVal = createColumnMetaDataHM(sTableName, conn);

			synchronized (m_hmColumnMetaData)
			{
				m_hmColumnMetaData.put(sTableName, hmRetVal);
			}

			// Updates the parallel HashMap in the SelectListColumn class.
			MetaDataHolder.setTableToColumnsMetaDataHM(m_hmColumnMetaData);
		}

		return hmRetVal;
	}

	/**
	 * @param sProfileID
	 * @return a hash table with column name and column type combination for specific profile ID.
	 */
	public Map<String, ColumnMetaData> getColumnsMetaDataHM(String sTableName) {
		return getColumnsMetaDataHM(sTableName, null);
	}

	/**
     * 
     */
	public static boolean refreshDBColumnsMetaDataHM() {
		m_hmColumnMetaData.clear();
		return true;
	}

	/**
	 * @param sProfileID
	 * @return result set meta data per profile id
	 */
	private Map<String, ColumnMetaData> createColumnMetaDataHM(String sTableName, Connection con) {
		final String METHOD_NAME = "createColumnMetaDataHM() -";

		ResultSetMetaData rsmd = null;
		ResultSet rs = null;
		Statement statement = null;
		Map<String, ColumnMetaData> hmRetVal = null;

		StringBuffer sbStatement = new StringBuffer(STRING_SELECT_STAR_FROM).append(sTableName).append(STRING_WHERE_1_EQUALS_2);
		try
		{
			con = con == null ? getConnection() : con;
			statement = con.createStatement();
			rs = statement.executeQuery(sbStatement.toString());
			rsmd = rs.getMetaData();

			hmRetVal = createColumnMetaDataHM(rsmd, sTableName);
		}
		catch (Exception e)
		{
			logger.error(METHOD_NAME + e.getMessage());
			logger.info(e.getMessage());
		}
		finally
		{
			releaseResources(rs, statement, con);
		}

		return hmRetVal;
	}

	/**
	 * Gets a profile ID & column name & returns whether this column exists in the master table of this profile ID.
	 * 
	 * @param sProfileID the profile ID.
	 * @param sColumnName the column name.
	 * @return returns whether this column exists in the master table of this profile ID.
	 */
	public boolean columnExistsInTable(String sProfileID, String sColumnName) {
		String sMasterTable = StaticDataProfileFactory.getInstance().getProfile(sProfileID).getMasterTable();

		Map<String, ColumnMetaData> hmColumnsMetaData = getColumnsMetaDataHM(sMasterTable);

		return hmColumnsMetaData.get(sColumnName) != null;
	}

	/**
	 * Create and returns a Connection reference with set auto commit flag set to 'true'.
	 * 
	 * @param sDataSourceID data source ID according to the ones defined in the app-server-config.xml file; currently, we have: active, history &
	 *            reporting.
	 * @return returns a Connection reference with set auto commit flag set to 'true'.
	 */
	public Connection getConnection(String sDataSourceID) throws SQLException {
		DataSource ds = null;
		final Admin admin = Admin.getContextAdmin(); 
		boolean bSupportsSharedResource = (admin != null && admin.supportsSharedResources()) ; 
		
		//Guys --> disabled for now 
		//bSupportsSharedResource = false ;
		
		try
		{
			// This setting will work when there IS NO definition of
			// '@ejb.resource-ref jndi-name' element in the bean classes,
			// (See SecurityBean for example).
			// ds = (DataSource)m_context.lookup(sDataSourceName);

			// This setting will work when there IS definition of
			// '@ejb.resource-ref jndi-name' element in the bean classes,
			// (See SecurityBean for example).
			// The JNDI_ENV_PREFIX is actually "java:comp/env/".
			
			if(bSupportsSharedResource) { 
				//attempt to retrieve the shared resource from the admin 
				final Connection conn = admin.sharedResLookup(sDataSourceID, Connection.class) ;
				if(conn != null) { 
					//TODO: add traces 
					return conn ;
				}//EO if connection was already cached 
			}//EO if supports resources 
			
			
			// ACTIVE.
			if (DATA_SOURCE_ID_ACTIVE.equals(sDataSourceID))
			{
				ds = ServiceLocator.getInstance().dbDatasourceLookup(JNDI_ENV_PREFIX + m_sDataSourceActiveName);
			}

			// HISTORY.
			else if (DATA_SOURCE_ID_HISTORY.equals(sDataSourceID))
			{
				ds = ServiceLocator.getInstance().dbDatasourceLookup(JNDI_ENV_PREFIX + m_sDataSourceHistoryName);
			}

			// REPORTING.
			else if (DATA_SOURCE_ID_REPORTING.equals(sDataSourceID))
			{
				System.out.println("Tries getting REPORTING data source !!!");
				// If REPORTING database isn't defined than we use the ACTIVE one.
				ds = m_bReportingDataSourceNotDefined ? ServiceLocator.getInstance().dbDatasourceLookup(JNDI_ENV_PREFIX + m_sDataSourceActiveName)
						: ServiceLocator.getInstance().dbDatasourceLookup(JNDI_ENV_PREFIX + m_sDataSourceReportingName);
			}
		}
		catch (NamingException ne)
		{
			final String TRACE_CANNOT_LOCATE_DATA_SOURCE_ERROR_PREFIX = " ERROR: Can't locate the following data source: ";
			final String TRACE_REPORTING_DATA_SOURCE_FAILOVER_MESSAGE = "; switches to ACTIVE data source; REPORTING data source won't be used till next application startup !!!";

			StringBuilder sbTraceMessage = new StringBuilder(TRACE_CANNOT_LOCATE_DATA_SOURCE_ERROR_PREFIX).append(sDataSourceID);

			// This is the REPORTING database; switches to the ACTIVE one.
			if (DATA_SOURCE_ID_REPORTING.equals(sDataSourceID))
			{
				sbTraceMessage.append(TRACE_REPORTING_DATA_SOURCE_FAILOVER_MESSAGE);
				logger.warn(sbTraceMessage.toString());

				// Sets this flag to true, so no future attempts to get REPORTING data
				// source won't be done.
				m_bReportingDataSourceNotDefined = true;

				try
				{
					ds = ServiceLocator.getInstance().dbDatasourceLookup(JNDI_ENV_PREFIX + m_sDataSourceActiveName);
				}
				catch (NamingException e)
				{
					throw new SQLException(sbTraceMessage.toString()+": "+e.toString());
				}
			}

			else
			{
				throw new SQLException(sbTraceMessage.toString()+": "+ne.toString());
			}
		}

		final Connection conn = ds.getConnection(); 

		//if the admin supports shared resource, add the connection to the flow resources 
		if(bSupportsSharedResource) 
			{
			admin.registerSharedRes(sDataSourceID, conn) ; 
			}
		return conn ;
	}

	/**
	 * Create and returns a Connection reference with set auto commit flag set to 'true'.
	 * 
	 * @return returns a Connection reference with set auto commit flag set to 'true'.
	 */
	public Connection getConnection() throws SQLException {
		return getConnection(DATA_SOURCE_ID_ACTIVE);
	}

	/**
	 * Create and returns a Connection reference with set auto commit flag set to 'false'.
	 * 
	 * @param sDataSourceID data source ID according to the ones defined in the app-server-config.xml file; currently, we have: active, history &
	 *            reporting.
	 * @return returns a Connection reference with set auto commit flag set to 'false'.
	 */
	public Connection getConnectionWithFalseAutoCommit(String sDataSourceID) throws SQLException {
		Connection con = getConnection(sDataSourceID);
		con.setAutoCommit(false);

		return con;
	}
	
	public static final void releaseResources(Object... closableResources) {
		ServiceLocator.releaseResources(closableResources) ; 
	}// EOM

	/**
	 * releases the resources used by the DAO.
	 * 
	 * @return void.
	 * @param rs - ResultSet reference.
	 * @param statement - Statement reference.
	 * @param con - Connection reference.
	 */
	public void releaseResources(ResultSet rs, Statement statement, Connection con) {
		/* release the ResultSet */
		if (rs != null)
		{
			try
			{
				rs.close();
			}
			catch (SQLException sqle)
			{
				logger.info(TRACE_RELEASE_RS);
				logger.error(TRACE_RELEASE_RS);
			}
		}

		/* release the Statement */
		if (statement != null)
		{
			try
			{
				statement.close();
			}
			catch (SQLException sqle)
			{
				logger.info(TRACE_RELEASE_STMT);
				logger.error(TRACE_RELEASE_STMT);
			}
		}

		/* release the Connection */
		if (con != null)
		{
			try
			{
				con.close();
			}
			catch (SQLException sqle)
			{
				logger.info(TRACE_RELEASE_CON);
				logger.error(TRACE_RELEASE_CON);
			}
		}
	}

	/**
	 * This method adds the " AND ROWNUM <= ?" part to select statement.
	 * 
	 * @param sSelectStatement - SELECT statement to be executed.
	 * @param iNumOfRows - Limit the number of rows the query returns.
	 * @param bArrParams - boolean to indicate if statement contains parameters
	 * @return - Edited SELECT statement to be executed including filter by row num.
	 */
	private String addRowNumToSelectStatement(String sSelectStatement, int iNumOfRows, boolean bArrParams) {
		StringBuffer sbSelectStatement = new StringBuffer();

		if (iNumOfRows != -1)
		{
			int iIndexOrderBy = sSelectStatement.indexOf(ORDER_BY);
			String sWherePart = sSelectStatement;
			String sOrderByPart = ServerConstants.EMPTY_STRING;

			// We have 'ORDER BY' part.
			if (iIndexOrderBy > -1)
			{
				sWherePart = sSelectStatement.substring(0, iIndexOrderBy).trim();
				sOrderByPart = sSelectStatement.substring(iIndexOrderBy).trim();
			}

			// defer to the given DBType Enum for the current ROWNUM syntax
			sbSelectStatement.append(ms_DBType.configureRownumFilter(sWherePart, sOrderByPart, iNumOfRows, bArrParams));
		}

		else
		{
			sbSelectStatement = new StringBuffer(sSelectStatement);
		}

		return sbSelectStatement.toString();
	}

	/**
	 * Gets data from the database using the PreparedStatement interface in order to access the DB, which means that the SELECT statement it gets as
	 * input is not aware yet to the parameters values. The PreparedStatement is bind to its variables and only then executed. This method should be
	 * used only when executing a request which is used often, because the Statement is compiled by the server once and kept in cache for next calls.
	 * 
	 * @param sDataSourceID data source ID, (i.e. active, history or reporting).
	 * @param sSelectStatement SELECT statement to be executed.
	 * @param iNumOfRows number of rows to retrieve.
	 */
	public DTODataHolder getData(String sDataSourceID, String sSelectStatement, int iNumOfRows) {
		return getData(null, sDataSourceID, sSelectStatement, iNumOfRows);
	}

	/**
	 * Gets data from the database using the PreparedStatement interface in order to access the DB, which means that the SELECT statement it gets as
	 * input is not aware yet to the parameters values. The PreparedStatement is bind to its variables and only then executed. This method should be
	 * used only when executing a request which is used often, because the Statement is compiled by the server once and kept in cache for next calls.
	 * @param sDataSourceID data source ID, (i.e. active, history or reporting).
	 * @param sSelectStatement SELECT statement to be executed.
	 * @param iNumOfRows number of rows to retrieve.
	 */
	public DTODataHolder getData(Connection conn, String sDataSourceID, String sSelectStatement, int iNumOfRows) {
		DTODataHolder reply = new DTODataHolder();
		Connection finalConn = null;
		Statement statement = null;
		ResultSet rs = null;

		try
		{
			finalConn = conn != null ? conn : getConnection(sDataSourceID);

			// Add ROWNUM to statement if relevant.
			if (iNumOfRows > 0)
			{
				sSelectStatement = addRowNumToSelectStatement(sSelectStatement, iNumOfRows, false);
			}

			// Tracing.
			String sStatementTrace = new StringBuffer(STATEMENT_CONTENT_GET_DATA_1).append(sSelectStatement).toString();

			logger.debug(sStatementTrace);

			statement = finalConn.createStatement();
			rs = executeStaticQuery(statement, sSelectStatement);
			populateDataHolderDTO(reply, rs);
		}
		catch (SQLException sqle)
		{
			setExceptionFeedbackObject(reply, sqle);
		}
		finally
		{
			releaseResources(rs, statement, conn != null ? null : finalConn);
		}

		return reply;
	}

	/**
	 * Gets data from the database using the PreparedStatement interface in order to access the DB, which means that the SELECT statement it gets as
	 * input is not aware yet to the parameters values. The PreparedStatement is bind to its variables and only then executed. This method should be
	 * used only when executing a request which is used often, because the Statement is compiled by the server once and kept in cache for next calls.
	 * 
	 * @param conn Connection object - can be null.
	 * @param sSelectStatement SELECT statement to be executed.
	 * @param iNumOfRows number of rows to retrieve.
	 */
	public DTODataHolder getData(Connection conn, String sSelectStatement, int iNumOfRows) {
		String sDataSourceID = conn != null ? ServerConstants.EMPTY_STRING : DATA_SOURCE_ID_ACTIVE;
		return getData(conn, sDataSourceID, sSelectStatement, iNumOfRows);
	}

	/**
	 * Gets data from the database using the PreparedStatement interface in order to access the DB, which means that the SELECT statement it gets as
	 * input is not aware yet to the parameters values. The PreparedStatement is bind to its variables and only then executed. This method should be
	 * used only when executing a request which is used often, because the Statement is compiled by the server once and kept in cache for next calls.
	 * 
	 * @param sSelectStatement SELECT statement to be executed.
	 * @param iNumOfRows number of rows to retrieve.
	 */
	public DTODataHolder getData(String sSelectStatement, int iNumOfRows) {
		return getData(null, DATA_SOURCE_ID_ACTIVE, sSelectStatement, iNumOfRows);
	}

	/**
	 * Gets data from the database using the PreparedStatement interface in order to access the DB, which means that the SELECT statement it gets as
	 * input is not aware yet to the parameters values. The PreparedStatement is bind to its variables and only then executed. This method should be
	 * used only when executing a request which is used often, because the Statement is compiled by the server once and kept in cache for next calls.
	 * 
	 * @param sDataSourceID data source ID, (i.e. active, history or reporting).
	 * @param sSelectStatement SELECT statement to be executed.
	 * @param iNumOfRows number of rows to retrieve.
	 * @param arrarrParameters parameters which will be bind to the PreparedStatement.
	 */
	public DTODataHolder getData(String sDataSourceID, String sSelectStatement, StatementParameter[] arrParameters, int iNumOfRows) {
		return getData(null, sDataSourceID, sSelectStatement, arrParameters, iNumOfRows);
	}

	/**
	 * Gets data from the database using the PreparedStatement interface in order to access the DB, which means that the SELECT statement it gets as
	 * input is not aware yet to the parameters values. The PreparedStatement is bind to its variables and only then executed. This method should be
	 * used only when executing a request which is used often, because the Statement is compiled by the server once and kept in cache for next calls.
	 * 
	 * @param conn Connection object - can be null.
	 * @param sSelectStatement SELECT statement to be executed.
	 * @param arrarrParameters parameters which will be bind to the PreparedStatement.
	 */
	public DTODataHolder getData(Connection conn, String sSelectStatement, StatementParameter... parameters) {
		String sDataSourceID = conn != null ? ServerConstants.EMPTY_STRING : DATA_SOURCE_ID_ACTIVE;
		return getData(conn, sDataSourceID, sSelectStatement, parameters, 0);
	}

	/**
	 * Gets data from the database using the PreparedStatement interface in order to access the DB, which means that the SELECT statement it gets as
	 * input is not aware yet to the parameters values. The PreparedStatement is bind to its variables and only then executed. This method should be
	 * used only when executing a request which is used often, because the Statement is compiled by the server once and kept in cache for next calls.
	 * 
	 * @param conn Connection object - can be null.
	 * @param sDataSourceID data source ID, (i.e. active, history or reporting).
	 * @param sSelectStatement SELECT statement to be executed.
	 * @param iNumOfRows number of rows to retrieve.
	 * @param arrarrParameters parameters which will be bind to the PreparedStatement.
	 */
	public DTODataHolder getData(Connection conn, String sDataSourceID, String sSelectStatement, StatementParameter[] arrParameters, int iNumOfRows) {

		sDataSourceID = conn != null ? ServerConstants.EMPTY_STRING : DATA_SOURCE_ID_ACTIVE;
		DTODataHolder reply = new DTODataHolder();

		
		Connection finalConn = null;
		PreparedStatement statement = null;
		ResultSet rs = null;

		// No need to add ROWNUM.
		if (iNumOfRows != -1)
		{
			if (iNumOfRows == 0)
			{
				iNumOfRows = MAX_ROW_NUMBER;
			}

			// Add rownum to the select statement.
			sSelectStatement = addRowNumToSelectStatement(sSelectStatement, iNumOfRows, true);

			if (ms_DBType.rownumBindingSupport())
			{

				StatementParameter[] arrFinalParameters = null;
				int iRowNumParamIndex = -1;

				if (arrParameters != null)
				{
					iRowNumParamIndex = arrParameters.length;
					arrFinalParameters = new StatementParameter[arrParameters.length + 1];
					System.arraycopy(arrParameters, 0, arrFinalParameters, 0, arrParameters.length);
				}
				else
				{
					iRowNumParamIndex = 0;
					arrFinalParameters = new StatementParameter[1];
				}// EO else if the arrParameters was null

				arrFinalParameters[iRowNumParamIndex] = new StatementParameter(Integer.valueOf(iNumOfRows), java.sql.Types.NUMERIC);
				arrParameters = arrFinalParameters;
			}// EO if the database type supports row num parameter binding
		}

		try
		{
			finalConn = conn != null ? conn : getConnection(sDataSourceID);

			if (logger.isDebugEnabled())
			{
				logger.debug("{}{}", STATEMENT_CONTENT_GET_DATA_2, ServerUtils.getPreparedStatementFinalString(sSelectStatement, arrParameters));
			}
			
			statement = finalConn.prepareStatement(sSelectStatement);
			populatePreparedStatement(statement, arrParameters);
			rs = executeQuery(statement);
			populateDataHolderDTO(reply, rs);
		}
		catch (SQLException sqle)
		{
			setExceptionFeedbackObject(reply, sqle);
		}
		finally
		{
			releaseResources(rs, statement, conn != null ? null : finalConn);
		}

		return reply;
	}

	/**
	 * Gets data from the database using the PreparedStatement interface in order to access the DB, which means that the SELECT statement it gets as
	 * input is not aware yet to the parameters values. The PreparedStatement is bind to its variables and only then executed. This method should be
	 * used only when executing a request which is used often, because the Statement is compiled by the server once and kept in cache for next calls.
	 * 
	 * @param sSelectStatement SELECT statement to be executed.
	 * @param arrarrParameters parameters which will be bind to the PreparedStatement.
	 * @param iNumOfRows number of rows to retrieve.
	 */
	public DTODataHolder getData(String sSelectStatement, StatementParameter[] arrParameters, int iNumOfRows) {
		return getData(DATA_SOURCE_ID_ACTIVE, sSelectStatement, arrParameters, iNumOfRows);
	}

	/**
	 * Gets data from the database using the PreparedStatement interface in order to access the DB, which means that the SELECT statement it gets as
	 * input is not aware yet to the parameters values. The PreparedStatement is bind to its variables and only then executed. This method should be
	 * used only when executing a request which is used often, because the Statement is compiled by the server once and kept in cache for next calls.
	 * 
	 * @param sSelectStatement - SELECT statement to be executed.
	 * @param arrarrParameters parameters which will be bind to the PreparedStatement.
	 */
	public DTODataHolder getData(String sSelectStatement, StatementParameter... arrParameters) {
		return getData(sSelectStatement, arrParameters, 0);
	}

	public DTODataTable getDataTable(String sSelectStatement, StatementParameter[] arrParameters, int iNumOfRows) {
		DTODataTable resultTable = null;
		Connection con = null;
		PreparedStatement statement = null;
		ResultSet rs = null;

		// Add rownum to the select statement.
		if (iNumOfRows != 0)
		{
			sSelectStatement = addRowNumToSelectStatement(sSelectStatement, iNumOfRows, true);

			// As the DB2's driver does not support parameter binding
			// a check must be performed prior to binding the rownum
			if (ms_DBType.rownumBindingSupport())
			{
				StatementParameter[] arrFinalParameters = new StatementParameter[arrParameters.length + 1];

				System.arraycopy(arrParameters, 0, arrFinalParameters, 0, arrParameters.length);

				arrFinalParameters[arrParameters.length] = new StatementParameter(Integer.valueOf(iNumOfRows), java.sql.Types.NUMERIC);
				arrParameters = arrFinalParameters;
			}// EO if the database type supports row num parameter binding
		}

		try
		{
			con = getConnection();

			// Tracing.
			String sTraceSelectStatement = ServerUtils.getPreparedStatementFinalString(sSelectStatement, arrParameters);
			sTraceSelectStatement = new StringBuffer(STATEMENT_CONTENT_GET_DATA_2).append(sTraceSelectStatement).toString();
			logger.info(sTraceSelectStatement);

			statement = con.prepareStatement(sSelectStatement);
			populatePreparedStatement(statement, arrParameters);
			rs = executeQuery(statement);

			// populateDataHolderDTO(reply, rs);
			resultTable = populateDataTable(rs);
			resultTable.getTable().moveFirst();
		}
		catch (SQLException sqle)
		{
			setExceptionFeedbackObject(resultTable, sqle);
		}
		finally
		{
			releaseResources(rs, statement, con);
		}

		return resultTable;
	}

	/**
	 * Gets a single value from the database using the PreparedStatement interface in order to access the DB, which means that the SELECT statement it
	 * gets as input is not aware yet to the parameters values. The PreparedStatement is bind to its variables and only then executed. This method
	 * should be used only when executing a request which is used often, because the Statement is compiled by the server once and kept in cache for
	 * next calls.
	 * 
	 * @param sSelectStatement SELECT statement to be executed.
	 * @param arrParameters array of parameters to be bind into the select statement.
	 * @param conn Connection object, can be null.
	 */
	public DTOSingleValue getSingleValue(String sSelectStatement, StatementParameter[] arrParameters, Connection conn) {
		DTOSingleValue dtoSingleValue = new DTOSingleValue();
		PreparedStatement psStatement = null;
		ResultSet rs = null;
		Connection coActual = null;
		if (arrParameters == null)
		{
			arrParameters = new StatementParameter[0];
		}

		try
		{
			coActual = conn != null ? conn : getConnection();

			if (logger.isDebugEnabled())
			{
				String sTraceSelectStatement = ServerUtils.getPreparedStatementFinalString(sSelectStatement, arrParameters);

				logger.debug("{}{}",STATEMENT_CONTENT_GET_SINGLE_VALUE_1, sTraceSelectStatement );
			}

			psStatement = coActual.prepareStatement(sSelectStatement);
			populatePreparedStatement(psStatement, arrParameters);
			rs = executeQuery(psStatement);
			populateDTO(dtoSingleValue, rs);
		}
		catch (SQLException sqle)
		{
			setExceptionFeedbackObject(dtoSingleValue, sqle);
		}
		finally
		{
			// Release a connection only if created it localy.
			Connection coRelease = conn == null ? coActual : null;
			releaseResources(rs, psStatement, coRelease);
		}

		return dtoSingleValue;
	}

	/**
	 * Gets a single value from the database using the PreparedStatement interface in order to access the DB, which means that the SELECT statement it
	 * gets as input is not aware yet to the parameters values. The PreparedStatement is bind to its variables and only then executed. This method
	 * should be used only when executing a request which is used often, because the Statement is compiled by the server once and kept in cache for
	 * next calls.
	 * 
	 * @param sSelectStatement SELECT statement to be executed.
	 * @param conn Connection object, can be null.
	 */
	public DTOSingleValue getSingleValue(String sSelectStatement, Connection con) {
		DTOSingleValue dtoSingleValue = new DTOSingleValue();
		Connection coActual = null;
		Statement statement = null;
		ResultSet rs = null;

		try
		{
			coActual = con != null ? con : getConnection();

			statement = coActual.createStatement();


			logger.debug("{}{}",STATEMENT_CONTENT_GET_SINGLE_VALUE_2 , sSelectStatement );


			rs = statement.executeQuery(sSelectStatement);

			populateDTO(dtoSingleValue, rs);
		}
		catch (Exception e)
		{
			setExceptionFeedbackObject(dtoSingleValue, e);
		}
		finally
		{
			// Release a connection only if created it localy.
			Connection coRelease = con == null ? coActual : null;
			releaseResources(rs, statement, coRelease);
		}

		return dtoSingleValue;
	}

	/**
	 * Populated the preparedStatement with the input parameters.
	 * 
	 * @return void.
	 * @param statement - PreparedStatement reference.
	 * @param arrParameters parameters which will be bind to the PreparedStatement.
	 */
	protected void populatePreparedStatement(PreparedStatement statement, StatementParameter... parameters) {
		if (parameters == null) return;
		for (int i = 0; i < parameters.length; i++)
		{
			try
			{
				if (parameters[i].getTargetSqlType() == Types.DATE || parameters[i].getTargetSqlType() == Types.TIMESTAMP) {
					java.sql.Date d = null;
					if (parameters[i].getParameterObject() != null){
						d =  new java.sql.Date(((java.util.Date)parameters[i].getParameterObject()).getTime());
					}
					statement.setObject(i + 1 , d , parameters[i].getTargetSqlType());
				}
				else statement.setObject(i + 1, parameters[i].getParameterObject(), parameters[i].getTargetSqlType());
			}
			catch (Exception e)
			{
				try {
					statement.setObject(i , parameters[i].getParameterObject(), parameters[i].getTargetSqlType());
					return;
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
				}
				ExceptionController.getInstance().handleException(e, this);
			}
		}
	}

	/**
	 * Populated the preparedStatement with the input parameters replace APOSTROPHE with DOUBLE_APOSTROPHE.
	 * 
	 * @return void.
	 * @param statement - PreparedStatement reference.
	 * @param arrParameters parameters which will be bind to the PreparedStatement.
	 */
	protected void populatePreparedStatementForUpdate(PreparedStatement statement, StatementParameter... arrParameters) throws SQLException {
		final int iStartBindingIndex = 0;
		this.populatePreparedStatementForUpdate(statement, iStartBindingIndex, arrParameters);
	}// EOM

	/**
	 * Populated the preparedStatement with the input parameters replace APOSTROPHE with DOUBLE_APOSTROPHE.
	 * 
	 * @return void.
	 * @param statement - PreparedStatement reference.
	 * @param iStartBindingIndex = starting index (java oriented not jdbc (i.e. starting from 0 not 1) from which to commence populating the binding
	 *            parameters
	 * @param arrParameters parameters which will be bind to the PreparedStatement.
	 */
	protected void populatePreparedStatementForUpdate(PreparedStatement statement, int iStartBindingIndex, StatementParameter... arrParameters) {
		// initiali incrementation to bring it to the jdbc required first index value
		iStartBindingIndex++;
		// guard condition
		if (arrParameters == null) return;

		for (int i = 0; i < arrParameters.length; i++, iStartBindingIndex++)
		{
			Object oNewValue = arrParameters[i].getParameterObject();
			// Special handling for CLOB types.
			try
			{
				if (arrParameters[i].getTargetSqlType() == Types.CLOB)
				{
					String sNewValue = (String) oNewValue;
					StringReader reader = new StringReader(sNewValue);
					statement.setCharacterStream(iStartBindingIndex, reader, sNewValue.length());
				}
				else if (arrParameters[i].getTargetSqlType() == Types.VARBINARY)
				{
					String sNewValue = (String) oNewValue;
					statement.setBytes(iStartBindingIndex, sNewValue.getBytes());
				}
				else
				// No need for that in case of CLOB types !!!
				// if(parameters[i].getTargetSqlType() != Types.CLOB)
				{
					statement.setObject(iStartBindingIndex, oNewValue, arrParameters[i].getTargetSqlType());
				}
			}
			catch (Exception e)
			{
				ExceptionController.getInstance().handleException(e, this);
			}
		}
	}

	/**
	 * Executes the query for a PreparedStatement and creates the ResultSet.
	 * 
	 * @return ResultSet.
	 * @param statement - PreparedStatement reference.
	 */
	protected ResultSet executeQuery(PreparedStatement statement) throws SQLException {
		ResultSet rs = null;

		rs = statement.executeQuery();

		return rs;
	}

	/**
	 * Executes the query for a Statement and creates the ResultSet.
	 * 
	 * @return ResultSet.
	 * @param statement - PreparedStatement reference.
	 * @param query - String that holds the query statement.
	 */
	protected ResultSet executeStaticQuery(Statement statement, String query) throws SQLException {
		ResultSet rs = null;

		rs = statement.executeQuery(query);

		return rs;
	}

	/**
	 * Executes the query for a PreparedStatement and creates the ResultSet.
	 * 
	 * @return ResultSet.
	 * @param statement - PreparedStatement reference.
	 */
	protected int executeUpdate(PreparedStatement statement) throws SQLException {
		int iRetVal;

		iRetVal = statement.executeUpdate();

		return iRetVal;
	}

	/**
	 * Populates a DTO from the ResultSet
	 * 
	 * @return void.
	 * @param reply - a DTO
	 * @param rs - A populated ResultSet.
	 */
	protected void populateDataHolderDTO(DTODataHolder reply, ResultSet rs) throws SQLException {
		HashMap<String, Object> hmDataRow = new HashMap<String, Object>();
		ResultSetMetaData rsmd = rs.getMetaData();

		int iColumnCount = rsmd.getColumnCount();
		Object oColumnValue;
		
		while (rs.next())
		{
			for (int i = 1; i <= iColumnCount; i++)
			{
				oColumnValue = getColumnValue(i, rs, rsmd);
				hmDataRow.put(rsmd.getColumnLabel(i), oColumnValue);
			}
			reply.addDataRow(hmDataRow);

			hmDataRow = new HashMap<String, Object>();
		}
	}

	/**
	 * Populates a DTOTable from the ResultSet
	 * 
	 * @return void.
	 * @param targetTabe - a DTOTable
	 * @param rs - A populated ResultSet.
	 */
	protected DTODataTable populateDataTable(ResultSet rs) throws SQLException {
		DTODataTable dtoTable = null;
		HashMap<String, Object[]> hmFieldsIndex = new HashMap<String, Object[]>();
		ResultSetMetaData rsmd = rs.getMetaData();
		int iColumnCount = rsmd.getColumnCount();
		Object oColumnValue;
		Table table = new Table(iColumnCount);
		Object[] arrFieldsInfo = new Object[4];
		try
		{
			while (rs.next())
			{
				table.addNew();
				for (int i = 1; i <= iColumnCount; i++)
				{
					oColumnValue = getColumnValue(i, rs, rsmd);
					if (table.getRowCount() == 1)
					{
						arrFieldsInfo[DTODataTable.FIELD_INDEX] = Integer.valueOf(i - 1);
						arrFieldsInfo[DTODataTable.FIELD_TYPE] = Integer.valueOf(rsmd.getColumnType(i));
						arrFieldsInfo[DTODataTable.FIELD_SIZE] = Integer.valueOf(rsmd.getColumnDisplaySize(i));
						arrFieldsInfo[DTODataTable.FIELD_TABLE] = rsmd.getTableName(i);
						hmFieldsIndex.put(rsmd.getColumnName(i), arrFieldsInfo);
						if (!(rsmd.getTableName(i)).equals(GlobalConstants.EMPTY_STRING))
						;
						{
							hmFieldsIndex.put(rsmd.getTableName(i) + rsmd.getColumnName(i), arrFieldsInfo);
						}
					}
					table.setValue(i - 1, oColumnValue);
				}

			}

			dtoTable = new DTODataTable();
			dtoTable.setTable(table);
			dtoTable.setFieldsInfo(hmFieldsIndex);
		}
		catch (Exception e)
		{
			logger.info(e.toString() + ServerConstants.NEWLINE);

			logger.info(table.toString());
		}

		return dtoTable;
	}

	/**
	 * Gets a Clob object and returns its string representation.
	 * 
	 * @param clob the Clob object.
	 * @return sRetVal the Clob object's string representation.
	 */
	public String getCLOBColumnValue(Clob clob) throws SQLException {
		String sRetVal = ServerConstants.EMPTY_STRING;

		if (clob != null)
		{
			long len = clob.length();
			sRetVal = clob.getSubString(1, (int) len).trim();
		}

		return sRetVal;
	}

	/**
	 * @param iColumnIndex - column index
	 * @param rs - result set
	 * @param rsmd - result set meta data
	 * @return a single column string value according to its type
	 * @throws SQLException
	 */
	protected Object getColumnValue(int iColumnIndex, ResultSet rs, ResultSetMetaData rsmd) throws SQLException {
		String sRetVal = null;
		final int iColumnType = rsmd.getColumnType(iColumnIndex);
		if (iColumnType == java.sql.Types.CLOB)
		{
			Clob clob = (Clob) rs.getObject(iColumnIndex);
			sRetVal = getCLOBColumnValue(clob);
		}
		else if (iColumnType == Types.VARBINARY)
		{
			sRetVal = new String(rs.getBytes(iColumnIndex));
		}
		else if (iColumnType == 2007)
		{
			try
			{
				final Object oRetVal = DAOBasic.ms_DBType.getXmlDao().getColumnContent(rs, rsmd.getColumnLabel(iColumnIndex));
				sRetVal = (oRetVal == null ? GlobalConstants.EMPTY_STRING : oRetVal.toString());
			}
			catch (Exception e)
			{
				ExceptionController.getInstance().handleException(e, this);
			}
			if (sRetVal == null) sRetVal = "";
		} else if (iColumnType == java.sql.Types.DATE || iColumnType == java.sql.Types.TIMESTAMP) {
			final String iColumnName = rsmd.getColumnName(iColumnIndex);
			final String iColumnTypeName = rsmd.getColumnTypeName(iColumnIndex);
			Timestamp timestamp = rs.getTimestamp(iColumnName);
			sRetVal = GlobalConstants.EMPTY_STRING;
			if (timestamp != null) {
				sRetVal = new SimpleDateFormat(GlobalDateTimeUtil.STATIC_DATA_DATE_TIME).format(timestamp);
			}
		} else {
			sRetVal = rs.getString(iColumnIndex);

			if (sRetVal == null)
			{
				sRetVal = GlobalConstants.EMPTY_STRING;
			}		
		}

		Admin admin = Admin.getContextAdmin();
		String sProfileID = admin != null ? (String)admin.getSessionData(ServerConstants.COLUMN_PROFILE_ID) : null;
		
		sRetVal = !isNullOrEmpty(sProfileID) && LayoutConstants.PROFILE_ID_CHAR_SETS.equals(sProfileID) ? sRetVal : sRetVal.trim();
		
		return sRetVal;
	}

	public static Object getColumnDefaultValue(Connection conn, String tableName, String columnName) throws Exception {
		Object defValue = null;
		int dataType;

		if (conn != null)
		{
			ResultSet rs = null;
			try
			{
				rs = conn.getMetaData().getColumns(conn.getCatalog(), null, tableName, columnName);
				rs.next();
				boolean isNotNullable = rs.getInt("NULLABLE") == 0;
				if (isNotNullable)
				{

					defValue = rs.getObject("COLUMN_DEF");
					if (defValue != null) defValue = ((String) defValue).trim();

					Object o = rs.getObject("DATA_TYPE");
					if (o instanceof BigDecimal) o = ((BigDecimal) o).intValue();

					dataType = (Integer) o;

					defValue = DataType.reverseValueOf(dataType).convert(defValue);

				}

			}
			catch (Exception e)
			{
				
				logger.error(e.getMessage());
				throw e;
			}
			finally
			{
				rs.close();
			}
		}

		return defValue;
	}

	/**
	 * Populates a DTO from the ResultSet
	 * 
	 * @return void.
	 * @param reply - a DTO
	 * @param rs - A populated ResultSet.
	 */
	private void populateDTO(DTOSingleValue reply, ResultSet rs) throws SQLException {
		ResultSetMetaData rsmd = rs.getMetaData();
		Object oValue = null;
		boolean bHasValue = false;

		if (rs.next())
		{
			bHasValue = true;
			oValue = getColumnValue(1, rs, rsmd);
		}

		if (bHasValue)
		{
			reply.setValue(oValue);
		}
	}

	/**
	 * Sets a Feedback object with an error embeeded in it.
	 * 
	 * @param reply DTOBasic object.
	 * @param sErrorText the error text.
	 */
	protected void setErrorFeedbackObject(DTOBasic reply, String sErrorText) {
		Feedback feedback = reply.getFeedBack();

		feedback.setFailure();
		feedback.setErrorCode(28560);
		feedback.setErrorText(sErrorText);
	}

	/**
	 * Sets a Feedback object with an exception.
	 * 
	 * @param reply DTOBasic object.
	 * @param e Exception object.
	 */
	protected void setExceptionFeedbackObject(DTOBasic reply, Exception e) {
		Feedback feedback = reply.getFeedBack();
		feedback.setFailure();
		feedback.setErrorCode(28560);
		feedback.setException(e);
		ExceptionController.getInstance().handleException(e, this);
	}

	/**
	 * Sets a Feedback object with an error embeeded in it.
	 * 
	 * @param reply DTOBasic object.
	 * @param sErrorText the error text.
	 */
	protected void setErrorFeedbackObject(DTOBasic reply, int iErrorCode, BindingParameter[] arrErrorVariables) {
		Feedback feedback = reply.getFeedBack();

		feedback.setFailure();
		feedback.setErrorCode(iErrorCode);
		feedback.setErrorVariables(arrErrorVariables);
	}

	/**
	 * Generate the filter part of the WHERE phrase of a SelectList select statement, according to a Filter object. This part is later added to the
	 * select statement which came from PROFILE_SELECT_STATEMENT table.
	 * 
	 * @param reply DTOBasic object.
	 * @param e Exception object.
	 */
	public static String getWherePhraseFromFilter(Filter filter) {
		// return value.
		StringBuffer sbRetVal = new StringBuffer();

		// holds the elements of the filter.
		FilterElement[] arrElements = filter.getElements();

		// holds the values of each filter element.
		String[] arrValues = null;

		// append to the SELECT statement each element of the filter.
		for (int i = 0; i < arrElements.length; i++)
		{
			// the method of the filter defines the condition, but if this is the first
			// element, than AND must be use in order to connect it to the rest of the
			// SELECT statement. The OR in this case is good only for the part of the filter.
			if (i == 0)
			{
				sbRetVal.append(AND);
				sbRetVal.append(OPEN_GROUP);

			}
			else
			{
				if (filter.getMethod().equals(CONDITION_ALL))
				{
					sbRetVal.append(AND);
				}
				else
				{
					sbRetVal.append(OR);
				}
			}

			sbRetVal.append(arrElements[i].getFieldName());
			sbRetVal.append(SPCAE);
			sbRetVal.append(arrElements[i].getOperator());
			sbRetVal.append(SPCAE);

			arrValues = arrElements[i].getValues();

			sbRetVal.append(OPEN_GROUP);

			for (int j = 0; j < arrValues.length; j++)
			{
				sbRetVal.append(PLACE_HOLDER);
				sbRetVal.append(SEPERATOR);
			}

			// Replace the last seperator with closing brackets
			sbRetVal.setCharAt(sbRetVal.length() - 1, CLOSE_GROUP.toCharArray()[0]);
		}

		// only if open bracket was added, set as well the closing bracket.
		if (arrElements.length > 0)
		{
			sbRetVal.append(CLOSE_GROUP);
		}

		/* Add ORDER BY if needed */
		String sSortBy = filter.getSortBy();

		if (sSortBy != null && !sSortBy.equals(GlobalConstants.EMPTY_STRING))
		{
			sbRetVal.append(ORDER_BY);
			sbRetVal.append(sSortBy);
		}

		return sbRetVal.toString();
	}

	/**
	 * Do an update or insert operation for prepared statements
	 * 
	 * @param sStatement - statement string
	 * @param arrParameters - prepared statement parameters
	 * @param connection - exist connection to reuse or null
	 * @param feedback - exist feedback to reuse or null
	 * @deprecated - please use update() method from now on - Yaron The reasons are: 1. The method doesnt return back number of affected rows 2. The
	 *             method considers 0 affected rows as an error
	 * @return
	 */
	public Feedback doUpdate(String sStatement, StatementParameter[] arrParameters, Connection connection, Feedback feedback) {
		Feedback feedbackRetVal = feedback != null ? feedback : new Feedback();
		Connection coActual = null;
		PreparedStatement ps = null;

		try
		{
			coActual = connection != null ? connection : getConnection();

			// Tracing.
			String sTraceSelectStatement = ServerUtils.getPreparedStatementFinalString(sStatement, arrParameters);
			sTraceSelectStatement = new StringBuffer(STATEMENT_CONTENT_DO_UPDATE_VALUE).append(sTraceSelectStatement).toString();
			logger.info(sTraceSelectStatement);
			// sStatement =
			// "INSERT INTO CUTOFF_PROFILE (EFFECTIVE_DATE,DESCRIPTION,UID_CUTOFF_PROFILE,DEFAULT_IND,REC_STATUS,PROFILE_CHANGE_STATUS,EXP_TO_DATE,TIME_STAMP,PENDING_ACTION,EXP_FROM_DATE,OFFICE,CUTOFF_NAME,CUTOFF_TYPE,FINAL_CUTOFF,DEPARTMENT,INTERIM_CUTOFF) VALUES (TO_DATE(CAST(? AS VARCHAR(20)),'YYYY-MM-DD'),?,?,?,?,?,?,?,?,?,?,?,?,TO_DATE(?,'HH24:MI'),?,TO_DATE(?,'HH24:MI'))";

			ps = coActual.prepareStatement(sStatement);
			populatePreparedStatementForUpdate(ps, arrParameters);
			// ps.setObject(1,"2008-01-01",Types.CHAR);
			int iAffectedRoes = executeUpdate(ps);

			if (iAffectedRoes == 0)
			{
				feedbackRetVal.setFailure();
				// An error has occured while tring to perform this action
				feedbackRetVal.setErrorCode(10);
				feedbackRetVal.setErrorText("Got 0 records while trying to update");
			
			}
		}
		catch (Exception e)
		{
			feedbackRetVal.setFailure();
			// An error has occured while tring to perform this action
			feedbackRetVal.setErrorCode(28560);
			feedbackRetVal.setException(e);
			ExceptionController.getInstance().handleException(e,this);
		}
		finally
		{
			// Release a connection only if created it localy.
			Connection coRelease = connection == null ? coActual : null;
			releaseResources(null, ps, coRelease);
		}

		return feedbackRetVal;
	}

	public Feedback doUpdate(String sStatement, Feedback feedback, StatementParameter... arrParameters) {
		return doUpdate(sStatement, arrParameters, null, feedback);
	}

	/**
	 * Do an update or insert operation for prepared statements
	 * 
	 * @param sStatement - statement string
	 * @param arrParameters - prepared statement parameters
	 * @param arrAffectedRows - if the caller will pass an int array with size 1 then the method will fill it with the statement effected rows number,
	 *            otherwize the caller can pass null
	 * @param connection[] - wrap exist connection to reuse or null value for non existing connection
	 * @param bSetAutoCommit - in case that the caller code is not in transaction scope, there is a need to set the connection to auto commit mode
	 * @param feedback - exist feedback to reuse or null
	 * @return feedback
	 */
	public Feedback update(String sStatement, StatementParameter[] arrParameters, int[] arrAffectedRows, Connection[] connection,
			boolean bReturnConnection, boolean bSetAutoCommit, Feedback feedback) {
		Feedback feedbackRetVal = feedback != null ? feedback : new Feedback();
		Connection coActual = null;
		PreparedStatement ps = null;
		String sTraceSelectStatement = null, sFullTraceMsg = null ;  

		try
		{
			coActual = connection != null && connection[0] != null ? connection[0] : getConnection(DATA_SOURCE_ID_ACTIVE);

			// Tracing.
			sTraceSelectStatement = ServerUtils.getPreparedStatementFinalString(sStatement, arrParameters);
			sFullTraceMsg = new StringBuffer(STATEMENT_CONTENT_DO_UPDATE_VALUE).append(sTraceSelectStatement).toString();
			logger.info(sFullTraceMsg);

			ps = coActual.prepareStatement(sStatement);
			populatePreparedStatementForUpdate(ps, arrParameters);
			int iAffectedRows = executeUpdate(ps);

			if (arrAffectedRows != null)
			{
				arrAffectedRows[0] = iAffectedRows;
			}

		}
		catch (Exception e)
		{
			feedbackRetVal.setFailure();

			// An error has occurred while string to perform this action
			feedbackRetVal.setErrorCode(28560);
			feedbackRetVal.setException(e);
			sTraceSelectStatement = "Error occurred while perform update action";
			final ProcessError processError = new ProcessError(ProcessErrorConstants.SQLError, new Object[]{"DAOBasic.doUpdate()", sTraceSelectStatement});
			logger.info(processError.getDescription()) ;
			//ExceptionController.getInstance().handleException(e,this);
			ErrorAuditUtils.setErrors(processError) ;
		}
		finally
		{
			if (bReturnConnection)
			{ // Send back the connection no matter if it came from the out side or
				// has created by this method
				connection[0] = coActual;
				releaseResources(null, ps, null);
			}
			else
			{ // No need to return back the connection, release it
				releaseResources(null, ps, coActual);
			}
		}

		return feedbackRetVal;
	}

	/**
	 * Do an update or insert operation for regular statements
	 * 
	 * @param sStatement - statement string
	 * @param connection - exist connection to reuse or null
	 * @return number of effected rows
	 */
	protected DTOSingleValue doUpdate(String sStatement, Connection connection)

	{
		DTOSingleValue dtoSingleValue = new DTOSingleValue();
		Connection coActual = null;
		Statement statement = null;

		try
		{
			coActual = connection != null ? connection : getConnection();

			// Tracing.
			String sTraceSelectStatement = new StringBuffer(STATEMENT_CONTENT_DO_UPDATE_VALUE).append(sStatement).toString();
			logger.info(sTraceSelectStatement);

			statement = coActual.createStatement();
			int iEffectedRecords = statement.executeUpdate(sStatement);
			dtoSingleValue.setValue(String.valueOf(iEffectedRecords));
		}
		catch (Exception e)
		{
			Feedback feedback = dtoSingleValue.getFeedBack();
			feedback.setFailure();
			// An error has occured while tring to perform this action
			feedback.setErrorCode(28560);
			feedback.setException(e);
			logger.error("Error doUpdate for statement: {}. error: {}",sStatement, e.getMessage());
		}
		finally
		{
			// Release a connection only if created it localy.
			Connection coRelease = connection == null ? coActual : null;
			releaseResources(null, statement, coRelease);
		}

		return dtoSingleValue;
	}

	/**
	 * Do an update or insert operation for prepared statements
	 * 
	 * @param sStatement - statement string
	 * @param arrParameters - prepared statement parameters
	 * @param connection - exist connection to reuse or null
	 * @param feedback - exist feedback to reuse or null
	 * @return
	 */
	protected Feedback doDelete(String sStatement, StatementParameter[] arrParameters, Connection connection, Feedback feedback) {
		Feedback feedbackRetVal = feedback != null ? feedback : new Feedback();
		Connection coActual = null;
		PreparedStatement ps = null;

		try
		{
			coActual = connection != null ? connection : getConnection();

			// Tracing.
			String sTraceSelectStatement = ServerUtils.getPreparedStatementFinalString(sStatement, arrParameters);
			sTraceSelectStatement = new StringBuffer(STATEMENT_CONTENT_DO_UPDATE_VALUE).append(sTraceSelectStatement).toString();
			logger.info(sTraceSelectStatement);

			ps = coActual.prepareStatement(sStatement);
			populatePreparedStatement(ps, arrParameters);
			executeUpdate(ps);
		}
		catch (Exception e)
		{
			feedbackRetVal.setFailure();
			// An error has occured while tring to perform this action
			feedbackRetVal.setErrorCode(28560);
			feedbackRetVal.setException(e);
		}
		finally
		{
			// Release a connection only if created it localy.
			Connection coRelease = connection == null ? coActual : null;
			releaseResources(null, ps, coRelease);
		}

		return feedbackRetVal;
	}

	public DTOSingleValue isRecordExist(String[] arrKeys, String[] arrValues, String sTableName) {
		return isRecordExist(arrKeys, arrValues, sTableName, null);
	}

	public DTOSingleValue isRecordExist(String[] arrKeys, String[] arrValues, String sTableName, String columnToReturn) {
		return isRecordExist(arrKeys, arrValues, sTableName, columnToReturn, false);
	}// EOM

	/**
	 * @param Check whether a record exists
	 * @param arrKeys
	 * @param arrValues
	 * @param sTableName
	 * @return a DTOBooelean object containing the boolean value that tells whether a record exists with given key value combination
	 */
	public DTOSingleValue isRecordExist(String[] arrKeys, String[] arrValues, String sTableName, String columnToReturn, final boolean bAddPermissions) {
		DTOSingleValue dtoSingleValue;
		// String sColumnName;

		if (arrKeys.length == arrValues.length && !sTableName.equals(GlobalConstants.EMPTY_STRING))
		{
			StatementParameter[] arrValuesParameters = createStatementParameterArray(sTableName, arrKeys, arrValues);

			if (columnToReturn == null || columnToReturn.length() == 0)
			{
				columnToReturn = "1";
			}
			StringBuffer sbSqlStatement = new StringBuffer("SELECT ").append(columnToReturn).append(" FROM ").append(sTableName).append(
					GlobalConstants.SPACE);

			sbSqlStatement.append(createWhereStatementPart(arrKeys, arrValues));

			dtoSingleValue = isRecordExist(sbSqlStatement.toString(), bAddPermissions, arrValuesParameters);

		}
		else
		{ // Input is invalid
			dtoSingleValue = new DTOSingleValue();
			createInvalidParametersFeedback(dtoSingleValue);
		}

		return dtoSingleValue;
	}

	/**
	 * Create WHERE statement part
	 * 
	 * @param arrKeys - array of keys
	 * @return - WHERE statement part or null
	 */
	private String createWhereStatementPart(String[] arrKeys, String arrValues[]) {
		String sRetVal = null;

		if (arrKeys != null)
		{
			StringBuffer sb = new StringBuffer("WHERE ");

			boolean bFirst = true;
			for (int i = 0; i < arrKeys.length; i++)
			{
				if (!bFirst)
				{
					sb.append("AND ");
				}
				if (GlobalUtils.isNullOrEmpty(arrValues[i]))
				{
					sb.append(arrKeys[i]).append(" IS NULL ");
					;
				}
				else
				{
					if (representsDateParameter(arrValues[i]))
					{
						sb.append(arrKeys[i]).append(" = ").append(getDateMask(arrValues[i]));
					}
					else
					{
						sb.append(arrKeys[i]).append(" = ").append(" ? ");
					}
				}

				bFirst = false;
			}

			sRetVal = sb.toString();
		}

		return sRetVal;
	}

	/**
	 * Creates a statement parameters array
	 * 
	 * @param sTableName - table name
	 * @param arrKeys - keys array
	 * @param arrValues - values array
	 * @return - statement parameters arry or null
	 */
	public StatementParameter[] createStatementParameterArray(String sTableName, String[] arrKeys, String[] arrValues) {
		StatementParameter[] arrStatementParameters = null;

		String sColumnName;
		int iCounter = 0;

		if (arrKeys.length == arrValues.length && !sTableName.equals(GlobalConstants.EMPTY_STRING))
		{
			arrStatementParameters = new StatementParameter[arrValues.length];
			Map<String, ColumnMetaData> hmColumnMetaData = getColumnsMetaDataHM(sTableName);
			int parameterCount = 0;

			int i = 0;
			for (i = 0; i < arrValues.length; i++)
			{
				if (arrValues[i]!= null &&!GlobalConstants.EMPTY_STRING.equals(arrValues[i]))
				{
					sColumnName = convertFullNameToColumnName(arrKeys[i]);
					int iColumnType = (hmColumnMetaData.get(sColumnName)).getColumnType();

					// must use this specific constructor so as to initialise the table and column names within the
					// statement parameter instance. those would be used during the internal init() to
					// retrieve the column'e meta data
					arrStatementParameters[parameterCount] = new StatementParameter(arrKeys[i], arrValues[i], iColumnType);

					parameterCount++;
				}
				else
				{
					iCounter++;
				}
			}

			if (iCounter > 0)
			{
				StatementParameter[] arrStatementParametersDuplicate = new StatementParameter[arrValues.length - iCounter];
				System.arraycopy(arrStatementParameters, 0, arrStatementParametersDuplicate, 0, arrStatementParametersDuplicate.length);
				arrStatementParameters = arrStatementParametersDuplicate;
			}

		}

		return arrStatementParameters;
	}

	public DTOSingleValue isRecordExist(final String sStatement, final StatementParameter... parameters) {
		return this.isRecordExist(sStatement, false, parameters);
	}// EOM

	/**
	 * @param Check whether a record exists
	 * @param sStatement - SQL statement
	 * @param arrParameters - Statement parameters
	 * @return boolean value
	 */
	public DTOSingleValue isRecordExist(String sStatement, final boolean bAddPermissions, StatementParameter... parameters) {
		// pre-requisite - the admin should be populated with the websession info map
		if (bAddPermissions)
		{

			final String sUserEntitlementName = Admin.getContextAdmin().getWebSessionInfo().getUEntName();
			if (sUserEntitlementName != null)
			{

				// retrieve the user entitlement container
				final UserEntitlementData userEntitlementData = EntitlementsDataFactory.getInstance().getUserEntitlementData(sUserEntitlementName);

				// if there was a were parameters then add the AND keyword otherwise use the WHERE
				sStatement = new StringBuilder(sStatement).append(parameters == null ? " WHERE " : " AND ").append("DEPARTMENT IN (").append(
						userEntitlementData.getPERM_PROF_DEPARTMENT()).append(')').toString();
			}// EO if the entitlement was present
		}// EO if the bAddPermissions was true

		return this.getSingleValue(sStatement, parameters, null);
	}// EOM

	public DTOBoolean isRecordExistToBoolean(String sStatement, StatementParameter... parameters) {
		DTOSingleValue dtoSingleValue = isRecordExist(sStatement, parameters);
		DTOBoolean dtoBoolean = new DTOBoolean();
		if (dtoSingleValue.isFeedBackSuccess() && !dtoSingleValue.isEmpty())
		{
			dtoBoolean.setValue(!dtoSingleValue.getValue().equals(GlobalConstants.ZERO_VALUE));
		}
		else
		{
			dtoBoolean.setFeedback(dtoSingleValue.getFeedBack());
		}

		return dtoBoolean;
	}

	public DTOBoolean isRecordExistToBoolean(String[] arrKeys, String[] arrValues, String sTableName) {
		DTOSingleValue dtoSingleValue = isRecordExist(arrKeys, arrValues, sTableName);
		DTOBoolean dtoBoolean = new DTOBoolean();
		if (dtoSingleValue.isFeedBackSuccess() && !dtoSingleValue.isEmpty())
		{
			dtoBoolean.setValue(!dtoSingleValue.getValue().equals(GlobalConstants.ZERO_VALUE));
		}
		else
		{
			dtoBoolean.setFeedback(dtoSingleValue.getFeedBack());
		}

		return dtoBoolean;
	}

	/**
	 * Fetch the maximum value of a column
	 * 
	 * @param sTableName - Table name
	 * @param sFieldName - Columns name
	 * @param arrWhereClauseColumnNames - Columns names for where clause if any or null
	 * @param arrWhereClauseValues - Columns parameters for where clause if any or null
	 * @param connection - Open connection if any or null
	 * @return DTOSingleValue - Max value
	 */
	protected DTOSingleValue getMaxColumnValue(String sTableName, String sFieldName, String[] arrWhereClauseColumnNames,
			StatementParameter[] arrWhereClauseValues) {
		DTOSingleValue dtoSingleValue;

		if (sTableName != null && sFieldName != null
				&& (arrWhereClauseColumnNames == null && arrWhereClauseValues == null || arrWhereClauseValues.length == arrWhereClauseValues.length))
		{ // Input is valid

			// Connection con = null;
			// ResultSet rs = null;
			// Statement statement = null;

			StringBuffer sbSelectStatement = new StringBuffer("SELECT MAX(").append(sFieldName).append(") FROM ").append(sTableName);

			if (arrWhereClauseColumnNames != null)
			{// Add the where clause with AND
				int i;
				sbSelectStatement.append(" WHERE ");

				for (i = 0; i < arrWhereClauseColumnNames.length; i++)
				{
					sbSelectStatement.append(arrWhereClauseColumnNames[i]).append("= ?");
					if (i < arrWhereClauseColumnNames.length - 1)
					{// This is not the last item
						sbSelectStatement.append(" AND ");
					}
				}
			}

			dtoSingleValue = getSingleValue(sbSelectStatement.toString(), arrWhereClauseValues, null);
		}
		else
		{
			dtoSingleValue = new DTOSingleValue();
			createInvalidParametersFeedback(dtoSingleValue);
		}

		return dtoSingleValue;
	}

	/**
	 * Create an invalid parameters feedback
	 * 
	 * @param dtoBasic - DTO object that hold the feedback
	 * @return
	 */
	private void createInvalidParametersFeedback(DTOBasic dtoBasic) {
		Feedback feedback = dtoBasic.getFeedBack();

		feedback.setFailure();
		feedback.setErrorText("Invalid parameters");
		// General Error for the user
		feedback.setErrorCode(98349);
	}

	/**
	 * Returns a well formed 'SET' string according to the passed master table name & the values in the passed HashMap.
	 * 
	 * @param sMasterTableName the master table name.
	 * @param hmNewValues HashMap in which: Key - a column name from the passed table name. Value - the value to set for this column.
	 * @return sSetString a well formed 'SET' string according to the passed master table name & the values in the passed HashMap.
	 */
	
	public String getWellFormedSETString(String sMasterTableName, HashMap hmNewValues, ArrayList<String>udfArr) throws IllegalArgumentException {
		final String SET_START = "SET ";
		final String EQUAL_SIGN_PART = " = ";

		String sSetString = null;
		StringBuffer sb = new StringBuffer(SET_START);

		// Gets the metadata types for the passed table name.
		Map<String, ColumnMetaData> hmColumnMetaData = getColumnsMetaDataHM(sMasterTableName);

		if (hmNewValues != null && !hmNewValues.isEmpty())
		{
			Iterator<String> iterKeys = hmNewValues.keySet().iterator();

			String sColumnName, sColumnValue;
			int iColumnType = -1;

			while (iterKeys.hasNext())
			{
				sColumnName = iterKeys.next();
				//if the column name is a profile udf then add it to the given udfArr parameter and 
				//don't concatenate it to the returned string
				if (sColumnName.indexOf("^")!= -1) {
					udfArr.add(sColumnName);
				}else {
				
					sColumnValue = (String) hmNewValues.get(sColumnName);
	
					// In case new value is empty, it means that the field was set to null.
					if (sColumnValue.length() == 0)
					{
						// NULL insertions and updates in DB2 are datatype dependent.
						// In order to circumvent explicity casting, the default keyword
						// supported by both Oracle and DB2 is used.
						sColumnValue = DEFAULT_KEYWORD;
					}
					
						
					else
					{
						
						// if the value is not null, format it to conform to the correct syntax
							iColumnType = (hmColumnMetaData.get(sColumnName)).getColumnType();
						
						// if
						/*
						 * f("PREVENT_STP, RATE_USAGE, EXCHRATE_CFG, DUPLICATE_CHECK".indexOf(sMasterTableName) != -1 &&
						 * sColumnName.equals("EFFECTIVE_DATE")) iColumnType = Types.VARCHAR ;
						 */
	
						sColumnValue = formatValue(sColumnValue, iColumnType);
					}// EO else if the value is not null
	
					sb.append(sColumnName).append(EQUAL_SIGN_PART).append(sColumnValue).append(ServerConstants.COMMA).append(ServerConstants.SPACE);
				}
			}

			// Cosmetics.
			sSetString = sb.toString();
			int iLength = sSetString.length();
			if (iLength > 0)
			{
				// Removes the last appended ', ' part.
				sSetString = sSetString.substring(0, iLength - 2);
			}
		}

		return sSetString;
	}
	
	
	/**
     *
     */
	public String formatValue(String sValue, int iSqlType) throws IllegalArgumentException {
		final String ERROR_MESSAGE_1 = "ERROR: DAOBasic.formatValue - ";
		final String ERROR_MESSAGE_2 = " un-supported type: ";

		StringBuffer sbRetVal = new StringBuffer();

		switch (iSqlType) {
			case Types.VARCHAR:
			case Types.CHAR: {
				if (!sValue.equals(NULL))
				{
					// first replace all single quotes with double ones
					sValue = sValue.replaceAll("'", "''");
					sbRetVal.append(ServerConstants.APOSTROPHE).append(sValue).append(ServerConstants.APOSTROPHE);
				}
				else
				{
					sbRetVal.append(sValue);
				}
				break;
			}
			case Types.INTEGER:
			case Types.DECIMAL:
			case Types.NUMERIC:
			case Types.SMALLINT: {
				sbRetVal.append(sValue);
				break;
			}
			case Types.DATE: {
				handleDateType(sValue, sbRetVal);

				break;
			}
			case Types.TIMESTAMP: {
				handleDateType(sValue, sbRetVal);

				break;
			}
			default: {
				String sErrorMessage = new StringBuffer(ERROR_MESSAGE_1).append(iSqlType).append(ERROR_MESSAGE_2).toString();
				throw new IllegalArgumentException(sErrorMessage);
			}
		}

		return sbRetVal.toString();
	}

	private void handleDateType(String sValue, StringBuffer sb) {
		// DB2 convertion of char to Timestamp type is rigid and leaves no
		// room for leniency, thus attempting to use the 'MM-DD-YYYY HH24:M:SS'
		// on a date string consisted only of the date part would fail.
		if (sValue.length() == 10)
		{
			sValue += " 00:00:00";
		}
		final String DATE_PART_1 = "TO_DATE('";
		final String DATE_PART_2 = "','" + SQL_FORMAT_DATE_TIME + "')";
		final String DATE_PART_3 = "','" + SQL_FORMAT_TIME_NO_SECONDS + "')";

		// For date columns, TO_DATE can not take NULL as value, so in case of NULL
		// just skip the TO_DATE to achieve a successfull UPDATE.
		if (!sValue.equals(NULL))
		{
			if (sValue.length() == 5) sb.append(DATE_PART_1).append(sValue).append(DATE_PART_3);
			else sb.append(DATE_PART_1).append(sValue).append(DATE_PART_2);
		}
		else
		{
			sb.append(sValue);
		}
	}

	/**
	 * To concatenate blank space after a string
	 * 
	 * @param sValue - Value of a field
	 * @param iWidth - Length of a field in the database
	 * @return the original value wrapped with spaces or just the original string for illigal parameters
	 */
	public String adjustWidth(String sValue, int iWidth) {
		String sRetVal = sValue;
		if (sValue != null && sValue.length() < iWidth)
		{
			StringBuffer sb = new StringBuffer(sValue);
			for (int i = sValue.length(); i < iWidth; i++)
			{
				sb.append(GlobalConstants.SPACE);
			}
			sRetVal = sb.toString();
		}
		return sRetVal;
	}

	/**
	 * Converts a full tag name "Table.field" to column name
	 * 
	 * @param sFullName - full tag name
	 * @return a column name without TableName
	 */
	public static String convertFullNameToColumnName(String sFullName) {
		String sColumnName = sFullName;
		int iIndexOfDot = sFullName.indexOf(GlobalConstants.DOT);
		if (iIndexOfDot != -1)
		{
			sColumnName = sFullName.substring(iIndexOfDot + 1);
		}

		return sColumnName;
	}

	/**
	 * Converts a full tag name "Table.field" to table name
	 * 
	 * @param sFullName - full tag name
	 * @return a column name without TableName
	 */
	public static String convertFullNameToTableName(String sFullName) {
		String sTableName = sFullName;
		int iIndexOfDot = sFullName.indexOf(GlobalConstants.DOT);
		if (iIndexOfDot != -1)
		{
			sTableName = sFullName.substring(0, iIndexOfDot);
		}

		return sTableName;
	}

	/**
	 * inserts record into given table.
	 * 
	 * @param sTableName
	 * @param arrKeys
	 * @param arrValues
	 * @return feedback
	 */
	public Feedback insertRecord(String sTableName, String[] arrKeys, String[] arrValues) {
		Map<String, ColumnMetaData> hmColumnMetaData = getColumnsMetaDataHM(sTableName);
		StatementParameter[] arrParameters;
		// Connection con = null;
		Feedback feedBack = new Feedback();

		Iterator<Map.Entry<String, ColumnMetaData>> itFields = hmColumnMetaData.entrySet().iterator();

		StringBuffer sbStatement = new StringBuffer(STRING_INSERT_INTO);
		sbStatement.append(sTableName).append(OPEN_GROUP).append(GlobalConstants.SPACE);

		int i = 0;

		while (itFields.hasNext())
		{ // Loop on types hashmap
			Map.Entry<String, ColumnMetaData> entry = itFields.next();
			sbStatement.append(entry.getKey());
			if (i < hmColumnMetaData.size() - 1)
			{
				sbStatement.append(GlobalConstants.COMMA).append(GlobalConstants.SPACE);
			}
			i++;
		}

		sbStatement.append(STRING_INSERT_VALUES);

		for (i = 0; i < hmColumnMetaData.size(); i++)
		{
			sbStatement.append(PLACE_HOLDER);
			if (i < hmColumnMetaData.size() - 1)
			{ // This is not the last iteration
				sbStatement.append(GlobalConstants.COMMA).append(GlobalConstants.SPACE);
			}
		}

		sbStatement.append(CLOSE_GROUP);

		// /Now the insert statement is ready......

		arrParameters = createStatementParameterArray(sTableName, arrKeys, arrValues);

		// Now the statement parameter is ready.

		feedBack = doUpdate(sbStatement.toString(), arrParameters, null, feedBack);

		return feedBack;
	}

	/**
	 * inserts multiple records into given table.
	 * 
	 * @param sTableName
	 * @param dtoHolder
	 * @return feedback
	 */
	public Feedback insertMultipleRecords(String sTableName, DTODataHolder dtoHolder) {
		// Object[] arrKeys;
		// Object[] arrValues;
		int iNumberOfRecords = dtoHolder.getRowsNumber();
		Feedback feedback = new Feedback();
		int i = 0;
		while (i < iNumberOfRecords && feedback.isSuccessful())
		{
			HashMap hmDataRow = dtoHolder.getDataRow(i);
			int iNumberOfFields = hmDataRow.size();

			Set setEntries = hmDataRow.entrySet();
			Iterator it = setEntries.iterator();

			String[] arrStrKeys = new String[iNumberOfFields];
			String[] arrStrValues = new String[iNumberOfFields];

			while (it.hasNext())
			{
				Map.Entry entry = (Map.Entry) it.next();
				arrStrKeys[i] = (String) entry.getKey();
				arrStrValues[i] = (String) entry.getValue();
			}
			feedback = insertRecord(sTableName, arrStrKeys, arrStrValues);
			i++;
		}
		return feedback;
	}

	public boolean bIsDateOrTime(String sParamValue)
	{
		if (GlobalUtils.isNullOrEmpty(sParamValue))
		{
			return false;
		}
		char[] charArray=sParamValue.toCharArray();
		boolean bResult=
				(
				//2014-11-25
				 (charArray.length>9 && charArray[4]=='-' && charArray[7]=='-' && 
				  Character.isDigit(charArray[0]) && Character.isDigit(charArray[1]) && Character.isDigit(charArray[2]) && Character.isDigit(charArray[3]) && 
				  Character.isDigit(charArray[5]) && Character.isDigit(charArray[6]) && 
				  Character.isDigit(charArray[8]) && Character.isDigit(charArray[9])) ||
				//23:56:14
				 (charArray.length>7 && charArray[2]==':' && charArray[5]==':' && 
				  Character.isDigit(charArray[0]) && Character.isDigit(charArray[1]) && 
				  Character.isDigit(charArray[3]) && Character.isDigit(charArray[4]) && 
				  Character.isDigit(charArray[6]) && Character.isDigit(charArray[7]))
				);
		return bResult;
	}
	/**
	 * Decide if a parameter holds a date value.
	 * 
	 * @param sParameterValue - parameter value which the date mask should mask.
	 * @return Date format.
	 */
	public boolean representsDateParameter(StatementParameter parameter) {
		boolean bRepresentsDateParameter = false;

		// TODO - find a nicer way to do the check - get the data from the layout cache
		if (parameter.getTargetSqlType() == Types.VARCHAR)
		{
			String sParamValue = (String) parameter.getParameterObject();

			if (sParamValue != null
					&& sParamValue.length() != 23 //P_TIME_STAMP length is 23. For timestemp it is not a date
					&& bIsDateOrTime(sParamValue))
			{// Value is not null and is a date or time format
				bRepresentsDateParameter = true;
			}
		}

		return bRepresentsDateParameter;
	}

	/**
	 * Decide if a parameter holds a time value.
	 * 
	 * @param sParameterValue - parameter value which the date mask should mask.
	 * @return Time format.
	 */
	public boolean representsTimeParameter(StatementParameter parameter) {
		boolean bRepresentsDateParameter = false;

		// TODO - find a nicer way to do the check - get the data from the layout cache
		if (parameter.getTargetSqlType() == Types.VARCHAR)
		{
			String sParamValue = (String) parameter.getParameterObject();

			if (sParamValue != null && ((sParamValue.length() == 5 && sParamValue.charAt(2) == ':') // HH24:MI
					|| (sParamValue.length() == 8 && sParamValue.charAt(2) == ':' && sParamValue.charAt(5) == ':') // HH24:MI:SS
			|| (sParamValue.length() == 12 && sParamValue.charAt(2) == ':' && sParamValue.charAt(5) == ':' && sParamValue.charAt(8) == ' '))) // HH24:MI:SS.FF3

			{// Value is not null and is a date or time format
				bRepresentsDateParameter = true;
			}
		}

		return bRepresentsDateParameter;
	}

	/**
	 * Decide if a parameter holds a date value.
	 * 
	 * @param sParameterValue - parameter value which the date mask should mask.
	 * @return Date format.
	 */
	public boolean representsDateParameter(String sParameterValue) {
		return representsDateParameter(new StatementParameter(sParameterValue, Types.VARCHAR));
	}

	/**
	 * Decide if a parameter holds a time value.
	 * 
	 * @param sParameterValue - parameter value which the date mask should mask.
	 * @return Time format.
	 */
	public boolean representsTimeParameter(String sParameterValue) {
		return representsTimeParameter(new StatementParameter(sParameterValue, Types.VARCHAR));
	}

	/**
	 * Decide and return a date format for select statement according to the value it represents.
	 * 
	 * @param sParameterValue - parameter value which the date mask should mask.
	 * @return Date format.
	 */
	public String getDateMask(StatementParameter sParameterValue) {
		String sDateFormat = NULL;

		String sParamValue = (String) sParameterValue.getParameterObject();

		if (sParameterValue != null)
		{ // Has a date value
			if (sParamValue.length() > 16 && sParamValue.charAt(4) == '-' && sParamValue.charAt(7) == '-' && sParamValue.charAt(13) == ':'
					&& sParamValue.charAt(16) == ':')
			{
				// Explicit cast of the to date bound parameter to its respective datatype is
				// mandatory in DB2 and supported in oracle
				sDateFormat = "TO_DATE(?,'" + SQL_FORMAT_DATE_TIME + "')";
			}
			else if (sParamValue.length() > 7 && sParamValue.charAt(4) == '-' && sParamValue.charAt(7) == '-')
			{
				// Explicit cast of the to date bound parameter to its respective datatype is
				// mandatory in DB2 and supported in oracle
				sDateFormat = "TO_DATE(? ,'" + SQL_FORMAT_DATE + "')";
			}
			else if (sParamValue.length() > 5 && sParamValue.charAt(2) == ':' && sParamValue.charAt(5) == ':')
			{
				// Explicit cast of the to date bound parameter to its respective datatype is
				// mandatory in DB2 and supported in oracle
				sDateFormat = "TO_DATE(? ,'" + SQL_FORMAT_TIME + "')";
			}
		}

		return sDateFormat;
	}

	/**
	 * Decide and return a time format for select statement according to the value it represents.
	 * 
	 * @param sParameterValue - parameter value which the date mask should mask.
	 * @return Time format.
	 */
	public String getTimeMask(StatementParameter sParameterValue) {
		String sDateFormat = NULL;

		String sParamValue = (String) sParameterValue.getParameterObject();

		if (sParameterValue != null)
		{ // Has a time value
			if (sParamValue.length() == 5)
			{
				sDateFormat = "TO_DATE(? ,'" + SQL_FORMAT_TIME_NO_SECONDS + "')";
			}
			else if (sParamValue.length() == 8)
			{
				sDateFormat = "TO_DATE(? ,'" + SQL_FORMAT_TIME + "')";
			}
			else
			{
				sDateFormat = "TO_DATE(? ,'" + SQL_FORMAT_TIME_SECONDS_AND_MILLISECONDS + "')";
			}
		}

		return sDateFormat;
	}

	/**
	 * Decide and return a date format for select statement according to the value it represents.
	 * 
	 * @param sParameterValue - parameter value which the date mask should mask.
	 * @return Date format.
	 */
	public String getDateMask(String sParameterValue) {
		return getDateMask(new StatementParameter(sParameterValue, Types.VARCHAR));
	}

	/**
	 * Decide and return a time format for select statement according to the value it represents.
	 * 
	 * @param sParameterValue - parameter value which the date mask should mask.
	 * @return Time format.
	 */
	public String getTimeMask(String sParameterValue) {
		return getTimeMask(new StatementParameter(sParameterValue, Types.VARCHAR));
	}

	/**
	 * Updates a record
	 * 
	 * @param sTableNAme - table name
	 * @param arrKeys - keys array
	 * @param arrValues values array
	 * @param arrStatementParameters - statement paraemter array
	 * @param sWhereClause - where clause or null if not exist
	 * @param connection - connection if exist
	 * @return feedback
	 */
	public Feedback doUpdate(String sTableNAme, String[] arrKeys, StatementParameter[] arrStatementParameters, String sWhereClause,
			Connection connection) {
		Feedback feedback = null;

		if (arrStatementParameters.length >= arrKeys.length)
		{
			StringBuffer sb = new StringBuffer();

			sb.append("UPDATE ").append(sTableNAme).append(" SET ");
			for (int i = 0; i < arrKeys.length; i++)
			{
				sb.append(arrKeys[i]).append(" = ?");

				if (i < arrKeys.length - 1)
				{// It is not the last parameter
					sb.append(", ");
				}
			}

			if (sWhereClause != null)
			{
				sb.append(" WHERE ").append(sWhereClause);
			}

			feedback = doUpdate(sb.toString(), arrStatementParameters, connection, null);

		}
		else
		{
			feedback = new Feedback();
			feedback.setFailure();
			feedback.setErrorText("Invalid parameters");
		}

		return feedback;
	}

	/**
	 * Populates a callable statement with the values sent.
	 * 
	 * @param statement - The callable statement.
	 * @param parameters - Array of values to bind to the statement.
	 */
	protected void populateCallableStatement(CallableStatement statement, CallableStatementParameter[] arrParameters) throws SQLException {
		for (int i = 0; i < arrParameters.length; i++)
		{
			// Only parameters that are direction IN should be bind.
			if (arrParameters[i].isInputParameter())
			{
				statement.setObject(i + 1, arrParameters[i].getParameterObject(), arrParameters[i].getTargetSqlType());
			}
		}
	}

	/**
	 * Callable statement requires registering the output variables. This method does the registration.
	 * 
	 * @param statement - The callable statement.
	 * @param parameters - Array of values to bind to the statement.
	 */
	protected void registerCallableStatementOutParams(CallableStatement callableStatement, CallableStatementParameter... parameters)
			throws SQLException {
		for (int i = 0; i < parameters.length; i++)
		{
			// Only parameters that are direction OUT should be registered.
			if (parameters[i].isOutputParameter())
			{
				callableStatement.registerOutParameter(i + 1, parameters[i].getTargetSqlType());
			}
		}
	}

	/**
	 * Populates a single value DTO from the callable statement out params.
	 * 
	 * @param reply - The single value DTO.
	 * @param statement - The callable statement.
	 * @param parameters - Array of values to bind to the statement.
	 */
	private void populateDTOFromCallableStatement(DTODataHolder reply, CallableStatement callableStatement, String sSPName,
			CallableStatementParameter... parameters) throws SQLException {
		Feedback feedback = new Feedback();

		String sValue = null;
		HashMap hmOutParams = new HashMap();

		for (int i = 0; i < parameters.length; i++)
		{
			// Checks only output parameters.
			if (parameters[i].isOutputParameter())
			{
				// If the passed SP name is one for which we need to check the return code
				// and if the current output parameter is the RETURN code, than set it to
				// the feedback.
				if (parameters[i].getParameterProperty().equals(CallableStatementParameter.OUTPUT_RETURN_CODE)
						&& !HS_SP_NAMES_NO_RET_CODE_CHECK_REQUIRED.contains(sSPName))
				{
					// if the returned error code isn't 0, we set the Feedback object
					// to failure, to notify the first method that initialized this call.
					if (!callableStatement.getString(i + 1).equals(CALLABLE_STATEMENT_SUCCESS))
					{
						feedback.setFailure();

						// Sets the error code into the feedback; this error code will
						// be checked in the calling method.
						String sErrorCode = callableStatement.getString(i + 1);
						feedback.setErrorCode(Integer.valueOf(sErrorCode).intValue());
					}
				}

				// Currently - 16/08/05 - not implemented !!!!!
				// When implemented, it should be coordinated with:what we do with
				// 1) The OUTPUT_ERROR_TEXT parameter, (see next 'else' clause).
				// 2) The '' which sets error messages into the feedback according to the
				// error code which was set into the feedback.
				//
				// If the current output parameter is the ERROR code from the ERRCODES
				// table, we should get matching error message from the table & set it
				// into the set it the feedback error message.
				if (parameters[i].getParameterProperty().equals(CallableStatementParameter.OUTPUT_ERROR_CODE))
				{}

				// If the current output parameter is error text, set it to the feedback.
				else if (parameters[i].getParameterProperty().equals(CallableStatementParameter.OUTPUT_ERROR_TEXT))
				{
					String sErrorText = callableStatement.getString(i + 1);
					feedback.setErrorText(sErrorText);

					// In general this error text should be written into the trace file
					// by the Feedback object & its members, (see 'UserDialog.toHtml' method,
					// the 'm_sDeveloperErrorText' member).
					// Currently - 21/07/05 - this isn't done there, so we do it here.
					if (sErrorText != null && !sErrorText.equals(ServerConstants.EMPTY_STRING))
					{
						ExceptionController.getInstance().handleError(-2, sErrorText, ServerConstants.EMPTY_STRING);
					}
				}

				// Copies the current output parameter into a HashMap object, which
				// will be set into the DTODataHolder object.
				String sParameterKey = new StringBuffer(PARAMETER).append(i).toString();
				sValue = callableStatement.getString(i + 1);
				sValue = sValue != null ? sValue : ServerConstants.EMPTY_STRING;
				hmOutParams.put(sParameterKey, sValue);
				parameters[i].setResultValue(sValue);
			}
		}

		reply.addDataRow(hmOutParams);

		reply.setFeedback(feedback);
	}

	/**
	 * Executes a callable statement.
	 * 
	 * @param sCallableStatementName the callable statement in String representation.
	 * @param arrParameters array of parameters to bind to the statement.
	 */
	public DTODataHolder executeCallableStatement(String sCallableStatementName, CallableStatementParameter... arrParameters) {
		return executeCallableStatement(null, sCallableStatementName, arrParameters);
	}

	/**
	 * Executes a callable statement.
	 * 
	 * @param conn Connection object, can be null.
	 * @param sCallableStatementName the callable statement in String representation.
	 * @param arrParameters array of parameters to bind to the statement.
	 */
	public DTODataHolder executeCallableStatement(Connection conn, String sCallableStatementName, CallableStatementParameter... parameters) {
		DTODataHolder dtoDataHolder = new DTODataHolder();
		Connection finalConn = null;

		try
		{
			finalConn = conn != null ? conn : getConnection();
			CallableStatement callableStatement = finalConn.prepareCall(sCallableStatementName);
			registerCallableStatementOutParams(callableStatement, parameters);
			populateCallableStatement(callableStatement, parameters);
			callableStatement.execute();

			String sSPName = getSPName(sCallableStatementName);
			populateDTOFromCallableStatement(dtoDataHolder, callableStatement, sSPName, parameters);
		}
		catch (SQLException sqle)
		{
			setExceptionFeedbackObject(dtoDataHolder, sqle);
		}
		finally
		{
			releaseResources(null, null, conn != null ? null : finalConn);
		}

		return dtoDataHolder;
	}

	/**
	 * Gets a callebale statement string, (e.g. {call SP_MSG_LOCK(?,?,?,?,?,?,?,?,?,?,?,?,?)} ) and returns the stored procedure name from it.
	 */
	private static String getSPName(String sCallableStatementName) {
		final String SP_PREFIX = "{call";
		final int SP_PREFIX_LENGTH = SP_PREFIX.length();

		sCallableStatementName = sCallableStatementName.trim();
		int iOpenParenthesisIndex = sCallableStatementName.indexOf(GlobalConstants.OPENING_PARENTHESIS);

		return sCallableStatementName.substring(SP_PREFIX_LENGTH, iOpenParenthesisIndex).trim();
	}

	/**
	 * Returns a unique sys time string from the database.
	 */
	public DTOSingleValue getUniqueSysTimeFromDB() {
		// Replaced the SYSTIMESTAMP(6) with a polymorphicically determined keyword.
		// Replaced DUAL with database dependent value
		final String SELECT_STATEMENT = "SELECT TO_CHAR(" + ms_DBType.getCurrentTimestampKeyword() + ",'MISSFF') FROM "
				+ ms_DBType.getDummyTableName();

		return getSingleValue(SELECT_STATEMENT, null);
	}

	public static String getFormattedTimeStampKeyword(){
		return FORMATTED_SYSTIME_COLUMN;
	}
	
	public DTOSingleValue getFormatedUniqueSysTimeFromDB(boolean isWriteToDB) {
		// Replaced the SYSTIMESTAMP(6) with a polymorphicically determined keyword.
		// Replaced DUAL with database dependent value
		final String sSELECT_STATEMENT = "SELECT" + FORMATTED_SYSTIME_COLUMN + "FROM " + ms_DBType.getDummyTableName() ; 
		return getSingleValue(sSELECT_STATEMENT, null);
	}

	public DTOSingleValue getFormatedUniqueSysTimeFromDB() {
		return getFormatedUniqueSysTimeFromDB(true);
	}
	
	public String[] getFormattedSysTimeAndTimeStampFromDB() throws SQLException{
		final String sSELECT_STAEMENT = "SELECT" + FORMATTED_SYSTIME_COLUMN + ',' + SYS_TIMESTAMP_COLUMN + "FROM " + ms_DBType.getDummyTableName() ; 
		
		Connection conn = null ; 
		PreparedStatement ps = null ; 
		ResultSet rs = null ; 
		try{ 
			conn = this.getConnection() ; 
			ps = conn.prepareStatement(sSELECT_STAEMENT) ; 
			rs = ps.executeQuery() ; 
			rs.next() ; 
			
			return new String[] { rs.getString(1), rs.getString(2) } ;						
		}finally{ 
			this.releaseResources(rs, ps, conn) ; 
		}//EO catch block 
	}//EOM 

	public DTOSingleValue getSysTimeInMillisecondsFromDB() {
		// Replaced the SYSTIMESTAMP(6) with a polymorphicically determined keyword.
		// Replaced DUAL with database dependent value
		// final String SELECT_STATEMENT =
		// "SELECT (TRUNC("+ms_DBType.getCurrentTimestampKeyword()+") - TO_DATE('01011970','DDMMYYYY'))*60*60*24*1000 FROM " +
		// ms_DBType.getDummyTableName();

		final String sSELECT_STATEMENT = "SELECT " + SYS_TIMESTAMP_COLUMN + "FROM " + ms_DBType.getDummyTableName() ; 
		return getSingleValue(sSELECT_STATEMENT, null);
	}

	/**
	 * Note: Currently this method is not supported as DB2's Pk column datatype is identity as opposing to integer+sequence in oracle, and thus does
	 * not provide the next sequence facility. Nevertheless, sequences are supported by DB2 and if the need arises will be introduced, thus giving
	 * this method legitimacy. Function calls to DB Sequence for return next value of specified field (@sFieldName) The function builds Sequence Name
	 * according to following convention: "SEQ_"+'Table Name'+"_"+'Field Name', if final seq name long than 30 chars it will be cut the name to 30
	 * chars
	 * 
	 * @param sTableName
	 * @param sFieldName
	 * @param conn
	 * @return
	 * @deprecated
	 */
	public DTOSingleValue getNextValueFor(String sTableName, String sFieldName, Connection conn) {
		StringBuffer sbSeqName = new StringBuffer();
		String sSeqName = null;
		sbSeqName.append("SEQ_").append(sTableName).append(GlobalConstants.UNDERSCORE).append(sFieldName);
		if (sbSeqName.length() > 30)
		{
			sSeqName = sbSeqName.substring(0, 30);
		}
		else
		{
			sSeqName = sbSeqName.toString();
		}
		StringBuffer sbSeqCallSQL = new StringBuffer();
		sbSeqCallSQL.append(SEQ_SQL_PREFIX).append(sSeqName).append(SEQ_SQL_SUFFIX);
		return getSingleValue(sbSeqCallSQL.toString(), conn);
	}

	/**
	 * Dec 4, 2007 guys Utility method to execute an insert query and retrieve the generated PK value in the same call scope. The method supports both
	 * sequence and identity PK column types and is thus suitable for Oracle and DB2 both. * Note: The method is autarkic and will release all self
	 * created resources at the exist from the method scope.
	 * 
	 * @param sStatement Insert Query to execute.
	 * @param arrParameters StatementParameter varargs to bind.
	 * @return DTOSingleValue containing the execution results and the generated Pk value
	 */
	public final DTOSingleValue doUpdateAndReturnAutoGeneratedPk(final String sStatement, StatementParameter... arrParameters) {

		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		DTOSingleValue returnValue = new DTOSingleValue();

		final String PK_RETRIEVAL_STATEMENT = "SELECT PK_PROFILE_UPDATE FROM PROFILE_UPDATE WHERE TIME_STAMP = ? AND PROFILE_ID = ? AND FK_PROFILE_UID = ?";
		try
		{
			// Tracing.
			String sTraceSelectStatement = ServerUtils.getPreparedStatementFinalString(sStatement, arrParameters);
			sTraceSelectStatement = new StringBuffer(STATEMENT_CONTENT_DO_UPDATE_VALUE).append(sTraceSelectStatement).toString();
			logger.info(sTraceSelectStatement);

			// conn = getConnection();

			// get the prepared statemet using the correct configuration given the database type
			// ps = ms_DBType.getPrepareStatementWithIdentity(sStatement, conn) ;

			// ps = conn.prepareStatement(STATEMENT_CONTENT_DO_UPDATE_VALUE) ;
			// populatePreparedStatementForUpdate(ps, arrParameters);

			// int iAffectedRows = ps.executeUpdate();

			Feedback feedback = this.doUpdate(sStatement, arrParameters, null, null);

			if (!feedback.isSuccessful())
			{
				returnValue.setFeedback(feedback);
				return returnValue;
			}// EO if a failure had occurred

			// rertieve the pk
			final DTODataHolder dtoPk = this.getData(PK_RETRIEVAL_STATEMENT, new StatementParameter[] { arrParameters[12], arrParameters[13],
					arrParameters[0] });

			feedback = dtoPk.getFeedBack();

			if (!feedback.isSuccessful())
			{
				returnValue.setFeedback(feedback);
				return returnValue;
			}// EO if a failure had occurred

			// get the Generated Keys resultset
			// rs = ps.getGeneratedKeys() ;
			// rs.next() ;

			// get the first column's value
			// /returnValue.setValue(rs.getString(1)) ;
			returnValue.setValue(dtoPk.getColumnData("PK_PROFILE_UPDATE"));

		}
		catch (Exception e)
		{

			Feedback feedbackRetVal = returnValue.getFeedBack();

			feedbackRetVal.setFailure();

			// An error has occured while tring to perform this action
			feedbackRetVal.setErrorCode(28560);
			feedbackRetVal.setException(e);
			ExceptionController.getInstance().handleException(e,this);

		}

		return returnValue;

	}// EOM

	/**
	 * Performs update and returns a DTOSingleValue that includes the unique record ID for the updated record.
	 */
	public final DTOSingleValue doUpdateAndReturnUniqueRecordID(final String sStatement, int iUniqueRecIDIndex, StatementParameter... arrParameters) {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		// Initializes the returned value with the value from the passed StatementParameter[]
		// according to the passed unique record ID index.
		DTOSingleValue returnValue = new DTOSingleValue(arrParameters[iUniqueRecIDIndex].getParameterObject());

		try
		{
			// Tracing.
			String sTraceSelectStatement = ServerUtils.getPreparedStatementFinalString(sStatement, arrParameters);
			sTraceSelectStatement = new StringBuffer(STATEMENT_CONTENT_DO_UPDATE_VALUE).append(sTraceSelectStatement).toString();
			logger.info(sTraceSelectStatement);

			Feedback feedback = this.doUpdate(sStatement, arrParameters, null, null);

			if (!feedback.isSuccessful())
			{
				returnValue.setFeedback(feedback);
				return returnValue;
			}
		}
		catch (Exception e)
		{
			Feedback feedbackRetVal = returnValue.getFeedBack();
			feedbackRetVal.setFailure();
			// An error has occured while tring to perform this action
			feedbackRetVal.setErrorCode(28560);
			feedbackRetVal.setException(e);
			ExceptionController.getInstance().handleException(e,this);
		}

		return returnValue;
	}

	/*public final static String dbTrace(final String sMessage, Object... params) {
		return GlobalTracer.database(sMessage, params);
	}// EOM
*/
	/**
	 * Returns list of populated JPA Objects.
	 * 
	 * @param sSelectStatement - select statement to execute
	 * @param JPAObjectClass - the Class of the JPA Object to be populated
	 * @param iNumOfRows
	 * @return List of JPA Objects populated in List
	 */
	public <T> List<T> getDataRows(String sSelectStatement, Class<T> JPAObjectClass, int iNumOfRows, StatementParameter... arrParameters) {
		Connection finalConn = null;
		PreparedStatement statement = null;
		ResultSet rs = null;
		List<T> reply = new ArrayList<T>();

		try
		{
			finalConn = getConnection(DATA_SOURCE_ID_ACTIVE);

			// No need to add ROWNUM.
			if (iNumOfRows != -1)
			{
				if (iNumOfRows == 0)
				{
					iNumOfRows = MAX_ROW_NUMBER;
				}

				// Add rownum to the select statement.
				sSelectStatement = addRowNumToSelectStatement(sSelectStatement, iNumOfRows, true);

				if (ms_DBType.rownumBindingSupport())
				{

					StatementParameter[] arrFinalParameters = null;
					int iRowNumParamIndex = -1;

					if (arrParameters != null)
					{
						iRowNumParamIndex = arrParameters.length;
						arrFinalParameters = new StatementParameter[arrParameters.length + 1];
						System.arraycopy(arrParameters, 0, arrFinalParameters, 0, arrParameters.length);
					}
					else
					{
						iRowNumParamIndex = 0;
						arrFinalParameters = new StatementParameter[1];
					}// EO else if the arrParameters was null

					arrFinalParameters[iRowNumParamIndex] = new StatementParameter(Integer.valueOf(iNumOfRows), java.sql.Types.NUMERIC);
					arrParameters = arrFinalParameters;
				}// EO if the database type supports row num parameter binding
			}

			// Tracing.
			String sTraceSelectStatement = ServerUtils.getPreparedStatementFinalString(sSelectStatement, arrParameters);
			sTraceSelectStatement = new StringBuffer(STATEMENT_CONTENT_GET_DATA_2).append(sTraceSelectStatement).toString();

			logger.info(sTraceSelectStatement);

			statement = finalConn.prepareStatement(sSelectStatement);
			populatePreparedStatement(statement, arrParameters);
			
			logger.debug("Before executeQuery");
			rs = executeQuery(statement);
			logger.debug("Before populateJPAObjects");
			populateJPAObjects(reply, rs, JPAObjectClass);
			logger.debug("After populateJPAObjects");
		}

		catch (SQLException sqle)
		{
			// setExceptionFeedbackObject(reply, sqle);
			throw new RuntimeException(sqle);
		}
		finally
		{
			releaseResources(rs, statement, finalConn);
		}

		return reply;
	}

	/**
	 * Populates the ResultSet onto the List containing the Class of JPAObject's Type the paratmeters Names and types are reflectivly and cached in
	 * the method's scope
	 */
	public <T> void populateJPAObjects(List<T> reply, ResultSet rs, Class<T> jpaObject) {
		try
		{
			ResultSetMetaData rsmd = rs.getMetaData();
			
			int iColumnCount = rsmd.getColumnCount();
			Object oColumnValue;
			String sColumnName;
			Class clsDbValueType = null, clsSetterMethodParameterType = null;

			// For Each Row
			while (rs.next())
			{
				// Instanciates the JPA object.
				T mainObj = jpaObject.newInstance();
				Class objIdClass = null;
				Object objId = null;
				try
				{
					objIdClass = Class.forName(jpaObject.getCanonicalName() + "Id");
					objId = objIdClass.newInstance();
					Method m = jpaObject.getMethod("setId", objIdClass);
					m.invoke(mainObj, objId);

				}
				catch (Exception e)
				{

				}

				// Loops the columns.
				for (int i = 1; i <= iColumnCount; i++)
				{
					sColumnName = rsmd.getColumnName(i);
					Method setterMethod = getSetterMethod(m_mapJPASetterMethods, jpaObject, sColumnName);
					Object obj = mainObj;
					Class classForSetMethod = jpaObject;
					if (setterMethod == null && objIdClass != null)
					{
						setterMethod = getSetterMethod(m_mapJPASetterMethods, objIdClass, sColumnName);
						obj = objId;
						classForSetMethod = objIdClass;
					}
					if (setterMethod != null)
					{
						oColumnValue = DataType.reverseValueOf(setterMethod.getParameterTypes()[0]).getValue(rs, i);
						try{
							
							clsSetterMethodParameterType = setterMethod.getParameterTypes()[0];
//							if value type does not match to setter method input parameter, use setter method with different input parameter. 
							if (oColumnValue != null && !clsSetterMethodParameterType.isAssignableFrom((clsDbValueType = oColumnValue.getClass()))) { 
								setterMethod = (Method)m_mapJPASetterMethods.get(classForSetMethod.getName() + "." + sColumnName + "." + clsDbValueType.toString());
							}//EO if the value is not null and its type is not the same (or instance of) the parameter type 
							// Sets the value.
							
							setterMethod.invoke(obj, oColumnValue);
						}
						catch (Exception e)
						{
							ExceptionController.getInstance().handleException(e,this);
							throw e;
						}
					}
				}
				reply.add(mainObj);
			}
		}
		catch (Exception e)
		{
			logger.error(e.getMessage());
			throw new RuntimeException(e);
		}
	}
	
	/**
	 * Retrieve the setter Method type of the class ,keep them in the Map for next use..
	 * 
	 * @param hmSetters
	 * @param classObject
	 * @param columnName
	 * @return Method of Setter i.e setFIELD_NAME(Attrtype)
	 */
	private static Method getSetterMethod(Map hmSetters, Class classObject, String columnName) {

		try{

			Column column = null ; 
			String sColumnName = null ; 
			
			if (hmSetters.size() == 0 || !hmSetters.containsKey(classObject.getName() + "." + columnName))
			{
//				loop on every method in the class
				for (Method method : classObject.getMethods()){
					String methodName = method.getName();
					
//					if it is a setter method, verify that the getter method do have column annotation. 
					if (methodName.startsWith("set"))
					{
						String getterMethodName = "g" + methodName.substring(1);
						
						try{ 
							Method getterMethod = classObject.getMethod(getterMethodName);
							
							if (getterMethod != null){
								
								column = getterMethod.getAnnotation(Column.class);
								//if the method does not have a column annotation (e.g. transient or nested embedded class proxy getters
								//use the method name as the column name 
								sColumnName = (column == null ? methodName.substring(3) : column.name() ) ;    
								
	//							map the setter method with method name as a key and mathod name.input parameter type as a key 
	//							because it is posible that there are setter methods with different input parameter types for example:
	//							setAmount(Double)
	//							setAmount(BigDecimal)
								// TODO: consider system's scope cache for this methods (for next fetch of the same Object)
								hmSetters.put(method.getDeclaringClass().getCanonicalName() + "." + sColumnName, method);
								String param = method.getParameterTypes().length > 0 ? "."+method.getParameterTypes()[0].toString() : "";								
								hmSetters.put(method.getDeclaringClass().getCanonicalName() + "." + sColumnName + param, method);
							}//EO if there is a corresponding accessor 
						}catch(Throwable t) { 
							 logger.error(t.getLocalizedMessage());
						}//EO catch block 
						
					}
				}//EO while there are more method in the class 
			}//EO if the methods were not yet cached 
//			else
//			{
//				logger.debug("Found Something !!");
//			}
			return (Method) hmSetters.get(classObject.getName() + "." + columnName);

		}catch (Exception e) {
			// TODO: log..
			throw new RuntimeException(e);
		}//EO catch block 
	}//EOM

	/**
	 * Returns list of populated XmlObject objects.
	 * 
	 * @param sSelectStatement select statement to execute.
	 * @param classXmlObject the Class of the XML Object to be populated.
	 * @return reply list of populated XmlObject objects.
	 */
	public <T extends XmlObject> List<T> getXmlObjectDataRows(String sSelectStatement, Class<T> classXmlObject, int iNumOfRows,
			StatementParameter... arrParameters) {
		Connection finalConn = null;
		PreparedStatement statement = null;
		ResultSet rs = null;
		List<T> reply = null;

		try
		{
			finalConn = getConnection(DATA_SOURCE_ID_ACTIVE);

			// No need to add ROWNUM.
			if (iNumOfRows != -1)
			{
				if (iNumOfRows == 0)
				{
					iNumOfRows = MAX_ROW_NUMBER;
				}

				// Add rownum to the select statement.
				sSelectStatement = addRowNumToSelectStatement(sSelectStatement, iNumOfRows, true);

				if (ms_DBType.rownumBindingSupport())
				{

					StatementParameter[] arrFinalParameters = null;
					int iRowNumParamIndex = -1;

					if (arrParameters != null)
					{
						iRowNumParamIndex = arrParameters.length;
						arrFinalParameters = new StatementParameter[arrParameters.length + 1];
						System.arraycopy(arrParameters, 0, arrFinalParameters, 0, arrParameters.length);
					}
					else
					{
						iRowNumParamIndex = 0;
						arrFinalParameters = new StatementParameter[1];
					}// EO else if the arrParameters was null

					arrFinalParameters[iRowNumParamIndex] = new StatementParameter(Integer.valueOf(iNumOfRows), java.sql.Types.NUMERIC);
					arrParameters = arrFinalParameters;
				}// EO if the database type supports row num parameter binding
			}

			// Tracing.
			String sTraceSelectStatement = ServerUtils.getPreparedStatementFinalString(sSelectStatement, arrParameters);
			sTraceSelectStatement = new StringBuffer(STATEMENT_CONTENT_GET_DATA_2).append(sTraceSelectStatement).toString();

			logger.info(sTraceSelectStatement);

			statement = finalConn.prepareStatement(sSelectStatement);
			populatePreparedStatement(statement, arrParameters);
			rs = executeQuery(statement);

			reply = populateXmlObjects(rs, classXmlObject);
		}

		catch (SQLException sqle)
		{
			throw new RuntimeException(sqle);
		}
		finally
		{
			releaseResources(rs, statement, finalConn);
		}

		return reply;
	}

	/**
	 * Populates the ResultSet onto the List containing the Class of JPAObject's Type the paratmeters Names and types are reflectivly and cached in
	 * the method's scope
	 */
	public <T extends XmlObject> List<T> populateXmlObjects(ResultSet rs, Class<T> classXmlObject) {
		final List<T> reply = new ArrayList<T>();

		try{
			final ResultSetMetaData rsmd = rs.getMetaData();
			final int iColumnCount = rsmd.getColumnCount();

			// STEP 1 -
			// Get the HashMap that includes the mapping between a column name and the
			// 'set' method name.
			final Map<String, String> hmXmlElementNames = CacheKeys.ormMetaDataKey.getSingle(classXmlObject);
			final Map<String, Object> mapLocalChildrenMetadata = new HashMap<String,Object>() ; 
			final DASInterface dasImpl = PluginFactory.get(DASInterface.class);

			// Prepares one time XmlOptions object for creating a new instance of the
			// underlying class of the 'classXmlObject' parameter.
			final String XmlObject_SchemaType_FIELD = "type";
			final SchemaType schemaType = (SchemaType) (classXmlObject.getDeclaredField(XmlObject_SchemaType_FIELD).get(null));
			final XmlOptions options = new XmlOptions();
			options.setDocumentType(schemaType);

			
			//Map<String, ColumnMetaData> columnMap = getColumnsMetaDataHM(rsmd.getTableName(1));
			// Iterates each row in the reply and prepares the parallel object which is
			// from XmlObject type.
			String sXmlElementName = null, sTargetNamespace = null  ;
			XmlObjectBase rootXbean = null, childXbean = null ; 
			LogicalFields childLogicalField = null ; 
			Object oChildLogicalField = null ; 
			DataType enumDataType = null ; 
			Object oValue = null ;
			while (rs.next()) {
				//T obj = (T) XmlObject.Factory.newInstance(options);
				rootXbean = (XmlObjectBase) XmlObject.Factory.newInstance(options);
				
				// Loops the columns.
				for (int i = 1; i <= iColumnCount; i++){
					
					String sColumnName = rsmd.getColumnName(i);
					
					//attempt to extract the already cached logical field from the mapLocalChildrenMetadata
					//if the field was not yet rertieved, retreive its logical field and cache it against 
					//Note: store against the column name rather than the logical field id as field id can be derived from the 
					//logical field instance 
					oChildLogicalField = mapLocalChildrenMetadata.get(sColumnName) ; 
					
					//if the entry is a MissValue placeholder continue ;   
					if(oChildLogicalField == null ) { 
						sXmlElementName = hmXmlElementNames.get(sColumnName); 
						if(sXmlElementName == null) {
							mapLocalChildrenMetadata.put(sColumnName, MissValue.PlaceHolder) ; 
							continue ; 	
						}//EO if the mapping did not define an xml element - logical field) for the given column name  
						//else 
						oChildLogicalField = CacheKeys.LogicalFieldsIdKey.getSingle(sXmlElementName) ; 
						mapLocalChildrenMetadata.put(sColumnName, oChildLogicalField) ; 
						
					}//EO if the logical field local cached metadata was not yet initialized
					else if(oChildLogicalField == MissValue.PlaceHolder) continue ;
					//else 
					
					childLogicalField = (LogicalFields) oChildLogicalField ; 
					//assign the logical field id as the xml node name as per the convension 
					
					if (childLogicalField == null)
					{
						System.out.println(childLogicalField);
					}
					sXmlElementName = childLogicalField.getFieldLogicalId() ; 
					
					if(sTargetNamespace == null) sTargetNamespace = rootXbean.get_schema_type().getName().getNamespaceURI() ; 
					
					childXbean = dasImpl.getOrCreateXmlNode(sXmlElementName, sXmlElementName, rootXbean, sTargetNamespace, false /*multi occurrence*/);
					
					try{ 
						enumDataType = childLogicalField.getDataType() ;
						oValue = enumDataType.getValue(rs, i) ;
						//set the object in the new xbean using the data type enum 
						enumDataType.setXbeanValue(childXbean, oValue) ;
					}catch (Exception e) {
						ExceptionController.getInstance().handleException(e,this);
					}//EO catch block  
							
				}//EO while there are more children (columns)  

				reply.add((T) rootXbean);
			}//EO while there are more result setst 
		
		}catch (Exception e) {
			throw new RuntimeException(e);
		}//EO catch block  

		return reply;
	}//EOM 

	public static final void populateStatement(String sTraceStatement, final PreparedStatement statement, Object... arrBindingParams)
			throws SQLException {

		//final GlobalTracer logger = Admin.m_contextTracer.get();

		final int iLength = arrBindingParams.length;
		Object oFieldValue = null;
		String sParamValue = null;
//		final ParameterMetaData parameterMetadata = statement.getParameterMetaData();

		for (int i = 0; i < iLength; i++)
		{

			oFieldValue = arrBindingParams[i];

			com.fundtech.util.GlobalUtils.setObject(statement, i + 1, oFieldValue);

			if (logger.isInfoEnabled())
			{
				final String STANDARD_DATE_PATTERN = "yyyy-MM-dd";
				final String DATE_TEMPLATE = "TO_DATE('%s', 'yyyy-mm-dd')";
				final SimpleDateFormat STANDARD_DATE_FORMAT = new SimpleDateFormat(STANDARD_DATE_PATTERN);

				if (oFieldValue == null) sParamValue = "NULL";
				else
				{
					final DataType enumDataType = DataType.reverseValueOf(oFieldValue);
					final int dataType = enumDataType.getSqlDataType();

					if (dataType == Types.VARCHAR) sParamValue = (oFieldValue == null ? "''" : (sParamValue = "'" + oFieldValue + '\''));
					else if (oFieldValue == null && (dataType == Types.NUMERIC || dataType == Types.DECIMAL)) sParamValue = "null";
					else if (oFieldValue != null && (dataType == Types.DATE || dataType == Types.TIMESTAMP)) sParamValue = String.format(DATE_TEMPLATE, STANDARD_DATE_FORMAT
							.format(oFieldValue));
					else sParamValue = oFieldValue == null ? "" : oFieldValue.toString();
				}// EO if the value was not null

				sTraceStatement = sTraceStatement.replaceFirst("\\?", sParamValue);
			}// EO if the trace level was database

		}// EO while there are more binding params

		logger.info("Populated the following Satement:\n\t" + sTraceStatement);

	}// EOM
	
	public String getMIDAccordingToInstrId(String instrId) throws Exception
	{
		String query = "select p_mid from minf where P_INSTR_ID = ? and p_is_history = 0 ";
		Connection con = null;
		ResultSet rs = null;
		PreparedStatement ps = null;
		String mid = null;
		
		try
		{
			con = getDataSource().getConnection();
			ps = con.prepareStatement(query);
			ps.setString(1, instrId) ;
			rs = ps.executeQuery();
			
			while (rs.next())
			{
				mid = rs.getString(1);
			}
			
		}finally 
		{
			releaseResources(rs, ps, con);
		}
		return mid;
	}

	/**
	 * Returns the database system DATE & TIME, which is in format of 'yyyy-MM-dd HH:mm:ss'.
	 */
	public final String getSystemDateAndTimeFromDatabase() {
		String SELECT_STATEMENT = "SELECT " + ms_DBType.getCurrentDateKeyword() + " FROM " + ms_DBType.getDummyTableName();

		DTOSingleValue dto = this.getSingleValue(SELECT_STATEMENT, null);

		return dto.getValue();
	}// EOM

}
