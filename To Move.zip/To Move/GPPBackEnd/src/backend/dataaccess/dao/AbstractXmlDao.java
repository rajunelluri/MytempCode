package backend.dataaccess.dao;



import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.xml.serialize.OutputFormat;
import org.apache.xml.serialize.XMLSerializer;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlObjectBase;
import org.w3c.dom.Document;

import backend.dataaccess.dao.AbstractXmlDao.CommandInfo.NodeGroupInfo;
import backend.dataaccess.dao.AbstractXmlDao.CommandInfo.NodeInfo;
import backend.dataaccess.dao.xquerygenerators.GenerateSingleExtractValueClause;
import backend.dataaccess.dto.DTODataHolder;
import backend.dataaccess.dto.DTOSingleValue;
import backend.dataaccess.dto.IterableResultSet;
import backend.util.ServerConstants;

import com.fundtech.cache.entities.LogicalFields;
import com.fundtech.cache.entities.LogicalFieldsXpath;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.general.PluginFactory;
import com.fundtech.core.general.StatementParameter;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.das.DASInterface;
import com.fundtech.core.paymentprocess.data.das.DASInterface.XmlLocationType;
import com.fundtech.core.paymentprocess.data.fields.FieldType;
import com.fundtech.core.paymentprocess.data.paymenttypes.PaymentType;
import com.fundtech.jndi.ServiceLocator;
import com.fundtech.util.DBTypeInterface;
import com.fundtech.util.ExceptionController;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author guys
 * 
 * Super class defining the contruct for database xml columns handling.
 * 
 * Provides the means to perform the following actions: 
 * 1. Single String value extraction  
 * 2. XML Subset or column recrod content extraction (per single column).
 * 4. Combined relational data and XML multiple records retrieval. 
 * 3. XML node updates.
 *
 *	NOTE: 
 *
 *  All XML nodes are considered fullly qualified and comprised of two parts : <namespace>:<local element name>. 
 *	Thus in order to access a given element, the default behaviour dictates that the namespace (or a prefix alias 
 *	which might be nothing if so declared in the xmlns prolog) must be defined along with the element name. 
 *	In order to emulate a namespce unaware behaviour, all elments must be prefixed by one of the following delerations: 
 *	1.  *:<element local name> - defines the element as belonging to all namespaces. 
 *	2.  *[local-name()="<element local name>"]
 *	3.  *[name()="<element local name>"]
 *	As writing and maintaing xpaths containing such declarations is unreasonably tedious, all methods in this class 
 *	provide the following facility: 
 *		If the namespce is provided, the methods will declare it as the default element namespace thus alliviating 
 *		the neeed for namespace prefix.
 *		Otherwise if the namespace was not provided, the methods will modify all xpath queries provided 
 *		to include either the first or the third aforementioned option. 
 *		Please adhere be the following rules while developing an xpath query: 
 *		1. xpath might already be enriched by the '*:' namespace, in which case, the methods will not modify the xpath. 
 *		   This behaviour is applied to each xpath element individually (i.e. those nodes declared without the 
 *		   prefix would be modified while those containing the declaration will not). 
 *		2. xpath must not contain the local() or local-name() declaration in conjunction with null namespace 
 *		   as the methods will not check for the existence of the constructs, and will hence render the xpath 
 *		   query invalid by adding the construct again.
 *		   In other words, when providing no namespace, provide xpath queries that do not contain 
 *		   namespace declaration. The various method will ensure that those are added.
 *		 
 *	 	Note: currently, a single namespace declaration is supported through this method. Nevertheless, as the db syntax 
 *	 	 * 		 supports multiple namespace declarations, if the need arises, the method could be altered to accomodate it.
 *	 	 * 		 The current implementation, for convenience sake, decalres a no-prefix namespace so that the elementXPath
 *		 * 		 value should not be altered to include the namespace prefix.
 *
 */
public abstract class AbstractXmlDao extends DAOBasic implements GenerateSingleExtractValueClause{

	private final static Logger logger = LoggerFactory.getLogger(AbstractXmlDao.class);

	/** DOM document to string output format*/ 
	private OutputFormat outputFormat = null ; 
	  
	/** 
	 * Query consrtuction constants and formatter tempaltes
	 */
	protected static final String WHERE_CLAUSE_START = " WHERE " ; 
	protected static final String FROM_CLAUSE = " FROM " ;
	protected static final String XML_RESULT_COLUMN_NAME = "XML_RESULT" ; 
	protected static final String TEXT_VALUE = "/text()" ;
	
	protected static PaymentType[] m_arrDBColumnCasePaymentTypes  ; 
		
	/*
	 * 1 - table name. 
	 * 2 - column names 
	 */
	private static final String UPDATE_TEMPLATE = "update %s set %s " ;
	
	/*
	 * 1 - namespace  
	 */
	protected static final String NS_DECLAREATION_TEMPLATE = "declare default element namespace \"%s\"; " ;
	/*
	 * 1 - declare namspace clause  
	 * 2 - root xpath 
	 * 3 - passing by type ('by ref', 'by value'  or '')
	 * 4 - column name
	 * 5 - returning clause ('returning content' or '')
	 * 6 - table name 
	 */
 	protected static final String SINGLE_VALUE_SELECT_STATEMENT_TEMPLATE = 
 		"select xmlserialize(content xmlquery('%s $doc%s' passing %s %s as \"doc\" %s) as varchar(4000)) as XML_RESULT from %s " ;
  
 	/*
	 * 1 - columns 
	 * 2 - tables  
	 * 3 - where claue 
	 */
	private static final String SELECT_XML_TEMPLATE = "select %s from %s " ; 
	
	/*
	 * 1 - declare namspace clause  
	 * 2 - 1..n for each statememts string 
	 * 3 - passing by type ('by ref', 'by value'  or '')
	 * 4 - column name
	 * 5 - returning clause ('returning content' or '')
	 */
	private static final String OVERALL_SELECT_TEMPLATE = "xmlquery('%s<root>%s</root>' passing %s %s as \"doc\" %s) as XML_RESULT" ;
	/*
	 * 1x2 - parent element xpath end node
	 * 2   - 1..n sub nodes string
	 */
	private static final String FOR_EACH_MULTIPLE_RETURN_ELEMENTS_TEMLPATE =  "<%1$s>%2$s</%1$s>" ;	
	/*
	 * 1 - parent element xpath 
	 * 2 - return elements clause  
	 */
	private static final String FOR_EACH_SELECT_TEMPLATE = "{for $e in $doc%1$s return %2$s}" ;
	
	/*
	 * 1 - xpath relative to the parent xpath defined as $e 
	 */
	private static final String FOR_EACH_RETURN_ELEMENT_TEMLPATE_MULTIPLE_CHILDREN  = "{$e%s}" ;
	/*
	 * 1 - xpath relative to the parent xpath defined as $e 
	 */
	private static final String FOR_EACH_RETURN_ELEMENTS_TEMLPATE_SIGNLE_CHIILD =  "$e%s" ;

	private static final String RELATIVE_ROOT_ELEMENT_NAME = "$e" ; 
	/*
	 * Purpose: get the last defined node name exclusive of '*'
	 * 
	 * Explanation: 
	 * capture one or more chars which are not '*' preceeded by one or two '/' and followed by 'End of input' 
	 * or 
	 * one or two '/' followed by '*'  
	 */
	//private static final String LAST_NODE_NAME_REGEX_STRING = ".*/([^*]+?)$|.*/([^*]+?)/{1,2}\\*" ;
	private static final String LAST_NODE_NAME_REGEX_STRING = ".*/([^*]+?)(?:$|(?:/{1,2}\\*))" ; 
	private static final Pattern LAST_NODE_NAME_REGEX = Pattern.compile(LAST_NODE_NAME_REGEX_STRING) ;
	
	public static final String COMMON_TYPES_NS_PREFIX = "fndt" ; 
	public static final String COMMON_TYPES_NS = "http://fundtech.com/SCL/CommonTypes" ;
	
	static { 
		initialisePaymentTypes() ; 
	}//EO static block 
	
	public static final void initialisePaymentTypes() {
		final String ALL_PAYMENT_TYPES_STATEMENT = "SELECT XDT.DOCUMENT_ID,\r\n" + 
		"       XDT.ROOT_LOCAL_NAME,\r\n" + 
		"       XDT.NAMESPACE,\r\n" + 
		"       XDT.ADDITIONAL_NAMESPACES,\r\n" + 
		"       XDT.CLASS_NAME,\r\n" + 
		"       XDT.SCHEMA_LOCATION,\r\n" + 
				"		XDT.VALIDATOR_CLASS,\r\n" + 
		"       XDT.XML_LOCATION_TYPE,\r\n" + 
		"       (CASE\r\n" + 
		"         WHEN DOCUMENT_ID IN\r\n" + 
		"              (SELECT DISTINCT FORMAT_TYPE FROM XML_FORMAT_TYPE_RELATIONS) THEN\r\n" + 
		"          0\r\n" + 
		"         ELSE\r\n" + 
		"          1\r\n" + 
		"       END) ROOT_ELEMENT_DERIVATION,\r\n" + 
				"       TRNS_READER_CLASS_NAME\r\n " +
		"  FROM XML_DOCUMENT_TYPES XDT\r\n" + 
		"UNION\r\n" + 
		"SELECT DISTINCT XFR.FORMAT_TYPE,\r\n" + 
		"                XDT.ROOT_LOCAL_NAME,\r\n" + 
		"                XDT.NAMESPACE,\r\n" + 
		"                XDT.ADDITIONAL_NAMESPACES,\r\n" + 
		"                XDT.CLASS_NAME,\r\n" + 
		"                XDT.SCHEMA_LOCATION,\r\n" + 
				"				 XDT.VALIDATOR_CLASS,\r\n" + 
		"                XDT.XML_LOCATION_TYPE,\r\n" + 
		"                0 ROOT_ELMENT_DERIVATION,\r\n" + 
				"       		 '' TRNS_READER_CLASS_NAME\r\n " +
		"  FROM XML_FORMAT_TYPE_RELATIONS XFR\r\n" + 
		" INNER JOIN XML_DOCUMENT_TYPES XDT ON XFR.XML_TYPE = XDT.DOCUMENT_ID\r\n" + 
		" WHERE XFR.FORMAT_TYPE NOT IN\r\n" + 
		"       (SELECT DISTINCT DOCUMENT_ID FROM XML_DOCUMENT_TYPES)\r\n" + 
		"   AND XDT.REC_STATUS = 'AC'\r\n" + 
		"   AND EX_PATH_PARENT_ID IS NULL\r\n" + 
		" ORDER BY ROOT_ELEMENT_DERIVATION DESC";

		
		final String ACTUAL_XML_TYPES_STATEMENT = "SELECT DOCUMENT_ID FROM XML_DOCUMENT_TYPES WHERE DOCUMENT_ID IN (" +  
				"SELECT DISTINCT XML_TYPE FROM LOGICAL_FIELDS_XPATH WHERE XML_LOCATION_TYPE IS NOT NULL AND REC_STATUS = 'AC' )" ;
		
		Connection conn = null ; 
		PreparedStatement ps = null ; 
		ResultSet rs = null ;
		
		final Set<PaymentType> setDBCasePaymentTypes = new HashSet<PaymentType>() ;
		
		//first initailise all payment types 
		try{
			conn = new DAOBasic().getConnection() ;
			
			ps = conn.prepareStatement(ALL_PAYMENT_TYPES_STATEMENT) ; 
			rs = ps.executeQuery() ; 
				
				//initialise the payment type enumeration 
			PaymentType.init(new IterableResultSet(rs)) ;
			 			 
			 //now initialize all actual xml types (the ones used for xml queries)  
			 for(PaymentType enumPaymentType : PaymentType.values()) {  
				 if(enumPaymentType.usedForDBCases()) setDBCasePaymentTypes.add(enumPaymentType) ;
			 }//EO while there are more payment types 
		
		}catch(Throwable t) { 
			 ExceptionController.getInstance().handleException(t, null) ;
		 }finally{
			 try{ 
				 DAOBasic.releaseResources(new Object[]{rs, ps, conn } ) ;
			 }catch(Exception e) { 
				 ExceptionController.getInstance().handleException(e, null) ; 
			 }//EO inner catch block 
		 }//EO catch block 
		  
	  //finally initialise the payment type array 
	  m_arrDBColumnCasePaymentTypes = new PaymentType[setDBCasePaymentTypes.size()] ; 
	  setDBCasePaymentTypes.toArray(m_arrDBColumnCasePaymentTypes) ; 
	}//EOM 
 	
	public AbstractXmlDao() {
		super();
	}//EOM
	
	/**
	 * Constructs and exeuctes a sql/xml query which should supposdely yeild a single string value. 
	 * nevertheless, the method is constrcuted to convert any returned xml to string where the query 
	 * execution yeilded xml instead. 
	 * 
	 * An Exmample: 
	 * 
	 * select xmlserialize(
	 * 	xmlquery(
	 * 		'declare default element namespace "urn:iso:std:iso:20022:tech:xsd:pacs.008.001.01";  
	 * 		$doc//CdtTrfTxInf[1]/PmtId/TxId/text()' 
	 *   passing by ref x_contents as "doc"
	 *  ) as varchar(4000)
	 * ) as XML_RESULT 
	 * from xml_test   
	 * WHERE Code = 6
	 * 
	 * Note: will always alias the result value as 'XML_RESULT' 
	 * 
	 * @param sTablename   DB table name on which to perform the select statement. 
	 * @param sXmlColumnname DB column name from which to extract values.
	 * @param sWhereClause Additional filter, unrelated to the xml column.
	 * @param sElementXPath XPath yeilding the node list required
	 * @param sNamespace All XML nodes are considered fullly qualified and comprised of two parts : <namespace>:<local element name>. 
	 *	Thus in order to access a given element, the default behaviour dictates that the namespace (or a prefix alias 
	 *	which might be nothing if so declared in the xmlns prolog) must be defined along with the element name. 
	 *	In order to emulate a namespce unaware behaviour, all elments must be prefixed by one of the following delerations: 
	 *	1.  *:<element local name> - defines the element as belonging to all namespaces. 
	 *	2.  *[local-name()="<element local name>"]
	 *	3.  *[name()="<element local name>"]
	 *	As writing and maintaing xpaths containing such declarations is unreasonably tedious, all methods in this class 
	 *	provide the following facility: 
	 *		If the namespce is provided, the methods will declare it as the default element namespace thus alliviating 
	 *		the neeed for namespace prefix.
	 *		Otherwise if the namespace was not provided, the methods will modify all xpath queries provided 
	 *		to include either the first or the third aforementioned option. 
	 *		Please adhere be the following rules while developing an xpath query: 
	 *		1. xpath might already be enriched by the '*:' namespace, in which case, the methods will not modify the xpath. 
	 *		   This behaviour is applied to each xpath element individually (i.e. those nodes declared without the 
	 *		   prefix would be modified while those containing the declaration will not). 
	 *		2. xpath must not contain the local() or local-name() declaration in conjunction with null namespace 
	 *		   as the methods will not check for the existence of the constructs, and will hence render the xpath 
	 *		   query invalid by adding the construct again.
	 *		   In other words, when providing no namespace, provide xpath queries that do not contain 
	 *		   namespace declaration. The various method will ensure that those are added.
	 *		 
	 *	 	Note: currently, a single namespace declaration is supported through this method. Nevertheless, as the db syntax 
	 *	 	 * 		 supports multiple namespace declarations, if the need arises, the method could be altered to accomodate it.
	 *	 	 * 		 The current implementation, for convenience sake, decalres a no-prefix namespace so that the elementXPath
	 *		 * 		 value should not be altered to include the namespace prefix.
	 * @param externalConnection external SQL connection. 
	 * Note: If null, a new connection would be created in the method and disposed at its end. 
	 * Note: Will close the connection at the end of the method IFF the latter was craeted in the method scope.
	 * @return String result of the sql/xml exeuction. 
	 * Note: will return null in event failure. 
	 */
	public final String getSingleValue(
			final String sTablename, 
			final String sXmlColumnname, 
			final String sWhereClause, 
			String sElementXPath, 
			final String sNamespace, 
			final Connection externalConnection) { 
		
		PreparedStatement ps =  null ; 
		ResultSet rs = null ; 
		String sResult = null ; 
		Connection internalConnection = null ;  
		try{ 
			final StringBuilder builder = new StringBuilder() ; 
			
			String sNsDecleration =  null ; 
			
			//Constructs the declare namespace
			//if the namespace was null (not provided, modify the xpath to ignore the namespace 
			if(sNamespace !=  null) { 
				sNsDecleration = String.format(NS_DECLAREATION_TEMPLATE, sNamespace) ;
			}else { 
				sNsDecleration = ServerConstants.EMPTY_STRING ;
				sElementXPath = this.modifyXpathToIgnoreNamespace(sElementXPath) ;
			}//EO else if there was no name space 
							
			//if the xpath does not end with '/text()' append it 
			if(!sElementXPath.toLowerCase().endsWith(TEXT_VALUE) ) sElementXPath = sElementXPath + TEXT_VALUE ;
			
			/*
			 * 1 - declare namspace clause  
			 * 2 - root xpath 
			 * 3 - passing by type ('by ref', 'by value'  or '')
			 * 4 - column name
			 * 5 - returning clause ('returning content' or '')
			 * 6 - table name 
			 */
			builder.append(String.format(SINGLE_VALUE_SELECT_STATEMENT_TEMPLATE, 
					sNsDecleration, 
					sElementXPath, 
					this.getXQueryPassingByTypeString(),  
					sXmlColumnname, 
					this.getXQueryPassingReturnClasueString(), 
					sTablename)) ; 
			
			if(sWhereClause != null) builder.append(' ').append(WHERE_CLAUSE_START).append(sWhereClause) ; 
									
			final String sQuery = builder.toString() ; 
			
			logger.info("QUERY:\n"+sQuery+"\n");
		
			//if the formal arg connection was null, create a new connection 
			internalConnection = (externalConnection != null ? externalConnection : this.getConnection()) ;
			
			ps = internalConnection.prepareStatement(sQuery) ; 

			rs  = ps.executeQuery() ; 		
			
			if(rs.next()) { 
				//get the value of the XML_RESULT_COLUMN_NAME
				sResult = rs.getString(XML_RESULT_COLUMN_NAME) ; 
			}//EO if the query yielded results 
			
		}catch(Exception sqle) { 
			ExceptionController.getInstance().handleException(sqle, this) ; 
		}finally{ 
			//do not dispose of the connection as it scoped outside of this method
			 this.dispose(rs, ps, (externalConnection != null ? null : internalConnection)) ; 
		}//EO catch block
		
		return sResult ;
	}//EOM 

	/**
	 * Constructs and exeuctes a sql/xml query to update multiple nodes within a single given xml column 
	 * Note: uses the opened connection provided in the commandInfo or creates a new one if the former was not 
	 * provided.
	 * Note: Will close the connection at the end of the method IFF the latter was craeted in the method scope.
	 * 
	 * NOTE: 
	 * All XML nodes are considered fullly qualified and comprised of two parts : <namespace>:<local element name>. 
	 *	Thus in order to access a given element, the default behaviour dictates that the namespace (or a prefix alias 
	 *	which might be nothing if so declared in the xmlns prolog) must be defined along with the element name. 
	 *	In order to emulate a namespce unaware behaviour, all elments must be prefixed by one of the following delerations: 
	 *	1.  *:<element local name> - defines the element as belonging to all namespaces. 
	 *	2.  *[local-name()="<element local name>"]
	 *	3.  *[name()="<element local name>"]
	 *	As writing and maintaing xpaths containing such declarations is unreasonably tedious, all methods in this class 
	 *	provide the following facility: 
	 *		If the namespce is provided, the methods will declare it as the default element namespace thus alliviating 
	 *		the neeed for namespace prefix.
	 *		Otherwise if the namespace was not provided, the methods will modify all xpath queries provided 
	 *		to include either the first or the third aforementioned option. 
	 *		Please adhere be the following rules while developing an xpath query: 
	 *		1. xpath might already be enriched by the '*:' namespace, in which case, the methods will not modify the xpath. 
	 *		   This behaviour is applied to each xpath element individually (i.e. those nodes declared without the 
	 *		   prefix would be modified while those containing the declaration will not). 
	 *		2. xpath must not contain the local() or local-name() declaration in conjunction with null namespace 
	 *		   as the methods will not check for the existence of the constructs, and will hence render the xpath 
	 *		   query invalid by adding the construct again.
	 *		   In other words, when providing no namespace, provide xpath queries that do not contain 
	 *		   namespace declaration. The various method will ensure that those are added.
	 *		 
	 *	 	Note: currently, a single namespace declaration is supported through this method. Nevertheless, as the db syntax 
	 *	 	 * 		 supports multiple namespace declarations, if the need arises, the method could be altered to accomodate it.
	 *	 	 * 		 The current implementation, for convenience sake, decalres a no-prefix namespace so that the elementXPath
	 *		 * 		 value should not be altered to include the namespace prefix.
	 * 
	 * @param commandInfo Class containg all required data for the consturction of a given xml sql query.
	 * @return Number of rows updated. 
	 * Note: Returns -1 if an error had occured .
	 * @throws SQLException
	 */
	public int update(CommandInfo commandInfo) throws SQLException {
		
		final ProcessingContext ctx = new ProcessingContext(commandInfo) ;
		 
		final String sQuery = this.constructUpdateQuery(ctx) ;

		PreparedStatement ps = null ;
		int iUpdatedRowsNumber = -1 ; 
		Connection internalConnection = null ;
		
		try{ 
			logger.info("QUERY:\n"+sQuery+"\n");

			//if the commandInfo connection was null, create a new connection 
			internalConnection = (commandInfo.getConnection() != null ?  commandInfo.getConnection() : this.getConnection()) ;
			
			ps = internalConnection.prepareStatement(sQuery) ;
					
			//add the 
			int iCounter = 1 ; 
			for(String sValue : ctx.getBindParamValuesList()) { 
				ps.setString(iCounter++, sValue) ;
			}//EO while there are more parameters to bing
			
			//if there are additional binding paramters provided by the client code 
			//add them as well 
			this.populatePreparedStatementForUpdate(ps, iCounter-1, commandInfo.getStatementParameters()) ; 
						
			iUpdatedRowsNumber = ps.executeUpdate() ; 
			
		}catch(Exception e) { 
			logger.error(e.getMessage());
		}finally{ 
			//do not dispose of the connection as it scoped outside of this method
			this.dispose(ps, (commandInfo.getConnection() != null ? null : internalConnection)) ;
		}//EO catch block 
		 			 
		return iUpdatedRowsNumber ;  
	}//EOM		
	
	/**
	 * Hook method used in the getXML() 
	 * @return The context specific type of the passing by clause 
	 * 
	 * Possible context values: 
	 * Oracle: empty String or 'BY VALUE'
	 * DB2:    'by ref' 
	 */
	protected abstract String getXQueryPassingByTypeString() ;
	
	public abstract void setNullToXmlColumn(PreparedStatement ps, int inx)  throws SQLException;
	
	/**
	 * Dec 26, 2007
	 * guys
	 *
	 * @return int repersentation of the prorietary data type
	 */
	protected abstract int getXmlColumnDataType() ;
	
	public static final PaymentType[] getDBXmlTypes() { return m_arrDBColumnCasePaymentTypes ; }//EOM

	
	/**
	 * Hook method used in the getXML() 
	 * @return The context specific 'Return' block of the 'passing' clasue.
	 * 
	 * Possible context values: 
	 * Oracle: 'returning content' 
	 * DB2:    empty String 
	 */
	protected abstract String getXQueryPassingReturnClasueString() ;
	 
	
	/**
	 * 
	 * Hook method used in the getXML() 
	 * 
	 * Extracts and returns an input stream containing XML data.
	 * 
	 * Note: does not close the ResultSet. 
	 * 
	 * @param rs opened ResultSet to extract the xml input stream from.
	 * @param sColumnName Column name in which the xml data is stored.
	 * @return xml DOM Document. 
	 * @throws SQLException
	 */
	protected abstract Document getDomDocument(ResultSet rs, String sColumnName) throws Exception ; 
	
	public abstract XmlObjectBase getColumnContent(ResultSet rs, String sColumnName) throws Exception ; 
	
	/**
	 * Exeuctes a SQL/XML query on an XML typed column and returns a DOM document.
	 * Note: As the query might return a list of nodes rather then a well-formed document 
	 * 		 a wrapper root element named 'root' would always exist. 
	 * Note: If the query yeilds no results, the root element would be returned empty. 
	 * Note: Root element has the name space value of the namespace formal arg value.
	 * Note: Will close the connection at the end of the method IFF the latter was craeted in the method scope.
	 * Note: query returing a single text value is valid as the return document is always 
	 * 	     enclosed with the 'root; element 
	 * 
	 * @param tablename DB table name on which to perform the select statement. 
	 * @param xmlColumnname DB column name from which to extract values.
	 * @param whereClause Additional filter, unrelated to the xml column.
	 * Note: should not contain the 'WHERE' keyword. 
	 * @param elementXPath XPath yeilding the node list required
	 * Note: Generated xQuery always contains a loop construct using the following tempalte : for $e in $doc<xpath> return $e
	 * therefore, it is permitted to append an xquery-where-clause to the xpath using the $e or the $doc as the root elements 
	 * for any required condition xpath as such: elementXPath = '//Id where $doc/otherNode = 'value'  
	 * @param sNamespace All XML nodes are considered fullly qualified and comprised of two parts : <namespace>:<local element name>. 
	 *	Thus in order to access a given element, the default behaviour dictates that the namespace (or a prefix alias 
	 *	which might be nothing if so declared in the xmlns prolog) must be defined along with the element name. 
	 *	In order to emulate a namespce unaware behaviour, all elments must be prefixed by one of the following delerations: 
	 *	1.  *:<element local name> - defines the element as belonging to all namespaces. 
	 *	2.  *[local-name()="<element local name>"]
	 *	3.  *[name()="<element local name>"]
	 *	As writing and maintaing xpaths containing such declarations is unreasonably tedious, all methods in this class 
	 *	provide the following facility: 
	 *		If the namespce is provided, the methods will declare it as the default element namespace thus alliviating 
	 *		the neeed for namespace prefix.
	 *		Otherwise if the namespace was not provided, the methods will modify all xpath queries provided 
	 *		to include either the first or the third aforementioned option. 
	 *		Please adhere be the following rules while developing an xpath query: 
	 *		1. xpath might already be enriched by the '*:' namespace, in which case, the methods will not modify the xpath. 
	 *		   This behaviour is applied to each xpath element individually (i.e. those nodes declared without the 
	 *		   prefix would be modified while those containing the declaration will not). 
	 *		2. xpath must not contain the local() or local-name() declaration in conjunction with null namespace 
	 *		   as the methods will not check for the existence of the constructs, and will hence render the xpath 
	 *		   query invalid by adding the construct again.
	 *		   In other words, when providing no namespace, provide xpath queries that do not contain 
	 *		   namespace declaration. The various method will ensure that those are added.
	 *		 
	 *	 	Note: currently, a single namespace declaration is supported through this method. Nevertheless, as the db syntax 
	 *	 	 * 		 supports multiple namespace declarations, if the need arises, the method could be altered to accomodate it.
	 *	 	 * 		 The current implementation, for convenience sake, decalres a no-prefix namespace so that the elementXPath
	 *		 * 		 value should not be altered to include the namespace prefix.
	 * Note: The namespace value provided here would be declared in the enclosing 'root' root element.
	 * @param externalConnection external SQL connection. 
	 * Note: If null, a new connection would be created in the method and disposed at its end. 
	 * Note: Will close the connection at the end of the method IFF the latter was craeted in the method scope.
	 * @return DOM document containing the query results and enclosed by 'root' root element declaring the 
	 * namespace formal arg's value namespace (using no prefix); 
	 * Note: In failure scenarios, returns null.
	 */
	public DTOSingleValue getSingleXMLDocument(final CommandInfo commandInfo) {
 		
		ProcessingContext ctx = new ProcessingContext(commandInfo) ;
		final String sQuery = this.constructSelectXmlQuery(ctx) ; 
		
		System.out.printf("QUERY:%n%s%n", sQuery);
					
		return this.getSingleValue(sQuery, commandInfo.getStatementParameters(), commandInfo.getConnection()) ; 

	}//EOM 
	
	/**
	 * Executes a SQL/XML query on a possible combination of relational and XML columns 
	 * and returns a DTOSingleValue containing all returned records. 
	 * Note: Currenly a signe XML column (and possibly multiple relational ones) query is supported. 
	 * Note: XML column name XML_RESULT and it is unmodifyable.
	 * Note: suports multiple relative child nodes per root node xpath per query.  
	 * Note: supports Multiple root node XPapth per query.
	 * Note: every result document will contain a 'root' root element as there is no was of knowing whether the 
	 * 	     result xml would contain one and a result might not be considered well formed. 
	 * Note: Supports Parameter bindings 
	 * Note: if the commandInfo's query template value is provided, will use it as the query statement, replacing the place holder 
	 * 	     with the generated xml column retrieval. If the former is not provided, will construct a complete query using the 
	 * 		 commandInfo's table name and additional where clause.
	 * 
	 * @please refer to Appendix A - unit testing 'XML Typed Database Columns' document for usage examples.
	 * 
	 *  Query Examples: 
	 * 
	 *  Query:
	 *  select xmlquery('declare default element namespace "urn:iso:std:iso:20022:tech:xsd:pacs.008.001.01"; <root>{for $e in $doc//pacs.008.001.01/GrpHdr return $e/MsgId}</root>' passing  x_contents as "doc" returning content) as XML_RESULT from xml_test  WHERE code = 6 AND ROWNUM <= 1500 
	 *    
	 *  Result:  
	 *  <root xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.01">
    		<MsgId xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.01">aaa</MsgId>
		</root>
	 *  
	 *  Query:
	 * 	select xmlquery('<root>{for $e in $doc//*:pacs.008.001.01/*:GrpHdr return $e/*:MsgId}</root>' passing  x_contents as "doc" returning content) as XML_RESULT from xml_test  WHERE code = 6 AND ROWNUM <= 1500  
	 * 
	 *  Result:
	 *  <root>
		    <MsgId xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.01">aaa</MsgId>
		</root>

	 *  Query:
	 *	select xmlquery('<root>{for $e in $doc//*:pacs.008.001.01/*:GrpHdr return <GrpHdr>{$e/*:MsgId}{$e/*:SttlmInf/*:SttlmMtd}{$e//*:TtlIntrBkSttlmAmt}</GrpHdr>}</root>' passing  x_contents as "doc" returning content) as XML_RESULT from xml_test  WHERE code = 6 AND ROWNUM <= 1500 
	 *  
	 *  Result:
	 * <root>
		    <GrpHdr>
		        <MsgId xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.01">aaa</MsgId>
		        <SttlmMtd xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.01">INDA</SttlmMtd>
		        <TtlIntrBkSttlmAmt Ccy="USD" xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.01">bbb</TtlIntrBkSttlmAmt>
		    </GrpHdr>
		</root>
	 *  
	 *  
	 *  XML Clasue:
	 *	xmlquery('declare default element namespace "urn:iso:std:iso:20022:tech:xsd:pacs.008.001.01"; <root>{for $e in $doc//pacs.008.001.01/GrpHdr return $e/MsgId}{for $e in $doc//*:pacs.008.001.01/*:GrpHdr return $e/*:MsgId}{for $e in $doc//*:pacs.008.001.01/*:GrpHdr return <GrpHdr>{$e/*:MsgId}{$e/*:SttlmInf/*:SttlmMtd}{$e//*:TtlIntrBkSttlmAmt}</GrpHdr>}{for $e in $doc//pacs.008.001.01/GrpHdr return <GrpHdr>{$e/MsgId}{$e/SttlmInf/SttlmMtd}{$e//TtlIntrBkSttlmAmt}</GrpHdr>}</root>' passing  x_contents as "doc" returning content) as XML_RESULT
	 *  
	 *  Result:
	 *  <root xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.01">
		   <MsgId>aaa</MsgId>
		   <MsgId>aaa</MsgId>
		   <GrpHdr>
		      <MsgId>aaa</MsgId>
		      <SttlmMtd>INDA</SttlmMtd>
		      <TtlIntrBkSttlmAmt Ccy="USD">bbb</TtlIntrBkSttlmAmt>
		   </GrpHdr>
		   <GrpHdr>
		      <MsgId>aaa</MsgId>
		      <SttlmMtd>INDA</SttlmMtd>
		      <TtlIntrBkSttlmAmt Ccy="USD">bbb</TtlIntrBkSttlmAmt>
		   </GrpHdr>
		</root>

	 *  Query:
	 *  select xmlquery('declare default element namespace "urn:iso:std:iso:20022:tech:xsd:pacs.008.001.01"; <root>{for $e in $doc//pacs.008.001.01/GrpHdr return <GrpHdr>{$e/MsgId}{$e/SttlmInf/SttlmMtd}{$e//TtlIntrBkSttlmAmt}</GrpHdr>}</root>' passing  x_contents as "doc" returning content) as XML_RESULT from xml_test  WHERE code = 6 AND ROWNUM <= 1500 
	 * 	
	 *  Result:
	 *  <root xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.01">
		    <GrpHdr xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.01">
		        <MsgId xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.01">aaa</MsgId>
		        <SttlmMtd xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.01">INDA</SttlmMtd>
		        <TtlIntrBkSttlmAmt
		            xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.01" Ccy="USD">bbb</TtlIntrBkSttlmAmt>
		    </GrpHdr>
		</root>
	 * 
	 *  Query:
	 *  select xmlquery('<root>{for $e in $doc//*:pacs.008.001.01/*:GrpHdr return <GrpHdr>{$e/*:MsgId}{$e/*:SttlmInf/*:SttlmMtd}{$e//*:TtlIntrBkSttlmAmt}</GrpHdr>}{for $e in $doc/*:Document/*:pacs.008.001.01//* return $e/*:Id[*:IBAN[text()!="JDB"]]//*:IBAN}</root>' passing  x_contents as "doc" returning content) as XML_RESULT from xml_test  WHERE code = 6 AND ROWNUM <= 1500 
	 * 	
	 * 	Result:
	 * <root>
		    <GrpHdr>
		        <MsgId xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.01">aaa</MsgId>
		        <SttlmMtd xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.01">INDA</SttlmMtd>
		        <TtlIntrBkSttlmAmt Ccy="USD" xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.01">bbb</TtlIntrBkSttlmAmt>
		    </GrpHdr>
		    <IBAN xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.01">p</IBAN>
		    <IBAN xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.01">p</IBAN>
		    <IBAN xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.01">p</IBAN>
		</root>
	 * 
	 *  Query:
	 *  select xmlquery('declare default element namespace "urn:iso:std:iso:20022:tech:xsd:pacs.008.001.01"; <root>{for $e in $doc//pacs.008.001.01/GrpHdr return <GrpHdr>{$e/MsgId}{$e/SttlmInf/SttlmMtd}{$e//TtlIntrBkSttlmAmt}</GrpHdr>}{for $e in $doc/Document/pacs.008.001.01//* return $e/Id[IBAN[text()!="JDB"]]//IBAN}</root>' passing  x_contents as "doc" returning content) as XML_RESULT from xml_test  WHERE code = 6 AND ROWNUM <= 1500 
 	 * 	
 	 *  Result:
 	 *  <root xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.01">
		    <GrpHdr xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.01">
		        <MsgId xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.01">aaa</MsgId>
		        <SttlmMtd xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.01">INDA</SttlmMtd>
		        <TtlIntrBkSttlmAmt
		            xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.01" Ccy="USD">bbb</TtlIntrBkSttlmAmt>
		    </GrpHdr>
		    <IBAN xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.01">p</IBAN>
		    <IBAN xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.01">p</IBAN>
		    <IBAN xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.01">p</IBAN>
		</root>
 	 * 
 	 *  Query:
 	 * 	select xmlquery('<root>{for $e in $doc//*:pacs.008.001.01/*:GrpHdr return <GrpHdr>{$e/*:MsgId}{$e/*:SttlmInf/*:SttlmMtd}{$e//*:TtlIntrBkSttlmAmt}</GrpHdr>}{for $e in $doc/*:Document/*:pacs.008.001.01 return <pacs.008.001.01>{$e//*:Id[*:IBAN[text()!="JDB"]]//*:IBAN}{$e//*:Id}{$e//*:Strd}</pacs.008.001.01>}</root>' passing  x_contents as "doc" returning content) as XML_RESULT from xml_test  WHERE code = 6 AND ROWNUM <= 1500 
	 * 
	 * 	Result:	
	 * <root>
		   <GrpHdr>
		      <MsgId xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.01">aaa</MsgId>
		      <SttlmMtd xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.01">INDA</SttlmMtd>
		      <TtlIntrBkSttlmAmt Ccy="USD" xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.01">bbb</TtlIntrBkSttlmAmt>
		   </GrpHdr>
		   <pacs.008.001.01>
		      <IBAN xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.01">p</IBAN>
		      <IBAN xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.01">p</IBAN>
		      <IBAN xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.01">p</IBAN>
		      <Id xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.01">
		         <OrgId>
		            <BIC>AAAAFRPP</BIC>
		         </OrgId>
		      </Id>
		      <Id xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.01">
		         <IBAN>p</IBAN>
		      </Id>
		      <Id xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.01">AAAAFRPP</Id>
		      <Id xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.01">
		         <IBAN>p</IBAN>
		      </Id>
		      <Id xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.01">
		         <OrgId>
		            <BIC>ZZZZITMM</BIC>
		         </OrgId>
		      </Id>
		      <Id xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.01">
		         <IBAN>p</IBAN>
		      </Id>
		      <Strd xmlns="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.01">
		         <RfrdDocInf>
		            <RfrdDocTp>
		               <Cd>CINV</Cd>
		            </RfrdDocTp>
		            <RfrdDocNb>ABC060928CCT0013</RfrdDocNb>
		         </RfrdDocInf>
		      </Strd>
		   </pacs.008.001.01>
		</root>
	 *
	 * @param commandInfo Class containg all required data for the consturction of a given xml sql query.
	 * @return DTODataHolder containing all returned records where by the DOM documents are stored in each 
	 * record against the XML_RESULT key. 
	 */
	public DTODataHolder getData(final CommandInfo commandInfo) { 
				
		ProcessingContext ctx = new ProcessingContext(commandInfo) ;
		final String sQuery = this.constructSelectXmlQuery(ctx) ;
		
		//execute the query
		DTODataHolder dtoDataHolder = 
			this.getData(commandInfo.getConnection(), sQuery, commandInfo.getStatementParameters()) ;
		
		return dtoDataHolder ; 		
	}//EOM 
	
	/**
	 * Dec 27, 2007
	 * guys
	 * 
	 *  Hook method for the consturction of the XML column update clause.
	 * 
	 * @param ctx ProcessingContext instance containing all data required for query construction.
	 * @return xml column update clause.
	 */
	protected abstract String constructUpdateQueryInnerHook(final ProcessingContext ctx) ;  
	
	
	/**
	 * Dec 27, 2007
	 * guys
	 * 
	 * Constructs a complete SQL update query whereby one or more of the modified columns are of XML data type. 
	 * 
	 * Syntax support for: 
	 * %	mixed column data types 
	 * %	Parameter bindings  
	 * %	query template --> uses the query and enriches it with the generated xml column update 
	 * %	no query template --> constructs a complete query
	 * 
	 * @param ctx
	 * @return
	 */
	private final String constructUpdateQuery(final ProcessingContext ctx) {
		
		final CommandInfo commandInfo = ctx.getCommandInfo() ; 
		
		//invoke the hook method to construct and retrieve the xml column 
		//update clause 
		final String sXmlColumnUpdateClause = this.constructUpdateQueryInnerHook(ctx) ; 
		
		//if the queryTemplate is null, construct a  whole select statement otherwise, us the 
		//former 
		final String sQueryTemplate = commandInfo.getQueryTemplate() ; 
		String sQuery = null ; 
		
		if(sQueryTemplate != null) { 
			
			sQuery = String.format(sQueryTemplate, ctx.getOvrllBldr().toString()) ;  			
		}else { 
			final String sTablename = commandInfo.getTablename() ; 
			final String sWhereClause = commandInfo.getAdditionalWhereclause() ; 
			
			//constrcut the complete statement
			sQuery = String.format(UPDATE_TEMPLATE
					,sTablename  
					,sXmlColumnUpdateClause
				);			
			//if the commandInfo.m_sWhereClause is not null append it 
			if(sWhereClause != null) { 
				sQuery = sQuery + WHERE_CLAUSE_START + commandInfo.getAdditionalWhereclause() ;  
			}//EO if the commandInfo.m_sWhereClause is not null append it
		}//EO else if the query template was not provided.
		
		return sQuery ; 
	}//EOM 
		
	/**
	 * Dec 27, 2007
	 * guys
	 * 
	 * Query generation method. 
	 * Uses metadata stored in the processing context formal argument in the process of the query generation. 
	 * Note: syntax support for: 
	 * %	single for each 
	 * %	multiple for each 
	 * %	foreach with no child elements (returns $e) 
	 * %	foreach with a single child elements (returns $e<relative xpath>) 
	 * %	foreach with multiple child elements (returns {<parent node name>{$e<relative xpath>}{$e<relative xpath>}</parent node name>)
	 * %	query template --> uses the query and enriches it with the generated xml column retrieval 
	 * %	no query template --> constructs a complete query
	 * 
	 * @param ctx ProcessingContext instance containing all data required for query construction.
	 * @return complete SQL ready statement 
	 */
	private final String constructSelectXmlQuery(ProcessingContext ctx) { 
		
		final CommandInfo commandInfo = ctx.getCommandInfo() ; 
		
		final String sNamespace = commandInfo.getNamespace() ; 
		final String sXmlColumnname = commandInfo.getColumnname() ; 
		final String sQueryTemplate = commandInfo.getQueryTemplate() ;
		
		String sParentXPath, sEnrichedParentXpath, sParentElementName, sForeachClasue,
			sForeachReturnClause    = null ; 
				
		//iterate over the NodeGroupInfo elements and create the 'for each'
		//for each of them 
		Iterator<NodeGroupInfo> iterator = commandInfo.nodeGroupIterator() ; 
		
		while(iterator.hasNext()) { 
			
			//set the current nodeGroupInfo as the current one 
			ctx.setCurrentNodeGroupInfo(iterator.next()) ; 
			
			//construct the foreach return clause for the current for each 
			//the value would be stored in the ctx.get
			this.constructSelectForeachReturnClause(ctx) ; 
			
			sParentXPath = ctx.getCurrentNodeGroupInfo().m_sParentXPath ;
			
			//if the namespace delcaration was missing, modify the xpath  
			//to prefix each xpath element with the any-namspace declaration on each
			sEnrichedParentXpath = ( ctx.getCommandInfo().getNamespace() != null ?
					sParentXPath :
					this.modifyXpathToIgnoreNamespace(sParentXPath) 
					) ; 
			
			//if there are no nodeInfo instance, then the root element should be returned
			//else if there where more then one node info instances 
			//wrap them in a root element 
			sForeachReturnClause = ctx.getReturnClsBldr().toString() ; 
			
			//reset the ForeachReturnClasueBuilder readying it for the next nodeGroupInfo
			ctx.resetForeachReturnClasueBuilder(); 
			
			if(sForeachReturnClause.equals("")) { 
				sForeachReturnClause = RELATIVE_ROOT_ELEMENT_NAME ; 
			}else { 
				
				//no need for else as the sForeachReturnClause is already assigned
				if(ctx.getCurrentNodeGroupInfo().m_listUpdateNodes.size() > 1) {  
				
					//get the parent node name from the xpath so as to create a child 
					//root element.
					Matcher matcher = LAST_NODE_NAME_REGEX.matcher(sParentXPath) ; 
					matcher.find() ; 
					sParentElementName = matcher.group(1) ;  
					
					sForeachReturnClause = String.format(FOR_EACH_MULTIPLE_RETURN_ELEMENTS_TEMLPATE,
							sParentElementName, 
							sForeachReturnClause
							); 
				}//EO if there where more then one node info instances  	
			}//EO else if there were child elements 
			 
			//create the foreach clause and append it to the overall buffer
			/*
			 * 1 - parent element xpath 
			 * 2 - return elements clause  
			 */
			sForeachClasue = String.format(FOR_EACH_SELECT_TEMPLATE,
					sEnrichedParentXpath, 
					sForeachReturnClause
					); 
			
			ctx.getOvrllBldr().append(sForeachClasue) ;
					 
		}//EO while there are more NodeGroupInfo elements
		
		//construct the namespace declaration 
		String sNsDecleration =  (sNamespace == null ? 
		    "" : 
			String.format(NS_DECLAREATION_TEMPLATE, sNamespace) 
			);
 
		//construct the complete xml column retrieval block 
		/*
		 * 1 - declare namspace clause  
		 * 2 - 1..n for each statememts string 
		 * 3 - passing by type ('by ref', 'by value'  or '')
		 * 4 - column name
		 * 5 - returning clause ('returning content' or '')
		 */
		final String sXmlQueryClasue = String.format(OVERALL_SELECT_TEMPLATE, 
				sNsDecleration, 
				ctx.getOvrllBldr().toString(),
				this.getXQueryPassingByTypeString(),  
				sXmlColumnname, 
				this.getXQueryPassingReturnClasueString() 
				); 
				
		String sQuery = null ; 
		//if the sQueryTemplate is not null, use it as the complete statement 
		if(sQueryTemplate != null) { 
			sQuery	= String.format(sQueryTemplate, sXmlQueryClasue) ;		
		}else { 
			final String sTableName = commandInfo.getTablename() ; 
			final String sWhereClause = commandInfo.getAdditionalWhereclause() ; 
			
			//create a select statement around the xml single column
			sQuery =  String.format(SELECT_XML_TEMPLATE, 
					sXmlQueryClasue, 
					sTableName, 
					(sWhereClause == null ? ServerConstants.EMPTY_STRING : sWhereClause)
					) ;
			
			//if the where clause was not null append it 
			if(sWhereClause != null) { 
				final StringBuilder builder = new StringBuilder(sQuery).
				append(WHERE_CLAUSE_START).append(sWhereClause) ; 
				
				sQuery = builder.toString() ;
			}//EO  if the where clause was not null 
				 
		}//EO else if the sQueryTemplate was null 
		
		return sQuery ;
		 
	}//EOM
	
	/**
	 * Dec 27, 2007
	 * guys
	 *
	 * Constructs a given for-each return clause. 
	 * Result is stored in the ctx.getReturnClsBldr(). 
	 * Note: client code is expected to clear the buffer from previous invocation data before each call.
	 * 
	 * Supports the following scenarios: 
	 *  
	 * %	foreach with no child elements (returns $e) 
	 * %	foreach with a single child elements (returns $e<relative xpath>) 
	 * %	foreach with multiple child elements (returns {<parent node name>{$e<relative xpath>}{$e<relative xpath>}</parent node name>)
	 * 
	 * @param ctx ProcessingContext instance containing all data required for query construction.
	 */
	private final void constructSelectForeachReturnClause(final ProcessingContext ctx) { 
		String sRelativeElementXpath, sForeachReturnClauseTemplate = null ; 
		NodeInfo nodeInfo = null ; 
		
		//get the nodeInfo return elements clause 
		Iterator<NodeInfo> nodeInfoIterator = ctx.getCurrentNodeGroupInfo().nodeInfoIterator() ; 
				
		final boolean bMoreThenOneElement = ctx.getCurrentNodeGroupInfo().m_listUpdateNodes.size() > 1 ;
		
		while(nodeInfoIterator.hasNext()) { 
			nodeInfo = nodeInfoIterator.next() ;
			
			sRelativeElementXpath = nodeInfo.getRelativeColumnXPath() ; 
			
			//if the namespace delcaration was missing, modify the xpath  
			//to prefix each xpath element with the any-namspace declaration on each 
			sRelativeElementXpath = ( ctx.getCommandInfo().getNamespace() != null ?
					sRelativeElementXpath :
					this.modifyXpathToIgnoreNamespace(sRelativeElementXpath) 
					) ; 
			
			//create the return element template only if there are more then one child element 
			//otherwise, use the relative xpath as-is
			sForeachReturnClauseTemplate = ( bMoreThenOneElement ? 
					FOR_EACH_RETURN_ELEMENT_TEMLPATE_MULTIPLE_CHILDREN :  
					FOR_EACH_RETURN_ELEMENTS_TEMLPATE_SIGNLE_CHIILD
				) ; 
			
			sRelativeElementXpath = String.format(sForeachReturnClauseTemplate, sRelativeElementXpath) ;
										
			ctx.getReturnClsBldr().append(sRelativeElementXpath) ; 
							
		}//EO while there are more node Info elements
	}//EOM 	
		
	
	@Override 
	/**
	 * invokes the DAOBasic's implementation unless the type is an xml one.
	 */
	protected Object getColumnValue(int iColumnIndex, ResultSet rs, ResultSetMetaData rsmd) throws SQLException { 
		
		 Object oResult = null ; 
		
		 final int iColumnType = rsmd.getColumnType(iColumnIndex) ;  
		
		 if(this.getXmlColumnDataType() == iColumnType) { 
			
			 try{ 
				 oResult = this.getDomDocument(rs, XML_RESULT_COLUMN_NAME) ;
			 }catch(Exception e) { 
				 ExceptionController.getInstance().handleException(e, this) ;
			 }//EO catch block
			 
		 }else oResult = super.getColumnValue(iColumnIndex, rs, rsmd) ;  
		
		 return oResult ; 
	}//EOM 
	

	/**
	 * Closes all objects by reflection invokation of the close() on eahc closable object.
	 * Note: all objects must have a close method.
	 * Note: Null Values in the vararg are permitted. 
	 * Note: failiure of one invocation will not terminate the method but will be caught, reported and ignored.
	 * @param closables Object[] containing all object instances on which to invoke the close()
	 */
	public final void dispose(Object...closables) { 
			 
			for(Object closable : closables) {
				try{ 
					if(closable == null) continue ; 
					else if(closable instanceof ResultSet) ((ResultSet)closable).close() ;
					else if(closable instanceof Statement) ((Statement)closable).close() ;
					else if(closable instanceof Connection) ((Connection)closable).close() ;
				}catch(Exception e) { 
					logger.error(e.getMessage());
				}//EO while there are more closable objects 			
			}//EO catch block 
	
	}//EOM 
	
	/**
	 * Utility method for tracing DOM document instances.
	 * @param document
	 * @throws IOException
	 */
	protected final void printXML(final Document document) throws IOException{ 
		 
		if(this.outputFormat ==  null) { 
			this.outputFormat = new OutputFormat(document, "ISO-8859-1", true) ; 
			outputFormat.setIndenting(true) ; 
			outputFormat.setStandalone(true) ;
		}//EO if the output format was not instantiated as of yet.
		
		final StringWriter writer = new StringWriter() ; 
		XMLSerializer serializer = new XMLSerializer(writer, outputFormat) ;
		
		serializer.asDOMSerializer() ; 
		serializer.serialize(document) ; 
		logger.info(writer.getBuffer().toString()); 
		writer.close();
	}//EOM
	
 	/**
 	 * Session Container class used to share resource in method scope rather then instance one.
 	 *  
 	 * @author guys
 	 *
 	 */
 	protected static class ProcessingContext { 
 		
 		private CommandInfo   m_commandInfo ;
 		private NodeGroupInfo m_nodeGroupInfo ; 
 		private StringBuilder m_sbOverallStatementBuilder = new StringBuilder() ; 
 		private StringBuilder m_snValuesRefDeclarationBuilder = new StringBuilder() ;
 		private char m_iReferenceCounter = 'a'  ;
 		private List<String> m_listParameterValues = new ArrayList<String>() ;
 		private StringBuilder m_foreachReturnClasueBuilder = new StringBuilder() ;
 		 		
 		public ProcessingContext(CommandInfo commandInfo) { 
 			this.m_commandInfo = commandInfo ; 
 		}//EOM
 		
 		/**
 		 * @return CommandInfo containing the required resource for query construction.
 		 */
 		public CommandInfo getCommandInfo() { 
 			return this.m_commandInfo ; 
 		}//EOM 
 		
 		/**
 		 * @return Current NodeInfo instance containing the data for query segment construction 
 		 */
 		public final NodeGroupInfo getCurrentNodeGroupInfo() { 
 			return this.m_nodeGroupInfo ; 
 		}//EOM 
 		
 		/**
 		 * @param nodeGroupInfo NodeInfo instance containing the data for query segment construction
 		 */
 		public final void setCurrentNodeGroupInfo(final  NodeGroupInfo nodeGroupInfo) { 
 			this.m_nodeGroupInfo = nodeGroupInfo ; 
 		}//EOM
 		
 		
 		 /** 
 		 * @return StringBuilder used for the construction of the overall query. 
 		 */
 		public final StringBuilder getOvrllBldr()  { 
 			return this.m_sbOverallStatementBuilder ; 
 		}//EOM 
 		
 		/**
 		 * Dec 27, 2007
 		 * guys
 		 *
 		 * @return StringBuilder used for the construction of a given Select query xml foreach return clause
 		 */
 		public final StringBuilder getReturnClsBldr() { 
 			return this.m_foreachReturnClasueBuilder ; 
 		}//EOM
 		
 		/**
 		 * Dec 27, 2007
 		 * guys
 		 * 
 		 * Clears the m_foreachReturnClasueBuilder
 		 */
 		public final void resetForeachReturnClasueBuilder() { 
 			this.m_foreachReturnClasueBuilder = new StringBuilder() ;
 		}//EOM
 		
 		/**
 		 * @return StringBuilder used for the construction of the parameter binding part of the 
 		 * Passing clause in the context of xml update.
 		 * 
 		 * Syntax Example (whereby the reference part is the one following the 'passing by ref x_contents as "doc"' block): 
 		 * 
 		 * update xml_test set x_contents = xmlquery(' 
 		 * 	declare default element namespace "urn:iso:std:iso:20022:tech:xsd:pacs.008.001.01";
 		 *  copy $newDoc := $doc 
 		 *  modify(  
 		 *  	for $e in $newDoc//pacs.008.001.01/GrpHdr 
 		 *  	return (
 		 *  			do replace value of $e/MsgId with $a
 		 *  		   ,do replace value of $e/TtlIntrBkSttlmAmt with $b
 		 *  	       ) , 
 		 *  	for $e in $newDoc//CdtTrfTxInf[1]/PmtId 
 		 *  	return (
 		 *  			do replace value of $e/TxId with $c
 		 *  		   ,do replace value of $e/EndToEndId with $d
 		 *  		   ) 
 		 *  	) 
 		 *  return $newDoc'  
 		 *  passing by ref x_contents as "doc"
 		 *  , cast(? as varchar(2000)) as "a"
 		 *  , cast(? as varchar(2000)) as "b"
 		 *  , cast(? as varchar(2000)) as "c"
 		 *  , cast(? as varchar(2000)) as "d") 
 		 *  WHERE Code = 6
 		 */
 		public final StringBuilder valuesRefDeclarationBuilder() { 
 			return this.m_snValuesRefDeclarationBuilder ; 
 		}//EOM 
 		
 		/**
 		 * @return Auto-generated paramter binding alias used in the context of xml update
 		 * 
 		 * Syntax Example (whereby the refVarNames are the "a", "b", "c", "d" and "$a", "$b", "$c", "$d" respectively):  
 		 * 
 		 * Note: as $e is a reserved char, skip it.
 		 * 
 		 * update xml_test set x_contents = xmlquery(' 
 		 * 	declare default element namespace "urn:iso:std:iso:20022:tech:xsd:pacs.008.001.01";
 		 *  copy $newDoc := $doc 
 		 *  modify(  
 		 *  	for $e in $newDoc//pacs.008.001.01/GrpHdr 
 		 *  	return (
 		 *  			do replace value of $e/MsgId with $a
 		 *  		   ,do replace value of $e/TtlIntrBkSttlmAmt with $b
 		 *  	       ) , 
 		 *  	for $e in $newDoc//CdtTrfTxInf[1]/PmtId 
 		 *  	return (
 		 *  			do replace value of $e/TxId with $c
 		 *  		   ,do replace value of $e/EndToEndId with $d
 		 *  		   ) 
 		 *  	) 
 		 *  return $newDoc'  
 		 *  passing by ref x_contents as "doc"
 		 *  , cast(? as varchar(2000)) as "a"
 		 *  , cast(? as varchar(2000)) as "b"
 		 *  , cast(? as varchar(2000)) as "c"
 		 *  , cast(? as varchar(2000)) as "d") 
 		 *  WHERE Code = 6
 		 */
 		public final String getNextRefVarName() { 
 			char ch = this.m_iReferenceCounter++ ;
 			if(ch == 'e') this.m_iReferenceCounter++ ;
 			return Character.toString(this.m_iReferenceCounter) ; 
 		}//EOM
 		
 		/**
 		 * @return Parameter binding values, logically mapped to the ? in the query example
 		 * 
 		 * Syntax Example:  
 		 * 
 		 * update xml_test set x_contents = xmlquery(' 
 		 * 	declare default element namespace "urn:iso:std:iso:20022:tech:xsd:pacs.008.001.01";
 		 *  copy $newDoc := $doc 
 		 *  modify(  
 		 *  	for $e in $newDoc//pacs.008.001.01/GrpHdr 
 		 *  	return (
 		 *  			do replace value of $e/MsgId with $a
 		 *  		   ,do replace value of $e/TtlIntrBkSttlmAmt with $b
 		 *  	       ) , 
 		 *  	for $e in $newDoc//CdtTrfTxInf[1]/PmtId 
 		 *  	return (
 		 *  			do replace value of $e/TxId with $c
 		 *  		   ,do replace value of $e/EndToEndId with $d
 		 *  		   ) 
 		 *  	) 
 		 *  return $newDoc'  
 		 *  passing by ref x_contents as "doc"
 		 *  , cast(? as varchar(2000)) as "a"
 		 *  , cast(? as varchar(2000)) as "b"
 		 *  , cast(? as varchar(2000)) as "c"
 		 *  , cast(? as varchar(2000)) as "d") 
 		 *  WHERE Code = 6
 		 */
 		public final  List<String> getBindParamValuesList() { 
 			return this.m_listParameterValues ; 
 		}//EOM 
 		
 		/**
 		 * Adds a new parameter binding value to the internal binding values list member
 		 * @param sValue
 		 */
 		public final void addBindingParamValue(final String sValue) { 
 			this.m_listParameterValues.add(sValue) ; 
 		}//EOM
 		
 	}//EOM 
 	
 	/**
 	 * 
 	 * Dec 11, 2007
 	 * guys
 	 * 
 	 * replaces all '/' (which are not followed by ':*' or '/'  with '/*:')  
 	 *
 	 * @param sXpath raw String to modify  
 	 * @return modify xpath containng the 'any-namespace' operators  
 	 */
 	protected final String modifyXpathToIgnoreNamespace(String sXpath) { 
 		final String ATTR_OR_ANY_OR_FWD_SLASH_REGEX_STRING  = "([/\\[])([^\\d/*@])" ;  
 		final String ATTR_OR_ANY_OR_FWD_SLASH_REPLACEMENT_TEMPLATE = "$1*:$2" ;  
		
		//(?!text())
		final String TEXT_NODE_REGEX_STRING = "\\*:(text\\(\\))" ;  
 		final String TEXT_NODE_REPLACEMENT_TEMPLATE = "$1" ; 
		
 		sXpath = sXpath.replaceAll(ATTR_OR_ANY_OR_FWD_SLASH_REGEX_STRING, ATTR_OR_ANY_OR_FWD_SLASH_REPLACEMENT_TEMPLATE) ;
 		
 		sXpath = sXpath.replaceAll(TEXT_NODE_REGEX_STRING, TEXT_NODE_REPLACEMENT_TEMPLATE) ;
 		
 		 
 		return sXpath ;
 	}//EOM 
 	
 	/**
 	 * Dec 12, 2007
 	 * guys
 	 *
 	 * Transforms a given xpath to one using '*[name()="<nodeName">] instaed of fully qualified 
 	 * node names so that namespaces could be ignored.
 	 *
 	 *  Regex Breakdown: 
 	 *  
 	 *  ([/\\[]*)([^\\[\\]/*\"@=]+)([/\\[]|$) 
 	 *  
 	 *  * capture any number of consequetive '/' into group number 1 
 	 *  * capture any char belonging to the following set {start of input, 
 	 *    NOT the following chars: '\', '[', ']', '/', '*', '"', '@', '='} 
 	 *    into group number 2 
 	 *  * capture nay char belonging to the following set {'/','['} or end of line into group number 3   
 	 *  
 	 *  $1*[name()=\"$2\"]$3 --> $n represents captured group from the above regex 
 	 *  
 	 * @param sXpath Xpath string using fully qualified node names 
 	 * @return Transformed xpath 
 	 */
 	protected final String modifyXpathToUseLocalNames(String sXpath) { 
 		
 		final String FULL_QNAME_NODE_REGEX_STRING  = "([/\\[]*)([^\\[\\]/*\"@=]+)([/\\[]|$)" ;
 		
 		final String LOCAL_QNAME_NODE_REPLACEMENT_STRING = "$1*[name()=\"$2\"]$3" ; 
		
		final String TEXT_NODE_REGEX_STRING = "\\*\\[name\\(\\)=\"text\\(\\)\"\\]" ;  
 		final String TEXT_NODE_REPLACEMENT_TEMPLATE = "text()" ; 
 		
 		final String ARRAY_INDEX_REGEX_STRING = "\\*\\[name\\(\\)=\"(\\d+)\\]\"" ;
 		final String FIRST_CAPTURED_GROUP_REPLACEMENT_TEMPLATE = "$1" ;
		
 		sXpath = sXpath.replaceAll(FULL_QNAME_NODE_REGEX_STRING, LOCAL_QNAME_NODE_REPLACEMENT_STRING) ;
 		
 		sXpath = sXpath.replaceAll(TEXT_NODE_REGEX_STRING, TEXT_NODE_REPLACEMENT_TEMPLATE) ;
 		
 		sXpath = sXpath.replaceAll(ARRAY_INDEX_REGEX_STRING, FIRST_CAPTURED_GROUP_REPLACEMENT_TEMPLATE) ;
 		
 		
 		return sXpath ;
 	}//EOM 
 	
 	public final boolean isXmlType(final int iSqlDataType) { 
 		return this.getXmlColumnDataType() == iSqlDataType ; 
 	}//EOM 
 	
 	public abstract void bindXmlColumn(final int iColIndex, final XmlObject xmlBeanRoot, PreparedStatement ps) throws SQLException, IOException; 
 	
 	public abstract void bindXmlColumn(final int iColIndex, final String xml, PreparedStatement ps) throws SQLException, IOException;
 	
 	public abstract void bindXmlColumn(final int iColIndex, final InputStream is, PreparedStatement ps) throws SQLException, IOException;
 	 	
 	/**
 	 * 
 	 * Jul 23, 2008
 	 * guys
 	 *
 	 * @param logicalField
 	 * @param bIsInWhereClause
 	 * @param sOccurenceIndex nullable and must start from one. acts as a flag indicating whether to aggregate the occurrences
 	 * if the value is "-1"  (PDOConstantFieldsInterface.MULTI_OCCURRENCE_AGGREGATE_INDEICATOR)
 	 * @return
 	 
 	public String constructPaymentXmlColumnCase(final LogicalFields logicalField, boolean bIsInWhereClause, final String sOccurenceIndex) {   

	  final StringBuilder caseBuilder = new StringBuilder() ; 
	  
	  final String MSG_TYPE_COL_NAME_TEMPLATE = "P_%s_TYPE" ; 
	  
	  //multiple whens   
	  final String XML_COLUMN_TEMLPATE = "CASE %s %s ELSE NULL END %s" ;
	  
	  //payment type  
	  //extract value template
	  final String XML_CASE_TEMPLATE =  "WHEN '%s' THEN (%s) "  ;
	  
	  //EXTRACTVALUE or EXTRACT if the bIsAggregate flag is true 
	  //xml column name (logical field location) 
	  //path parent xpath 
	  //child xpath  
	  //multi occurrence predicate or /text() 
	  //xml namespace 
	  final String EXTRACTVALUE_TEMPLATE = "%s(%s,'%s%s%s','xmlns=\"%s\"')" ; 
	  
	  //extract value template 
	  final String XML_SERIALIZE_TEMPLATE = "XMLSERIALIZE(CONTENT %s as varchar(4000))" ; 
	  final String NULL = "NULL" ; 
	  
	  //iterate over the m_arrPaymentTypes and construct a case for each 
	  LogicalFieldsXpath pathParentCacheEntry = null, fieldPathCacheEntry = null ;
	  final CacheServiceInterface cache = CacheServiceInterface.eINSTANCE ; 
	  Map<String, LogicalFieldsXpath> mapFieldsXPath = null ;
	  String sExtractValueTemplate = null ; 
	  
	  final boolean bIsMultiOccurrenceClasue = (sOccurenceIndex != null) ;
	  final boolean bIsAggregateFunction = bIsMultiOccurrenceClasue && sOccurenceIndex.equals(PDOConstantFieldsInterface.MULTI_OCCURRENCE_AGGREGATE_INDEICATOR) ; 
	  final String sExtractType = (bIsMultiOccurrenceClasue ? "EXTRACT" : "EXTRACTVALUE" ) ;  
	  
	  final String sXpathAppendum = (!bIsMultiOccurrenceClasue ? "" : (bIsAggregateFunction ? "/text()" : '[' + sOccurenceIndex + ']'  ) ) ;  
	  	  
	  for(PaymentType enumPaymentType : m_arrPaymentTypes) { 
		 		  
		  mapFieldsXPath = (Map<String, LogicalFieldsXpath>) CacheKeys.LogicalFieldsXPathKey.getSingle(enumPaymentType) ; 
		 
		 pathParentCacheEntry = mapFieldsXPath.get(logicalField.getPathParentId())  ;
		 fieldPathCacheEntry  = mapFieldsXPath.get(logicalField.getFieldLogicalId())  ;
		 
		 //if the fieldPathCacheEntry is null, then the field does not belong to the given payment type 
		 //and thus the case should return null 
		 if(fieldPathCacheEntry == null) sExtractValueTemplate = NULL ; 
		 else { 
			  
			//first format the extract value template 
			 sExtractValueTemplate = String.format(EXTRACTVALUE_TEMPLATE,
					 sExtractType, 
					 fieldPathCacheEntry.getLocation(), 
					 (pathParentCacheEntry == null ? "" : pathParentCacheEntry.getFieldPath()),
					 fieldPathCacheEntry.getFieldPath(), 
					 sXpathAppendum, 
					 enumPaymentType.getSchemaNamespace() ) ;
			 
			//if the sOccurenceIndex is not null AND not '-1', then the logical field is a multi occurrence one, 
			//which means that the index predicate must be inserted into the xpath 
			//if on the other hand the index is that of a multi occurrence aggregate ("-1") 
			//then the XML_SERIALIZE_TEMPLATE should be used to wrap the EXTRACTVALUE_TEMPLATE
			 if(bIsAggregateFunction) sExtractValueTemplate = String.format(XML_SERIALIZE_TEMPLATE, sExtractValueTemplate) ; 
 
		 }//EO else if there was an xpath 
		 
		 //if the logical field has a spacial formatting template apply it on the 
		 //extract value template 
		 if(fieldPathCacheEntry != null && fieldPathCacheEntry.getFormat() != null)
			 sExtractValueTemplate = String.format(fieldPathCacheEntry.getFormat(), sExtractValueTemplate) ; 
		 
		 //construct the when clause
		 caseBuilder.append(String.format(XML_CASE_TEMPLATE, 
				  enumPaymentType.name(), 
				  sExtractValueTemplate )) ;
	  }//EO while there are more payment types 
	  
	  //xml column - message type column correlation must adhere to the following convension: 
	  //	xml column name: 		XML_<type e.g. orig/cover>_MSG
	  //	msg type column name: 	P_<type e.g. orig.conver>_MSG_TYPE ; 
	  final String sMsgTypeColName = String.format(MSG_TYPE_COL_NAME_TEMPLATE, logicalField.getLocation().substring("XML_".length())) ; 
	  
	  //construct the complete case clause 
	  return (bIsInWhereClause ? "(" : "") +
	  		 String.format(XML_COLUMN_TEMLPATE, sMsgTypeColName,  
	  				 caseBuilder.toString(), (bIsInWhereClause ? "" : "\""+logicalField.getFieldLogicalId()+"\"" ) ) + 
	  		(bIsInWhereClause ? ")" : "") ; 
	}//EOM 
 	*/ 
 	
 	
 	/**
 	 * 
 	 * Jul 23, 2008
 	 * guys
 	 *
 	 * @param logicalField
 	 * @param bIsInWhereClause
 	 * @param sOccurenceIndex nullable and must start from one. acts as a flag indicating whether to aggregate the occurrences
 	 * if the value is "-1"  (PDOConstantFieldsInterface.MULTI_OCCURRENCE_AGGREGATE_INDEICATOR)
 	 * @return
 	 
 	public String constructPaymentXmlColumnCase(final LogicalFields logicalField, boolean bIsInWhereClause, final String sOccurenceIndex) {   

	  final StringBuilder caseBuilder = new StringBuilder() ; 
	  
	  final String MSG_TYPE_COL_NAME_TEMPLATE = "P_%s_TYPE" ; 
	  
	  //multiple whens   
	  final String XML_COLUMN_TEMLPATE = "CASE %s %s ELSE NULL END %s" ;
	  
	  //payment type  
	  //extract value template
	  final String XML_CASE_TEMPLATE =  "WHEN '%s' THEN (%s) "  ;
	  
	  //EXTRACTVALUE or EXTRACT if the bIsAggregate flag is true 
	  //xml column name (logical field location) 
	  //path parent xpath 
	  //child xpath  
	  //multi occurrence predicate or /text() 
	  //xml namespace 
	  final String EXTRACTVALUE_TEMPLATE = "%s(%s,'%s%s%s','xmlns=\"%s\"')" ; 
	  
	  //extract value template 
	  final String XML_SERIALIZE_TEMPLATE = "XMLSERIALIZE(CONTENT %s as varchar(4000))" ; 
	  final String NULL = "NULL" ; 
	  
	  //iterate over the m_arrPaymentTypes and construct a case for each 
	  LogicalFieldsXpath pathParentCacheEntry = null, fieldPathCacheEntry = null ;
	  final CacheServiceInterface cache = CacheServiceInterface.eINSTANCE ; 
	  Map<String, LogicalFieldsXpath> mapFieldsXPath = null ;
	  String sExtractValueTemplate = null ; 
	  
	  final boolean bIsMultiOccurrenceClasue = (sOccurenceIndex != null) ;
	  final boolean bIsAggregateFunction = bIsMultiOccurrenceClasue && sOccurenceIndex.equals(PDOConstantFieldsInterface.MULTI_OCCURRENCE_AGGREGATE_INDEICATOR) ; 
	  final String sExtractType = (bIsMultiOccurrenceClasue ? "EXTRACT" : "EXTRACTVALUE" ) ;  
	  
	  final String sXpathAppendum = (!bIsMultiOccurrenceClasue ? "" : (bIsAggregateFunction ? "/text()" : '[' + sOccurenceIndex + ']'  ) ) ;  
	  	  
	  for(PaymentType enumPaymentType : m_arrPaymentTypes) { 
		 		  
		  mapFieldsXPath = (Map<String, LogicalFieldsXpath>) CacheKeys.LogicalFieldsXPathKey.getSingle(enumPaymentType) ; 
		 
		 pathParentCacheEntry = mapFieldsXPath.get(logicalField.getPathParentId())  ;
		 fieldPathCacheEntry  = mapFieldsXPath.get(logicalField.getFieldLogicalId())  ;
		 
		 //if the fieldPathCacheEntry is null, then the field does not belong to the given payment type 
		 //and thus the case should return null 
		 if(fieldPathCacheEntry == null) sExtractValueTemplate = NULL ; 
		 else { 
			  
			//first format the extract value template 
			 sExtractValueTemplate = String.format(EXTRACTVALUE_TEMPLATE,
					 sExtractType, 
					 fieldPathCacheEntry.getLocation(), 
					 (pathParentCacheEntry == null ? "" : pathParentCacheEntry.getFieldPath()),
					 fieldPathCacheEntry.getFieldPath(), 
					 sXpathAppendum, 
					 enumPaymentType.getSchemaNamespace() ) ;
			 
			//if the sOccurenceIndex is not null AND not '-1', then the logical field is a multi occurrence one, 
			//which means that the index predicate must be inserted into the xpath 
			//if on the other hand the index is that of a multi occurrence aggregate ("-1") 
			//then the XML_SERIALIZE_TEMPLATE should be used to wrap the EXTRACTVALUE_TEMPLATE
			 if(bIsAggregateFunction) sExtractValueTemplate = String.format(XML_SERIALIZE_TEMPLATE, sExtractValueTemplate) ; 
 
		 }//EO else if there was an xpath 
		 
		 //if the logical field has a spacial formatting template apply it on the 
		 //extract value template 
		 if(fieldPathCacheEntry != null && fieldPathCacheEntry.getFormat() != null)
			 sExtractValueTemplate = String.format(fieldPathCacheEntry.getFormat(), sExtractValueTemplate) ; 
		 
		 //construct the when clause
		 caseBuilder.append(String.format(XML_CASE_TEMPLATE, 
				  enumPaymentType.name(), 
				  sExtractValueTemplate )) ;
	  }//EO while there are more payment types 
	  
	  //xml column - message type column correlation must adhere to the following convension: 
	  //	xml column name: 		XML_<type e.g. orig/cover>_MSG
	  //	msg type column name: 	P_<type e.g. orig.conver>_MSG_TYPE ; 
	  final String sMsgTypeColName = String.format(MSG_TYPE_COL_NAME_TEMPLATE, logicalField.getLocation().substring("XML_".length())) ; 
	  
	  //construct the complete case clause 
	  return (bIsInWhereClause ? "(" : "") +
	  		 String.format(XML_COLUMN_TEMLPATE, sMsgTypeColName,  
	  				 caseBuilder.toString(), (bIsInWhereClause ? "" : "\""+logicalField.getFieldLogicalId()+"\"" ) ) + 
	  		(bIsInWhereClause ? ")" : "") ; 
	}//EOM 
 	*/ 
 	
 	public String constructPaymentXmlColumnCase(final String sFieldLogicalId, boolean bIsInWhereClause, final String sOccurenceIndex)
 	{
 		return constructPaymentXmlColumnCase(sFieldLogicalId,bIsInWhereClause,sOccurenceIndex,null);
 	}
 	  
    
public String constructPaymentXmlColumnCaseMultiForQueueList(final String sFieldLogicalId, boolean bIsInWhereClause, final String sOccurenceIndex, XmlLocationType enumXmlLocationType) { 
 		
 		//Cases content 
		///field logical id 
		final String XML_COLUMN_TEMLPATE = "'<MultiValues xmlns=\"http://fundtech.com/SCL/QueueListService\">' || (CASE %s ELSE NULL END) || '</MultiValues>' %s" ;
		final String XML_COLUMN_TEMLPATE1 = "(CASE %s ELSE NULL END) %s" ;
		//final BackendTracer logger = GlobalTracer ;
		//= or like depending on the content of the payment type
		//msg type column
		//payment type, 
		//Extract value clause 
		String sIndividualCaseTemplate = "WHEN  %s %s %s THEN %s" ;
		
		final String LIKE = "LIKE" ; 
		final String EQUALS = "=" ;
		final String IN = "IN" ;
				
		final StringBuilder sbCaseBuilder = new StringBuilder() ;
		String sSingleCase = null, sXmlType = null, sColumnClause = null ;
		PaymentType enumPaymentType = null ; 
		
		final boolean bIsMultiOccurrenceClasue = !GlobalUtils.isNullOrEmpty(sOccurenceIndex) ;
		final boolean bIsAggregateFunction = bIsMultiOccurrenceClasue && sOccurenceIndex.equals(PDOConstantFieldsInterface.MULTI_OCCURRENCE_AGGREGATE_INDEICATOR) ; 
		  
		final String sXpathAppendum = (!bIsMultiOccurrenceClasue ? "" : (bIsAggregateFunction ? "/text()" : '[' + sOccurenceIndex + ']'  ) ) ;  
		
		PaymentType[] arrSupportedXmlTypes = AbstractXmlDao.getDBXmlTypes() ; 
		final int iLength = arrSupportedXmlTypes.length  ;
		int iNoOfSupoprtingPaymentTypes = 0 ;
	
		final LogicalFields logicalFieldMetadata = CacheKeys.LogicalFieldsIdKey.getSingleLogicalOrUserDefinedField(sFieldLogicalId) ;
	
		enumXmlLocationType =  enumXmlLocationType == null ? XmlLocationType.valueOf(logicalFieldMetadata) : enumXmlLocationType; 
		final List<String[]> listExtractValueClauses = new ArrayList<String[]>() ; 
		//(logicalFieldMetadata.getFieldType() == FieldType.ORIG_XML ? XmlLocationType.XML_ORIG_MSG : XmlLocationType.XML_MSG) ;
		for(int i=0; i < iLength; i++) { 
			
			enumPaymentType = arrSupportedXmlTypes[i] ; 
			logger.debug("[AbstractXmlDao.constructPaymentXmlColumnCase()]: Iterating over payment type: " + enumPaymentType.name());
			
			this.constructSinglePaymentXmlColumnCase(enumPaymentType,
					listExtractValueClauses, 
					logicalFieldMetadata, 
					enumXmlLocationType, 
					bIsMultiOccurrenceClasue, 
					sXpathAppendum, 
					new HashMap<String,String[]>(),/*sSuperTypeXPath*/
					sOccurenceIndex) ; 
			
			
			//enumPaymentType = arrSupportedXmlTypes[i] ; 
			//BackendTracer.logger.debug("Iterating over payment type: " + enumPaymentType.name()); 
			//sXmlType = enumPaymentType.getXmlTypeForDBCase() ; 
			//sXmlTypNamespaceURI = enumPaymentType.getSchemaNamespace() ; 
			
			//if the payment type's namespace already belongs to common types there is no need to add the common types namespace again
			//bXmlTypeBelongsToCommonTypes =  sXmlTypNamespaceURI.equals(COMMON_TYPES_NS) ; 
			

            
			//sXPath = PluginFactory.get(DASInterface.class).getLogicalFieldXpath(
				//	sFieldLogicalId, enumPaymentType, true, 
				//	(bXmlTypeBelongsToCommonTypes ? null : COMMON_TYPES_NS_PREFIX) ) ;
			
				// final Map<String, LogicalFieldsXpath> mapFieldsXPaths = CacheKeys.LogicalFieldsXPathKey.getSingle(enumPaymentType.name()) ;
				// if(mapFieldsXPaths != null) {
				//	 LogicalFieldsXpath logicalFieldsXpath = mapFieldsXPaths.get(sFieldLogicalId);
				//	 if(logicalFieldsXpath != null) {
				//	 	String tagName = logicalFieldsXpath.getTagName();
				//	 	sXPath = sXPath + "/" + tagName;
				//	 }
				// }
			//if the xpath is null, skip construction and appending  
			//if(sXPath == null) {
			//	BackendTracer.logger.debug("Xpath does not exist for field {}", sFieldLogicalId); 
			//	continue; 
			//}
			//BackendTracer.logger.debug("Xpath = " + sXPath); 
			
			/*//construct the extract value clause 
			//EXTRACT/EXTRACTVALUE
			//XML_MSG, XML_ORIG_MSG 
			//xpath 
			//multi occurrence predicate or /text() 
			//payment type namespace 
			//common types namespace (optional)
			sExtractValueClause = String.format(sExtractValueTemplate, 
					sExtractType,
					enumDbColumnName,
					sXPath, 
					sXpathAppendum,
					sXmlTypNamespaceURI, 
					(bXmlTypeBelongsToCommonTypes ? "" : String.format(COMMON_TYPES_NS_DECLERATION, COMMON_TYPES_NS_PREFIX, COMMON_TYPES_NS))
				);*/
			// Factory for  getting the correct strategy  class implementation for building sql query  INTERFACE_CONTENT
			//GenerateSingleExtractValueClause generateSingleExtractValueClause = getXqueryStrategy(enumXmlLocationType,GlobalConstants.getDbType());
			//sExtractValueClause = generateSingleExtractValueClause.generateSingleExtractValueClause(logicalFieldMetadata, bIsMultiOccurrenceClasue, enumXmlLocationType.getDbXmlLocation(), sXPath, sXpathAppendum, enumPaymentType, 
			//		bXmlTypeBelongsToCommonTypes) ; 
		 
			//listExtractValueClauses.add(new String[]{sXmlType, sExtractValueClause}) ;  
		}//EO while there are more supported payment types 
		
	    iNoOfSupoprtingPaymentTypes = listExtractValueClauses.size() ; 
		logger.debug("[AbstractXmlDao.constructPaymentXmlColumnCase()]: No Supported payment types = " + iNoOfSupoprtingPaymentTypes); 
		
		//if there are no supporting payment types return null 
		//else if there is only one Extract Value Clause, skip the case clause and use the 
		//extract value directly 
		String logicalFieldType = logicalFieldMetadata.getFieldType().name();
		if(iNoOfSupoprtingPaymentTypes == 0) return null ; 
		else if(iNoOfSupoprtingPaymentTypes == 1 && sOccurenceIndex == null) { 
			
			sColumnClause = listExtractValueClauses.get(0)[1]  ; 
			
			if(bIsInWhereClause) { 
				sColumnClause = logicalFieldMetadata.getDataType().configureSqlXmlColunmType(sColumnClause) ;  
			}else  {
				sColumnClause = sColumnClause + (" \"" + sFieldLogicalId + "\"")  ;
				} 
			
			return sColumnClause ;			
		}//EO if there was a single payment type supported 
		else if(iNoOfSupoprtingPaymentTypes == 1 && sOccurenceIndex != null) {
			sColumnClause = listExtractValueClauses.get(0)[1]  ; 
			
			if(bIsInWhereClause) { 
				sColumnClause = logicalFieldMetadata.getDataType().configureSqlXmlColunmType(sColumnClause) ;  
			}else  {sColumnClause = sColumnClause + (" \"" + sFieldLogicalId +  "["+ sOccurenceIndex + "]" + "\"")  ;} 
		}
		//else iterate over the list and construct a case for each 
		String sCaseOperator = null ; 
		String[] arrSingleExtractValueResources = null ; 
		for(int i=0; i < iNoOfSupoprtingPaymentTypes; i++) {
			arrSingleExtractValueResources = listExtractValueClauses.get(i) ;  

			sXmlType = arrSingleExtractValueResources[0] ; 
			
			if(sXmlType.indexOf(',') != -1) { 
				sXmlType = "('" + sXmlType.replaceAll(",", "','") + "')" ; 
				sCaseOperator = IN ; 
			}else { 
				sCaseOperator = (sXmlType.indexOf('%') != -1 ? LIKE  :EQUALS) ; 
				sXmlType = "'" + sXmlType + "'" ; 
			}//EO if there is just one payment type assoicated with a given xml 
			
			//= like or in depending on the content of the payment type  
			//payment type, 
			//Extract value clause  
			sSingleCase = String.format(sIndividualCaseTemplate,
					enumXmlLocationType.getCorrespondingMsgTypeField(), 
					sCaseOperator, 
					sXmlType,
					arrSingleExtractValueResources[1] 
				); 
			
			sbCaseBuilder.append(sSingleCase).append("\n") ;
		}//EO while there are more payment types 
		
		//if there is only a single case and the last selected payment type is EXTN, 
		//use do not constrct the case but simply return the case builder 
		  //construct the complete case clause 
		boolean isParentInd = logicalFieldMetadata.getPathParentInd();
		if(isParentInd) {
		  if(bIsInWhereClause) { 
					
					sColumnClause = String.format(XML_COLUMN_TEMLPATE,  
			  				 sbCaseBuilder.toString(), 
			  			     ""
			  				) ;
					
					//invoke the extract xml column type convertions required for types such as date and date time 
					 sColumnClause = logicalFieldMetadata.getDataType().configureSqlXmlColunmType(sColumnClause) ; 
				}else { 
					if(sOccurenceIndex == null) {
							 sColumnClause = String.format(XML_COLUMN_TEMLPATE,  
			  				 sbCaseBuilder.toString(), 
			  			     (" \"" + sFieldLogicalId + "\"")
			  			) ; 
						}
						else  {
							sColumnClause = String.format(XML_COLUMN_TEMLPATE,  
			  				 sbCaseBuilder.toString(), 
			  			     (" \"" + sFieldLogicalId +  "["+ sOccurenceIndex + "]" +  "\"")
			  			) ; 
						}
				}//EO else if select clause context 
		}
		else {
			if(bIsInWhereClause) { 
			  			     sColumnClause = String.format(XML_COLUMN_TEMLPATE,  
			  				 sbCaseBuilder.toString(), 
			  			     ""
			  				) ;
					
					//invoke the extract xml column type convertions required for types such as date and date time 
					 sColumnClause = logicalFieldMetadata.getDataType().configureSqlXmlColunmType(sColumnClause) ; 
				}else { 
					if(sOccurenceIndex == null) {
							 sColumnClause = String.format(XML_COLUMN_TEMLPATE1,  
			  				 sbCaseBuilder.toString(), 
			  			     (" \"" + sFieldLogicalId + "\"")
			  			) ; 
						}
						else {
							sColumnClause = String.format(XML_COLUMN_TEMLPATE1,  
			  				 sbCaseBuilder.toString(), 
			  			     (" \"" + sFieldLogicalId +  "["+ sOccurenceIndex + "]" +  "\"")
			  			) ; 
						}
				}//EO else if select clause context 
		}
		return sColumnClause ; 
		 //construct the complete case clause 
		
 	}//EOM   
 	
 	
 	/**
 	 * @param sOccurenceIndex nullable and must start from one. acts as a flag indicating whether to aggregate the occurrences
 	 * if the value is "-1"  (PDOConstantFieldsInterface.MULTI_OCCURRENCE_AGGREGATE_INDEICATOR)
 	 * Note: currently supports only oracle syntax
 	 */
 	public String constructPaymentXmlColumnCase(final String sFieldLogicalId, boolean bIsInWhereClause, final String sOccurenceIndex, XmlLocationType enumXmlLocationType) { 
 		//final BackendTracer logger = GlobalTracer ;
 		
 		//Cases content 
		///field logical id 
		final String XML_COLUMN_TEMLPATE = "(CASE %s ELSE '' END) %s" ;
	
		//= or like depending on the content of the payment type
		//msg type column
		//payment type with or without ' enclosers, 
		//Extract value clause 
		String sIndividualCaseTemplate = "WHEN %s %s %s THEN %s" ;
		
		final String LIKE = "LIKE" ; 
		final String EQUALS = "=" ;
		final String IN = "IN" ;
				
		final StringBuilder sbCaseBuilder = new StringBuilder() ;
		String sSingleCase = null, sXmlType = null, sColumnClause = null ;
		PaymentType enumPaymentType = null ; 
		
		final boolean bIsMultiOccurrenceClasue = !GlobalUtils.isNullOrEmpty(sOccurenceIndex) ;
		final boolean bIsAggregateFunction = bIsMultiOccurrenceClasue && sOccurenceIndex.equals(PDOConstantFieldsInterface.MULTI_OCCURRENCE_AGGREGATE_INDEICATOR) ; 
		  
		final String sXpathAppendum = (!bIsMultiOccurrenceClasue ? "" : (bIsAggregateFunction ? "/text()" : '[' + sOccurenceIndex + ']'  ) ) ;  
		
		PaymentType[] arrSupportedXmlTypes = AbstractXmlDao.getDBXmlTypes() ; 
		final int iLength = arrSupportedXmlTypes.length  ;
		int iNoOfSupoprtingPaymentTypes = 0 ;
	
		final LogicalFields logicalFieldMetadata = CacheKeys.LogicalFieldsIdKey.getSingleLogicalOrUserDefinedField(sFieldLogicalId) ;
	
		enumXmlLocationType =  enumXmlLocationType == null ? XmlLocationType.valueOf(logicalFieldMetadata) : enumXmlLocationType; 
			//(logicalFieldMetadata.getFieldType() == FieldType.ORIG_XML ? XmlLocationType.XML_ORIG_MSG : XmlLocationType.XML_MSG) ;
		final List<String[]> listExtractValueClauses = new ArrayList<String[]>() ; 
		
		for(int i=0; i < iLength; i++) { 
			enumPaymentType = arrSupportedXmlTypes[i] ; 
			logger.debug("[AbstractXmlDao.constructPaymentXmlColumnCase()]: Iterating over payment type: " + enumPaymentType.name());
			
			this.constructSinglePaymentXmlColumnCase(enumPaymentType,
					listExtractValueClauses, 
					logicalFieldMetadata, 
					enumXmlLocationType, 
					bIsMultiOccurrenceClasue, 
					sXpathAppendum, 
					new HashMap<String,String[]>(),/*sSuperTypeXPath*/
					 "") ; 
			
			/*
			enumPaymentType = arrSupportedXmlTypes[i] ; 
			logger.info(logger.debug("[AbstractXmlDao.constructPaymentXmlColumnCase()]: Iterating over payment type: " + enumPaymentType.name())) ; 
			
			sXmlType = enumPaymentType.getXmlTypeForDBCase() ; 
			sXmlTypNamespaceURI = enumPaymentType.getSchemaNamespace() ; 
			
			//if the payment type's namespace already belongs to common types there is no need to add the common types namespace again
			bXmlTypeBelongsToCommonTypes =  sXmlTypNamespaceURI.equals(COMMON_TYPES_NS) ; 
		            
			sXPath = das.getLogicalFieldXpath(sFieldLogicalId, 
					enumPaymentType, true,
					//bStartFromFndtMdg 
					(bXmlTypeBelongsToCommonTypes ? null : COMMON_TYPES_NS_PREFIX)
					//sFndtMsgNsPrefix
					) ;
			
			//if the xpath is null, skip construction and appending  
			if(sXPath == null) {
				logger.info(logger.debug("[AbstractXmlDao.constructPaymentXmlColumnCase()]: Xpath does not exist for field {} in Pament type", sFieldLogicalId, enumPaymentType)) ; 
				continue; 
			}//EO if no xpath was defined for the logical field in the context of the iteration payment type 
			
			logger.debug("AbstractXmlDao.constructPaymentXmlColumnCase()]: Xpath = " + sXPath); 
			
			//if the payment type supports sub types iterate over the subtype and 
			//compare the xpath of each with the one of the super type 
			//and construct an xml column case for all those which differ.
			if( (listSubTypes = enumPaymentType.getSubTypes()) != null) {

				for(PaymentType enumSubPaymentType : listSubTypes) { 
					
				}//EO whlie there are more subTypes 
				
			}//EO if there are subtypes 
			
			//construct the extract value clause 
			//EXTRACT/EXTRACTVALUE
			//XML_MSG, XML_ORIG_MSG 
			//xpath 
			//multi occurrence predicate or /text() 
			//payment type namespace 
			//common types namespace (optional)
			
			// Factory for  getting the correct strategy  class implementation for building sql query  INTERFACE_CONTENT
			GenerateSingleExtractValueClause generateSingleExtractValueClause = this.getXqueryStrategy(enumXmlLocationType,GlobalConstants.getDbType());
			sExtractValueClause = generateSingleExtractValueClause.generateSingleExtractValueClause(logicalFieldMetadata, bIsMultiOccurrenceClasue, enumXmlLocationType.getDbXmlLocation(), sXPath, sXpathAppendum, enumPaymentType, 
					bXmlTypeBelongsToCommonTypes) ; 
		 
			listExtractValueClauses.add(new String[]{sXmlType, sExtractValueClause}) ;  
			*/ 
		}//EO while there are more supported payment types 
		
		iNoOfSupoprtingPaymentTypes = listExtractValueClauses.size() ; 
		logger.debug("[AbstractXmlDao.constructPaymentXmlColumnCase()]: No Supported payment types = " + iNoOfSupoprtingPaymentTypes); 
		
		//if there are no supporting payment types return null 
		//else if there is only one Extract Value Clause, skip the case clause and use the 
		//extract value directly 
		if(iNoOfSupoprtingPaymentTypes == 0) return null ; 
		else if(iNoOfSupoprtingPaymentTypes == 1) { 
			
			sColumnClause = listExtractValueClauses.get(0)[1]  ; 
			
			if(bIsInWhereClause) { 
				sColumnClause = logicalFieldMetadata.getDataType().configureSqlXmlColunmType(sColumnClause) ;  
			}else sColumnClause = sColumnClause + (" \"" + sFieldLogicalId + "\"")  ; 
			
			return sColumnClause ;			
		}//EO if there was a single payment type supported 
		
		//else iterate over the list and construct a case for each 
		String sCaseOperator = null ; 
		String[] arrSingleExtractValueResources = null ; 
		for(int i=0; i < iNoOfSupoprtingPaymentTypes; i++) {
			arrSingleExtractValueResources = listExtractValueClauses.get(i) ;  

			sXmlType = arrSingleExtractValueResources[0] ; 
			
			if(sXmlType.indexOf(',') != -1) { 
				sXmlType = "('" + sXmlType.replaceAll(",", "','") + "')" ; 
				sCaseOperator = IN ; 
			}else { 
				sCaseOperator = (sXmlType.indexOf('%') != -1 ? LIKE  :EQUALS) ; 
				sXmlType = "'" + sXmlType + "'" ; 
			}//EO if there is just one payment type assoicated with a given xml 
			
			//= like or in depending on the content of the payment type  
			//payment type, 
			//Extract value clause  
			sSingleCase = String.format(sIndividualCaseTemplate,
					enumXmlLocationType.getCorrespondingMsgTypeField(), 
					sCaseOperator, 
					sXmlType,
					arrSingleExtractValueResources[1] 
				); 
			
			sbCaseBuilder.append(sSingleCase).append("\n") ;
		}//EO while there are more payment types 
		
		//if there is only a single case and the last selected payment type is EXTN, 
		//use do not constrct the case but simply return the case builder 
		 
		if(bIsInWhereClause) { 
			
			sColumnClause = String.format(XML_COLUMN_TEMLPATE,  
	  				 sbCaseBuilder.toString(), 
	  			     ""
	  				) ;
			
			//invoke the extract xml column type convertions required for types such as date and date time 
			 sColumnClause = logicalFieldMetadata.getDataType().configureSqlXmlColunmType(sColumnClause) ; 
		}else { 
			sColumnClause = String.format(XML_COLUMN_TEMLPATE,  
	  				 sbCaseBuilder.toString(), 
	  			     (" \"" + sFieldLogicalId + "\"")
	  			) ; 
		}//EO else if select clause context 
		
		return sColumnClause ; 
		 //construct the complete case clause 
		
 	}//EOM 
 	
 	private void constructSinglePaymentXmlColumnCase(final PaymentType enumPaymentType, 
 			final List<String[]> listConstructedCases, 
 			final LogicalFields logicalFieldMetadata, 
 			final XmlLocationType enumXmlLocationType,
 			final boolean bIsMultiOccurrenceClause, final String sXpathAppendum, 
 			Map<String,String[]> mapSubTypesXpathes,
 			final String sOccurenceIndex) { 
 		
 		//final BackendTracer logger = GlobalTracer ;
		logger.debug("[AbstractXmlDao.constructPaymentXmlColumnCase()]: Iterating over payment type: " + enumPaymentType.name()); 
		
		final String sXmlType = enumPaymentType.getXmlTypeForDBCase() ; 
		final String sXmlTypNamespaceURI = enumPaymentType.getSchemaNamespace() ; 
		final String sFieldLogicalId = logicalFieldMetadata.getFieldLogicalId() ; 
		
		//if the payment type's namespace already belongs to common types there is no need to add the common types namespace again
		final boolean bXmlTypeBelongsToCommonTypes =  sXmlTypNamespaceURI.equals(COMMON_TYPES_NS) ; 
	           
		String sXPath = PluginFactory.get(DASInterface.class).getLogicalFieldXpath(
				sFieldLogicalId, 
				enumPaymentType, true/*bStartFromFndtMdg*/, 
				(bXmlTypeBelongsToCommonTypes ? null : COMMON_TYPES_NS_PREFIX)/*sFndtMsgNsPrefix*/) ;
		
		boolean bIsXMLMultiChild = logicalFieldMetadata.isXMLMultiChild();
		FieldType fieldTypeForXqueryGenerator = null;
		boolean bIsXmlMulti = FieldType.isXmlMulti(logicalFieldMetadata.getFieldType());
		if(   bIsMultiOccurrenceClause || bIsXmlMulti
			 || (logicalFieldMetadata.enumFieldType == FieldType.XML_TEXT && bIsXMLMultiChild))
		{
			 final Map<String, LogicalFieldsXpath> mapFieldsXPaths = CacheKeys.LogicalFieldsXPathKey.getSingle(enumPaymentType.name()) ;
				if(mapFieldsXPaths != null) {
					LogicalFieldsXpath logicalFieldsXpath = mapFieldsXPaths.get(sFieldLogicalId);
					
					if(logicalFieldsXpath != null) 
					{
						if(bIsXmlMulti) 
						{
						 	String tagName = logicalFieldsXpath.getTagName();
						 	sXPath = sXPath + "/" + tagName;
 					  }
						else if(logicalFieldMetadata.enumFieldType == FieldType.XML_TEXT && bIsXMLMultiChild)
						{
							fieldTypeForXqueryGenerator = FieldType.XML_TEXT;
						}
						
					 else if (!sOccurenceIndex.equals("")){
						 	String tagName = logicalFieldsXpath.getTagName();
						 	sXPath = sXPath.substring(0,sXPath.lastIndexOf("/"));
						 	sXPath = sXPath + "[" + sOccurenceIndex + "]" + "/" + tagName;
					 }
					}
				 }
		}
		String sXmlTypesForPath = null ;
		String[] arrExtractClauseResources = null ;
		
		//if the xpath is null, skip construction and appending  
		if(sXPath == null) {
			logger.debug("[AbstractXmlDao.constructPaymentXmlColumnCase()]: Xpath does not exist for field {} in Pament type", sFieldLogicalId, enumPaymentType); 
			return ;
		}//EO if no xpath was defined for the logical field in the context of the iteration payment type
		else if( (arrExtractClauseResources = mapSubTypesXpathes.get(sXPath)) != null ) { 
			logger.debug("[AbstractXmlDao.constructPaymentXmlColumnCase()]: Xpath '{}' was the same as super Type's for sub type", sXPath, enumPaymentType);
			
			sXmlTypesForPath = arrExtractClauseResources[0] ; 
			//if the sXmlTypesForPath contains a '%' then the case would be constrcuted with a LIKE and therefore, 
			//there is no need to append the current xml type to the sXmlTypesForPath
			if(sXmlTypesForPath.indexOf('%') == -1) { 
				arrExtractClauseResources[0] = sXmlTypesForPath + ',' + sXmlType ;  
			}//EO if the xmltype for the given path was not associated with a like clause
			
			return ;
		}//EO else if the current xpath was already defined for type data set 
		else { 
			//create a new arrExtractClauseResources string[] 
			//and store it in the map agains the xpath 
			arrExtractClauseResources = new String[]{ sXmlType, null/*sExtractClause*/ } ; 
			mapSubTypesXpathes.put(sXPath, arrExtractClauseResources) ;
		}//EO else xpath was defined for the payment type but not yet for the type hierarchy 
		
		logger.debug("AbstractXmlDao.constructPaymentXmlColumnCase()]: Xpath = " + sXPath); 
		
		List<PaymentType> listSubTypes = null ;
		
		//if the payment type supports sub types iterate over the subtype and 
		//compare the xpath of each with the one of the super type 
		//and construct an xml column case for all those which differ.
		//Note: this must occur prior to the construction and additio 
		//if the super type's case clause as subtypes cases should 
		//be evaluated by the query first 
		if( (listSubTypes = enumPaymentType.getSubTypes()) != null) {

			for(PaymentType enumSubPaymentType : listSubTypes) { 

				//recurse into this method 
				this.constructSinglePaymentXmlColumnCase(
						enumSubPaymentType, 
						listConstructedCases, 
						logicalFieldMetadata, 
						enumXmlLocationType, 
						bIsMultiOccurrenceClause, 
						sXpathAppendum, 
						mapSubTypesXpathes,
						 "")  ;
			}//EO whlie there are more subTypes 
			
		}//EO if there are subtypes 
		
		/*//construct the extract value clause 
		//EXTRACT/EXTRACTVALUE
		//XML_MSG, XML_ORIG_MSG 
		//xpath 
		//multi occurrence predicate or /text() 
		//payment type namespace 
		//common types namespace (optional)
		sExtractValueClause = String.format(sExtractValueTemplate, 
				sExtractType,
				enumDbColumnName,
				sXPath, 
				sXpathAppendum,
				sXmlTypNamespaceURI, 
				(bXmlTypeBelongsToCommonTypes ? "" : String.format(COMMON_TYPES_NS_DECLERATION, COMMON_TYPES_NS_PREFIX, COMMON_TYPES_NS))
			);*/
		
		// Factory for  getting the correct strategy  class implementation for building sql query  INTERFACE_CONTENT
		final GenerateSingleExtractValueClause generateSingleExtractValueClause = this.getXqueryStrategy(enumXmlLocationType,GlobalConstants.getDbType(), fieldTypeForXqueryGenerator);
		 String sExtractValueClause ="";
		if(bIsMultiOccurrenceClause && logicalFieldMetadata.getFieldType().name().equals("XML_MULTI")) {
		       sExtractValueClause = generateSingleExtractValueClause.generateSingleExtractValueClause(logicalFieldMetadata, bIsMultiOccurrenceClause, enumXmlLocationType.getDbXmlLocation(), sXPath, sXpathAppendum, enumPaymentType, 
					bXmlTypeBelongsToCommonTypes) ;
		}
		else {
			 sExtractValueClause = generateSingleExtractValueClause.generateSingleExtractValueClause(logicalFieldMetadata, bIsMultiOccurrenceClause, enumXmlLocationType.getDbXmlLocation(), sXPath, "", enumPaymentType, 
					bXmlTypeBelongsToCommonTypes) ;
		}
		//add the extract clause to the arrExtractClauseResources and add to the list 
		arrExtractClauseResources[1] = sExtractValueClause ; 
		listConstructedCases.add(arrExtractClauseResources) ;  
 		
 	}//EOM 
 	
 	private GenerateSingleExtractValueClause getXqueryStrategy(XmlLocationType xmlLocationType,DBTypeInterface dbType, FieldType fieldType) 
 	{
 		StringBuilder sbBeanName = new StringBuilder(100).append("backend.dataaccess.dao.xquerygenerators.");
 		// The following is so the 'XML_TEXT_XML_MSG_Xquerygenerator' class will be used for XML fields which 
 		// their parent is a multi field that its location is XML_MSG or XML_MSG_EXTN.
 		// NOTE: No handling for now for following XML locations: XML_ORIG_MSG, XML_ORIG_MSG_EXTN.
 		if(fieldType == FieldType.XML_TEXT && xmlLocationType == xmlLocationType.XML_MSG_EXTN) xmlLocationType = xmlLocationType.XML_MSG;
 		String beanName = fieldType == null ? sbBeanName.append(dbType.toString()).append("_").append(xmlLocationType.name()).append("_Xquerygenerator").toString() :
 			                                    sbBeanName.append(fieldType.name()).append("_").append(xmlLocationType.name()).append("_Xquerygenerator").toString();
 		 
 		try {
			final Class<? extends GenerateSingleExtractValueClause> clsGeneratorStrategy = (Class<? extends GenerateSingleExtractValueClause>)
																				Thread.currentThread().getContextClassLoader().loadClass(beanName) ;
 			
			GenerateSingleExtractValueClause generateSingleExtractValueClause = ServiceLocator.getInstance().getNsetSpringBean(beanName, clsGeneratorStrategy) ;
			if(null == generateSingleExtractValueClause) {
				return this;
			}
			return generateSingleExtractValueClause;
 		} catch (Throwable e) {
			return this;
		}
 	}
 	 
 	
 	/**
 	 * @author guys
 	 * 
 	 * Class containg all required data for the consturction of a given xml sql query.
 	 *
 	 */
	public class CommandInfo { 

		
		private Connection m_connection ;
		private String m_sQueryTemplate ; 
		private String m_sNamespace ; 
		private String m_sTableName ;
		private String m_sColumnName ; 
		private String m_sWhereClause  ; 
		private StatementParameter[] m_arrStatementParameters ;
		private List<NodeGroupInfo> m_listNodeGroupInfo ;
				
		public CommandInfo(final Connection connection) { 
			this.m_connection = connection ;
			m_listNodeGroupInfo = new ArrayList<NodeGroupInfo>() ; 
		}//EOM
		
		/**
		 * 
		 * Recommended constructor for soley XML column extraction. 
		 * 
		 * @param connection opened connection to use for the query execution.
		 *  @param sNamespace All XML nodes are considered fullly qualified and comprised of two parts : <namespace>:<local element name>. 
		 *	Thus in order to access a given element, the default behaviour dictates that the namespace (or a prefix alias 
		 *	which might be nothing if so declared in the xmlns prolog) must be defined along with the element name. 
		 *	In order to emulate a namespce unaware behaviour, all elments must be prefixed by one of the following delerations: 
		 *	1.  *:<element local name> - defines the element as belonging to all namespaces. 
		 *	2.  *[local-name()="<element local name>"]
		 *	3.  *[name()="<element local name>"]
		 *	As writing and maintaing xpaths containing such declarations is unreasonably tedious, all methods in this class 
		 *	provide the following facility: 
		 *		If the namespce is provided, the methods will declare it as the default element namespace thus alliviating 
		 *		the neeed for namespace prefix.
		 *		Otherwise if the namespace was not provided, the methods will modify all xpath queries provided 
		 *		to include either the first or the third aforementioned option. 
		 *		Please adhere be the following rules while developing an xpath query: 
		 *		1. xpath might already be enriched by the '*:' namespace, in which case, the methods will not modify the xpath. 
		 *		   This behaviour is applied to each xpath element individually (i.e. those nodes declared without the 
		 *		   prefix would be modified while those containing the declaration will not). 
		 *		2. xpath must not contain the local() or local-name() declaration in conjunction with null namespace 
		 *		   as the methods will not check for the existence of the constructs, and will hence render the xpath 
		 *		   query invalid by adding the construct again.
		 *		   In other words, when providing no namespace, provide xpath queries that do not contain 
		 *		   namespace declaration. The various method will ensure that those are added.
		 *		 
		 *	 	Note: currently, a single namespace declaration is supported through this method. Nevertheless, as the db syntax 
		 *	 	 * 		 supports multiple namespace declarations, if the need arises, the method could be altered to accomodate it.
		 *	 	 * 		 The current implementation, for convenience sake, decalres a no-prefix namespace so that the elementXPath
		 *		 * 		 value should not be altered to include the namespace prefix.
		 * Note: The namespace value provided here would be declared in the enclosing 'root' root element.
		 * @param sTablename DB table name on which to perform the select statement. 
		 * @param sColumnname DB column name from which to extract values.
		 * @param sAdditionalWereclause Additional filter, unrelated to the xml column.
		 */
		public CommandInfo(final Connection connection, final String sNamespace, final String sTablename, final String sColumnname, 
				final String sAdditionalWereclause) { 
			
			this(connection) ; 
			this.m_sNamespace = sNamespace ; 
			this.m_sTableName = sTablename ; 
			this.m_sColumnName = sColumnname ; 
			this.m_sWhereClause = sAdditionalWereclause ; 
		}//EOM
		
		/**
		 * 
		 * Recommended constructor for relational and XML data retrival combination or in complex queries 
		 * involving joins and aggregation functions. 
		 * 
		 * @param connection opened connection to use for the query execution.
		 *  @param sNamespace All XML nodes are considered fullly qualified and comprised of two parts : <namespace>:<local element name>. 
		 *	Thus in order to access a given element, the default behaviour dictates that the namespace (or a prefix alias 
		 *	which might be nothing if so declared in the xmlns prolog) must be defined along with the element name. 
		 *	In order to emulate a namespce unaware behaviour, all elments must be prefixed by one of the following delerations: 
		 *	1.  *:<element local name> - defines the element as belonging to all namespaces. 
		 *	2.  *[local-name()="<element local name>"]
		 *	3.  *[name()="<element local name>"]
		 *	As writing and maintaing xpaths containing such declarations is unreasonably tedious, all methods in this class 
		 *	provide the following facility: 
		 *		If the namespce is provided, the methods will declare it as the default element namespace thus alliviating 
		 *		the neeed for namespace prefix.
		 *		Otherwise if the namespace was not provided, the methods will modify all xpath queries provided 
		 *		to include either the first or the third aforementioned option. 
		 *		Please adhere be the following rules while developing an xpath query: 
		 *		1. xpath might already be enriched by the '*:' namespace, in which case, the methods will not modify the xpath. 
		 *		   This behaviour is applied to each xpath element individually (i.e. those nodes declared without the 
		 *		   prefix would be modified while those containing the declaration will not). 
		 *		2. xpath must not contain the local() or local-name() declaration in conjunction with null namespace 
		 *		   as the methods will not check for the existence of the constructs, and will hence render the xpath 
		 *		   query invalid by adding the construct again.
		 *		   In other words, when providing no namespace, provide xpath queries that do not contain 
		 *		   namespace declaration. The various method will ensure that those are added.
		 *		 
		 *	 	Note: currently, a single namespace declaration is supported through this method. Nevertheless, as the db syntax 
		 *	 	 * 		 supports multiple namespace declarations, if the need arises, the method could be altered to accomodate it.
		 *	 	 * 		 The current implementation, for convenience sake, decalres a no-prefix namespace so that the elementXPath
		 *		 * 		 value should not be altered to include the namespace prefix.
		 * Note: The namespace value provided here would be declared in the enclosing 'root' root element. 
		 * @param sColumnname DB column name from which to extract values.
		 * @param sQueryTemplate Complete SQL statement containing a  single place holder adhering 
		 * 		  to the java.util.Formatter protocol. provided as an alternative to complete query construction
		 * 		  approach and should be used when relational data is required as well as XML data. 
		 */
		public CommandInfo(final Connection connection, final String sNamespace,  final String sColumnname, 
				final String sQueryTemplate) { 
			
			this(connection) ; 
			this.m_sNamespace = sNamespace ;  
			this.m_sColumnName = sColumnname ; 
			this.m_sQueryTemplate = sQueryTemplate ; 
		}//EOM
		
		/**
		 * @return internal opened connection.
		 */
		public final Connection getConnection() { 
			return this.m_connection ; 
		}//EOM
		
		/**
		 *  @param sNamespace All XML nodes are considered fullly qualified and comprised of two parts : <namespace>:<local element name>. 
		 *	Thus in order to access a given element, the default behaviour dictates that the namespace (or a prefix alias 
		 *	which might be nothing if so declared in the xmlns prolog) must be defined along with the element name. 
		 *	In order to emulate a namespce unaware behaviour, all elments must be prefixed by one of the following delerations: 
		 *	1.  *:<element local name> - defines the element as belonging to all namespaces. 
		 *	2.  *[local-name()="<element local name>"]
		 *	3.  *[name()="<element local name>"]
		 *	As writing and maintaing xpaths containing such declarations is unreasonably tedious, all methods in this class 
		 *	provide the following facility: 
		 *		If the namespce is provided, the methods will declare it as the default element namespace thus alliviating 
		 *		the neeed for namespace prefix.
		 *		Otherwise if the namespace was not provided, the methods will modify all xpath queries provided 
		 *		to include either the first or the third aforementioned option. 
		 *		Please adhere be the following rules while developing an xpath query: 
		 *		1. xpath might already be enriched by the '*:' namespace, in which case, the methods will not modify the xpath. 
		 *		   This behaviour is applied to each xpath element individually (i.e. those nodes declared without the 
		 *		   prefix would be modified while those containing the declaration will not). 
		 *		2. xpath must not contain the local() or local-name() declaration in conjunction with null namespace 
		 *		   as the methods will not check for the existence of the constructs, and will hence render the xpath 
		 *		   query invalid by adding the construct again.
		 *		   In other words, when providing no namespace, provide xpath queries that do not contain 
		 *		   namespace declaration. The various method will ensure that those are added.
		 *		 
		 *	 	Note: currently, a single namespace declaration is supported through this method. Nevertheless, as the db syntax 
		 *	 	 * 		 supports multiple namespace declarations, if the need arises, the method could be altered to accomodate it.
		 *	 	 * 		 The current implementation, for convenience sake, decalres a no-prefix namespace so that the elementXPath
		 *		 * 		 value should not be altered to include the namespace prefix.
		 * Note: The namespace value provided here would be declared in the enclosing 'root' root element.
		 */
		public final String getNamespace() { 
			return this.m_sNamespace ; 
		}//EOM 
		
		/**
		 *  @param sNamespace All XML nodes are considered fullly qualified and comprised of two parts : <namespace>:<local element name>. 
		 *	Thus in order to access a given element, the default behaviour dictates that the namespace (or a prefix alias 
		 *	which might be nothing if so declared in the xmlns prolog) must be defined along with the element name. 
		 *	In order to emulate a namespce unaware behaviour, all elments must be prefixed by one of the following delerations: 
		 *	1.  *:<element local name> - defines the element as belonging to all namespaces. 
		 *	2.  *[local-name()="<element local name>"]
		 *	3.  *[name()="<element local name>"]
		 *	As writing and maintaing xpaths containing such declarations is unreasonably tedious, all methods in this class 
		 *	provide the following facility: 
		 *		If the namespce is provided, the methods will declare it as the default element namespace thus alliviating 
		 *		the neeed for namespace prefix.
		 *		Otherwise if the namespace was not provided, the methods will modify all xpath queries provided 
		 *		to include either the first or the third aforementioned option. 
		 *		Please adhere be the following rules while developing an xpath query: 
		 *		1. xpath might already be enriched by the '*:' namespace, in which case, the methods will not modify the xpath. 
		 *		   This behaviour is applied to each xpath element individually (i.e. those nodes declared without the 
		 *		   prefix would be modified while those containing the declaration will not). 
		 *		2. xpath must not contain the local() or local-name() declaration in conjunction with null namespace 
		 *		   as the methods will not check for the existence of the constructs, and will hence render the xpath 
		 *		   query invalid by adding the construct again.
		 *		   In other words, when providing no namespace, provide xpath queries that do not contain 
		 *		   namespace declaration. The various method will ensure that those are added.
		 *		 
		 *	 	Note: currently, a single namespace declaration is supported through this method. Nevertheless, as the db syntax 
		 *	 	 * 		 supports multiple namespace declarations, if the need arises, the method could be altered to accomodate it.
		 *	 	 * 		 The current implementation, for convenience sake, decalres a no-prefix namespace so that the elementXPath
		 *		 * 		 value should not be altered to include the namespace prefix.
		 * Note: The namespace value provided here would be declared in the enclosing 'root' root element.
		 */
		public final void setNamespace(final String sNamespace) { 
			this.m_sNamespace = sNamespace ; 
		}//EOM
		
		/**
		 * @return DB table name on which to perform the select statement. Used for internal 
		 * construction of the complete SQL statement.
		 * Note: expected to be null if the QueryTemplate is provided   
		 */
		public final String getTablename() { 
			return this.m_sTableName ; 
		}//EOM
		
		/**
		 * @param sTablename DB table name on which to perform the select statement. Used for internal 
		 * construction of the complete SQL statement.
		 */
		public final void setTablename(final String sTablename) { 
			this.m_sTableName = sTablename ; 
		}//EOm 
		
		/**
		 * @return DB column name from which to extract values.
		 */
		public final String getColumnname() {
			 return this.m_sColumnName ; 
		}//EOM
		
		/**
		 * @param sColumnname DB column name from which to extract values.
		 */
		public final void setColumnname(final String sColumnname) { 
			this.m_sColumnName = sColumnname ; 
		}//EOM
		
		/**
		 * @param sQueryTemplate Complete sql statment containing a single 
		 * place holder to be replaced by the generated xmlquery clause. 
		 * Note: Place holder must adhere to the java.util.Formatter protocol (e.g '%s') 
		 */
		public final void setQueryTemplate(final String sQueryTemplate) { 
			this.m_sQueryTemplate = sQueryTemplate; 
		}//EOM
		
		/**
		 * @return sQueryTemplate Complete sql statment containing a single 
		 * place holder to be replaced by the generated xmlquery clause. 
		 * Note: Place holder must adhere to the java.util.Formatter protocol (e.g '%s')
		 */
		public final String getQueryTemplate(){ 
			return this.m_sQueryTemplate ; 
		}//EOM
		
		/**
		 * Dec 27, 2007
		 * guys
		 *
		 * @param arrStatementParameters Additional binding parameters to be set into the 
		 * prepared Statement. 
		 * Note: might be null. 
		 */
		public final void setStatementParameters(StatementParameter...arrStatementParameters) { 
			this.m_arrStatementParameters = arrStatementParameters ; 
		}//EOM 
		
		/**
		 * Dec 27, 2007
		 * guys
		 *
		 * @return arrStatementParameters Additional binding parameters to be set into the 
		 * prepared Statement. 
		 * Note: might be null. 
		 */
		public final StatementParameter[] getStatementParameters() { 
			return this.m_arrStatementParameters ; 
		}//EOM
		
		/**
		 * @return Additional filter, unrelated to the xml column. Used for internal 
		 * construction of the complete SQL statement.
		 * Note: expected to be null if the QueryTemplate is provided   
		 */
		public final String getAdditionalWhereclause() { 
			return this.m_sWhereClause ; 
		}//EOM 
		
		/**
		 * @param sAdditionalWhereclause Additional filter, unrelated to the xml column. Used for internal 
		 * construction of the complete SQL statement.
		 */
		public final void setAdditionalWhereclause(final String sAdditionalWhereclause) { 
			this.m_sWhereClause = sAdditionalWhereclause ; 
		}//EOM
		
		/**
		 * Adds a new NodeGroup instance to the internal node group list (this corresponds to 
		 * adding an additional xml xPath and multiple sub elements for update)  
		 * 
		 * @param sParentXPath Context root element whose sub elements (stored in the internal NodeInfo) 
		 * should be updated.
		 * 
		 * @return The created NodeGroupInfo instance.
		 */
		public final NodeGroupInfo addNodeGroup(final String sParentXPath) {
			NodeGroupInfo nodeGroupInfo = new NodeGroupInfo(sParentXPath) ;
			
			this.m_listNodeGroupInfo.add(nodeGroupInfo)  ;
			
			return nodeGroupInfo ; 
		}//EOM 
		
		/**
		 * Convenience method for creating a node group along with a single sub node update element (NodeInfo) 
		 * For instance: 
		 * Node group: Parent xpath = //Employee 
		 * 		Node info: update node xpath : //phone-numnber/text()  update node new value = "23234"
		 * 
		 * @param sParentXPath xpath returiing the context root(s) under which one or more nodes 
		 * are to be updated.
		 * @param sColumnXpath Xpath relative to the context root returning a child element whose value is to be 
		 * udpated. 
		 * @param sColumnValue new node value
		 * @return Created NodeGroupInfo instance.
		 */
		public final NodeGroupInfo addSingleUpdateNodeGroup(final String sParentXPath, 
							final String sColumnXpath, final String sColumnValue) {
			
			NodeGroupInfo nodeGroup = new NodeGroupInfo(sParentXPath) ; 
			nodeGroup.addNodeInfo(sColumnXpath, sColumnValue) ; 
			
			this.m_listNodeGroupInfo.add(nodeGroup)  ; 
			
			return nodeGroup ; 
		}//EOM 
		
		/**
		 * Dec 27, 2007
		 * guys
		 * 
		 * Single element xpath 
		 *
		 * @param sElementXpath
		 */
		public final void setSelectElementXpath(final String sElementXpath) { 
			final NodeGroupInfo nodeGroup = new NodeGroupInfo(sElementXpath) ; 
			
			if(this.m_listNodeGroupInfo.isEmpty()) this.m_listNodeGroupInfo.add(nodeGroup) ;
			else this.m_listNodeGroupInfo.set(0,nodeGroup) ; 
		}//EOM
		
		public final String getSelectElementXpath() { 
			return this.m_listNodeGroupInfo.get(0).m_sParentXPath ; 
		}//EOM
		
		/**
		 * @return All NodeGroups (i.e. all context roots under which to update nodes)
		 */
		public Iterator<NodeGroupInfo> nodeGroupIterator() { 
			return this.m_listNodeGroupInfo.iterator() ;
		}///EOM 
				
		/**
		 * @author guys
		 * 
		 * Container class representing the following generated sql/xml query block: 
		 * 
		 *  for $e in $newDoc//pacs.008.001.01/GrpHdr 
 		 *  	return (
 		 *  			do replace value of $e/MsgId with $a,
 		 *  			do replace value of $e/TtlIntrBkSttlmAmt with $b
 		 *  			)
 		 *  
 		 *  whereby the m_sParentXPath is the '//pacs.008.001.01/GrpHdr '
 		 *  and the m_listUpdateNodes individual NodeInfo instances are mapped to '/MsgId' and '/TtlIntrBkSttlmAmt'
		 *
		 */
		public final class NodeGroupInfo { 
			public  String m_sParentXPath ;  
			public List<NodeInfo> m_listUpdateNodes ; 
			
			NodeGroupInfo(final String sParentXPath) { 
				this.m_sParentXPath = sParentXPath;  
				this.m_listUpdateNodes = new ArrayList<NodeInfo>() ;	
			}//EOM 
			
			/**
			 * @return All NodeInfo instances containing context root child 
			 * elements xpaths along with their corresponding new updated value. 
			 */
			public Iterator<NodeInfo> nodeInfoIterator() { 
				return this.m_listUpdateNodes.iterator() ; 
			}//EOM
			
			/**
			 * Creates and adds a new NodeInfo instance containing the 
			 * context root child elements xpaths along with their corresponding new updated value. 
			 * 
			 * @param sColumnXpath xpath relative to the NodeGroupInfo.m_sParentXPath root path 
			 * yeilding the individual node (or attribute) whose value is to be updated with the sColumnValue.
			 * @param sColumnValue new value to update with.  
			 */
			public final void addNodeInfo(final String sColumnXpath, final String sColumnValue) { 
				final NodeInfo column = new NodeInfo(sColumnXpath, sColumnValue) ; 
				this.m_listUpdateNodes.add(column) ; 
			}//EOM 
						
		}//EOC NodeGroupInfo class
		
		/**
		 * @author guys
		 * 
		 * Container class enclosing data required to construct a single node update statement in the context 
		 * of an xquery loop over a corresponding parent NodeGroupInfo.m_sParentXPath
		 * 
		 *  Note: m_sColumnXpath contains a relative path from the parent NodeGroupInfo.m_sParentXPath
		 *
		 */
		public final class NodeInfo { 
			private String m_sColumnXpath  ;
			private String m_sValue ; 
			
			public NodeInfo(final String sColumnXpath, final String sColumnValue) { 
				this.m_sColumnXpath = sColumnXpath ; 
				this.m_sValue = sColumnValue ;  
			}//EOM
			
			public NodeInfo(final String sColumnXpath) { 
				this.m_sColumnXpath = sColumnXpath ; 
			}//EOM
			/**
			 * @return a relative path from the parent NodeGroupInfo.m_sParentXPath yeilding the individual node 
			 * (or attribute) whose value is to be updated with the sColumnValue.
			 */
			public final String getRelativeColumnXPath() { 
				return this.m_sColumnXpath ; 
			}//EOM 
			
			/**
			 * @return new update value. 
			 * Note:  null values are permitted and would be represented as an empty element.
			 */
			public final String getValue() { 
				return this.m_sValue ;
			}//EOM 
			
		}//EO NodeInfo class 
	
	}//EOC Command  
	


}//EOC Command  
		

