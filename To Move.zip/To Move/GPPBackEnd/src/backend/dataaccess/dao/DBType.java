package backend.dataaccess.dao;

import static com.fundtech.util.GlobalConstants.SPACE;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.xmlbeans.impl.values.XmlObjectBase;

import backend.dataaccess.dao.db2.Db2XmlDao;
import backend.dataaccess.dao.oracle.OracleWasXmlDao;
import backend.dataaccess.dao.oracle.OracleXmlDao;
import backend.util.ServerConstants;

import com.fundtech.lang.OperatorType;
import com.fundtech.util.DBTypeInterface;

/**
 * Dec 4, 2007 DBType.java
 * 
 * @author guys Enumeration representing database types and encapsulating global constant and logical resources. The enum contains various utility
 *         methods intended to abstract database proprietary syntax by generating SQL segments in a dynamic manner. Database specific syntax packs are
 *         located in properties files residing in the same directory as this class and are selected respectively using the name() equivalent suffix.
 *         At initialisation the class would populate all private members with the values from the resourceBundle and then dispose of it. The bundle
 *         is passed to the initialise() which is viable for subclassing thus providing the means for subclasses to use special non-common syntax
 *         resource attributes.
 */
public enum DBType implements DBTypeInterface {

	
	
	Oracle {
		// Used for creating a prepared statement which enable auto-generated
		// keys extraction.
		private final int[] IDENTITY_COLUMN_INDICES_ARR = { 1 };
		
		/**
		 * Oracle Dec 4, 2007 guys Used for ROWNUM clause prefix determination (i.e. whether the statement already contains and where clause or not).
		 * 
		 * @param bIsLastCondition True if the statement already contains a where clause and False if the ROWNUM is the first condition (i.e. no where
		 *            clause)
		 * @param bIsLastCondition Flag indicating whether the ROWNUM attribute should be appended to an existing where clause or be the first
		 *            condition in the client statement.
		 * @return The ROWNUM prefix: if the bIsLastCondition = true then 'AND' else 'WHERE' Oracle
		 */
		@Override
		protected String getWhereClauseRownumPrefix(final boolean bIsLastCondition) {

			final String ROWNUM_AT_START_PREFIX = "WHERE ";
			final String ROWNUM_AT_END_PREFIX = " AND ";

			return (bIsLastCondition ? ROWNUM_AT_END_PREFIX : ROWNUM_AT_START_PREFIX);
		}// EOM
		@Override
		public String getSID() {
			return "SELECT SYS_CONTEXT ('USERENV','DB_NAME') AS DB_NAME FROM SYS.DUAL";
		}
		@Override
		public String getHostName() {
			return "SELECT SYS_CONTEXT ('USERENV','SERVER_HOST') AS SERVER_HOST FROM SYS.DUAL";
		}
		@Override
		public String getSchemaOrUser() {
			return "SELECT SYS_CONTEXT ('USERENV','CURRENT_USER') AS CURRENT_USER FROM SYS.DUAL";
		}

		/**
		 * Oracle Dec 4, 2007 guys Constructs and returns a complete where + order by clause. Ensures that the query body section already contains the
		 * WHERE clause or the AND keyword aproprietley and if found to be missing, adds it.
		 * 
		 * @param sWherePart First part of the statement including the WHERE clause (if any).
		 * @param sOrderByPart ORDERBY clause
		 * @param iRowNum Number of rows to fetch
		 * @param bBindValue If true will replace the iRowNum with '?'
		 * @return Complete query consisted of body+where clause+rownum+orderby. Oracle
		 */
		public String configureRownumFilter(final String sQeryPart, final String sOrderByPart, final int iRowNum, final boolean bBindValue) {

			final StringBuilder builder = new StringBuilder(sQeryPart);

			final Matcher matcher = WHERE_CLASUE_PATTERN.matcher(sQeryPart);
			// if the query does not have a where clause append one.
			// else if the query has the where and not 'and suffix' part, then append the AND
			final boolean bHasWhereClause = matcher.find();

			String sRownumPrefix = ServerConstants.EMPTY_STRING;

			if (!bHasWhereClause)
			{
				sRownumPrefix = (ServerConstants.WHERE);

			}
			else if (bHasWhereClause && (!sQeryPart.endsWith(ServerConstants.AND)))
			{
				sRownumPrefix = ServerConstants.AND;

			}// EO else if the query has a where clause but not a trailing 'AND'

			final OperatorType operator = OperatorType.LTE;

			final String sRownumValue = (bBindValue ? ServerConstants.QUESTION_MARK_STR : ServerConstants.EMPTY_STRING + iRowNum);

			// %s ROWNUM %s %s
			final String sRownumPart = String.format(this.m_sWhereClasueRownum, sRownumPrefix, operator.getSign(), sRownumValue);

			return builder.append(ServerConstants.SPACE).append(sRownumPart).append(ServerConstants.SPACE).append(sOrderByPart).toString();

		}// EOM

		/**
		 * Oracle Dec 4, 2007 guys
		 * 
		 * @return True as the database supports ROWNUM parameter binding (for prepared statements) Oracle
		 */
		public boolean rownumBindingSupport() {
			return true;
		}// EOM

		/**
		 * Oracle Dec 4, 2007 guys Creates a prepared statement using the provided formal arg connection, configured to return an auto-generated key
		 * subsequent to insert query execution. invokes the: connection.prepareStatement(String qurey, int[] auto-generated key column index) Note:
		 * auto-generated key column is considered to always be the first one and thus the index value is always 1. Handles the scenario whereby the
		 * PK is numeric+sequence.
		 * 
		 * @param sQuery Insert statement
		 * @param conn Active and opened SQL connection
		 * @return PreparedStatement configured for returning the auto-generated key (if any)
		 * @throws SQLException Oracle
		 */
		public PreparedStatement getPrepareStatementWithIdentity(final String sQuery, final Connection conn) throws SQLException {

			return conn.prepareStatement(sQuery, IDENTITY_COLUMN_INDICES_ARR);
		}// EOM

		/**
		 * Oracle Dec 4, 2007 guys Constructs and returns a SQL code segment representing a time unit. For instance, let iTimeUnit be 1 and datePart
		 * DatePart.Second: Oracle: 1/86400
		 * 
		 * @param iTimeUnit Time unit to represent.
		 * @param datePart DatePart instance to convert the time unit to
		 * @return SQL code segment representing the time unit, converted into the date part. Oracle
		 */
		public final String getTimeRep(final int iTimeUnit, final DatePart datePart) {
			return new StringBuilder(iTimeUnit).append('/').append(datePart.secs()).toString();
		}// EOM

		/**
		 * Oracle Hook method creating a dao class dedicated for xml type column handling.
		 */
		@Override
		protected AbstractXmlDao newXmlDao() {
			if (System.getProperty(JAVA_NAMING_PROPERTY) != null && System.getProperty(JAVA_NAMING_PROPERTY).toLowerCase().indexOf("weblogic") > -1) return new OracleXmlDao();
			return new OracleWasXmlDao();

		}// EOM

		@Override
		public boolean shouldUseParamNamesForBinding() {
			return true;
		}

		@Override
		public String getDeductSecondsFromTimeStampString(String arg0) {
			return getCurrentTimestampKeyword() + "- interval  " + arg0 + " SECOND";
		}		


	}, // EO Oracle

	DB2 {
		final String DATE_TOCHAR_TEMPLATE_FORMATTED_MEMBER = "date.tochar.template.formatted";
		final String DATE_TOCHAR_TEMPLATE_MEMBER = "date.tochar.template";
		
		// final String WHERE_CLAUSE_ROWNUM_PREFIX = "where.clause.rownum.prefix" ;

		private String formattedDateForRepresentationKeyword;
		private String dateForRepresentationKeyword;

		// private String m_sWhereClauseRownumPrefix ;

		/**
		 * DB2 Dec 4, 2007 guys Populates the private class members using the resourceBundles value.
		 * 
		 * @param syntaxBundle ResourceBundle containing the given database syntax pack. DB2
		 */
		@Override
		protected void initialise(final ResourceBundle syntaxBundle) throws MissingResourceException {

			super.initialise(syntaxBundle);

			// initailise the dateForRepresentationKeyword
			this.formattedDateForRepresentationKeyword = syntaxBundle.getString(DATE_TOCHAR_TEMPLATE_FORMATTED_MEMBER);
			this.dateForRepresentationKeyword = syntaxBundle.getString(DATE_TOCHAR_TEMPLATE_MEMBER);
			// this.m_sWhereClauseRownumPrefix = syntaxBundle.getString(WHERE_CLAUSE_ROWNUM_PREFIX) ;

		}// EOM

		@Override
		protected String getWhereClauseRownumPrefix(final boolean bIsLastCondition) {

			final String ROWNUM_AT_START_PREFIX = "WHERE ";
			final String ROWNUM_AT_END_PREFIX = " AND ";

			return (bIsLastCondition ? ROWNUM_AT_END_PREFIX : ROWNUM_AT_START_PREFIX);
		}// EOM

		@Override
		public String getSID() {
			return "SELECT CURRENT SERVER FROM SYSIBM.SYSDUMMY1 WHERE 1=2";
		}
		@Override
		public String getHostName() {
			return "SELECT CURRENT SERVER FROM SYSIBM.SYSDUMMY1";
		}
		@Override
		public String getSchemaOrUser() {
			return "SELECT CURRENT SCHEMA FROM SYSIBM.SYSDUMMY1";
		}

		/**
		 * DB2 Dec 4, 2007 guys
		 * 
		 * @return False as the database does not support ROWNUM parameter binding (for prepared statements) DB2
		 */
		public boolean rownumBindingSupport() {
			return false;
		}// EOM

		/**
		 * DB2 Dec 4, 2007 guys Constructs and returns a complete where + order by clause. Note: as DB2 does not support ROWNUM parameter binding,
		 * will ignore the bBindValue and use the iRowNum value instead Post-condition: client code must check for rownum binding support using the
		 * rownumBindingSupport prior to attempting to bind the rownum parameter.
		 * 
		 * @param sWherePart First part of the statement including the WHERE clause (if any).
		 * @param sOrderByPart ORDERBY clause
		 * @param iRowNum Number of rows to fetch
		 * @param bBindValue If true will replace the iRowNum with '?'
		 * @return Complete query consisted of body+where clause+orderby+rownum DB2
		 */
		public String configureRownumFilter(final String sWherePart, final String sOrderByPart, final int iRowNum, final boolean bBindValue) {

			final OperatorType operator = OperatorType.LTE;
			final Matcher matcher = WHERE_CLASUE_PATTERN.matcher(sWherePart);
			// if the query does not have a where clause append one.
			// else if the query has the where and not 'and suffix' part, then append the AND
			final boolean bHasWhereClause = matcher.find();
			final String sRownumPart = this.getWhereClauseRownum(bHasWhereClause, operator, iRowNum);

			return new StringBuilder(sWherePart).append(SPACE).append(sRownumPart).append(SPACE).append(sOrderByPart).toString();

		}// EOM

		/**
		 * DB2 Dec 4, 2007 guys Creates a prepared statement using the provided formal arg connection, configured to return an auto-generated key
		 * subsequent to insert query execution. invokes the: connection.prepareStatement(String qurey, int[] Statement.RETURN_GENERATED_KEYS) Handles
		 * the scenario whereby the PK is of an 'identity' datatype.
		 * 
		 * @param sQuery Insert statement
		 * @param conn Active and opened SQL connection
		 * @return PreparedStatement configured for returning the auto-generated key (if any)
		 * @throws SQLException DB2
		 */
		public PreparedStatement getPrepareStatementWithIdentity(final String sQuery, final Connection conn) throws SQLException {

			return conn.prepareStatement(sQuery, Statement.RETURN_GENERATED_KEYS);
		}// EOM

		/**
		 * DB2 Dec 4, 2007 guys
		 * 
		 * @param bIsUsedForCalculation An extra hint which could be used for instance, for determination whether to wrap the current date keyword
		 *            with a char conversion or not.
		 * @return 'current timestamp' DB2
		 */
		public String getCurrentDateKeyword(boolean bIsUsedForCalculation) {
			// return (bIsUsedForCalculation ? this.m_sCurrentDateKeyword : dateForRepresentationKeyword) ;
			return getCurrentDateKeyword(bIsUsedForCalculation, formattedDateForRepresentationKeyword);
		}// EOM

		/**
		 * DB2 Dec 4, 2007 guys
		 * 
		 * @param bIsUsedForCalculation An extra hint which could be used for instance, for determination whether to wrap the current date keyword
		 *            with a char conversion or not.
		 * @return 'current timestamp' DB2
		 */
		public String getCurrentDateKeyword(boolean bIsUsedForCalculation, String sDateFormat) {
			return (bIsUsedForCalculation ? this.m_sCurrentDateKeyword : String.format(dateForRepresentationKeyword, sDateFormat));
		}// EOM

		/**
		 * DB2 Dec 4, 2007 guys
		 * 
		 * @return The current date keyword reserved for the given database type, using a version not intended for calculation (i.e. converted to char
		 *         in some cases) DB2
		 */
		public String getCurrentDateKeyword(String sDateFormat) {
			return this.getCurrentDateKeyword(false, sDateFormat);
		}// EOM

		/**
		 * DB2 Dec 4, 2007 guys Constructs and returns a SQL code segment representing a time unit. For instance, let iTimeUnit be 1 and datePart
		 * DatePart.Second: DB2: 1 second
		 * 
		 * @param iTimeUnit Time unit to represent.
		 * @param datePart DatePart instance to convert the time unit to
		 * @return SQL code segment representing the time unit, converted into the date part. DB2
		 */
		public final String getTimeRep(final int iTimeUnit, final DatePart datePart) {
			return new StringBuilder(iTimeUnit).append(ServerConstants.SPACE).append(datePart.name()).toString();
		}// EOM

		/**
		 * DB2 Hook method creating a dao class dedicated for xml type column handling.
		 */
		@Override
		protected AbstractXmlDao newXmlDao() {
			return new Db2XmlDao();
		}// EOM

		@Override
		public boolean shouldUseParamNamesForBinding() {
			return false;
		}

		@Override
		public boolean isDate(int type) {
			return type == Types.TIMESTAMP;
		}

		@Override
		public String getEmptyString(String variable, boolean equal) {
			String sign = equal ? "=" : "<>";

			return " AND " + variable + " " + sign + " " + "''";
		}

		@Override
		public String getDeductSecondsFromTimeStampString(String arg0) {
			return getCurrentTimestampKeyword() + "- " + arg0 + " SECONDS";
		}
		

	};// EO DB2

	private static final String DB2_IDENTIFIER = "DB2";
	private static final String ORACLE_IDENTIFIER = "Oracle";
	private static String DBYypeName = DBType.class.getName();
	private static final String TYPE_NOT_SUPPORTED_TEMPLATE_MSG = "Database type %s is not suppported.";

	private static final String WHERE_CLASUE_PATTERN_STRING = "(?i)\\where(?!.*\\bfrom\\b(?!.*?\\).*?\\band\\b))";
	private static final Pattern WHERE_CLASUE_PATTERN = Pattern.compile(WHERE_CLASUE_PATTERN_STRING);

	private static final String ROWNUM_MEMBER = "select.rownum";
	private static final String NULL_MEMBER = "null.value";
	private static final String TOCHAR_MEMBER = "to.char";
	private static final String UPPER_MEMBER = "upper";
	private static final String XMLCUST_MEMBER = "xml.cast";
	private static final String WHERECLAUSE_ROWNUM_TEMPLATE_MEMBER = "where.clause.rownum.template";
	private static final String DUMMY_TABLE_MEMBER = "dummy.table";
	private static final String CURRENT_DATE_MEMBER = "current.date";
	private static final String CURRENT_TIMESTAMP_MEMBER = "current.timestamp";
	private static final String TIMESTAMP_DIFF_TEMPLATE_MEMBER = "timestamp.diff.template";
	private static final String STRING_FORMAT_TEMPLATE = "string.format.template";
	private static final String TIMESTAMP_FORMAT = "timestamp.format";
	private static final String EXTRACT_HOURS_FORMAT = "extract.hours";
	private static final String UNIQUE_CONSTRAINT_ERROR_CODE = "error.unique.constraint";
	
	

	private String m_sRowNumValue;
	private String m_sNullValue;
	private String m_sToCharValue;
	private String m_sUpperValue;
	private String m_sXmlCastValue;
	protected String m_sWhereClasueRownum;
	private String m_sDummyTableName;
	protected String m_sCurrentDateKeyword;
	private String m_sCurrentTimestampKeyword;
	private String m_sTimestampDiffTemplate;
	private String m_sStringFormatTemplate;
	private AbstractXmlDao m_XmlDao;
	private String m_timeStampFormat;
	private String m_extractHoursFormat;
	private int m_uniqueConstraintVendorCode;

	protected String JAVA_NAMING_PROPERTY = "java.naming.factory.initial";

	/**
	 * Dec 4, 2007 guys Possible values: Oracle: 'Oracle' DB2: DB2+<machine architecture type>
	 * 
	 * @param sDBTypeValue database product name as retrieved from the DatabaseMetadata.
	 * @return a given DBType instance.
	 * @throws IllegalArgumentException if the sDBTypeValue does not conform the expected value set.
	 */
	public static DBType parse(final String sDBTypeValue) {

		if (sDBTypeValue.startsWith(DB2_IDENTIFIER)) return DB2;
		else if (sDBTypeValue.equals(ORACLE_IDENTIFIER)) return Oracle;
		else throw new IllegalArgumentException(String.format(TYPE_NOT_SUPPORTED_TEMPLATE_MSG, sDBTypeValue));
	}// EOM

	/**
	 * Loads the given databse type's syntax pack using the following algorithm: properties file name = DBType class Name + _ + this DBType instance
	 * name() The file name construction and subsequence load and parsing is performed by the ResourceBundle class. This method will provide it with
	 * the fully qualified name of the DBType class and a Locale initialised with the name() value.
	 * 
	 * @throws MissingResourceException
	 */
	private DBType() throws MissingResourceException {
		// load the resource bundle associated with the given instance name.
		final String sBaseName = DBType.getName();

		final String syntaxVariation = this.name().toLowerCase();

		final ResourceBundle syntaxBundle = ResourceBundle.getBundle(sBaseName + '_' + syntaxVariation);

		this.initialise(syntaxBundle);
	}// EOM

	/**
	 * @return
	 */
	public static String getName()
	{
		final String sBaseName = DBType.class.getName();
		return sBaseName;
	}

	/**
	 * Dec 4, 2007 guys Populates the private class memebers using the resourceBundles value.
	 * 
	 * @param syntaxBundle ResourceBundle containing the given database syntax pack.
	 */
	protected void initialise(final ResourceBundle syntaxBundle) {

		// populate the local members
		this.m_sRowNumValue = syntaxBundle.getString(ROWNUM_MEMBER);
		this.m_sNullValue = syntaxBundle.getString(NULL_MEMBER);
		this.m_sToCharValue = syntaxBundle.getString(TOCHAR_MEMBER);
		this.m_sUpperValue = syntaxBundle.getString(UPPER_MEMBER);
		this.m_sXmlCastValue = syntaxBundle.getString(XMLCUST_MEMBER);
		this.m_sWhereClasueRownum = syntaxBundle.getString(WHERECLAUSE_ROWNUM_TEMPLATE_MEMBER);
		this.m_sDummyTableName = syntaxBundle.getString(DUMMY_TABLE_MEMBER);
		this.m_sCurrentDateKeyword = syntaxBundle.getString(CURRENT_DATE_MEMBER);
		this.m_sCurrentTimestampKeyword = syntaxBundle.getString(CURRENT_TIMESTAMP_MEMBER);
		this.m_sTimestampDiffTemplate = syntaxBundle.getString(TIMESTAMP_DIFF_TEMPLATE_MEMBER);
		this.m_sStringFormatTemplate = syntaxBundle.getString(STRING_FORMAT_TEMPLATE);
		this.m_timeStampFormat = syntaxBundle.getString(TIMESTAMP_FORMAT);
		this.m_extractHoursFormat = syntaxBundle.getString(EXTRACT_HOURS_FORMAT);
		this.m_uniqueConstraintVendorCode = Integer.parseInt(syntaxBundle.getString(UNIQUE_CONSTRAINT_ERROR_CODE));

		// create the m_XmlDao
		this.m_XmlDao = this.newXmlDao();
	}// EOM

	/**
	 * Dec 4, 2007 guys
	 * 
	 * @return The char conversion keyword as reserved by the given database instance.
	 */
	public final String getToCharValue() {
		return this.m_sToCharValue;
	}// EOM
	
	public final String getUpperValue() {
		return this.m_sUpperValue;
	}//EOM

	public final String getXmlCastValue() {
		return m_sXmlCastValue;
	}

	public final String formatString(final String sRawValue) {
		return String.format(this.m_sStringFormatTemplate, sRawValue);
	}// EOM

	/**
	 * Dec 4, 2007 guys
	 * 
	 * @return The row number keyword as used in the select clause (as opposing to where clause) and as reserved for for given database instance.
	 */
	public final String getRowNumValue() {
		return this.m_sRowNumValue;
	}// EOM

	/**
	 * Dec 4, 2007 guys
	 * 
	 * @return The 'NULL' value as supported by the given database instance.
	 */
	public final String getNullValue() {
		return this.m_sNullValue;
	}// EOM

	/**
	 * Dec 4, 2007 guys
	 * 
	 * @return The dummy table name associated with the given database instance.
	 */
	public final String getDummyTableName() {
		return this.m_sDummyTableName;
	}// EOM

	/**
	 * Dec 4, 2007 guys
	 * 
	 * @return The current date keyword reserved for the given database type, using a version not intended for calculation (i.e. converted to char in
	 *         some cases)
	 */
	public String getCurrentDateKeyword(String sDateFormat) {
		return this.getCurrentDateKeyword(false);
	}// EOM

	/**
	 * Dec 4, 2007 guys
	 * 
	 * @param bIsUsedForCalculation An extra hint which could be used for instance, for determination whether to wrap the current date keyword with a
	 *            char conversion or not.
	 * @return 'current timestamp'
	 */
	public String getCurrentDateKeyword(boolean bIsUsedForCalculation, String sDateFormat) {
		return this.getCurrentDateKeyword(bIsUsedForCalculation);
	}// EOM

	/**
	 * Dec 4, 2007 guys
	 * 
	 * @return The current date keyword reserved for the given database type, using a version not intended for calculation (i.e. converted to char in
	 *         some cases)
	 */
	public final String getCurrentDateKeyword() {
		return this.getCurrentDateKeyword(false);
	}// EOM

	/**
	 * Dec 4, 2007 guys
	 * 
	 * @param bIsUsedForCalculation An extra hint which could be used for instance, for determination whether to wrap the current date keyword with a
	 *            char conversion or not.
	 * @return The current date keyword reserved for the given database type.
	 */
	public String getCurrentDateKeyword(boolean bIsUsedForCalculation) {
		return this.m_sCurrentDateKeyword;
	}// EOM

	/**
	 * Dec 4, 2007 guys
	 * 
	 * @return The Timestamp keyword reserved for the given database type.
	 */
	public final String getCurrentTimestampKeyword() {
		return this.m_sCurrentTimestampKeyword;
	}// EOM

	/**
 	  * 
 	  */
	public final String getExtractHoursFormat() {
		return this.m_extractHoursFormat;
	}// EOM

	/**
	 * Dec 4, 2007 guys Constructs and returns a complete ROWNUM clause.
	 * 
	 * @param bIsLastCondition True if the statement already contains a where clause and False if the ROWNUM is the first condition (i.e. no where
	 *            clause)
	 * @param operator OperatorType instance
	 * @param sRowNum Number of rows to be fetched.
	 * @return Complete ROWNUM clause encapsulated by whitespace and prefixed in accordance with the client code requirements.
	 */
	public String getWhereClauseRownum(final boolean bIsLastCondition, final OperatorType operator, final String sRowNum) {

		final String sPrefix = this.getWhereClauseRownumPrefix(bIsLastCondition);
		return String.format(m_sWhereClasueRownum, sPrefix, operator.getSign(), sRowNum);

	}// EOM

	/**
	 * Dec 4, 2007 guys Constructs and returns a complete ROWNUM clause.
	 * 
	 * @param bIsLastCondition True if the statement already contains a where clause and False if the ROWNUM is the first condition (i.e. no where
	 *            clause)
	 * @param operator OperatorType instance
	 * @param sRowNum Number of rows to be fetched.
	 * @return Complete ROWNUM clause encapsulated by whitespace and prefixed in accordance with the client code requirements.
	 */
	public String getWhereClauseRownum(final boolean bIsLastCondition, final OperatorType operator, final int iRowNun) {

		return this.getWhereClauseRownum(bIsLastCondition, operator, ServerConstants.EMPTY_STRING + iRowNun);

	}// EOM

	/**
	 * Dec 4, 2007 guys Template method, returning the default of '', used for ROWNUM clause prefix determination (i.e. whether the statement already
	 * contains and where clause or not).
	 * 
	 * @param bIsLastCondition True if the statement already contains a where clause and False if the ROWNUM is the first condition (i.e. no where
	 *            clause)
	 * @return The ROWNUM prefix
	 */
	protected String getWhereClauseRownumPrefix(final boolean bIsLastCondition) {
		return ServerConstants.EMPTY_STRING;
	}// EOM

	/**
	 * Dec 4, 2007 guys Constructs and returns a complete where + order by clause.
	 * 
	 * @param sWherePart First part of the statement including the WHERE clause (if any).
	 * @param sOrderByPart ORDERBY clause
	 * @param iRowNum Number of rows to fetch
	 * @param bBindValue If true will replace the iRowNum with '?'
	 * @return Complete query consisted of body+where clause+rownum+orderby Note: rownum and orderby are interchangable depending on the database
	 *         type.
	 */
	public abstract String configureRownumFilter(final String sWherePart, final String sOrderByPart, final int iRowNum, final boolean bBindValue);

	/**
	 * Dec 4, 2007 guys
	 * 
	 * @return True if the database supports ROWNUM parameter binding (for prepared statements) and False if it does not.
	 */
	public abstract boolean rownumBindingSupport();

	/**
	 * Dec 11, 2007 guys
	 * 
	 * @return new AbstractXmlDao instance
	 */
	protected abstract AbstractXmlDao newXmlDao();

	/**
	 * Dec 4, 2007 guys Constructs and returns a SQL code segment representing a time unit. For instance, let iTimeUnit be 1 and datePart
	 * DatePart.Second: Oracle: 1/86400 DB2: 1 second
	 * 
	 * @param iTimeUnit Time unit to represent.
	 * @param datePart DatePart instance to convert the time unit to
	 * @return SQL code segment representing the time unit, converted into the date part.
	 */
	public abstract String getTimeRep(int iTimeUnit, DatePart datePart);

	/**
	 * @return
	 */
	public abstract String getSID();

	/**
	 * @return
	 */
	public abstract String getHostName();

	/**
	 * @return
	 */
	public abstract String getSchemaOrUser();
	
	
	/**
	 * Dec 4, 2007 guys Template method to be subclassed, creating a prepared statement using the provided formal arg constructor, configured to
	 * return an auto-generated key subsequent to insert query execution.
	 * 
	 * @param sQuery Insert statement
	 * @param conn Active and opened SQL connection
	 * @return PreparedStatement configured for returning the auto-generated key (if any)
	 * @throws SQLException
	 */
	public abstract PreparedStatement getPrepareStatementWithIdentity(final String sQuery, final Connection conn) throws SQLException;

	/**
	 * Dec 4, 2007 guys Constructs a SQL code segment calculating the time difference in seconds between two time types in which the first must be a
	 * timestamp.
	 * 
	 * @param sLeftTimestampOperad Timestamp time unit.
	 * @param sRightTimestampOperand (date, time or timestamp) to subtract from the current given sql server time.
	 * @return Whitespace encapsulated SQL String.
	 */
	public String getTsDiffSecs(final String sLeftTimestampOperad, final String sRightTimestampOperand) {

		return String.format(this.m_sTimestampDiffTemplate, sLeftTimestampOperad, sRightTimestampOperand);
	}// EOM

	public String getTimestampFormat(String operand) {
		return String.format(m_timeStampFormat, operand);
	}

	/**
	 * Dec 4, 2007 guys Constructs a SQL code segment calculating the time difference in seconds between the given SQL server current time and the
	 * sRightTimestampOperand
	 * 
	 * @param sRightTimestampOperand Time unit (date, time or timestamp) to subtract from the current given sql server time.
	 * @return Whitespace encapsulated SQL String.
	 */
	public final String getCurrTsDiffSecs(final String sRightTimestampOperand) {

		return String.format(this.m_sTimestampDiffTemplate, this.getCurrentDateKeyword(true), sRightTimestampOperand);
	}// EOM

	/**
	 * Dec 4, 2007 guys Constructs a SQL code to increment a day part by a time unit.
	 * 
	 * @param iTimeUnit Increment offset
	 * @param datePart Daypart operand to increment.
	 * @return SQL String segment encapsulated by whitespace using the following template (%s + %s)
	 */
	public final String getCurrTsIncrementationPart(final int iTimeUnit, final DatePart datePart) {
		final String sTemplate = " (%s + %s) ";
		return String.format(sTemplate, this.getCurrentDateKeyword(true), this.getTimeRep(iTimeUnit, datePart));
	}// EOM

	/**
	 * Dec 5, 2007 guys Searched sQuery string for the last occurrence of the ROWNUM keyword as reserved by the given DBtype instance and
	 * 
	 * @param sQuery Input Query String.
	 * @return True if the current representation of the ROWNUM exist and False if does not
	 */
	public boolean doesWhereClauseRownumExist(final String sQuery) {
		final String sRowNumPrefix = new StringBuilder(ServerConstants.SPACE).append(this.getRowNumValue()).toString();

		return sQuery.indexOf(sRowNumPrefix) != -1;
	}

	public String getToCharFormat(String value, String format) {
		return getToCharValue() + "(" + value + ",'" + format + "')";
	}
	
	public String getUpperFormat(String value) {
		return getUpperValue() + "(" + value + ")";
	}

	public abstract boolean shouldUseParamNamesForBinding();

	public abstract String getDeductSecondsFromTimeStampString(String seconds);

	public String getCastToVarcharBindingParam() {
		return this.formatString("?");
	}

	public String getEmptyString(String variable, boolean equal) {
		return "";
	}
	
	/**
	 * determines weather the input is caused by a unique constraint violation
	 * @param e  the SQLException
	 * @return true if it is a representation of a Unique Constraint violation, false if it is other violation
	 */
	public boolean isUniqueConstraintViolated(SQLException e) {
		return e.getErrorCode() == this.m_uniqueConstraintVendorCode;
	}

	/**
	 * Dec 11, 2007 guys
	 * 
	 * @return the XmlDao for the given DBType context.
	 */
	public final AbstractXmlDao getXmlDao() {
		return this.m_XmlDao;
	}// EOM
	
	public final XmlObjectBase getXmlColumnContent(final ResultSet rs, final String sColumnName) throws Exception { 
		return this.m_XmlDao.getColumnContent(rs, sColumnName) ;
	}//EOM 

	public boolean isDate(int type) {
		return type == Types.DATE || type == Types.TIMESTAMP;
	}

	public boolean isNumeric(int iColumnType) {
		return iColumnType == Types.NUMERIC || iColumnType == Types.DECIMAL || iColumnType == Types.INTEGER || iColumnType == Types.SMALLINT;
	}

}// EO Enum
