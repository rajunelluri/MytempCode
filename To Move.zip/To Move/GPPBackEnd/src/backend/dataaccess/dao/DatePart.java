package backend.dataaccess.dao;

/**
 * Dec 4, 2007
 * DatePart.java
 * @author guys
 * 
 * Enumeration representing day parts literally and numerically (in seconds) 
 * and used in SQL date arithmetic. 
 */
public enum DatePart { 
	Year(365*24*60*60), 
	Day(24*60*60), 
	Minute(60),
	Second(1);     	
	
	private int m_iSecs ; 
	
	private DatePart(final int iSecs) { 
		this.m_iSecs = iSecs ; 
	}//EOM 
	
	public int secs() {
		 return this.m_iSecs ; 
	}//EOM
	
}