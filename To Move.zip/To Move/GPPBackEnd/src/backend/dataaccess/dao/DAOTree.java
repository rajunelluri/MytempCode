/*
 * Description: DAO object for Profile Tree methods 
 * Company:		Fundtech Israel
 * Author:		Inna Ben-Shushan
 * Date:		31/10/06
 */
package backend.dataaccess.dao;

import java.sql.Types;
import java.util.HashMap;

import com.fundtech.core.general.StatementParameter;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.util.GlobalConstants;

import backend.dataaccess.dto.DTODataHolder;
import backend.dataaccess.dto.DTOHashMap;
import backend.staticdata.dataaccess.dao.DAOStaticData;
import backend.staticdata.profilehandler.security.dataaccess.dto.DTOUserPermissionAudit;
import backend.staticdata.profilehandler.security.dataaccess.dto.DTOUserPermissionAuditContainer;
import backend.util.ServerConstants;

public abstract class DAOTree extends DAOStaticData
{
	protected String m_sCategoriesSqlSelect = ServerConstants.EMPTY_STRING;
	protected String m_sAvailableSqlSelect = ServerConstants.EMPTY_STRING;
	protected String m_sSelectedSqlSelect = ServerConstants.EMPTY_STRING;
	
	protected String m_sInsertPermissionStatement; 
	protected String m_sDeletePermissionsStatement;
	protected String m_sUpdatePermissionsStatement;
	//Replaced DUAL with database dependent value   
	private static final String DEFAULT_SELECT_CATEGORIES = 
		"SELECT 1 AS CATEGORY_ID,'' AS CATEGORY_NAME, CAST(NULL AS VARCHAR(50)) AS CATEGORY_PARENT FROM " + ms_DBType.getDummyTableName();
	private static final String COLUMN_FIELD_NAME = "FIELD_NAME";
	private static final String COLUMN_PERMISSION = "PERMISSION"; 
	
	/**
	 * Get Categories tree data:
	 * @return data holder - Categories tree nodes
	 */
	public DTODataHolder getTreeCategoriesData()
	{
		m_sCategoriesSqlSelect = (!m_sCategoriesSqlSelect.equals(ServerConstants.EMPTY_STRING))? 
									m_sCategoriesSqlSelect : DEFAULT_SELECT_CATEGORIES;		
		
		DTODataHolder dtoDataHolder = getData(m_sCategoriesSqlSelect, 0);
		return dtoDataHolder;
	}
	
	/**
	 * Get Items tree data:
	 * @return data holder - Items tree nodes 
	 */
	public DTODataHolder getTreeItemsData(String sProfileName, boolean bAvailable)
	{
		DTODataHolder dtoDataHolder;
				
		StatementParameter[] arrParameters = new StatementParameter[1];
		arrParameters[0] = new StatementParameter(sProfileName, Types.VARCHAR);
				
		String sSqlSelect = (bAvailable)? m_sAvailableSqlSelect : m_sSelectedSqlSelect;
		
		dtoDataHolder = getData(sSqlSelect, arrParameters);
		return dtoDataHolder;
	}
	/**
	 * @param sAccessProfileName
	 * @return dto hashmap access level attached fields where key is field name
	 * and value is permission 
	 */
	public DTOHashMap getAttachedFields(String sProfileName)
	{
		StatementParameter[] arrParameters = new StatementParameter[1];
		arrParameters[0] = new StatementParameter(sProfileName, Types.VARCHAR);
		
		DTODataHolder dto = getTreeItemsData(sProfileName, false);
		
		DTOHashMap dtoHashMap = new DTOHashMap();
		dtoHashMap.setFeedback(dto.getFeedBack());
		
		for(int i=0 ; i<dto.getRowsNumber() ; i++)
		{
			HashMap hm = dto.getDataRow(i);
			String sName = (String)hm.get(COLUMN_FIELD_NAME);
			String sPermissionType = (String)hm.get(COLUMN_PERMISSION);
			
			dtoHashMap.put(sName, sPermissionType);
		}
		
		return dtoHashMap;
	}
	
	/**
	 * Converts from GUI permission type (0/1) to DB permissions type (R/W)
	 * @param sPermissionOld - GUI permission type
	 * @return DB permissions type
	 */
	private String convertPermissionType(String sPermissionOld)
	{
		String sPermissionNew = "W";
		
		if(sPermissionOld.equals(GlobalConstants.ZERO_VALUE))
		{
			sPermissionNew = "R";
		}
		
		return sPermissionNew;
	}
	
	/**
	 * insert permssions data for create
	 * @param container - permissions containsr
	 * @return feedback
	 */
	public Feedback insertPermissionsDataForCreate
						(DTOUserPermissionAuditContainer container)
	{
		int iSize = container.size();
		int i=0;
		Feedback feedback = new Feedback();
		
		while (i<iSize && feedback.isSuccessful()) 
		{
			DTOUserPermissionAudit dto = container.getDTO(i);
			
			feedback = insertPermissionsForCreate(dto, feedback);

			i++;
		}
		
		return feedback;
	}
	
	/**
	 * Insert a single permission
	 * @param dto - a single permission
	 * @param feedback - feedback if exists or null
	 * @return feedback
	 */
	public Feedback insertPermissionsForCreate(DTOUserPermissionAudit dto, Feedback feedback)
	{
		StatementParameter[] arrParameters = createParametersForCreate(dto);
		
		feedback = update(m_sInsertPermissionStatement, arrParameters, null, null,
				false, 
				false, feedback);

		return feedback;
	}
	
	/**
	 * Updates an existing permission
	 * @param dto - a single permission
	 * @return feedback
	 */
	public Feedback updatePermission(DTOUserPermissionAudit dto)
	{
		Feedback feedback = null;
		
		StatementParameter[] arrParameters = createParametersForCreate(dto);		
		
		return update(m_sUpdatePermissionsStatement, arrParameters, null, null, false, 
				false, null); 
	}
	
	/**
	 * Deletes an existing permission
	 * @param dto - a single permission
	 * @return feedback
	 */
	public Feedback deletePermission(DTOUserPermissionAudit dto)
	{
		Feedback feedback = null;
		
		StatementParameter[] arrParameters = createParametersForDelete(dto);		
		
		return doDelete(m_sDeletePermissionsStatement, arrParameters, null, null); 
	}
	
	
	/**
	 * Create parameters for inserting record for create
	 * @param dto - user permissions data 
	 * @return statement parameters array
	 */
	public StatementParameter[] createParametersForCreate(DTOUserPermissionAudit dto)
	{
		StatementParameter[] arrParameters = null;

		arrParameters = new StatementParameter[3];
		
		arrParameters[0] = new StatementParameter(dto.getNewPermissionType(), Types.VARCHAR);		
		arrParameters[1] = new StatementParameter(dto.getFieldID(), Types.VARCHAR);
		arrParameters[2] = new StatementParameter(dto.getAccessLevelName()[0], Types.VARCHAR);
		
		return arrParameters;
	}
	
	/**
	 * Create parameters for inserting record for create
	 * @param dto - user permissions data 
	 * @return statement parameters array
	 */
	public StatementParameter[] createParametersForDelete(DTOUserPermissionAudit dto)
	{
		StatementParameter[] arrParameters = null;

		arrParameters = new StatementParameter[2];
		
		arrParameters[0] = new StatementParameter(dto.getFieldID(), Types.VARCHAR);
		arrParameters[1] = new StatementParameter(dto.getAccessLevelName()[0], Types.VARCHAR);

		return arrParameters;
	}
    
    /**
     * Rerteives all entries corresponding to the profile_id and the table name formal args 
     * from the PROFILE_UPDATE_DETAILS (for simple data) and from PROFILE_UPDATE_COMPLEX (in complex data 
     * cases).
     * <br> 
     * <b>Note</b> There might be more than one entry per profile (e.g. simple and complex) 
     * <br>
     * @param sProfileUID Indentifier of the profile entry and foreign key in the PROFILE_UPDATE table 
     * @param sTableName Identifier of the profile type.
     * @return {@link DTODataHolder} containing all entries and feedback 
     */
	public DTODataHolder getProfilePendingData(String sProfileUID, String sTableName) { 
        
        final String QUERY = "SELECT PROFILE_UPDATE_DETAILS.* " +
                "FROM PROFILE_UPDATE INNER JOIN PROFILE_UPDATE_DETAILS ON " +
                "PROFILE_UPDATE_DETAILS.FK_PROFILE_UPDATE = PROFILE_UPDATE.PK_PROFILE_UPDATE " +
                "WHERE PROFILE_UPDATE.TABLE_NAME = ? AND " +
                "PROFILE_UPDATE.APPROVAL_STATUS = 'PN' AND " +
                "PROFILE_UPDATE.FK_PROFILE_UID = ?" ; 
        
        StatementParameter[] arrParameters = {
                new StatementParameter(sTableName, Types.VARCHAR),
                new StatementParameter(sProfileUID, Types.VARCHAR)
        } ; 
        
        return this.getData(QUERY, arrParameters, 0) ;
    }//EOM
}
