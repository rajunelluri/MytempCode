package backend.dataaccess.dao;

import java.util.List;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 * Title:        UserPreferencesDAO
 * Description:  DAO for user preferences, user favorites etc.
 * Company:      Fundtech Israel
 * @author       Alon Levy
 * @version      1.0
 */
public class UserPreferencesDAO 
{
	
	private final static Logger logger = LoggerFactory.getLogger(UserPreferencesDAO.class);
	final String QUERY_SELECT_USER_PREFERENCES_XML = "SELECT UP.DATA_XML FROM USER_PREFERENCE UP WHERE UP.UID_USER_PREFERENCE = ?";
	final String QUERY_UPDATE_USER_PREFERENCES_XML = "UPDATE USER_PREFERENCE UP SET UP.DATA_XML = ? WHERE UP.UID_USER_PREFERENCE = ?";
	final String QUERY_INSERT_USER_PREFERENCES_XML = "INSERT INTO USER_PREFERENCE (UID_USER_PREFERENCE ,USER_ID,DATA_TYPE,DATA_XML) VALUES(?,?,?,?)";
	private JdbcTemplate jdbcTemplate;
	
	public void setDataSource(DataSource dataSource)
	{
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	
	@SuppressWarnings("unchecked")
	public String getUserPreferencesByUID(String sUID)
	{  
	   
		List<String> resList = (List<String>) jdbcTemplate.queryForList(QUERY_SELECT_USER_PREFERENCES_XML, new Object[]{sUID}, String.class);
		if(resList.size()==0)
		{
			return null;
		}
		return (String)resList.get(0);
	}
	
	
	public int updatePreferencesByUID(String sUID, String sDataXml)
	{
		Object[] parmsArray = new Object[] {sDataXml, sUID};
		int numOfAffectedRows = jdbcTemplate.update(QUERY_UPDATE_USER_PREFERENCES_XML, parmsArray);
		return numOfAffectedRows;
	}
	
	
	public void insertPreferencesByUID(String sUID, String sUserId, String sDataType, String sDataXml)
	{
		Object[] parmarray = new Object[] {sUID, sUserId, sDataType, sDataXml};
		 jdbcTemplate.update(QUERY_INSERT_USER_PREFERENCES_XML, parmarray );
	}
}
