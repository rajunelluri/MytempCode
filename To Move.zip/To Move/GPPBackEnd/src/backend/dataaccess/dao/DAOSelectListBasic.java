package backend.dataaccess.dao;

import static com.fundtech.util.GlobalConstants.UDF_DATA_TYPE_DATE;
import static com.fundtech.util.GlobalConstants.UDF_DATA_TYPE_DATE_TIME;
import static com.fundtech.util.GlobalUtils.isNullOrEmpty;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import backend.dataaccess.dto.DTODataHolder;
import backend.services.cache.ASCacheFactory;
import backend.staticdata.dataaccess.dao.DAOProfileLoadActions;
import backend.staticdata.module.approvedecline.dataaccess.dao.DAOApproveDecline;
import backend.staticdata.module.selectlist.dataaccess.dto.DTOSelectListModel;
import backend.staticdata.profilehandler.BasicProfileHandler;
import backend.staticdata.profilehandler.ProfileHandlerFactory;
import backend.util.ServerConstants;

import com.fundtech.cache.entities.ProfileUDF;
import com.fundtech.cache.entities.WebSessionInfo;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.cache.syspar.SystemParametersInterface;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.request.Filter;
import com.fundtech.datacomponent.response.layout.ScreenObject;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalDateTimeUtil;

/**
 * Title:			DAOSelectList
 * date:			17-04-2005		 
 * Description:		Base class for Select List functionality.
 * Company:			Fundtech Israel
 * @author			Ehud Tavor
 * @version			1.0
 */
public class DAOSelectListBasic extends DAOProfileLoadActions
{
	private static final String COLUMN_PK_PROFILE_UPDATE = "PK_PROFILE_UPDATE";
	private static final String UID = "UID";
	DAOApproveDecline m_daoApproveDecline =  new DAOApproveDecline();
	/**
	 * Populates a DTO from the passed ResultSet object.
	 * 
	 * @param bFormatDateColumns true - needs to format date column in this method and not leave it for the clinet side; this is required for the
	 * PROFILE_UPDATE_DETAILS audit dispaly, because date fields are kept in VARCHAR columns, (OLD_VALUE, NEW_VALUE), and not in DATE columns, (such
	 * as in the profiles); otherwise, exception occurs on browser side because the value kept in the OLD_VALUE, NEW_VALUE columns can't be formatted.
	 * false - no date columns formatting should be done.
	 * @param sFormatStyleColumnName column name for format style value.
	 * @param arrDateColumnsPositions positions of date columns. RESTRICTION: date columns positions MUST be lower then the format style column
	 * position.
	 * @param sProfileID
	 * @param udfsMap - updated values of profile udfs
	 * @param udfsNameArr - ArrayLisy including all profile udfs names
	 */
	protected void populateSelectListModelDTO(DTOSelectListModel reply, ResultSet rs, boolean bFormatDateColumns, String sFormatStyleColumnName, int[] arrDateColumnsPositions,
			String sProfileID, Map<String, Map<String, String>> udfsMap, List<ProfileUDF> udfsNameArr) throws SQLException {
		populateSelectListModelDTO(reply, rs, bFormatDateColumns, sFormatStyleColumnName, arrDateColumnsPositions, sProfileID, udfsMap, udfsNameArr, null);
	}
  
	protected void populateSelectListModelDTO(DTOSelectListModel reply, ResultSet rs,         
			  boolean bFormatDateColumns, String sFormatStyleColumnName,
            int [] arrDateColumnsPositions,
            String sProfileID,Map<String,Map<String,String>> udfsMap, List<ProfileUDF> udfsNameArr, Filter filter) throws SQLException
{
		populateSelectListModelDTO(reply, rs, bFormatDateColumns, sFormatStyleColumnName, arrDateColumnsPositions, sProfileID, udfsMap, udfsNameArr, null, ServerConstants.SELECT_TYPE_SELECT);
}
	/**
	 * Populates a DTO from the passed ResultSet object.
	 * 
	 * @param bFormatDateColumns true - needs to format date column in this method and not leave it for the clinet side; this is required for the
	 * PROFILE_UPDATE_DETAILS audit dispaly, because date fields are kept in VARCHAR columns, (OLD_VALUE, NEW_VALUE), and not in DATE columns, (such
	 * as in the profiles); otherwise, exception occurs on browser side because the value kept in the OLD_VALUE, NEW_VALUE columns can't be formatted.
	 * false - no date columns formatting should be done.
	 * @param sFormatStyleColumnName column name for format style value.
	 * @param arrDateColumnsPositions positions of date columns. RESTRICTION: date columns positions MUST be lower then the format style column
	 * position.
	 * @param sProfileID
	 * @param udfsMap - updated values of profile udfs
	 * @param udfsNameArr - ArrayLisy including all profile udfs names
	 */
	protected void populateSelectListModelDTO(DTOSelectListModel reply, ResultSet rs,         
			  boolean bFormatDateColumns, String sFormatStyleColumnName,
              int [] arrDateColumnsPositions,
              String sProfileID,Map<String,Map<String,String>> udfsMap, List<ProfileUDF> udfsNameArr, Filter filter, char cSelectType) throws SQLException
  {
    ResultSetMetaData rsmd = rs.getMetaData();
    int iColumnCount = rsmd.getColumnCount();
    int iRowPos = 0;
    Object[] arrOneRowColumnsData;
    String sValue;
    String profileUID = null;
    reply.setColumnCount(iColumnCount);
    Map<String,String> tmp = null;
    int totalSize = iColumnCount;
    //get the total number from the column count and profile udfs
    if (udfsNameArr!= null && !udfsNameArr.isEmpty()) {
    	
    	totalSize += udfsNameArr.size() ;
    }
    
    SimpleDateFormat[] arrDateFormats = null;
    
    
    // If we need to format date columns then gets the date format pattern once according to the user's office' settings.
    WebSessionInfo webSessionInfo = Admin.getContextAdmin().getWebSessionInfo() ; 
    if (webSessionInfo == null) {
    	Admin admin = Admin.getContextAdmin();
    	webSessionInfo = CacheKeys.WebSessionInfoKey.getSingle(admin ) ;
    }
    String sUserDefOffice = GlobalConstants.DEFAULT_SERVER_OFFICE_NAME;
    if (webSessionInfo != null) {
    	sUserDefOffice = webSessionInfo.getDefaultOffice() ;
    }
    if(bFormatDateColumns)
    {	
       Object[] arrFormattingValues = ASCacheFactory.getInstance().getFormattingValues(sUserDefOffice);
      arrDateFormats = (SimpleDateFormat[])arrFormattingValues[0];
    }
    
    // HashMap in which: Key - column name, Value - column location in the columns array.
    // The HashMap is used later during the population of column model to link
    // each column in the column model to its location in the data model.
    HashMap hmColumnNameToLocationInColumnsDataArray = reply.getHMColumnNamePos();
    
    // In case there is actual data, value will be set to true in the next 
    // 'while' loop.
    boolean bNoData = true;
    boolean addIndicator = true;
    String profileUpdatePk = null;
    boolean isApproval = ServerConstants.SELECT_TYPE_APPROVAL == cSelectType;
    boolean updatedDataisLaoded = false;
    HashMap <String,String> updatedData = null;
    // As long as exist more rows in the result set, adds them to the reply object.
    while(rs.next())
    {
    	addIndicator = true;
      bNoData = false;
      profileUID = null;
       profileUpdatePk = null;
       updatedData = new  HashMap <String,String>();
       arrOneRowColumnsData = new Object[totalSize];
       updatedDataisLaoded = false;
       iRowPos++;
       for(int iColumnPos=1; iColumnPos<=iColumnCount; iColumnPos++)
       {   
    	   String sColumnName = rsmd.getColumnLabel(iColumnPos);

    	   // Get the value from the column.
    	   sValue = (String)getColumnValue(iColumnPos, rs, rsmd);
    	   sValue = !isNullOrEmpty(sValue) ? sValue : GlobalConstants.EMPTY_STRING;
    	   if (sColumnName.indexOf(UID)>-1){
    		   profileUID = sValue;	
    	   }
    	   else if (sColumnName.equals(COLUMN_PK_PROFILE_UPDATE))
    	   {
    		   profileUpdatePk = sValue;
    	   }
    	   
    	   // if pending approval, load the changes 
    	   if (profileUID != null && profileUpdatePk != null  &&  isApproval && !updatedDataisLaoded)
    	   {   
    		   updatedData = loadUpdatedData(profileUpdatePk);
    		   //only once
    		   updatedDataisLaoded=true;
    	   }
    	   
    		// check the data columns, if updated is required      
    	   if (iColumnPos > 2 && !updatedData.isEmpty())
    	   {
    		   // if there is new value, replace the existing value with the updated value
    		   if (updatedData.containsKey(sColumnName))
    		   {
    			   sValue = updatedData.get(sColumnName);
    		   }   		   
    	   }
    	   
    	   boolean bDateField = sColumnName.equals(sFormatStyleColumnName) && isDateFormatStyle(sValue);

    	   // Need to format date columns and we have reached the column that holds the date format value
    	   // for formatting on client side; sets it to '1', (i.e. no formatting), and formats the
    	   // related date columns to right value.
    	   if(bFormatDateColumns && bDateField)
    	   {
    		   handleDateFields(sValue, arrOneRowColumnsData, arrDateFormats, arrDateColumnsPositions);
    		   sValue = ScreenObject.FORMAT_STYLE_BASIC;
    	   }

    	   // Add the current column's value to the columns array.
    	   arrOneRowColumnsData[iColumnPos-1] = sValue;

    	   // 'hmColumnNames' population; done only once, for the first row.
    	   if(iRowPos == 1)
    	   {
    		   if(hmColumnNameToLocationInColumnsDataArray.get(rsmd.getColumnLabel(iColumnPos)) == null)
    		   {
    			   hmColumnNameToLocationInColumnsDataArray.put(rsmd.getColumnLabel(iColumnPos), Integer.toString(iColumnPos-1));
    		   }

    		   // Updates the 'reply' parameter with the 'hmColumnNames' HashMap 
    		   // when we reach to the last column of the first row.
    		   if(iColumnPos == iColumnCount)
    		   {
    			   reply.setHMColumnNamePos(hmColumnNameToLocationInColumnsDataArray);
    		   }
    	   }
       }

       //handle the profile udfs
       if (udfsNameArr != null && !udfsNameArr.isEmpty()) {    	  
    	   tmp = udfsMap.get(profileUID);
    	   int index = iColumnCount;
    	   String udfName = null;
    	   ProfileUDF profileUDF = null;
    	   String value = null;
    	   for (int l = 0 ; l < udfsNameArr.size() ; l++) {
    		   profileUDF = udfsNameArr.get(l); 
    		   udfName = profileUDF.getUidUdf();
    		   if (iRowPos ==1) {
    			   hmColumnNameToLocationInColumnsDataArray.put(udfName, Integer.toString(index));
    		   }

    		   if (tmp != null) {    			  
    			   value = tmp.get(udfName);
    			   if (value != null) {
    				   if (UDF_DATA_TYPE_DATE.equals(profileUDF.getDataType())){
    					   value = formatDate(value,sUserDefOffice);
    				   }else if (UDF_DATA_TYPE_DATE_TIME.equals(profileUDF.getDataType())) {
    					   value = formatDateTime(value);
    				   }
    				   arrOneRowColumnsData[index++]=value;
    			   } else {
    				   arrOneRowColumnsData[index++]="";
    			   }
    		   }else {//there is no value
    			   arrOneRowColumnsData[index++]="";
    		   }

    	   }
       }
       if (addIndicator) {
    	   // Row is populated, add it to the rows array in reply object.
    	   if(sProfileID != null)
    	   {
    		   BasicProfileHandler profileHandler = ProfileHandlerFactory.getInstance().getHandler(sProfileID);
    		   Object[] arrNewColumnsData = profileHandler.addAdditionalColumnsToSelectListResults(hmColumnNameToLocationInColumnsDataArray, arrOneRowColumnsData, filter);
    		   arrOneRowColumnsData = arrNewColumnsData != null ? arrNewColumnsData : arrOneRowColumnsData;
    	   }
    	   
    	   // add the line to the grid only in case previous step returned data 
    	   // is used to filter the grid by the fields that are could not be retreived
    	   // by sql statement and need to be filtered in java
    	   // e.i. filter by "Text" field in ACTIVITY_AUDIT profile
		   if (arrOneRowColumnsData.length != 0) {
			   reply.setGridDataRow(arrOneRowColumnsData);
		   }
       }    
    }

    // No data - just sets the 'hmColumnNames' variable.
    if(bNoData)
    {
    	for(int iColumnPos=1; iColumnPos<=iColumnCount; iColumnPos++)
    	{
    		hmColumnNameToLocationInColumnsDataArray.put(rsmd.getColumnName(iColumnPos), Integer.toString(iColumnPos-1));
    	}

    	reply.setHMColumnNamePos(hmColumnNameToLocationInColumnsDataArray);
    }
  }

  private String formatDate (String date, String office) {
	  String sDateFormat = CacheKeys.SystParKey.getSingleParmValue(office, SystemParametersInterface.SYS_PAR_WEBDATEFMT);
	  return GlobalDateTimeUtil.getFormattedDateString(date,"yyyy-MM-dd HH:mm:ss.0",sDateFormat);
  }
  
  private String formatDateTime(String date) {
    	 return GlobalDateTimeUtil.getFormattedDateString(date,"yyyy-MM-dd HH:mm:ss.0","dd/MM/yyyy HH:mm:ss");
     }
  
  /**
   * Returns whether the passed foprmat style is a date format style.
   */
  private boolean isDateFormatStyle(String sFormatStyle)
  {
    return    ScreenObject.FORMAT_STYLE_DATE_TIME.equals(sFormatStyle)
           || ScreenObject.FORMAT_STYLE_DATE_ONLY.equals(sFormatStyle)
           || ScreenObject.FORMAT_STYLE_TIME_ONLY_1.equals(sFormatStyle)
           || ScreenObject.FORMAT_STYLE_TIME_ONLY_2.equals(sFormatStyle);
  }
  
  /**
   * Handles date fields in case formatting should be done on server side.
   * For example: profile's audit details; see explanation in the above 'populateSelectListModelDTO' 
   * method's Javadoc for the 'bFormatDateColumns' parameter 
   */
  private void handleDateFields(String sFormatStyle, Object[] arrColumns, SimpleDateFormat[] arrDateFormats,
                                int[] arrDateColumnsPositions)
  {
    final String SUFFIX_DOT_ZERO = ".0";
    
    // Gets the date pattern to use according to the format style value,
    // and the input format for the 'GlobalDateTimeUtil.getFormattedDateString'.
    String sDateFieldPattern = null;
    String sDateInputFormat = null;
    boolean bTimeField = false;
    
    if(ScreenObject.FORMAT_STYLE_DATE_TIME.equals(sFormatStyle))
    {
      sDateFieldPattern = arrDateFormats[0].toPattern();
      
      // "yyyy-MM-dd HH:mm:ss".
      sDateInputFormat = GlobalDateTimeUtil.STATIC_DATA_DATE_TIME;
    }
    else if(ScreenObject.FORMAT_STYLE_DATE_ONLY.equals(sFormatStyle))
    {
      sDateFieldPattern = arrDateFormats[1].toPattern();
      
      // "yyyy-MM-dd".
      sDateInputFormat = GlobalDateTimeUtil.STATIC_DATA_DATE;
    }
    if(   ScreenObject.FORMAT_STYLE_TIME_ONLY_1.equals(sFormatStyle)
       || ScreenObject.FORMAT_STYLE_TIME_ONLY_2.equals(sFormatStyle))
    {
      sDateFieldPattern = arrDateFormats[2].toPattern();
      bTimeField = true;
    }
    
    // Loops the date columns and formats them accordingly.
    for(int i=0; i<arrDateColumnsPositions.length; i++)
    {
      int iCurrentDatePosition = arrDateColumnsPositions[i];
      String sUnformattedDateValue = (String)arrColumns[iCurrentDatePosition];
      
      // Value can't be null, because of setting in the caller method.
      if(!sUnformattedDateValue.equals(ServerConstants.EMPTY_STRING))
      {
        if(sUnformattedDateValue.endsWith(SUFFIX_DOT_ZERO))
        {
          sUnformattedDateValue = sUnformattedDateValue.substring(0, sUnformattedDateValue.length()-2).trim();
        }

        if(bTimeField)
        {
          // "HH:mm" OR "yyyy-MM-dd HH:mm:ss".
          sDateInputFormat = sUnformattedDateValue.length() == 5 ? GlobalDateTimeUtil.STATIC_DATA_TIME_NO_SECONDS : GlobalDateTimeUtil.STATIC_DATA_DATE_TIME;
        }
        
        arrColumns[iCurrentDatePosition] = GlobalDateTimeUtil.getFormattedDateString(sUnformattedDateValue, sDateInputFormat, sDateFieldPattern);
      }
    }
  }
  
  /**
   * Load the updated data and return it as a HashMap<cloum name, new value> 
   * @param profileUpdatePk
   * @return
   */
  private HashMap<String, String> loadUpdatedData(String profileUpdatePk) 
  {

	  HashMap<String, String> hmProfileData = new  HashMap<String, String>();
	  
	  // Gets changed data from the PROFILE_UPDATE table.		
	  DTODataHolder dtoChanges = m_daoApproveDecline.getPROFILE_UPDATE_DETAILS_Data(profileUpdatePk);

      // Call has succeed.
      if(dtoChanges.getFeedBack().isSuccessful())
      {			
	  	  // get list of changes, pending to approve
    	  List<Map<String, String>> dataList = dtoChanges.getDataAL();
    	  int size = dataList.size();
	  	  Map<String, String> map = null;
	  	  // update the load profile with new data
	  	  for (int i=0; i<size ; i++) 
	  	  {
	  		  map = dataList.get(i);	  	    		
	  		  hmProfileData.put(map.get(DAOApproveDecline.PROFILE_UPADTE_DETAILS_COLUMN_NAME), map.get(DAOApproveDecline.PROFILE_UPADTE_DETAILS_NEW_VALUE));
	  	  }	          
      }  
	  return hmProfileData;
	}
  
}