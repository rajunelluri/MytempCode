package backend.dataaccess.dao.oracle;

import java.io.IOException;
import java.io.InputStream;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLXML;
import java.util.Iterator;
import java.util.Map;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import oracle.jdbc.OracleTypes;
import org.apache.poi.util.IOUtils;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlObjectBase;
import org.w3c.dom.Document;

import com.fundtech.cache.entities.LogicalFields;
import com.fundtech.core.paymentprocess.data.das.DASInterface.XmlLocationType;
import com.fundtech.core.paymentprocess.data.paymenttypes.PaymentType;
import com.fundtech.util.GlobalUtils;

import backend.dataaccess.dao.AbstractXmlDao;
import backend.dataaccess.dao.AbstractXmlDao.CommandInfo.NodeGroupInfo;
import backend.dataaccess.dao.AbstractXmlDao.CommandInfo.NodeInfo;
import backend.util.ServerConstants;

/**
 * @author guys
 * 
 * Oracle XML column types handling class. 
 * 
 * Provides the means to perform the following actions: 
 * 1. Single String value extraction  
 * 2. XML Subset or column recrod content extraction 
 * 3. XML node updates.
 * 
 *  NOTE:
 *  All XML nodes are considered fullly qualified and comprised of two parts : <namespace>:<local element name>. 
 *	Thus in order too access a given element, the default behaviour dictates that the namespace (or a prefix alias 
 *	which might be nothing if so declared in the xmlns prolog) must be defined along with the element name. 
 *	In order to emulate a namespce unaware behaviour, all elments must be prefixed by one of the following delerations: 
 *	1.  *:<element local name> - defines the element as belonging to all namespaces. 
 *	2.  *[local-name()="<element local name>"]
 *	3.  *[name()="<element local name>"]
 *	As writing and maintaing xpaths containing such declarations is unreasonably tedious, all methods in this class 
 *	provide the following facility: 
 *		If the namespce is provided, the methods will declare it as the default element namespace thus alliviating 
 *		the neeed for namespace prefix.
 *		Otherwise if the namespace was not provided, the methods will modify all xpath queries provided 
 *		to include either the first or the third aforementioned option. 
 *		Please adhere be the following rules while developing an xpath query: 
 *		1. xpath might already be enriched by the '*:' namespace, in which case, the methods will not modify the xpath. 
 *		   This behaviour is applied to each xpath element individually (i.e. those nodes declared without the 
 *		   prefix would be modified while those containing the declaration will not). 
 *		2. xpath must not contain the local() or local-name() declaration in conjunction with null namespace 
 *		   as the methods will not check for the existence of the constructs, and will hence render the xpath 
 *		   query invalid by adding the construct again.
 *		   In other words, when providing no namespace, provide xpath queries that do not contain 
 *		   namespace declaration. The various method will ensure that those are added.
 *		 
 *	 	Note: currently, a single namespace declaration is supported through this method. Nevertheless, as the db syntax 
 *	 	 * 		 supports multiple namespace declarations, if the need arises, the method could be altered to accomodate it.
 *	 	 * 		 The current implementation, for convenience sake, decalres a no-prefix namespace so that the elementXPath
 *		 * 		 value should not be altered to include the namespace prefix.
 *  
 *  
 *
 */
public class OracleXmlDao extends AbstractXmlDao{

	/**
	 * Constants and formatter templates used in the process of query construction
	 */
	private static final String RETURNING_CONTENT = "returning content" ;
	

	/*
	 * 1 - column name 
	 * 1a - column name 
	 */
	private static final String UPDATE_XML_START_TEMPLATE = "%1$s = updatexml(%1$s, " ;
	/*
	 * 1 - Namespace value
	 */
	private static final String UPDATE_XML_END_TEMPLATE = ",\n'xmlns=\"%s\"')" ;
	/*
	 * 1 - Full xpath 
	 */
	private static final String UPDATE_TUPLE_TEMPLATE = "'%s', ?" ; 
	
	private static final int ORACLE_OPQAQUE_DATA_TYPE = 2007 ; 
	
	public OracleXmlDao() { 
		super() ; 
	}//EOM
				
	/**
	 * Hook method used in the getXML() 
	 * @return The context specific type of the passing by clause 
	 * 
	 * Possible context values: 
	 * Oracle:    '' 
	 */
	@Override 
	public final String getXQueryPassingByTypeString() { 
		return ServerConstants.EMPTY_STRING ; 	
	}//EOM 
	
	/**
	 * Hook method used in the getXML() 
	 * @return The context specific 'Return' block of the 'passing' clasue.
	 * 
	 * Possible context values: 
	 * Oracle: 'returning content' 
	 */
	@Override
	protected String getXQueryPassingReturnClasueString() { 
		return RETURNING_CONTENT ; 
	}//EOM
		
	/**
	 * 
	 * Hook method used in the getXML() 
	 * 
	 * Extracts and returns an input stream containing XML data, using : 
	 * 
	 * ResultSet.Object(), casting it to OPAQUE, creating an XMLType from it,
	 * and retrieving the xml stream from it.
	 * 
	 * Note: does not close the ResultSet. 
	 * 
	 * @param rs opened ResultSet to extract the xml input stream from.
	 * @param sColumnName Column name in which the xml data is stored.
	 * @return xml InputStream. 
	 * @throws SQLException
	 */
	@Override
	protected Document getDomDocument(ResultSet rs, String columnName) throws SQLException {
		SQLXML sqlxml = rs.getSQLXML(columnName);
		DOMSource domSource = sqlxml.getSource(DOMSource.class); //TBD, is there a better 'Source' to use? 
		Document document = (Document) domSource.getNode();
		return document;
		/*oracle.sql.OPAQUE opaque = (oracle.sql.OPAQUE) rs.getObject(columnName) ;
		XMLType xml = XMLType.createXML(opaque) ;  
		return xml.getDOM();*/
	}//EOM
	
	public XmlObjectBase getColumnContent(ResultSet rs, String sColumnName) throws Exception{ 
		SQLXML sqlxml = rs.getSQLXML(sColumnName);
		return (sqlxml == null ? null : (XmlObjectBase) 
				PaymentType.m_contextXchemaTypeLoader.parse(sqlxml.getCharacterStream(), null,null) ) ;
		/*oracle.sql.OPAQUE opaque = (oracle.sql.OPAQUE) rs.getObject(sColumnName) ;
		return opaque == null ? null : (XmlObjectBase) PaymentType.m_contextXchemaTypeLoader.parse(XMLType.createXML(opaque).getDOM(), null,null) ;*/
	}//EOM 
	
	/**
	 * @return int repersentation of the prorietary data type (ORACLE_OPQAQUE_DATA_TYPE = 2007) 
	 */
	@Override
	protected int getXmlColumnDataType() { 
		return ORACLE_OPQAQUE_DATA_TYPE ; 
	}//EOM

	
	/**
	 * Utility method used to construct an update sql/xml query.
	 * @param ctx ProcessingContext instance containing all data required for query construction.  
	 * @return 
	 * @see update() for more information on the ProcessingContext content and query syntax.
	 */
	@Override
	protected final String constructUpdateQueryInnerHook(final ProcessingContext ctx) { 														
		
		final CommandInfo commandInfo = ctx.getCommandInfo() ; 
		
		//get all the node groups and for each 
		Iterator<NodeGroupInfo> iterator = commandInfo.nodeGroupIterator() ; 
				
		//constrcut and append the begining of the statement 
		final String sStartOfStatement =  
			String.format(UPDATE_XML_START_TEMPLATE, commandInfo.getColumnname()); 
	
		ctx.getOvrllBldr().append(sStartOfStatement) ; 

		String sParentXPath = null ; 
		NodeGroupInfo nodeGroupInfo = null ; 

		while(iterator.hasNext()) { 
			
			nodeGroupInfo = iterator.next() ; 
			
			sParentXPath = nodeGroupInfo.m_sParentXPath ; 
			
			Iterator<NodeInfo> nodeInfoIterator = nodeGroupInfo.nodeInfoIterator() ; 
			NodeInfo nodeInfo = null ; 
			StringBuilder fullNodeXpathBuilder  = null ; 
			
			//get all the node infos 
			while(nodeInfoIterator.hasNext()) { 
				
				nodeInfo = nodeInfoIterator.next() ;
				
				//create the full node xpath 
				//by appending the parent xpath and the relative one 
				//and finally if there is no text() a text() as well.
				fullNodeXpathBuilder = new StringBuilder(sParentXPath).
					append(nodeInfo.getRelativeColumnXPath()) ; 
				
				//if the namespace was not provided, modify the xpath to 
				//ignore namespaces by modifying the node names to use the '*[name()="<nodeName>"]' 
				//syntax instead 
				if(commandInfo.getNamespace() == null)  
					fullNodeXpathBuilder =
						new StringBuilder(this.modifyXpathToUseLocalNames(fullNodeXpathBuilder.toString())) ;    
				
				if(! nodeInfo.getRelativeColumnXPath().toLowerCase().endsWith(TEXT_VALUE)) { 
					fullNodeXpathBuilder.append(TEXT_VALUE) ;
				}//EO if there was no text() suffix 
					
				//create the xpath tuple format 
				ctx.getOvrllBldr().append(
						String.format(UPDATE_TUPLE_TEMPLATE, fullNodeXpathBuilder.toString()))  ;
				
				//add the value to the list 
				ctx.addBindingParamValue(nodeInfo.getValue()) ; 
				
				//if there are more values, append a ',' 
				if(nodeInfoIterator.hasNext()) { 
					ctx.getOvrllBldr().append(",\n") ; 
				}//EO if there are more values 
				                                
			}//EO while there are more node infos 
			
			if(iterator.hasNext()) { 
				ctx.getOvrllBldr().append(",\n") ; 
			}//EO if there are more values 
						
		}//EO while there are more node groups
		
		String sStatementEnd = null ; 
		//if the name space exists append the name space declaration, else append a closing parenthesis
		if(commandInfo.getNamespace() != null) { 
			sStatementEnd = String.format(UPDATE_XML_END_TEMPLATE, commandInfo.getNamespace()) ;
		}else {
			sStatementEnd = ServerConstants.CLOSING_PARENTHESIS ; 
		}//EO else if no namespace was provided 
		
		
		//append the closing parenthesys 
		ctx.getOvrllBldr().append(sStatementEnd) ; 

		return ctx.getOvrllBldr().toString() ; 
	}//EOM

	@Override
	public void bindXmlColumn(final int iColIndex, final XmlObject xmlBeanRoot, final PreparedStatement ps) throws SQLException, IOException 
	{
		bindXmlColumn(iColIndex,xmlBeanRoot == null ? null : xmlBeanRoot.xmlText(),ps);
		
		/*if (xmlBeanRoot == null)
		{
			setNullToXmlColumn(ps, iColIndex);
		}
		else
		{
			final XMLType poXML = XMLType.createXML(ps.getConnection(), xmlBeanRoot.newInputStream()) ;		
			com.fundtech.util.GlobalUtils.setObject(ps,iColIndex, poXML) ;
		}*/
	    
	    
	}//EOM 
    @Override
    public void bindXmlColumn(final int iColIndex, final String xml, final PreparedStatement ps) throws SQLException {
//        final XMLType poXML = XMLType.createXML(ps.getConnection(), new ByteArrayInputStream(xml.getBytes())) ;     
		if (xml == null)
		{
			setNullToXmlColumn(ps, iColIndex);
		}
		else {
			SQLXML sqlxml = ps.getConnection().createSQLXML();
			sqlxml.setString(xml);
			com.fundtech.util.GlobalUtils.setObject(ps,iColIndex, sqlxml) ;	
		}
//      ps.setString(iColIndex, xmlBeanRoot.xmlText()) ; 
    }//EOM 

    @Override
    public void bindXmlColumn(int colIndex, InputStream is, PreparedStatement ps)
            throws SQLException, IOException
    {
		if (is == null)
		{
			setNullToXmlColumn(ps, colIndex);
		} else {
			SQLXML sqlxml = ps.getConnection().createSQLXML();
			StreamResult stream = sqlxml.setResult(StreamResult.class);
			IOUtils.copy(is, stream.getOutputStream());
			com.fundtech.util.GlobalUtils.setObject(ps,colIndex, sqlxml) ;
	    	}
    }

    
	@Override
	public void setNullToXmlColumn(PreparedStatement ps, int inx) throws SQLException 
	{
		// ASAF: The 'Types.SQLXML' is required when WebSphere runs against Oracle, (driver issue);
		// In case an exception occurs, then assumes that we run against WebLogic and then uses the 'ps.setObject(inx, null)' line
		// will be used in the 'catch' clause.
		try
		{
			//now with SQLXML, Is that still required?!
			ps.setNull(1, OracleTypes.OPAQUE, "SYS.XMLTYPE");
		}
		catch(Exception e)
		{
			ps.setObject(inx, null);
		}
	}

	@Override
	public final String generateSingleExtractValueClause(final LogicalFields logicalFieldMetadata, final boolean bIsMultiOccurrenceClasue, 
 			final XmlLocationType enumDbColumnName, final String sXPath, final String sXpathAppendum, final PaymentType enumPaymentType, 
			final boolean bXmlTypeBelongsToCommonTypes ) { 
		
		//EXTRACT/EXTRACTVALUE
		//XML_MSG, XML_ORIG_MSG 
		//xpath 
		//multi occurrence predicate or /text() 
		//payment type namespaces
		//common types namespace (optional) 
		final String sExtractValueTemplate = "(%s(%s,'%s%s','%s %s'))" ; 
		
		//ns prefix 
		//namespace
		final String COMMON_TYPES_NS_DECLERATION = "xmlns:%s=\"%s\"" ;
		
		//constrcut the namespace clause 
		//Example: xmlns="urn:iso:std:iso:20022:tech:xsd:pain.002.001.03" xmlns:pain002="urn:iso:std:iso:20022:tech:xsd:pain.002.001.03" xmlns:fndt="http://fundtech.com/SCL/CommonTypes"
		//optional colon 
		//prefix 
		//ns 
		final String sNsTemplate = "xmlns%s%s=\"%s\" " ;
		final StringBuilder nsBuilder = new StringBuilder();
		String sNsPrefix = null ; 
		
		for(Map.Entry<String,String> nsEntry : enumPaymentType.getDeclaredNamespaces().entrySet()) { 
			sNsPrefix = nsEntry.getKey(); 
			nsBuilder.append(String.format(sNsTemplate, (GlobalUtils.isNullOrEmpty(sNsPrefix) ? "" : ":"), sNsPrefix, nsEntry.getValue())) ; 
		}//EO while there are more declared nss 
		
		final String sExtractType = (bIsMultiOccurrenceClasue ? "EXTRACT" : "EXTRACTVALUE" ) ; 
		
		//construct the extract value clause 
		//EXTRACT/EXTRACTVALUE
		//XML_MSG, XML_ORIG_MSG 
		//xpath 
		//multi occurrence predicate or /text() 
		//payment type declared namespaces 
		//common types namespace (optional)
		return String.format(sExtractValueTemplate, 
				sExtractType,
				enumDbColumnName,
				sXPath, 
				sXpathAppendum,
				nsBuilder, 
				(bXmlTypeBelongsToCommonTypes ? "" : String.format(COMMON_TYPES_NS_DECLERATION, COMMON_TYPES_NS_PREFIX, COMMON_TYPES_NS))
			);
		
	}//EOM 
	
}//EOC
