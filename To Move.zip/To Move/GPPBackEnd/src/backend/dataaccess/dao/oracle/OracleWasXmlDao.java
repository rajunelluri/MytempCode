package backend.dataaccess.dao.oracle;

import java.io.IOException;
import java.io.InputStream;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.xmlbeans.XmlObject;

import com.ibm.websphere.rsadapter.WSCallHelper;

public class OracleWasXmlDao extends OracleXmlDao
{
//    @Override
//    public final void bindXmlColumn(final int iColIndex, final XmlObject xmlBeanRoot, final PreparedStatement ps) throws SQLException, IOException {
//        InputStream in = xmlBeanRoot.newInputStream();
//        XMLType xmlType  = (XMLType)(WSCallHelper.jdbcPass(XMLType.class, "createXML", new Object[]{ps.getConnection(),in}, 
//              new Class[]{java.sql.Connection.class, InputStream.class},new int[]{WSCallHelper.CONNECTION,WSCallHelper.IGNORE}));
        
 //       //WSCallHelper.jdbcCall(null, ps, 
//        //            "setObject", new Object[]{iColIndex, xmlType},new Class[]{int.class, Object.class});
//        ps.setObject(iColIndex, xmlType);
        
//    }//EOM 
//    @Override
//    public final void bindXmlColumn(final int iColIndex, final String xml, final PreparedStatement ps) throws SQLException {
//        XMLType xmlType  = (XMLType)(WSCallHelper.jdbcPass(XMLType.class, "createXML", new Object[]{ps.getConnection(),xml}, 
//              new Class[]{java.sql.Connection.class, String.class},new int[]{WSCallHelper.CONNECTION,WSCallHelper.IGNORE}));
        //WSCallHelper.jdbcCall(null, ps, 
        //            "setObject", new Object[]{iColIndex, xmlType},new Class[]{int.class, Object.class});
//        ps.setObject(iColIndex, xmlType);
//    }//EOM 

//    @Override
//  public void bindXmlColumn(int colIndex, InputStream is, PreparedStatement ps)
//            throws SQLException, IOException
//    {
//        XMLType xmlType  = (XMLType)(WSCallHelper.jdbcPass(XMLType.class, "createXML", new Object[]{ps.getConnection(),is}, 
//              new Class[]{java.sql.Connection.class, InputStream.class},new int[]{WSCallHelper.CONNECTION,WSCallHelper.IGNORE}));
        //WSCallHelper.jdbcCall(null, ps, 
        //            "setObject", new Object[]{colIndex, xmlType},new Class[]{int.class, Object.class});
//        ps.setObject(colIndex, xmlType);
//    }


}
