
package backend.dataaccess.dao.xquerygenerators;
import static backend.dataaccess.dao.AbstractXmlDao.COMMON_TYPES_NS;
import static backend.dataaccess.dao.AbstractXmlDao.COMMON_TYPES_NS_PREFIX;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.dataaccess.dao.DAOBasic;
import backend.dataaccess.dao.DBType;
import backend.util.ServerConstants;

import com.fundtech.cache.entities.LogicalFields;
import com.fundtech.core.paymentprocess.data.das.DASInterface.XmlLocationType;
import com.fundtech.core.paymentprocess.data.paymenttypes.PaymentType;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalUtils;

public class XML_TEXT_XML_MSG_Xquerygenerator implements GenerateSingleExtractValueClause 
{
	private final static Logger logger = LoggerFactory.getLogger(XML_TEXT_XML_MSG_Xquerygenerator.class);
	private static String COMMON_TYPES_NS_DECLERATION;

	static
	{
		String sDBType = GlobalConstants.getDbType().toString();

		// ORACLE.
		if(sDBType.equals(DBType.Oracle.name())) COMMON_TYPES_NS_DECLERATION = "xmlns:%s=\"%s\"";
		else if(sDBType.equals(DBType.DB2.name())) COMMON_TYPES_NS_DECLERATION = "declare namespace %s=\"%s\";";
	}

	@Override
	public final String generateSingleExtractValueClause(final LogicalFields logicalFieldMetadata, final boolean bIsMultiOccurrenceClasue, 
			final XmlLocationType enumDbColumnName, final String sXPath, String sXpathAppendum, 
			final PaymentType enumPaymentType, final boolean bXmlTypeBelongsToCommonTypes) 
	{

		String sRetVal = ServerConstants.EMPTY_STRING;

		String sDBType = GlobalConstants.getDbType().toString();

		String sNameSpacePart = bXmlTypeBelongsToCommonTypes ? ServerConstants.EMPTY_STRING : 
			String.format(COMMON_TYPES_NS_DECLERATION, COMMON_TYPES_NS_PREFIX, COMMON_TYPES_NS);

		sXpathAppendum = "/text()";

		// ORACLE.
		if(sDBType.equals(DBType.Oracle.name()))
		{
			// IMPORTANT NOTE:
			// When this class is being called as a part of a rule, (e.g. condition on the X_INSTR_NXT_AGT_OTHER_CD field as part of rule 155
			// 'RJCT_ORGNL'; ROFI manual matching), then it will be called one time when the rule is first parsed.
			// For re-testing this class after code changes, need to refresh the related prules and object prules objects and then put a breakpoint 
			// in the 'Prules.postLoadInit' method where the 'parseScript' method is being called.

			// Constrcuts the namespace clause. 
			// Example: xmlns="urn:iso:std:iso:20022:tech:xsd:pain.002.001.03" xmlns:pain002="urn:iso:std:iso:20022:tech:xsd:pain.002.001.03" xmlns:fndt="http://fundtech.com/SCL/CommonTypes"
			final String sNsTemplate = "xmlns%s%s=\"%s\" ";
			final StringBuilder sbNameSpace = new StringBuilder();
			String sNsPrefix = null ; 

			for(Map.Entry<String,String> nsEntry : enumPaymentType.getDeclaredNamespaces().entrySet()) 
			{ 
				sNsPrefix = nsEntry.getKey(); 
				sbNameSpace.append(String.format(sNsTemplate, (GlobalUtils.isNullOrEmpty(sNsPrefix) ? "" : ":"), sNsPrefix, nsEntry.getValue())) ; 
			} 

			// Binding parameters:
			// 1) sXPath.
			// 2) sXpathAppendum.
			// 3) nsBuilder
			// 4) sNameSpacePart
			final String EXTRACT_TEMPLATE = "NVL((CAST(EXTRACT(XML_MSG,'%s%s','%s %s') AS VARCHAR(4000))), ' ') ";

			// Example for a constructed returned value:
			//	NVL((CAST(EXTRACT(XML_MSG,
			//                    '/FndtMsg/Msg/Extn/XMLPersistentInfo/InstrNxtAgtOtherCodes/InstrNxtAgtOtherCode/X_INSTR_NXT_AGT_OTHER_CD/text()',
			//                    'xmlns="http://fundtech.com/SCL/CommonTypes"  ') AS VARCHAR(4000))), ' ') 
			sRetVal = String.format(EXTRACT_TEMPLATE, sXPath, sXpathAppendum, sbNameSpace, sNameSpacePart);
		}

		// DB2.
		else if(sDBType.equals(DBType.DB2.name()))
		{
			// IMPORTANT NOTE:
			// When this class is being called as a part of a rule, (e.g. condition on the X_INSTR_NXT_AGT_OTHER_CD field as part of rule 155
			// 'RJCT_ORGNL'; ROFI manual matching), then it will be called one time when the rule is first parsed.
			// For re-testing this class after code changes, need to refresh the related prules and object prules objects and then put a breakpoint 
			// in the 'Prules.postLoadInit' method where the 'parseScript' method is being called.

			String sDeclaredNameSpaces = enumPaymentType.getXpathlNamespaceCaluse().replaceAll("'", "\"");

			// Binding parameters:
			// 1) sDeclaredNameSpaces; e.g. declare default element namespace "urn:fundtech/scl/SWIFT".
			// 2) sNameSpacePart; e.g. declare namespace fndt="http://fundtech.com/SCL/CommonTypes";.
			// 3) enumDbColumnName; from method signature. e.g. XML_MSG.
			// 4) sXpath; e.g. /fndt:FndtMsg/fndt:Msg/fndt:Extn/fndt:XMLPersistentInfo/fndt:InstrNxtAgtOtherCodes/fndt:InstrNxtAgtOtherCode/fndt:X_INSTR_NXT_AGT_OTHER_CD.
			// 5) sXpathAppendum; e.g. /text(). 
			final String EXTRACT_TEMPLATE = "NVL(XMLSERIALIZE(XMLQUERY('%s%s$%s%s%s') AS VARCHAR(4000)), ' ')";

			// Example for a constructed returned value:
			//  NVL(XMLSERIALIZE(XMLQUERY('declare default element namespace "urn:fundtech/scl/SWIFT";declare namespace fndt="http://fundtech.com/SCL/CommonTypes";
			//                         $XML_MSG/fndt:FndtMsg/fndt:Msg/fndt:Extn/fndt:XMLPersistentInfo/fndt:InstrNxtAgtOtherCodes/fndt:InstrNxtAgtOtherCode/fndt:X_INSTR_NXT_AGT_OTHER_CD/text()')
			//                         AS VARCHAR(4000)), ' ')
			sRetVal = String.format(EXTRACT_TEMPLATE, sDeclaredNameSpaces, sNameSpacePart, enumDbColumnName, sXPath, sXpathAppendum);

			logger.info("DB2 construction involved values:\n  sDeclaredNameSpaces: {}\n  sNameSpacePart: {}\n", sDeclaredNameSpaces, sNameSpacePart);
			logger.info("enumDbColumnName: {}\n  sXPath: {}\n", enumDbColumnName, sXPath);
			logger.info("sXpathAppendum: {}\n  sRetVal: {}",  sXpathAppendum, sRetVal);

		}
		return sRetVal;
	} 
}