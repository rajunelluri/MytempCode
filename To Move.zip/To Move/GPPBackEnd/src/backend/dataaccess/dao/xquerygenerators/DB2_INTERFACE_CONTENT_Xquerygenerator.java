package backend.dataaccess.dao.xquerygenerators;

import static backend.dataaccess.dao.AbstractXmlDao.COMMON_TYPES_NS;
import static backend.dataaccess.dao.AbstractXmlDao.COMMON_TYPES_NS_PREFIX;

import com.fundtech.cache.entities.LogicalFields;
import com.fundtech.core.paymentprocess.data.das.DASInterface.XmlLocationType;
import com.fundtech.core.paymentprocess.data.paymenttypes.PaymentType;

public class DB2_INTERFACE_CONTENT_Xquerygenerator  implements GenerateSingleExtractValueClause{
	@Override
	public final String generateSingleExtractValueClause(final LogicalFields logicalFieldMetadata, final boolean bIsMultiOccurrenceClasue, 
 			final XmlLocationType enumDbColumnName, final String sXPath, String sXpathAppendum, final PaymentType enumPaymentType , 
			final boolean bXmlTypeBelongsToCommonTypes ) { 
		
		final String ANY_ATTRIBUTE_XPATH_ELEMENT = "@*" ;
		
		//if the column is to be constructed for a whereclause and the path ends with '@*' add "/text()" 
		//if(sXPath.endsWith(ANY_ATTRIBUTE_XPATH_ELEMENT)) sXpathAppendum = "/text()"  ;
		sXpathAppendum = "/text()"  ;
		
		//payment type declared namepaces
		//optional common types namespace 
		//XML_MSG, XML_ORIG_MSG 
		//xpath 
		//multi occurrence predicate or /text() 
		//datatype
		//final String sExtractValueTemplate =  "XMLCAST(XMLQUERY( 'declare default element namespace \"%s\" ;%s$%s%s%s') AS %s)" ; 
		//template  modification add passing suffix
		final String sExtractValueTemplate =  "XMLCAST(XMLQUERY( '%s%s$%s%s%s'%s) AS %s)" ;
		
		//ns prefix 
		//namespace
		final String COMMON_TYPES_NS_DECLERATION = "declare namespace %s=\"%s\";" ;
		
		return String.format(sExtractValueTemplate, 
				//enumPaymentType.getSchemaNamespace(),
				enumPaymentType.getXpathlNamespaceCaluse().replaceAll("'", "\""), 
				(bXmlTypeBelongsToCommonTypes ? "" : String.format(COMMON_TYPES_NS_DECLERATION, COMMON_TYPES_NS_PREFIX, COMMON_TYPES_NS)), 
				enumDbColumnName, 
				sXPath, 
				sXpathAppendum, 
				" PASSING  (xmlparse(document interface_content))  AS  \"INTERFACE_CONTENT\"",
				logicalFieldMetadata.getDataType().getSqlTypeCastString(logicalFieldMetadata.getMaxLength(),logicalFieldMetadata.getLocationType())
				
			); 
	}//EOM 
}
