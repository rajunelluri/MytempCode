
package backend.dataaccess.dao.xquerygenerators;
import static backend.dataaccess.dao.AbstractXmlDao.COMMON_TYPES_NS; 
import static backend.dataaccess.dao.AbstractXmlDao.COMMON_TYPES_NS_PREFIX;  
import java.util.Map;

import com.fundtech.cache.entities.LogicalFields;
import com.fundtech.core.paymentprocess.data.das.DASInterface.XmlLocationType;
import com.fundtech.core.paymentprocess.data.paymenttypes.PaymentType;
import com.fundtech.util.GlobalUtils;

import backend.dataaccess.dao.AbstractXmlDao;

public class Oracle_INTERFACE_CONTENT_Xquerygenerator implements GenerateSingleExtractValueClause {

	@Override
	public final String generateSingleExtractValueClause(final LogicalFields logicalFieldMetadata, final boolean bIsMultiOccurrenceClasue, 
 			final XmlLocationType enumDbColumnName, final String sXPath, final String sXpathAppendum, final PaymentType enumPaymentType, 
			final boolean bXmlTypeBelongsToCommonTypes) { 
		
		//EXTRACT/EXTRACTVALUE
		//XML_MSG, XML_ORIG_MSG 
		//xpath 
		//multi occurrence predicate or /text() 
		//payment type namespaces
		//common types namespace (optional) ""
		final String sExtractValueTemplate = "(%s(xmlparse(document %s),'%s%s','%s %s'))" ; 
		
		//ns prefix 
		//namespace
		final String COMMON_TYPES_NS_DECLERATION = "xmlns:%s=\"%s\"" ;
		
		//constrcut the namespace clause 
		//Example: xmlns="urn:iso:std:iso:20022:tech:xsd:pain.002.001.03" xmlns:pain002="urn:iso:std:iso:20022:tech:xsd:pain.002.001.03" xmlns:fndt="http://fundtech.com/SCL/CommonTypes"
		//optional colon 
		//prefix 
		//ns 
		final String sNsTemplate = "xmlns%s%s=\"%s\" " ;
		final StringBuilder nsBuilder = new StringBuilder();
		String sNsPrefix = null ; 
		
		for(Map.Entry<String,String> nsEntry : enumPaymentType.getDeclaredNamespaces().entrySet()) { 
			sNsPrefix = nsEntry.getKey(); 
			nsBuilder.append(String.format(sNsTemplate, (GlobalUtils.isNullOrEmpty(sNsPrefix) ? "" : ":"), sNsPrefix, nsEntry.getValue())) ; 
		}//EO while there are more declared nss 
		
		final String sExtractType = (bIsMultiOccurrenceClasue ? "EXTRACT" : "EXTRACTVALUE" ) ; 
		
		//construct the extract value clause 
		//EXTRACT/EXTRACTVALUE
		//XML_MSG, XML_ORIG_MSG 
		//xpath 
		//multi occurrence predicate or /text() 
		//payment type declared namespaces 
		//common types namespace (optional)
		return String.format(sExtractValueTemplate, 
				sExtractType,
				enumDbColumnName,
				sXPath, 
				sXpathAppendum,
				nsBuilder, 
				(bXmlTypeBelongsToCommonTypes ? "" : String.format(COMMON_TYPES_NS_DECLERATION, COMMON_TYPES_NS_PREFIX, COMMON_TYPES_NS))
			);
		
	}//EOM 
	
}//EOC 
