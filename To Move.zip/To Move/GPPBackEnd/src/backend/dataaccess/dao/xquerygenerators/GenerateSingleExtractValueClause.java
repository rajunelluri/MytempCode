package backend.dataaccess.dao.xquerygenerators;

import com.fundtech.cache.entities.LogicalFields;
import com.fundtech.core.paymentprocess.data.das.DASInterface.XmlLocationType;
import com.fundtech.core.paymentprocess.data.paymenttypes.PaymentType;

public interface GenerateSingleExtractValueClause {

	public abstract String generateSingleExtractValueClause(final LogicalFields logicalFieldMetadata, final boolean bIsMultiOccurrenceClasue, 
 			final XmlLocationType enumDbColumnName, final String sXPath, final String sXpathAppendum, final PaymentType enumPaymentType, 
			final boolean bXmlTypeBelongsToCommonTypes) ; 
}
