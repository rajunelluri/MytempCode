package backend.paymentprocess.creditpartyenrichment.ejb;

import javax.ejb.Stateless;
import backend.core.SuperSLSB;
import com.fundtech.core.security.Admin;
import backend.businessobject.proxies.interceptors.InterceptorSetType;
import backend.paymentprocess.creditpartyenrichment.businessobjects.BOCreditPartyEnrichment;
import backend.paymentprocess.creditpartyenrichment.ejbinterfaces.CreditPartyEnrichmentLocal;
import backend.paymentprocess.creditpartyenrichment.ejbinterfaces.CreditPartyEnrichment;

@Stateless
public class CreditPartyEnrichmentBean extends SuperSLSB<CreditPartyEnrichment> implements CreditPartyEnrichmentLocal, CreditPartyEnrichment{
	
	public CreditPartyEnrichmentBean() { super(backend.paymentprocess.creditpartyenrichment.businessobjects.BOCreditPartyEnrichment.class, InterceptorSetType.Complete) ; }//EOM
	
	
	/** 
	 */
	public com.fundtech.datacomponent.response.Feedback performCreditPartyEnrichment(final Admin admin, java.lang.String sMID ) {
		return this.m_bo.performCreditPartyEnrichment(admin, sMID ) ;
	}//EOM

}//EOC