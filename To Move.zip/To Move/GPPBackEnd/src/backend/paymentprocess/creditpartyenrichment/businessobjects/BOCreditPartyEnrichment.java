package backend.paymentprocess.creditpartyenrichment.businessobjects;

import static com.fundtech.util.GlobalUtils.isArrayNotNullAndNotEmpty;
import static com.fundtech.util.GlobalUtils.isNullOrEmpty;


import com.fundtech.annotations.Expose;
import com.fundtech.annotations.Wrap;
import com.fundtech.cache.entities.Customrs;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.findfirstinchain.MessageChainsData;
import com.fundtech.core.paymentprocess.findfirstinchain.FindFirstInChainConstants.ChainType;
import com.fundtech.core.paymentprocess.findfirstinchain.FindFirstInChainConstants.ChainTypeOrigin;
import com.fundtech.core.paymentprocess.findfirstinchain.MessageChainsData.ChainData;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.util.ExceptionController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import backend.businessobject.BOBasic;
import backend.businessobject.BOProxies;
import backend.businessobject.proxies.LoadPDO;
import backend.core.module.MessageConstantsInterface;
import backend.paymentprocess.findfirstinchain.businessobjects.BOFindFirstInChain;


/**
 * Title:       BOCreditPartyEnrichment
 * Description: Business object for credit party enrichment
 * Company:     Fundtech Israel
 * Author:      Asaf Levy
 * Date:        06/01/2010
 * @version     1.0
 */
@Wrap 

public class BOCreditPartyEnrichment extends BOBasic implements PDOConstantFieldsInterface, MessageConstantsInterface
{

	private static final Logger logger = LoggerFactory.getLogger(BOCreditPartyEnrichment.class);
	private static final String SECONDARY_ACTION_ADD_FIRST = "ADD_FIRST";
	private static final String SECONDARY_ACTION_REPLACE_FIRST = "REPLACE_FIRST";
	
  /**
   * 
   */
  @Expose
  @LoadPDO
  public Feedback performCreditPartyEnrichment(final String sMID)
  {
  	final String TRACE_CREDIT_PARTY_CHAIN_ENRICH_RULE_RESULTS = "Credit party enrichment rule results - Main action 1: {}, Secondary action 2: {}.";
  	final String TRACE_SECONDARY_ACTION_ADD_FIRST = "About to add BIC {} as 1st in CREDIT chain...";
  	final String TRACE_SECONDARY_ACTION_REPLACE_FIRST = "About to replace current 1st in CREDIT chain...";
  	final String TRACE_SECONDARY_ACTION_REPLACE_FIRST_RESULTS = "REPLACE_FIRST action will set BIC '{}' as 1st in chain instead of {} '{}' which its cust code is '{}'.";
  	final String TRACE_CURRENT_CHAIN_INDEX = "Current 1st in CREDIT chain index: {}.";
  	
    

    Feedback feedback = new Feedback();
    PDO pdo = Admin.getContextPDO();
    
		// Gets the related monitor field value.
		String sMF_CDT_PARTY_ENRICH = pdo.getString(MF_CDT_PARTY_ENRICH);
		boolean bCreditPartyEnriched = MONITOR_FLAG_ENRICHED.equals(sMF_CDT_PARTY_ENRICH);
		
    try
    {
			// Continues only if credit party wasn't enriched yet.
			if(!bCreditPartyEnriched)
			{
				// STEP 1 - 
				// Invokes the credit party chain enrichment rule, (rule type ID 168).
				String[] arrRuleActions = BOProxies.m_paymentServicesLogging.invokeRuleWithSecondaryAction(Admin.getContextAdmin(), RULE_TYPE_ID_CREDIT_PARTY_CHAIN_ENRICHMENT, true);
				logger.info(TRACE_CREDIT_PARTY_CHAIN_ENRICH_RULE_RESULTS, arrRuleActions[0], arrRuleActions[1]);
				
				// Enrichment is required.
				if(isArrayNotNullAndNotEmpty(arrRuleActions))
				{
					String sCustCode = arrRuleActions[0];
					String sSecondaryAction = arrRuleActions[1];
					
					if(!isNullOrEmpty(sSecondaryAction))
					{
						Customrs customrs = CacheKeys.customrsCCKey.getSingle(sCustCode);
						String sBIC = customrs.getSwiftId();
						
						int iCurrentFirstInChainIndex = pdo.getInteger(D_CHAIN_INDEX).intValue();
						logger.info(TRACE_CURRENT_CHAIN_INDEX, iCurrentFirstInChainIndex);
						
						// Secondary action is to add the customrs BIC as the first in credit chain.
						if(SECONDARY_ACTION_ADD_FIRST.equals(sSecondaryAction))
						{
							logger.info(TRACE_SECONDARY_ACTION_ADD_FIRST, sBIC);
							
							BOFindFirstInChain.setChainField(true, iCurrentFirstInChainIndex-1, ChainTypeOrigin.BIC, sBIC);
						}
						
  					// Secondary action is to replace the current credit first in chain with the BIC.
						else // REPLACE_FIRST
						{
							logger.info(TRACE_SECONDARY_ACTION_REPLACE_FIRST);
							
							// Assumption: there is always a current 1st in chain; i.e. we'll arrive here even if in BOPartyProcessing we have fail in
							// the find 1st in chain service; in that case, an execption will occur here, message will go to REPAIR and user will fix
							// it in the GUI. There is no check for null case as not having a 1st in chain in the message is a rare situation.
							MessageChainsData messageChainsData = pdo.getCreditChainsData();
							ChainData chainData = messageChainsData.getSpecificChainData(iCurrentFirstInChainIndex);
							ChainType chainType = chainData.getChainType();
							ChainTypeOrigin currentFirstInChainChainTypeOrigin = chainData.getChainTypeOrigin();
							String sCurrentFirstInChainValue = chainData.getValue();
							String sCurrentFirstInChainCustCode = chainData.getCustCode();
							
							logger.info(TRACE_SECONDARY_ACTION_REPLACE_FIRST_RESULTS,  new Object[]{sBIC, currentFirstInChainChainTypeOrigin, sCurrentFirstInChainValue, sCurrentFirstInChainCustCode});
							
							// Cleans all other fields related to this chain type.
							// Not required for 'Receiver' and 'Correspondent' chain types as these chains include only BIC,
							// which is replaced in any case.
							if(chainType != chainType.Receiver && chainType != chainType.Correspondent)
							{
								cleanChainTypeRelatedFields(chainType);
							}
							
							BOFindFirstInChain.setChainField(true, iCurrentFirstInChainIndex, ChainTypeOrigin.BIC, sBIC);
						}
						
						// Sets service monitor to 'E'.
						pdo.set(MF_CDT_PARTY_ENRICH, MONITOR_FLAG_ENRICHED);
					}
				}
			}
    }
    catch(Exception e)
    {
      ExceptionController.getInstance().handleException(e, this);
    }

    

    return feedback;
  }
  
  /**
   * 
   */
  private void cleanChainTypeRelatedFields(ChainType chainType)
  {
  	final String TRACE_CLEANS_IBAN_FIELD = "Sets related IBAN field {} to null; previous value: {}; also sets related derived field to null.";
  	final String TRACE_CLEANS_ACCOUNT_NUMBER_FIELD = "Sets related account number field {} to null; previous value: {}; also sets related derived field to null.";
  	
  	
  	
  	PDO pdo = Admin.getContextPDO();
  	
  	// IBAN.
  	String sD_FIRST_IN_CDT_CHAIN_IBAN = pdo.getString(D_FIRST_IN_CDT_CHAIN_IBAN);
  	if(!isNullOrEmpty(sD_FIRST_IN_CDT_CHAIN_IBAN))
  	{
  		// Gets the related IBAN field ID and sets it to null.
  		String sRelatedIBANFieldID = pdo.getString(D_1ST_IN_CDT_CHA_IBAN_FLD_ID);
  		logger.info(TRACE_CLEANS_IBAN_FIELD, sRelatedIBANFieldID, sD_FIRST_IN_CDT_CHAIN_IBAN);
  		pdo.set(sRelatedIBANFieldID, (String)null);
  		
  		// Sets related derived fields to null.
  		pdo.set(D_FIRST_IN_CDT_CHAIN_IBAN, (String)null);
  		pdo.set(D_1ST_IN_CDT_CHA_IBAN_FLD_ID, (String)null);
  	}
  	
  	// Account number.
  	String sD_FIRST_IN_CDT_CHAIN_ACC_NUM = pdo.getString(D_FIRST_IN_CDT_CHAIN_ACC_NUM);
  	if(!isNullOrEmpty(sD_FIRST_IN_CDT_CHAIN_ACC_NUM))
  	{
  		// Gets the related account number field ID and sets it to null.
  		String sRelatedAccNumberFieldID = pdo.getString(D_1ST_IN_CDT_CHA_ACCNUM_FLD_ID);
  		logger.info(TRACE_CLEANS_ACCOUNT_NUMBER_FIELD, sRelatedAccNumberFieldID, sD_FIRST_IN_CDT_CHAIN_ACC_NUM);
  		pdo.set(sRelatedAccNumberFieldID, (String)null);
  		
  		// Sets related derived fields to null.
  		pdo.set(D_FIRST_IN_CDT_CHAIN_ACC_NUM, (String)null);
  		pdo.set(D_1ST_IN_CDT_CHA_ACCNUM_FLD_ID, (String)null);
  	}
  	
  	
  }
}
