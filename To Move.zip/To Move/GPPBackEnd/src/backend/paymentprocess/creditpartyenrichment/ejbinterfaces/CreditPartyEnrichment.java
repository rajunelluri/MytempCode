package backend.paymentprocess.creditpartyenrichment.ejbinterfaces;

import javax.ejb.Remote;
import com.fundtech.core.security.Admin;

/**
 * Remote interface for CreditPartyEnrichment.
 */
@Remote
public interface CreditPartyEnrichment{

	public static final String REMOTE_JNDI_NAME="ejb/CreditPartyEnrichmentBean";
	
	
	/** 
	 */
	public com.fundtech.datacomponent.response.Feedback performCreditPartyEnrichment(final Admin admin, java.lang.String sMID ) ;

}//EOI  