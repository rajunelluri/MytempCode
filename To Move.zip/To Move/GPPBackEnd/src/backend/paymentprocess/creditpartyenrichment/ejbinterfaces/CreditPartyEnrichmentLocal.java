package backend.paymentprocess.creditpartyenrichment.ejbinterfaces;

import javax.ejb.Local;

/**
 * Local interface for CreditPartyEnrichment.
 */
@Local
public interface CreditPartyEnrichmentLocal extends CreditPartyEnrichment{} ; 