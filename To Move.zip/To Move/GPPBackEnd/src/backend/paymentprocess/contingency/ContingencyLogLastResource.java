package backend.paymentprocess.contingency;

import java.util.Date;

import javax.transaction.HeuristicMixedException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.core.general.tx.LastResourceInterface;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.security.Admin;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalDateTimeUtil;

public class ContingencyLogLastResource implements LastResourceInterface {
	
	protected final static Logger logger = LoggerFactory.getLogger("payment_rollback"); 
	
	private final static String TIMESTAMP = "Timestamp";
	private final static String ERROR_CODE = "Error description";
	private final static String MID = "MID";
	private final static String INSTRUCTION_ID = "Instruction ID";
	private final static String REQUEST_EXECUTION_DATE = "Request execution date";
	
	protected final static String SEP = ": ";
	protected final static String FIELD_SEP = ", ";
	protected final static String NEW_LINE = "\n";
	protected final static String START_END = "***********************************************************************************";




	@Override
	public void commitLastResource() throws HeuristicMixedException {

	}

	@Override
	public void compensate() throws HeuristicMixedException {
		StringBuilder loggerMessage = getLogDescription();
		loggerMessage.append(NEW_LINE);
		loggerMessage.append(START_END);
		logger.info(loggerMessage.toString());
	}
	
	protected StringBuilder getLogDescription(){
		PDO pdo = Admin.getRollbackPDOHolder();
		Throwable exception = Admin.getRollbackExceptionHolder();
		
		StringBuilder loggerMessage = new StringBuilder(NEW_LINE);
		loggerMessage.append(START_END);
		loggerMessage.append(NEW_LINE);
		loggerMessage.append(TIMESTAMP);
		loggerMessage.append(SEP);
		loggerMessage.append(GlobalDateTimeUtil.getServerTimeStamp());
		loggerMessage.append(FIELD_SEP);
		loggerMessage.append(ERROR_CODE);
		loggerMessage.append(SEP);
		loggerMessage.append(exception.getMessage());
		loggerMessage.append(FIELD_SEP);
		loggerMessage.append(MID);
		loggerMessage.append(SEP);
		loggerMessage.append(pdo.getMID());
		loggerMessage.append(FIELD_SEP);
		loggerMessage.append(INSTRUCTION_ID);
		loggerMessage.append(SEP);
		loggerMessage.append(pdo.get(PDOConstantFieldsInterface.P_INSTR_ID));
		loggerMessage.append(FIELD_SEP);
		loggerMessage.append(REQUEST_EXECUTION_DATE);
		loggerMessage.append(SEP);
		Date date = pdo.getDate(PDOConstantFieldsInterface.X_STTLM_DT_1B);
		loggerMessage.append(date == null ? GlobalConstants.EMPTY_STRING : GlobalDateTimeUtil.dateToStaticDataString(date));
		
		return loggerMessage;
	}

	@Override
	public void afterCommit() throws HeuristicMixedException {

	}

	@Override
	public String getID() {
		return ContingencyLogLastResource.class.getName();
	}

}