/*    */ package backend.paymentprocess.debulkingprocess.ejb;
/*    */ 
/*    */ import backend.paymentprocess.asynch.timers.AbstractTimer;
/*    */ import backend.paymentprocess.asynch.timers.TimerBeanInterface;
/*    */ import backend.paymentprocess.debulkingprocess.businessobjects.BODebulkingProcess;
/*    */ import backend.paymentprocess.debulkingprocess.ejbinterfaces.DebulkingProcess;
/*    */ import backend.paymentprocess.debulkingprocess.ejbinterfaces.DebulkingProcessLocal;
/*    */ import com.fundtech.core.general.flows.FlowException;
/*    */ import com.fundtech.core.security.Admin;
/*    */ import com.fundtech.datacomponent.response.Feedback;
/*    */ import com.fundtech.datacomponent.response.SimpleResponseDataComponent;
/*    */ import javax.ejb.Stateless;
/*    */ 
/*    */ @Stateless
/*    */ public class DebulkingProcessBean extends AbstractTimer<DebulkingProcess>
/*    */   implements DebulkingProcess, DebulkingProcessLocal, TimerBeanInterface
/*    */ {
/*    */   private static final String TIMEOUT_METHOD = "onDebulkPreProcessingTimeOut";
/*    */ 
/*    */   public DebulkingProcessBean()
/*    */   {
/* 35 */     super(BODebulkingProcess.class, DebulkingProcess.class, "onDebulkPreProcessingTimeOut");
/*    */   }
/*    */ 
/*    */   public SimpleResponseDataComponent performDebulkPreProcessing(Admin admin, String tuple) throws FlowException {
/* 39 */     return ((DebulkingProcess)getBOInstance()).performDebulkPreProcessing(admin, tuple);
/*    */   }
/*    */ 
/*    */   public SimpleResponseDataComponent performDebulkMultiPreProcessing(Admin admin, String tuple) throws FlowException
/*    */   {
/* 44 */     return ((DebulkingProcess)getBOInstance()).performDebulkMultiPreProcessing(admin, tuple);
/*    */   }
/*    */ 
/*    */   public SimpleResponseDataComponent performAckDebulkPreProcessing(Admin admin, String tuple) throws FlowException
/*    */   {
/* 49 */     return ((DebulkingProcess)getBOInstance()).performAckDebulkPreProcessing(admin, tuple);
/*    */   }
/*    */ 
/*    */   public Feedback performAccumulations(Admin admin, String mid)
/*    */     throws FlowException
/*    */   {
/* 56 */     return ((DebulkingProcess)getBOInstance()).performAccumulations(admin, mid);
/*    */   }
/*    */ 
/*    */   public SimpleResponseDataComponent performDebulkMultiPreProcessingForWaitingPayments(Admin admin, String tuple)
/*    */     throws FlowException
/*    */   {
/* 62 */     return ((DebulkingProcess)getBOInstance()).performDebulkMultiPreProcessingForWaitingPayments(admin, tuple);
/*    */   }
/*    */ }

/* Location:           c:\Documents and Settings\ofer.baranes\Desktop\OCBC\MassPayment\RND_import\classes\debulkingprocess\ejb\
 * Qualified Name:     backend.paymentprocess.debulkingprocess.ejb.DebulkingProcessBean
 * JD-Core Version:    0.6.0
 */