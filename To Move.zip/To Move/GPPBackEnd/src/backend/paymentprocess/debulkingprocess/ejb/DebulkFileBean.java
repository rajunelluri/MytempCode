/*    */ package backend.paymentprocess.debulkingprocess.ejb;
/*    */ 
/*    */ import backend.businessobject.proxies.interceptors.InterceptorSetType;
/*    */ import backend.core.SuperSLSB;
/*    */ import backend.paymentprocess.debulkingprocess.businessobjects.BODebulkFile;
/*    */ import backend.paymentprocess.debulkingprocess.ejbinterfaces.DebulkFile;
/*    */ import backend.paymentprocess.debulkingprocess.ejbinterfaces.DebulkFileLocal;
/*    */ import com.fundtech.core.general.flows.FlowException;
/*    */ import com.fundtech.core.security.Admin;
/*    */ import com.fundtech.datacomponent.response.SimpleResponseDataComponent;
import javax.ejb.Stateless;
/*    */ 
/*    */ @Stateless
/*    */ public class DebulkFileBean extends SuperSLSB<DebulkFile>
/*    */   implements DebulkFileLocal, DebulkFile
/*    */ {
/*    */   public DebulkFileBean()
/*    */   {
/* 17 */     super(BODebulkFile.class, InterceptorSetType.Complete);
/*    */   }
/*    */ 
/*    */   public SimpleResponseDataComponent debulkFile(Admin admin, String filePath) throws FlowException {
/* 21 */     return ((DebulkFile)this.m_bo).debulkFile(admin, filePath);
/*    */   }
/*    */ 
/*    */   public SimpleResponseDataComponent debulkString(Admin admin, String message) throws FlowException {
/* 25 */     return ((DebulkFile)this.m_bo).debulkString(admin, message);
/*    */   }
/*    */ 
/*    */   public SimpleResponseDataComponent debulkFileByIndex(Admin admin, String filePath) throws FlowException {
/* 29 */     return ((DebulkFile)this.m_bo).debulkFileByIndex(admin, filePath);
/*    */   }
/*    */ 
/*    */   public SimpleResponseDataComponent debulkStringByIndex(Admin admin, String message) throws FlowException {
/* 33 */     return ((DebulkFile)this.m_bo).debulkStringByIndex(admin, message);
/*    */   }
/*    */ 
/*    */   public SimpleResponseDataComponent redebulkFileByIndex(Admin admin, String message) throws FlowException {
/* 37 */     return ((DebulkFile)this.m_bo).redebulkFileByIndex(admin, message);
/*    */   }
			
			public  SimpleResponseDataComponent createChunksForRejectedFile(Admin admin, String internalFileId) throws Throwable{
				return ((DebulkFile)this.m_bo).createChunksForRejectedFile(admin, internalFileId);
			}
/*    */ }

/* Location:           c:\Documents and Settings\ofer.baranes\Desktop\OCBC\MassPayment\RND_import\classes\debulkingprocess\ejb\
 * Qualified Name:     backend.paymentprocess.debulkingprocess.ejb.DebulkFileBean
 * JD-Core Version:    0.6.0
 */