package backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi;

import static backend.core.module.MessageConstantsInterface.MESSAGE_TYPE_PACS_008;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.X_FITOFICSTMRCDTTRF;

import java.io.File;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Map;

import com.fundtech.cache.entities.LogicalFieldsXpath;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.paymenttypes.PaymentType;

import backend.paymentprocess.debulkingprocess.common.WorkflowType;


/**
 * Concrete SingleMessageTypeData for pacs 08.
 * 
 * @author dmitryp
 */
public class SinglePacs08 extends SingleMessageTypeData
{
	private Map<String, LogicalFieldsXpath> logicalFieldsXPathMap;
	
	public SinglePacs08(PaymentType paymentType) {
		super(paymentType);
		this.setPaymentType(paymentType);
		CLOSE_XML_TAGS = "</%sFIToFICstmrCdtTrf></%sDocument>";
		MULTI_FILE_START_TAG = 	 "<%sFIToFICstmrCdtTrf>";
		MULTI_FILE_END_TAG = "</%sFIToFICstmrCdtTrf>";
		logicalFieldsXPathMap = CacheKeys.LogicalFieldsXPathKey.getSingle(PaymentType.valueOf(MESSAGE_TYPE_PACS_008));
	}
	
//	@Override
//	public void initTags()
//	{
//		super.initTags();
//		PaymentType paymentType = PaymentType.valueOf(this.getPaymentType());    
//        Map<String, LogicalFieldsXpath> map =CacheKeys.LogicalFieldsXPathKey.getSingle(paymentType);  
//        
//       PACS_08_TRANSACTION_START_TAG =  this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_PMT_INFO).getTagName(),false);
//       PACS_08_TRANSACTION_END_TAG =  this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_PMT_INFO).getTagName(), true);
//	}
//	@Override
//	public String getTransactionStartTag() {
//		return PACS_08_TRANSACTION_START_TAG;
//	}
//		
//	@Override
//	public String getTransactionEndTag() {
//		return PACS_08_TRANSACTION_END_TAG;
//	}

	@Override
	public String getTypeIdentifier() {
		// TODO Get the type from PaymentType	
		return paymentType.getSchemaNamespace();
	}

	@Override
	public String getPaymentTypeName() {
		//return "Pacs_008";
		return paymentType.name();
	}
	
	@Override
	public String getPreDocumentEnd() {
		return getGrpHdrEndTag();
	}

	@Override
	public String getPrePmtInfEnd() {
		return getTransactionStartTag();
	}
	
	@Override
	public XmlTransactionReaderBase getReaderWithoutInit(File file, int chunkSize, RandomAccessFile accessFile)
	{
		if (reader == null) {
			reader = new PacsTransactionReader(file,accessFile, chunkSize,this);
		}
		return reader;
	}

	
	@Override
	public XmlTransactionReaderBase getReader() {
		
		if (defaultCtorReader == null) {
			defaultCtorReader= new PacsTransactionReader(this);
		}
		return defaultCtorReader;
		
	}
	

	@Override
	public XmlTransactionReaderBase getReader(File file, int chunkSize) {
		
		if (reader == null) {
			return new PacsTransactionReader(file, chunkSize,this);
		}
		return reader;
		
	}

//	@Override
//	public String getXmlClosingTags() {
//		return PACS_08_CLOSE_XML_TAGS;
//	}
	
	@Override
	public String getWorkflow() {
		return WorkflowType.Pacs_008.name();
	}
	
	@Override
	public void formatTags(String namespace)
	{
		super.formatTags(namespace);
//		this.PACS_08_TRANSACTION_END_TAG   = String.format(this.PACS_08_TRANSACTION_END_TAG,namespace);
//		this.PACS_08_TRANSACTION_START_TAG = String.format(this.PACS_08_TRANSACTION_START_TAG,namespace);
//		this.PACS_08_CLOSE_XML_TAGS 	   = String.format(this.PACS_08_CLOSE_XML_TAGS,namespace,namespace);
	}

	@Override
	public byte[] getPaymentInfoElementStartTagBytes() {
		return getPaymentInfoElementStartTag().getBytes();
	}
	


	
	public ArrayList<byte[]> getTranscationTagsByteArrayByOrderList()
	{
		ArrayList<byte[]>  list = new ArrayList<byte[]>();
		list.add(new String("xmlns=").getBytes());
		list.add(this.getTransactionStartTagBytes());
		list.add(this.getTransactionEndTagBytes());
		return list;
	}
	
	public ArrayList<byte[]> getHeaderTagsByteArrayByOrderList()
	{
		ArrayList<byte[]>  list = new ArrayList<byte[]>();
		list.add(new String("xmlns=").getBytes());
		list.add(new String("<GrpHdr>").getBytes());
		list.add(new String("</GrpHdr>").getBytes());
		return list;
	}
	
	@Override
	public void initTags(PaymentType paymentType)
	{
       Map<String, LogicalFieldsXpath> map = CacheKeys.LogicalFieldsXPathKey.getSingle(paymentType);  
        
       GROUP_HEADER_START_TAG =  this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_GRP_INFO).getTagName(),false);
       GROUP_HEADER_END_TAG =  this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_GRP_INFO).getTagName(), true);
       
//       PAYMENT_INFO_START_TAG =  this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_PMT_INFO).getTagName(), false);
//       PAYMENT_INFO_END_TAG =  this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_PMT_INFO).getTagName(), true);
//       
       //TODO: NO FIELDS AT LOGICAL FIELDS XPATH
       PAYMENT_INFO_START_TAG=  "";
       PAYMENT_INFO_END_TAG = "";
       
       
      TRANSACTION_START_TAG =  this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_PMT_INFO).getTagName(), false);
      TRANSACTION_END_TAG =  this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_PMT_INFO).getTagName(), true);
	}
	
	@Override
	public byte[] getPaymentInfoElementEndTagBytes() {
		return getPaymentInfoElementEndTag().getBytes();
	}
	
	@Override
	public byte[] getTransactionEndTagBytes() {
		return getTransactionEndTag().getBytes();
	}

	@Override
	public byte[] getTransactionStartTagBytes() {
		return getTransactionStartTag().getBytes();
	}
		
	/**
	 * @return the header tag
	 */
	@Override
	public String getHeaderTag() {
		LogicalFieldsXpath logicalFieldsXpath = logicalFieldsXPathMap.get(X_FITOFICSTMRCDTTRF) ;			
		return logicalFieldsXpath.getTagName(); // FIToFICstmrCdtTrf
	}
	
}//EOC SinglePacs08