
package backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi;

import java.io.InputStream;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import javax.xml.namespace.QName;
import javax.xml.stream.EventFilter;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ctc.wstx.exc.WstxParsingException;
import com.fundtech.core.paymentprocess.data.paymenttypes.PaymentType;

/**
 * XML stream based parser.
 * The parser collect information from the head of the file.   
 */
public class FndtBatchMessageStreamBasedParser {
	private static final Logger logger = LoggerFactory.getLogger(FndtBatchMessageStreamBasedParser.class);
	
	private XMLEventReader reader;
	private DynamicEventFilter filter;

	private long offSet;
	
	static final String FNDT_MSG_URI = PaymentType.valueOf(PaymentType.PT_FNDT_MSG).getSchemaNamespace();

	private static final int MAX_HEADER_SIZE = 1024*8;
	
	public FndtBatchMessageStreamBasedParser(InputStream inputStream) throws XMLStreamException {
		XMLInputFactory ifactory = XMLInputFactory.newInstance();
		reader = ifactory.createXMLEventReader(inputStream);					
	}
	
	public FndtBatchMsgParseResult parseHead(long offSet) throws XMLStreamException {
		FndtBatchMsgParseResult result = new FndtBatchMsgParseResult();
		this.offSet=offSet;
		return parseHead(this.reader);
	}
		
	public FndtBatchMsgParseResult parseHead(XMLEventReader reader) throws XMLStreamException {
		FndtBatchMsgParseResult result = new FndtBatchMsgParseResult();
		
		XMLEvent e = null;
		
		filter = new DynamicEventFilter(new QName(FNDT_MSG_URI,"BatchHeader"));
		
		while (reader.hasNext()) {
			try {
				e = reader.nextEvent();
			} catch (Exception ex) {
				if (isInvalidXmlException(ex))
					throw (XMLStreamException)ex;
				
				logger.error("",ex);
				
				break;
			}
			
			enforceHeadMaxLimit(e,result);
			
			if (filter.accept(e) && (e.isStartElement() || e.isEndElement())) {
				if (!result.isBatchHeaderStarted()) {
					result.setBatchHeaderStarted(true);
					filter.acceptAllStopAt(true);
					continue;
				} 
				
				//GrpHeader is within BatchHeader
				if (!result.isNativeGrpHeaderStarted()) {									
					result.setNativeGrpHeaderStarted(true);					
					result.nativePayloadGrpHdrStartTagLocation = e.getLocation().getCharacterOffset()+offSet;
					result.nativeHeaderRootQName = ((StartElement)e).getName();
					filter.setTarget(new QName(FNDT_MSG_URI,"BatchHeader")); //go the end of the GrpHdr 
					continue;
				} 
				
				if (!result.isBatchHeaderEnded()) {						
					result.setBatchHeaderEnded(true);						
					result.nativePayloadGrpHdrEndTagLocation = e.getLocation().getCharacterOffset()+offSet;				
					filter.setTarget(new QName(FNDT_MSG_URI,"PmntHeader"));					
					continue;
				}
				
				if (!result.isPmntHeaderStarted()) {
					result.setPmntHeaderStarted(true);
					filter.acceptAllStopAt(true);
					continue;
				} 
				
				//PmtInf is within PmntHeader
				if (!result.isNativePmtInfStarted()) {									
					result.setNativePmtInfStarted(true);					
					result.nativePayloadPmtInfStartTagLocation = e.getLocation().getCharacterOffset()+offSet;					
					filter.setTarget(((StartElement)e).getName()); //go the end of the PmtInf 
					continue;
				} 
				
				if (!result.isPmntHeaderEnded()) {						
					result.setPmntHeaderEnded(true);						
					result.nativePayloadPmtInfEndTagLocation = e.getLocation().getCharacterOffset()+offSet;				
					filter.setTarget(new QName(FNDT_MSG_URI,"FndtMsg"));					
					continue;
				}
				
				if (!result.isFndtMsgStarted()) {						
					result.setFndtMsgStarted(true);	
					result.fndtMsgRootQName = ((StartElement)e).getName();
					filter.setTarget(new QName(FNDT_MSG_URI,"Pmnt"));
					continue;
				}
				
				if (!result.isNativePayloadStarted()) {
					result.setNativePayloadStarted(true);
					e = reader.nextTag();
					result.nativeMessageRootQName = ((StartElement)e).getName();
					break;
				}				
			}
		}//while
		
		logger.debug("results "+result);
		
		return result;
	}
	
	private boolean isInvalidXmlException(Exception ex) {
		return ex instanceof WstxParsingException;
	}

	private void enforceHeadMaxLimit(XMLEvent e,FndtBatchMsgParseResult result) throws RuntimeException {
		if (e.getLocation().getCharacterOffset() < 0)
			throw new RuntimeException("Oh Oh.. "+reader.getClass().getName()+" doesn't supports the optional" +
					" 'CharacterOffset' on the Location interface. TBD manual impl");
		
		if (e.getLocation().getCharacterOffset() > MAX_HEADER_SIZE) {			
			throw new RuntimeException("Could not complete processing within max size of "+MAX_HEADER_SIZE
					+" characters, missing expected tag: " +result.getFirstMissingTagName());
		}
	}	
	
	
}//MessageStreamBasedParser


class DynamicEventFilter implements EventFilter {
	Set<QName> targetChoise;
	
	boolean acceptAllStopAt;
	boolean acceptNone;
	boolean acceptTarget;
	
	DynamicEventFilter() {
		this((Set<QName>)null);
	}
	
	DynamicEventFilter(QName acceptableTarget) {
		this(new HashSet<QName>(Arrays.asList(new QName[]{acceptableTarget})));
	}
	
	DynamicEventFilter(Set<QName> acceptableTargets) {
		setTarget(acceptableTargets);
	}
	
	public void acceptAllStopAt(boolean acceptTarget) {
		acceptAllStopAt(targetChoise,acceptTarget);
	}
	
	public void acceptAllStopAt(Set<QName> targetChoise,boolean acceptTarget) {			
		setTarget(targetChoise);
		this.acceptAllStopAt = true;
		this.acceptTarget = acceptTarget;
	}
	
	public boolean accept(XMLEvent event) {	
		if (acceptNone)
			return false;
					
		if (isTargetElement(event)) {
			if (acceptAllStopAt) {
				acceptNone = true;
				return acceptTarget;
			} else {
				return true;
			}
		} 

		return acceptAllStopAt ? true : false;
	}

	private boolean isTargetElement(XMLEvent event) {
		if (event.isStartElement() || event.isEndElement()) {
			QName qname = event.isStartElement() ? ((StartElement) event).getName() : ((EndElement) event).getName();
			return targetChoise.contains(qname);
		}
		return false;
	}

	void setTarget(Set<QName> targetChoise) {
		this.targetChoise = targetChoise;
		reset();
	}
	
	void setTarget(QName targetChoise) {
		setTarget(new HashSet<QName>(Arrays.asList(new QName[]{targetChoise})));
	}

	void reset() { 
		this.acceptAllStopAt = false;
		this.acceptNone = false;
	}		
}// DynamicFilter
