package backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi;

import java.io.File;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.cache.entities.InterfaceTypes;

/**
 * @author danny.aram
 * 
 */
public class G3MultiPacs002BulkTransactionReader extends
		G3MultiBulkTransactionReaderBase implements AckXmlTransactionReaderIfc {

	private static final Logger logger = LoggerFactory
			.getLogger(G3MultiPacs002BulkTransactionReader.class);
	private int numberOfChunks;
	
	public G3MultiPacs002BulkTransactionReader(File file, int chunkSize) {
		super(file, chunkSize);
		INTERFACE_SUB_TYPE = InterfaceTypes.INTERFACE_SUB_TYPE_DIST_ACK;

	}

	protected XmlTransactionReader getReaderForMessageType(String msgType) {
		nativeReader = new G3_SingleTypePacsBatch_TransactionReader(getFile(),
				getRandomeFile(), getChunkSize(), new G3Msg_SingleTypeBatch());
		nativeReader.setListener(this);
		nativeReader.setUtils(getUtils());
		nativeReader.lastTransactionEndInd = this.lastTransactionEndInd;
		return nativeReader;
	}

	@Override
	public String getFileStatus() {
		return ((AckXmlTransactionReader) nativeReader).getFileStatus();
	}

	@Override
	public String getoriginalFileInternalId() {
		return ((AckXmlTransactionReader) nativeReader)
				.getoriginalFileInternalId();
	}

	public boolean hasNext() {

		boolean hasNext = nativeReader.hasNext();

		setNewBulk(nativeReader.isNewBulk());

		setBulkNumOfTx(nativeReader.getBulkNumOfTx());

		setBulkCtrlSum(nativeReader.getBulkCtrlSum());

		setBulkTotalAmt(nativeReader.getBulkTotalAmt());
		
		setBulkType(nativeReader.getBulkType());
		
		if(getAppHdrCreDt()==null)
			setAppHdrCreDt(nativeReader.getAppHdrCreDt());
		if (hasNext) {
			setNumberOfChunks();
		}
		
		return nativeReader.hasMoreBulks() || hasNext;

	}

	private void setNumberOfChunks() {
		numberOfChunks++;
	}
	
	public int getNumberOfChunks() {
		return numberOfChunks;
	}

	@Override
	public void setAdditionalDocumentData(Object request, String chunkId,
			String status, String internalFileId, String path, String workFlow,
			String bulkId) {

		nativeReader.setAdditionalDocumentData(request, chunkId, status,
				internalFileId, path, workFlow, bulkId);
	}
	
	

}
