package backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi;



import java.io.File;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.paymentprocess.debulkingprocess.common.WorkflowType;

import com.fundtech.cache.entities.FileSummary;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.scl.debulkingProcessService.FileIndexDataType;
import com.fundtech.scl.debulkingProcessService.PerformDebulkingMultiRequestDocument;
import com.fundtech.scl.debulkingProcessService.PreStartDataType;
import com.fundtech.util.GlobalFileUtil;

/**
 * CamtTransactionReader for Camt_029 and Camt_056
 *
 */
public class CamtTransactionReader extends AbstractSingleInMuliSchemaReader{

	private static final Logger logger = LoggerFactory.getLogger(CamtTransactionReader.class);
	
	public CamtTransactionReader(FileMessageTypeData fileMessageTypeData ,  boolean headerContainsNumberOfTransactions){
		this.setFileMessageTypeData(fileMessageTypeData);
		super.headerContainsNumberOfTransactions = headerContainsNumberOfTransactions;
	}

	
	public CamtTransactionReader (File file,int chunkSize,FileMessageTypeData fileMessageTypeData , boolean headerContainsNumberOfTransactions){
		super(file,chunkSize,fileMessageTypeData);
		super.headerContainsNumberOfTransactions = headerContainsNumberOfTransactions;
		initMembers();
	}

	
	public CamtTransactionReader (File file,RandomAccessFile raf, int chunkSize,FileMessageTypeData fileMessageTypeData, boolean headerContainsNumberOfTransactions){
		super(file,raf, chunkSize,fileMessageTypeData);
		super.headerContainsNumberOfTransactions = headerContainsNumberOfTransactions;
		initMembers();
	}

	
	@Override
	public List<PDO> getPDOsFromChunk(PerformDebulkingMultiRequestDocument doc,
			String chunkId, String sInternalFileID, FileSummary fileSummary,
			Map[] arrMapSharedPDOContextHolder, boolean bShouldLogInfo)
			throws Throwable {
		final String COLUMN_OFFICE = "OFFICE";
	  	final String COLUMN_INITG_PTY_CUST_CODE = "INITG_PTY_CUST_CODE";
	  	final String COLUMN_MSG_TYPE = "MSG_TYPE";

	  	boolean isSinglePayment = false;
	  	

	    String sTracePrefix = String.format("'getPDOsFromChunk', (internal file ID: %s, chunk ID: %s); ", sInternalFileID, chunkId);

	  	// Gets related FILE_SUMMARY's OFFICE & INITG_PTY_CUST_CODE values.
	    final String sFileSummary_OFFICE =  fileSummary.getOffice() ;
	    final String sFileSummary_INITG_PTY_CUST_CODE = fileSummary.getInitgPtyCustCode() ;
	    final String msgType = fileSummary.getMsgType() ;

	  	logger.info(sTracePrefix + "calls 'BODebulkFile.debulkFile' for parsing passed XML chunk content...");
	  	List<String> listChunk = new ArrayList<String>();
	    logger.info(sTracePrefix + "after call to 'BODebulkFile.debulkFile'; size of returned list: %s", listChunk.size());
	    String path = doc.getPerformDebulkingMultiRequest().getPath();
	    File file = new File(path);
	    if (!file.isFile())
	    {
	    	path = path.substring(0,path.lastIndexOf(java.io.File.separator)) + java.io.File.separator + GlobalFileUtil.ARCHIVE_DIR +  path.substring(path.lastIndexOf(java.io.File.separator));
	    	file = new File(path);
	    }

	    String endTags 			= doc.getPerformDebulkingMultiRequest().getEndTags();
		PreStartDataType preStartDataType = doc.getPerformDebulkingMultiRequest().getPreStartDataListArray()[0];
	    long preDocumentStartTag = preStartDataType.getPreDocumentStartTag();
	    long preDocumentEndTag 	= preStartDataType.getPreDocumentEndTag();
	    long prePmtInfStartTag 	= preStartDataType.getPrePmtInfStartTag();
	    long prePmtInfEndTag 	= preStartDataType.getPrePmtInfEndTag();

	    RandomAccessFileUtils utils = new RandomAccessFileUtils(file);

	    boolean bAddPmtInf = (prePmtInfStartTag!=0);
	    List<PDO> pdoList = new ArrayList<PDO>();

	    listChunk.size();
	    String officeCurrency = CacheKeys.banksKey.getSingle(sFileSummary_OFFICE).getCurrency();


	    {
	    	StringBuilder sb = new StringBuilder();
			boolean needToAddFirstline = false;
	    	String documentPartTillFirstTransaction = utils.getDocumentPartTillFirstTransaction(
    						preDocumentStartTag,bAddPmtInf ? prePmtInfStartTag : preDocumentEndTag,
    						prePmtInfStartTag,prePmtInfEndTag,endTags,
    						bAddPmtInf,false,true,this.getFileMessageTypeData());


    		FileIndexDataType[] arr = doc.getPerformDebulkingMultiRequest().getFileIndexDataTypeListArray();

			for (FileIndexDataType fileIndexDataType : arr) {
	  	    	//Xml document without payment info section
	  	    	sb.append(documentPartTillFirstTransaction);
	  	    		
	  	    	//Transaction
				sb.append(fileIndexDataType.getMultiPaymentGroupingTagStart());
	  	    	sb.append("\r\n" + utils.getFileSectionFromIndexes(fileIndexDataType.getTransactionStartTag(),fileIndexDataType.getTransactionEndTag()));
	  	    	sb.append("\r\n" + fileIndexDataType.getMultiPaymentGroupingTagEnd());
	  	    	sb.append("\r\n" +endTags);

	  	    	//Transaction
	  	    	PDO pdo = PaymentDataFactory.newPDO(sb.toString(), true /*transient*/, false/*primary*/, false /*conjoined*/, null);

		        String sMID = pdo.getMID();
		        String sP_MSG_STS = pdo.getString(PDOConstantFieldsInterface.P_MSG_STS);
		        pdo.set(PDOConstantFieldsInterface.P_IS_HISTORY, WorkflowType.MP_PARTITION);
		        pdo.set(PDOConstantFieldsInterface.X_TX_NO, 1+"");
		  		pdo.set(PDOConstantFieldsInterface.P_RAW_MSG_TYPE, msgType);

		        pdo.set(PDOConstantFieldsInterface.P_ORG_INITG_PTY_CUST_CD, sFileSummary_INITG_PTY_CUST_CODE);

		        // Sets chunk ID.
		        pdo.set(PDOConstantFieldsInterface.P_CHUNK_ID, chunkId);

		        // Adds the MID to the returned list that later on will be used in the caller method for executing base processing for each MID.
		        pdoList.add(pdo);

		    	if(bShouldLogInfo) logger.info(String.format(sTracePrefix + "created following PDO - MID: %s, Status: %s, Chunk ID: %s, PDO ID: " +

		    		"%s", sMID, pdo.getString(PDOConstantFieldsInterface.P_MSG_STS), chunkId, pdo));

		    	sb.delete(0,sb.length());
			}
	    }

	    utils.dispose();

	    

	    return pdoList;

	}
	
	protected void configureNativeReader(){}


	@Override
	public void init(InputStream inputStream) throws Exception {
		// TODO Auto-generated method stub
		
	}


	@Override
	public long getBatchIndexOffset() {
		// TODO Auto-generated method stub
		return 0;
	}
}
