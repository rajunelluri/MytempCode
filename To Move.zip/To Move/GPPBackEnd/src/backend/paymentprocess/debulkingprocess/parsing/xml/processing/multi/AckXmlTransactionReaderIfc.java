package backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi;

public interface AckXmlTransactionReaderIfc {
	
	public String getFileStatus();

	 public String getoriginalFileInternalId();

}
