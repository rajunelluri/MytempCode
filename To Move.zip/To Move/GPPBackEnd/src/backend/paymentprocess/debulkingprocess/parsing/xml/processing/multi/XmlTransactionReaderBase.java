package backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi;

import java.io.InputStream;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.fundtech.cache.entities.FileSummary;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.scl.debulkingProcessService.PerformDebulkingMultiRequestDocument;

/**
 * This interface represents XML transaction reader.
 * It's input is the XML file and it's output is list of FileIndexData objects that represents the transactions header,start and end tags.
 *
 * @see FileIndexData
 *
 * @author haimv
 * @author dmitryp
 */
public interface XmlTransactionReaderBase extends Iterator {


	public void setAdditionalDocumentData(Object request, String chunkId, String status, String internalFileId, String path, String workFlow, String bulkId);


	public int getRecCountInChunk (Object chunk);

	public String getXmlofChunk(Object chunk);

	public void init() throws Exception;
	public void init(InputStream inputStream) throws Exception;

	public String getMsgId();
	
	public void setMsgId(String msgId);
	
	public String getPmtInfId();

	public String getCtrlSum();

	public String getPartyName();

	public String getInitiatingPartyCustCode();
	
	public String getSendingInst();

	public String getReceivingInst();

	public int getTrnsCount();
	
	public Date getAppHdrCreDt();
	
	public String getAppHdrBizMsgIdr();

	public int getPmtInfCount() ;

	public String getWorkflow() ;

	public String getOffice();
	
	public void setOffice(String office);

	public String getFileName();

	public boolean isSinglePayment();

	public String getInterfaceSubType();

	public Date getBusinessDate();

	public String getFileType();
	
	public void setM_fileType(String m_fileType);

	public String getInternalFileId();

	public void setInternalFileId(String m_internalFileId);

	boolean headerContainsNumberOfTransactions();
	
	public String getFileSource() ;

	public int getLastTransactionEndInd();
	
	public String getFileReference();
	
	public void setFileReference(String fileReference);
	
	public void setBulkCreDtTm(String bulkCreDtTm);
	
	public String getBulkCreDtTm();
	
	public int getNumDDBlk();
	
	public int getNumCTBlk();
	
	public int getCalcNumDDBlk();
	
	public int getCalcNumCTBlk();
	
	public String getSenderName() ;
	
	public abstract List<PDO> getPDOsFromChunk(PerformDebulkingMultiRequestDocument doc,String chunkId, String sInternalFileID,final FileSummary fileSummary,
			  final Map[] arrMapSharedPDOContextHolder) throws Throwable;

	public void setListener(XmlTransactionReaderListener listener);
	
	public boolean isNewBulk();
	
	public String getBulkType();
	public long getBulkNumOfTx();

	public BigDecimal getBulkTotalAmt();

	public long getBulkCtrlSum();


	public long getBatchIndexOffset();

}//EOI XmlTransactionReaderBase