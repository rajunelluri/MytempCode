package backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi;

import java.io.File;
import java.io.RandomAccessFile;
import java.util.Map;

import com.fundtech.cache.entities.LogicalFieldsXpath;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.paymenttypes.PaymentType;

import backend.paymentprocess.debulkingprocess.common.WorkflowType;

/**
 * Concrete SingleMessageTypeData for pacs 03.
 * 
 * @author haimv
 * @author dmitryp
 */
public class SinglePain08 extends SingleMessageTypeData{
	
	// TODO Do not use hard-coded tags - take it from logical_fields_xpath cache.
//		private String PAIN_08_TRANSACTION_START_TAG = "<%sDrctDbtTxInf>";
//	private String PAIN_08_TRANSACTION_END_TAG  = "</%sDrctDbtTxInf>";
//	
//	
//	private String PAIN_08_TRANSACTION_START_TAG = "";
//	private String PAIN_08_TRANSACTION_END_TAG  = "";
//	
//		
//
//	private String PAIN_08_CLOSE_XML_TAGS 		 = "</%sPmtInf></%sCstmrDrctDbtInitn></%sDocument>";
//	
	
	public SinglePain08(PaymentType paymentType) {
		super(paymentType);
		this.setPaymentType(paymentType);
		CLOSE_XML_TAGS 		 = "</%sPmtInf></%sCstmrDrctDbtInitn></%sDocument>";
		STARTING_XML_TAGS = "<Document xmlns=\""+paymentType.getSchemaNamespace()+"\"><CstmrDrctDbtInitn>";
		
	}
		
//	@Override
//	public void initTags()
//	{
//
//		super.initTags();
//		PaymentType paymentType = PaymentType.valueOf(getPaymentType());    
//        Map<String, LogicalFieldsXpath> map =CacheKeys.LogicalFieldsXPathKey.getSingle(paymentType);  
//        
//       PAIN_08_TRANSACTION_START_TAG =  this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_DIRECT_DBT_TRNF_INFO).getTagName(),false);
//       PAIN_08_TRANSACTION_END_TAG =  this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_DIRECT_DBT_TRNF_INFO).getTagName(), true);
//	}
//	@Override
//	public String getTransactionStartTag() {
//		return PAIN_08_TRANSACTION_START_TAG;
//	}
//	
//	@Override
//	public String getTransactionEndTag() {
//		return PAIN_08_TRANSACTION_END_TAG;
//	}

	@Override
	public String getTypeIdentifier() {
		// TODO Get the type from PaymentType		
		return "urn:iso:std:iso:20022:tech:xsd:pain.008.001.02";
	}

	@Override
	public String getPaymentTypeName() {
		return "Pain_008";

	}

	@Override
	public String getPreDocumentEnd() {
		return getGrpHdrStartTag();
	}

	@Override
	public String getPrePmtInfEnd() {
		return getTransactionStartTag();
	}

	@Override
	public XmlTransactionReaderBase getReader() {
		if (defaultCtorReader == null) {
			defaultCtorReader = new PainTransactionReader();
		}
		return defaultCtorReader;
	}
	
	@Override
	public XmlTransactionReaderBase getReader(File file, int chunkSize) {
		if (reader == null) {
			reader = new PainTransactionReader(file, chunkSize,this);
		}
		return reader;
	}
	
	@Override
	public XmlTransactionReaderBase getReaderWithoutInit(File file, int chunkSize, RandomAccessFile accessFile)
	{
		if (reader == null) {
			reader = new PainTransactionReader(file,accessFile, chunkSize,this);
		}
		return reader;
	}


//	@Override
//	public String getXmlClosingTags() {
//		return PAIN_08_CLOSE_XML_TAGS;
//	}
	
	@Override
	public String getWorkflow() {
		return WorkflowType.Pain_008.name();
	}
	
	@Override
	public void formatTags(String namespace)
	{
		super.formatTags(namespace);
//		this.PAIN_08_TRANSACTION_END_TAG   = String.format(this.PAIN_08_TRANSACTION_END_TAG,namespace);
//		this.PAIN_08_TRANSACTION_START_TAG = String.format(this.PAIN_08_TRANSACTION_START_TAG,namespace);
//		this.PAIN_08_CLOSE_XML_TAGS 	   = String.format(this.PAIN_08_CLOSE_XML_TAGS,namespace,namespace,namespace);
	}

	@Override
	public byte[] getPaymentInfoElementStartTagBytes() {
		return getPaymentInfoElementStartTag().getBytes();
	}

	@Override
	public byte[] getTransactionEndTagBytes() {
		return TRANSACTION_END_TAG_BYTES;
	}

	@Override
	public byte[] getTransactionStartTagBytes() {
		return TRANSACTION_START_TAG_BYTES;
	}

	@Override
	public byte[] getPaymentInfoElementEndTagBytes() {
		// TODO
		return null;
	}
	
	
		@Override
	public void initTags(PaymentType paymentType)
	{
        Map<String, LogicalFieldsXpath> map =CacheKeys.LogicalFieldsXPathKey.getSingle(paymentType);  
        
       GROUP_HEADER_START_TAG =  this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_GRP_INFO).getTagName(),false);
       GROUP_HEADER_END_TAG =  this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_GRP_INFO).getTagName(), true);
       
       PAYMENT_INFO_START_TAG =  this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_PMT_INFO).getTagName(), false);
       PAYMENT_INFO_END_TAG =  this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_PMT_INFO).getTagName(), true);
       

       
       //TODO: NO FIELD AT LOGICAL X PATH
      TRANSACTION_START_TAG =  this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_DIRECT_DBT_TRNF_INFO).getTagName(), false);
      TRANSACTION_END_TAG =  this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_DIRECT_DBT_TRNF_INFO).getTagName(), true);
       

	}
	
	protected void formatXmlClosingTags(String namespace) {
		this.CLOSE_XML_TAGS    = String.format(this.CLOSE_XML_TAGS,namespace,namespace,namespace);		
	}

}//EOF SinglePain08.java