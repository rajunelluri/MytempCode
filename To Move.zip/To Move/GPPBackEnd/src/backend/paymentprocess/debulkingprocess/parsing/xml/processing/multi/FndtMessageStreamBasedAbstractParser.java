package backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import javax.xml.namespace.QName;
import javax.xml.stream.EventFilter;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ctc.wstx.exc.WstxParsingException;
import com.fundtech.core.paymentprocess.data.paymenttypes.PaymentType;

public abstract class FndtMessageStreamBasedAbstractParser {

	private static final Logger logger = LoggerFactory.getLogger(FndtMessageStreamBasedAbstractParser.class);
	
	protected final String FNDT_MSG_URI = PaymentType.valueOf(PaymentType.PT_FNDT_MSG).getSchemaNamespace();

	protected static final int MAX_HEADER_SIZE = 1024*8;
	
	protected DynamicEventFilter filter;
	protected XMLEventReader reader;
	
	
	
	
	protected void enforceHeadMaxLimit(XMLEvent e,FndtBatchMsgParseResult result) throws RuntimeException {
		if (e.getLocation().getCharacterOffset() < 0)
			throw new RuntimeException("Oh Oh.. "+reader.getClass().getName()+" doesn't supports the optional" +
					" 'CharacterOffset' on the Location interface. TBD manual impl");
		
		if (e.getLocation().getCharacterOffset() > MAX_HEADER_SIZE) {			
			throw new RuntimeException("Could not complete processing within max size of "+MAX_HEADER_SIZE
					+" characters, missing expected tag: " +result.getFirstMissingTagName());
		}
	}	
	
	protected boolean isInvalidXmlException(Exception ex) {
		return ex instanceof WstxParsingException;
	}
}
