package backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi;

import static backend.core.module.MessageConstantsInterface.MESSAGE_TYPE_CAMT_029;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.X_GRP_INFO;

import java.io.File;
import java.io.RandomAccessFile;
import java.util.Map;

import com.fundtech.cache.entities.LogicalFieldsXpath;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.paymenttypes.PaymentType;

public class SingleCamt029 extends SingleMessageTypeData {
	
	private Map<String, LogicalFieldsXpath> logicalFieldsXPathMap;	

	public SingleCamt029(PaymentType paymentType) {
		super(paymentType);
		this.setPaymentType(paymentType);
		logicalFieldsXPathMap = CacheKeys.LogicalFieldsXPathKey.getSingle(PaymentType.valueOf(MESSAGE_TYPE_CAMT_029));
	}

	@Override
	public String getTypeIdentifier() {
		return "urn:iso:std:iso:20022:tech:xsd:camt.029.001.03";
	}

	@Override
	public void initTags(PaymentType paymentType) {
	    Map<String, LogicalFieldsXpath> map =CacheKeys.LogicalFieldsXPathKey.getSingle(paymentType);  
	        
	    TRANSACTION_START_TAG =  this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_PMT_INFO).getTagName(),false);
	    TRANSACTION_END_TAG =  this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_PMT_INFO).getTagName(), true);
	   
	   	PAYMENT_INFO_START_TAG = this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_GRP_INFO_MULTI).getTagName(), false);
		PAYMENT_INFO_END_TAG = this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_GRP_INFO_MULTI).getTagName(), true);
		
		MULTI_PAYMENT_GROUPING_TAG_START =  this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_CXLDTLS).getTagName(), false);
		MULTI_PAYMENT_GROUPING_TAG_END =  this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_CXLDTLS).getTagName(), true);
			
		GROUP_HEADER_START_TAG = PAYMENT_INFO_START_TAG;
		// The header info ends with </STS>
		GROUP_HEADER_END_TAG   = this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_STATUS).getTagName(), true);;

		CLOSE_XML_TAGS = "</%sRsltnOfInvstgtn></%sDocument>";
	}

	@Override
	public String getPaymentTypeName() {
		return "Camt_029";
	}

	@Override
	public XmlTransactionReaderBase getReader(File file, int chunkSize) {
		if (reader == null) {
			reader = new CamtTransactionReader(file, chunkSize,this , false);
		}
		return reader;
	}

	@Override
	public XmlTransactionReaderBase getReader() {
		if (defaultCtorReader == null) {
			defaultCtorReader= new CamtTransactionReader(this , false);
		}
		return defaultCtorReader;
		
	}

	@Override
	public String getPreDocumentEnd() {
		return getGrpHdrEndTag();
	}

	@Override
	public String getPrePmtInfEnd() {
		return getTransactionStartTag();
	}

	@Override
	public byte[] getPaymentInfoElementStartTagBytes() {
		return getPaymentInfoElementStartTag().getBytes();
	}

	@Override
	public byte[] getPaymentInfoElementEndTagBytes() {
		return getPaymentInfoElementEndTag().getBytes();
	}

	@Override
	public XmlTransactionReaderBase getReaderWithoutInit(File file,
			int chunkSize, RandomAccessFile accessFile) {
		if (reader == null) {
			reader = new CamtTransactionReader(file,accessFile, chunkSize,this , false);
		}
		return reader;
	}

	@Override
	public String getHeaderTag() {
		LogicalFieldsXpath logicalFieldsXpath = logicalFieldsXPathMap.get(X_GRP_INFO);
		return logicalFieldsXpath.getTagName(); // RsltnOfInvstgtn
	}	
}
