
package backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.namespace.QName;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class XmlParsingHelper {
	private static final Logger logger = LoggerFactory.getLogger(XmlParsingHelper.class);
	
	public static QName extractRootNamespace(String xmSnippet) {
		QName qname = null;
		
		String tag = null;
		String prefix = null;
		String namespacesDecl = null;
		
    	Pattern p = Pattern.compile("<(?:([a-zA-Z0-9]*):)?([a-zA-Z0-9]*)\\s*(xmlns(.*?)=\"(.*?)\")?>");
    	xmSnippet = xmSnippet.replaceAll("\\r\\n"," ");
    	xmSnippet = xmSnippet.replaceAll("\\r"," ");
    	xmSnippet = xmSnippet.replaceAll("\\n"," ");
    	
    	xmSnippet = xmSnippet.substring(xmSnippet.lastIndexOf("?>") + 1);
        Matcher m = p.matcher(xmSnippet);
        
        if (m.find()){
            prefix = m.group(1);
            tag = m.group(2);
            namespacesDecl = m.group(3);
        } 
  
        if (StringUtils.isEmpty(namespacesDecl))
        	return new QName(null,tag,prefix != null ? prefix : "");
        
 		p = Pattern.compile("(.*)xmlns"+(prefix != null && prefix.length() > 0 ? (":"+prefix+"[^=]"):("[^:^=]"))+"*=[^\"]*\"([^\"]*)(.*)"); //(.*)xmlns[^:^=]*=[^"]*"([^"]*)(.*)
        m = p.matcher(namespacesDecl);
        
  		if (m.find()) {
        	String nameSpace = m.group(2);
        	qname= new QName(nameSpace,tag,prefix == null ? "" : prefix);            		    		
      	} else {
      		logger.warn("could not find namespace declarion for prefix {}",prefix);
      	}
  		
  		return qname;
  	}
	
	/**
	 * normalize an xml snippest to the default NS.
	 * Assuming a single NS to the whole xml.
	 * Assuming a single NS declaration on root.
	 * Add NS if not exists.
	 */
	public static String normalizeToDefaultNamespace(String xmlSnippet,String requiredNamespaceURI)  {
		if (xmlSnippet == null || requiredNamespaceURI == null)
			return xmlSnippet;
		
		QName root = extractRootNamespace(xmlSnippet);
		
		boolean prefixExists = !StringUtils.isEmpty(root.getPrefix());
		boolean declarationExists = !StringUtils.isEmpty(root.getNamespaceURI());

		//case 1: there is no namespace declaration or prefix on the snippet 
		//		--> add default namespace declaration 
		if (!declarationExists && !prefixExists) {
			String rootElement = "<"+root.getLocalPart()+" xmlns=\""+requiredNamespaceURI+"\">";
			xmlSnippet = rootElement+xmlSnippet.substring(xmlSnippet.indexOf(">",1)+1);
			
		} 

		//case 2: there is no namespace declaration but there is prefix(none default) on the snippet (probably outer declaration)
		//		--> add default namespace declaration
		//			remove the used prefix
		else if (!declarationExists && prefixExists) {
			xmlSnippet = xmlSnippet.replaceAll(root.getPrefix()+":","");
			String rootElement = "<"+root.getLocalPart()+" xmlns=\""+requiredNamespaceURI+"\">";
			xmlSnippet = rootElement+xmlSnippet.substring(xmlSnippet.indexOf(">",1)+1);
		}
		
		//case 3: there is namespace declaration and prefix on the snippet but not the default NS
		//		--> remove the prefix from the declaration
		//			remove the prefix from the tags		
		else if (declarationExists && prefixExists) {
			if (requiredNamespaceURI.equals(root.getNamespaceURI()) && !root.getPrefix().equals("")) {
				xmlSnippet = xmlSnippet.replaceAll(root.getPrefix()+":","");
				xmlSnippet = xmlSnippet.replaceAll(":"+root.getPrefix(),"");	
			}
		} 
		
		return xmlSnippet;		
	}

	public static String readHead(File file,int size) throws IOException {
		FileInputStream fileInput = new FileInputStream(file);
		try{
			byte[] arr = new byte[size];
			int read = 0;
			while ((read+=fileInput.read(arr)) < size);				
			
			return new String(arr);
		}finally{
			try{
				if (fileInput !=null) fileInput.close();
			}catch(Exception e){
        		logger.error("Exception - could not close fileInput-FileInputStream at XmlParsingHelper.readHead");
			}
		}
	}		
	
	/**
	 * return concrete prefix with the semicolon part 
	 */
	public static String makeConcretePrefix(String prefix) {
		if (!"".equals(prefix))
			return prefix + ":";
		return prefix;
	}
}
