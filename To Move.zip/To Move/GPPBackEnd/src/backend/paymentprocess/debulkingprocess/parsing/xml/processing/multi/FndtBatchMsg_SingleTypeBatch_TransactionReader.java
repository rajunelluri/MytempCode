
package backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi;

import static backend.core.module.MessageConstantsInterface.MESSAGE_TYPE_PAIN_001;
import static backend.core.module.MessageConstantsInterface.MESSAGE_TYPE_PAIN_008;
import static backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi.XmlParsingHelper.normalizeToDefaultNamespace;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_BUSINESS_FLOW_TP;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_IS_HISTORY;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.X_CDT_TRNF_INFO;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.X_DIRECT_DBT_TRNF_INFO;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.X_TX_NO;
import static com.fundtech.util.GlobalConstants.BPFILE;
import static com.fundtech.util.GlobalConstants.RTFILE;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.namespace.QName;
import javax.xml.stream.XMLStreamException;

import org.apache.cxf.common.util.StringUtils;
import org.apache.xmlbeans.impl.values.XmlObjectBase;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.businessobject.BOProxies;
import backend.paymentprocess.commons.MessageUtils;
import backend.paymentprocess.debulkingprocess.common.WorkflowType;
import backend.paymentprocess.enrichment.commons.InterfaceSubTypeFlow;
import backend.staticdata.profilehandler.DAOBasicProfileHandler;

import com.fundtech.cache.entities.FileSummary;
import com.fundtech.cache.entities.InterfaceTypes;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.paymentprocess.data.DefaultDeepPDOCloneHandler.CloningContext;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.core.paymentprocess.data.das.DASInterface.XmlLocationType;
import com.fundtech.core.paymentprocess.data.das.PaymentInputSourceType;
import com.fundtech.core.paymentprocess.data.paymenttypes.PaymentType;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.scl.debulkingProcessService.FileIndexDataType;
import com.fundtech.scl.debulkingProcessService.PerformDebulkingMultiRequestDocument;
import com.fundtech.scl.debulkingProcessService.PreStartDataType;
import com.fundtech.util.GlobalConstants;

/**
 * FndtBatchMsg TransactionReader parse the native message parts along with the Fndt parts.
 * 
 * Supports FndtBatchMsg which 
 * 	1. has BatchHeader
 * 	2. contains transactions all from same native type
 * 	3. all native transactions share the same prefix
 * 
 * Parsing Notes:
 * 	Parsing of GrpHdr and PmtInf is done using XML streaming
 * 	Parsing of Transaction is done using native message parser.
 * 	Parsing of Extn is done using RAF   
 * 
 * Namespace Notes:
 * 	When constructing single FndtMsg out of indexed, normalize 
 *  the Namespace to default NS (both on FndtMsg and on native message)
 * 
 * TBD support other Fndt parts beside Extn  
 */
public class FndtBatchMsg_SingleTypeBatch_TransactionReader extends SingleXmlTransactionReader implements XmlTransactionReaderListener {
	private static final Logger logger = LoggerFactory.getLogger(FndtBatchMsg_SingleTypeBatch_TransactionReader.class);
	  private static final DAOBasicProfileHandler m_daoBasicProfileHandle = new DAOBasicProfileHandler();
	private FndtBatchMsg_SingleTypeBatch fndtBatchDataType; //to avoid casting	
	private XmlTransactionReader nativeReader;

	private boolean initialized;

	private long batchIndexOffset=0;

	public static final String FNDT_MSG_START = "<FndtMsg xmlns=\"http://fundtech.com/SCL/CommonTypes\"><Msg>";
	public static final String FNDT_MSG_PMNT_START = "<Pmnt>";
	public static final String FNDT_MSG_PMNT_END = "</Pmnt>";
	public static final String FNDT_MSG_END = "</Msg></FndtMsg>";

	public FndtBatchMsg_SingleTypeBatch_TransactionReader() {
		setM_fileType(RTFILE);
	}
	
	public FndtBatchMsg_SingleTypeBatch_TransactionReader(FndtBatchMsg_SingleTypeBatch fileDataType) {
		setFileMessageTypeData(fileDataType);
		setM_fileType(RTFILE);
	}
	
	public FndtBatchMsg_SingleTypeBatch_TransactionReader(File file,int chunkSize,FileMessageTypeData fileMessageTypeData) {
		try {
			setFile(file);
			setChunkSize(chunkSize);
			initFileRelatedMembers(file);
			setFileMessageTypeData(fileMessageTypeData);
			setPmtInfCount(getPmtInfCount() + 1);
			setM_fileType(RTFILE);
		} catch (Exception e) {
			throw new RuntimeException(e);
		} 		
	}

	/**
	 * @param file
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	private void initFileRelatedMembers(File file)
			throws FileNotFoundException, IOException {
		setRandomeFile(new RandomAccessFile(file, "r"));
		setFileSize(getRandomeFile().length()) ;
		setUtils(new RandomAccessFileUtils(getFile()));
	}

	public FndtBatchMsg_SingleTypeBatch_TransactionReader(File file,RandomAccessFile accessFile, int chunkSize,FileMessageTypeData fileMessageTypeData) {
		super(file,accessFile,chunkSize,fileMessageTypeData);
	}
	
	
	@Override
	public void init() throws IOException,XMLStreamException {
		if (initialized){
			return;
		}
		
		initialized = true;
		setNewBulk(true);
		setFileSource(Admin.getContextAdmin().getIncomingInterfaceType().getPaymentSource());
		parseFileHead();
		
		innerInitializtion();
	}
	
	public void init(InputStream fileInputStream) throws IOException,XMLStreamException {
		if (initialized&&fileInputStream==null){
			return;
		}
		
		initialized = true;
		setNewBulk(true);
		
		parseFileHead(fileInputStream);
		initFileRelatedMembers(getFile());
		innerInitializtion(true);
	}
	
	@Override
	public void initHeader(){
		String header = nativeReader.getHeader();
		
		// Grab CreDtTm from the original file
		//
		COMPILE_PATTERN = "<CreDtTm>(.*)</CreDtTm>|<NbOfTxs>(.*)</NbOfTxs>|<CtrlSum>(.*)</CtrlSum>"; 
		setPattern(Pattern.compile(COMPILE_PATTERN));
		Matcher m = getPattern().matcher(header);
		
		while (m.find()){
			if (m.group(1) != null){
				setBulkCreDtTm((String)m.group(1));
			}
			if (m.group(2) != null){
				setBulkNumOfTx(Long.parseLong(m.group(2)));
			}
			if (m.group(3) != null){
				setBulkCtrlSum(m.group(3).isEmpty()? 0 : Long.parseLong(m.group(3)));
			}       
        }		
	}

	/**
	 * @throws IOException
	 */
	private void innerInitializtion() throws IOException {
		innerInitializtion(false);
	}
	
	private void innerInitializtion(boolean skipNewNativeReader) throws IOException {
		configureNativeReader(skipNewNativeReader);
		
		//TBD copied from pain parser, is that required?!		
		INTERFACE_TYPE = InterfaceTypes.INTERFACE_TYPE_MASSPMNTS;
		INTERFACE_SUB_TYPE = InterfaceTypes.INTERFACE_SUB_TYPE_DEB;
		setSinglePayment(false);

		nativeReader.setHeader(getUtils().getFileSectionFromIndexes(getGlobalHeaderStartTagIndex(), getGlobalHeaderEndTagIndex()));
		nativeReader.setCompiledPattern();
		nativeReader.initHeader();
		initHeader();
	}


	/**
	 * basic parsing from the file head.
	 * Parse the of native GrpHdr out of fndt BatchHeader
	 * Parse the of native PmtInf out of fndt PmntHeader 
	 */
	private void parseFileHead() throws IOException,XMLStreamException {
		FileInputStream fileInputStream = null;
		try{
			fileInputStream=new FileInputStream(getFile());
			parseFileHead(fileInputStream);
		}
		finally{
			try
			{
				if (fileInputStream !=null) fileInputStream.close();
			}catch(Exception e){
        		logger.error("Exception - could not close FileInputStream-fileInputStream at FndtBatchMsg_MultiTypeBatch_TransactionReader.parseFileHead()");
			}
		}
		
	}
		
	private void parseFileHead(InputStream fileInputStream) throws IOException,XMLStreamException {
		try {
			fileInputStream.reset();
		} catch (Exception e) {
			logger.debug("No skip. File in begining");
		}
		FndtBatchMessageStreamBasedParser parser = new FndtBatchMessageStreamBasedParser(fileInputStream);
		FndtBatchMsgParseResult result = parser.parseHead(this.batchIndexOffset);
		
		setGlobalHeaderStartTagIndex(result.nativePayloadGrpHdrStartTagLocation);
		setGlobalHeaderEndTagIndex(result.nativePayloadGrpHdrEndTagLocation);
		setPrePmtInfoStartIndex(result.nativePayloadPmtInfStartTagLocation);
		setPrePmtInfoEndIndex(result.nativePayloadPmtInfEndTagLocation);
		
		//transform parse information to data type
		fndtBatchDataType.init(result.nativeMessageRootQName,result.fndtMsgRootQName,result.nativeHeaderRootQName);		
	}
	
	public void configureNativeReader() {		
		configureNativeReader(false);
	}
	
	public void configureNativeReader(boolean noNewReader) {
		try {
			if(!noNewReader){
				nativeReader = (XmlTransactionReader)fndtBatchDataType.getNativeMessageDataType().getReader();//getReaderWithoutInit(file,chun);
				nativeReader.setByteBuffer(new ByteArrayListOptimized());// getByteBuffer());
			}
			
			nativeReader.setFndtBatchMsgContext(true);
			nativeReader.setListener(this);
			
			nativeReader.setFile(getFile());
			nativeReader.setChunkSize(getChunkSize());
			nativeReader.setRandomeFile(getRandomeFile());
			nativeReader.setFileSize(getFileSize()) ;			
			nativeReader.setUtils(getUtils());
			nativeReader.setCurrentChunk(PerformDebulkingMultiRequestDocument.Factory.newInstance());
			nativeReader.getCurrentChunk().addNewPerformDebulkingMultiRequest();
			nativeReader.setFileMessageTypeData(fndtBatchDataType.getNativeMessageDataType());
			nativeReader.setNamespacePrefix(fndtBatchDataType.getNativePaymentPrefix());
			nativeReader.setHeaderNamespacePrefix(fndtBatchDataType.getNativePaymentHeaderPrefix());
			//copy parsed index
			nativeReader.setGlobalHeaderStartTagIndex(getGlobalHeaderStartTagIndex());
			nativeReader.setGlobalHeaderEndTagIndex(getGlobalHeaderEndTagIndex());
			nativeReader.setPrePmtInfoStartIndex(getPrePmtInfoStartIndex());
			nativeReader.setPrePmtInfoEndIndex(getPrePmtInfoEndIndex());
			nativeReader.initPreStartDataType();
			nativeReader.setNumOfTrxActuallyReadFromFile(0);
		} catch (Exception e) {
			logger.error("configureNativeReader failed",e);
		}		
	}

	@Override
	public void setFileMessageTypeData(FileMessageTypeData fileMessageTypeData) {
		super.setFileMessageTypeData(fileMessageTypeData);
		this.fndtBatchDataType = (FndtBatchMsg_SingleTypeBatch)fileMessageTypeData;
	}
	
	
	//
	// BODebulkFile related
	//
	
	@Override
	public void onTransactionEnded(XmlTransactionReaderBase readerBase,FileIndexDataType txInfo) {
		txInfo.setPaymentType(fndtBatchDataType.getPaymentTypeName());
		addExtenstionIndexes(readerBase,txInfo);
	}
	
	private void addExtenstionIndexes(XmlTransactionReaderBase readerBase,FileIndexDataType txInfo) {		
		try {			
			//using of ByteBuffer doesn't works right. Apply this workaround:
			String filePart = getUtils().getFileSectionFromIndexes(txInfo.getTransactionEndTag(), txInfo.getTransactionEndTag()+1024*8);
			int extnStartIndex = filePart.indexOf(fndtBatchDataType.getExtnStartTag());
			int extnEndIndex = filePart.indexOf(fndtBatchDataType.getExtnEndTag());			
			
			txInfo.setPaymentFndtExtnStartTag(txInfo.getTransactionEndTag()+extnStartIndex );
			txInfo.setPaymentFndtExtnEndTag(txInfo.getTransactionEndTag()+extnEndIndex+fndtBatchDataType.getExtnEndTag().length());		
		} catch (Exception e) {
			logger.error("fail adding Extn",e);
		}
	}
	
	
	public long getBatchIndexOffset() {
		return batchIndexOffset;
	}

	public void setBatchIndexOffset(long batchIndexOffset) {
		this.batchIndexOffset = batchIndexOffset;
	}


	
	
	//
	// BODebulkProcessing related
	//
	
		public List<PDO> getPDOsFromChunk( PerformDebulkingMultiRequestDocument doc
									  ,String chunkId
									  ,String internalFileID
									  ,final FileSummary fileSummary
									  ,final Map[] sharedPDOContextHolder) throws Throwable {
	  	FileIndexDataType[] transactions = doc.getPerformDebulkingMultiRequest().getFileIndexDataTypeListArray();
	  	
	  	logger.debug("getPDOsFromChunk, internal file ID: {}, chunk ID: {} , number of TX on chunk {}",
	  			new Object[]{internalFileID,internalFileID,transactions.length});
	    
	  	String officeCurrency = CacheKeys.banksKey.getSingle(fileSummary.getOffice()).getCurrency();	    
	    
	    RandomAccessFileUtils utils = getFileUtils(doc);
	    List<PDO> pdoList = null;
	    
	    try {
	    	String prePmntInf = getPrePaymenInf(doc,utils);
	    	String pmntInf = getPaymenInf(doc,utils);
	    	
			String templateMessage = contructTemplateMessae(prePmntInf,pmntInf);

			CloningContext[] context = new CloningContext[1];
		    
			PDO templatePDO = createTemplatePDO( templateMessage
		    									,sharedPDOContextHolder
		    									,officeCurrency
		    									,internalFileID
		    									,chunkId
		    									,fileSummary
		    									,fileSummary.getMsgType()
		    									,fileSummary.getInitgPtyCustCode()
		    									,context);
		       
		    pdoList = createIndividualPayments( transactions
		    								   ,templatePDO
		    								   ,prePmntInf
		    								   ,pmntInf		    								   
		    								   ,context		    								   
		    								   ,chunkId
		    								   ,utils);

	    } catch (Exception e) {
	    	logger.error("",e);
	   	    	
	    	
	    } finally {
	    	 utils.dispose();

	    }

	    return pdoList;
	}
		
    private List<PDO> createIndividualPayments( FileIndexDataType[] transactions
    										   ,PDO templatePDO
    										   ,String prePmntInfo
    										   ,String pmtInfo    										   
    										   ,CloningContext[] context    										   
    										   ,Object chunkId
    										   ,RandomAccessFileUtils utils) throws Throwable {
    	final List groups = CacheKeys.LogicalFieldsXPathGroupsKey.get(null, templatePDO.getPaymentType("XML_MSG"), "XML_MSG");

    	//if pain001 or pain008
    	boolean isDD = templatePDO.getNSetMsgTypes().getMsgClass().indexOf("DD") > -1;
	    String trnsInfoLogicalField = isDD ? X_DIRECT_DBT_TRNF_INFO : X_CDT_TRNF_INFO;
	    
    	List<PDO> pdoList = new ArrayList<PDO>();
    	
  	    for (int i=0;i<transactions.length;i++) {
  	    	String fndtExtn = getTransactionExtn(transactions[i],utils);
  	    	
  	    	String concreteMessage = contructConcreteMessae(transactions[i],prePmntInfo,pmtInfo,fndtExtn,utils);
  	    	
  	    	logger.debug("creating individul payment {}({}) (by cloning template) ..",i+1,transactions.length);
  	    	try{
  	    	PDO pdo = PaymentDataFactory.clonePDO(context[0], concreteMessage, trnsInfoLogicalField, true, groups);
     	 	addExtnXml(pdo,fndtExtn);
   	    	logger.debug("created individul PDO - MID: {}, Status: {}, Chunk ID: {}, PDO ID: {}" 
  		    		,new Object[]{  pdo.getMID(), pdo.getString(PDOConstantFieldsInterface.P_MSG_STS), chunkId, pdo});
  	    	
  	    	pdo.set(P_IS_HISTORY, WorkflowType.MP_PARTITION);
  	    	pdo.set(X_TX_NO, 1+"");
  	    	pdo.severConjoinedLinks();
  	    	pdoList.add(pdo);
  	    	}catch(Exception e){
  	    		logger.debug(e.getMessage());
 	    		String internalFileId=templatePDO.getString(PDOConstantFieldsInterface.P_IN_INTERNAL_FILEID);
		    	int iSessionId= m_daoBasicProfileHandle.getSessionId();
  				m_daoBasicProfileHandle.addInterfaceErrorLog("SYSTEM", iSessionId, "Feeder", "ERROR","Error creating Individual for internalFileId: "+internalFileId );
  	    		
  	    	}
		}//for

  	    return pdoList;
	}
    
    /**
	 *
	  <FndtMsg>											--> (a) manually added with default NS
		<Msg>											--> (a) 
			<Pmnt>										--> (a) 
				<native root element>					--> (b) manually added with default NS 
					<native root child element>			--> (b) 
						<native GrpHdr></native GrpHdr>	----> (c) use indexes prePmtInfStartTag-prePmtInfEndTag (GrpHdr within the BatchHeader) 
						<native PmtInf>					----> (d) use indexes paymentInfoStartTag-paymentInfoEndTag  (PmtInf within the PaymentHeader)							
						</native PmtInf>				--> (f) manually added with default NS 
					</native root child element>		--> (f)
				</native root element>					--> (f)
			</Pmnt>										--> (g) manually added with default NS
		</Msg>											--> (i) manually added with default NS
	</FndtMsg>											--> (i)


		(a) hard coded in the FndtBatchMsg parser			
		(c) normalizion required only if NS declartion is outer
		(d) after normalizing to default NS (end tag must share same prefix)(normalizing once per chunk)
		(e) after normalizing to default NS
		(f) native payment metadata, getXmlClosingTags()
		(h) after normalizing to default NS
		(i) hard coded in the FndtBatchMsg parser
	 */
   private String contructTemplateMessae(String prePmntInf,String pmntInf) {
   	StringBuilder message = new StringBuilder();
		
   	message.append(FNDT_MSG_START)
   		   .append(FNDT_MSG_PMNT_START)
   		   .append(getNativeMessageXmlStarting())
   		   .append(prePmntInf)
   		   .append(pmntInf)
   		   .append(getNativeMessageXmlEnding())    		   
   		   .append(FNDT_MSG_PMNT_END)
   		   .append(FNDT_MSG_END);
   	
		return message.toString();
	}
   
	/**
	 *
	  <FndtMsg>											--> (a) manually added with default NS
		<Msg>											--> (a) 
			<Pmnt>										--> (a) 
				<native root element>					--> (b) manually added with default NS 
					<native root child element>			--> (b) 
						<native GrpHdr></native GrpHdr>	----> (c) use indexes prePmtInfStartTag-prePmtInfEndTag (GrpHdr within the BatchHeader) 
						<native PmtInf>					----> (d) use indexes paymentInfoStartTag-paymentInfoEndTag  (PmtInf within the PaymentHeader)
							<native Tx>					----> (e) use indexes transactionStartTag-transactionEndTag 
							</native Tx>				----> (e)
						</native PmtInf>				--> (f) manually added with default NS 
					</native root child element>		--> (f)
				</native root element>					--> (f)
			</Pmnt>										--> (g) manually added with default NS
			<Extn>										----> (h) use indexes transactionExtnStartTag-transactionExtnEndTag 
			</Extn>										----> (h)
		</Msg>											--> (i) manually added with default NS
	</FndtMsg>											--> (i)


		(a) hard coded in the FndtBatchMsg parser			
		(c) normalizion required only if NS declartion is outer
		(d) after normalizing to default NS (end tag must share same prefix)(normalizing once per chunk)
		(e) after normalizing to default NS
		(f) native payment metadata, getXmlClosingTags()
		(h) after normalizing to default NS
		(i) hard coded in the FndtBatchMsg parser
	 */
    private String contructConcreteMessae( FileIndexDataType transaction    									  
    									  ,String prePmntInf
    									  ,String pmntInf
    									  ,String fndtExtn
    									  ,RandomAccessFileUtils utils) {
    	StringBuilder message = new StringBuilder();
		
    	message.append(FNDT_MSG_START)
    		   .append(FNDT_MSG_PMNT_START)
    		   .append(getNativeMessageXmlStarting())
    		   .append(prePmntInf)
    		   .append(pmntInf)
    		   .append(getTransaction(transaction,utils))
    		   .append(getNativeMessageXmlEnding())
    		   .append(FNDT_MSG_PMNT_END)
    		   .append(fndtExtn)//getTransactionExtn(transaction,utils))    		   
    		   .append(FNDT_MSG_END);
    	
//    	message.append(getNativeMessageXmlStarting())
//		   	   .append(prePmntInf)
//		   	   .append(pmntInf)
//		   	   .append(getTransaction(transaction,utils))
//		   	   .append(getNativeMessageXmlEnding());
		   
    	
		return message.toString();
	}


	private PDO createTemplatePDO( String templateMessage
								  ,Map[] sharedPDOContextHolder
								  ,String officeCurrency
								  ,String internalFileID
								  ,String chunkId
								  ,FileSummary fileSummary
								  ,String msgType
								  ,String sFileSummary_INITG_PTY_CUST_CODE
								  ,CloningContext[] context) throws Exception {
		logger.debug("creating template PDO");
		String sBusinessFlowType = InterfaceSubTypeFlow.getFlowType(fileSummary.getPlFileType());
		PDO templatePDO = PaymentDataFactory.newPDO(templateMessage,true/*bTransient*/, true, true/*bConjoinedMode*/, null, GlobalConstants.BP.equals(sBusinessFlowType));
		logger.debug("template PDO is: {}",templatePDO);
		boolean isBPFlow = BPFILE.equals(fileSummary.getPlFileType());
		Admin.enrichMDC("T");
	    sharedPDOContextHolder[0] = templatePDO.getSharedContext() ;

	    templatePDO.set(PDOConstantFieldsInterface.X_STTLM_CCY, officeCurrency);
	    templatePDO.set(PDOConstantFieldsInterface.X_STTLM_AMT, new BigDecimal(0));
	    templatePDO.set(PDOConstantFieldsInterface.P_IN_INTERNAL_FILEID, internalFileID);
	    templatePDO.set("D_DEBULKING_TEMPLATE_PDO",isBPFlow ? "" : "true");
	    //templatePDO.getNSetIncomingFileSummary();
	    templatePDO.setIncomingFileSummary(fileSummary) ;
	    logger.debug("executing basic processing on template individual PDO before use it for cloning");
	    Feedback feedback = BOProxies.m_processFlowsLocal.performLowValuePreProcessingPaymentSubFlow(Admin.getContextAdmin(), templatePDO.getMID());
	    context[0]= new CloningContext(templatePDO,null/*sCreationMID*/,null/*cloneHandler*/,sharedPDOContextHolder[0]);

	    templatePDO.set(PDOConstantFieldsInterface.P_RAW_MSG_TYPE, msgType);
	    templatePDO.set(PDOConstantFieldsInterface.P_ORG_INITG_PTY_CUST_CD, sFileSummary_INITG_PTY_CUST_CODE);
	    // Sets chunk ID.
	    templatePDO.set(PDOConstantFieldsInterface.P_CHUNK_ID, chunkId);
	    
	    templatePDO.set(P_BUSINESS_FLOW_TP, sBusinessFlowType);
	    templatePDO.set(PDOConstantFieldsInterface.P_PMNT_SRC, fileSummary.getFileSource());

	    Admin.clearMDC();
	    templatePDO.set("D_DEBULKING_TEMPLATE_PDO","");
	    return templatePDO;
	}
	
	/**
     * manually add the extension to the PDO since it is not supported via PaymentDataFactory.clonePDO()
     * TBD support via clone
     */
    private void addExtnXml(PDO pdo, String fndtExtn) throws Exception {
    	XmlObjectBase fndtExtnXbean = PaymentInputSourceType.toXbean(fndtExtn,null,XmlLocationType.XML_MSG_EXTN,true/* bToDocumentFirstChild */);
    	MessageUtils.setExtn(pdo, fndtExtnXbean);    		    		
	}

    
	private String getNativeMessageXmlEnding() {
		fndtBatchDataType.getNativeMessageDataType().formatTags(""); //default NS
		return fndtBatchDataType.getNativeMessageDataType().getXmlClosingTags();
	}

	private String getNativeMessageXmlStarting() {
		return fndtBatchDataType.getNativeMessageDataType().getXmlStartingTags(); //would be on default NS	
	}
	
	private String getPaymenInf(PerformDebulkingMultiRequestDocument doc,RandomAccessFileUtils utils) {
		FileIndexDataType transaction = doc.getPerformDebulkingMultiRequest().getFileIndexDataTypeListArray()[0];		
	    String pmntinf = utils.getFileSectionFromIndexes(transaction.getPaymentInfoStartTag(),transaction.getPaymentInfoEndTag());
	    return normalizeToDefaultNamespace(pmntinf,fndtBatchDataType.getNativeMessageDataType().getPaymentType().getSchemaNamespace());
	}

	private String getPrePaymenInf(PerformDebulkingMultiRequestDocument doc,RandomAccessFileUtils utils) {
		PreStartDataType preStartDataType = doc.getPerformDebulkingMultiRequest().getPreStartDataListArray()[0];	    
	    String prePaymentInf = utils.getFileSectionFromIndexes(preStartDataType.getPrePmtInfStartTag(),preStartDataType.getPrePmtInfEndTag());
	    return normalizeToDefaultNamespace(prePaymentInf,fndtBatchDataType.getNativeMessageDataType().getPaymentType().getSchemaNamespace());
	}
	
	private String getTransactionExtn(FileIndexDataType messageIndexes,RandomAccessFileUtils utils) {
		logger.debug("FndtExtnStartTag is: {} FndtExtnEndTag is: {} ",messageIndexes.getPaymentFndtExtnStartTag(),messageIndexes.getPaymentFndtExtnEndTag());
		String extn = utils.getFileSectionFromIndexes(messageIndexes.getPaymentFndtExtnStartTag(),messageIndexes.getPaymentFndtExtnEndTag());
		return normalizeToDefaultNamespace(extn,fndtBatchDataType.getTypeIdentifier());
	}

	private Object getTransaction(FileIndexDataType messageIndexes,RandomAccessFileUtils utils) {
		String tx = utils.getFileSectionFromIndexes(messageIndexes.getTransactionStartTag(),messageIndexes.getTransactionEndTag());
		return normalizeToDefaultNamespace(tx,fndtBatchDataType.getNativeMessageDataType().getPaymentType().getSchemaNamespace());
	}
	
	//
	// relation with native reader
	//
	
	@Override
	public boolean hasNext() {
		try {
			init();
		} catch (Exception e) {
			throw new BulkFileParsingExecption(e);
		}
		
		if (nativeReader.getNumOfTrxActuallyReadFromFile() == 0){
			setNewBulk(true);
		}else{
			setNewBulk(false);
		}
		
		return nativeReader.hasNext();
	}
	
	@Override
	public Object next() {
		return nativeReader.next();						
	}
	
	@Override
	protected boolean readTransactionsOfChunkSize() {
		//this method wouldn't be read. hasNext is via native reader
		return false;
	}

	@Override
	public String getXmlofChunk(Object chunk) {
		return nativeReader.getXmlofChunk(chunk);
	}

	@Override
	public int getRecCountInChunk(Object chunk) {
		return nativeReader.getRecCountInChunk(chunk);
	}
	
	@Override
	public String getMsgId() {
		if (StringUtils.isEmpty(super.getMsgId()) && nativeReader != null)
			return nativeReader.getMsgId();
		
		return super.getMsgId();
	}

	@Override
	public int getPmtInfCount() {
		if (super.getPmtInfCount() == 0 && nativeReader != null)
			return nativeReader.getPmtInfCount();
		
		return super.getPmtInfCount();
	}

	@Override
	public int getTrnsCount() {		
		if (super.getTrnsCount() == 0 && nativeReader != null)
			return nativeReader.getTrnsCount();
		
		return super.getTrnsCount();
	}

	@Override
	public String getCtrlSum() {
		if (StringUtils.isEmpty(super.getCtrlSum()) && nativeReader != null)
			return nativeReader.getCtrlSum();
		
		return super.getCtrlSum();
	}

	@Override
	public String getPartyName() {
		if (StringUtils.isEmpty(super.getPartyName()) && nativeReader != null)
			return nativeReader.getPartyName();
		
		return super.getPartyName();
	}

	@Override
	public String getInitiatingPartyCustCode() {
		if (StringUtils.isEmpty(super.getInitiatingPartyCustCode()) && nativeReader != null)
			return nativeReader.getInitiatingPartyCustCode();
		
		return super.getInitiatingPartyCustCode();
	}

	@Override
	public void onBulkEnd(long FndtBatchTagLastIndex,long transactionEndTagIndex,long newTxStartIndex) {
		if(listener!=null)
			listener.onBulkEnd(FndtBatchTagLastIndex,transactionEndTagIndex,newTxStartIndex);
	}

	
	public String getBulkType(){
		PaymentType payment = PaymentType.valueOf(new QName(fndtBatchDataType.getNativeHeaderRoot().getNamespaceURI(), "Document"));

		if (payment.m_sPaymentType.equals(MESSAGE_TYPE_PAIN_001)){
			return MESSAGE_TYPE_PAIN_001;
		}
		if (payment.m_sPaymentType.equals(MESSAGE_TYPE_PAIN_008)){
			return MESSAGE_TYPE_PAIN_008;
		}
		
		return null;
	}
	@Override
	public boolean isBulkEnd() {
		if(listener!=null)
			return listener.isBulkEnd();
		
		return false;
	}

	@Override
	public void markBulkFullReject() {
		// TODO Auto-generated method stub
		
	}
	
}



/*private void addExtenstionIndexes(XmlTransactionReaderBase readerBase,FileIndexDataType txInfo) {
try {			
	XmlTransactionReader reader = (XmlTransactionReader)readerBase;			
	int extnStartIndex = reader.findAndReadTillNearestTagInChunk(fndtBatchDataType.getExtnStartTagBytes(),(int)txInfo.getTransactionEndTag());
	int extnEndIndex = reader.findAndReadTillNearestTagInChunk(fndtBatchDataType.getExtnEndTagBytes(),extnStartIndex+1) + fndtBatchDataType.getExtnEndTagBytes().length;
	
	txInfo.setPaymentFndtExtnStartTag(extnStartIndex + reader.getTotalDeleted());
	txInfo.setPaymentFndtExtnEndTag(extnEndIndex + reader.getTotalDeleted());
	
	// delete the buffer untill the end of the transcation
	//reader.getByteBuffer().removeRangeFromBeginning(extnEndIndex);
	//reader.setTotalDeleted(reader.getTotalDeleted() + extnEndIndex);
} catch (IOException e) {
	logger.error("fail adding Extn",e);
}
}*/
