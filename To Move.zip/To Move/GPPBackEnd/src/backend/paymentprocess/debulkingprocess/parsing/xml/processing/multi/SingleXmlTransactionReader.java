package backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;

import backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi.ByteArrayListOptimized.FindWordResponse;

import com.fundtech.scl.debulkingProcessService.PerformDebulkingMultiRequestDocument;
import com.fundtech.scl.debulkingProcessService.PerformDebulkingMultiRequestType;

/**
 * SingleXmlTransactionReader for single message types.
 * It will read and index the transactions for single message types.
 * 
 * @see XmlTransactionReader
 * 
 * @author haimv
 * @author dmitryp
 */
public abstract class SingleXmlTransactionReader extends XmlTransactionReader{

	public SingleXmlTransactionReader(){};
	//Ctor
	public SingleXmlTransactionReader(File file,int chunkSize,FileMessageTypeData fileMessageTypeData)
	{
		super(file,chunkSize,fileMessageTypeData);
	}
	
	public SingleXmlTransactionReader(File file,RandomAccessFile raf, int chunkSize,FileMessageTypeData fileMessageTypeData)
	{
		super(file,raf , chunkSize,fileMessageTypeData);
	}
	
	@Override
	protected void readPreTransactionData()
	{

		// </%sDocument>
		//String postTagsEnd = m_fileMessageTypeData.getDocumentElementEndTag();
		//m_postTagsEndIndex = m_byteBuffer.indexOf(postTagsEnd.getBytes()) + postTagsEnd.getBytes().length + this.m_totalDeleted;
	}
	
	

	
	@Override
	protected void readDocumentStartData()
	{
		try {
//			System.out.println( 
//					new String(new String(getByteBuffer().getArray()))
//					);	
		setSize(getFileSize() - getByteCount() > BUFFER_SIZE ? BUFFER_SIZE
				: getFileSize() - getByteCount());
		
		getUtils().readToByteArrayListEnd(this.getByteBuffer(), (int)getSize());
		setByteCount(getByteCount() + getSize());
		//GrpHdr
		String docPreStartTag = getFileMessageTypeData().getDocumentElementStartTag();
		setDocPreStartTagIndex(getByteBuffer().indexOf(docPreStartTag.getBytes()) + this.getTotalDeleted());
//		//m_docPreStartTagIndex = findAndReadTillNearestTagInChunk(docPreStartTag.getBytes(),0) + this.m_totalDeleted;
//
//		if (getDocPreStartTagIndex() == -1) {
//			setDocPreStartTagIndex(this.getTotalDeleted());
//		}
		
		//<%sGrpHdr>
		String globalHeaderStartTag = getFileMessageTypeData().getGrpHdrStartTag();
		setGlobalHeaderStartTagIndex(getByteBuffer().indexOf(globalHeaderStartTag.getBytes())  + this.getTotalDeleted() );
		//m_globalHeaderStartTagIndex = findAndReadTillNearestTagInChunk(globalHeaderStartTag.getBytes(),0) + this.m_totalDeleted;


		//</%sGrpHdr>
		String globalHeaderEndTag = getFileMessageTypeData().getGrpHdrEndTag();
		setGlobalHeaderEndTagIndex(getByteBuffer().indexOf(globalHeaderEndTag.getBytes())    + globalHeaderEndTag.getBytes().length +  this.getTotalDeleted());
		//m_globalHeaderEndTagIndex =findAndReadTillNearestTagInChunk(globalHeaderEndTag.getBytes(),0) + globalHeaderEndTag.getBytes().length + this.m_totalDeleted;

				//Cut from <Document till <GrpHdr>

		
//		setDocPreEndTagIndex(getByteBuffer().indexOf(docPreEndTag.getBytes()) +  /* this.getByteBuffer().getStart() */   this.getTotalDeleted());
		//m_docPreEndTagIndex = findAndReadTillNearestTagInChunk(docPreEndTag.getBytes(),0)+ this.m_totalDeleted;

		// THIS IS A HACK! I CURRENTLY THIS CODE CAN'T HANDLE "REAL" MULTI FORMAT
//		if (true) {
//			setDocPreStartTagIndex(this.getTotalDeleted());
//			// we start from <GrpHdr and go back till we find xmlns
//			long idx = this.getTotalDeleted() +  getByteBuffer().indexOf("xmlns".getBytes() , -100);
//			setDocPreStartTagIndex(this.getTotalDeleted() +  idx);
//			setDocPreEndTagIndex(this.getTotalDeleted() -1 );
//		}
		
				//<PmtInf>
		String prePmtInfoStart = getFileMessageTypeData().getPaymentInfoElementStartTag();
		setPrePmtInfoStartIndex(getByteBuffer().indexOf(prePmtInfoStart.getBytes()) +  /* this.getByteBuffer().getStart() */ +  this.getTotalDeleted());
		//m_prePmtInfoStartIndex = findAndReadTillNearestTagInChunk(prePmtInfoStart.getBytes(),0) + this.m_totalDeleted;

		
		
		
		// PACS_03_TRANSACTION_START_TAG
		String prePmtInfoEnd = getFileMessageTypeData().getPrePmtInfEnd();
		setPrePmtInfoEndIndex(getByteBuffer().indexOf(prePmtInfoEnd.getBytes()) + /* this.getByteBuffer().getStart() */  + this.getTotalDeleted());
		//m_prePmtInfoEndIndex = findAndReadTillNearestTagInChunk(SprePmtInfoEnd.getBytes(),0)+ this.m_totalDeleted;

		
		
		
		
		

		
		//PRE section
		//Implemented in each message type  :  </%sGrpHdr>

		


		
		setPmtInfCount(getPmtInfCount() + 1);
		
		//POST section
		// </%sPmtInf>
		String postTagsStart = getFileMessageTypeData().getPaymentInfoElementEndTag();
		setPostTagsStartIndex(getByteBuffer().indexOf(postTagsStart.getBytes()) +  this.getTotalDeleted());
		//m_postTagsStartIndex = findAndReadTillNearestTagInChunk(postTagsStart.getBytes(),0) + this.m_totalDeleted;

		}
		catch (Exception e)
		{
			
		}

		
	}//EOM readPreTransactionData
	
	
	
	protected int findAndReadTillNearestTagInChunk(byte[] tag, int startIndex) throws IOException {
		// check if there is occurrence of the tag in the current chunk.
		int index = getByteBuffer().indexOf(tag, startIndex);    
		while (index == -1) {
			if (getByteCount() >= getFileSize())
				break;
			int temp = getByteBuffer().getSize();
			// Read next chunk
			setSize(getFileSize() - getByteCount() > BUFFER_SIZE ? BUFFER_SIZE
					: getFileSize() - getByteCount());
			startIndex = getByteBuffer().getSize();
			getUtils().readToByteArrayListEnd(this.getByteBuffer(), (int)getSize());
			setByteCount(getByteCount() + getSize());
			// set startIndex to the last checked index to avoid duplicate search
			
			index = getByteBuffer().indexOf(tag, temp - tag.length);

		}
		return index;
	}
	
	protected FindWordResponse findAndReadTillNearestTagsInChunk(int startIndex, ArrayList<byte[]> tags , int bufferSize) 
			throws IOException {
		FindWordResponse response= getByteBuffer()
				.indexOfFirstAppearingWord(tags, startIndex);
			while (response.getLocation()== -1) {
				if (getByteCount() >= getFileSize())
					break;
				int temp = getByteBuffer().getSize();
				// Read next chunk
				setSize(getFileSize() - getByteCount() > bufferSize ? bufferSize
						: getFileSize() - getByteCount());
				//setByteCount(getByteCount() + getSize());
				// set startIndex to the last checked index to avoid duplicate search
				startIndex = getByteBuffer().getSize();
				getUtils().getM_raf().seek(getByteCount());
				getUtils().readToByteArrayListEnd(this.getByteBuffer(), (int)getSize());
				setByteCount(getByteCount() + getSize());
				//m_totalDeleted += m_byteBuffer.size();
				response = getByteBuffer().indexOfFirstAppearingWord(tags, temp);
			
			}
				return response;
	}
	
	@Override
	public void setAdditionalDocumentData(Object request, String chunkId, String status,String internalFileId, String path, String workFlow, String bulkId) {
	 	PerformDebulkingMultiRequestDocument doc = (PerformDebulkingMultiRequestDocument)request;
		PerformDebulkingMultiRequestType debulkingMultyRequest = doc.getPerformDebulkingMultiRequest();
		debulkingMultyRequest.setChunkId(chunkId);
	    debulkingMultyRequest.setStatus(status);
	    debulkingMultyRequest.setInternalFileId(internalFileId);
	    debulkingMultyRequest.setPath(path);
	    debulkingMultyRequest.setWorkflow(workFlow);
	    debulkingMultyRequest.setBulkId(bulkId);
	}
	
}//EOC SingleXmlTransactionReader