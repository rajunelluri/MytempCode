package backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi;

import java.io.File;
import java.io.IOException;

import javax.xml.stream.XMLStreamException;

import com.fundtech.scl.debulkingProcessService.PerformDebulkingMultiRequestDocument;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * IterableXmlTransactionReader
 * 
 * @author dmitryp
 */

public class IterableXmlTransactionReader implements Iterable<PerformDebulkingMultiRequestDocument> {
	private static final Logger logger = LoggerFactory.getLogger(IterableXmlTransactionReader.class);
	
	private File m_file;
	private int m_chunkSize;
	
	public IterableXmlTransactionReader(File file,int chunkSize)  {
		this.m_file = file;
		this.m_chunkSize = chunkSize;
		logger.debug("file: {}, chunk size: {}",file,chunkSize);
	}
	
	@Override
	public XmlTransactionReaderBase iterator() {
		XmlTransactionReaderBase iter = null;
		
		iter = XmlTransactionReader.createXmlTransactionReader(m_file,m_chunkSize);
		
		return iter;
		
	}//EOM iterator

	
}//EOC IterableXmlTransactionReader

