//package backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi;
//
//import java.io.File;
//import java.io.IOException;
//import java.util.regex.Matcher;
//import java.util.regex.Pattern;
//
//import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
//
///**
// * @author liron.aravot
// *
// */
//public class SepaCfvTransactionReader extends XmlTransactionReader {
//
//	private final int HEADER_MAX_LENGTH = 3000;
//	public SepaCfvTransactionReader(File file,int chunkSize,FileMessageTypeData fileMessageTypeData)
//	{
//		super(file,chunkSize, fileMessageTypeData);
//	}
//
//
//	@Override
//	public void init() throws IOException {
//		initHeader ();
//	}
//
//	@Override
//	protected void readPreTransactionData() {
//		// TODO
//
//	}
//
//
//
//	@Override
//	public void setAdditionalDocumentData(String chunkId, String status,
//			String internalFileId, String path) {
//		// TODO
//
//	}
//
//
//	@Override
//	public void initHeader ()
//	{
//		String origFileRef;
//		String fileRjctRsn;
//		m_header = m_utils.getFileSectionFromIndexes(0, HEADER_MAX_LENGTH);
//		String headerPattern = "<%" +PDOConstantFieldsInterface.X_ORIGFREF+">(.*)</%" +PDOConstantFieldsInterface.X_ORIGFREF+">" +
//				"|<%" +PDOConstantFieldsInterface.X_FILERJCTRSN+">(.*)</%" +PDOConstantFieldsInterface.X_FILERJCTRSN+">";
//
//		m_pattern = Pattern.compile(headerPattern);
//        Matcher m = m_pattern.matcher(m_header);
//
//        while (m.find())
//        {
//        	if (m.group(1) != null)
//        	{
//        		origFileRef = m.group(1);
//        	}
//        	if (m.group(2) != null)
//        	{
//        		fileRjctRsn=m.group(2);
//        		break;
//        	}
//        }//while
//	}
//
//	@Override
//	protected void readDocumentStartData() {
//		// TODO
//
//	}
//
//	@Override
//	protected boolean readTransactionsOfChunkSize() {
//
//		return false;
//	}
//
//
//
//	@Override
//	public boolean hasNext()
//	{
//		return readTransactionsOfChunkSize();
//
//	}//EOM hasNext
//
//}
