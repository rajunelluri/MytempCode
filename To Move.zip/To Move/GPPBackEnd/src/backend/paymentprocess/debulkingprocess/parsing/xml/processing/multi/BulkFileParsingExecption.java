
package backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi;

public class BulkFileParsingExecption extends RuntimeException {

	public BulkFileParsingExecption() {
		super();
	}

	public BulkFileParsingExecption(String message, Throwable cause) {
		super(message, cause);
	}

	public BulkFileParsingExecption(String message) {
		super(message);
	}

	public BulkFileParsingExecption(Throwable cause) {
		super(cause);
	}
}
