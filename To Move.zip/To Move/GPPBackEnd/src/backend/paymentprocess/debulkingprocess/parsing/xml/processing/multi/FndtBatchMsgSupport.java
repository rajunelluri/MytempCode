
package backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FndtBatchMsgSupport {
	private static final Logger logger = LoggerFactory.getLogger(FndtBatchMsgSupport.class);
	
	public static boolean isFndtBatchMsg(String messageSnippet) {
		if (messageSnippet.indexOf("FndtMsgBatch") != -1) {
			logger.debug("file holds FndtBatchMsg");
			return true;
		}
		
		return false;
	}

	public static boolean isFndtBulkBatchMsg(String messageSnippet) {
		if (messageSnippet.indexOf("FndtFileDocument") != -1) {
			logger.debug("file holds FndtBulkBatchMsg");
			return true;
		}
		
		return false;
	}
	 
	public static boolean isFndtMsgPaymentType(String paymentTypeName) {
		return paymentTypeName.startsWith("FndtBatchMsg_SingleTypeBatch_");		
	}

	public static XmlTransactionReaderBase getReader(String paymentTypeName) {
		if (!isFndtMsgPaymentType(paymentTypeName))
			return null;
		
		String nativePaymentName = paymentTypeName.substring("FndtBatchMsg_SingleTypeBatch_".length());
		
		logger.debug("native payment type: {}",nativePaymentName);
		
		return new FndtBatchMsg_SingleTypeBatch_TransactionReader(new FndtBatchMsg_SingleTypeBatch(nativePaymentName));				
	}
}
