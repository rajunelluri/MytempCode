package backend.paymentprocess.debulkingprocess.parsing.xml.processing;

import static backend.core.module.MessageConstantsInterface.MESSAGE_TYPE_PACS_004;
import static backend.core.module.MessageConstantsInterface.MESSAGE_TYPE_PACS_008;
import static com.fundtech.util.GlobalConstants.EMPTY_STRING;
import static com.fundtech.util.GlobalConstants.NEWLINE;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.FileChannel.MapMode;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.cache.entities.Customrs;
import com.fundtech.cache.entities.SwiftId;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.general.flows.FlowException;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalUtils;

import backend.paymentprocess.SubBatchProcessInterface;
import backend.paymentprocess.debulkingprocess.common.WorkflowType;

public abstract class TransactionReader implements Iterator<String> 
{
	private static final Logger logger = LoggerFactory.getLogger(TransactionReader.class);
	private static final String FNDT_MSG_HEADER = "<FndtMsg";
	private static final String FNDT_MSG_BATCH_HEADER = "FndtMsgBatch";
	private static final String PAIN_001_HEADER = "pain.001";
	private static final String PAIN_008_HEADER = "pain.008";
	private static final String PACS_004_HEADER = "pacs.004";
	private static final String PACS_008_HEADER = "pacs.008";
	
	private static final String PACS_04_TRANS_START_TAG = "<TxInf";
	private static final String PACS_04_TRANS_END_TAG = "</TxInf";
	private static final String PACS_04_CHUNK_END_TAGS = "></PmtRtr></Document>";
	private static final String PACS_08_CHUNK_END_TAGS = "></FIToFICstmrCdtTrf></Document>";
	
	RandomAccessFile m_randomeFile;
	MappedByteBuffer m_mappedBuffer;
	StringBuilder m_stringBuffer = new StringBuilder();
	protected String m_header;
	protected String m_currentTrns;
	private  int m_byteCount = 0;
	private int m_pmtInfCount = 0;
	protected int m_trnsCountInPmtInf = 0;
	protected int m_trnsCount = 0; // Number of transactions from the file header; once set, shouldn't be changed.
	protected String m_trnsEndTag;
	protected String m_trnsStartTag;
	protected String m_chunkEnd;
	
	protected boolean m_isSinglePayment = false;
	protected boolean m_isContainFooter = true;

	protected String m_currentPmtInfHeader = "";
	protected String XML_TRNS_END_TAG = "</CdtTrfTxInf";
	protected String XML_TRNS_START_TAG = "<CdtTrfTxInf";
	private String PMT_INF_START_TAG = "<PmtInf";
	
	protected Pattern m_pattern;
	protected String m_msgId;
	protected String m_ctrlSum;          
	protected String m_partyName;
	protected String m_initiatingPartyCustCode;
	protected String m_office;
	protected String m_fileName;
	protected String m_workflow;
	protected String m_inMsgContext;
	protected String m_msgType;
	protected String m_xmlns;
	protected String m_emptyHeader;


	Object m_input;

	
	protected TransactionReader() 
	{
		m_inMsgContext = "Feeder";
	}
	
//	public static TransactionReader TransactionReaderFactory(Object o) throws Exception
//	{
//		return null;
//	}
	
	public static TransactionReader TransactionReaderFactory(File file) throws Exception
	{
		FileInputStream fileInput = new FileInputStream(file);
		try{
			byte[] arr = new byte[200]; 
			fileInput.read(arr);
			String str = new String(arr);
						
			TransactionReader reader = null;
			if (str.indexOf(FNDT_MSG_BATCH_HEADER) > -1) reader = new TransactionReaderBatchFndtMsg(file);
			else if (str.indexOf(PAIN_001_HEADER) > -1) reader = new TransactionReaderPain001(file); 
			else if (str.indexOf(PAIN_008_HEADER) > -1) reader = new TransactionReaderPain008(file);
			else if (str.indexOf(PACS_008_HEADER) > -1) reader = new TransactionReaderPacs08(file);
			else if (str.indexOf(PACS_004_HEADER) > -1) reader = new TransactionReaderPacs04(file);
			
			// TODO Are those the correct identifiers for multi ?
			else if (str.indexOf("MPEDDDnfBlkDirDeb") > -1) reader = new TransactionReaderMultiPacs03(file);
			else if (str.indexOf("S2SCTIcf") > -1) reader = new TransactionReaderMultiPacs04Pacs08(file);
			
			else if (str.startsWith("{")) reader = new TransactionReaderSwift(file);
			else reader = new TransactionReaderNomina(file) ;
			
			return reader;
		}finally{
			try{
				if (fileInput !=null) fileInput.close();
			}catch(Exception e){
        		logger.error("Exception - could not close fileInput-FileInputStream at TransactionReader.TransactionReaderFactory");
			}
		}
	}
	
	public static TransactionReader TransactionReaderFactory(String str) throws FlowException
	{
		TransactionReader reader = null;
		
		try
		{
			if (str.startsWith(FNDT_MSG_HEADER)) reader = new TransactionReaderBatchFndtMsg(str);
			else if (str.indexOf(PAIN_001_HEADER) > -1) reader = new TransactionReaderPain001(str); 
			else if (str.indexOf(PAIN_008_HEADER) > -1) reader = new TransactionReaderPain008(str);
			else if (str.indexOf(PACS_008_HEADER) > -1) reader = new TransactionReaderPacs08(str);
			else if (str.indexOf(PACS_004_HEADER) > -1) reader = new TransactionReaderPacs04(str);
			
			// TODO Are those the correct identifiers for multi ?
			else if (str.indexOf("MPEDDDnfBlkDirDeb") > -1) reader = new TransactionReaderMultiPacs03(str);
			else if (str.indexOf("S2SCTIcf") > -1) reader = new TransactionReaderMultiPacs04Pacs08(str);	
			
			else if (str.startsWith("{")) reader = new TransactionReaderSwift(str);
			else reader = new TransactionReaderNomina(str) ;
		}catch(Exception e)
		{
			throw new FlowException(e);
		}
		
		return reader;
	}

	/**
	 * @param file
	 * @throws Exception
	 */
	public void init(File file) throws Exception {
		m_randomeFile = new RandomAccessFile(file, "r");
		init();
	}

	
	
	/**
	 * @param xml
	 * @throws Exception
	 */
	public void init(String xml) throws Exception {
		m_stringBuffer.append(xml);
		init();
	}
	
	
	public String getMsgType()
	{
		return m_msgType;
	}
	
	
	public String getFileName()
	{
		return m_fileName;
	}
	
	public void setFileName(String fileName)
	{
		m_fileName = fileName;
	}
	
	
	public String getWorkflow() {
		return m_workflow;
	}	

	public void setWorkflow(String workflow) {
		m_workflow = workflow;
	}

	public String getPmtInfoStartTag()
	{
		return PMT_INF_START_TAG;
	}

	protected abstract void init() throws IOException; 

	public String getXmlns()
	{
		return m_xmlns;
	}
	
	
	public String getEmptyHeader() {return m_emptyHeader;}
	protected void setXmlns(String str, String tagElement)
	{
		m_xmlns = GlobalConstants.EMPTY_STRING;
		if (!GlobalUtils.isNullOrEmpty(str))
		{
			Pattern p = Pattern.compile("<"+tagElement+" (.*)>");
			Matcher m = p.matcher(str);
	    	if (m.find())
	    	{
	    		m_xmlns = m.group(1);
	    	}
		}
		
	}


	public String getInputAsString()
	{
		return m_input != null ? m_input.toString() : GlobalConstants.EMPTY_STRING;
	}
	
	public String getInMsgContext() 
	{
		return m_inMsgContext;
	}

	public void setInMsgContext(String mInMsgContext) 
	{
		m_inMsgContext = mInMsgContext;
	}

//	@Override
//	public Iterator<String> iterator() {
//		// TODO Auto-generated method stub
//		return this;
//	}

	@Override
	public boolean hasNext() {
		boolean hasNext = false;

		try
		{
			if(this.m_randomeFile != null) this.updateBuffer(m_trnsEndTag);
			final String sContent = m_stringBuffer.toString();
			hasNext = indexOfIgnoreWhiteSpaces(sContent, m_trnsEndTag,m_trnsEndTag) > -1 && indexOfIgnoreWhiteSpaces(sContent, m_trnsStartTag) > -1;
		}
		catch (Exception e)
		{
			logger.error(e.getMessage());
			throw new RuntimeException(e);
		}
		return hasNext;
	}

	@Override
	public String next() {
		String str = null;
		try
		{
			// retrieve next transaction
			str = remove(m_trnsEndTag, null);
			// store the transaction
			m_currentTrns = str;
			updateCurrenctPmtInf(str);
			// update transaction counters
			m_trnsCountInPmtInf++;
		}
		catch (Exception e)
		{
			logger.error(e.getMessage());
			throw new RuntimeException(e);
		}
		return str;
	}

	protected void updateCurrenctPmtInf(String str) {
		// update the counters in case new 'pmt info' tag
		if (indexOfIgnoreWhiteSpaces(str, PMT_INF_START_TAG,m_trnsEndTag) > -1)
		{
			int from = indexOfIgnoreWhiteSpaces(str, PMT_INF_START_TAG,m_trnsEndTag);
			int to = indexOfIgnoreWhiteSpaces(str, m_trnsStartTag,m_trnsEndTag);
			
			if (to > from)
			{
				m_currentPmtInfHeader = str.substring(from, to);
				m_pmtInfCount++;
				m_trnsCountInPmtInf = 0;
			}
		}

	}

	protected void updateBuffer(String toTag) throws IOException {
		// int BUFFER_SIZE = 2048;
		// if (indexOfIgnoreWhiteSpaces(m_stringBuffer.toString(),toTag) == -1)
		// {
		// while (m_byteCount < m_randomeFile.length() && indexOfIgnoreWhiteSpaces(m_stringBuffer.toString(),toTag) == -1)
		// {
		// try{
		// int size = m_mappedBuffer.remaining() > BUFFER_SIZE ? BUFFER_SIZE : m_mappedBuffer.remaining();
		// byte[] arr = new byte[size];
		// m_mappedBuffer.get(arr,0,size);
		// m_stringBuffer.append(new String(arr,0,size));
		// }catch(Exception e)
		// {
		// logger.error(e.getMessage());
		// throw new RuntimeException("problem reading "+m_byteCount+" chunk");
		// }
		// }
		// }

		if(this.m_randomeFile == null) return ; 
		
		final FileChannel nioChannel = m_randomeFile.getChannel() ; 
		MappedByteBuffer mappedBuffer;
		int BUFFER_SIZE = 2048;
		byte[] arr = new byte[BUFFER_SIZE];
		final long lFileSize = m_randomeFile.length() ;
		
		if (indexOfIgnoreWhiteSpaces(m_stringBuffer.toString(), toTag) == -1)
		{
			//while (m_randomeFile != null && m_byteCount < m_randomeFile.length() && indexOfIgnoreWhiteSpaces(m_stringBuffer.toString(), toTag) == -1)
			while (m_randomeFile != null && m_byteCount < lFileSize && indexOfIgnoreWhiteSpaces(m_stringBuffer.toString(), toTag) == -1)
			{
				try
				{
					//long size = m_randomeFile.length() - m_byteCount > BUFFER_SIZE ? BUFFER_SIZE : m_randomeFile.length() - m_byteCount;
					long size = lFileSize - m_byteCount > BUFFER_SIZE ? BUFFER_SIZE : lFileSize - m_byteCount;

					mappedBuffer = nioChannel.map(MapMode.READ_ONLY, m_byteCount, size);
					m_byteCount += size;
					mappedBuffer.get(arr, 0, (int) size);
					m_stringBuffer.append(new String(arr, 0, (int) size));
				}
				catch (Exception e)
				{
					logger.error(e.getMessage());
					throw new RuntimeException("problem reading " + m_byteCount + " chunk");
				}
			}
		}

	}

	/**
	 * Method which returns and removes the specified string from 'fromTag' to 'toTag' from local buffer
	 * 
	 * @param fromStr
	 * @param toStr
	 * @return
	 * @throws IOException String
	 */
	protected String remove(String fromStr, String toStr, String prefix) throws IOException {
		if(this.m_randomeFile != null) updateBuffer(toStr);
		String str = GlobalConstants.EMPTY_STRING;
		
		final String sContent = this.m_stringBuffer.toString() ; 
		
		/*if (indexOfIgnoreWhiteSpaces(m_stringBuffer.toString(), toStr,m_trnsEndTag) > -1)
		{
			int from = fromStr != null ? indexOfIgnoreWhiteSpaces(m_stringBuffer.toString(), fromStr,m_trnsEndTag) : 0;
			int to = indexOfIgnoreWhiteSpaces(m_stringBuffer.toString(), toStr,m_trnsEndTag) + toStr.length();
			str = m_stringBuffer.substring(from, to);
			m_stringBuffer.delete(0, to);
		}*/
		
		if (indexOfIgnoreWhiteSpaces(sContent, toStr,m_trnsEndTag) > -1)
		{
			int from = fromStr != null ? indexOfIgnoreWhiteSpaces(sContent, fromStr,m_trnsEndTag) : 0;
			int to = indexOfIgnoreWhiteSpaces(sContent, toStr,m_trnsEndTag) + toStr.length();
			str = sContent.substring(from, to);
			m_stringBuffer.delete(0, to);
		}
		return str;
	}

	protected String remove(String toStr, String prefix) throws IOException {
		return remove(null, toStr,prefix);
	}

	public void close() throws IOException {
		m_randomeFile.close();
	}

	public String getSuffix() {
		return m_stringBuffer.toString();
	}

	public String getHeader() {
		return m_header;
	}

	public int getPmtInfCount() {
		return m_pmtInfCount;
	}

	public int getTrnsCountInPmtInf() {
		return m_trnsCountInPmtInf;
	}

	public String getCurrentPmtInfHeader() {
		return m_currentPmtInfHeader;
	}

	public void setPmtInfCount(int infCount) {
		m_pmtInfCount = infCount;
	}

	public void setTrnsCountInPmtInf(int countInPmtInf) {
		m_trnsCountInPmtInf = countInPmtInf;
	}

	public void setCurrentPmtInfHeader(String pmtInfHeader) {
		m_currentPmtInfHeader = pmtInfHeader;
	}

	public int getNumOfTxs() {
		return m_trnsCount;
	}

	public void setNumOfTxs(int iNumOfTxs) {
		m_trnsCount = iNumOfTxs;
	}

	/**
	 * Method which shifts the local buffer to payment info and transaction number as defined in method input
	 * 
	 * @param numOfPmtInf
	 * @param numOfTrns void
	 */
	public void goTo(int numOfPmtInf, int numOfTrns) {
		// skip the transaction till transaction number equals transaction number in input
		while (this.hasNext() && (this.m_pmtInfCount != numOfPmtInf || m_trnsCountInPmtInf != numOfTrns))
		{
			this.next();
		}
		// return the last chunk so the 'next' method can retrieved it.
		if (this.m_pmtInfCount == numOfPmtInf && m_trnsCountInPmtInf == numOfTrns)
		{
			m_stringBuffer.insert(0, m_currentTrns);
			// update the counters
			if (m_trnsCountInPmtInf == 0) m_pmtInfCount--;
			else m_trnsCountInPmtInf--;
		}

	}

	public String getCurrentTrns() {
		return m_currentTrns;
	}

	@Override
	public void remove() {}

	/**
	 * @return the trnsEndTag
	 */
	public String getTrnsEndTag() {
		return m_trnsEndTag;
	}

	/**
	 * @return the trnsStartTag
	 */
	public String getTrnsStartTag() {
		return m_trnsStartTag;
	}
	
	public String getChunkEnd() {
		return this.m_chunkEnd;
	}
	
	
	public boolean isSinglePayment(){
		return m_isSinglePayment;
	}
	

	/**
	 * Method which emulates String.indexOf method, but ignoring white spaces
	 * 
	 * @param text
	 * @param tag
	 * @return int
	 */
	public int indexOfIgnoreWhiteSpaces(String text, String tag) {
		return indexOfIgnoreWhiteSpaces(text, tag, null);
	}
	public int indexOfIgnoreWhiteSpaces(String text, String tag, String endTag) {
		
		//if the text is empty return -1 
		final int iTextLength = text.length() ;
		if(iTextLength == 0) return -1 ; 

		boolean isEndTag = false;
		int indx = -1;
		int tempIndex = 0;
		String tagName;
				
		final int iTagLength = tag.length() ;
		int iTagNameLength = -1 ; 
		
		if (tag == null)
			indx = 0;
		//else if (tag.length() == 1 || tag.length() == 0) 
		else if (iTagLength == 1 || iTagLength == 0)
		{ 
			indx = text.indexOf(tag); 
		}
		else 
		{
//			if (tag.indexOf("/") > -1)
			if (tag.charAt(1) == '/')
			{
				isEndTag = true;
				tagName = tag.substring(2);
				iTagNameLength = iTagLength-2; 
			}
			else { 
				 tagName = tag.substring(1);
				 iTagNameLength = iTagLength-1; 
			}
	
			String tempText = text ; //text.substring(tempIndex);
			while (indx == -1 && tempText != null)
			{
	
				int startOfTagName = tempText.indexOf(tagName);
				if (startOfTagName > -1)
				{
					String subString = tempText.substring(0, startOfTagName);
					int lastIndexOfTag = subString.lastIndexOf('<');
					int lastIndexOfFrwd = subString.lastIndexOf('/');
	
					if ((isEndTag && lastIndexOfFrwd < startOfTagName && lastIndexOfFrwd > lastIndexOfTag)
							|| (!isEndTag && lastIndexOfFrwd < lastIndexOfTag || lastIndexOfFrwd > startOfTagName)) indx = lastIndexOfTag + tempIndex;
					else
					{
						tempText = null;
						if (startOfTagName > -1)
						{
							//tempIndex += startOfTagName + tagName.length();
							tempIndex += startOfTagName + iTagNameLength;
							//if (tempIndex < text.length() + tag.length()) tempText = text.substring(tempIndex);
							if (tempIndex < iTextLength + iTagLength) tempText = text.substring(tempIndex);
						}
					}
				}
				else tempText = null;
			}
		}
		
//		if the string ends and the end tag not found, then return till the end of the string
//		this is relevant when the end tag is '\n' and the last line does not hold the '\n' character.
		//if (indx == -1 && !m_isContainFooter && endTag != null && text.length() > 0 && tag.equals(endTag)){
		if (indx == -1 && !m_isContainFooter && endTag != null && iTextLength > 0 && tag.equals(endTag)){
			//indx = text.length() - tag.length() ;
			indx = iTextLength - iTagLength ;
		}
		
		return indx;
	}
	public int lastIndexOfIgnoreWhiteSpaces(String text, String tag, String endTag) {
		
		boolean isEndTag = false;
		int indx = -1;
		int tempIndex = 0;
		String tagName;
		
		if (tag == null)
			indx = 0;
		else if (tag.length() == 1 || tag.length() == 0) 
		{ 
			indx = text.indexOf(tag); 
		}
		else 
		{
			String tmpTag = tag;
			if (tag.startsWith("<"))
			{
				tmpTag = tmpTag.substring(1);
			}
			if (tag.indexOf("/") > -1)
			{
				isEndTag = true;
				tmpTag = tmpTag.substring(1);
			}
			tagName = tmpTag;
	
			String tempText = text.substring(tempIndex);
			while (tempText != null)
			{
	
				int startOfTagName = tempText.indexOf(tagName);
				if (startOfTagName > -1)
				{
					String subString = tempText.substring(0, startOfTagName);
					int lastIndexOfTag = subString.lastIndexOf('<');
					int lastIndexOfFrwd = subString.lastIndexOf('/');
	
					if ((isEndTag && lastIndexOfFrwd < startOfTagName && lastIndexOfFrwd > lastIndexOfTag)
							|| (!isEndTag && lastIndexOfFrwd < lastIndexOfTag || lastIndexOfFrwd > startOfTagName))
					{
						indx = lastIndexOfTag + tempIndex;
						tempText = tempText.substring(startOfTagName);
					}
					else
					{
						tempText = null;
						if (startOfTagName > -1)
						{
							tempIndex += startOfTagName + tagName.length();
							if (tempIndex < text.length() + tag.length()) tempText = text.substring(tempIndex);
						}
					}
				}
				else tempText = null;
			}
		}
		
//		if the string ends and the end tag not found, then return till the end of the string
//		this is relevant when the end tag is '\n' and the last line does not hold the '\n' character.
		if (indx == -1 && !m_isContainFooter && endTag != null && text.length() > 0 && tag.equals(endTag)){
			indx = text.length() - tag.length() ;
		}
		
		return indx;
	}

	public String getMsgId() {
		return this.m_msgId;
	}
	
	public String getCtrlSum(){
		return m_ctrlSum;
	}
	
	public String getPartyName(){
		return this.m_partyName;
	}
	
	public String getInitiatingPartyCustCode(){
		return this.m_initiatingPartyCustCode;
	}
	
	public String getOffice()
	{
		return m_office;
	}
	
	public void setOffice(String office)
	{
		m_office = office;
	}
	
	public String getVirtualChunkHeader()
	{
		return "";
	}
	
	public String getVirtualChunkEnd()
	{
		return "";
	}
	
	public String getVirtualTrnsStart()
	{
		return "";
	}
	
	public String getVirtualTrnsEnd()
	{
		return "";
	}
	
	public static String getCustCodeFromBic(String bic){
		SwiftId swiftId = CacheKeys.swiftIdPerSwiftIdKey.getSingle(bic);
		String custCode = null;
		if (swiftId != null){
    		String office = swiftId.getOffice();
    		Customrs cust =  CacheKeys.customrsBICandOfficeKey.getSingle(bic,office);
    		if (cust != null){
    			custCode = cust.getCustCode();
    		}
		}
		
		return custCode;
	}

	/**
	 * Base class for pain 01 and pain 08
	 */
	public static abstract class TransactionReaderPainBase extends TransactionReader
	{
		protected TransactionReaderPainBase() throws Exception 
		{
			super();
		}

		protected TransactionReaderPainBase(File file) throws Exception 
		{
			super();
			init(file);
		}
		
		protected TransactionReaderPainBase(String xml) throws Exception 
		{
			super();
			init(xml);
		}
		
		protected abstract String getTransationEndTag();
		
		protected abstract String getTransationStartTag();
		
		protected abstract String getChunkEndTags();
		
		@Override
		protected void init() throws IOException {
	        // Gets the info from the file.
			m_header = this.remove("<Document", "</GrpHdr", null);
			
			m_header = m_header + ">";
			
			m_emptyHeader = m_header.substring(0, this.indexOfIgnoreWhiteSpaces(m_header, "<GrpHdr>"));
			
			m_trnsEndTag = getTransationEndTag();
			m_trnsStartTag = getTransationStartTag();
			m_chunkEnd = getChunkEndTags();
			
			m_isSinglePayment = false;
			m_isContainFooter = true;
			m_pattern = Pattern.compile("<MsgId>(.*)</MsgId>|<NbOfTxs>(.*)</NbOfTxs>|<CtrlSum>(.*)</CtrlSum>|<Nm>(.*)</Nm>|<Othr>\\s*<Id>(.*)</Id>");
			setXmlns(m_header,"Document");
	        Matcher m = m_pattern.matcher(m_header);
	        while (m.find())
	        {
	        	if (m.group(1) != null) m_msgId = m.group(1);
	        	if (m.group(2) != null) m_trnsCount=Integer.parseInt(m.group(2));
	        	if (m.group(3) != null) m_ctrlSum=m.group(3);          
	        	if (m.group(4) != null) m_partyName=m.group(4);
	        	if (m.group(5) != null) m_initiatingPartyCustCode=m.group(5);
	        }
		}
	}		
	
	public static class TransactionReaderPain001 extends TransactionReaderPainBase
	{
		private static final String PAIN_001_CHUNK_END_TAGS = "></PmtInf></CstmrCdtTrfInitn></Document>";

		protected TransactionReaderPain001(File file) throws Exception 
		{
			super();
			init(file);
		}
		
		protected TransactionReaderPain001(String xml) throws Exception 
		{
			super();
			init(xml);
		}
		
		@Override
		protected String getTransationEndTag() {
			return XML_TRNS_END_TAG;
		}
		
		@Override
		protected String getTransationStartTag() {
			return XML_TRNS_START_TAG;
		}
		
		@Override
		protected String getChunkEndTags() {
			return PAIN_001_CHUNK_END_TAGS;
		}

	}
	
	public static class TransactionReaderPain008 extends TransactionReaderPainBase
	{
		private static final String PAIN_008_TRANSACTION_TAG = "DrctDbtTxInf";
		private static final String PAIN_008_TRANSACTION_START_TAG = "<" + PAIN_008_TRANSACTION_TAG;
		private static final String PAIN_008_TRANSACTION_END_TAG = "</" + PAIN_008_TRANSACTION_TAG;
		private static final String PAIN_008_CHUNK_END_TAGS = "></PmtInf></CstmrDrctDbtInitn></Document>";

		protected TransactionReaderPain008(File file) throws Exception 
		{
			super();
			init(file);
			setWorkflow(WorkflowType.Pain_008.name());
		}
		
		protected TransactionReaderPain008(String xml) throws Exception 
		{
			super();
			init(xml);
			setWorkflow(WorkflowType.Pain_008.name());
		}

		@Override
		protected String getChunkEndTags() {
			return PAIN_008_CHUNK_END_TAGS;
		}

		@Override
		protected String getTransationEndTag() {
			return PAIN_008_TRANSACTION_END_TAG;
		}
		
		@Override
		protected String getTransationStartTag() {
			return PAIN_008_TRANSACTION_START_TAG;
		}
	}	
	
	// TODO Add support to 'urn' in the xml file, also to Pacs04 and Multi
	/**
	 * Base class for pacs 08, pacs 04 and multi type
	 */
	public static abstract class TransactionReaderPacsBase extends TransactionReader
	{
		
		protected TransactionReaderPacsBase() throws Exception 
		{
			super();
		}

		protected TransactionReaderPacsBase(File file) throws Exception 
		{
			super();
			init(file);
		}
		
		protected TransactionReaderPacsBase(String xml) throws Exception 
		{
			super();
			init(xml);
		}
		
		protected abstract String getTransationEndTag();
		
		protected abstract String getTransationStartTag();
		
		protected abstract String getChunkEndTags();
		
		protected void extraInit() {
			// Empty implementation
		}
		
		protected String getHeaderStartTag() {
			return "<Document";
		}
		
		protected String getHeaderEndTag() {
			return "</GrpHdr";
		}	

		@Override
		protected void init() throws IOException {
	        // Gets the info from the file.
			m_header = this.remove(getHeaderStartTag(), getHeaderEndTag(), null);
			m_header = m_header + ">";
			extraInit();
			m_trnsEndTag = getTransationEndTag();
			m_trnsStartTag = getTransationStartTag();
			m_chunkEnd = getChunkEndTags();
			m_isSinglePayment = false;
			m_isContainFooter = true;
			m_pattern = Pattern.compile("<MsgId>(.*)</MsgId>|<NbOfTxs>(.*)</NbOfTxs>|<CtrlSum>(.*)</CtrlSum>|<Nm>(.*)</Nm>|<InstdAgt>\\s*<FinInstnId>\\s*<BIC>(.*)</BIC>");
			String instdBic=null;
	        Matcher m = m_pattern.matcher(m_header);
	        while (m.find())
	        {
	        	if (m.group(1) != null) m_msgId = m.group(1);
	        	if (m.group(2) != null) m_trnsCount=Integer.parseInt(m.group(2));
	        	if (m.group(3) != null) m_ctrlSum=m.group(3);          
	        	if (m.group(4) != null) m_partyName=m.group(4);
	        	if (m.group(5) != null) instdBic=m.group(5);
	        }
	        m_initiatingPartyCustCode = CacheKeys.banksKey.getSingle("***").getCustCode();
	        if (instdBic != null)
	        {
	        	instdBic = instdBic.substring(0, 8) + "XXX";
	        	SwiftId swiftId = CacheKeys.swiftIdPerSwiftIdKey.getSingle(instdBic);
	        	if (swiftId != null) 
	        	{
	        		m_initiatingPartyCustCode = CacheKeys.customrsBICandOfficeKey.getSingle(instdBic, swiftId.getOffice()).getCustCode();
	        	}
	        }	        
		}
	}	
	
	public static class TransactionReaderPacs08 extends TransactionReaderPacsBase
	{
		
		protected TransactionReaderPacs08() throws Exception 
		{
			super();
			setWorkflow(WorkflowType.Pacs_008.name());
		}

		protected TransactionReaderPacs08(File file) throws Exception 
		{
			super();
			init(file);
			setWorkflow(WorkflowType.Pacs_008.name());
		}
		
		protected TransactionReaderPacs08(String xml) throws Exception 
		{
			super();
			init(xml);
			setWorkflow(WorkflowType.Pacs_008.name());
		}
		
		@Override
		protected String getTransationEndTag() {
			return XML_TRNS_END_TAG;
		}
		
		@Override
		protected String getTransationStartTag() {
			return XML_TRNS_START_TAG;
		}
		
		@Override
		protected String getChunkEndTags() {
			return PACS_08_CHUNK_END_TAGS;
		}	
	}
	
	public static class TransactionReaderPacs04 extends TransactionReaderPacsBase
	{

		protected TransactionReaderPacs04(File file) throws Exception 
		{
			super();
			init(file);
			setWorkflow(WorkflowType.Pacs_004.name());
		}
		
		protected TransactionReaderPacs04(String xml) throws Exception 
		{
			super();
			init(xml);
			setWorkflow(WorkflowType.Pacs_004.name());
		}
		
		protected String getTransationEndTag() {
			return PACS_04_TRANS_END_TAG;
		}
		
		protected String getTransationStartTag() {
			return PACS_04_TRANS_START_TAG;
		}
		
		protected String getChunkEndTags() {
			return PACS_04_CHUNK_END_TAGS;
		}
	}

	public static abstract class TransactionReaderMultiPacsBase extends TransactionReaderPacsBase
	{
		protected ReaderMessageType m_currentMessageType;
		protected boolean m_messageTypeChanged;
		protected boolean m_newHeaderIsRequired;
		protected String m_headerEndTag;
		protected String m_headerStartTag;

		protected TransactionReaderMultiPacsBase() throws Exception 
		{
			super();
		}		

		protected TransactionReaderMultiPacsBase(File file) throws Exception 
		{
			super();
			init(file);
		}

		protected TransactionReaderMultiPacsBase(String xml) throws Exception 
		{
			super();
			init(xml);
		}

		protected String getTransationEndTag() {
			return m_trnsEndTag;
		}

		protected String getTransationStartTag() {
			return m_trnsStartTag;
		}

		protected String getChunkEndTags() {
			return m_chunkEnd;
		}			

		protected String getHeaderEndTag() {
			return m_headerEndTag;
		}	

		protected String getHeaderStartTag() {
			return m_headerStartTag;
		}

		protected abstract void setHeaderStartAndEndTags();		

		@Override
		protected void init() throws IOException {
			// TODO What do we need to read from the global header ?

			// First init for global header
			if (m_currentMessageType == null) {
				setHeaderStartAndEndTags();

				// Set m_trnsCount to -1 in order to execute the BODebulkFile.executeDebulking
				m_trnsCount = GlobalConstants.MINUS_ONE_INT;
			}

			super.init();
		}

		@Override
		public boolean hasNext() {
			try {
				// Set start tag, end tag and header according to the message type
				setMessageTypeAndInit();
			} catch (IOException e) {
				throw new RuntimeException(e);
			}

			return super.hasNext();
		}

		/**
		 * Initialize header, tags and set the message type.
		 * 
		 * @throws IOException 
		 */
		protected abstract void setMessageTypeAndInit() throws IOException;

		/**
		 * @param messageType
		 */
		protected void setCurrentMessageType(ReaderMessageType messageType) {
			// If the message type has not changed another header in the same chunk is needed
			if (messageType.equals(m_currentMessageType)) {
				m_newHeaderIsRequired = true;
			}

			m_currentMessageType = messageType;
			m_messageTypeChanged = true;
		}

		@Override
		public boolean isMessageTypeChanged() {
			return m_messageTypeChanged;
		}		

		@Override
		public boolean isSameHeaderInChunkRequired() {
			return m_newHeaderIsRequired;
		}	

		/**
		 * @see backend.paymentprocess.debulkingprocess.parsing.xml.processing.TransactionReader#getChunkStatus()
		 */
		@Override
		public String getChunkStatus() {		
			return SubBatchProcessInterface.STATUS_PENDING_WAITING;
		}		

		public enum ReaderMessageType{
			PACS_04(),
			PACS_08(),
			PACS_03()
		}
	}		
	
	public static class TransactionReaderMultiPacs04Pacs08 extends TransactionReaderMultiPacsBase
	{
		// TODO Should we support only Pacs 008 and Pacs 004 for multi ? what about Pain 007 ?		
		
		private String m_headerSecondTag;

		protected TransactionReaderMultiPacs04Pacs08(File file) throws Exception 
		{
			super();
			init(file);
		}
		
		protected TransactionReaderMultiPacs04Pacs08(String xml) throws Exception 
		{
			super();
			init(xml);
		}
		
		private String getHeaderSecondTag() {
			return m_headerSecondTag;
		}
		
		protected void extraInit() {
			if (m_currentMessageType != null) {
				// For pacs 04 and pacs 08 a second header is needed that doesn't exist in the original multi file
				m_header = m_header.replace(getHeaderStartTag(), "<Document");
				m_header = m_header.replace("<GrpHdr>", getHeaderSecondTag() + "<GrpHdr>");
			}
		}			
		
		/**
		 * @see backend.paymentprocess.debulkingprocess.parsing.xml.processing.TransactionReader.TransactionReaderMultiPacsBase#setHeaderStartAndEndTags()
		 */
		@Override
		protected void setHeaderStartAndEndTags() {
			m_headerStartTag = "<S2SCTIcf:SCTIcfBlkCredTrf";
			m_headerEndTag = "</S2SCTIcf:NumROIBlk>";
		}		
		
		/**
		 * Initialize header, tags and set the message type.
		 * 
		 * @throws IOException 
		 */
		protected void setMessageTypeAndInit() throws IOException {
			m_newHeaderIsRequired = false;
			m_messageTypeChanged = false;
			
			// TODO How to do it more O-O-D ?
			
			// Pacs 04 or pacs 08 can be in the same buffer - take the first one
			int indexOfPacs08 = m_stringBuffer.indexOf("urn:iso:std:iso:20022:tech:xsd:pacs.008.001.02");
			int indexOfPacs04 = m_stringBuffer.indexOf("urn:iso:std:iso:20022:tech:xsd:pacs.004.001.02");
			
			// If the start transaction tag is before the header tag it means that the current transaction wasn't finish  
			String trnsStartTag = getTrnsStartTag();
			int indexOfCurrentStartTransaction = trnsStartTag == null ? GlobalConstants.MINUS_ONE_INT : m_stringBuffer.indexOf(trnsStartTag);

			if (indexOfPacs08 > indexOfPacs04) {

				if (indexOfCurrentStartTransaction == GlobalConstants.MINUS_ONE_INT) {
					setAndInitPacs08();
				} else if (indexOfPacs08 < indexOfCurrentStartTransaction) {
					setAndInitPacs08();
				}

			} else if (indexOfPacs04 >  indexOfPacs08) {

				if (indexOfCurrentStartTransaction == GlobalConstants.MINUS_ONE_INT) {
					setAndInitPacs04();
				} else if (indexOfPacs04 < indexOfCurrentStartTransaction) {
					setAndInitPacs04();
				}
			}
		}

		private void setAndInitPacs04() throws IOException {
			setCurrentMessageType(ReaderMessageType.PACS_04);
			
			m_trnsStartTag = PACS_04_TRANS_START_TAG;
			m_trnsEndTag = PACS_04_TRANS_END_TAG;
			
			m_headerStartTag = "<S2SCTIcf:PmtRtr";
			m_headerEndTag = "</GrpHdr";
			
			m_headerSecondTag = "<PmtRtr>";		
			m_chunkEnd = "></PmtRtr></Document>";	
			
			init();
			
			setWorkflow(WorkflowType.Pacs_004.name());
		}

		private void setAndInitPacs08() throws IOException {
			setCurrentMessageType(ReaderMessageType.PACS_08);
			
			m_trnsStartTag = XML_TRNS_START_TAG;
			m_trnsEndTag = XML_TRNS_END_TAG;
			
			m_headerStartTag = "<S2SCTIcf:FIToFICstmrCdtTrf";
			m_headerEndTag = "</GrpHdr";
			
			m_headerSecondTag = "<FIToFICstmrCdtTrf>";			
			m_chunkEnd = "></FIToFICstmrCdtTrf></Document>";
			
			init();
			
			setWorkflow(WorkflowType.Pacs_008.name());
		}
	}	

	public static class TransactionReaderMultiPacs03 extends TransactionReaderMultiPacsBase
	{

		protected TransactionReaderMultiPacs03(File file) throws Exception 
		{
			super();
			init(file);
		}
		
		protected TransactionReaderMultiPacs03(String xml) throws Exception 
		{
			super();
			init(xml);
		}
		
		/**
		 * @see backend.paymentprocess.debulkingprocess.parsing.xml.processing.TransactionReader.TransactionReaderMultiPacsBase#setHeaderStartAndEndTags()
		 */
		@Override
		protected void setHeaderStartAndEndTags() {
			m_headerStartTag = "<S2SDDDnf:MPEDDDnfBlkDirDeb";
			m_headerEndTag = "</S2SDDDnf:NumREJBlk>";
		}		
		
		/**
		 * Initialize header, tags and set the message type.
		 * 
		 * @throws IOException 
		 */
		protected void setMessageTypeAndInit() throws IOException {
			m_newHeaderIsRequired = false;
			m_messageTypeChanged = false;
			
			int indexOfPacs03 = m_stringBuffer.indexOf("urn:iso:std:iso:20022:tech:xsd:pacs.003.001.01");
			
			// If the start transaction tag is before the header tag it means that the current transaction wasn't finish  
			String trnsStartTag = getTrnsStartTag();
			int indexOfCurrentStartTransaction = trnsStartTag == null ? GlobalConstants.MINUS_ONE_INT : m_stringBuffer.indexOf(trnsStartTag);
			
			if (indexOfPacs03 != GlobalConstants.MINUS_ONE_INT && indexOfPacs03 > indexOfCurrentStartTransaction) {
				setAndInitPacs03();
			}			
		}
		
		private void setAndInitPacs03() throws IOException {
			setCurrentMessageType(ReaderMessageType.PACS_03);
			
			m_trnsStartTag = "<DrctDbtTxInf";
			m_trnsEndTag = "</DrctDbtTxInf";
			
			m_headerStartTag = "<S2SDDDnf:pacs.003.001.01";
			m_headerEndTag = "</GrpHdr";
			
			m_chunkEnd = "></S2SDDDnf:pacs.003.001.01>";
			
			init();
		}		
	}	
	
	public static class TransactionReaderBatchFndtMsg extends TransactionReader
	{
		private String m_grpHeader;
		private String m_chunkHeader;
		private String m_documentStart;
		private String m_documentEnd;
		private String m_xmlns;
		private StringBuilder m_msgBatchPrefix = new StringBuilder();
		private StringBuilder m_fndMsgPrefix = new StringBuilder();
		private StringBuilder m_fndPmntTxInfPrefix = new StringBuilder();
		
		protected TransactionReaderBatchFndtMsg(File file) throws Exception 
		{
			super();
			init(file);
		}

		
		protected TransactionReaderBatchFndtMsg(String str) throws Exception 
		{
			super();
			init(str);
		}

		
		@Override
		protected void init() throws IOException 
		{
	        // Gets the info from the file.
			updateBuffer("<PmntTxInf");
			setXmlnsPrefixes(m_msgBatchPrefix, m_stringBuffer.toString(), "FndtMsgBatch");
			setXmlnsPrefixes(m_fndPmntTxInfPrefix, m_stringBuffer.toString(), "PmntTxInf");
			
			m_header = this.remove("<FndtMsgBatch", "<PmntTxInf", m_fndPmntTxInfPrefix.toString());
			m_header = m_header.length() > 0 ? m_header + ">" : m_header;
//			m_header=m_header.replaceAll("FndtMsgBatch", "MsgBatch");
			m_header=m_header.replaceAll("PmntTxInf", "FndtPmntTxInf");
			setXmlns(m_header, "FndtMsgBatch");
			m_trnsEndTag = "</FndtMsg";
			m_trnsStartTag = "<FndtMsg";
			
			m_chunkEnd = "</FndtMsg></"+m_fndPmntTxInfPrefix+"FndtPmntTxInf></"+m_msgBatchPrefix+"FndtMsgBatch>";
			m_isSinglePayment = false;
			m_isContainFooter = true;

			m_documentStart = "<Document xsi:schemaLocation=\"urn:iso:std:iso:20022:tech:xsd:pain.001.001.03 pain.001.001.03.xsd \" xmlns=\"urn:iso:std:iso:20022:tech:xsd:pain.001.001.03\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\r\n" + 
					"              <CstmrCdtTrfInitn>\r\n" + 
					"                <GrpHdr/>\r\n" + 
					"                <PmtInf>";
			
			m_documentEnd = "</PmtInf>\r\n" + 
					"              </CstmrCdtTrfInitn>\r\n" + 
					"            </Document>";
			
			m_grpHeader = m_header.length() > 0 ? m_header.substring(this.indexOfIgnoreWhiteSpaces(m_header, "<GrpHdr"), this.indexOfIgnoreWhiteSpaces(m_header, "</BatchHeader")) 
					: GlobalConstants.EMPTY_STRING;
			m_pattern = Pattern.compile("<\\w*:?MsgId>(.*)</\\w*:?MsgId>|<\\w*:?NbOfTxs>(.*)</\\w*:?NbOfTxs>|<\\w*:?CtrlSum>(.*)</\\w*:?CtrlSum>|<\\w*:?Nm>(.*)</\\w*:?Nm>|<\\w*:?Othr>\\s*<\\w*:?Id>(.*)</\\w*:?Id>\\s*</\\w*:?Othr>|<\\w*:?Workflow>(.*)</\\w*:?Workflow>");

	        Matcher m = m_pattern.matcher(m_header);
	        while (m.find())
	        {
	        	if (m.group(1) != null) m_msgId = m.group(1);
	        	if (m.group(2) != null) m_trnsCount=Integer.parseInt(m.group(2));
	        	if (m.group(3) != null) m_ctrlSum=m.group(3);          
	        	if (m.group(4) != null) m_partyName=m.group(4);
	        	if (m.group(5) != null) m_initiatingPartyCustCode=m.group(5);
	        	if (m.group(6) != null) m_workflow=m.group(6);
	        }
			
		}
		
		private void setXmlns(String str)
		{
			m_xmlns = GlobalConstants.EMPTY_STRING;
			if (!GlobalUtils.isNullOrEmpty(str))
			{
				Pattern p = Pattern.compile("<FndtMsgBatch (.*)>");
				Matcher m = p.matcher(str);
		    	if (m.find())
		    	{
		    		m_xmlns = m.group(1);
		    	}
			}
			
		}
		
		
		private void setXmlnsPrefixes(StringBuilder prefix, String text, String tag)
		{
			if (!GlobalUtils.isNullOrEmpty(text) && !GlobalUtils.isNullOrEmpty(tag))
			{
				if (prefix.length() != 0) prefix.delete(0, prefix.length());
				Pattern p = Pattern.compile("<(.*:)"+tag);
				Matcher m = p.matcher(text);
		    	if (m.find())
		    	{
		    		prefix.append(m.group(1));
		    	}
				
			}
		}
		
		@Override
		public String next() 
		{
			
			String str = null;
			try
			{
				// retrieve next transaction
				str = remove(m_trnsEndTag, m_fndPmntTxInfPrefix.toString());
				
				// store the transaction
				m_currentTrns = str;
				updateCurrenctPmtInf(str);
				str = insertDocumentTags(str);
				str = insertGrpHdrIntoTrans(str);

				str = str.substring(indexOfIgnoreWhiteSpaces(str, m_trnsStartTag)) + ">";
				
				
				str = insertPmtInf(str);
				
//				add the name space for each FndtMsg
				str = str.replaceFirst(m_trnsStartTag + "( *)>", m_trnsStartTag + " "+m_xmlns+">");
				setXmlnsPrefixes(m_fndMsgPrefix, str, "FndtMsg");
				// update transaction counters
				m_trnsCountInPmtInf++;
			}
			catch (Exception e)
			{
				logger.error(e.getMessage());
				throw new RuntimeException(e);
			}
			return str;

		}
		
		@Override
		public String getTrnsEndTag() 
		{
			return super.getTrnsEndTag().replaceAll("</", "</"+m_fndMsgPrefix);
		}
		
		@Override
		public String getChunkEnd() {
			return super.getChunkEnd().replaceAll("</FndtMsg", "</"+m_fndPmntTxInfPrefix+"FndtMsg");
		}
		private String insertGrpHdrIntoTrans(String str)
		{
			if (m_grpHeader.length() > 0)
			{
				int beforeIndex = this.indexOfIgnoreWhiteSpaces(str, "GrpHdr");
				int afterIndex = this.indexOfIgnoreWhiteSpaces(str, "PmtInf>");
				
				if (beforeIndex < 0) beforeIndex = this.indexOfIgnoreWhiteSpaces(str, "<PmtInf");
				
				
				str = str.substring(0, beforeIndex) + m_grpHeader + str.substring(afterIndex);
			}
			
			return str;
		}
		
		@Override
		protected void updateCurrenctPmtInf(String str) 
		{
			if (m_grpHeader.length() > 0)
			{
				super.updateCurrenctPmtInf(str);
				int fromIndex = this.indexOfIgnoreWhiteSpaces(m_currentPmtInfHeader, "PmtInf");
				int toIndex = this.indexOfIgnoreWhiteSpaces(m_currentPmtInfHeader, "</PmtInf>");
				m_chunkHeader = m_currentPmtInfHeader.substring(fromIndex, toIndex);
				fromIndex = m_chunkHeader.indexOf(">");
//				remove the <PmtInf> tag from header
				m_chunkHeader = m_chunkHeader.substring(fromIndex + 1);
			}
		}
		
		private String insertPmtInf(String str)
		{
			if (!GlobalUtils.isNullOrEmpty(m_chunkHeader))
			{
				int indexPmtInf = indexOfIgnoreWhiteSpaces(str, "PmtInf");
				int indexCdtTrfTxInf = indexOfIgnoreWhiteSpaces(str, "CdtTrfTxInf");
				
				str  = str.substring(0, indexCdtTrfTxInf) + m_chunkHeader + str.substring(indexCdtTrfTxInf);
			}
			
			return str;
		}
		
		private String insertDocumentTags(String str)
		{
			if (indexOfIgnoreWhiteSpaces(str, "Document") == -1)
			{
				int cdtTrfTxInfIndex = indexOfIgnoreWhiteSpaces(str, "CdtTrfTxInf");
				int pmntEndIndex = indexOfIgnoreWhiteSpaces(str, "</Pmnt");
				
				str = str.substring(0, cdtTrfTxInfIndex) + m_documentStart + str.substring(cdtTrfTxInfIndex, pmntEndIndex) + m_documentEnd + str.substring(pmntEndIndex);
			}
			return str;
		}
		
		@Override
		public String getCurrentPmtInfHeader() {
			return "";
		}
	}
	
	public static class TransactionReaderNomina extends TransactionReader
	{
		private String NOMINA_TRNS_END_TAG = NEWLINE;
		private String NOMINA_TRNS_START_TAG = EMPTY_STRING;

		protected TransactionReaderNomina(File file) throws Exception {
			super();
			init(file);
		}
		
		protected TransactionReaderNomina(String xml) throws Exception {
			super();
			init(xml);
		}

		@Override
		protected void init() throws IOException 
		{
			String tempHeader = null;
	        // Gets the info from the file.
//			if the header remains null, then it is not xml file; this is file contains mass of single payments. 
			
			m_trnsEndTag = NOMINA_TRNS_END_TAG;
			m_trnsStartTag = NOMINA_TRNS_START_TAG;
			m_header = EMPTY_STRING;
			m_chunkEnd = NEWLINE;
			m_isSinglePayment = true;
			m_isContainFooter = false;
			updateBuffer(m_trnsEndTag);
			tempHeader = m_stringBuffer.substring(0, indexOfIgnoreWhiteSpaces(m_stringBuffer.toString(), m_trnsEndTag,m_trnsEndTag) + m_trnsEndTag.length());
			

			m_trnsCount = -1;
			m_ctrlSum = "-1";
			m_initiatingPartyCustCode = tempHeader.substring(3, 13);
	            
		}
		
		
		
	}
	
	public static class TransactionReaderNominaAsXml extends TransactionReader
	{
		private String NOMINA_TRNS_END_TAG = NEWLINE;
		private String NOMINA_TRNS_START_TAG = EMPTY_STRING;

		@Override
		protected void init() throws IOException 
		{
			String tempHeader = null;
	        // Gets the info from the file.
//			if the header remains null, then it is not xml file; this is file contains mass of single payments. 
			
			m_trnsEndTag = NOMINA_TRNS_END_TAG+"</Trns>";
			m_trnsStartTag = "<Trns>";
			m_header = "<Chunk>";
			m_chunkEnd ="</Chunk>";
			m_isSinglePayment = true;
			m_isContainFooter = false;
			updateBuffer(m_trnsEndTag);
			tempHeader = m_stringBuffer.substring(0, indexOfIgnoreWhiteSpaces(m_stringBuffer.toString(), m_trnsEndTag,m_trnsEndTag) + m_trnsEndTag.length());
			

			m_trnsCount = -1;
			m_ctrlSum = "-1";
			m_initiatingPartyCustCode = tempHeader.substring(3, 13);
	            
		}
	}

	/**
	 * @return true if the multi message type has changed, false otherwise
	 */
	public boolean isMessageTypeChanged() {
		return false;
	}

	/**
	 * It is for the same header type (one after the other) in multi type file. 
	 * In that case 2 headers in the same chunk are needed.
	 *  
	 * @return true if the multi header is required.
	 */
	public boolean isSameHeaderInChunkRequired() {
		return false;
	}

	/**
	 * @return The chunk status for the FILE_PROCESS_DISTRIBUTION table.
	 */
	public String getChunkStatus() {		
		return SubBatchProcessInterface.STATUS_WAITING;
	}
}


