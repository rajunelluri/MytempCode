package backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi;

import java.io.File;
import java.io.RandomAccessFile;

import javax.xml.namespace.QName;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.core.paymentprocess.data.paymenttypes.PaymentType;

public class FndtBatchMsg_MultiTypeBatch  extends MultiFndtMessageTypeData {
	private static final Logger logger = LoggerFactory.getLogger(FndtBatchMsg_MultiTypeBatch.class);
		
	private FndtBatchMsg_SingleTypeBatch fndtBatchMsg_SingleTypeBatch;

	public FndtBatchMsg_MultiTypeBatch() {
		super(null);
	}
	
	public FndtBatchMsg_MultiTypeBatch(String nativePaymentName) {
		this((SingleMessageTypeData)FileMessageTypeData.Factory.getFileMessageTypeData(nativePaymentName));
	}
	
	public FndtBatchMsg_MultiTypeBatch(SingleMessageTypeData nativeMessageDataType) {
		setNativeMessageDataType(nativeMessageDataType);
	}

	public void init(QName nativeMessageRoot,QName fndtMsgRoot,QName nativeHeaderRoot) {
		FndtBatchMsg_SingleTypeBatch fndtBatchMsg=new FndtBatchMsg_SingleTypeBatch();  
		fndtBatchMsg.setFndtMsgData(fndtMsgRoot);
		fndtBatchMsg.setNativeMessageData(nativeMessageRoot,nativeHeaderRoot);
		fndtBatchMsg_SingleTypeBatch=fndtBatchMsg;
	}
	
	@Override
	public String getWorkflow() {
		 return "TBD";
	}

	@Override
	public String getTypeIdentifier() {
		return "http://fundtech.com/SCL/CommonTypes";
	}

	@Override
	public String getPaymentTypeName() {
		return "FndtBatchMsg_SingleTypeBatch_"
				+ (fndtBatchMsg_SingleTypeBatch.getNativeMessageDataType()!= null 
				   ? fndtBatchMsg_SingleTypeBatch.getNativeMessageDataType().getPaymentTypeName()
				   : "unknown");
	}

	@Override
	public String getPreDocumentEnd() {
		return null;
	}

	
	/**
	 * PmtInf resides on the PmntHeader section as <PmtInf></PmtInf>
	 */
	@Override
	public String getPrePmtInfEnd() {
		return fndtBatchMsg_SingleTypeBatch.getNativeMessageDataType().PAYMENT_INFO_END_TAG;
	}

	@Override
	public XmlTransactionReaderBase getReader() {
		if (defaultCtorReader == null) {
			defaultCtorReader = new FndtBatchMsg_MultiTypeBatch_TransactionReader();
		}
		return defaultCtorReader;
	}

	
	@Override
	public XmlTransactionReaderBase getReader(File file, int chunkSize) {
		if (reader == null) {
			reader = new FndtBatchMsg_MultiTypeBatch_TransactionReader(file, chunkSize,this,"FndtFileDocument");
		}
		return reader;
	}
	
	
	@Override
	public XmlTransactionReaderBase getReaderWithoutInit(File file, int chunkSize, RandomAccessFile accessFile) {
		if (reader == null) {
			reader = new FndtBatchMsg_MultiTypeBatch_TransactionReader(file, chunkSize,this);
		}
		return reader;
	}
		
	@Override
	public void initTags(PaymentType paymentType) {
	   initNativeTags();	
	   
       this.fndtBatchMsg_SingleTypeBatch.setFNDT_MSG_EXTN_START_TAG(this.formatTagToCorrectStructure("Extn",false));
       this.fndtBatchMsg_SingleTypeBatch.setFNDT_MSG_EXTN_END_TAG(this.formatTagToCorrectStructure("Extn",true));       
	}
	
	private void initNativeTags() {
		fndtBatchMsg_SingleTypeBatch.getNativeMessageDataType().initTags(getNativeMessageDataType().paymentType);
		fndtBatchMsg_SingleTypeBatch.getNativeMessageDataType().debugTags();
	}

	public void formatTags(String namespace) {
		this.fndtBatchMsg_SingleTypeBatch.formatTags(namespace);
	}
	
	public void setNativeMessageData(QName nativeMessageRoot,QName nativeHeaderRoot) {
		this.fndtBatchMsg_SingleTypeBatch.setNativeMessageData(nativeMessageRoot,nativeHeaderRoot);
	}
	
	public void setNativeMessageDataType(SingleMessageTypeData nativeMessageDataType) {
		logger.debug("native message data type {}",nativeMessageDataType);
		this.fndtBatchMsg_SingleTypeBatch.setNativeMessageDataType(nativeMessageDataType) ;
	}
	
	public String getNativePaymentPrefix() {
		return this.fndtBatchMsg_SingleTypeBatch.getNativeMessageRoot().getPrefix();
	}
	
	public String getNativePaymentHeaderPrefix() {
		return this.fndtBatchMsg_SingleTypeBatch.getNativeHeaderRoot().getPrefix();
	}

	public String getFndtMsgPrefix() {
		return this.fndtBatchMsg_SingleTypeBatch.getFndtMsgRoot().getPrefix();
	}
	
	public SingleMessageTypeData getNativeMessageDataType() {
		return this.fndtBatchMsg_SingleTypeBatch.getNativeMessageDataType();
	}
	
	public void setFndtMsgData(QName fndtMsgPrefix) {
		getFndtBatchMsg_SingleTypeBatch().setFndtMsgData(fndtMsgPrefix);		
	}

	public String getExtnStartTag() {		
		return this.fndtBatchMsg_SingleTypeBatch.getFNDT_MSG_EXTN_START_TAG(); //FNDT_MSG_EXTN_START_TAG;
	}

	public String getExtnEndTag() {
		return this.fndtBatchMsg_SingleTypeBatch.getFNDT_MSG_EXTN_END_TAG();
	}

	
	public byte[] getExtnStartTagBytes() {		
		return getExtnStartTag().getBytes();
	}

	public byte[] getExtnEndTagBytes() {
		return getExtnEndTag().getBytes();
	}

	public FndtBatchMsg_SingleTypeBatch getFndtBatchMsg_SingleTypeBatch() {
		return fndtBatchMsg_SingleTypeBatch;
	}
	
	
}
