package backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi;



import static com.fundtech.util.GlobalConstants.BP;
import static com.fundtech.util.GlobalConstants.BPFILE;
import static com.fundtech.util.GlobalConstants.RT;
import static com.fundtech.util.GlobalConstants.RTFILE;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.businessobject.BOProxies;
import backend.paymentprocess.debulkingprocess.common.WorkflowType;
import backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi.ByteArrayListOptimized.FindWordResponse;
import backend.paymentprocess.enrichment.commons.InterfaceSubTypeFlow;

import com.fundtech.cache.entities.FileSummary;
import com.fundtech.cache.entities.InterfaceTypes;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.paymentprocess.data.DefaultDeepPDOCloneHandler.CloningContext;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.scl.debulkingProcessService.FileIndexDataType;
import com.fundtech.scl.debulkingProcessService.PerformDebulkingMultiRequestDocument;
import com.fundtech.scl.debulkingProcessService.PerformDebulkingMultiRequestType;
import com.fundtech.scl.debulkingProcessService.PreStartDataType;
import com.fundtech.util.ExceptionController;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalUtils;

/**
 * SingleXmlTransactionReader for pain 01 and 08
 *
 */
public class PainTransactionReader extends SingleXmlTransactionReader
{

	private static final Logger logger = LoggerFactory.getLogger(PainTransactionReader.class);
	private static boolean bPrintTime = false;
	private long m_prePmtInfoStartIndexTemp = GlobalConstants.DEFAULT_NOT_FOUND_VALUE;
	private long m_prePmtInfoEndIndexTemp = GlobalConstants.DEFAULT_NOT_FOUND_VALUE;
	private ArrayList<FileIndexDataType> listFileIndexDataType = null;
	private ArrayList<PreStartDataType>  listPreStartDataType= null;
	FindWordResponse response = null;
	PreStartDataType[] arrayPreStartDataType = null;
	String newSchemeString = null;
	byte[] newSchemeBytes = null;
	PreStartDataType preStart = null;

	public PainTransactionReader ()
	{
		initMembers();
	}
	//Ctor
	public PainTransactionReader (File file,int chunkSize,FileMessageTypeData fileMessageTypeData)
	{
		super(file,chunkSize,fileMessageTypeData);
		initMembers();
	}

	public PainTransactionReader (File file,RandomAccessFile raf, int chunkSize,FileMessageTypeData fileMessageTypeData)
	{
		super(file,raf, chunkSize,fileMessageTypeData);
		initMembers();
	}

	@Override
	public void initHeader() throws IOException 
	{
		//Gets the info from the file.
		setPattern(Pattern.compile(COMPILE_PATTERN));
        Matcher m = getPattern().matcher(getHeader());
        getRandomeFile().seek(getByteCount());
        getUtils().setM_raf(getRandomeFile());

        while (m.find())
        {
        	if (m.group(1) != null) setMsgId(m.group(1));
        	if (m.group(2) != null) setTrnsCount(Integer.parseInt(m.group(2)));
        	if (m.group(3) != null) setCtrlSum(m.group(3));
        	if (m.group(4) != null) setPartyName(m.group(4));
        	if (m.group(5) != null) setInitiatingPartyCustCode(m.group(5));
        }//while
	}
	
	public void initPmtInf() throws IOException
	{
		//Gets payment info from the file-this done in order to get the PmtInfId for duplicate file check in Deut bank
		setPattern(Pattern.compile(COMPILE_PATTERN_PMTINF));
		Matcher m = getPattern().matcher(getPmtInfId());
    
	    while (m.find())
	    {
	    	if (m.group(1) != null) setPmtInfId(m.group(1));
	    	
	    }//while
	}

	@Override
	public void init() throws IOException 
	{
		if (m_bIsinitialized)
			return;
		
		m_bIsinitialized = true;
		
		INTERFACE_TYPE = InterfaceTypes.INTERFACE_TYPE_MASSPMNTS;
		INTERFACE_SUB_TYPE = InterfaceTypes.INTERFACE_SUB_TYPE_DEB;
		setSinglePayment(false);

//		setDocPreStartTagIndex(0); //Will be set in SingleXmlTransactionReader::readDocumentStartData
		setHeader(getUtils().getFileSectionFromIndexes(getDocPreStartTagIndex(), getPrePmtInfoStartIndex()));
		setPmtInfId(getUtils().getFileSectionFromIndexes(getPrePmtInfoStartIndex(), getPrePmtInfoEndIndex()));
		
		
		
		initHeader();
		initPmtInf();

        this.getByteBuffer().removeRangeFromBeginning((int)this.getPrePmtInfoEndIndex());
		this.setTotalDeleted(this.getTotalDeleted() + getPrePmtInfoEndIndex());
	}//EOM init()

	public void testMethod()
	{
		//Gets the info from the file.
		setCompiledPattern();
		setPattern(Pattern.compile(COMPILE_PATTERN));
		setHeader(new String(getByteBuffer().returnActualArray()));
        Matcher m = getPattern().matcher(getHeader());

        while (m.find())
        {
        	if (m.group(1) != null) setMsgId(m.group(1));
        	if (m.group(2) != null) setTrnsCount(Integer.parseInt(m.group(2)));
        	if (m.group(3) != null) setCtrlSum(m.group(3));
        	if (m.group(4) != null) setPartyName(m.group(4));
        	if (m.group(5) != null) {setInitiatingPartyCustCode(m.group(5)); break;};

        }//while
	}

	public void initMembers()
	{
		INTERFACE_TYPE = InterfaceTypes.INTERFACE_TYPE_MASSPMNTS;
		INTERFACE_SUB_TYPE = InterfaceTypes.INTERFACE_SUB_TYPE_DEB;
		newSchemeBytes =XML_NAMESPACE.getBytes();
		listFileIndexDataType = new ArrayList<FileIndexDataType>();
		initPreStartDataType();
	}

	public void initPreStartDataType() {
		preStart = PreStartDataType.Factory.newInstance();
		preStart.setPreDocumentStartTag(getDocPreStartTagIndex());
		preStart.setPreDocumentEndTag(getDocPreEndTagIndex());
		preStart.setPrePmtInfStartTag(getGlobalHeaderStartTagIndex());
		preStart.setPrePmtInfEndTag(getGlobalHeaderEndTagIndex());
		arrayPreStartDataType = new PreStartDataType[] {preStart};
		listPreStartDataType = new ArrayList<PreStartDataType>();		

	}
	
	public void initPreTransaction()
	{
//		preStart = PreStartDataType.Factory.newInstance();
//
//		preStart.setPreDocumentStartTag(m_docPreStartTagIndex);
//
//
//		preStart.setPreDocumentEndTag(m_docPreEndTagIndex);
//		preStart.setPrePmtInfStartTag	(m_globalHeaderStartTagIndex);
//		preStart.setPrePmtInfEndTag		(m_globalHeaderEndTagIndex);
//		arrayPreStartDataType[0] = preStart;
	}

	
	@Override
	protected boolean readTransactionsOfChunkSize()
	{

//		if (this.m_isFromMultiReader)
//			preStart.setPreDocumentStartTag(0 + this.m_totalDeleted);

		int transactionStartTagIndex = GlobalConstants.DEFAULT_NOT_FOUND_VALUE;
		int transactionEndTagIndex = GlobalConstants.DEFAULT_NOT_FOUND_VALUE;

		byte[] transactionStartTagBytes = getFileMessageTypeData().getTransactionStartTagBytes();
		byte[] transactionEndTagBytes = getFileMessageTypeData().getTransactionEndTagBytes();

		String newSchemeString = new String("xmlns");
		
		int transactionEndTagLength = transactionEndTagBytes.length;

		listFileIndexDataType.clear();
		listPreStartDataType.clear();


		// TODO outside the loop?
		if (listPreStartDataType.isEmpty())
			listPreStartDataType.add(preStart);
		ArrayList<byte[]> listStartTran = new ArrayList<byte[]>();

		// add to the list the tag of new scheme which is global and same for all FileMessageDataType
		//listStartTran.add(m_fileMessageTypeData.getPaymentInfoElementStartTagBytes());
		listStartTran.add(getFileMessageTypeData().getTransactionStartTagBytes());
		// arraylist contain the tags that should appear/checked before new
		// transcation collection is being made (for example - if the transaction scheme
		// is different than the previous ones.
		ArrayList<byte[]> listEndTran = new ArrayList<byte[]>();
		listEndTran.add(getFileMessageTypeData().getTransactionEndTagBytes());

		try {
			if (getPrePmtInfoStartIndex() == -1)
				setPrePmtInfoStartIndex(this.findAndReadTillNearestTagInChunk(getFileMessageTypeData().getPaymentInfoElementStartTagBytes(), (int)(getGlobalHeaderEndTagIndex() - this.getTotalDeleted())) + this.getTotalDeleted());
			if (getPrePmtInfoEndIndex() == -1)
			{
				int temp1 =  this.findAndReadTillNearestTagInChunk(transactionStartTagBytes, (int)(getPrePmtInfoStartIndex() - this.getTotalDeleted()));
				setPrePmtInfoEndIndex(this.findAndReadTillNearestTagInChunk(transactionStartTagBytes, (int)(getPrePmtInfoStartIndex() - this.getTotalDeleted())) + this.getTotalDeleted()) ;
				preStart.setPrePmtInfEndTag(getPrePmtInfoEndIndex());
				this.getByteBuffer().removeRangeFromBeginning(temp1);
				this.setTotalDeleted(this.getTotalDeleted() + temp1);
			}
		}
		catch (IOException e) {
			ExceptionController.getInstance().handleException(e, this);
			throw new RuntimeException("Problem reading " + getByteCount() + " chunk");
		}
		long batchIndex=-1;
		try {
		transactionStartTagIndex = this.findAndReadTillNearestTagInChunk(transactionStartTagBytes ,transactionStartTagIndex);
		/*
		 As per Ronen and Mina BP pain payment is not valid after payment transformation , remove this code as it causes shifts in the BUffer (RandomAccessFile)
		batchIndex=this.findAndReadTillNearestTagInChunk("<FndtMsgBatch".getBytes(),transactionStartTagIndex);
		if(batchIndex!=-1)
			batchIndex+= this.getTotalDeleted();*/

		//Till the end of file and no more End tags exists or CHUNK is ready or PaymentInfo section has been changed
		while ((getByteCount() < getFileSize() || transactionStartTagIndex != -1)
				&& listFileIndexDataType.size() < getChunkSize())
		{

			if(listener!=null && listener.isBulkEnd())
				break;
				
				// look for the first appearing tag from the start transaction
				// tag list

				// if new scheme indicating tag found, change the scheme
				// means a tag indicating a new transaction is found

				// get new file index data type which will conation the
				// indexes of the transcation
				FileIndexDataType fileInfo = FileIndexDataType.Factory.newInstance();
				// set the transaction starting tag index
				fileInfo.setTransactionStartTag(transactionStartTagIndex + this.getTotalDeleted());
				// find the end of the transcation
				transactionEndTagIndex = this.findAndReadTillNearestTagInChunk(transactionEndTagBytes,(int)transactionStartTagIndex+ transactionStartTagBytes.length);

				// set the transaction end tag index
				fileInfo.setTransactionEndTag(transactionEndTagIndex + transactionEndTagLength + this.getTotalDeleted());
				
				// delete the buffer untill the end of the transcation
				this.getByteBuffer().removeRangeFromBeginning(transactionEndTagIndex + transactionEndTagLength);
				this.setTotalDeleted(this.getTotalDeleted() + (transactionEndTagIndex + transactionEndTagBytes.length));
				
				fileInfo.setPaymentInfoStartTag(getPrePmtInfoStartIndex());
				fileInfo.setPaymentInfoEndTag(getPrePmtInfoEndIndex());
				// END PAYMENT INFO
				fileInfo.setPaymentInfoElementStartTag(getFileMessageTypeData().getPaymentInfoElementStartTag());

				fileInfo.setPaymentType(getFileMessageTypeData().getPaymentTypeName());
				fileInfo.setPaymentInfoElementStartTag(getFileMessageTypeData().getPaymentInfoElementStartTag());

				listFileIndexDataType.add(fileInfo);
				if(listener != null){
					listener.onTransactionEnded(this, fileInfo);
					listener.onBulkEnd(batchIndex,fileInfo.getTransactionEndTag(),transactionStartTagIndex+getTotalDeleted());
				}
				setNumOfTrxActuallyReadFromFile(getNumOfTrxActuallyReadFromFile()+ 1);
				transactionStartTagIndex = this.findAndReadTillNearestTagInChunk(transactionStartTagBytes ,0);
				
				if (transactionStartTagIndex > -1 && !isFndtBatchMsgContext() || (listener!=null && listener.isBulkEnd())){
					int temp =getByteBuffer().indexOfWithStartEndIndex(getFileMessageTypeData().getPaymentInfoElementStartTagBytes(), 0, transactionStartTagIndex);
					if (temp != -1)
					{
						long totalDeleted = getTotalDeleted();
						setPrePmtInfoStartIndex(totalDeleted + temp);
						setPrePmtInfoEndIndex(totalDeleted + transactionStartTagIndex);
						break;
					}
				}
			}// try
			
		}
		catch (Exception e) {
			ExceptionController.getInstance().handleException(e, this);
			throw new RuntimeException("Problem reading " + getByteCount()
					+ " chunk");
		}
		if(!GlobalUtils.isListNullOrEmpty(listFileIndexDataType))
		{
			//set arrFileIndexDataType
			FileIndexDataType[] arrFileIndexDataType = new FileIndexDataType[listFileIndexDataType.size()];
			getCurrentChunk().getPerformDebulkingMultiRequest().setFileIndexDataTypeListArray(listFileIndexDataType.toArray(arrFileIndexDataType));

			//PreStartDataType[] arrPreStartDataType = new PreStartDataType[listPreStartDataType.size()];
			getCurrentChunk().getPerformDebulkingMultiRequest().setPreStartDataListArray(arrayPreStartDataType);

			getCurrentChunk().getPerformDebulkingMultiRequest().setEndTags(getFileMessageTypeData().getXmlClosingTags());
			return true;
		} else {
			logger.debug("no more transaction on file");
			return false;
		}


	}//EOM readTransactionsOfChunkSize


	/**
	 * receives a word list and a start index and search for the nearest
	 * appearance of any of the words, reads from file if needed until the any
	 * of the words is found, returns the first found word and it's index
	 *
	 * @param startIndex - start index to look from
	 * @param tags - word list (converted to bytes)
	 * @return - first found word and its index on the file.
	 * @throws IOException
	 */
		protected FindWordResponse findAndReadTillNearestTagsInChunk(int startIndex, ArrayList<byte[]> tags) throws IOException {
		FindWordResponse response= getByteBuffer()
							.indexOfFirstAppearingWord(tags, startIndex);
		while (response.getLocation()== -1) {
			if (getByteCount() >= getFileSize())
				break;
			int temp = getByteBuffer().getSize();
			// Read next chunk
			setSize(getFileSize() - getByteCount() > BUFFER_SIZE ? BUFFER_SIZE
					: getFileSize() - getByteCount());
			setByteCount(getByteCount() + getSize());
			// set startIndex to the last checked index to avoid duplicate search
			startIndex = getByteBuffer().getSize();
			getUtils().getM_raf().seek(getByteCount());
			getUtils().readToByteArrayListEnd(this.getByteBuffer(), (int)getSize());
			//m_totalDeleted += m_byteBuffer.size();
			response = getByteBuffer().indexOfFirstAppearingWord(tags, temp - 30);

		}
		return response;
	}



	@Override
	public int getRecCountInChunk (Object chunk)
	{
		PerformDebulkingMultiRequestDocument doc = (PerformDebulkingMultiRequestDocument)chunk;
		PerformDebulkingMultiRequestType debulkingMultyRequest = doc.getPerformDebulkingMultiRequest();
		return debulkingMultyRequest.getFileIndexDataTypeListArray().length;
	}

	@Override
 	public String getXmlofChunk(Object chunk)
	{
		PerformDebulkingMultiRequestDocument doc = (PerformDebulkingMultiRequestDocument)chunk;
		return doc.xmlText();
	}

	
	 public List<PDO> getPDOsFromChunk(PerformDebulkingMultiRequestDocument doc,String chunkId, String sInternalFileID,final FileSummary fileSummary,
			  final Map[] arrMapSharedPDOContextHolder) throws Throwable
	  {
	  	String sTracePrefix = null ;
	  		sTracePrefix = String.format("'getPDOsFromChunk', (internal file ID: %s, chunk ID: %s); ", sInternalFileID, chunkId);
	  	

	  	logger.info(sTracePrefix + "calls 'BODebulkFile.debulkFile' for parsing passed XML chunk content...");
	  	FileIndexDataType[] arr = doc.getPerformDebulkingMultiRequest().getFileIndexDataTypeListArray();
	  	logger.info(sTracePrefix + "after call to 'BODebulkFile.debulkFile'; size of returned list: {}", arr.length);
	    String officeCurrency = CacheKeys.banksKey.getSingle(fileSummary.getOffice()).getCurrency();
	    String endTags 			= doc.getPerformDebulkingMultiRequest().getEndTags();
	    PreStartDataType preStartDataType = doc.getPerformDebulkingMultiRequest().getPreStartDataListArray()[0];
	    long preDocumentStartTag = preStartDataType.getPreDocumentStartTag();
	    long prePmtInfEndTag 	= preStartDataType.getPrePmtInfEndTag();
	    long paymentInfoStartTag = arr[0].getPaymentInfoStartTag();
	    RandomAccessFileUtils utils = getFileUtils(doc);
	    List<PDO> pdoList;
	    try
	    {
			String documentPartTillFirstTransaction2 = utils.getDocumentPartTillFirstTransaction(preDocumentStartTag,prePmtInfEndTag,paymentInfoStartTag,arr[0].getPaymentInfoEndTag()
					,endTags,true,true,false/*isMulti*/,null/*fileMessageTypeData*/);

			String documentPartTillFirstTransaction = documentPartTillFirstTransaction2.replaceFirst("<S2SCTIcf:FIToFICstmrCdtTrf", "<Document");

			CloningContext[] context = new CloningContext[1];
		    PDO templatePDO=createTemplatePDO(documentPartTillFirstTransaction, arrMapSharedPDOContextHolder, officeCurrency,sInternalFileID, chunkId, fileSummary, fileSummary.getMsgType()
		    		,fileSummary.getInitgPtyCustCode(),context);
		    boolean isDD = templatePDO.getNSetMsgTypes().getMsgClass().indexOf("DD") > -1;
		    String trnsInfoLogicalField = isDD ? "X_DIRECT_DBT_TRNF_INFO" : PDOConstantFieldsInterface.X_CDT_TRNF_INFO;

		    pdoList = createIndividualPayments(templatePDO, utils, arr, prePmtInfEndTag, endTags, preDocumentStartTag, preStartDataType.getPrePmtInfStartTag(), trnsInfoLogicalField,
	    			context, sTracePrefix,chunkId);

	    }finally
	    {
	    	utils.dispose();
	    }

	    
	    return pdoList;
   }

   
	private List<PDO> createIndividualPayments(PDO templatePDO,RandomAccessFileUtils utils, FileIndexDataType[] arr, long prePmtInfEndTag, String endTags, long preDocumentStartTag,
			long prePmtInfStartTag, String trnsInfoLogicalField, CloningContext[] context, String sTracePrefix,Object chunkId ) throws Throwable
	{
    	final List groups = CacheKeys.LogicalFieldsXPathGroupsKey.get(null, templatePDO.getPaymentType("XML_MSG"), "XML_MSG");

    	StringBuilder sb = new StringBuilder();
		String documentPartTillFirstTransaction2 =
			utils.getDocPartTillFirstTransaction(preDocumentStartTag,prePmtInfEndTag,prePmtInfStartTag,prePmtInfEndTag,endTags,false,false,arr[0].getPaymentInfoElementStartTag());

		String documentPartTillFirstTransaction = documentPartTillFirstTransaction2.replaceFirst("<S2SCTIcf:FIToFICstmrCdtTrf", "<Document");
		List<PDO> pdoList = new ArrayList<PDO>();
  	    for (FileIndexDataType fileIndexDataType : arr)
  	    {
  	    	//Xml document without payment info section
  	    	sb.append(documentPartTillFirstTransaction);

  	    	//PaymentInfo Element
  	    	//sb.append(Utils.getFileSectionFromIndexes(file,fileIndexDataType.getPaymentInfoStartTag(),fileIndexDataType.getPaymentInfoEndTag()));
  	    	//Transaction Element
  	    	sb.append(utils.getFileSectionFromIndexes(fileIndexDataType.getTransactionStartTag(),fileIndexDataType.getTransactionEndTag()));
  	    	sb.append(endTags);
  	    	//sb.append(endTags.replace("</PmtInf>",""));

  	    	PDO pdo = PaymentDataFactory.clonePDO(context[0], sb.toString(), trnsInfoLogicalField, true, groups);
  	    	pdo.set(PDOConstantFieldsInterface.P_IS_HISTORY, WorkflowType.MP_PARTITION);
  	    	pdo.set(PDOConstantFieldsInterface.X_TX_NO, 1+"");
  	    	String sMID = pdo.getMID();
  	    	pdoList.add(pdo);

	    	logger.info("{} created individual PDO - MID: {}, Status: {}, Chunk ID: {}, PDO ID: {}" 
	    		,new Object[]{sTracePrefix,  sMID, pdo.getString(PDOConstantFieldsInterface.P_MSG_STS), chunkId, pdo});

	    	sb.delete(0,sb.length());

		}//for

  	    return pdoList;
	}
	private PDO createTemplatePDO(String documentPartTillFirstTransaction,Map[] arrMapSharedPDOContextHolder, String officeCurrency, String internalFileID, String chunkId,
			FileSummary fileSummary, String msgType, String sFileSummary_INITG_PTY_CUST_CODE,CloningContext[] context) throws Exception
	{		
		String sBusinessFlowType = InterfaceSubTypeFlow.getFlowType(fileSummary.getPlFileType());
		PDO templatePDO = PaymentDataFactory.newPDO(documentPartTillFirstTransaction,true/*bTransient*/, true, true/*bConjoinedMode*/, null, GlobalConstants.BP.equals(sBusinessFlowType));
		boolean isBPFlow = BPFILE.equals(fileSummary.getPlFileType());

		Admin.enrichMDC("T");
	    templatePDO.set("D_DEBULKING_TEMPLATE_PDO",isBPFlow ? "" : "true");
		
	    arrMapSharedPDOContextHolder[0] = templatePDO.getSharedContext() ;

	    templatePDO.set(PDOConstantFieldsInterface.X_STTLM_CCY, officeCurrency);
	    templatePDO.set(PDOConstantFieldsInterface.X_STTLM_AMT, new BigDecimal(0));
	    templatePDO.set(PDOConstantFieldsInterface.P_IN_INTERNAL_FILEID, internalFileID);
	    templatePDO.set(PDOConstantFieldsInterface.P_BUSINESS_FLOW_TP, sBusinessFlowType);
	    
	    //templatePDO.getNSetIncomingFileSummary();
	    templatePDO.setIncomingFileSummary(fileSummary) ;
	    
	    logger.debug("executing pre processing on template PDO");
	    Feedback feedback = BOProxies.m_processFlowsLocal.performLowValuePreProcessingPaymentSubFlow(Admin.getContextAdmin(), templatePDO.getMID());
	    context[0]= new CloningContext(templatePDO, null/*sCreationMID*/, null/*cloneHandler*/, arrMapSharedPDOContextHolder[0]);

	    templatePDO.set(PDOConstantFieldsInterface.P_RAW_MSG_TYPE, msgType);
	    templatePDO.set(PDOConstantFieldsInterface.P_ORG_INITG_PTY_CUST_CD, sFileSummary_INITG_PTY_CUST_CODE);
	    // Sets chunk ID.
	    templatePDO.set(PDOConstantFieldsInterface.P_CHUNK_ID, chunkId);
	    
	    Admin.clearMDC();
	    templatePDO.set("D_DEBULKING_TEMPLATE_PDO","");
	    
	    logger.debug("template PDO {}",templatePDO);
	    
	    return templatePDO;
	}

	protected int findAndReadTillNearestTagInChunk(byte[] tag, int startIndex) throws IOException {
		// check if there is occurrence of the tag in the current chunk.
		int index = getByteBuffer()
							.indexOf(tag, startIndex);
		while (index == -1) {
			if (getByteCount() >= getFileSize())
				break;
			int temp = getByteBuffer().getSize();
			// Read next chunk
			setSize(getFileSize() - getByteCount() > BUFFER_SIZE ? BUFFER_SIZE
					: getFileSize() - getByteCount());
			startIndex = getByteBuffer().getSize();
			getUtils().getM_raf().seek(getByteCount());;
			getUtils().readToByteArrayListEnd(this.getByteBuffer(), (int)getSize());
			setByteCount(getByteCount() + getSize());
			// set startIndex to the last checked index to avoid duplicate search


			index = getByteBuffer()
						.indexOf(tag, temp - tag.length);

		}
		return index;
	}
	@Override
	public void init(InputStream inputStream) throws Exception {
		// TODO Auto-generated method stub
		
	}
	@Override
	public long getBatchIndexOffset() {
		// TODO Auto-generated method stub
		return 0;
	}
	

}//EOC Pain001TransactionReader
