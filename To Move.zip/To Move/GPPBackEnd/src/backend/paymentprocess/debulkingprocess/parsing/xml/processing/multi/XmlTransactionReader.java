package backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi;

import static backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi.XmlParsingHelper.makeConcretePrefix;
import static com.fundtech.util.GlobalDateTimeUtil.ISO_NORMALIZED_DATE_TIME;
import static com.fundtech.util.GlobalDateTimeUtil.XML_SCHEMA_DATE_TIME_CANNONICAL;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.stream.XMLStreamException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.cache.entities.FileSummary;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.scl.debulkingProcessService.PerformDebulkingMultiRequestDocument;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalFileUtil;
import com.fundtech.util.GlobalUtils;


/**
 * This abstract class implements the XmlTransactionReaderBase.
 * It will read and index the file global header and delegates the transaction reading and indexing to it's descendants.
 *
 * @author haimv
 * @author dmitryp
 */
public abstract class XmlTransactionReader implements XmlTransactionReaderBase {
	private static final Logger logger = LoggerFactory.getLogger(XmlTransactionReader.class);
	
	protected String COMPILE_PATTERN;
	protected String COMPILE_PATTERN_PMTINF;

	protected String PMT_INF_START_TAG = "<PmtInf";
	final String TRACE_METHOD_RESULT = "method result: %s";
	protected final String XML_NAMESPACE = "xmlns";

	private boolean m_isFromMultiReader = false;
	protected boolean m_bIsinitialized = false;
	private String m_header;
	private Pattern m_pattern;
	private String m_msgId;
	private String m_pmtInfId;
	private String m_ctrlSum;
	private String m_partyName;
	private String m_namespacePrefix; //the namespace prefix
	private String m_headerNamespacePrefix; //option to different namespace of the Header (FndtBatchMsg)
	private String m_initiatingPartyCustCode;
	private String sendingInst;
	private String receivingInst;
	private String senderName;
	private String fileReference;
	private String relatedFileReference;
	private String fileSource;
	private int NumCTBlk;
	private int NumDDBlk;
	private int calcNumCTBlk;
	private int calcNumDDBlk;
	private Date fileDtTm;
	
	private String m_office;
	private String m_fileName;
	private String m_fileType;
	private Date m_businessDate;
	private File m_file;
	private int m_chunkSize;
	private String m_internalFileId;
	protected int numOfTrxActuallyReadFromFile;

	private String bulkCreDtTm;
	private long bulkNumOfTx;
	private BigDecimal bulkTotalAmt;
	private long bulkCtrlSum;
	private boolean isNewBulk;
	protected String bulkType;

	private boolean m_isSinglePayment = false;

	private int m_pmtInfCount = 0;
	private int m_trnsCount 	= 0; // Number of transactions from the file header; once set, shouldn't be changed.
	private Date m_appHdrCreDt; 	 // Date of file AppHdr CreDt;
	private String m_appHdrBizMsgIdr;
	//Reading file members
	private PerformDebulkingMultiRequestDocument m_currentChunk = null;
	private Set<FileMessageTypeData> supportedTypes = null;
	private FileMessageTypeData m_fileMessageTypeData = null;
	private RandomAccessFile m_randomeFile = null;
	protected int BUFFER_SIZE = 2048;
	private long m_byteCount = 0;
	private ByteArrayListOptimized m_byteBuffer = null;
	private long m_lFileSize = 0;
	private long m_size = 0;
	private long m_totalDeleted = 0;

	private long m_globalHeaderStartTagIndex 	= GlobalConstants.DEFAULT_NOT_FOUND_VALUE;
	private long m_globalHeaderEndTagIndex 	= GlobalConstants.DEFAULT_NOT_FOUND_VALUE;
	private long m_docPreStartTagIndex 		= GlobalConstants.DEFAULT_NOT_FOUND_VALUE;
	private long m_docPreEndTagIndex 			= GlobalConstants.DEFAULT_NOT_FOUND_VALUE;
	private long m_prePmtInfoStartIndex 		= GlobalConstants.DEFAULT_NOT_FOUND_VALUE;
	private long m_prePmtInfoEndIndex 		= GlobalConstants.DEFAULT_NOT_FOUND_VALUE;
	private long m_postTagsStartIndex 		= GlobalConstants.DEFAULT_NOT_FOUND_VALUE;
	private long m_postTagsEndIndex 			= GlobalConstants.DEFAULT_NOT_FOUND_VALUE;
	protected String INTERFACE_TYPE;
	protected String INTERFACE_SUB_TYPE;
	private RandomAccessFileUtils m_utils = null;
	protected boolean hasMoreBulks = false;
	private  int newSchemeIndex = -1;
	private  int newSchemeIndexEnd = -1;
 	// default schema contains transaction number in header
	protected boolean headerContainsNumberOfTransactions = true;
	
	protected int lastTransactionEndInd = 0;
	protected boolean isDDBulkwasProcessed = false;
	protected boolean isCTBulkwasProcessed = false;
	protected XmlTransactionReaderListener listener;
	
	public void initMembers() {}
	public void testMethod() {}

	public XmlTransactionReader()
	{
	}
		//Ctor
	public XmlTransactionReader(File file,int chunkSize,FileMessageTypeData fileMessageTypeData){
		this.setFile(file);
		this.setChunkSize(chunkSize);

		try {
			setRandomeFile(new RandomAccessFile(file, "r"));
			setFileSize(getRandomeFile().length()) ;
		} catch (FileNotFoundException e1) {
			// TODO
			logger.error(e1.getMessage());
		} catch (IOException e) {
			// TODO
			logger.error(e.getMessage());
		}
		setUtils(new RandomAccessFileUtils(getFile()));
		// TODO Remove hard - coded supported types

		setCurrentChunk(PerformDebulkingMultiRequestDocument.Factory.newInstance());
		getCurrentChunk().addNewPerformDebulkingMultiRequest();


			setFileMessageTypeData(fileMessageTypeData);


			// Read global header
			setByteBuffer(new ByteArrayListOptimized());

			setSize(getFileSize() - getByteCount() > BUFFER_SIZE ? BUFFER_SIZE : getFileSize() - getByteCount());
			setByteCount(getByteCount() + getSize());

			getUtils().readToByteArrayListEnd(getByteBuffer(), (int)getSize());


			evaluateAndSetXmlNamespacePrefix(new String(getByteBuffer().returnActualArray()),"Document");
			//m_byteBuffer.removeRangeFromBeginning((int)m_size);

			//Add namespace to all tags
			getFileMessageTypeData().formatTags(getNamespacePrefix());

			readDocumentStartData();
			readPreTransactionData();

			setCompiledPattern();

			try {
				init();
			} catch (Exception e) {
				logger.error("",e);
			}

		}

	
	public boolean headerContainsNumberOfTransactions() {
		return this.headerContainsNumberOfTransactions;
	}

	
	public int getNumOfTrxActuallyReadFromFile() {
		return numOfTrxActuallyReadFromFile;
	}
	public void setNumOfTrxActuallyReadFromFile(int numOfTrxActuallyReadFromFile) {
		this.numOfTrxActuallyReadFromFile = numOfTrxActuallyReadFromFile;
	}
	
	
	public String getInterfaceSubType() {
		return this.INTERFACE_SUB_TYPE;
	}

	public Date getBusinessDate() {
		return this.m_businessDate;
	}

	public String getInterfaceType() {
		return this.INTERFACE_TYPE;
	}

	public String getFileType() {
		return this.m_fileType;
	}


	public String getInternalFileId() {
		return m_internalFileId;
	}

	public void setInternalFileId(String m_internalFileId) {
		this.m_internalFileId = m_internalFileId;
	}

	public String getRelatedFileReference() {
		return relatedFileReference;
	}
	public void setRelatedFileReference(String relatedFileReference) {
			this.relatedFileReference = relatedFileReference;
	}

	public String getFileReference() {
		if(fileReference==null)
			return getMsgId();
		return fileReference;
	}
	public void setFileReference(String fileReference) {
		if(this.fileReference==null)
			this.fileReference = fileReference;
	}
	public String getFileSource() {
		return fileSource;
	}
	public void setFileSource(String fileSource) {
		this.fileSource = fileSource;
	}
	public XmlTransactionReader(File file, RandomAccessFile raf,int chunkSize,FileMessageTypeData fileMessageTypeData)
	{
		this.setFile(file);
		this.setRandomeFile(raf);
		this.setChunkSize(chunkSize);
		this.setFileMessageTypeData(fileMessageTypeData);
		//readPreTransactionData();
	}//Ctor

	public abstract void setAdditionalDocumentData(Object request, String chunkId, String status, String internalFileId, String path, String workFlow, String bulkId);

	protected void setCompiledPattern()
	{
		COMPILE_PATTERN = "<%sMsgId>(.*)</%sMsgId>|<%sNbOfTxs>(.*)</%sNbOfTxs>|<%sCtrlSum>(.*)</%sCtrlSum>|<%sNm>(.*)</%sNm>|<%sOthr>\\s*<%sId>(.*)</%sId>";
		COMPILE_PATTERN_PMTINF="<%sPmtInfId>(.*)</%sPmtInfId>";
		String prefix = makeConcretePrefix(getHeaderNamespacePrefix());
		String pmtHeder= makeConcretePrefix(getPmtInfPrefix());		
		this.COMPILE_PATTERN = this.COMPILE_PATTERN.replace("%s",prefix);
		this.COMPILE_PATTERN_PMTINF=this.COMPILE_PATTERN_PMTINF.replace("%s",pmtHeder);
		
	}
	
	protected abstract void readPreTransactionData();
	protected abstract void readDocumentStartData();

	public String getWorkflow(){
		return getFileMessageTypeData().getWorkflow();
	}


	public void initPreTransaction() {}

	public static XmlTransactionReaderBase createXmlTransactionReader(File file,int chunkSize) {
		return getXmlTransactionReader(file,chunkSize);

	}//EOF XmlTransactionReader

	public boolean isSinglePayment(){
		return m_isSinglePayment;
	}



	public String getOffice(){
		return m_office;
	}
	
	public void setOffice(String office){
		m_office = office;
	}

	public String getFileName(){
		return m_fileName;
	}

	public String getMsgId() {
		return m_msgId;
	}
	
	public void setMsgId(String msgId) {
		logger.debug("message Id: '{}'",msgId);
		this.m_msgId = msgId;
		setFileReference(m_msgId);
	}
	
	public String getPmtInfId() {
		return m_pmtInfId;
	}

	public int getPmtInfCount() {
		return m_pmtInfCount;
	}

	public int getTrnsCount() {
		return m_trnsCount;
	}
	
	public String getAppHdrBizMsgIdr(){
		return m_appHdrBizMsgIdr;
	}
	
	public Date getAppHdrCreDt(){
		return m_appHdrCreDt;
	}

	public String getCtrlSum() {
		return m_ctrlSum;
	}

	public String getPartyName() {
		return m_partyName;
	}

	public String getInitiatingPartyCustCode() {
		return m_initiatingPartyCustCode;
	}
	
	public String getSendingInst() {
		return sendingInst;
	}	
	
	public String getReceivingInst() {
		return receivingInst;
	}
	public Date getFileDtTm() {
		return fileDtTm;
	}
	public void setFileDtTm(Date fileDT) {
		this.fileDtTm = fileDT;
	}
	/**
	 *  Abstract method for reading and indexing the transactions header,start and end tags.
	 *  Read and index the file global header and delegates the transaction reading and indexing to it's descendants using readTransactions abstract method
	 */
	protected abstract boolean readTransactionsOfChunkSize();


	public void initHeader ()  throws IOException {
	}
	
	public void initPreStartDataType ()  throws IOException {		
	}
	

//	@Override
	public boolean hasNext()
	{
		return readTransactionsOfChunkSize();

	}//EOM hasNext
	
	public boolean hasMoreBulks()
	{
		return hasMoreBulks;
	}

	//@Override
	public Object next() {

		return getCurrentChunk();
	}

	//@Override
	public void remove() {

		try {
			getUtils().dispose();
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		try
		{			
			getRandomeFile().close();
		} catch (IOException e) {
			logger.error(e.getMessage());
		}		

	}//EOM remove

	protected void evaluateAndSetXmlNamespacePrefix(String str, String tagElement)
	{
		//<Document xmlns="urn:iso:std:iso:20022:tech:xsd:pain.001.001.03">
		//xmlns:xhtml="http://www.w3.org/1999/xhtml"  --->> For example, the following declaration maps the "xhtml:" prefix
		//xmlns="http://www.w3.org/1999/xhtml"
		setNamespacePrefix(GlobalConstants.EMPTY_STRING);

		if (!GlobalUtils.isNullOrEmpty(str))
		{
			//First line may be:
			//<?xml version='1.0' encoding='UTF-8'?>

//			Pattern p = Pattern.compile("xmlns(.*)=");;
			Pattern nsPattern = Pattern.compile("xmlns:([a-zA-Z0-9]+)=");
			Matcher nsMatcher = nsPattern.matcher(str);
	    	while (nsMatcher.find())
	    	{
	    		String namespace=nsMatcher.group(1);
	    		Pattern patternTag = Pattern.compile("<(\\s*)"+namespace+"(\\s*):");
	    		Matcher matcherTag = patternTag.matcher(str);
				if (matcherTag.find())
	    		{
	    			setNamespacePrefix(namespace + GlobalConstants.COLON);;
	    			break;
	    		}
	    	}
		}

	}//EOM setXmlNamespace

	/**
	 * Factory method to retrieve the XmlTransactionReaderBase.
	 * It will be according to the FileMessageTypeData.getTypesData.
	 *
	 * @see FileMessageTypeData.Factory#getFileMessageTypeData(File, Set)
	 *
	 * @param file
	 * @return MultiXmlTransactionReader if FileMessageTypeData.getTypesData is not null, SingleXmlTransactionReader otherwise.
	 * @throws IOException
	 * @throws XMLStreamException 
	 */
	public static XmlTransactionReaderBase getXmlTransactionReader(File file,int chunkSize) {
		FileMessageTypeData fileMessageTypeData = null;
		try {
			fileMessageTypeData = FileMessageTypeData.Factory.getFileMessageTypeData(file);
		} catch (IOException e) {
			logger.error("getFileMessageTypeData failed",e);
			throw new BulkFileParsingExecption(e);			
		}

		XmlTransactionReaderBase iter = fileMessageTypeData.getReader(file, chunkSize);
		
		logger.debug("using {} as XmlTransactionReader",iter.getClass().getName());

		return iter;
	}//EOM getXmlTransactionReader
	
	public void parseAppHdr() {
		final String endTag_APP_HDR = "</AppHdr>";

		if(getAppHdrCreDt()!=null)
			return;
		
		try {
			int startAppHdr = getByteBuffer().getStart()+3;

			int endAppHdr = this.lastTransactionEndInd;

			if (endAppHdr <= getByteBuffer().getStart())
				return;
			
			endAppHdr += endTag_APP_HDR.length();

			String appHeader = getUtils().getFileSectionFromIndexes(startAppHdr, endAppHdr);

			COMPILE_PATTERN = "<head:CreDt>(.*)</head:CreDt>";

			setPattern(Pattern.compile(COMPILE_PATTERN));
			Matcher m = getPattern().matcher(appHeader);

			while (m.find()) {
				if (m.group(1) != null) {
					Date appHdrCreDt = null;
					SimpleDateFormat isoNormalizedDateFormat = new SimpleDateFormat(ISO_NORMALIZED_DATE_TIME);
					SimpleDateFormat cannonicalDateFormat = new SimpleDateFormat(XML_SCHEMA_DATE_TIME_CANNONICAL);
					try {
						appHdrCreDt = cannonicalDateFormat.parse(m.group(1));
					} catch (ParseException e1) {
						logger.debug("unable to parse AppHdr CreDt {} as {}",
								m.group(1), XML_SCHEMA_DATE_TIME_CANNONICAL);
						try {
							appHdrCreDt = isoNormalizedDateFormat.parse(m.group(1));
						} catch (ParseException e2) {
							logger.debug("unable to parse AppHdr CreDt {} as {}",m.group(1), ISO_NORMALIZED_DATE_TIME);
							logger.error("AppHdr CreDt {} is not parsable",m.group(1));
						}
					}
					setAppHdrCreDt(appHdrCreDt);
				}
			}

			this.lastTransactionEndInd = endAppHdr;
		} catch (Exception e) {
			logger.error("unable to retrive the file AppHdr Tag");
		}
	}




	public List<PDO> getPDOsFromChunk(PerformDebulkingMultiRequestDocument doc,String chunkId, String sInternalFileID,final FileSummary fileSummary,final Map[] arrMapSharedPDOContextHolder) throws Throwable {
		return null;
	}

	public long getTotalDeleted() {
		return m_totalDeleted;
	}
	public void setTotalDeleted(long m_totalDeleted) {
		this.m_totalDeleted = m_totalDeleted;
	}
	public FileMessageTypeData getFileMessageTypeData() {
		return m_fileMessageTypeData;
	}
	public void setFileMessageTypeData(FileMessageTypeData m_fileMessageTypeData) {
		this.m_fileMessageTypeData = m_fileMessageTypeData;
	}
	public long getFileSize() {
		return m_lFileSize;
	}
	public void setFileSize(long m_lFileSize) {
		this.m_lFileSize = m_lFileSize;
	}
	public long getByteCount() {
		return m_byteCount;
	}
	public void setByteCount(long m_byteCount) {
		this.m_byteCount = m_byteCount;
	}
	public RandomAccessFileUtils getUtils() {
		return m_utils;
	}
	public void setUtils(RandomAccessFileUtils m_utils) {
		this.m_utils = m_utils;
	}
	public String getNamespacePrefix() {
		return m_namespacePrefix;
	}

	public void setNamespacePrefix(String m_xmlns) {
		this.m_namespacePrefix = m_xmlns;
	}
	
	public String getHeaderNamespacePrefix() {
		if (m_headerNamespacePrefix == null)
			return getNamespacePrefix();
		
		return m_headerNamespacePrefix;
	}
	
	
	public String getPmtInfPrefix() {
		if (m_headerNamespacePrefix == null)
			return getNamespacePrefix();
		
		return m_headerNamespacePrefix;
	}

	public String getSenderName() {
		return senderName;
	}
	public void setSenderName(String senderName) {
		this.senderName = senderName;
	}
	public int getNumCTBlk() {
		return NumCTBlk;
	}
	public void setNumCTBlk(int numCTBlk) {
		NumCTBlk = numCTBlk;
	}
	public int getNumDDBlk() {
		return NumDDBlk;
	}
	public void setNumDDBlk(int numDDBlk) {
		NumDDBlk = numDDBlk;
	}
	public void setHeaderNamespacePrefix(String m_xmlns) {
		this.m_headerNamespacePrefix = m_xmlns;
	}
	
	public ByteArrayListOptimized getByteBuffer() {
		return m_byteBuffer;
	}
	public void setByteBuffer(ByteArrayListOptimized m_byteBuffer) {
		this.m_byteBuffer = m_byteBuffer;
	}
	public PerformDebulkingMultiRequestDocument getCurrentChunk() {
		return m_currentChunk;
	}
	public void setCurrentChunk(PerformDebulkingMultiRequestDocument m_currentChunk) {
		this.m_currentChunk = m_currentChunk;
	}
	public long getDocPreStartTagIndex() {
		return m_docPreStartTagIndex;
	}
	public void setDocPreStartTagIndex(long m_docPreStartTagIndex) {
		this.m_docPreStartTagIndex = m_docPreStartTagIndex;
	}
	public RandomAccessFile getRandomeFile() {
		return m_randomeFile;
	}
	public void setRandomeFile(RandomAccessFile m_randomeFile) {
		this.m_randomeFile = m_randomeFile;
	}
	public int getChunkSize() {
		return m_chunkSize;
	}
	public void setChunkSize(int m_chunkSize) {
		this.m_chunkSize = m_chunkSize;
	}
	public File getFile() {
		return m_file;
	}
	public void setFile(File m_file) {
		this.m_file = m_file;
	}
	
	public void setPmtInfId(String m_pmtInfId) {
		logger.debug("payment Info: '{}'",m_pmtInfId);
		this.m_pmtInfId = m_pmtInfId;
	}
	
	public void setTrnsCount(int m_trnsCount) {
		logger.debug("Transaction Count: {}",m_trnsCount);
		this.m_trnsCount = m_trnsCount;
	}
	
	public void setAppHdrBizMsgIdr(String appHdrBizMsgIdr){
		if(this.m_appHdrBizMsgIdr == null)
		{
			logger.debug("AppHdr BizMsgIdr: {}",appHdrBizMsgIdr);
			this.m_appHdrBizMsgIdr = appHdrBizMsgIdr;
		}
	}
	
	public void setAppHdrCreDt(Date appHdrCreDt){
		logger.debug("AppHdr CreDt: {}",appHdrCreDt);
		this.m_appHdrCreDt = appHdrCreDt;
	}
	
	public void setCtrlSum(String m_ctrlSum) {
		logger.debug("Ctrl Sum: {}",m_ctrlSum);
		this.m_ctrlSum = m_ctrlSum;
	}
	public void setPartyName(String m_partyName) {
		logger.debug("Party Name: '{}'",m_partyName);
		this.m_partyName = m_partyName;
	}
	public void setInitiatingPartyCustCode(String m_initiatingPartyCustCode) {
		logger.debug("Initiating Party Cust Code: '{}'",m_initiatingPartyCustCode);
		this.m_initiatingPartyCustCode = m_initiatingPartyCustCode;
	}
	public void setSendingInst(String sendingInst) {
		logger.debug("Sending Istitutaion: '{}'",sendingInst);
		this.sendingInst = sendingInst;
	}
	
	public void setReceivingInst(String receivingInst) {
		logger.debug("Receiving Istitutaion: '{}'",receivingInst);
		this.receivingInst = receivingInst;
	}
	
	public void setSinglePayment(boolean m_isSinglePayment) {
		this.m_isSinglePayment = m_isSinglePayment;
	}
	public long getSize() {
		return m_size;
	}
	public void setSize(long m_size) {
		this.m_size = m_size;
	}
	public long getGlobalHeaderStartTagIndex() {
		return m_globalHeaderStartTagIndex;
	}
	public void setGlobalHeaderStartTagIndex(long m_globalHeaderStartTagIndex) {
		this.m_globalHeaderStartTagIndex = m_globalHeaderStartTagIndex;
	}
	public long getGlobalHeaderEndTagIndex() {
		return m_globalHeaderEndTagIndex;
	}
	public void setGlobalHeaderEndTagIndex(long m_globalHeaderEndTagIndex) {
		this.m_globalHeaderEndTagIndex = m_globalHeaderEndTagIndex;
	}
	public long getDocPreEndTagIndex() {
		return m_docPreEndTagIndex;
	}
	public void setDocPreEndTagIndex(long m_docPreEndTagIndex) {
		this.m_docPreEndTagIndex = m_docPreEndTagIndex;
	}
	public long getPrePmtInfoStartIndex() {
		return m_prePmtInfoStartIndex;
	}
	public void setPrePmtInfoStartIndex(long m_prePmtInfoStartIndex) {
		this.m_prePmtInfoStartIndex = m_prePmtInfoStartIndex;
	}
	public long getPrePmtInfoEndIndex() {
		return m_prePmtInfoEndIndex;
	}
	public void setPrePmtInfoEndIndex(long m_prePmtInfoEndIndex) {
		this.m_prePmtInfoEndIndex = m_prePmtInfoEndIndex;
	}
	public void setPmtInfCount(int m_pmtInfCount) {
		this.m_pmtInfCount = m_pmtInfCount;
	}
	public long getPostTagsStartIndex() {
		return m_postTagsStartIndex;
	}
	public void setPostTagsStartIndex(long m_postTagsStartIndex) {
		this.m_postTagsStartIndex = m_postTagsStartIndex;
	}
	public int getNewSchemeIndex() {
		return newSchemeIndex;
	}
	public void setNewSchemeIndex(int newSchemeIndex) {
		this.newSchemeIndex = newSchemeIndex;
	}
	
	public int getNewSchemeIndexEnd() {
		return newSchemeIndexEnd;
	}
	public void setNewSchemeIndexEnd(int newSchemeIndexEnd) {
		this.newSchemeIndexEnd = newSchemeIndexEnd;
	}
	
	public String getHeader() {
		return m_header;
	}
	public void setHeader(String m_header) {
		this.m_header = m_header;
	}
	public Pattern getPattern() {
		return m_pattern;
	}
	public void setPattern(Pattern m_pattern) {
		this.m_pattern = m_pattern;
	}
	public void setM_fileType(String m_fileType) {
		this.m_fileType = m_fileType;
	}
	public void setBusinessDate(Date m_businessDate) {
		logger.debug("Business Date: {}",m_businessDate);
		this.m_businessDate = m_businessDate;
	}
	public boolean isFromMultiReader() {
		return m_isFromMultiReader;
	}
	public void setIsFromMultiReader(boolean isFromMultiReader) {
		this.m_isFromMultiReader = isFromMultiReader;
	}

	public void setListener(XmlTransactionReaderListener listener) {
		logger.debug("listener: {}",listener);
		this.listener = listener;
	}

	/**
	 * the method gets as parameter a tag and a start index and return its earliest index in the file,
	 * if the received tag is not present, another chunk from the file is read and
	 * the search for the tag continues.
	 * @param tag - tag to look for in the file
	 * @param startIndex - start index for looking
	 * @return index of the first occurrence (in current read chunk from file)
	 * @throws IOException
	 */
	protected int findAndReadTillNearestTagInChunk(byte[] tag, int startIndex) throws IOException {
		// check if there is occurrence of the tag in the current chunk.
		int index = getByteBuffer().indexOf(tag, startIndex);
		
		while (index == -1) {
			if (getByteCount() >= getFileSize())
				break;
			int temp = getByteBuffer().getSize();
			// Read next chunk
			setSize(getFileSize() - getByteCount() > BUFFER_SIZE ? BUFFER_SIZE : getFileSize() - getByteCount());
			startIndex = getByteBuffer().getSize();
			getUtils().getM_raf().seek(getByteCount());
			getUtils().readToByteArrayListEnd(this.getByteBuffer(), (int)getSize());
			setByteCount(getByteCount() + getSize());
			// set startIndex to the last checked index to avoid duplicate search


			index = getByteBuffer().indexOf(tag, temp - tag.length);
		}
		return index;
	}
	
	protected RandomAccessFileUtils getFileUtils(PerformDebulkingMultiRequestDocument doc) {
    	//read file from "archive" dir
    	String path = doc.getPerformDebulkingMultiRequest().getPath();
 	    File file = new File(path);
 	    if (!file.isFile()) {
 	    	path = path.substring(0,path.lastIndexOf(File.separator))
 	    			+ File.separator 
 	    			+ GlobalFileUtil.ARCHIVE_DIR 
 	    			+ path.substring(path.lastIndexOf(File.separator));
 	    	
 	    	file = new File(path);
 	    }
 	    
 	    RandomAccessFileUtils utils = new RandomAccessFileUtils(file);

 	    return utils;
    }
	
	/**
	 * indicator if parsing is done as part of FndtBatchMsg parsing 
	 */
	boolean isFndtBatchMsgContext;	
	protected boolean isFndtBatchMsgContext() {		
		return isFndtBatchMsgContext;
	}
	
	protected void setFndtBatchMsgContext(boolean isFndtBatchMsgContext) {
		this.isFndtBatchMsgContext = isFndtBatchMsgContext;
	}
	public int getLastTransactionEndInd() {
		return lastTransactionEndInd;
	}
	
	public long getBulkNumOfTx() {
		return bulkNumOfTx;
	}
	public void setBulkCreDtTm(String bulkCreDtTm) {
		this.bulkCreDtTm = bulkCreDtTm;
	}
	public String getBulkCreDtTm() {
		return this.bulkCreDtTm;
	}
	public void setBulkNumOfTx(long bulkNumOfTx) {
		this.bulkNumOfTx = bulkNumOfTx;
	}
	public BigDecimal getBulkTotalAmt() {
		return bulkTotalAmt;
	}
	public void setBulkTotalAmt(BigDecimal bulkTotalAmt) {
		this.bulkTotalAmt = bulkTotalAmt;
	}
	public long getBulkCtrlSum() {
		return bulkCtrlSum;
	}
	public void setBulkCtrlSum(long bulkCtrlSum) {
		this.bulkCtrlSum = bulkCtrlSum;
	}
	public String getBulkType() {
		return bulkType;
	}
	public void setBulkType(String bulkType) {
		this.bulkType = bulkType;
	}
	public boolean isNewBulk() {
		return isNewBulk;
	}
	public void setNewBulk(boolean isNewBulk) {
		this.isNewBulk = isNewBulk;
	}
	public int getCalcNumCTBlk() {
		return calcNumCTBlk;
	}
	public void setCalcNumCTBlk(int calcNumCTBlk) {
		this.calcNumCTBlk = calcNumCTBlk;
	}
	public int getCalcNumDDBlk() {
		return calcNumDDBlk;
	}
	public void setCalcNumDDBlk(int calcNumDDBlk) {
		this.calcNumDDBlk = calcNumDDBlk;
	}
}//EOC XmlTransactionReader