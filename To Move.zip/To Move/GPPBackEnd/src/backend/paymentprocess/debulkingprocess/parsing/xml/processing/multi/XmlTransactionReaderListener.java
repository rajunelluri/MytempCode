package backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi;

import com.fundtech.scl.debulkingProcessService.FileIndexDataType;

public interface XmlTransactionReaderListener {
	void onTransactionEnded(XmlTransactionReaderBase reader,FileIndexDataType txInfo);
	void onBulkEnd(long FndtBatchTagLastIndex,long transactionEndTagIndex,long newTxStartIndex);
	boolean isBulkEnd();
	void markBulkFullReject();
}
