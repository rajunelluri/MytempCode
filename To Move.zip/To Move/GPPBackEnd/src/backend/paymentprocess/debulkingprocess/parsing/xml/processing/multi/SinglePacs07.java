package backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi;

import java.io.File;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.fundtech.cache.entities.LogicalFieldsXpath;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.paymenttypes.PaymentType;

import backend.paymentprocess.debulkingprocess.common.WorkflowType;


/**
 * Concrete SingleMessageTypeData for pacs 07.
 * 
 * @author haimv
 * @author dmitryp
 */
public class SinglePacs07 extends SingleMessageTypeData
{
	// TODO Do not use hard-coded tags - take it from logical_fields_xpath cache.
//	
//	private String PACS_07_TRANSACTION_START_TAG = "<%sTxInf>"; // "<%sCdtTrfTxInf>";
//	private String PACS_07_TRANSACTION_END_TAG =   "</%sTxInf>"; //"</%sCdtTrfTxInf>";
	
//		private String PACS_07_TRANSACTION_START_TAG = ""; // "<%sCdtTrfTxInf>";
//	private String PACS_07_TRANSACTION_END_TAG =   ""; //"</%sCdtTrfTxInf>";
//	private String PACS_07_CLOSE_XML_TAGS = "</%sFIToFIPmtRvsl></%sDocument>";
	
	public SinglePacs07(PaymentType paymentType) {
		super(paymentType);
		this.setPaymentType(paymentType);
		CLOSE_XML_TAGS = "</%sFIToFIPmtRvsl></%sDocument>";
	
	}
	
//		@Override
//	public void initTags()
//	{
//		super.initTags();
//		PaymentType paymentType = PaymentType.valueOf(this.getPaymentType());    
//        Map<String, LogicalFieldsXpath> map =CacheKeys.LogicalFieldsXPathKey.getSingle(paymentType);  
//        
//       PACS_07_TRANSACTION_START_TAG =  this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_CDT_TRNF_INFO).getTagName(),false);
//       PACS_07_TRANSACTION_END_TAG =  this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_CDT_TRNF_INFO).getTagName(), true);
//	}
//		
//	@Override
//	public String getTransactionStartTag() {
//		return PACS_07_TRANSACTION_START_TAG;
//	}
//		
//	@Override
//	public String getTransactionEndTag() {
//		return PACS_07_TRANSACTION_END_TAG;
//	}

	@Override
	public String getTypeIdentifier() {
		// TODO Get the type from PaymentType		
		return "urn:iso:std:iso:20022:tech:xsd:pacs.007.001.02";
	}

	@Override
	public String getPaymentTypeName() {
		//return "pacs.007";
		return "Pacs_007";
	}

	@Override
	public String getPreDocumentEnd() {
		return getGrpHdrEndTag();
	}

	@Override
	public String getPrePmtInfEnd() {
		return getTransactionStartTag();
	}
	
	@Override
	public XmlTransactionReaderBase getReaderWithoutInit(File file, int chunkSize, RandomAccessFile accessFile)
	{
		if (reader == null) {
			reader = new PacsTransactionReader(file,accessFile, chunkSize,this);
		}
		return reader;
	}

	
	@Override
	public XmlTransactionReaderBase getReader() {
		
		if (defaultCtorReader == null) {
			defaultCtorReader= new PacsTransactionReader();
		}
		return defaultCtorReader;
		
	}


	@Override
	public XmlTransactionReaderBase getReader(File file, int chunkSize) {
		
		if (reader == null) {
			reader = new PacsTransactionReader(file, chunkSize,this);
		}
		return reader;
		
	}

//	@Override
//	public String getXmlClosingTags() {
//		return PACS_07_CLOSE_XML_TAGS;
//	}
	
	@Override
	public String getWorkflow() {
		return WorkflowType.Pacs_007.name();
	}
	
	@Override
	public void formatTags(String namespace)
	{
		super.formatTags(namespace);
//		this.PACS_07_TRANSACTION_END_TAG   = String.format(this.PACS_07_TRANSACTION_END_TAG,namespace);
//		this.PACS_07_TRANSACTION_START_TAG = String.format(this.PACS_07_TRANSACTION_START_TAG,namespace);
//		this.PACS_07_CLOSE_XML_TAGS 	   = String.format(this.PACS_07_CLOSE_XML_TAGS,namespace,namespace);
	}

	@Override
	public byte[] getPaymentInfoElementStartTagBytes() {
		return getPaymentInfoElementStartTag().getBytes();
	}
	
	
		@Override
	public void initTags(PaymentType paymentType)
	{
        Map<String, LogicalFieldsXpath> map =CacheKeys.LogicalFieldsXPathKey.getSingle(paymentType);  
        
       GROUP_HEADER_START_TAG =  this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_GRP_INFO).getTagName(),false);
       GROUP_HEADER_END_TAG =  this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_GRP_INFO).getTagName(), true);
       
//       PAYMENT_INFO_START_TAG =  this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_PMT_INFO).getTagName(), false);
//       PAYMENT_INFO_END_TAG =  this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_PMT_INFO).getTagName(), true);
//       
       //TODO: NO FIELDS AT LOGICAL FIELDS XPATH
       PAYMENT_INFO_START_TAG=  "";
       PAYMENT_INFO_END_TAG = "";
       
       
      TRANSACTION_START_TAG =  this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_PMT_INFO).getTagName(), false);
      TRANSACTION_END_TAG =  this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_PMT_INFO).getTagName(), true);
	}

	
	public ArrayList<byte[]> getTranscationTagsByteArrayByOrderList()
	{
		ArrayList<byte[]>  list = new ArrayList();
		list.add(new String("xmlns=").getBytes());
		list.add(this.getTransactionStartTagBytes());
		list.add(this.getTransactionEndTagBytes());
		return list;
	}
	
	public ArrayList<byte[]> getHeaderTagsByteArrayByOrderList()
	{
		ArrayList<byte[]>  list = new ArrayList();
		list.add(new String("xmlns=").getBytes());
		list.add(new String("<GrpHdr>").getBytes());
		list.add(new String("</GrpHdr>").getBytes());
		return list;
	}
	
	@Override
	public byte[] getPaymentInfoElementEndTagBytes() {
		return getPaymentInfoElementEndTag().getBytes();
	}
		
		
}//EOC SinglePacs07