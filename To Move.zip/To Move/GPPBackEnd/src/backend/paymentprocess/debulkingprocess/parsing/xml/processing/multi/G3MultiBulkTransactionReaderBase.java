package backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi;

import static backend.core.module.MessageConstantsInterface.CREDIT_TRANSFER;
import static backend.core.module.MessageConstantsInterface.DIRECT_DEBIT;
import static com.fundtech.parser.g3.G3MessageUtil.APPHDR_BIZMSGIDR;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.io.StringWriter;
import java.io.Writer;

import javax.xml.namespace.QName;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLEventWriter;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.cache.entities.InterfaceTypes;
import com.fundtech.parser.g3.G3BulkMessageMetadata;
import com.fundtech.parser.g3.G3MessageUtil;
import com.fundtech.parser.g3.jaxb.bah.AppHdr;
import com.fundtech.scl.debulkingProcessService.FileIndexDataType;
import com.fundtech.scl.debulkingProcessService.PerformDebulkingMultiRequestDocument;
import com.fundtech.util.GlobalUtils;

public class G3MultiBulkTransactionReaderBase extends MultiXmlTransactionReader implements XmlTransactionReaderListener{

	protected static final Logger logger = LoggerFactory.getLogger(G3MultiBulkTransactionReaderBase.class);
	
	protected Writer payloadOutput;
	protected XMLEventWriter payloadWriter;
	protected String headerNSPrefix;
	protected XmlTransactionReader nativeReader;
	protected int numOfBulks = 1;
	

	protected QName appHdrQname = new QName(G3MessageUtil.APPHDR_NAMESPACE, G3MessageUtil.APPHDR_LOCAL_NAME);

	private boolean bulkFullReject;
	
	public G3MultiBulkTransactionReaderBase(File file, int chunkSize) {
		super();
		setFile(file);
		setChunkSize(chunkSize);

		try {
			setRandomeFile(new RandomAccessFile(file, "r"));
			setFileSize(getRandomeFile().length()) ;
		} catch (FileNotFoundException e1) {
			logger.error(e1.getMessage(), e1);
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		setUtils(new RandomAccessFileUtils(getFile()));

		setCurrentChunk(PerformDebulkingMultiRequestDocument.Factory.newInstance());
		getCurrentChunk().addNewPerformDebulkingMultiRequest();
		setFileMessageTypeData(new G3Msg_SingleTypeBatch());



		// Read global header
		setByteBuffer(new ByteArrayListOptimized());

		setSize(getFileSize() - getByteCount() > BUFFER_SIZE ? BUFFER_SIZE : getFileSize() - getByteCount());
		setByteCount(getByteCount() + getSize());

		getUtils().readToByteArrayListEnd(getByteBuffer(), (int)getSize());


		getReaderForMessageType(null);

		try {
			init();
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}

		readTillNextPaymentTypeAndChangeReader();

		INTERFACE_TYPE = InterfaceTypes.INTERFACE_TYPE_MASSPMNTS;
		INTERFACE_SUB_TYPE = InterfaceTypes.INTERFACE_SUB_TYPE_DEB;

	}
	

	public boolean hasNext(){
		
		boolean hasNext = nativeReader.hasNext();
		if (!hasNext && numOfBulks > 0){
			this.setFile(nativeReader.getFile());
			this.setRandomeFile(nativeReader.getRandomeFile()); 
			this.setChunkSize(nativeReader.getChunkSize()); 
			this.setFileSize(nativeReader.getFileSize());
			this.setUtils(nativeReader.getUtils());
			this.setByteBuffer(nativeReader.getByteBuffer());
			this.setTotalDeleted(nativeReader.getTotalDeleted());
			this.setByteCount(nativeReader.getByteCount());
			this.setSize(nativeReader.getSize());
			this.lastTransactionEndInd = nativeReader.getLastTransactionEndInd();
			
			nativeReader = getReaderForMessageType(null);
			nativeReader.setFile(getFile());
			nativeReader.setRandomeFile(getRandomeFile());
			nativeReader.setByteBuffer(getByteBuffer());
			nativeReader.setChunkSize(getChunkSize()); 
			nativeReader.setUtils(getUtils());
			nativeReader.setByteCount(getByteCount());
			nativeReader.setFileSize(getFileSize());
			nativeReader.setTotalDeleted(getTotalDeleted());
			nativeReader.setSize(getSize());
			nativeReader.lastTransactionEndInd = this.lastTransactionEndInd;
			hasNext = nativeReader.hasNext();
			numOfBulks--;
		}
		setNewBulk(nativeReader.isNewBulk());
		setBulkNumOfTx(nativeReader.getBulkNumOfTx());
		setBulkCtrlSum(nativeReader.getBulkCtrlSum());
		setBulkTotalAmt(nativeReader.getBulkTotalAmt());
		setBulkType(nativeReader.getBulkType());
		setBulkCreDtTm(nativeReader.getBulkCreDtTm());
		if(nativeReader.getAppHdrCreDt()!=null)
			setAppHdrCreDt(nativeReader.getAppHdrCreDt());

		if(CREDIT_TRANSFER.equals(nativeReader.getBulkType()))
		{
			setNumCTBlk((int)nativeReader.getBulkNumOfTx());
		}else if(DIRECT_DEBIT.equals(nativeReader.getBulkType()))
		{
			setNumDDBlk((int)nativeReader.getBulkNumOfTx());
		}
		return hasNext;
		
	}
	
	@Override
	public Object next() {
		return nativeReader.next();
	}

	protected void initWriter() throws XMLStreamException {
		XMLOutputFactory ofactory = XMLOutputFactory.newInstance();

		payloadOutput = new StringWriter();
		payloadWriter = ofactory.createXMLEventWriter(payloadOutput);	

	}

	protected void closeWriter() throws XMLStreamException {
		payloadWriter.flush();
		payloadWriter.close();		

	}	

	protected void getNSPrefix(XMLEvent e) {
		if (headerNSPrefix == null && e.isStartElement()){
			headerNSPrefix = e.asStartElement().getName().getPrefix();
		}
	}
	
	
	@Override
	public void initHeader ()
	{
		XMLEventReader reader = null;
		try{
			XMLInputFactory ifactory = XMLInputFactory.newInstance();
			try {
				reader = ifactory.createXMLEventReader(new FileInputStream(getFile()));
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				logger.error(e1.getMessage(), e1);
			} catch (XMLStreamException e1) {
				// TODO Auto-generated catch block
				logger.error(e1.getMessage(), e1);
			}
	
	
			try {
				initWriter();
			} catch (XMLStreamException e1) {
				// TODO Auto-generated catch block
				logger.error(e1.getMessage(), e1);
			}
	
			boolean payloadStarted = false;
			boolean appHdrStarted = false;
			boolean appHdrEnded = false;
	
	
			XMLEvent e = null;
			DynamicEventFilter filter;
			String grpHdrUri;
			String appHdr = null;
			String msgId = null;
			String bizMsgIdr = null;
			StartElement headerStartElement = null;
	
			filter = new DynamicEventFilter(appHdrQname);
	
			while (reader.hasNext()) {
				try {
					e = reader.nextEvent();
				} catch (Exception ex) {
					logger.error("Error occurred due to  {}", ex);
				}
	
				try {
	
					if (filter.accept(e)) {
						if (!appHdrStarted) {
							appHdrStarted = true;
							payloadWriter.add(e);
							headerStartElement = (StartElement)e;
							continue;
						} 
	
						if (!appHdrEnded) { 
							appHdrEnded = true;
							payloadWriter.add(e);
							closeWriter();
							lastTransactionEndInd = e.getLocation().getCharacterOffset();
							appHdr = payloadOutput.toString();
							filter.setTarget(G3BulkMessageMetadata.getAllG3PayloadsNames()); //go the first bulk 
							continue;
						} 
						
						if (!payloadStarted){
							payloadStarted = true;
							e = reader.nextTag();
							grpHdrUri = ((StartElement)e).getName().getNamespaceURI();
							filter.setTarget(new QName(grpHdrUri, "MsgId"));
							continue;
						}
	
						msgId = reader.getElementText();
						setMsgId(msgId);
						setFileType(msgId);
						break;
	
					}else{
						if (appHdrStarted && !appHdrEnded){
	
							if(e.isStartElement() && APPHDR_BIZMSGIDR.equals(((StartElement)e).getName().getLocalPart()))
							{
								payloadWriter.add(e);
								e = reader.nextEvent();
								bizMsgIdr = (e.isCharacters()) ? e.asCharacters().getData() : "";
								setAppHdrBizMsgIdr(bizMsgIdr);
							}
							
							getNSPrefix(e);
							payloadWriter.add(e);
						}
					}
	
				} catch (XMLStreamException e1) {
					// TODO Auto-generated catch block
					logger.error(e1.getMessage(), e1);
				}
			}//while
	
			getDataFromBizAppHdr(appHdr, headerStartElement);
		}
		finally
		{
			try{
				if (reader !=null) reader.close();
			}catch(Exception e){
        		logger.error("Exception - could not close FileInputStream-fileInputStream at G3MultiBulkTransactionReaderBase.initHeader");
			}
			
		}
	}
	
	public void setFileType(String msgId){
		setM_fileType(msgId.substring(3, 6));
	}

	protected void setCurrentSchemaToCurrTrnMsgType(long index1 , long index2 ) {
		currTransactionsMsgDataType = (FileMessageTypeData) new G3Msg_SingleTypeBatch();
	}

	
/*
	protected XmlTransactionReader getReaderForMessageType(String msgType)
	{
		nativeReader = new G3_SingleTypePacsBatch_TransactionReader(getFile(), getRandomeFile(), getChunkSize(), new G3Msg_SingleTypeBatch());
		nativeReader.setListener(this);
		nativeReader.setUtils(getUtils());
		nativeReader.lastTransactionEndInd = this.lastTransactionEndInd;
		return nativeReader;
	}
*/
	protected void getDataFromBizAppHdr(String appHdr, StartElement hdrElement){
		String headElement = hdrElement.getName().getLocalPart();
		if (appHdr.contains("<" + headElement + ">")){
			appHdr = appHdr.replace("<" + headElement + ">", "").replace("</" + headElement + ">", "");
		}else{
			appHdr = appHdr.replaceAll("<.*:" + headElement + ">", "").replaceAll("</.*:" + headElement + ">", "");
		}

		String businessApplicationHeader = String.format("%s%s%s"
				, new Object[]{  
						"<" + headElement+ " xmlns:" + headerNSPrefix + "=\"" + hdrElement.getNamespaceURI(headerNSPrefix) +"\">"
						,appHdr
						,"</" + headElement+ ">"
				});

		G3MessageUtil msgUtil = new G3MessageUtil();
		AppHdr header = msgUtil.parseHeader(businessApplicationHeader);
		setSendingInst(header.getFr().getFIId().getFinInstnId().getClrSysMmbId().getMmbId());
		setReceivingInst(header.getTo().getFIId().getFinInstnId().getClrSysMmbId().getMmbId());
	}



	@Override
	public void onTransactionEnded(XmlTransactionReaderBase reader,	FileIndexDataType txInfo) {
		lastTransactionEndInd = reader.getLastTransactionEndInd();
	}

	@Override
	public int getRecCountInChunk(Object chunk) {
		return nativeReader.getRecCountInChunk(chunk);
	}

	@Override
	public String getXmlofChunk(Object chunk) {
		return nativeReader.getXmlofChunk(chunk);
	}

	@Override
	public void init(){
		initHeader();
		
	}

	@Override
	protected boolean readTransactionsOfChunkSize() {
		// will not be called
		return false;
	}


	@Override
	public void onBulkEnd(long FndtBatchTagLastIndex,
			long transactionEndTagIndex, long newTxStartIndex) {
	}


	@Override
	public boolean isBulkEnd() {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public void markBulkFullReject() {
		bulkFullReject=true;
	}


	public boolean isBulkFullReject() {
		return bulkFullReject;
	}

	@Override
	public void setBulkType(String bulkType) {
		if(GlobalUtils.isNullOrEmpty(bulkType)){
			this.bulkType = "ALL";
		}else{
			this.bulkType = bulkType;
		}
	}

}
