package backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi;



import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_BUSINESS_FLOW_TP;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_IN_BULK_MSGID;

import java.io.File;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.paymentprocess.debulkingprocess.common.WorkflowType;
import backend.paymentprocess.enrichment.commons.InterfaceSubTypeFlow;

import com.fundtech.cache.entities.FileSummary;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.scl.debulkingProcessService.FileIndexDataType;
import com.fundtech.scl.debulkingProcessService.PerformDebulkingMultiRequestDocument;
import com.fundtech.scl.debulkingProcessService.PreStartDataType;
import com.fundtech.util.ExceptionController;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalFileUtil;
import com.fundtech.util.GlobalUtils;


/**
 * PacsTransactionReader for pacs04 and pacs08
 *
 */
public class PacsTransactionReader extends AbstractSingleInMuliSchemaReader
{


	private ArrayList<PreStartDataType>  listPreStartDataType= null;
	PreStartDataType preStart = null;
	int ChunkNum = 1 ;


	private static final Logger logger = LoggerFactory.getLogger(PacsTransactionReader.class);
	public PacsTransactionReader(){
		initMembers();
	}

	public PacsTransactionReader(FileMessageTypeData fileMessageTypeData){
		this.setFileMessageTypeData(fileMessageTypeData);
		initMembers();
	}


	public PacsTransactionReader (File file,int chunkSize,FileMessageTypeData fileMessageTypeData)
	{
		super(file,chunkSize,fileMessageTypeData);
		initMembers();
	}


	public PacsTransactionReader (File file,RandomAccessFile raf, int chunkSize,FileMessageTypeData fileMessageTypeData)
	{
		super(file,raf, chunkSize,fileMessageTypeData);
		initMembers();
	}

	protected void configureNativeReader(){}

	public void initPreStartDataType() {
		preStart = PreStartDataType.Factory.newInstance();
		preStart.setPreDocumentStartTag(getDocPreStartTagIndex());
		preStart.setPreDocumentEndTag(getDocPreEndTagIndex());
		preStart.setPrePmtInfStartTag(getGlobalHeaderStartTagIndex());
		preStart.setPrePmtInfEndTag(getGlobalHeaderEndTagIndex());

		arrayPreStartDataType = new PreStartDataType[] {preStart};
		listPreStartDataType = new ArrayList<PreStartDataType>();		

	}

	@Override
	protected boolean readTransactionsOfChunkSize()
	{
		int TransactionNum = 1;
		//		return super.readTransactionsOfChunkSize();
		int transactionStartTagIndex = GlobalConstants.DEFAULT_NOT_FOUND_VALUE;
		int transactionEndTagIndex = GlobalConstants.DEFAULT_NOT_FOUND_VALUE;

		byte[] transactionStartTagBytes = getFileMessageTypeData().getTransactionStartTagBytes();
		byte[] transactionEndTagBytes = getFileMessageTypeData().getTransactionEndTagBytes();

		int transactionEndTagLength = transactionEndTagBytes.length;

		listFileIndexDataType.clear();
		listPreStartDataType.clear();


		// TODO outside the loop?
		if (listPreStartDataType.isEmpty())
			listPreStartDataType.add(preStart);
		ArrayList<byte[]> listStartTran = new ArrayList<byte[]>();

		// add to the list the tag of new scheme which is global and same for all FileMessageDataType
		//listStartTran.add(m_fileMessageTypeData.getPaymentInfoElementStartTagBytes());
		listStartTran.add(getFileMessageTypeData().getTransactionStartTagBytes());
		// arraylist contain the tags that should appear/checked before new
		// transcation collection is being made (for example - if the transaction scheme
		// is different than the previous ones.
		ArrayList<byte[]> listEndTran = new ArrayList<byte[]>();
		listEndTran.add(getFileMessageTypeData().getTransactionEndTagBytes());

		try {
			ChunkNum ++ ;
			int PrevIndxEnd = 0;
			int distancebetweentransactions = 0;
			transactionStartTagIndex = this.findAndReadTillNearestTagInChunk(transactionStartTagBytes ,transactionStartTagIndex);
			//Till the end of file and no more End tags exists or CHUNK is ready or PaymentInfo section has been changed
			while ( getByteCount() <= getFileSize() && transactionStartTagIndex != -1 && listFileIndexDataType.size() < getChunkSize() )
			{
				if(isNewBulk())
					break;

				FileIndexDataType fileInfo = FileIndexDataType.Factory.newInstance();
				
				// look for the first appearing tag from the start transaction
				// tag list

				// if new scheme indicating tag found, change the scheme
				// means a tag indicating a new transaction is found

				// get new file index data type which will conation the
				// indexes of the transaction
				// set the transaction starting tag index
				fileInfo.setTransactionStartTag(transactionStartTagIndex + this.getTotalDeleted());
				// find the end of the transaction
				transactionEndTagIndex = this.findAndReadTillNearestTagInChunk(transactionEndTagBytes,(int)transactionStartTagIndex+ transactionStartTagBytes.length);
				// set the transaction end tag index
				PrevIndxEnd = (int)fileInfo.getTransactionEndTag();
				fileInfo.setTransactionEndTag(transactionEndTagIndex + transactionEndTagLength + this.getTotalDeleted());

				// delete the buffer until the end of the transaction
				this.getByteBuffer().removeRangeFromBeginning(transactionEndTagIndex + transactionEndTagLength);
				this.setTotalDeleted(this.getTotalDeleted() + (transactionEndTagIndex + transactionEndTagBytes.length));
				fileInfo.setPaymentType(getFileMessageTypeData().getPaymentTypeName());
				
				String r = String.format("chunk num = %d , transaction num = %d , start index = %d , End Index = %d , transaction size = %d , distance = %d , distance between transactions = %d", 
						ChunkNum, 
						TransactionNum,
						fileInfo.getTransactionStartTag(),
						fileInfo.getTransactionEndTag(),
						fileInfo.getTransactionEndTag() - fileInfo.getTransactionStartTag(),
						PrevIndxEnd - fileInfo.getTransactionStartTag(),
						-(distancebetweentransactions - fileInfo.getTransactionStartTag() - PrevIndxEnd));
				logger.info(r);
				listFileIndexDataType.add(fileInfo);
				distancebetweentransactions =(int)fileInfo.getTransactionStartTag() - PrevIndxEnd;
				if(listener != null)
					listener.onTransactionEnded(this, fileInfo);

				setNumOfTrxActuallyReadFromFile(getNumOfTrxActuallyReadFromFile()+ 1);
				
				transactionStartTagIndex = this.findAndReadTillNearestTagInChunk(transactionStartTagBytes , 0);
				if (transactionStartTagIndex > -1 ){
					int temp =getByteBuffer().indexOfWithStartEndIndex("GrpHdr>".getBytes(), 0, transactionStartTagIndex);
					if (temp != -1){
						setNewBulk(true);
						break;
					}
				}
				TransactionNum ++;
				
			}// try

		}
		catch (Exception e) {
			ExceptionController.getInstance().handleException(e, this);
			throw new RuntimeException("Problem reading " + getByteCount()
					+ " chunk");
		}
		
		if (GlobalUtils.isArrayNotNullAndNotEmpty(arrayPreStartDataType)){
			getCurrentChunk().getPerformDebulkingMultiRequest().setPreStartDataListArray(arrayPreStartDataType);

			getCurrentChunk().getPerformDebulkingMultiRequest().setEndTags(getFileMessageTypeData().getXmlClosingTags());
		}
		
		if(!GlobalUtils.isListNullOrEmpty(listFileIndexDataType))
		{
			//set arrFileIndexDataType
			FileIndexDataType[] arrFileIndexDataType = new FileIndexDataType[listFileIndexDataType.size()];
			getCurrentChunk().getPerformDebulkingMultiRequest().setFileIndexDataTypeListArray(listFileIndexDataType.toArray(arrFileIndexDataType));

			getCurrentChunk().getPerformDebulkingMultiRequest().setPreStartDataListArray(arrayPreStartDataType);

			getCurrentChunk().getPerformDebulkingMultiRequest().setEndTags(getFileMessageTypeData().getXmlClosingTags());

			return true;
		} else {
			logger.debug("no more transaction on file");
			return false;
		}


	}//EOM readTransactionsOfChunkSize


	//
	@Override
	public List<PDO> getPDOsFromChunk( PerformDebulkingMultiRequestDocument doc
			,String chunkId
			,String internalFileID
			,final FileSummary fileSummary
			,final Map[] sharedPDOContextHolder) throws Throwable {

		return this.getPDOsFromChunk(doc, chunkId, internalFileID, fileSummary, sharedPDOContextHolder, true);


	}
	@Override
	public List<PDO> getPDOsFromChunk(PerformDebulkingMultiRequestDocument doc,String chunkId, String sInternalFileID,final FileSummary fileSummary,
			final Map[] arrMapSharedPDOContextHolder, final boolean bShouldLogInfo) throws Throwable {

		
		String sTracePrefix = String.format("'getPDOsFromChunk', (internal file ID: %s, chunk ID: %s); ", sInternalFileID, chunkId);
	    
		String flowType = InterfaceSubTypeFlow.getFlowType(fileSummary.getPlFileType());

		// Gets related FILE_SUMMARY's OFFICE & INITG_PTY_CUST_CODE values.
		final String sFileSummary_INITG_PTY_CUST_CODE = fileSummary.getInitgPtyCustCode() ;
		final String msgType = fileSummary.getMsgType() ;

		logger.info(sTracePrefix + "calls 'BODebulkFile.debulkFile' for parsing passed XML chunk content...");
		List<String> listChunk = new ArrayList<String>();
		logger.info(sTracePrefix + "after call to 'BODebulkFile.debulkFile'; size of returned list: %s", listChunk.size());
		String path = doc.getPerformDebulkingMultiRequest().getPath();
		File file = new File(path);
		if (!file.isFile())
		{
			path = path.substring(0,path.lastIndexOf(java.io.File.separator)) + java.io.File.separator + GlobalFileUtil.ARCHIVE_DIR +  path.substring(path.lastIndexOf(java.io.File.separator));
			file = new File(path);
		}

		String endTags 			= doc.getPerformDebulkingMultiRequest().getEndTags();
		PreStartDataType preStartDataType = doc.getPerformDebulkingMultiRequest().getPreStartDataListArray()[0];
		long preDocumentStartTag = preStartDataType.getPreDocumentStartTag();
		long preDocumentEndTag 	= preStartDataType.getPreDocumentEndTag();
		long prePmtInfStartTag 	= preStartDataType.getPrePmtInfStartTag();
		long prePmtInfEndTag 	= preStartDataType.getPrePmtInfEndTag();

		RandomAccessFileUtils utils = new RandomAccessFileUtils(file);

		boolean bAddPmtInf = (prePmtInfStartTag!=0);
		List<PDO> pdoList = new ArrayList<PDO>();
		String prefix = null;
		if (endTags != null){
			int endIndex = endTags.indexOf(":");
			if (endIndex > 0){ // the is namespace prefix
				int startIndex = endTags.indexOf("/") + 1;
				prefix = endTags.substring(startIndex, endIndex);
			}
		}

		StringBuilder sb = new StringBuilder();
		String documentPartTillFirstTransaction = utils.getDocumentPartTillFirstTransaction(
				preDocumentStartTag,(bAddPmtInf && preDocumentStartTag != -1) ? prePmtInfStartTag : preDocumentEndTag,
						prePmtInfStartTag,prePmtInfEndTag,endTags,
						bAddPmtInf,false,true,this.getFileMessageTypeData(), prefix/*payment namespace*/);


		FileIndexDataType[] arr = doc.getPerformDebulkingMultiRequest().getFileIndexDataTypeListArray();

		for (FileIndexDataType fileIndexDataType : arr)
		{

			//Xml document without payment info section
			sb.append(documentPartTillFirstTransaction);

			//Transaction
			sb.append(utils.getFileSectionFromIndexes(fileIndexDataType.getTransactionStartTag(),fileIndexDataType.getTransactionEndTag()));
			sb.append(endTags);
			//Transaction
			PDO pdo = PaymentDataFactory.newPDO(sb.toString(), true /*transient*/, false/*primary*/, false /*conjoined*/, null, GlobalConstants.BP.equals(flowType)/*is BP Flow*/);

			String sMID = pdo.getMID();
			
			pdo.set(PDOConstantFieldsInterface.X_TX_NO, 1+"");
			pdo.set(PDOConstantFieldsInterface.P_RAW_MSG_TYPE, msgType);

			pdo.set(PDOConstantFieldsInterface.P_ORG_INITG_PTY_CUST_CD, sFileSummary_INITG_PTY_CUST_CODE);

			// Sets chunk ID.
			pdo.set(PDOConstantFieldsInterface.P_CHUNK_ID, chunkId);
			// Sets Payment Source (G3BULK or BOOK)
			pdo.set(PDOConstantFieldsInterface.P_PMNT_SRC, fileSummary.getFileSource());
			// Adds the MID to the returned list that later on will be used in the caller method for executing base processing for each MID.
			
			// Sets Business flow type (BP or '' or RT)
			pdo.set(P_BUSINESS_FLOW_TP,flowType);
			
			pdo.set(P_IN_BULK_MSGID, doc.getPerformDebulkingMultiRequest().getBulkId());
			
			pdoList.add(pdo);

			if(bShouldLogInfo) logger.info(String.format(sTracePrefix + "created following PDO - MID: %s, Status: %s, Chunk ID: %s, PDO ID: " +
			    		"%s", sMID, pdo.getString(PDOConstantFieldsInterface.P_MSG_STS), chunkId, pdo));

			sb.delete(0,sb.length());

		}//for

		utils.dispose();
		return pdoList;

	}


	@Override
	public void init(InputStream inputStream) throws Exception {
		// TODO Auto-generated method stub
	
	}

	@Override
	public long getBatchIndexOffset() {
		// TODO Auto-generated method stub
		return 0;
	}

}
