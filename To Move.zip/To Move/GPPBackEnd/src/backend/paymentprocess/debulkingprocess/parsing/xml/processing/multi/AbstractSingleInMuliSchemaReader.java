package backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.paymentprocess.debulkingprocess.parsing.xml.processing.TransactionReader;
import backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi.ByteArrayListOptimized.FindWordResponse;

import com.fundtech.cache.entities.FileSummary;
import com.fundtech.cache.entities.InterfaceTypes;
import com.fundtech.cache.entities.SwiftId;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.parser.g3.G3BulkMessageMetadata;
import com.fundtech.scl.debulkingProcessService.FileIndexDataType;
import com.fundtech.scl.debulkingProcessService.PerformDebulkingMultiRequestDocument;
import com.fundtech.scl.debulkingProcessService.PerformDebulkingMultiRequestType;
import com.fundtech.scl.debulkingProcessService.PreStartDataType;
import com.fundtech.util.ExceptionController;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalUtils;

public abstract class AbstractSingleInMuliSchemaReader extends
                SingleXmlTransactionReader {
        private static final Logger logger = LoggerFactory.getLogger(AbstractSingleInMuliSchemaReader.class);
        private static final int SEEK_RANGE_FOR_NEAR_TAG_SIZE = 250;
        ArrayList<FileIndexDataType> listFileIndexDataType = null;
        PreStartDataType[] arrayPreStartDataType = null;
        String newSchemeString = null;
        byte[] newSchemeBytes = null;
        PreStartDataType preStart = null;
        private int TILL_XML_NS_SPACING = 67;
        private static final String sCreditTransferEndTag = "</CreditTransfer>";
        private static final String sDebitTransferEndTag = "</DirectDebit>";  
        private static final String sCreditPaymentReturnEndTag = "</CreditPaymentReturn>";  
        private static final String sDebitPaymentReturnEndTag = "</DebitPaymentReturn>";
        public AbstractSingleInMuliSchemaReader() {
                super();
        }

        
        
        public AbstractSingleInMuliSchemaReader(File file, int chunkSize,
                        FileMessageTypeData fileMessageTypeData) {
                super(file, chunkSize, fileMessageTypeData);
        }

        public void testMethod() {
                        if ((getHeader() == null || getHeader().isEmpty()) && isFromMultiReader())
                        {
                                setHeader(getUtils().getFileSectionFromIndexes(getGlobalHeaderStartTagIndex(), getGlobalHeaderEndTagIndex()));
                        }
        
                        if (getHeader() != null) {
                                setCompiledPattern();
                                // Gets the info from the file.
                                setPattern(Pattern.compile(COMPILE_PATTERN));
                                Matcher m = getPattern().matcher(getHeader());
        //                      setHeader(new String(getByteBuffer().returnActualArray(),
        //                                      (int) getDocPreStartTagIndex(), (int) getPrePmtInfoStartIndex()));
                                while (m.find()) {
                                        if (m.group(1) != null)
                                                setMsgId(m.group(1));
                                        if (m.group(2) != null)
                                                setTrnsCount(Integer.parseInt(m.group(2)));
                                        if (m.group(3) != null)
                                                setCtrlSum(m.group(3));
                                        if (m.group(4) != null)
                                                setPartyName(m.group(4));
                                        if (m.group(5) != null)
                                                setInitiatingPartyCustCode(m.group(5));
        
                                }// while
                        }
        
                }

        public void initMembers() {
        
                newSchemeBytes =XML_NAMESPACE.getBytes();
                listFileIndexDataType = new ArrayList<FileIndexDataType>();
                arrayPreStartDataType = new PreStartDataType[1];
        
                // init PreStart
                preStart = PreStartDataType.Factory.newInstance();
        
                preStart.setPreDocumentStartTag(getDocPreStartTagIndex());
        
        
                preStart.setPreDocumentEndTag(getDocPreEndTagIndex());
                preStart.setPrePmtInfStartTag(getGlobalHeaderStartTagIndex());
                preStart.setPrePmtInfEndTag(getGlobalHeaderEndTagIndex());
        
                arrayPreStartDataType[0] = preStart;
        }

        @Override
        protected void setCompiledPattern() {
                COMPILE_PATTERN = "<"+getNamespacePrefix()+"MsgId>(.*)</"+getNamespacePrefix()+"MsgId>|<"+getNamespacePrefix()+"NbOfTxs>(.*)</"+getNamespacePrefix()+"NbOfTxs>|" +
                                "<"+getNamespacePrefix()+"CtrlSum>(.*)</"+getNamespacePrefix()+"CtrlSum>|<"+getNamespacePrefix()+"Nm>(.*)</"+getNamespacePrefix()+"Nm>|<"+getNamespacePrefix()+"InstdAgt>\\s*<"+getNamespacePrefix()+"FinInstnId>\\s*<"+getNamespacePrefix()+"BIC>(.*)</"+getNamespacePrefix()+"BIC>";
        }

        @Override
        public void init() throws IOException {
                INTERFACE_TYPE = InterfaceTypes.INTERFACE_TYPE_MASSPMNTS;
                INTERFACE_SUB_TYPE = InterfaceTypes.INTERFACE_SUB_TYPE_DEB;
                //m_utils = new RandomAccessFileUtils(m_file);
                //RandomAccessFileUtils utils = new RandomAccessFileUtils(m_file);
                setHeader(getUtils().getFileSectionFromIndexes(getGlobalHeaderStartTagIndex(), getGlobalHeaderEndTagIndex()));
                  getRandomeFile().seek(getByteCount());
            getUtils().setM_raf(getRandomeFile());
        
                setPattern(Pattern.compile(COMPILE_PATTERN));
            Matcher m = getPattern().matcher(getHeader());
            String instdBic = null;
            setSinglePayment(false);
        
            while (m.find())
            {
                if (m.group(1) != null) setMsgId(m.group(1));
                if (m.group(2) != null) setTrnsCount(Integer.parseInt(m.group(2)));
                if (m.group(3) != null) setCtrlSum(m.group(3));
                if (m.group(4) != null) setPartyName(m.group(4));
                if (m.group(5) != null) instdBic=m.group(5);
        
            }//while
        
            setInitiatingPartyCustCode(CacheKeys.banksKey.getSingle("***").getCustCode());
            if (instdBic != null)
            {
                instdBic = instdBic.substring(0, 8) + "XXX";
                SwiftId swiftId = CacheKeys.swiftIdPerSwiftIdKey.getSingle(instdBic);
                if (swiftId != null)
                {
                        setOffice(swiftId.getOffice());
                        setInitiatingPartyCustCode(CacheKeys.customrsBICandOfficeKey.getSingle(instdBic, swiftId.getOffice()).getCustCode());
                }
            }
        
            this.getByteBuffer().removeRangeFromBeginning((int)this.getPrePmtInfoEndIndex());
                this.setTotalDeleted(this.getTotalDeleted() + getPrePmtInfoEndIndex());
        
        }//EOM init()

        public AbstractSingleInMuliSchemaReader(File file, RandomAccessFile raf,
                        int chunkSize, FileMessageTypeData fileMessageTypeData) {
                super(file, raf, chunkSize, fileMessageTypeData);
        }

        @Override
        protected boolean readTransactionsOfChunkSize() {
        
                        int transactionStartTagIndex = GlobalConstants.DEFAULT_NOT_FOUND_VALUE;
                        int transactionEndTagIndex = GlobalConstants.DEFAULT_NOT_FOUND_VALUE;
        
                        byte[] transactionStartTagBytes = getFileMessageTypeData().getTransactionStartTagBytes();
                        byte[] transactionEndTagBytes = getFileMessageTypeData().getTransactionEndTagBytes();
        
        
                        int transactionEndTagLength = transactionEndTagBytes.length;
        
                        listFileIndexDataType.clear();
        
                        boolean continueWithSameReader = true;
                        transactionStartTagIndex = -2;
                        while ((getByteCount() < getFileSize() || transactionStartTagIndex != -1)
                                        && listFileIndexDataType.size() < getChunkSize()) {
        
                                try {
        
                                        // look for the first appearing tag from the start transaction
                                        // tag list
        
                                        // if new scheme indicating tag found, change the scheme
                                        // means a tag indicating a new transaction is found
        
                                        // get new file index data type which will conation the
                                        // indexes of the transcation
                                        if (transactionStartTagIndex > -1) {
                                                FileIndexDataType fileInfo = FileIndexDataType.Factory
                                                                .newInstance();
                                                // set the transaction starting tag index
                                                fileInfo.setTransactionStartTag(transactionStartTagIndex
                                                                + this.getTotalDeleted());
        
                                                
                                                transactionEndTagIndex = this
                                                                .findAndReadTillNearestTagInChunk(
                                                                                transactionEndTagBytes,
                                                                                0
                                                                                                + transactionStartTagBytes.length + TILL_XML_NS_SPACING);
                                                
                                                
                                                // set the transaction end tag index
                                                fileInfo.setTransactionEndTag(transactionEndTagIndex
                                                                + transactionEndTagLength + this.getTotalDeleted());
                                                // delete the buffer untill the end of the transcation
                                                this.getByteBuffer()
                                                                .removeRangeFromBeginning(transactionEndTagIndex
                                                                                + transactionEndTagLength);
                                                this.setTotalDeleted(this.getTotalDeleted()
                                                                + (transactionEndTagIndex
                                                                                + transactionEndTagBytes.length));
        
                                                // fileInfo.setTransactionStartTag(transactionStartTagIndex);
                                                // fileInfo.setTransactionEndTag(transactionEndTagIndex);
        
                                                fileInfo.setPaymentInfoStartTag(getGlobalHeaderStartTagIndex());
                                                fileInfo.setPaymentInfoEndTag(getGlobalHeaderEndTagIndex());
                                                fileInfo.setPaymentType(getFileMessageTypeData()
                                                                .getPaymentTypeName());
                                                fileInfo.setPaymentInfoElementStartTag(getFileMessageTypeData()
                                                                .getPaymentInfoElementStartTag());
        
                                                fileInfo.setMultiPaymentGroupingTagEnd(this.getFileMessageTypeData().getMultiPaymentGroupingTagEnd());  
                                                fileInfo.setMultiPaymentGroupingTagStart(this.getFileMessageTypeData().getMultiPaymentGroupingTagStart());
                                                listFileIndexDataType.add(fileInfo);
                                                setNumOfTrxActuallyReadFromFile(getNumOfTrxActuallyReadFromFile()+ 1);
                                        }
        
                                        java.util.ArrayList<byte[]> lst =  new java.util.ArrayList<byte[]>();
        
                                        lst.add(newSchemeBytes);
                                        lst.add(transactionStartTagBytes);
        
                                        FindWordResponse resp = findAndReadTillNearestTagsInChunk(0 , lst);
                                        int newSchemaIndicator = -1;
                                        if ( Arrays.equals(resp.getWatchWord(), transactionStartTagBytes) ){
                                                transactionStartTagIndex = resp.getLocation();
                                        }else if ( Arrays.equals(resp.getWatchWord(), newSchemeBytes) ) {
                                                 newSchemaIndicator = 1;
                                        }else {
                                                continueWithSameReader = false;
                                                break;
                                        }
                                        
                                        
                                        
                                        // Here is where the current reader checks if there's another schema starting.
        //                              // in case it does, it marks it's location and breaks the loop
                                                if (newSchemaIndicator != -1 && transactionStartTagIndex != -1) {
                                                        // we found a new schema entry, so no we expect a start group tag.
                                                        int toDelete  = getByteBuffer().indexOfWithStartEndIndex(getFileMessageTypeData().getGrpHdrStartTag().getBytes(), 0,  SEEK_RANGE_FOR_NEAR_TAG_SIZE);
                                                        if (toDelete == -1) {
                                                                toDelete = findAndReadTillNearestTagInChunk(getFileMessageTypeData().getGrpHdrStartTag().getBytes(), 0);
                                                        }
                                                        
                                                        // TODO all this hard coded (250 etc..) variables need to be replaced with something a little more dynamic.  
                                                        // At the moment we (well, I..) don't have enough info about the file formats. 
                                                        int endOfPrevSchema  = getByteBuffer().indexOfWithStartEndIndex(GlobalConstants.CLOSE_XML_TAG.getBytes(), 0,  SEEK_RANGE_FOR_NEAR_TAG_SIZE);
                                                        // +1 is to add ">" for the schema tag
                                                        int newSchemaIndex  = getByteBuffer().indexOfWithStartEndIndex(GlobalConstants.LESS_THEN.getBytes(), endOfPrevSchema + GlobalConstants.GREATER_THEN.length(),  SEEK_RANGE_FOR_NEAR_TAG_SIZE); 
                                                        int newSchemaIndexEnd  = getByteBuffer().indexOfWithStartEndIndex(GlobalConstants.GREATER_THEN.getBytes(), newSchemaIndex,  SEEK_RANGE_FOR_NEAR_TAG_SIZE); 
                                                        
                                                        setNewSchemeIndex((int)getTotalDeleted() + newSchemaIndex);
                                                        setNewSchemeIndexEnd((int)getTotalDeleted() +newSchemaIndexEnd  +1);
                                                        
                                                        this.getByteBuffer()
                                                                        .removeRangeFromBeginning(toDelete);
                                                        this.setTotalDeleted(this.getTotalDeleted() + toDelete);
                                                        continueWithSameReader = false;
                                                        break;
                                                }
                                        
                                }// try
                                catch (Exception e) {
                                        logger.error(e.getMessage());
                                        ExceptionController.getInstance().handleException(e, this);
                                        throw new RuntimeException("Problem reading " + getByteCount()
                                                        + " chunk");
                                }
                        }
        
                        if(!GlobalUtils.isListNullOrEmpty(listFileIndexDataType))
                        {
                                FileIndexDataType[] arrFileIndexDataType = new FileIndexDataType[listFileIndexDataType.size()];
                                getCurrentChunk().getPerformDebulkingMultiRequest().setFileIndexDataTypeListArray(listFileIndexDataType.toArray(arrFileIndexDataType));
        
                                //PreStartDataType[] arrPreStartDataType = new PreStartDataType[listPreStartDataType.size()];
                                getCurrentChunk().getPerformDebulkingMultiRequest().setPreStartDataListArray(arrayPreStartDataType);
        
                                getCurrentChunk().getPerformDebulkingMultiRequest().setEndTags(getFileMessageTypeData().getXmlClosingTags());
        
                                return true && continueWithSameReader;
                        }else
                        {
                                return false;
                        }
        
        
                }//EOM readTransactionsOfChunkSize

        /**
        * the method gets as parameter a tag and a start index and return its earliest index in the file,
        * if the received tag is not present, another chunk from the file is read and
        * the search for the tag continues.
        * @param tag - tag to look for in the file
        * @param startIndex - start index for looking
        * @return index of the first occurrence (in current read chunk from file)
        * @throws IOException
        */
        protected int findAndReadTillNearestTagInChunk(byte[] tag, int startIndex) throws IOException 
        {
                int EndTagIndex = -1;//will hold the index of the current bulk end tag index.
                String currentEndTag = getEndTag(tag);// get the right end tag (of CreditTransfer or DirectDebit for any other case there is a need to change this function )
                boolean bFindEndTag = currentEndTag != null;//do not try to find the index if the tag is empty.
                // check if there is occurrence of the tag in the current chunk.
                int index = getByteBuffer().indexOf(tag, startIndex ); 
                if (bFindEndTag) EndTagIndex = getByteBuffer().indexOf(currentEndTag.getBytes(), startIndex);//do the same as index above.
                
                while (index == -1 && EndTagIndex == -1) // if the tag end of the bulk and the tag start are not found there is a  need to rotate the byte buffer. 
                {
                    if (getByteCount() >= getFileSize())
                        break;
                    int temp = getByteBuffer().getSize();
                    // Read next chunk
                    setSize(getFileSize() - getByteCount() > BUFFER_SIZE ? BUFFER_SIZE : getFileSize() - getByteCount());
                    startIndex = getByteBuffer().getSize();
                    getUtils().getM_raf().seek(getByteCount());
                    getUtils().readToByteArrayListEnd(this.getByteBuffer(), (int)getSize());
                    setByteCount(getByteCount() + getSize());
                    // set startIndex to the last checked index to avoid duplicate search
                    index = getByteBuffer().indexOf(tag, temp - tag.length);

                    if (bFindEndTag)
                    {// just like above fetch the info of EndTagIndex.
                        EndTagIndex = getByteBuffer().indexOf(currentEndTag.getBytes(), temp - currentEndTag.getBytes().length);

                        //Handles a specific case where an end tag is searched by can't be found since the buffer only contains part of it.
                        if (index != -1 && EndTagIndex == -1)
                        {
                            //If such tag is found, expend the buffer until a closing bracket is found, and add the closing tag length.
                            if (getClosingFITorPmtRtrtagIndex(currentEndTag,temp,tag) != -1)
                            {
                                ExpandBufferUntilClosingTag();
                                getUtils().readToByteArrayListEnd(this.getByteBuffer(), currentEndTag.length());                               
                                //EndTagIndex is now found.
                                EndTagIndex = getByteBuffer().indexOf(currentEndTag.getBytes(), temp - currentEndTag.getBytes().length); 
                            }
                        }
                    }
                }
                if (EndTagIndex>0)// if the tag was found save the index on the RandomAccessFileUtils.
                {
                	getUtils().setM_nNewBulkIndex(this.getTotalDeleted() +EndTagIndex + currentEndTag.getBytes().length);
                }                
                return index;
        }        
        //Expand the byte array buffer until a closing bracket is found and return its absolute index.
        private int ExpandBufferUntilClosingTag()
        {
            int counter, closingTagIndex = -1;
            
            for (counter = 0; closingTagIndex == -1; counter++)
            {
                getUtils().readToByteArrayListEnd(getByteBuffer(), 1);
                closingTagIndex = getByteBuffer().indexOf(">".getBytes(), getByteBuffer().getSize()-1);
            }
            
            return counter;

        }
        
        private int getClosingFITorPmtRtrtagIndex(String currentEndTag,int temp,byte[] tag)
        {
        	int closingFITorPmtRtrtagIndex = -1;
	        if (currentEndTag.equals(sCreditTransferEndTag))
	        {
	        	closingFITorPmtRtrtagIndex = getByteBuffer().indexOf("</ct:FIT".getBytes(), temp - "</ct:FIT".getBytes().length);
	        }
	        else if (currentEndTag.equals(sDebitTransferEndTag))
	        {
	        	closingFITorPmtRtrtagIndex = getByteBuffer().indexOf("</dd:FIT".getBytes(), temp - "</dd:FIT".getBytes().length);
	        }
	        else if (currentEndTag.equals(sCreditPaymentReturnEndTag) || currentEndTag.equals(sDebitPaymentReturnEndTag))
	        {
	        	closingFITorPmtRtrtagIndex = getByteBuffer().indexOf("</pr:PmtRtr".getBytes(), temp - "</pr:PmtRtr".getBytes().length);
	        }
	        return closingFITorPmtRtrtagIndex;
        }

        private String getEndTag(byte[] tag)
        {
        		G3BulkMessageMetadata getCurrentMsgType = getUtils().getCurrentMsgType();
                String currentEndTag=null;
                if (new String(tag).equals("</ct:" +PDOConstantFieldsInterface.CdtTrfTxInf + ">") || 
                	new String(tag).equals( "<ct:" +PDOConstantFieldsInterface.CdtTrfTxInf + ">"))
                {
                        currentEndTag = sCreditTransferEndTag;
                }
                else if (new String(tag).equals("</dd:" + PDOConstantFieldsInterface.DrctDbtTxInf+ ">") ||
                		 new String(tag).equals( "<dd:" + PDOConstantFieldsInterface.DrctDbtTxInf+ ">"))
                {
                        currentEndTag = sDebitTransferEndTag;
                }
                else if (new String(tag).equals("</pr:" + PDOConstantFieldsInterface.Pacs004TxInf+ ">") && getCurrentMsgType.g3PayloadName.equals("CreditPaymentReturn") ||
                	     new String(tag).equals( "<pr:" + PDOConstantFieldsInterface.Pacs004TxInf+ ">") && getCurrentMsgType.g3PayloadName.equals("CreditPaymentReturn")) 
                {
                	currentEndTag = sCreditPaymentReturnEndTag;
                }
                else if (new String(tag).equals("</pr:" + PDOConstantFieldsInterface.Pacs004TxInf+ ">") && getCurrentMsgType.g3PayloadName.equals("DebitPaymentReturn") ||
                		new String(tag).equals( "<pr:" + PDOConstantFieldsInterface.Pacs004TxInf+ ">") && getCurrentMsgType.g3PayloadName.equals("DebitPaymentReturn"))
                {
                	currentEndTag = sDebitPaymentReturnEndTag;
                }
                return currentEndTag;
        }
        
        
        /**
         * receives a word list and a start index and search for the nearest
         * appearance of any of the words, reads from file if needed until the any
         * of the words is found, returns the first found word and it's index
         *
         * @param startIndex - start index to look from
         * @param tags - word list (converted to bytes)
         * @return - first found word and its index on the file.
         * @throws IOException
         */
        protected FindWordResponse findAndReadTillNearestTagsInChunk(int startIndex, ArrayList<byte[]> tags)
                        throws IOException {
                                FindWordResponse response= getByteBuffer()
                                                                        .indexOfFirstAppearingWord(tags, startIndex);
                                while (response.getLocation()== -1) {
                                        if (getByteCount() >= getFileSize())
                                                break;
                                        int temp = getByteBuffer().getSize();
                                        // Read next chunk
                                        setSize(getFileSize() - getByteCount() > BUFFER_SIZE ? BUFFER_SIZE
                                                        : getFileSize() - getByteCount());
                                        //setByteCount(getByteCount() + getSize());
                                        // set startIndex to the last checked index to avoid duplicate search
                                        startIndex = getByteBuffer().getSize();
                                        getUtils().getM_raf().seek(getByteCount());
                                        getUtils().readToByteArrayListEnd(this.getByteBuffer(), (int)getSize());
                                        setByteCount(getByteCount() + getSize());
                                        //m_totalDeleted += m_byteBuffer.size();
                                        response = getByteBuffer().indexOfFirstAppearingWord(tags, temp);
                        
                                }
                                return response;
                        }

        @Override
        protected void readPreTransactionData() {
        
                        super.readPreTransactionData();
        
                        //PRE section
        //              String docPreEndTag = getFileMessageTypeData().getPreDocumentEnd();
        //              setDocPreEndTagIndex(getByteBuffer().indexOf(docPreEndTag.getBytes()) + docPreEndTag.getBytes().length);
        
                }//EOM readPreTransactionData

        @Override
        public int getRecCountInChunk(Object chunk) {
                PerformDebulkingMultiRequestDocument doc = (PerformDebulkingMultiRequestDocument)chunk;
                PerformDebulkingMultiRequestType debulkingMultyRequest = doc.getPerformDebulkingMultiRequest();
                return debulkingMultyRequest.getFileIndexDataTypeListArray().length;
        }

        @Override
        public String getXmlofChunk(Object chunk) {
                PerformDebulkingMultiRequestDocument doc = (PerformDebulkingMultiRequestDocument)chunk;
                return doc.xmlText();
        }

        @Override
        public void setAdditionalDocumentData(Object request, String chunkId,
                        String status, String internalFileId, String path, String workFlow, String bulkId) {
                        
                                PerformDebulkingMultiRequestDocument doc = (PerformDebulkingMultiRequestDocument)request;
                                PerformDebulkingMultiRequestType debulkingMultyRequest = doc.getPerformDebulkingMultiRequest();
                                debulkingMultyRequest.setChunkId(chunkId);
                            debulkingMultyRequest.setStatus(status);
                            debulkingMultyRequest.setInternalFileId(internalFileId);
                            debulkingMultyRequest.setPath(path);
                            debulkingMultyRequest.setWorkflow(workFlow);
                            debulkingMultyRequest.setBulkId(bulkId);
                        }

        
         abstract public List<PDO> getPDOsFromChunk(PerformDebulkingMultiRequestDocument doc,String chunkId, String sInternalFileID,final FileSummary fileSummary,
                          final Map[] arrMapSharedPDOContextHolder, final boolean bShouldLogInfo) throws Throwable;
        
        
        
        
}