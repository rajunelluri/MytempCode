package backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi;

import static backend.core.module.MessageConstantsInterface.MESSAGE_TYPE_PACS_003;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.X_FITOFICSTMRDRCTDBT;

import java.io.File;
import java.io.RandomAccessFile;
import java.util.Map;

import backend.paymentprocess.debulkingprocess.common.WorkflowType;

import com.fundtech.cache.entities.LogicalFieldsXpath;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.paymenttypes.PaymentType;

/**
 * Concrete SingleMessageTypeData for pacs 03.
 * 
 * @author haimv
 * @author dmitryp
 */
public class SinglePacs03 extends SingleMessageTypeData{
	
	// TODO Do not use hard-coded tags - take it from logical_fields_xpath cache.
	
//	private String  PACS_03_TRANSACTION_START_TAG = "<%sDrctDbtTxInf>";
//	private String  PACS_03_TRANSACTION_END_TAG   = "</%sDrctDbtTxInf>";
		private String  PACS_03_TRANSACTION_START_TAG = "";
	private String  PACS_03_TRANSACTION_END_TAG   = "";
	private Map<String, LogicalFieldsXpath> logicalFieldsXPathMap;

	/**
	 * 
	 */
	public SinglePacs03(PaymentType paymentType) {
		super(paymentType);
		this.setPaymentType(paymentType);
		CLOSE_XML_TAGS = "</%sFIToFICstmrDrctDbt></%sDocument>";
		MULTI_FILE_START_TAG = 	 "<%sFIToFICstmrDrctDbt>";
		logicalFieldsXPathMap = CacheKeys.LogicalFieldsXPathKey.getSingle(PaymentType.valueOf(MESSAGE_TYPE_PACS_003));
	}

//	@Override
//	public void initTags()
//	{
//		super.initTags();
//		PaymentType paymentType = PaymentType.valueOf(this.getPaymentType());    
//        Map<String, LogicalFieldsXpath> map =CacheKeys.LogicalFieldsXPathKey.getSingle(paymentType);  
//        
//       PACS_03_TRANSACTION_START_TAG =  this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_CDT_TRNF_INFO).getTagName(),false);
//       PACS_03_TRANSACTION_END_TAG =  this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_CDT_TRNF_INFO).getTagName(), true);
//	}
//	
//	@Override
//	public String getTransactionStartTag() {
//		return PACS_03_TRANSACTION_START_TAG;
//	}
//	
//	@Override
//	public String getTransactionEndTag() {
//		return PACS_03_TRANSACTION_START_TAG;
//	}
	
	public void initTags(PaymentType paymentType)
	{
  
        Map<String, LogicalFieldsXpath> map =CacheKeys.LogicalFieldsXPathKey.getSingle(paymentType);  
        
       GROUP_HEADER_START_TAG =  this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_GRP_INFO).getTagName(),false);
       GROUP_HEADER_END_TAG =  this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_GRP_INFO).getTagName(), true);
       
//       PAYMENT_INFO_START_TAG =  this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_PMT_INFO).getTagName(), false);
//       PAYMENT_INFO_END_TAG =  this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_PMT_INFO).getTagName(), true);
//       
       //TODO: NO FIELDS AT LOGICAL FIELDS XPATH
       PAYMENT_INFO_START_TAG=  "";
       PAYMENT_INFO_END_TAG = "";
       
       
      TRANSACTION_START_TAG =  this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_PMT_INFO).getTagName(), false);
      TRANSACTION_END_TAG =  this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_PMT_INFO).getTagName(), true);
	}

	@Override
	public String getTypeIdentifier() {
		return paymentType.getSchemaNamespace();
	}

	@Override
	public String getPaymentTypeName() {
		//return "pacs.003";
		return paymentType.name();
	}

	@Override
	public String getPreDocumentEnd() {
		return getGrpHdrStartTag();
	}

	@Override
	public String getPrePmtInfEnd() {
		return getTransactionStartTag();
	}

	@Override
	public XmlTransactionReaderBase getReader() {
		// TODO Auto-generated method stub
		if (defaultCtorReader == null) defaultCtorReader = new PacsTransactionReader(this);
		return defaultCtorReader;
	}
	
	@Override
	public XmlTransactionReaderBase getReader(File file, int chunkSize) {
		if (reader == null) {
			reader = new PacsTransactionReader(file, chunkSize,this);
		}
		return reader;
	}
	
	@Override
	public XmlTransactionReaderBase getReaderWithoutInit(File file, int chunkSize, RandomAccessFile accessFile)
	{
		if (reader == null) {
			reader = new PacsTransactionReader(file,accessFile, chunkSize,this);
		}
		return reader;
	}


	@Override
	public String getWorkflow() {
		return WorkflowType.Pacs_003.name();
	}

	@Override
	public void formatTags(String namespace)
	{
		super.formatTags(namespace);
		this.PACS_03_TRANSACTION_END_TAG   = String.format(this.PACS_03_TRANSACTION_END_TAG,namespace);
		this.PACS_03_TRANSACTION_START_TAG = String.format(this.PACS_03_TRANSACTION_START_TAG,namespace);
	}

	@Override
	public byte[] getPaymentInfoElementStartTagBytes() {
		return getPaymentInfoElementStartTag().getBytes();
	}

	@Override
	public byte[] getTransactionEndTagBytes() {
		return getTransactionEndTag().getBytes();
	}

	@Override
	public byte[] getTransactionStartTagBytes() {
		return getTransactionStartTag().getBytes();
	}

	@Override
	public byte[] getPaymentInfoElementEndTagBytes() {
		// TODO
		return null;
	}

	/**
	 * @return the header tag
	 */
	@Override
	public String getHeaderTag() {
		LogicalFieldsXpath logicalFieldsXpath = logicalFieldsXPathMap.get(X_FITOFICSTMRDRCTDBT) ;			
		return logicalFieldsXpath.getTagName(); // FIToFICstmrDrctDbt
	}
	
}//EOC SinglePacs03