package backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.fundtech.util.ExceptionController;
import com.fundtech.util.GlobalUtils;

import backend.dataaccess.dao.DAOBasic;
import backend.dataaccess.dto.DTOSingleValue;
import backend.paymentprocess.rebulking.dao.DAORebulkProcess;
import backend.staticdata.profilehandler.message.FILE_SUMMARYProfileHandler;

/**
 * @author liron
 *
 */
public class DAOFilesProcessing extends DAOBasic {

	private static FILE_SUMMARYProfileHandler fsHandler = FILE_SUMMARYProfileHandler.getInstance();
	private static DAORebulkProcess m_daoRebulkProcess = DAORebulkProcess.getInstance();

	public List<String[]> loadChunksOfFile(String internalFileId)
	{

		boolean isExist = false;

		String query = "select OUT_CHUNK_ID , GROUP_MSG_ID from out_file_buffers where OUT_FILE_ID = ? ";

		ResultSet rs = null;
		PreparedStatement ps = null;
		try
		{
			Connection con = super.getConnection();
			ps = con.prepareStatement(query);
			GlobalUtils.setObject(ps, 1, internalFileId);

			rs = ps.executeQuery();

			isExist = rs.next();
			if (!isExist)
				return Collections.emptyList();

			List<String[]> toReturn = new ArrayList<String[]>();
			do {
				toReturn.add(new String[] {rs.getString("OUT_CHUNK_ID"),rs.getString("GROUP_MSG_ID")});
			} while (rs.next());
			return toReturn;
		}
		catch(Exception e)
		{
			ExceptionController.getInstance().handleException(e, this);
			return Collections.emptyList();
		}finally
		{
			super.releaseResources(rs, ps);
		}
	}



	public List<String> loadChunksOfGroup(String outGroupingId)
	{

		boolean isExist = false;
		String query = "select OUT_CHUNK_ID from out_file_buffers where GROUP_MSG_ID = ? ";
		

		ResultSet rs = null;
		PreparedStatement ps = null;
		try
		{
			Connection con = super.getConnection();
			ps = con.prepareStatement(query);
			GlobalUtils.setObject(ps, 1, outGroupingId);

			rs = ps.executeQuery();

			isExist = rs.next();
			if (!isExist)
				return Collections.emptyList();

			List<String> toReturn = new ArrayList<String>();
			do {
				toReturn.add(rs.getString("OUT_CHUNK_ID"));
			} while (rs.next());
			return toReturn;
		}
		catch(Exception e)
		{
			ExceptionController.getInstance().handleException(e, this);
			return Collections.emptyList();
		}
		finally
		{
			super.releaseResources(rs, ps);
		}
	}


	public String performFileMatching(String fileRef)
	{

		boolean isExist = false;
		
		
		String query = "SELECT INTERNAL_FILE_ID FROM FILE_SUMMARY WHERE INTERNAL_FILE_ID = ? AND REL_INTERNAL_FILE_ID IS NULL";
		
		
		
		ResultSet rs = null;
		String toReturn = "";
		PreparedStatement ps = null;
		try
		{
			Connection con = super.getConnection();
			ps = con.prepareStatement(query);
			GlobalUtils.setObject(ps, 1, fileRef);

			rs = ps.executeQuery();

			isExist = rs.next();
			if (!isExist)
				return "";



			toReturn = rs.getString("INTERNAL_FILE_ID");
			return toReturn;
		}
		catch(Exception e)
		{
			ExceptionController.getInstance().handleException(e, this);
			return toReturn;
		}
		finally
		{
			super.releaseResources(rs, ps);
		}
	}



	public String performFileMatching(String origFName, String rcvgInst)
	{

		boolean isExist = false;
		String query = "select INTERNAL_FILE_ID from file_summary where file_reference = ? and Initg_Pty_Cust_Code = ?";

		ResultSet rs = null;
		String toReturn = "";
		PreparedStatement ps = null;
		try
		{
			Connection con = super.getConnection();
			ps = con.prepareStatement(query);
			GlobalUtils.setObject(ps, 1, origFName);
			GlobalUtils.setObject(ps, 2, rcvgInst);

			rs = ps.executeQuery();

			isExist = rs.next();
			if (!isExist)
				return "";



			toReturn = rs.getString("INTERNAL_FILE_ID");
			return toReturn;
		}
		catch(Exception e)
		{
			ExceptionController.getInstance().handleException(e, this);
			return toReturn;
		}
		finally
		{
			super.releaseResources(rs, ps);
		}
	}


	//TODO: CHANGE TO USE FEEDBACK AS WELL
	public boolean updateFileStatus(String internalFileId, String Status)
	{
		String query = "update file_summary set status = ? where internal_file_id = ? ";
		ResultSet rs = null;
		PreparedStatement ps = null;
		int rowsUpdated = 0;
		
		DTOSingleValue dtoStatus = m_daoRebulkProcess.getFILE_SUMMARY_Status(internalFileId);
		String sOldFileStatus = dtoStatus.isFeedBackSuccess() ? dtoStatus.getValue() : null;
		  
		try
		{
			Connection con = super.getConnection();
			ps = con.prepareStatement(query);
			GlobalUtils.setObject(ps, 1, Status);
			GlobalUtils.setObject(ps, 2, internalFileId);

			rowsUpdated = ps.executeUpdate();
		}
		catch(Exception e)
		{
			ExceptionController.getInstance().handleException(e, this);
			return false;
		}
		finally
		{
			super.releaseResources(rs, ps);
		}
		boolean statusUpdated = rowsUpdated > 0;
		
		if(statusUpdated)
			fsHandler.fileStatusAudit(Status, sOldFileStatus, internalFileId);
	    
	    return statusUpdated;
	}



	public List<String> loadGroupsOfFile(String outGroupingId)
	{

		boolean isExist = false;
		String query = "select OUT_CHUNK_ID from out_file_buffers where OUT_FILE_ID = ? ";

		ResultSet rs = null;
		PreparedStatement ps = null;
		try
		{
			Connection con = super.getConnection();
			ps = con.prepareStatement(query);
			GlobalUtils.setObject(ps, 1, outGroupingId);

			rs = ps.executeQuery();

			isExist = rs.next();
			if (!isExist)
				return Collections.emptyList();

			List<String> toReturn = new ArrayList<String>();
			do {
				toReturn.add(rs.getString("OUT_CHUNK_ID"));
			} while (rs.next());
			return toReturn;
		}
		catch(Exception e)
		{
			ExceptionController.getInstance().handleException(e, this);
			return Collections.emptyList();
		}
		finally
		{
			super.releaseResources(rs, ps);
		}
	}



}
