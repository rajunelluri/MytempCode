package backend.paymentprocess.debulkingprocess.parsing.xml.processing;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class IterableTransactionReader implements Iterable<String>
{
	private static final Logger logger = LoggerFactory.getLogger(IterableTransactionReader.class);
	private Object m_input;
	
	public IterableTransactionReader(Object input) 
	{
		m_input = input;
	}
	
	@Override
	public TransactionReader iterator() 
	{
		TransactionReader iter = null;
		try {
			iter= (TransactionReader)TransactionReader.class.getDeclaredMethod("TransactionReaderFactory", m_input.getClass()).invoke(null, m_input) ;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		}
		
		return iter;
	}

}
