package backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi;

import java.io.File;
import java.io.RandomAccessFile;
import java.util.Map;

import com.fundtech.cache.entities.LogicalFieldsXpath;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.paymenttypes.PaymentType;

/**
 * Concrete SingleMessageTypeData for pacs 03.
 * 
 * @author haimv
 * @author dmitryp
 */
public class SinglePain01 extends SingleMessageTypeData{
	
	// TODO Do not use hard-coded tags - take it from logical_fields_xpath cache.
//
//	private String PAIN_01_TRANSACTION_START_TAG = "<%sCdtTrfTxInf>";
//	private String PAIN_01_TRANSACTION_END_TAG = "</%sCdtTrfTxInf>";
//	
	


//	private byte[] TRANSACTION_END_TAG_BYTES = null;
//	private byte[] TRANSACTION_START_TAG_BYTES = null;
	
	public SinglePain01(PaymentType paymentType) {
		super(paymentType);
		this.setPaymentType(paymentType);
		CLOSE_XML_TAGS = "</%sPmtInf></%sCstmrCdtTrfInitn></%sDocument>";
		STARTING_XML_TAGS = "<Document xmlns=\""+paymentType.getSchemaNamespace()+"\"><CstmrCdtTrfInitn>";		
	}
	
	@Override
	public String getWorkflow() {
		 return"Pain_001";
	}
	
//	@Override
//	public void initTags()
//	{
//		super.initTags();
//		PaymentType paymentType = PaymentType.valueOf(this.getPaymentType());    
//        Map<String, LogicalFieldsXpath> map =CacheKeys.LogicalFieldsXPathKey.getSingle(paymentType);  
//        
//       PAIN_01_TRANSACTION_START_TAG =  this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_CDT_TRNF_INFO).getTagName(),false);
//       PAIN_01_TRANSACTION_END_TAG =  this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_CDT_TRNF_INFO).getTagName(), true);
//	}
//	
//	@Override
//	public String getTransactionStartTag() {
//		return PAIN_01_TRANSACTION_START_TAG;
//	}
//
//	@Override
//	public String getTransactionEndTag() {
//		return PAIN_01_TRANSACTION_END_TAG;
//	}

	@Override
	public String getTypeIdentifier() {
		// TODO Get the type from PaymentType		
		return "urn:iso:std:iso:20022:tech:xsd:pain.001.001.03";
	}

	@Override
	public String getPaymentTypeName() {
		return "Pain_001";
	}

	@Override
	public String getPreDocumentEnd() {
		return getGrpHdrStartTag();
	}

	@Override
	public String getPrePmtInfEnd() {
		return getTransactionStartTag();
	}

	@Override
	public XmlTransactionReaderBase getReader() {
		if (defaultCtorReader == null) {
			defaultCtorReader = new PainTransactionReader();
		}
		return defaultCtorReader;
	}

	
	@Override
	public XmlTransactionReaderBase getReader(File file, int chunkSize) {
		if (reader == null) {
			reader = new PainTransactionReader(file, chunkSize,this);
		}
		return reader;
	}
	
	
	@Override
	public XmlTransactionReaderBase getReaderWithoutInit(File file, int chunkSize, RandomAccessFile accessFile)
	{
		if (reader == null) {
			reader = new PainTransactionReader(file,accessFile, chunkSize,this);
		}
		return reader;
	}


	
	@Override
	public void formatTags(String namespace)
	{
		super.formatTags(namespace);
//		this.PAIN_01_TRANSACTION_END_TAG   = String.format(this.PAIN_01_TRANSACTION_END_TAG,namespace);
//		this.PAIN_01_TRANSACTION_START_TAG = String.format(this.PAIN_01_TRANSACTION_START_TAG,namespace);
//		this.PAIN_01_CLOSE_XML_TAGS 	   = String.format(this.PAIN_01_CLOSE_XML_TAGS,namespace,namespace,namespace);
//		
//		if(TRANSACTION_END_TAG_BYTES == null)
//		{
//			TRANSACTION_END_TAG_BYTES = getTransactionEndTag().getBytes();
//		}
//		if(TRANSACTION_START_TAG_BYTES == null)
//		{
//			TRANSACTION_START_TAG_BYTES = getTransactionStartTag().getBytes();
//		}
	}

	@Override
	public byte[] getPaymentInfoElementStartTagBytes() {
		return getPaymentInfoElementStartTag().getBytes();
	}
	
		@Override
	public byte[] getPaymentInfoElementEndTagBytes() {
		return getPaymentInfoElementEndTag().getBytes();
	}
		
		
	@Override
	public void initTags(PaymentType paymentType) {
        Map<String, LogicalFieldsXpath> map =CacheKeys.LogicalFieldsXPathKey.getSingle(paymentType);  
        
       GROUP_HEADER_START_TAG =  this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_GRP_INFO).getTagName(),false);
       GROUP_HEADER_END_TAG =  this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_GRP_INFO).getTagName(), true);
       
       PAYMENT_INFO_START_TAG =  this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_PMT_INFO).getTagName(), false);
       PAYMENT_INFO_END_TAG =  this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_PMT_INFO).getTagName(), true);

       //TODO: NO FIELD AT LOGICAL X PATH
      TRANSACTION_START_TAG =  this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_CDT_TRNF_INFO).getTagName(), false);
      TRANSACTION_END_TAG =  this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_CDT_TRNF_INFO).getTagName(), true);       
	}
	
	protected void formatXmlClosingTags(String namespace) {
		this.CLOSE_XML_TAGS    = String.format(this.CLOSE_XML_TAGS,namespace,namespace,namespace);		
	}
}//EOF SinglePain01.java