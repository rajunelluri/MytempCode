package backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi;

import java.io.InputStream;

import javax.xml.namespace.QName;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.core.paymentprocess.data.paymenttypes.PaymentType;

public class FndtMultiBatchMessageStreamBasedParser extends FndtMessageStreamBasedAbstractParser{
private static final Logger logger = LoggerFactory.getLogger(FndtMultiBatchMessageStreamBasedParser.class);
	
	private XMLEventReader reader;
	static final String FNDT_MSG_URI = PaymentType.valueOf(PaymentType.PT_FNDT_MSG).getSchemaNamespace();

	private static final int MAX_HEADER_SIZE = 10240*8;
	
	FndtBatchMessageStreamBasedParser innerParser;
	
	class FndtMultiBatchMsgParseResult {

		FndtMultiBatchMsgParseResult(){
		}
		
		private FndtBatchMsgParseResult bulkResult;

		private boolean fndtPrtryAppHdrStarted = false;
		private boolean fndtPrtryAppHdrEnded = false;
		private String sndgInst;
		private String sndgNm;
		private String rcvgInst;
		private String fileRef;
		private String fSrc;
		private String fType;
		private String fDtTm;
		private String numCTBlk;
		private String numDDBlk;
		private String cstmFileValdtion;

		private String bulkStartTag;

		private long bulkStartTagLocation;

		private String documentStartTag;
		private long documentStartTagLocation;

		private long sndgInstTagLocation;

		private String fndtPrtryAppHdrStartTag;
		
		private long fndtPrtryAppHdrStartTagLocation;
		
		
		
		public String getFirstMissingTagName() {
			if (!fndtPrtryAppHdrStarted)
				return "FndtPrtryAppHdr start element";
			if (!fndtPrtryAppHdrEnded)
				return "FndtPrtryAppHdr end element";
			/*if (!batchHeaderEnded)
				return "BatchHeader end element";
			if (!pmntHeaderStarted)
				return "PmntHeader start element";
			if (!nativePmtInfStarted)
				return "PmtInf start element";
			if (!pmntHeaderEnded)
				return "PmntHeader end element";
			if (!fndtMsgStarted)
				return "FndtMsg start element";
			if (!nativePayloadStarted)
				return "native Payload Start element>";*/
			return null;
		}

		public void setBulkStartTagLocation(long bulkStartTagLocation){
			this.bulkStartTagLocation=bulkStartTagLocation;
		}
		
		public long getBulkStartTagLocation() {
			return bulkStartTagLocation;
		}

		public FndtBatchMsgParseResult getBulkResult() {
			return bulkResult;
		}

		public void setBulkResult(FndtBatchMsgParseResult bulkResult) {
			this.bulkResult = bulkResult;
		}


		@Override
		public String toString() {
			return "FndtMultiBatchMsgParseResult [ sndgInst="
					+ sndgInst
					+ ", sndgNm="
					+ sndgNm
					+ ", rcvgInst="
					+ rcvgInst
					+ ", fileRef="
					+ fileRef
					+ ", fSrc="
					+ fSrc
					+ ", fType="
					+ fType
					+ ", fDtTm="
					+ fDtTm
					+ ", numCTBlk="
					+ numCTBlk
					+ ", numDDBlk="
					+ numDDBlk
					+ ", cstmFileValdtion="
					+ cstmFileValdtion
					+ "]";
			
		}


		public String getSndgInst() {
			return sndgInst;
		}


		public void setSndgInst(String sndgInst) {
			this.sndgInst = sndgInst;
		}


		public String getSndgNm() {
			return sndgNm;
		}


		public void setSndgNm(String sndgNm) {
			this.sndgNm = sndgNm;
		}


		public String getRcvgInst() {
			return rcvgInst;
		}


		public void setRcvgInst(String rcvgInst) {
			this.rcvgInst = rcvgInst;
		}


		public String getFileRef() {
			return fileRef;
		}


		public void setFileRef(String fileRef) {
			this.fileRef = fileRef;
		}


		public String getfSrc() {
			return fSrc;
		}


		public void setfSrc(String fSrc) {
			this.fSrc = fSrc;
		}


		public String getfType() {
			return fType;
		}


		public void setfType(String fType) {
			this.fType = fType;
		}


		public String getfDtTm() {
			return fDtTm;
		}


		public void setfDtTm(String fDtTm) {
			this.fDtTm = fDtTm;
		}


		public String getNumCTBlk() {
			return numCTBlk;
		}


		public void setNumCTBlk(String numCTBlk) {
			this.numCTBlk = numCTBlk;
		}


		public String getNumDDBlk() {
			return numDDBlk;
		}


		public void setNumDDBlk(String numDDBlk) {
			this.numDDBlk = numDDBlk;
		}


		public String getCstmFileValdtion() {
			return cstmFileValdtion;
		}


		public void setCstmFileValdtion(String cstmFileValdtion) {
			this.cstmFileValdtion = cstmFileValdtion;
		}


		public void setResultList(FndtBatchMsgParseResult resultList) {
			this.bulkResult = resultList;
		}


		public void setBulkStartTag(String bulkStartTag) {
			this.bulkStartTag=bulkStartTag;
		}

		public String getBulkStartTag() {
			return bulkStartTag;
		}

		public void setDocumentStartTag(String documentStartTag) {
			this.documentStartTag=documentStartTag;
			
		}

		public long getDocumentStartTagLocation() {
			return documentStartTagLocation;
		}

		public void setDocumentStartTagLocation(long documentStartTagLocation) {
			this.documentStartTagLocation = documentStartTagLocation;
		}

		public String getDocumentStartTag() {
			return documentStartTag;
		}

		public void setSndgInstTagLocation(long sndgInstTagLocation) {
			this.sndgInstTagLocation=sndgInstTagLocation;
		}

		public long getSndgInstTagLocation() {
			return sndgInstTagLocation;
		}

		public void setFndtPrtryAppHdrStartTag(String fndtPrtryAppHdrStartTag) {
			this.fndtPrtryAppHdrStartTag=fndtPrtryAppHdrStartTag;
			
		}

		public long getFndtPrtryAppHdrStartTagLocation() {
			return fndtPrtryAppHdrStartTagLocation;
		}

		public void setFndtPrtryAppHdrStartTagLocation(
				long fndtPrtryAppHdrStartTagLocation) {
			this.fndtPrtryAppHdrStartTagLocation = fndtPrtryAppHdrStartTagLocation;
		}

		public String getFndtPrtryAppHdrStartTag() {
			return fndtPrtryAppHdrStartTag;
		}		
		
		
	}
	
	public FndtMultiBatchMessageStreamBasedParser(InputStream inputStream) throws XMLStreamException {
		XMLInputFactory ifactory = XMLInputFactory.newInstance();
		reader = ifactory.createXMLEventReader(inputStream);
		 innerParser=new FndtBatchMessageStreamBasedParser(inputStream);
	}
	
	
	public FndtMultiBatchMsgParseResult parseHead() throws XMLStreamException {
		FndtMultiBatchMsgParseResult headResult = new FndtMultiBatchMsgParseResult();
		
		XMLEvent e = null;
		
		new DynamicEventFilter(new QName(FNDT_MSG_URI,"FndtPrtryAppHdr"));
		
		while (reader.hasNext()) {
			e = reader.nextEvent();
			
			enforceHeadMaxLimit(e,headResult);
			
				if (e.isStartElement()) {
					
			          StartElement startElement = e.asStartElement();
			          if (startElement.getName().getLocalPart() == ("FndtFileDocument")) {
			        	  headResult.setDocumentStartTagLocation(e.getLocation().getCharacterOffset());
			        	  continue;
			          }
			          if (startElement.getName().getLocalPart() == ("FndtPrtryAppHdr")) {
			        	  headResult.setFndtPrtryAppHdrStartTagLocation(e.getLocation().getCharacterOffset());
			        	  continue;
			          }
			          if (startElement.getName().getLocalPart() == ("SndgInst")) {
			        	  headResult.setSndgInstTagLocation(e.getLocation().getCharacterOffset());
			        	  e=reader.nextEvent();
			        	  headResult.setSndgInst(e.asCharacters().getData());
			        	  continue;
			          }
			          if (startElement.getName().getLocalPart() == ("SndgNm")) {
			        	  e=reader.nextEvent();
			        	  headResult.setSndgNm(e.asCharacters().getData());
			        	  continue;
			          }
			          if (startElement.getName().getLocalPart() == ("RcvgInst")) {
			        	  e=reader.nextEvent();
			        	  headResult.setRcvgInst(e.asCharacters().getData());
			        	  continue;
			          }
			          if (startElement.getName().getLocalPart() == ("FileRef")) {
			        	  e=reader.nextEvent();
			        	  headResult.setFileRef(e.asCharacters().getData());
			        	  continue;
			          }
			          if (startElement.getName().getLocalPart() == ("FSrc")) {
			        	  e=reader.nextEvent();
			        	  headResult.setfSrc(e.asCharacters().getData());
			        	  continue;
			          }
			          if (startElement.getName().getLocalPart() == ("FType")) {
			        	  e=reader.nextEvent();
			        	  headResult.setfType(e.asCharacters().getData());
			        	  continue;
			          }
			          if (startElement.getName().getLocalPart() == ("FDtTm")) {
			        	  e=reader.nextEvent();
			        	  headResult.setfDtTm(e.asCharacters().getData());
			        	  continue;
			          }
			          if (startElement.getName().getLocalPart() == ("NumCTBlk")) {
			        	  e=reader.nextEvent();
			        	  headResult.setNumCTBlk(e.asCharacters().getData());
			        	  continue;
			          }
			          if (startElement.getName().getLocalPart() == ("NumDDBlk")) {
			        	  e=reader.nextEvent();
			        	  headResult.setNumDDBlk(e.asCharacters().getData());
			        	  continue;
			          }
			          if (startElement.getName().getLocalPart() == ("CstmFileValdtion")) {
			        	  e=reader.nextEvent();
			        	  headResult.setCstmFileValdtion(e.asCharacters().getData());
			        	  continue;
			          } 
			          if (startElement.getName().getLocalPart() == ("FndtMsgBatch")) {
			        	  headResult.setBulkStartTag(startElement.getName().getLocalPart());
			        	  headResult.setBulkStartTagLocation(e.getLocation().getCharacterOffset());
			        	  break;
			          }
				}
		}//while
		logger.debug("results "+headResult);
		return headResult;
	}
	
	
	private void enforceHeadMaxLimit(XMLEvent e,FndtMultiBatchMsgParseResult result) throws RuntimeException {
		if (e.getLocation().getCharacterOffset() < 0)
			throw new RuntimeException("Oh Oh.. "+reader.getClass().getName()+" doesn't supports the optional" +
					" 'CharacterOffset' on the Location interface. TBD manual impl");
		
		if (e.getLocation().getCharacterOffset() > MAX_HEADER_SIZE) {			
			throw new RuntimeException("Could not complete processing within max size of "+MAX_HEADER_SIZE
					+" characters, missing expected tag: " +result.getFirstMissingTagName());
		}
	}	
	
	
}//MessageStreamBasedParser


