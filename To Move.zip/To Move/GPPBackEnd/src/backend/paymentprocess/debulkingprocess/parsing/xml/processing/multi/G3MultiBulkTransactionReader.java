package backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi;

import java.io.File;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.scl.debulkingProcessService.PerformDebulkingMultiRequestDocument;


public class G3MultiBulkTransactionReader extends G3MultiBulkTransactionReaderBase{

	private static final Logger logger = LoggerFactory.getLogger(G3MultiBulkTransactionReader.class);
	
	
	
	public G3MultiBulkTransactionReader(File file, int chunkSize) {
		super(file,chunkSize);
	}
	

	
	protected XmlTransactionReader getReaderForMessageType(String msgType)
	{
		nativeReader = new G3_SingleTypeBatch_TransactionReader(getFile(), getRandomeFile(), getChunkSize(), new G3Msg_SingleTypeBatch());
		nativeReader.setFileSize(getFileSize()) ;			
		nativeReader.setListener(this);
		nativeReader.setUtils(getUtils());
		nativeReader.setByteBuffer(getByteBuffer());
		nativeReader.setTotalDeleted(getTotalDeleted());
		nativeReader.setByteCount(getByteCount());
		nativeReader.setSize(getSize());
		nativeReader.lastTransactionEndInd = this.lastTransactionEndInd;
		return nativeReader;
	}

}
