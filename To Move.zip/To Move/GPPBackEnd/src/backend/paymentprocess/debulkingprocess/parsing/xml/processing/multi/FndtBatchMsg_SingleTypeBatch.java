
package backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi;

import static backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi.XmlParsingHelper.makeConcretePrefix;

import java.io.File;
import java.io.RandomAccessFile;

import javax.xml.namespace.QName;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.core.paymentprocess.data.paymenttypes.PaymentType;

/**
 * Supports FndtBatchMsg which 
 * 1. has BatchHeader
 * 2. contains transactions all from same native type
 * 3. all native transactions share the same prefix
 */
public class FndtBatchMsg_SingleTypeBatch extends SingleMessageTypeData {
	private static final Logger logger = LoggerFactory.getLogger(FndtBatchMsg_SingleTypeBatch.class);
		
	private SingleMessageTypeData nativeMessageDataType;
	
	/**
	 * the QName of the native header (aka GrpHdr)
	 */
	private QName nativeHeaderRoot;
	
	/**
	 * the QName of the first native payment on the file
	 */
	private QName nativeMessageRoot;
	
	/**
	 * the QName of the first FndtMsg on the file
	 */
	private QName fndtMsgRoot;
	
	
	private String FNDT_MSG_EXTN_START_TAG = "";
	private String FNDT_MSG_EXTN_END_TAG = "";
	

	public FndtBatchMsg_SingleTypeBatch() {
		super(null);
	}
	
	public FndtBatchMsg_SingleTypeBatch(String nativePaymentName) {
		this((SingleMessageTypeData)FileMessageTypeData.Factory.getFileMessageTypeData(nativePaymentName));
	}
	
	public FndtBatchMsg_SingleTypeBatch(SingleMessageTypeData nativeMessageDataType) {
		setNativeMessageDataType(nativeMessageDataType);
	}

	public void init(QName nativeMessageRoot,QName fndtMsgRoot,QName nativeHeaderRoot) {		
		setFndtMsgData(fndtMsgRoot);
		setNativeMessageData(nativeMessageRoot,nativeHeaderRoot);		
	}
	
	@Override
	public String getWorkflow() {
		 return "TBD";
	}

	@Override
	public String getTypeIdentifier() {
		return "http://fundtech.com/SCL/CommonTypes";//paymentType.getSchemaNamespace();//"http://fundtech.com/SCL/CommonTypes";
	}

	@Override
	public String getPaymentTypeName() {
		return "FndtBatchMsg_SingleTypeBatch_"
				+ (nativeMessageDataType != null 
				   ? nativeMessageDataType.getPaymentTypeName()
				   : "unknown");
	}

	@Override
	public String getPreDocumentEnd() {
		return null;
	}

	
	/**
	 * PmtInf resides on the PmntHeader section as <PmtInf></PmtInf>
	 */
	@Override
	public String getPrePmtInfEnd() {
		return nativeMessageDataType.PAYMENT_INFO_END_TAG;
	}

	@Override
	public XmlTransactionReaderBase getReader() {
		if (defaultCtorReader == null) {
			defaultCtorReader = new FndtBatchMsg_SingleTypeBatch_TransactionReader();
		}
		return defaultCtorReader;
	}

	
	@Override
	public XmlTransactionReaderBase getReader(File file, int chunkSize) {
		if (reader == null) {
			reader = new FndtBatchMsg_SingleTypeBatch_TransactionReader(file, chunkSize,this);
		}
		return reader;
	}
	
	
	@Override
	public XmlTransactionReaderBase getReaderWithoutInit(File file, int chunkSize, RandomAccessFile accessFile) {
		if (reader == null) {
			reader = new FndtBatchMsg_SingleTypeBatch_TransactionReader(file,accessFile, chunkSize,this);
		}
		return reader;
	}
		
	@Override
	public void initTags(PaymentType paymentType) {
	   initNativeTags();	
	   
       FNDT_MSG_EXTN_START_TAG =  this.formatTagToCorrectStructure("Extn",false);
       FNDT_MSG_EXTN_END_TAG =  this.formatTagToCorrectStructure("Extn",true);       
	}
	
	private void initNativeTags() {
	   nativeMessageDataType.initTags(getNativeMessageDataType().paymentType);
	   nativeMessageDataType.debugTags();
	}

	public void formatTags(String namespace) {
		formatNativeTags(getNativePaymentPrefix());
		
		String fndtPrefix = makeConcretePrefix(getFndtMsgPrefix());
		
		this.FNDT_MSG_EXTN_START_TAG = String.format(this.FNDT_MSG_EXTN_START_TAG,fndtPrefix);
		this.FNDT_MSG_EXTN_END_TAG = String.format(this.FNDT_MSG_EXTN_END_TAG,fndtPrefix);
	}
	
	private void formatNativeTags(String namespace) {
		logger.debug("formating native tags with namespace prefix '{}'",namespace);
		nativeMessageDataType.formatTags(namespace);
	}

	public void setNativeMessageData(QName nativeMessageRoot,QName nativeHeaderRoot) {
		this.nativeMessageRoot = nativeMessageRoot;
		this.nativeHeaderRoot = nativeHeaderRoot;
		
		PaymentType nativePaymentType = PaymentType.valueOf(nativeMessageRoot);
		setNativeMessageDataType((SingleMessageTypeData)nativePaymentType.getTrnsReaderNewInstance());		
		initTags(nativePaymentType);
		formatTags(nativeMessageRoot.getPrefix());
	}
	
	public void setNativeMessageDataType(SingleMessageTypeData nativeMessageDataType) {
		logger.debug("native message data type {}",nativeMessageDataType);
		this.nativeMessageDataType = nativeMessageDataType;
	}
	
	public String getNativePaymentPrefix() {
		return this.nativeMessageRoot.getPrefix();
	}
	
	public String getNativePaymentHeaderPrefix() {
		return this.nativeHeaderRoot.getPrefix();
	}

	public String getFndtMsgPrefix() {
		return this.fndtMsgRoot.getPrefix();
	}
	
	public SingleMessageTypeData getNativeMessageDataType() {
		return nativeMessageDataType;
	}
	
	public void setFndtMsgData(QName fndtMsgPrefix) {
		this.fndtMsgRoot = fndtMsgPrefix;		
	}

	public String getExtnStartTag() {		
		return FNDT_MSG_EXTN_START_TAG;
	}

	public String getExtnEndTag() {
		return FNDT_MSG_EXTN_END_TAG;
	}

	
	public byte[] getExtnStartTagBytes() {		
		return getExtnStartTag().getBytes();
	}

	public byte[] getExtnEndTagBytes() {
		return getExtnEndTag().getBytes();
	}

	public QName getNativeHeaderRoot() {
		return nativeHeaderRoot;
	}

	public void setNativeHeaderRoot(QName nativeHeaderRoot) {
		this.nativeHeaderRoot = nativeHeaderRoot;
	}

	public QName getNativeMessageRoot() {
		return nativeMessageRoot;
	}

	public void setNativeMessageRoot(QName nativeMessageRoot) {
		this.nativeMessageRoot = nativeMessageRoot;
	}

	public QName getFndtMsgRoot() {
		return fndtMsgRoot;
	}

	public void setFndtMsgRoot(QName fndtMsgRoot) {
		this.fndtMsgRoot = fndtMsgRoot;
	}

	public String getFNDT_MSG_EXTN_START_TAG() {
		return FNDT_MSG_EXTN_START_TAG;
	}

	public void setFNDT_MSG_EXTN_START_TAG(String fNDT_MSG_EXTN_START_TAG) {
		FNDT_MSG_EXTN_START_TAG = fNDT_MSG_EXTN_START_TAG;
	}

	public String getFNDT_MSG_EXTN_END_TAG() {
		return FNDT_MSG_EXTN_END_TAG;
	}

	public void setFNDT_MSG_EXTN_END_TAG(String fNDT_MSG_EXTN_END_TAG) {
		FNDT_MSG_EXTN_END_TAG = fNDT_MSG_EXTN_END_TAG;
	}
	
	
}
