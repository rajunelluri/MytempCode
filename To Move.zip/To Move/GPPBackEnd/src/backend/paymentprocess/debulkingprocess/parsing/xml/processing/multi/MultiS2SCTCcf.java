

package backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi;

import java.io.File;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.fundtech.cache.entities.LogicalFieldsXpath;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.paymenttypes.PaymentType;

import backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi.AckXmlTransactionReader.CcfTransactionReader;


/**
 * Concrete MultiMessageTypeData for pacs 04 and pacs 08.
 *
 * @author haimv
 * @author dmitryp
 */
public class MultiS2SCTCcf extends MultiMessageTypeData{

	// TODO Do not use hard-coded tags - take it from logical_fields_xpath cache.

	public MultiS2SCTCcf(PaymentType paymentType) {
	
	}
	
	@Override
	public String getGrpHdrEndTag() {
		return "</S2SCTCcf:FileCycleNo>";
	}

	@Override
	public String getGrpHdrStartTag() {
		return "<S2SCTCcf:SndgInst>";
	}

	@Override
	public String getTypeIdentifier() {
		return "SCTCcfBlkCredTrf";
	}

	@Override
	public void initTags(PaymentType paymentType)
	{
//		PaymentType paymentType = PaymentType.valueOf(getPaymentType());
//        Map<String, LogicalFieldsXpath> map =CacheKeys.LogicalFieldsXPathKey.getSingle(paymentType);
//
	}
	@Override
	public String getPreDocumentEnd() {
		//TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getDocumentElementStartTag() {
		//TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getPrePmtInfEnd() {
		//TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getPaymentInfoElementStartTag() {
		//TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getDocumentElementEndTag() {
		//TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getPaymentInfoElementEndTag() {
		//TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getXmlClosingTags() {
		//TODO Auto-generated method stub
		return null;
	}

	@Override
	public void formatTags(String namespace) {
		//TODO Auto-generated method stub

	}

	@Override
	public byte[] getPaymentInfoElementStartTagBytes() {
		//TODO Auto-generated method stub
		return null;
	}

	@Override
	public byte[] getTransactionEndTagBytes() {
		//TODO Auto-generated method stub
		return null;
	}

	@Override
	public byte[] getTransactionStartTagBytes() {
		//TODO Auto-generated method stub
		return null;
	}

	public byte[] getPaymentInfoElementEndTagBytes()
	{
		return null;
	}

	@Override
	public XmlTransactionReaderBase getReader(File file, int chunkSize) {
		if (reader == null) {
			reader = new CcfTransactionReader(file, chunkSize,this);
		}
		return reader;
	}

	
}
