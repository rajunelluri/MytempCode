package backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.datacomponent.response.GlobalResponseDataComponentText;
import com.fundtech.parser.g3.G3BulkMessageMetadata;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalUtils;
import com.fundtech.util.GlobalXMLTextUtil;

/**
  * @Title RandomAccessFileUtils
  * @Description contains RandomAccessFile read by indexes methods
  * @Company Fundtech Israel
  * @author Dmitryp
  * @since Dec 13, 2011
*/
public class RandomAccessFileUtils {
                private static final Logger logger = LoggerFactory.getLogger(RandomAccessFileUtils.class);
                private RandomAccessFile m_raf = null;
                private long m_nNewBulkIndex = -1;
                private G3BulkMessageMetadata CurrentMsgType = null;
                private G3BulkMessageMetadata lastSavedMessageType = null;

                public RandomAccessFile getM_raf() {
                        return m_raf;
                }
                                
                public void setM_raf(RandomAccessFile m_raf) {
                        //TODO This is wrong!!!! need to fix this
                        try {
                                if(this.m_raf != null){
                                        this.m_raf.close();
                                        this.m_raf = null;
                                }
                                this.m_raf = m_raf;     
                        } catch (Exception e) {
                                logger.error(e.getMessage());
                        }                       
                }
                
                public void setCurrentMsgType(G3BulkMessageMetadata msg) 
                {
                		CurrentMsgType = msg;
                }
                public G3BulkMessageMetadata getCurrentMsgType() 
                {
                        return CurrentMsgType;
                }
                
                public long getM_nNewBulkIndex() 
                {
                        return m_nNewBulkIndex;
                }
                
                public void setM_nNewBulkIndex(long NewBulkIndex) 
                {
                        m_nNewBulkIndex = NewBulkIndex;         
                }

                //Ctor
                public RandomAccessFileUtils(File file)
                {
                        try {

                                this.m_raf = new RandomAccessFile(file, "r");

                        } catch (FileNotFoundException e) {
                                logger.error(e.getMessage());
                        }
                }

                //Ctor
                public RandomAccessFileUtils(RandomAccessFile raf) {

                        this.m_raf = raf;

                }

                public void dispose()
                {
                        try {
                                if (m_raf != null) m_raf.close();

                        } catch (IOException ex)
                        {
                                logger.error(ex.getMessage());
                        }finally
                        {
                                m_raf = null;
                        }
                }
                /**
                 * Utility method to retrieve file section according to start and end indexes.
                 *
                 * @param path
                 * @param startIndex
                 * @param endIndex
                 * @return
                 */
                public String getFileSectionFromIndexes(long startIndex, long endIndex)
                {
                        long position = -1;
                        try {
                                 position = m_raf.getFilePointer();
                        } catch (IOException e) {
                                // TODO Auto-generated catch block
                                logger.error(e.getMessage());
                        }
                        logger.debug("startIndex is: {} endIndex is: {} ",startIndex,endIndex);
                        long iLength = endIndex - startIndex;

                        //Declare a buffer with the same length as desired chunk length
                        byte[] buffer = new byte[(int)iLength];

                        try
                        {
                                //Move cursor to the offset
                                m_raf.seek(startIndex);

                                //Read data from the file
                                m_raf.read(buffer);

                        } catch (IOException ex) {
                                logger.error(ex.getMessage());
                        }

                        try {
                                m_raf.seek(position);
                        } catch (IOException e) {
                                // TODO Auto-generated catch block
                                logger.error(e.getMessage());
                        }
                        return new String(Arrays.copyOfRange(buffer,0,buffer.length));

                }//EOM getFileSectionFromIndexes


                /**
                 * Add "<?xml version='1.0' encoding='UTF-8'?>" to xml
                 *
                 * @author dmitryp
                 */
                private String addXmlFirstLine(String xmlPart)
                {
                        if(!GlobalUtils.isObjectNullOrEmpty(xmlPart))
                        {
                                if(!xmlPart.startsWith(GlobalXMLTextUtil.XML_FIRST_LINE))
                                {
                                        return GlobalXMLTextUtil.XML_FIRST_LINE + xmlPart;
                                }
                        }

                        return "";

                }//EOM String


                public String getDocumentPartTillFirstTransaction(long preDocumentStart, long preDocumentEnd,long prePmtInfStart,long prePmtInfEnd,
                                String endTags,boolean bAddPmtInf,boolean bEndTags ,boolean isMulti , FileMessageTypeData fileMessageTypeData)
                {

                        StringBuilder sb = new StringBuilder();

                        String xmlPart = getFileSectionFromIndexes(preDocumentStart,preDocumentEnd);

                        if (isMulti) {
                                int position = xmlPart.indexOf(":");
                                xmlPart = xmlPart.substring(position+1);
                                xmlPart = "<" + xmlPart;

                        sb.append("<");
                        sb.append(fileMessageTypeData.getRootElement());
                        sb.append(" xmlns=\"");
                        sb.append(fileMessageTypeData.getTypeIdentifier());
                        sb.append("\">");

                        xmlPart = sb.toString() + xmlPart;

//                              + fileMessageTypeData.getRootElement() +  "xmlns=\"" +
//                                              fileMessageTypeData.getTypeIdentifier()) +
//                              sb.append("<Document xmlns=\"")"";
//                              sb.append(fileMessageTypeData.getTypeIdentifier());
//                              sb.append("\">");
                          sb.delete(0,sb.length());
                        }

                        //- <Document xmlns="urn:iso:std:iso:20022:tech:xsd:pain.001.001.03">
                                //- <CstmrCdtTrfInitn>
                        sb.append(xmlPart);

                                        //<GrpHdr>
                                        //</GrpHdr>
                                        //<PmtInf>
                        if(bAddPmtInf)
                        {
                                sb.append(getFileSectionFromIndexes(prePmtInfStart,prePmtInfEnd));
                        }

                                        //</PmtInf>
                                //</CstmrCdtTrfInitn>
                        //</Document>
                        if(bEndTags)
                        {
                                sb.append(endTags);
                        }

                        return sb.toString();

                }//EOM getDocumentPartTillFirstTransaction

                public String getDocumentPartTillFirstTransaction(long preDocumentStart, long preDocumentEnd,long prePmtInfStart,long prePmtInfEnd,
                                String endTags,boolean bAddPmtInf,boolean bEndTags ,boolean isMulti , FileMessageTypeData fileMessageTypeData, String namespacePrefix)
                {

                        StringBuilder sb = new StringBuilder();

                        String xmlPart = new String();

                        if (preDocumentStart > 0 && preDocumentEnd > 0){
                                xmlPart = getFileSectionFromIndexes(preDocumentStart,preDocumentEnd);
                        }

                        if (isMulti) {
                                int position = xmlPart.indexOf(":");
                                if (position > 0){
                                        xmlPart = xmlPart.substring(position+1);
                                        xmlPart = "<" + xmlPart;
                                }

                                sb.append("<");
                                if (!GlobalUtils.isNullOrEmpty(namespacePrefix)){
                                        sb.append(namespacePrefix);
                                        sb.append(":");
                                }
                                sb.append(fileMessageTypeData.getRootElement());
                                sb.append(" xmlns");
                                if (!GlobalUtils.isNullOrEmpty(namespacePrefix)){
                                        sb.append(":");
                                        sb.append(namespacePrefix);
                                }
                                sb.append("=\"");
                                sb.append(fileMessageTypeData.getTypeIdentifier());
                                sb.append("\">");

                                if (!GlobalUtils.isNullOrEmpty(fileMessageTypeData.getMultiFileStartTag())){
                                        sb.append(String.format(fileMessageTypeData.getMultiFileStartTag(), namespacePrefix + ":"));
                                }

                                xmlPart = sb.toString() + xmlPart;
                                sb.delete(0,sb.length());
                        }

                        sb.append(xmlPart);

                        if(bAddPmtInf)
                        {
                                sb.append(getFileSectionFromIndexes(prePmtInfStart,prePmtInfEnd));
                        }

                        if(bEndTags)
                        {
                                sb.append(endTags);
                        }

                        return sb.toString();

                }//EOM getDocumentPartTillFirstTransaction

                public String getDocPartTillFirstTransaction(long preDocumentStart,long preDocumentEnd,long prePmtInfStart,long prePmtInfEnd,
                                String endTags,boolean bAddPmtInf,boolean bEndTags,String paymentInfoElementStartTag)
                {

                        StringBuilder sb = new StringBuilder();

                        String xmlPart = getFileSectionFromIndexes(preDocumentStart,preDocumentEnd);

                        //- <Document xmlns="urn:iso:std:iso:20022:tech:xsd:pain.001.001.03">
                                //- <CstmrCdtTrfInitn>
                                        //<GrpHdr>
                                        //</GrpHdr>
                        sb.append(xmlPart);

                                        //<PmtInf>
                        sb.append(paymentInfoElementStartTag);
                                                //<CdtTrfTxInf>
                        //sb.append(fileMessageTypeData.getTransactionStartTag());
                                                //</CdtTrfTxInf>
                        //sb.append(fileMessageTypeData.getTransactionEndTag());

                        if(bAddPmtInf)
                        {
                                sb.append(getFileSectionFromIndexes(prePmtInfStart,prePmtInfEnd));
                        }

                                        //</PmtInf>
                                //</CstmrCdtTrfInitn>
                        //</Document>
                        //sb.append(fileMessageTypeData.getPostTagsStart() + "</CstmrCdtTrfInitn>" + fileMessageTypeData.getPostTagsEnd());


                        if(bEndTags)
                        {
                                sb.append(endTags);
                        }

                        return sb.toString();

                }//EOM getDocPartTillFirstTransaction




                public void readToByteArrayListEnd(ByteArrayListOptimized ball,int length)
        {
                //File file = new File("c:\\a.txt");
                //RandomAccessFile m_raf;
                try {
                        //m_raf = new RandomAccessFile(this., "rw");
                        int tmp = ball.getArray().length - ball.getEnd();
                        if (length<= tmp)
                        {
                                m_raf.read(ball.getArray(), ball.getEnd(), length);
                                ball.setEnd(ball.getEnd() +  length);
                        }
                        else
                        {
                                m_raf.read(ball.getArray(), ball.getEnd(), tmp);
                                m_raf.read(ball.getArray(), 0, length-tmp);
                                ball.setEnd(length-tmp);
                        }
                } catch (Exception e1) {
                        // TODO Auto-generated catch block
                        logger.error(e1.getMessage());
                }

                ball.setSize(ball.getSize() +length);
                ball.getArray()[(ball.getEnd())%ball.getArray().length] = 0;

        }//EOM readToByteArrayListLight
                
                
                /*
                 * This function will read from RandomAccessFile m_raf length bytes and put it on ball 
                 * ball will be override from his start to length and will set his end to length.
                 * 
                 * 
                 */
        public void readToByteArrayForNewBulk(ByteArrayListOptimized ball,int length)
        {
                try 
                {
                        m_raf.read(ball.getArray(), 0, length);
                        ball.setEnd(length);
                }
                catch (Exception e1) 
                {
                        logger.error(e1.getMessage());
                }
                ball.setSize(ball.getSize() +length);
        }//EOM readToByteArrayListLight
        
        public G3BulkMessageMetadata getLastSavedMessageType()
        {
            return lastSavedMessageType;
        }
        public void setLastSavedMessageType(G3BulkMessageMetadata lastSavedMessateType)
        {
            this.lastSavedMessageType = lastSavedMessateType;
        }
}//EOC RandomAccessFileUtils
