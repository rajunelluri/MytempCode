/*package backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi;

import java.io.File;
import java.io.RandomAccessFile;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.core.paymentprocess.data.paymenttypes.FileMeaasgeTypeDataInterface;
import com.fundtech.core.paymentprocess.data.paymenttypes.PaymentType;

public class FndtMultiMessageDataType extends FileMessageTypeDataAdapter{
	private static final Logger logger = LoggerFactory.getLogger(FndtMultiMessageDataType.class);
	
	protected String DOCUMENT_START_TAG 	 = "<%sDocument";
	protected String DOCUMENT_END_TAG 	 = "</%sDocument>";
	
//	protected String GROUP_HEADER_START_TAG = "<%sGrpHdr>";
//	protected String GROUP_HEADER_END_TAG   = "</%sGrpHdr>";
//	
//	protected String PAYMENT_INFO_START_TAG = "<%sPmtInf>";
//	protected String PAYMENT_INFO_END_TAG   = "</%sPmtInf>";
	
    protected String GROUP_HEADER_START_TAG = "";
	protected String GROUP_HEADER_END_TAG   = "";
	
	protected String PAYMENT_INFO_START_TAG = "";
	protected String PAYMENT_INFO_END_TAG   = "";
	
	protected String TRANSACTION_START_TAG = "";
	protected String TRANSACTION_END_TAG   = "";
	
	public String MULTI_FILE_START_TAG = "";
	public String MULTI_FILE_END_TAG = "";
	
	
	protected String MULTI_PAYMENT_GROUPING_TAG_START = "";
	protected String MULTI_PAYMENT_GROUPING_TAG_END = "";
	
	protected String STARTING_XML_TAGS   = "";
	protected String CLOSE_XML_TAGS   = "";
	
	protected byte[] TRANSACTION_END_TAG_BYTES = null;
	protected byte[] TRANSACTION_START_TAG_BYTES = null;
	
	protected XmlTransactionReaderBase reader = null;
	protected XmlTransactionReaderBase defaultCtorReader = null;
	protected PaymentType paymentType = null;

	
	public FndtMultiMessageDataType() {
	
	}
	
	public FndtMultiMessageDataType(PaymentType paymentType)
	{
		if (paymentType != null)
			initTags(paymentType);
	}
	
	@Override
	public void setPaymentType(PaymentType paymentType) {
		this.paymentType = paymentType;
		logger.debug("payment type {}",paymentType);
	}
	
	public PaymentType getPaymentType() {
		if (paymentType == null)
			setPaymentType(paymentType = getPaymentTypeName() != null ? PaymentType.valueOf(getPaymentTypeName()) : null);
			
		return this.paymentType;
	}
	
	@Override
	public String getRootElement()
	{
		return paymentType.getLocalPart();
	}
	
	@Override
	public String getXmlStartingTags() {
		return STARTING_XML_TAGS;
	}
	
	@Override
	public String getXmlClosingTags() {
		return CLOSE_XML_TAGS;
	}
	
	public String getMultiFileStartTag()
	{
		return this.MULTI_FILE_START_TAG;
	}
	
	public String getMultiFileEndTag()
	{
		return this.MULTI_FILE_END_TAG;
	}
	
	@Override
	public String getTransactionStartTag() {
		return TRANSACTION_START_TAG;
	}
	
	@Override
	public String getTransactionEndTag() {
		return TRANSACTION_END_TAG;
	}
	
	protected String formatTagToCorrectStructure(String tag, boolean isEndTag)
	{	
		if (isEndTag)
			return "</%s"  + tag + ">";
		
		return "<%s"  + tag + ">";
	}
	
	
	@Override
	public String getWorkflow() {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public String getDocumentElementStartTag() {
		return DOCUMENT_START_TAG;
	}
	
	@Override
	public String getDocumentElementEndTag() {
		return DOCUMENT_END_TAG;
	}
		
	@Override
	public String getGrpHdrStartTag() {
		return GROUP_HEADER_START_TAG;
	}

	@Override
	public String getGrpHdrEndTag() {
		return GROUP_HEADER_END_TAG;
	}
	
	@Override
	public String getPaymentInfoElementEndTag() {
		return PAYMENT_INFO_END_TAG;
	}
	
	@Override
	public String getPaymentInfoElementStartTag() {
		return PAYMENT_INFO_START_TAG;
	}
	
//	public abstract XmlTransactionReaderBase getReaderWithoutInit(File file, int chunkSize, RandomAccessFile accessFile);

	
	
	@Override
	public void formatTags(String namespace) {
		namespace = XmlParsingHelper.makeConcretePrefix(namespace);
		
		this.DOCUMENT_START_TAG     = String.format(this.DOCUMENT_START_TAG,namespace);
		this.DOCUMENT_END_TAG 	    = String.format(this.DOCUMENT_END_TAG,namespace);
		this.GROUP_HEADER_START_TAG = String.format(this.GROUP_HEADER_START_TAG,namespace);
		this.GROUP_HEADER_END_TAG   = String.format(this.GROUP_HEADER_END_TAG,namespace);	
		this.PAYMENT_INFO_START_TAG = String.format(this.PAYMENT_INFO_START_TAG,namespace);
		this.PAYMENT_INFO_END_TAG   = String.format(this.PAYMENT_INFO_END_TAG,namespace);
		this.TRANSACTION_START_TAG = String.format(this.TRANSACTION_START_TAG,namespace);
		this.TRANSACTION_END_TAG  = String.format(this.TRANSACTION_END_TAG,namespace);
		this.MULTI_PAYMENT_GROUPING_TAG_START = 	String.format(this.MULTI_PAYMENT_GROUPING_TAG_START,namespace);
		this.MULTI_PAYMENT_GROUPING_TAG_END = 	String.format(this.MULTI_PAYMENT_GROUPING_TAG_END,namespace);
		
		formatXmlClosingTags(namespace);
		formatXmlStartingTags(namespace);
		
		if(TRANSACTION_END_TAG_BYTES == null)
		{
			TRANSACTION_END_TAG_BYTES = getTransactionEndTag().getBytes();
		}
		if(TRANSACTION_START_TAG_BYTES == null)
		{
			TRANSACTION_START_TAG_BYTES = getTransactionStartTag().getBytes();
		}
		
		debugTags();
	
	}
	
	protected void formatXmlStartingTags(String namespace) {
	}

	protected void formatXmlClosingTags(String namespace) {
		this.CLOSE_XML_TAGS    = String.format(this.CLOSE_XML_TAGS,namespace,namespace,namespace);		
	}

	public String getMultiPaymentGroupingTagStart(){
		return MULTI_PAYMENT_GROUPING_TAG_START;
	}
	
	public String getMultiPaymentGroupingTagEnd(){
		return MULTI_PAYMENT_GROUPING_TAG_END;
	}
	
	
		@Override
	public byte[] getTransactionEndTagBytes() 
	{
		return TRANSACTION_END_TAG_BYTES;
	}

	@Override
	public byte[] getTransactionStartTagBytes() 
	{
		return TRANSACTION_START_TAG_BYTES;
	}

	public String getHeaderTag() {
		throw new UnsupportedOperationException();
	}
	
	@Override
	public byte[] getPaymentInfoElementStartTagBytes() {
		return getPaymentInfoElementStartTag().getBytes();
	}
	
		@Override
	public byte[] getPaymentInfoElementEndTagBytes() {
		return getPaymentInfoElementEndTag().getBytes();
	}
	
	public void debugTags() {
		 logger.debug(toString()+": Tags are:" +
				"DOCUMENT_START_TAG {} ,DOCUMENT_START_TAG {}," +
	          	"GROUP_HEADER_START_TAG {} ,GROUP_HEADER_END_TAG {}," +
	       		"PAYMENT_INFO_START_TAG {} ,PAYMENT_INFO_END_TAG {}," +
	       		"TRANSACTION_START_TAG {} ,TRANSACTION_END_TAG {}"
	       		,new Object[] {DOCUMENT_START_TAG,DOCUMENT_END_TAG
			 					,GROUP_HEADER_START_TAG,GROUP_HEADER_END_TAG
	       		   				,PAYMENT_INFO_START_TAG,PAYMENT_INFO_END_TAG
	       		   				,TRANSACTION_START_TAG,TRANSACTION_END_TAG});
	}
	
	public String toString() {
		return getClass().getName();
	}
}*/