
package backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi;

import java.io.File;
import java.io.RandomAccessFile;

import javax.xml.namespace.QName;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.core.paymentprocess.data.paymenttypes.PaymentType;

/**
 * Supports FndtBatchMsg which 
 * 1. has BatchHeader
 * 2. contains transactions all from same native type
 * 3. all native transactions share the same prefix
 */
public class G3Msg_SingleTypeBatch extends SingleMessageTypeData {
	private static final Logger logger = LoggerFactory.getLogger(G3Msg_SingleTypeBatch.class);
		
	private SingleMessageTypeData nativeMessageDataType;
	
	/**
	 * the QName of the native header (aka GrpHdr)
	 */
	private QName nativeHeaderRoot;
	
	/**
	 * the QName of the first native payment on the file
	 */
	private QName nativeMessageRoot;
	

	public G3Msg_SingleTypeBatch() {
		super(null);
	}
	
	public G3Msg_SingleTypeBatch(String nativePaymentName) {
		this((SingleMessageTypeData)FileMessageTypeData.Factory.getFileMessageTypeData(nativePaymentName));
	}
	
	public G3Msg_SingleTypeBatch(SingleMessageTypeData nativeMessageDataType) {
		setNativeMessageDataType(nativeMessageDataType);
	}

	public void init(QName nativeMessageRoot, QName nativeHeaderRoot) {		
		setNativeMessageData(nativeMessageRoot,nativeHeaderRoot);		
	}
	
	@Override
	public String getWorkflow() {
		 return "TBD";
	}

	@Override
	public String getTypeIdentifier() {
		return "http://fundtech.com/SCL/CommonTypes";//paymentType.getSchemaNamespace();//"http://fundtech.com/SCL/CommonTypes";
	}

	@Override
	public String getPaymentTypeName() {
		return (nativeMessageDataType != null 
				   ? nativeMessageDataType.getPaymentTypeName()
				   : "unknown");
	}

	@Override
	public String getPreDocumentEnd() {
		return null;
	}

	
	/**
	 * PmtInf resides on the PmntHeader section as <PmtInf></PmtInf>
	 */
	@Override
	public String getPrePmtInfEnd() {
		return nativeMessageDataType.PAYMENT_INFO_END_TAG;
	}

	@Override
	public XmlTransactionReaderBase getReader() {
		if (defaultCtorReader == null) {
			defaultCtorReader = new G3_SingleTypeBatch_TransactionReader();
		}
		return defaultCtorReader;
	}

	
	@Override
	public XmlTransactionReaderBase getReader(File file, int chunkSize) {
		if (reader == null) {
			reader = new G3_SingleTypeBatch_TransactionReader(file, chunkSize,this);
		}
		return reader;
	}
	
	
	@Override
	public XmlTransactionReaderBase getReaderWithoutInit(File file, int chunkSize, RandomAccessFile accessFile) {
		if (reader == null) {
			reader = new G3_SingleTypeBatch_TransactionReader(file,accessFile, chunkSize,this);
		}
		return reader;
	}
		
	@Override
	public void initTags(PaymentType paymentType) {
	   initNativeTags();	
     
	}
	
	private void initNativeTags() {
	   nativeMessageDataType.initTags(getNativeMessageDataType().paymentType);
	   nativeMessageDataType.debugTags();
	}

	public void formatTags(String namespace) {
		formatNativeTags(getNativePaymentPrefix());
	}
	
	private void formatNativeTags(String namespace) {
		logger.debug("formating native tags with namespace prefix '{}'",namespace);
		nativeMessageDataType.formatTags(namespace);
	}

	public void setNativeMessageData(QName nativeMessageRoot,QName nativeHeaderRoot) {
		this.nativeMessageRoot = nativeMessageRoot;
		this.nativeHeaderRoot = nativeHeaderRoot;
		
		PaymentType nativePaymentType = PaymentType.valueOf(new QName(nativeMessageRoot.getNamespaceURI(), "Document"));
		setNativeMessageDataType((SingleMessageTypeData)nativePaymentType.getTrnsReaderNewInstance());		
		initTags(nativePaymentType);
		formatTags(nativeMessageRoot.getPrefix());
	}
	
	public void setNativeMessageDataType(SingleMessageTypeData nativeMessageDataType) {
		logger.debug("native message data type {}",nativeMessageDataType);
		this.nativeMessageDataType = nativeMessageDataType;
	}
	
	public String getNativePaymentPrefix() {
		return this.nativeMessageRoot.getPrefix();
	}
	
	public String getNativePaymentHeaderPrefix() {
		return this.nativeHeaderRoot.getPrefix();
	}

	public SingleMessageTypeData getNativeMessageDataType() {
		return nativeMessageDataType;
	}
	
}
