package backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi;

import static backend.core.module.MessageConstantsInterface.CREDIT_TRANSFER;
import static backend.core.module.MessageConstantsInterface.DIRECT_DEBIT;
import static backend.core.module.MessageConstantsInterface.MESSAGE_TYPE_PACS_002;
import static backend.paymentprocess.SubBatchProcessInterface.STATUS_FILE_COMPLETED;
import static backend.paymentprocess.SubBatchProcessInterface.STATUS_NOT_MATCHED;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.X_ORGNL_MSG_ID;
import static com.fundtech.util.GlobalConstants.TRN_STS_ACTC;
import static com.fundtech.util.GlobalConstants.TRN_STS_RJCT;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.io.StringReader;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.transaction.UserTransaction;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;

import backend.businessobject.BOBasic;
import backend.paymentprocess.debulkingprocess.dao.DAODebulkingProcess;

import com.fundtech.cache.entities.FileSummary;
import com.fundtech.cache.entities.LogicalFieldsXpath;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.scl.debulkingProcessService.PerformDebulkingMultiRequestDocument;
import com.fundtech.scl.massPayment.PaymentReferenceType;
import com.fundtech.scl.massPayment.PerformDebulkingAckRequsetDocument;
import com.fundtech.scl.massPayment.PerformDebulkingAckRequsetType;
import com.fundtech.scl.massPayment.impl.PerformDebulkingAckRequsetDocumentImpl;
import com.fundtech.util.GlobalUtils;

/**
 * @author Shay A.
 * 
 */
public class Pacs002XmlTransactionReader extends AckXmlTransactionReader {

	private static Logger logger = LoggerFactory
			.getLogger(Pacs002XmlTransactionReader.class);
	private DAODebulkingProcess daoDebulkingProcess = DAODebulkingProcess.getInstance();
	protected enum BulkStatus {
		ACTC, RJCT, PART;
	}
	private enum TransactionStatus {
		REJECTED(TRN_STS_RJCT), ACCEPTED(TRN_STS_ACTC);

		private String txStatusInText;
		private static final Map<String, TransactionStatus> mapTxStatus = new HashMap<String, TransactionStatus>();
		static {
			for (TransactionStatus stts : TransactionStatus.values()) {
				mapTxStatus.put(stts.toString(), stts);
			}
		}

		private TransactionStatus(String txStatusInText) {
			this.txStatusInText = txStatusInText;
		}

		/**
		 * method for getting the correct group status for given group status in
		 * in the XML file
		 * 
		 * @param value
		 * @return GroupStatus
		 */
		public static TransactionStatus getStatusByValue(String value) {
			return mapTxStatus.get(value);
		}

		@Override
		public String toString() {
			return this.txStatusInText;
		}
	}

	
	private boolean bAlreadyMatched;
	private boolean isAnotherBulkFound = true;

	/**
	 * @author shay A. enum representing the different bulk reject
	 */
	/*protected enum BulkRejectStatus {
		BULK_ACCEPTED, BULK_REJECTED, BULK_PARTIALLY_ACCEPTED;

		private String reasonCode;
		
		public String getReasonCode() {
			return this.reasonCode;
		}
		
		public void setReasonCode(String reasonCd) {
			this.reasonCode = reasonCd;
		}
	}*/
	
	public Pacs002XmlTransactionReader(File file, int chunkSize,
			FileMessageTypeData fileMessageTypeData) {
		this.setFile(file);
		this.setChunkSize(chunkSize);

		try {
			setRandomeFile(new RandomAccessFile(file, "r"));
			setFileSize(getRandomeFile().length());
		} catch (FileNotFoundException e1) {
			logger.error("File {} not found.",file.getName());
			return;
		} catch (IOException e) {
			logger.error(e.getMessage());
			return;
		}
		setUtils(new RandomAccessFileUtils(getFile()));
		// TODO Remove hard - coded supported types

		setCurrentChunk(PerformDebulkingMultiRequestDocument.Factory
				.newInstance());
		getCurrentChunk().addNewPerformDebulkingMultiRequest();

		setFileMessageTypeData(fileMessageTypeData);

		// Read global header
		setByteBuffer(new ByteArrayListOptimized());

		setSize(getFileSize() - getByteCount() > BUFFER_SIZE ? BUFFER_SIZE
				: getFileSize() - getByteCount());
		setByteCount(getByteCount() + getSize());

		getUtils().readToByteArrayListEnd(getByteBuffer(), (int) getSize());

		evaluateAndSetXmlNamespacePrefix(new String(getByteBuffer()
				.returnActualArray()), "Document");
		// m_byteBuffer.removeRangeFromBeginning((int)m_size);

		// Add namespace to all tags
		getFileMessageTypeData().formatTags(getNamespacePrefix());

		readDocumentStartData();
		readPreTransactionData();

		setCompiledPattern();
	}

	@Override
	public void init(InputStream inputStream) throws Exception {
		super.init();
	}
	
	@Override
	public void rejectGroup(String outGroupId) {
		List<String[]> chunksOfFile = null;
		try {
			chunksOfFile = daoDebulkingProcess.getChunksByFileIDAndBulk(outGroupId,this.getBulkType());
		} catch (SQLException e) {
			logger.error(e.getMessage());
		}
		List<PerformDebulkingAckRequsetDocument> chunks = this.getChunksFromStringListForBulkReject(chunksOfFile);
		this.chunks.addAll(chunks);
	}
	
	@Override
	public boolean readTransactionsOfChunkSize() {

		if(GlobalUtils.isNullOrEmpty(getHeader()))		// in case we have no more bulks to handle
			return false;
		
		performMatchingAndGetFileStatus();
		
		// In case file was not matched...
		if (STATUS_NOT_MATCHED.equals(fileStatus)) {
			return false;
		}

		try {
			switch (status) {
			case FILE_ACCEPTED:
				if (!wasProcessed) {
					fileStatus = STATUS_FILE_COMPLETED;
					wasProcessed = true;
				}
				break;
			case FILE_PARTIALLY_ACCEPTED:
				Boolean hasChunks=this.processFileTransactionsAndGroups();
				fileStatus = STATUS_FILE_COMPLETED;
				return hasChunks; 
				// break;
			case FILE_REJECTED:
				this.processFileTransactionsAndGroups();
				fileStatus = STATUS_FILE_COMPLETED;
				wasProcessed = true;

				break;
			}

		} catch (XMLStreamException e) {
			logger.error(e.getMessage());
		} finally {

		}
		return this.chunks.size() > 0;
	}
	
	@Override
	protected String getCompleteNode(String tag) throws XMLStreamException {
		return this.getXMLBetweenTags(tag, tag);
	}
	
	/**
	 * @return
	 * @throws XMLStreamException
	 */
	@Override
	public boolean processFileTransactionsAndGroups()
			throws XMLStreamException {
		String group = getOrgnlGrpInfAndSts(this.getHeader());
		
		XPathExpression grpStatusPath;
		XPathExpression grpDescriptionPath;
		String grpStatusRsn = "";
		String grpDescriptionRsn = "";
		org.w3c.dom.Document doc = null;
		String orgMsg = getRelatedFileReference();
		try {

			if (group == null || group.isEmpty()) {
				return false;
			}

			DocumentBuilderFactory factory = DocumentBuilderFactory
					.newInstance();
			factory.setNamespaceAware(true); // never forget this!
			DocumentBuilder builder;
			builder = factory.newDocumentBuilder();
			InputSource source = new InputSource(new StringReader(group));
			doc = builder.parse(source);

			grpDescriptionPath = xpath.compile("//OrgnlGrpInfAndSts/StsRsnInf/Rsn/Prtry");
			if(grpDescriptionPath!=null){
				grpDescriptionRsn = grpDescriptionPath.evaluate(doc);
				status.setReasonCode(grpDescriptionRsn);
			}

		} catch (Exception e) {
			logger.error(e.getMessage());
		}

		String groupStatus = getBulkStatus();
		String bulkType = this.getBulkType();
		
		if (!StringUtils.isEmpty(groupStatus)
				&& 	((!isCTBulkwasProcessed && CREDIT_TRANSFER.equals(bulkType)) 
						|| (!isDDBulkwasProcessed && DIRECT_DEBIT.equals(bulkType)))) 
		{
			GroupStatus grpStatus = GroupStatus.getStatusByValue((groupStatus));
			switch (grpStatus) {
			case PART_REJECTED:
				try {
					grpStatusPath = xpath
							.compile("//OrgnlGrpInfAndSts/StsRsnInf/Rsn/Cd");
					grpDescriptionPath = xpath
							.compile("//OrgnlGrpInfAndSts/StsRsnInf/Rsn/Prtry");
					grpStatusRsn = grpStatusPath.evaluate(doc);
					grpDescriptionRsn = grpDescriptionPath.evaluate(doc);
				} catch (Exception e) {
					logger.error(e.getMessage());
				}

				int trxSize = this.rejectBulkTransactions(grpStatusRsn,grpDescriptionRsn, orgMsg,bulkType);
				
				this.setGlobalHeaderEndTagIndex(this.getGlobalHeaderEndTagIndex()+trxSize);		// Adding all found current bulk transactions <TxInfAndSts>
				break;
			case WHOLE_REJECTED:
				this.rejectGroup(orgMsg);
				break;
			case WHOLE_ACCEPTED:
				break;
			}
		}else
			isAnotherBulkFound=false;
		
		if(isAnotherBulkFound)
		{
			if(CREDIT_TRANSFER.equals(bulkType))
				isCTBulkwasProcessed = true;
			else if(DIRECT_DEBIT.equals(bulkType))
				isDDBulkwasProcessed = true;

		}	
		
		return isAnotherBulkFound;
	}
	
	@Override
	public int getRecCountInChunk(Object chunk) {

		this.getCurrentChunk();
		this.getBulkNumOfTx();
		PerformDebulkingAckRequsetDocumentImpl doc = (PerformDebulkingAckRequsetDocumentImpl) chunk;

		PerformDebulkingAckRequsetType debulkingAckRequest = doc.getPerformDebulkingAckRequset();
		PaymentReferenceType[] pmntRef = debulkingAckRequest.getPaymentReferenceTypeListArray();
		return pmntRef!=null ? pmntRef.length : 0;
	}
	
	protected int rejectBulkTransactions(String grpStatusRsn,
			String grpDescriptionRsn, String orgnlMsgId,String bulkType)
			throws XMLStreamException {
		String startGroup = "OrgnlGrpInfAndSts";
		String startTransaction = "DD".equals(bulkType) ? "DebitTransferReceipt" : "CreditTransferReceipt";//"TxInfAndSts";
		Set<String> tagsSet = new HashSet<String>();
		tagsSet.add(startTransaction);
		String statusRsn = "";
		String txStatus = "";
		String paymentMID = "";
		String orgnlInstrIdStr = "";
		int trxSize = 0;
		// group reason and description

		XPathExpression statusPath = null;
		XPathExpression descriptionPath = null;
		XPathExpression orgnlInstrId = null;
		XPathExpression orgnlTxId = null;
		XPathExpression txStatusPath = null;
		String tmp = null;
		
		try {
			tmp = this.readTillFirstAppearingTagInBulk(tagsSet, true);
		} catch (Exception e1) {
			logger.error(e1.getMessage());
		}

		try {
			txStatusPath = xpath.compile("//TxInfAndSts/TxSts");
			statusPath = xpath.compile("//TxInfAndSts/StsRsnInf/Rsn/Cd");
			descriptionPath = xpath
					.compile("//TxInfAndSts/StsRsnInf/Rsn/Prtry");
			orgnlInstrId = xpath.compile("//TxInfAndSts/OrgnlInstrId");
			orgnlTxId = xpath.compile("//TxInfAndSts/OrgnlTxId");
		} catch (XPathExpressionException e) {
			logger.error(e.getMessage());
		}
		
		tagsSet.clear();
		startTransaction = "TxInfAndSts";
		tagsSet.add(startTransaction);

		try {
			tmp = this.readTillFirstAppearingTagInBulk(tagsSet, true);
		} catch (Exception e1) {
			logger.error(e1.getMessage());
		}
		if (tmp == null) {
			// no transaction start tag nor new group were found.
			return trxSize;
		}

		List<PaymentReferenceType> listPaymentRefernceType = new ArrayList<PaymentReferenceType>();

		PerformDebulkingAckRequsetDocument newChunk = this
				.createChunk(orgnlMsgId);
		while (tmp != null && transactionCount < chunkSize) {
			// means that the current encountered tag is a group tag
			if (tmp.equals(startGroup)) {
				// means that is a chunk for the consumer to get
				break;
			}
			// means that the current encountered tag is a transaction tag
			else {
				String node = this.getCompleteNode(tmp);
				trxSize += node.length();
				
				transactionCount++;
				if (tmp.equals(startTransaction)) {

					try {
						Document doc = this.getXMLDocumentFromString(node);

						txStatus = txStatusPath.evaluate(doc);
						TransactionStatus txSts = TransactionStatus.getStatusByValue(txStatus);
						switch (txSts) {
							case REJECTED: {
								statusRsn = statusPath.evaluate(doc);
								if (GlobalUtils.isNullOrEmpty(statusRsn)) {
									statusRsn = descriptionPath.evaluate(doc);
								}
								if (GlobalUtils.isNullOrEmpty(statusRsn)) {
									statusRsn = (!GlobalUtils
											.isNullOrEmpty(grpStatusRsn)) ? grpStatusRsn
											: grpDescriptionRsn;
									status.setReasonCode(statusRsn);
								}
								orgnlInstrIdStr = orgnlInstrId.evaluate(doc);
								paymentMID = !GlobalUtils
										.isNullOrEmpty(orgnlInstrIdStr) ? orgnlInstrIdStr
										: orgnlTxId.evaluate(doc);
								PaymentReferenceType paymentInfo = PaymentReferenceType.Factory
										.newInstance();
								paymentInfo.setPaymentReference(paymentMID);
								paymentInfo.setReason(statusRsn);
								listPaymentRefernceType.add(paymentInfo);
							}
							break;
						}

					} catch (Exception e) {
						logger.error(e.getMessage());
					}
				}
			}
			tmp = this.readTillFirstAppearingTagInBulk(tagsSet, true);
		}

		if (listPaymentRefernceType.size() > 0) {
			newChunk.getPerformDebulkingAckRequset()
					.setPaymentReferenceTypeListArray(
							listPaymentRefernceType
									.toArray(new PaymentReferenceType[listPaymentRefernceType
											.size()]));
			if (!StringUtils.isEmpty(status.getStatusCode())) {
				newChunk.getPerformDebulkingAckRequset().setRejectReason(
						status.getStatusCode());
			}
			this.chunks.add(newChunk);
		}
		
		return trxSize;
	}

	protected List<PerformDebulkingAckRequsetDocument> getChunksFromStringListForBulkReject(
			List<String[]> chunksIds) {
		if (chunksIds == null || chunksIds.size() == 0)
			return Collections.emptyList();

		List<PerformDebulkingAckRequsetDocument> chunks = new ArrayList<PerformDebulkingAckRequsetDocument>();

		for (Iterator iterator = chunksIds.iterator(); iterator.hasNext();) {
			String[] values = (String[]) iterator.next();
			PerformDebulkingAckRequsetDocument doc = PerformDebulkingAckRequsetDocument.Factory
					.newInstance();
			doc.addNewPerformDebulkingAckRequset();
			doc.getPerformDebulkingAckRequset().setOutChunkID(values[0]);
			doc.getPerformDebulkingAckRequset().setOrgnlMsgId(values[1]);
			doc.getPerformDebulkingAckRequset().setRejectReason(
					status.getReasonCode());
			chunks.add(doc);
		}
		return chunks;
	}
	
	@Override
	public long getBatchIndexOffset() {
		return 0;
	}
	
	/**
	 * getting headerGrpInf xml containing both GrpHdr and OrgnlGrpInfAndSts and removing the GrpHdr and all namespace prefix
	 * @param headerGrpInf
	 * @return stripped headerGrpInf containing only OrgnlGrpInfAndSts tag
	 */
	private String getOrgnlGrpInfAndSts(String headerGrpInf){
		String strippedPart = null;
		String prefix = this.getNamespacePrefix();

		strippedPart = headerGrpInf.replaceAll(prefix+":","");
		strippedPart = strippedPart.substring(strippedPart.indexOf("<OrgnlGrpInfAndSts>"));
		strippedPart = strippedPart.replaceAll("\t","");

		return strippedPart;
	}

	@Override
	public void readerSpecificInit() throws XMLStreamException {
		
		GroupStatus groupStatus = GroupStatus.getStatusByValue(getBulkStatus());
		getStatus(groupStatus);
	}

	public void performMatchingAndGetFileStatus() {
		final UserTransaction[] arrTxHolder = new UserTransaction[1] ;
		HashMap<String, LogicalFieldsXpath> lfXpath = CacheKeys.LogicalFieldsXPathKey.getSingle(MESSAGE_TYPE_PACS_002);
		LogicalFieldsXpath origMsgId = lfXpath.get(X_ORGNL_MSG_ID);
		String tagName = origMsgId.getTagName();
		Feedback feedback = new Feedback();
		boolean shouldCommit = true;
		COMPILE_PATTERN = "<%s" + tagName + ">(.*)</%s" + tagName + ">";
		COMPILE_PATTERN = COMPILE_PATTERN.replaceAll("%s",getNamespacePrefix()+":");
		Connection conn = null;
		setPattern(Pattern.compile(COMPILE_PATTERN));
		Matcher m = getPattern().matcher(getHeader());

		// found orig message ID, perform matching check
		if (m.find()) {
			String origId = m.group(1);
			try {
				feedback = BOBasic.startTransaction(arrTxHolder) ;
			    if(!feedback.isSuccessful()) throw new Exception(feedback.toString()) ;
			    conn = daoDebulkingProcess.getConnection();
			    
				originalFileInternalId = daoDebulkingProcess.findMatchingFile(conn, origId);
				
				if (GlobalUtils.isNullOrEmpty(originalFileInternalId) && !bAlreadyMatched) { // match not found
					fileStatus = STATUS_NOT_MATCHED;
				} else { // found a match get status from pacs 002

					String statusFromPacs002 = getBulkStatus();
					String origFileStatus = STATUS_FILE_COMPLETED;
					fileStatus = STATUS_FILE_COMPLETED;
					switch (BulkStatus.valueOf(statusFromPacs002)) {
						case ACTC:
							break;
						case RJCT:
							this.listener.markBulkFullReject();
							break;
						case PART:
							break;
					}
					// update orig file status
					daoDebulkingProcess.updateFileSummaryStatusAndAudit(conn, origFileStatus,originalFileInternalId);

					bAlreadyMatched=true;
				}
			} catch (Exception e) {
				logger.error("Could not find matching file", e);
				fileStatus = STATUS_NOT_MATCHED;
				shouldCommit = false;
			}finally
			{
				feedback = BOBasic.endTransaction(arrTxHolder[0], shouldCommit)  ;
				DAODebulkingProcess.releaseResources(conn);
			}
		}
	}

	@Override
	public List<PDO> getPDOsFromChunk(PerformDebulkingMultiRequestDocument doc,
			String chunkId, String sInternalFileID, FileSummary fileSummary,
			Map[] arrMapSharedPDOContextHolder, boolean bShouldLogInfo)
			throws Throwable {
		return super.getPDOsFromChunk(doc, chunkId, sInternalFileID,
				fileSummary, arrMapSharedPDOContextHolder);
	}

}
