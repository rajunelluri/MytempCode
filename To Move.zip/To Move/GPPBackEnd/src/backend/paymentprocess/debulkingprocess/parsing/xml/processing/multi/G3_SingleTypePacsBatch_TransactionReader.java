package backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi;

import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.X_ORGNL_GRP_INFO;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.X_PMT_INFO;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.namespace.QName;
import javax.xml.stream.XMLStreamException;

import org.apache.cxf.common.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.cache.entities.FileSummary;
import com.fundtech.cache.entities.InterfaceTypes;
import com.fundtech.cache.entities.LogicalFieldsXpath;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.parser.g3.G3BulkMessageMetadata;
import com.fundtech.scl.debulkingProcessService.FileIndexDataType;
import com.fundtech.scl.debulkingProcessService.PerformDebulkingMultiRequestDocument;

public class G3_SingleTypePacsBatch_TransactionReader  extends AckXmlTransactionReader implements XmlTransactionReaderListener {
	private static final Logger logger = LoggerFactory.getLogger(G3_SingleTypeBatch_TransactionReader.class);
	
	private G3Msg_SingleTypeBatch g3DataType; //to avoid casting	
	private AckXmlTransactionReader nativeReader;
	private String prefix ;
	private boolean initialized;
	

	public G3_SingleTypePacsBatch_TransactionReader() {
	}
	
	public G3_SingleTypePacsBatch_TransactionReader(FndtBatchMsg_SingleTypeBatch fileDataType) {
		setFileMessageTypeData(fileDataType);
	}
	
	public G3_SingleTypePacsBatch_TransactionReader(File file,int chunkSize,FileMessageTypeData fileMessageTypeData) {
		try {
			setFile(file);
			setChunkSize(chunkSize);
			setRandomeFile(new RandomAccessFile(file, "r"));
			setFileSize(getRandomeFile().length()) ;
			setUtils(new RandomAccessFileUtils(getFile()));
			setFileMessageTypeData(fileMessageTypeData);
			setByteBuffer(new ByteArrayListOptimized());
		} catch (Exception e) {
			throw new RuntimeException(e);
		} 		
	}

	public G3_SingleTypePacsBatch_TransactionReader(File file,RandomAccessFile accessFile, int chunkSize,FileMessageTypeData fileMessageTypeData) {
		try {
			setFile(file);
			setChunkSize(chunkSize);
			setRandomeFile(new RandomAccessFile(file, "r"));
			setFileSize(getRandomeFile().length()) ;
			setUtils(new RandomAccessFileUtils(getFile()));
			setFileMessageTypeData(fileMessageTypeData);
		} catch (Exception e) {
			throw new RuntimeException(e);
		} 		
	}
	

	@Override
	public void init() {
		
		parseAppHdr();
		
		try {
			parseBulkAndGrpHead();
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
			return;
		}
		if(!initialized)
			return;

		configureNativeReader();
		
		//The following copied from pain parser, needed for moving the chunk to the next step (interface)				
		INTERFACE_TYPE = InterfaceTypes.INTERFACE_TYPE_MASSPMNTS;
		INTERFACE_SUB_TYPE = InterfaceTypes.INTERFACE_SUB_TYPE_DEB;
		setSinglePayment(false);
			
		nativeReader.setCompiledPattern();
		nativeReader.init();				// also gets into nativeReader.readerSpecificInit();
	}

	/**
	 * basic parsing from the file head.
	 * Parse the of native GrpHdr out of G3 message
	 */
	private void parseFileHead() throws IOException,XMLStreamException {
		G3BulkMessageMetadata[] msgTypes = G3BulkMessageMetadata.values();
		G3BulkMessageMetadata msg = null;
		int index = 0;
		for (G3BulkMessageMetadata msgType : msgTypes){
			index = getByteBuffer().
					indexOfWithStartEndIndex(("<" + msgType.g3PayloadName).getBytes(), (int)getLastTransactionEndInd() - getByteBuffer().getStart(), getByteBuffer().getEnd());
			if (index != -1){
				setBulkType(msgType.bulkType);
				msg = msgType;
				break;
			}
		}

		if (msg == null){
			return;
		}
		this.lastTransactionEndInd = index;
		prefix = msg.namespacePrefix;
		String ns = msg.paymentNamespace;
		HashMap<String, LogicalFieldsXpath> lfMap = CacheKeys.LogicalFieldsXPathKey.getSingle(msg.nativePaymentType);
		String transactionTag = lfMap.get(X_PMT_INFO).getTagName();
		
		byte[] headerStartTag = ("<" + prefix + ":GrpHdr>").getBytes(); 
		byte[] headerEndTag = ("</" + prefix + ":GrpHdr>").getBytes(); 
		setGlobalHeaderStartTagIndex(findAndReadTillNearestTagInChunk(headerStartTag, getLastTransactionEndInd() - getByteBuffer().getStart()) + getByteBuffer().getStart());
		setGlobalHeaderEndTagIndex(findAndReadTillNearestTagInChunk(headerEndTag, getLastTransactionEndInd()- getByteBuffer().getStart()) + getByteBuffer().getStart() + headerEndTag.length);
		
		LogicalFieldsXpath origData = lfMap.get(X_ORGNL_GRP_INFO);
		if (msg.isPacs002() && origData != null){
			byte[] origEndTag = ("</" +  prefix + ":" + origData.getTagName() + ">").getBytes();
			//long index = calcBulkBoundaries(origEndTag);
			setGlobalHeaderEndTagIndex(findAndReadTillNearestTagInChunk(origEndTag, getLastTransactionEndInd() - getByteBuffer().getStart()) + getTotalDeleted()+ origEndTag.length);
		}
		
		g3DataType.init(new QName(ns, transactionTag, prefix), new QName(ns, "GrpHdr", prefix));
		
		// get totals from GrpHdr
		setHeader(getUtils().getFileSectionFromIndexes(getGlobalHeaderStartTagIndex(), getGlobalHeaderEndTagIndex()));
		COMPILE_PATTERN = "<%sOrgnlNbOfTxs>(.*)</%sOrgnlNbOfTxs>|<%sCtrlSum>(.*)</%sCtrlSum>|<%sTtlIntrBkSttlmAmt.*>(.*)</%sTtlIntrBkSttlmAmt>";
		COMPILE_PATTERN = COMPILE_PATTERN.replaceAll("%s", prefix + ":");
		
		setPattern(Pattern.compile(COMPILE_PATTERN));
		Matcher m = getPattern().matcher(getHeader());
		
		while (m.find()){
			if (m.group(1) != null){
				setBulkNumOfTx(Long.parseLong(m.group(1)));
			}
			if (m.group(2) != null){
				setBulkCtrlSum(Long.parseLong(m.group(2)));
			}
			if (m.group(3) != null){
				setBulkTotalAmt(new BigDecimal(m.group(3)));
			}
        }
		
		
		initialized = true;	
	}
	
	/**
	 * parsing from the file head. for Pacs.002 only !!
	 * Parse the of native GrpHdr out of G3 message
	 */
	private void parseBulkAndGrpHead() throws IOException,XMLStreamException {
		//G3BulkMessageMetadata[] msgTypes = {G3BulkMessageMetadata.PAYMENT_STATUS_CT,G3BulkMessageMetadata.PAYMENT_STATUS_DD};
		G3BulkMessageMetadata[] msgTypes = G3BulkMessageMetadata.values();
		G3BulkMessageMetadata msg = null;
		int index = 0;
		for (G3BulkMessageMetadata msgType : msgTypes){
			
			index = findAndReadTillNearestTagInChunk(
					("<" + msgType.g3PayloadName).getBytes(), (int)getLastTransactionEndInd()- getByteBuffer().getStart());

			if (index != -1){
				setBulkType(msgType.bulkType);
				msg = msgType;
				break;
			}
		}
		
		if (index == -1)
			return;
		
		if(msg == G3BulkMessageMetadata.PAYMENT_STATUS_CT && !isCTBulkwasProcessed){
			isCTBulkwasProcessed = true;
		}else if(msg == G3BulkMessageMetadata.PAYMENT_STATUS_DD && !isDDBulkwasProcessed){
			isDDBulkwasProcessed = true;
		}else{
			return;
		}
		
		setBulkType(msg.bulkType);
		this.lastTransactionEndInd = index;
		prefix = msg.namespacePrefix;
		String ns = msg.paymentNamespace;
		HashMap<String, LogicalFieldsXpath> lfMap = CacheKeys.LogicalFieldsXPathKey.getSingle(msg.nativePaymentType);
		String transactionTag = lfMap.get(X_PMT_INFO).getTagName();
		
		byte[] headerStartTag = ("<" + prefix + ":GrpHdr>").getBytes(); 
		byte[] headerEndTag = ("</" + prefix + ":GrpHdr>").getBytes(); 
		setGlobalHeaderStartTagIndex(findAndReadTillNearestTagInChunk(headerStartTag, getLastTransactionEndInd() - getByteBuffer().getStart()) + getByteBuffer().getStart());
		setGlobalHeaderEndTagIndex(findAndReadTillNearestTagInChunk(headerEndTag, getLastTransactionEndInd()- getByteBuffer().getStart()) + getByteBuffer().getStart() + headerEndTag.length);
		
		LogicalFieldsXpath origData = lfMap.get(X_ORGNL_GRP_INFO);
		if (msg.isPacs002() && origData != null){
			byte[] origEndTag = ("</" +  prefix + ":" + origData.getTagName() + ">").getBytes();
			//long index = calcBulkBoundaries(origEndTag);
			setGlobalHeaderStartTagIndex(getGlobalHeaderEndTagIndex());
			setGlobalHeaderEndTagIndex(findAndReadTillNearestTagInChunk(origEndTag, (int)getGlobalHeaderEndTagIndex() - getByteBuffer().getStart()) + getByteBuffer().getStart() + origEndTag.length);
		}
		this.lastTransactionEndInd = (int)getGlobalHeaderEndTagIndex();
		g3DataType.init(new QName(ns, transactionTag, prefix), new QName(ns, "GrpHdr", prefix));
		
		// get totals from GrpHdr
		String header = getUtils().getFileSectionFromIndexes(getGlobalHeaderStartTagIndex(), getGlobalHeaderEndTagIndex());
		header = header.replaceAll("\t", "");
		setHeader(header);
		COMPILE_PATTERN = "<%sOrgnlMsgId>(.*)</%sOrgnlMsgId>|<%sOrgnlNbOfTxs>(.*)</%sOrgnlNbOfTxs>|<%sGrpSts>(.*)</%sGrpSts>";
		COMPILE_PATTERN = COMPILE_PATTERN.replaceAll("%s", prefix + ":");
		
		setPattern(Pattern.compile(COMPILE_PATTERN));
		Matcher m = getPattern().matcher(getHeader());
		
		while (m.find()){
			if (m.group(1) != null){
				setRelatedFileReference(m.group(1));
			}
			if (m.group(2) != null){
				setBulkNumOfTx(Long.parseLong(m.group(2)));
			}
			if (m.group(3) != null){
				setBulkStatus(m.group(3));
			}
        }
		
		this.lastTransactionEndInd = (int)getGlobalHeaderEndTagIndex();
		initialized = true;	
	}

	protected void configureNativeReader() {		
		try {
			nativeReader = (AckXmlTransactionReader) new Pacs002XmlTransactionReader(getFile(),getChunkSize(),getFileMessageTypeData());
			
			nativeReader.setListener(this);

			nativeReader.setCurrentChunk(PerformDebulkingMultiRequestDocument.Factory.newInstance());
			nativeReader.getCurrentChunk().addNewPerformDebulkingMultiRequest();
			nativeReader.setFileMessageTypeData(g3DataType.getNativeMessageDataType());
			nativeReader.setNamespacePrefix(g3DataType.getNativePaymentPrefix());
			nativeReader.setHeaderNamespacePrefix(g3DataType.getNativePaymentHeaderPrefix());
			//copy parsed index
			nativeReader.setGlobalHeaderStartTagIndex(getGlobalHeaderStartTagIndex());
			nativeReader.setGlobalHeaderEndTagIndex(getGlobalHeaderEndTagIndex());
			nativeReader.setPrePmtInfoStartIndex(getPrePmtInfoStartIndex());
			nativeReader.setPrePmtInfoEndIndex(getPrePmtInfoEndIndex());
			nativeReader.initPreStartDataType();
			nativeReader.lastTransactionEndInd = this.lastTransactionEndInd;
			nativeReader.setRelatedFileReference(this.getRelatedFileReference());
			nativeReader.setCompiledPattern();
			nativeReader.setBulkStatus(this.getBulkStatus());
			nativeReader.setBulkType(this.getBulkType());
			nativeReader.setHeader(this.getHeader());
			nativeReader.setAppHdrCreDt(this.getAppHdrCreDt());
		} catch (Exception e) {
			logger.error("configureNativeReader failed",e);
		}		
	}

	@Override
	public void setFileMessageTypeData(FileMessageTypeData fileMessageTypeData) {
		super.setFileMessageTypeData(fileMessageTypeData);
		this.g3DataType = (G3Msg_SingleTypeBatch)fileMessageTypeData;
	}
	
	
	//
	// BODebulkFile related
	//
	
	@Override
	public void onTransactionEnded(XmlTransactionReaderBase readerBase,FileIndexDataType txInfo) {
		txInfo.setPaymentType(g3DataType.getPaymentTypeName());
		this.lastTransactionEndInd = Integer.parseInt(Long.toString(txInfo.getTransactionEndTag()));

	}

	//
	// relation with native reader
	//
	
	private boolean hadTransactions = false;

	@Override
	public boolean hasNext() {

		try {
			init();
			if (!initialized){
				this.hadTransactions = false;
				this.hasMoreBulks = false;
				return false;
			}
		} catch (Exception e) {
			throw new BulkFileParsingExecption(e);
		}
		
		if(this.getHeader() != null){
			hadTransactions = nativeReader.hasNext();
			this.hasMoreBulks = !isCTBulkwasProcessed || !isDDBulkwasProcessed;
		}else{
			this.hadTransactions = false;
			this.hasMoreBulks = false;
		}

		try {
			resetBulk();
		} catch (IOException e) {
			logger.error(e.getMessage());
		}

		
		return hadTransactions;
	}
	
	private void resetBulk() throws IOException {
		setHeader(null);
		
		setGlobalHeaderEndTagIndex(0);
		setGlobalHeaderStartTagIndex(0);

		setUtils(new RandomAccessFileUtils(getFile()));
		setCurrentChunk(PerformDebulkingMultiRequestDocument.Factory.newInstance());
		getCurrentChunk().addNewPerformDebulkingMultiRequest();
		
		setByteBuffer(new ByteArrayListOptimized());
		setByteCount(BUFFER_SIZE);
		setSize(0);
		
		getUtils().getM_raf().seek(0);
		
		getUtils().readToByteArrayListEnd(getByteBuffer(), BUFFER_SIZE);

		this.initialized = false;
	}

	/**
	 * searches for tag of new bulk and reset header indexes
	 * @return
	 */
	private boolean ifMoreBulkExists() {
		
		byte[] headerStartTag = ("<" + prefix + ":GrpHdr>").getBytes(); 
		byte[] headerEndTag = ("</" + prefix + ":GrpHdr>").getBytes();
		
		byte[] bulkStartTag = ("<" + prefix + ":FIToFIPmtStsRpt>").getBytes(); 
		
		int newHeaderStartTagIndex = 0 ;
		int newHeaderEndTagIndex = 0 ;
		
		int newBulkStartTagIndex = 0 ;
		try {
			newBulkStartTagIndex = findAndReadTillNearestTagInChunk(
					bulkStartTag, (int)getGlobalHeaderEndTagIndex());
			
			if(newBulkStartTagIndex==-1)// no new bulk found
				return false;
			
			newHeaderStartTagIndex = findAndReadTillNearestTagInChunk(
					headerStartTag, newBulkStartTagIndex);
							
			newHeaderEndTagIndex = findAndReadTillNearestTagInChunk(
					headerEndTag, newHeaderStartTagIndex);
			
		} catch (IOException e) {
			return false;
		}
		setGlobalHeaderStartTagIndex(newHeaderStartTagIndex);
		setGlobalHeaderEndTagIndex(newHeaderEndTagIndex);
		initialized=false;
		return true;
	}

	@Override
	public Object next() {
		return nativeReader.next();						
	}
	
	@Override
	public boolean readTransactionsOfChunkSize() {
		//this method wouldn't be read. hasNext is via native reader
		return false;
	}

	@Override
	public String getXmlofChunk(Object chunk) {
		return nativeReader.getXmlofChunk(chunk);
	}

	@Override
	public int getRecCountInChunk(Object chunk) {
		return nativeReader.getRecCountInChunk(chunk);
	}
	
	@Override
	public String getMsgId() {
		if (StringUtils.isEmpty(super.getMsgId()) && nativeReader != null)
			return nativeReader.getMsgId();
		
		return super.getMsgId();
	}

	@Override
	public int getPmtInfCount() {
		if (super.getPmtInfCount() == 0 && nativeReader != null)
			return nativeReader.getPmtInfCount();
		
		return super.getPmtInfCount();
	}

	@Override
	public int getTrnsCount() {		
		if (super.getTrnsCount() == 0 && nativeReader != null)
			return nativeReader.getTrnsCount();
		
		return super.getTrnsCount();
	}

	@Override
	public String getCtrlSum() {
		if (StringUtils.isEmpty(super.getCtrlSum()) && nativeReader != null)
			return nativeReader.getCtrlSum();
		
		return super.getCtrlSum();
	}

	@Override
	public String getPartyName() {
		if (StringUtils.isEmpty(super.getPartyName()) && nativeReader != null)
			return nativeReader.getPartyName();
		
		return super.getPartyName();
	}

	@Override
	public String getInitiatingPartyCustCode() {
		if (StringUtils.isEmpty(super.getInitiatingPartyCustCode()) && nativeReader != null)
			return nativeReader.getInitiatingPartyCustCode();
		
		return super.getInitiatingPartyCustCode();
	}

	@Override
	public List<PDO> getPDOsFromChunk(PerformDebulkingMultiRequestDocument doc,
			String chunkId, String sInternalFileID, FileSummary fileSummary,
			Map[] arrMapSharedPDOContextHolder, boolean bShouldLogInfo)
			throws Throwable {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void init(InputStream inputStream) throws Exception {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void readerSpecificInit() throws XMLStreamException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onBulkEnd(long FndtBatchTagLastIndex,
			long transactionEndTagIndex, long newTxStartIndex) {
	}

	@Override
	public boolean isBulkEnd() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public long getBatchIndexOffset() {
		// TODO Auto-generated method stub
		return 0;
	}
	
	@Override
	public void setAdditionalDocumentData(Object request, String chunkId,
			String status, String internalFileId, String path, String workFlow, String bulkId) {
			
		nativeReader.setAdditionalDocumentData(request, chunkId, status, internalFileId, path, workFlow, bulkId);
	}

	@Override
	public String getFileStatus() {
		if (nativeReader != null){
			return nativeReader.getFileStatus();
		}
		
		return null;
	}

	@Override
	public String getoriginalFileInternalId() {
		if (nativeReader != null){
			return nativeReader.getoriginalFileInternalId();
		}
		return null;
	}

	@Override
	public void markBulkFullReject() {
		this.listener.markBulkFullReject();
		
	}

}


