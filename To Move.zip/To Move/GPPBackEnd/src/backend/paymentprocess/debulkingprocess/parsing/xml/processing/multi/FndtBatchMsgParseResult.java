package backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi;

import javax.xml.namespace.QName;

public class FndtBatchMsgParseResult {

	public QName fndtMsgRootQName;
	public QName nativeMessageRootQName;
	public QName nativeHeaderRootQName;
	
	public long nativePayloadGrpHdrStartTagLocation;
	public long nativePayloadGrpHdrEndTagLocation;
	
	public long nativePayloadPmtInfStartTagLocation;
	public long nativePayloadPmtInfEndTagLocation;
	
	
	private boolean batchHeaderStarted = false;
	private boolean nativeGrpHeaderStarted = false;
	private boolean batchHeaderEnded = false;
	private boolean pmntHeaderStarted = false;
	private boolean nativePmtInfStarted = false;
	private boolean pmntHeaderEnded = false;
	private boolean fndtMsgStarted = false;
	private boolean nativePayloadStarted = false;
	
	
	public String getFirstMissingTagName() {
		if (!batchHeaderStarted)
			return "BatchHeader start element";
		if (!nativeGrpHeaderStarted)
			return "GrpHdr start element";
		if (!batchHeaderEnded)
			return "BatchHeader end element";
		if (!pmntHeaderStarted)
			return "PmntHeader start element";
		if (!nativePmtInfStarted)
			return "PmtInf start element";
		if (!pmntHeaderEnded)
			return "PmntHeader end element";
		if (!fndtMsgStarted)
			return "FndtMsg start element";
		if (!nativePayloadStarted)
			return "native Payload Start element>";
		return null;
	}


	@Override
	public String toString() {
		return "FndtBatchMsgParseResult [fndtMsgRootQName="
				+ fndtMsgRootQName + ", nativeMessageRootQName="
				+ nativeMessageRootQName
				+ ", nativeHeaderRootQName = " + nativeHeaderRootQName
				+ ", nativePayloadGrpHdrEndTagLocation="
				+ nativePayloadGrpHdrEndTagLocation
				+ ", nativePayloadGrpHdrStartTagLocation="
				+ nativePayloadGrpHdrStartTagLocation
				+ ", nativePayloadPmtInfEndTagLocation="
				+ nativePayloadPmtInfEndTagLocation
				+ ", nativePayloadPmtInfStartTagLocation="
				+ nativePayloadPmtInfStartTagLocation + "]";
	}


	public QName getFndtMsgRootQName() {
		return fndtMsgRootQName;
	}


	public void setFndtMsgRootQName(QName fndtMsgRootQName) {
		this.fndtMsgRootQName = fndtMsgRootQName;
	}


	public QName getNativeMessageRootQName() {
		return nativeMessageRootQName;
	}


	public void setNativeMessageRootQName(QName nativeMessageRootQName) {
		this.nativeMessageRootQName = nativeMessageRootQName;
	}


	public QName getNativeHeaderRootQName() {
		return nativeHeaderRootQName;
	}


	public void setNativeHeaderRootQName(QName nativeHeaderRootQName) {
		this.nativeHeaderRootQName = nativeHeaderRootQName;
	}


	public long getNativePayloadGrpHdrStartTagLocation() {
		return nativePayloadGrpHdrStartTagLocation;
	}


	public void setNativePayloadGrpHdrStartTagLocation(
			long nativePayloadGrpHdrStartTagLocation) {
		this.nativePayloadGrpHdrStartTagLocation = nativePayloadGrpHdrStartTagLocation;
	}


	public long getNativePayloadGrpHdrEndTagLocation() {
		return nativePayloadGrpHdrEndTagLocation;
	}


	public void setNativePayloadGrpHdrEndTagLocation(
			long nativePayloadGrpHdrEndTagLocation) {
		this.nativePayloadGrpHdrEndTagLocation = nativePayloadGrpHdrEndTagLocation;
	}


	public long getNativePayloadPmtInfStartTagLocation() {
		return nativePayloadPmtInfStartTagLocation;
	}


	public void setNativePayloadPmtInfStartTagLocation(
			long nativePayloadPmtInfStartTagLocation) {
		this.nativePayloadPmtInfStartTagLocation = nativePayloadPmtInfStartTagLocation;
	}


	public long getNativePayloadPmtInfEndTagLocation() {
		return nativePayloadPmtInfEndTagLocation;
	}


	public void setNativePayloadPmtInfEndTagLocation(
			int nativePayloadPmtInfEndTagLocation) {
		this.nativePayloadPmtInfEndTagLocation = nativePayloadPmtInfEndTagLocation;
	}


	public boolean isBatchHeaderStarted() {
		return batchHeaderStarted;
	}


	public void setBatchHeaderStarted(boolean batchHeaderStarted) {
		this.batchHeaderStarted = batchHeaderStarted;
	}


	public boolean isNativeGrpHeaderStarted() {
		return nativeGrpHeaderStarted;
	}


	public void setNativeGrpHeaderStarted(boolean nativeGrpHeaderStarted) {
		this.nativeGrpHeaderStarted = nativeGrpHeaderStarted;
	}


	public boolean isBatchHeaderEnded() {
		return batchHeaderEnded;
	}


	public void setBatchHeaderEnded(boolean batchHeaderEnded) {
		this.batchHeaderEnded = batchHeaderEnded;
	}


	public boolean isPmntHeaderStarted() {
		return pmntHeaderStarted;
	}


	public void setPmntHeaderStarted(boolean pmntHeaderStarted) {
		this.pmntHeaderStarted = pmntHeaderStarted;
	}


	public boolean isNativePmtInfStarted() {
		return nativePmtInfStarted;
	}


	public void setNativePmtInfStarted(boolean nativePmtInfStarted) {
		this.nativePmtInfStarted = nativePmtInfStarted;
	}


	public boolean isPmntHeaderEnded() {
		return pmntHeaderEnded;
	}


	public void setPmntHeaderEnded(boolean pmntHeaderEnded) {
		this.pmntHeaderEnded = pmntHeaderEnded;
	}


	public boolean isFndtMsgStarted() {
		return fndtMsgStarted;
	}


	public void setFndtMsgStarted(boolean fndtMsgStarted) {
		this.fndtMsgStarted = fndtMsgStarted;
	}


	public boolean isNativePayloadStarted() {
		return nativePayloadStarted;
	}


	public void setNativePayloadStarted(boolean nativePayloadStarted) {
		this.nativePayloadStarted = nativePayloadStarted;
	}	
	
	
}
