
package backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi;

import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.X_ORGNL_GRP_INFO;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.X_PMT_INFO;
import static com.fundtech.util.GlobalDateTimeUtil.XML_SCHEMA_DATE_TIME_FULL;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.namespace.QName;
import javax.xml.stream.XMLStreamException;

import org.apache.cxf.common.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.cache.entities.FileSummary;
import com.fundtech.cache.entities.InterfaceTypes;
import com.fundtech.cache.entities.LogicalFieldsXpath;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.parser.g3.G3BulkMessageMetadata;
import com.fundtech.scl.debulkingProcessService.FileIndexDataType;
import com.fundtech.scl.debulkingProcessService.PerformDebulkingMultiRequestDocument;

/**
 * G3 TransactionReader parse the native message parts.
 * 
 * Supports G3 message which 
 *      1. has GrpHdr
 *      2. contains transactions all from same native type
 *      3. all native transactions share the same prefix
 * 
 * Parsing Notes:
 *      Parsing of GrpHdr is done using XML streaming
 *      Parsing of Transaction is done using native message parser.
 * 
 * Namespace Notes:
 *      When constructing single G3 out of indexed, normalize 
 *  the Namespace to default NS
 * 
 */
public class G3_SingleTypeBatch_TransactionReader extends AbstractSingleInMuliSchemaReader implements XmlTransactionReaderListener {
        private static final Logger logger = LoggerFactory.getLogger(G3_SingleTypeBatch_TransactionReader.class);
        
        private G3Msg_SingleTypeBatch g3DataType; //to avoid casting    
        private XmlTransactionReader nativeReader;

        private boolean initialized;
        

        public G3_SingleTypeBatch_TransactionReader() {
        }
        
        public G3_SingleTypeBatch_TransactionReader(FndtBatchMsg_SingleTypeBatch fileDataType) {
                setFileMessageTypeData(fileDataType);
        }
        
        public G3_SingleTypeBatch_TransactionReader(File file,int chunkSize,FileMessageTypeData fileMessageTypeData) {
                try {
                        setFile(file);
                        setChunkSize(chunkSize);
                        setRandomeFile(new RandomAccessFile(file, "r"));
                        setFileSize(getRandomeFile().length()) ;
                        setUtils(new RandomAccessFileUtils(getFile()));
                        setFileMessageTypeData(fileMessageTypeData);
                } catch (Exception e) {
                        throw new RuntimeException(e);
                }               
        }

        public G3_SingleTypeBatch_TransactionReader(File file,RandomAccessFile accessFile, int chunkSize,FileMessageTypeData fileMessageTypeData) {
                super(file,accessFile,chunkSize,fileMessageTypeData);
                setByteBuffer(new ByteArrayListOptimized());
                setUtils(new RandomAccessFileUtils(getFile()));
        }
        


        @Override
        public void init() throws IOException {
                if (initialized)
                        return;
                
                parseAppHdr();
                
                try {
                        parseFileHead();
                        if (!initialized){
                                return;
                        }
                } catch (XMLStreamException e) {
                        logger.error(e.getMessage(),e);
                }
                
                configureNativeReader();
                
                //TBD copied from pain parser, is that required?!               
                INTERFACE_TYPE = InterfaceTypes.INTERFACE_TYPE_MASSPMNTS;
                INTERFACE_SUB_TYPE = InterfaceTypes.INTERFACE_SUB_TYPE_DEB;
                setSinglePayment(false);

                nativeReader.setHeader(getUtils().getFileSectionFromIndexes(getGlobalHeaderStartTagIndex(), getGlobalHeaderEndTagIndex()));
                nativeReader.setCompiledPattern();
                nativeReader.initHeader();
                
        }
        
        /*
         * if the index of the new bulk was found this function will be triggered.
         * FIRST STEP - set the RandomAccessFile M_raf to be on that index. 
         * Second Step - copy to the byte buffer the info from the RandomAccessFile from the index till end of byte buffer length(fill all bybe buffer)
         * Third Step - clear the elements on the byte buffer.
         * Fourth Step - set the size after clearing it to BUFFER_SIZE.
         * Fifth Step - set the byte count to the index.
         * Six Step - do the same to the total deleted.
         */
        private boolean rotateFileIfNeeded()
        {
                if (getUtils().getM_nNewBulkIndex() > 0 )
                {
                        try
                        {
                                getUtils().getM_raf().seek(getUtils().getM_nNewBulkIndex());
                                getUtils().readToByteArrayForNewBulk(this.getByteBuffer(),BUFFER_SIZE);
                                this.getByteBuffer().clear();
                                this.setByteCount(getUtils().getM_nNewBulkIndex());
                                this.setTotalDeleted(getUtils().getM_nNewBulkIndex());
                                return true;
                        }
                        catch (Exception e) 
                        {
                                logger.debug("An issue has occured at rotateFileIfNeeded");
                        }
                }
                return false;
        }
        
        private void SetCurrentMsgType(G3BulkMessageMetadata msg)
        {
        	getUtils().setCurrentMsgType(msg); 
        }
        
        
        /**
         * basic parsing from the file head.
         * Parse the of native GrpHdr out of G3 message
         */
        private void parseFileHead() throws IOException,XMLStreamException {
                G3BulkMessageMetadata[] msgTypes = G3BulkMessageMetadata.values();
                G3BulkMessageMetadata msg = null;
                boolean bArrayWasRotated = rotateFileIfNeeded();
                for (G3BulkMessageMetadata msgType : msgTypes)
                {
                    int start = bArrayWasRotated ?0:(int)getLastTransactionEndInd() - getByteBuffer().getStart();
                    int end   = bArrayWasRotated ?this.getByteBuffer().getArray().length:((int)getLastTransactionEndInd() - getByteBuffer().getStart() + 100);
                    int index = getByteBuffer().indexOfWithStartEndIndex(("<" + msgType.g3PayloadName).getBytes(), start,end);
                    if (index != -1)
                    {
                        //QC# 78613: Make sure that only unique message types are searched within the file.
                        if (getUtils().getLastSavedMessageType()!= msgType)
                        {
                            msg = msgType;
                            getUtils().setLastSavedMessageType(msgType);
                            break;
                        }                       
                    }
                }

                if (msg == null){
                        return;
                }
                SetCurrentMsgType(msg);
                String prefix = msg.namespacePrefix;
                String ns = msg.paymentNamespace;
                setBulkType(msg.bulkType);
                
                HashMap<String, LogicalFieldsXpath> lfMap = CacheKeys.LogicalFieldsXPathKey.getSingle(msg.nativePaymentType);
                String transactionTag = lfMap.get(X_PMT_INFO).getTagName();
                
                byte[] headerStartTag = ("<" + prefix + ":GrpHdr>").getBytes(); 
                byte[] headerEndTag = ("</" + prefix + ":GrpHdr>").getBytes(); 
                // in a new bulk if the array was rotated the index is the start of the byte buffer.
                int  findAndReadTillNearestTagInChunkIndex = bArrayWasRotated ? 0 : getLastTransactionEndInd() - getByteBuffer().getStart();
                // in a new bulk if the array was rotated the shift is the index we have found .
                long findAndReadTillNearestTagInChunkIndexShift = bArrayWasRotated ?getUtils().getM_nNewBulkIndex():getByteBuffer().getStart();
                
                setGlobalHeaderStartTagIndex(findAndReadTillNearestTagInChunk(headerStartTag,findAndReadTillNearestTagInChunkIndex) + findAndReadTillNearestTagInChunkIndexShift);
                //in a new bulk if the array was rotated the index is the header index we just set less the index we have found for the start index. 
                findAndReadTillNearestTagInChunkIndex =bArrayWasRotated ? (int)(getGlobalHeaderStartTagIndex() -getUtils().getM_nNewBulkIndex()) : (getLastTransactionEndInd()- getByteBuffer().getStart());
                // in a new bulk if the array was rotated the shift the index we have found and the length of the tag.
                findAndReadTillNearestTagInChunkIndexShift = (bArrayWasRotated ?getUtils().getM_nNewBulkIndex():getByteBuffer().getStart()) + headerEndTag.length;
                
                setGlobalHeaderEndTagIndex(findAndReadTillNearestTagInChunk(headerEndTag,findAndReadTillNearestTagInChunkIndex) + findAndReadTillNearestTagInChunkIndexShift);
                
                LogicalFieldsXpath origData = lfMap.get(X_ORGNL_GRP_INFO);
                if (msg.isPacs002() && origData != null){
                        byte[] origEndTag = ("</" +  prefix + ":" + origData.getTagName() + ">").getBytes();
                        setGlobalHeaderEndTagIndex(findAndReadTillNearestTagInChunk(origEndTag, getLastTransactionEndInd() - getByteBuffer().getStart()) + getTotalDeleted()+ origEndTag.length);
                }
                
                g3DataType.init(new QName(ns, transactionTag, prefix), new QName(ns, "GrpHdr", prefix));
                
                // get totals from GrpHdr
                setHeader(getUtils().getFileSectionFromIndexes(getGlobalHeaderStartTagIndex(), getGlobalHeaderEndTagIndex()));
                COMPILE_PATTERN = "<%sCreDtTm>(.*)</%sCreDtTm>|<%sNbOfTxs>(.*)</%sNbOfTxs>|<%sCtrlSum>(.*)</%sCtrlSum>|<%sTtlIntrBkSttlmAmt.*>(.*)</%sTtlIntrBkSttlmAmt>|<%sTtlRtrdIntrBkSttlmAmt.*>(.*)</%sTtlRtrdIntrBkSttlmAmt>";
                COMPILE_PATTERN = COMPILE_PATTERN.replaceAll("%s", prefix + ":");
                
                setPattern(Pattern.compile(COMPILE_PATTERN));
                Matcher m = getPattern().matcher(getHeader());
                
                while (m.find()){
                        if (m.group(1) != null){
                                SimpleDateFormat formatter = new SimpleDateFormat(XML_SCHEMA_DATE_TIME_FULL);
                                Date bulkCreDtTm = null;
                                try {
                                        bulkCreDtTm = formatter.parse(m.group(1));
                                        setBulkCreDtTm(m.group(1));
                                } catch (ParseException e) {
                                        logger.error("unable to parse bulk CreDtTm {} as {}",m.group(1),XML_SCHEMA_DATE_TIME_FULL);
                                }
                        }
                        if (m.group(2) != null){
                                setBulkNumOfTx(Long.parseLong(m.group(2)));
                        }
                        if (m.group(3) != null){
                                setBulkCtrlSum(Long.parseLong(m.group(3)));
                        }
                        if (m.group(4) != null){
                        //      setBulkTotalAmt(Double.parseDouble(m.group(4)));
                                setBulkTotalAmt(new BigDecimal(m.group(4)));
                        }
                        if (m.group(5) != null){
                                setBulkTotalAmt(new BigDecimal(m.group(5)));
                        }
        }
                
                
                initialized = true;     
        }
        

    private void configureNativeReader() {              
                try {
                        nativeReader = (XmlTransactionReader)g3DataType.getNativeMessageDataType().getReader();//getReaderWithoutInit(file,chun);
                        
                        nativeReader.setListener(this);
                        
                        //TBD use constuctor
                        nativeReader.setFile(getFile());
                        nativeReader.setChunkSize(getChunkSize());
                        nativeReader.setRandomeFile(getRandomeFile());
                        nativeReader.setFileSize(getFileSize()) ;                       
                        nativeReader.setUtils(getUtils());
                        nativeReader.setCurrentChunk(PerformDebulkingMultiRequestDocument.Factory.newInstance());
                        nativeReader.getCurrentChunk().addNewPerformDebulkingMultiRequest();
                        nativeReader.setFileMessageTypeData(g3DataType.getNativeMessageDataType());
                        nativeReader.setByteBuffer(getByteBuffer());
                        nativeReader.setNamespacePrefix(g3DataType.getNativePaymentPrefix());
                        nativeReader.setHeaderNamespacePrefix(g3DataType.getNativePaymentHeaderPrefix());
                        //copy parsed index
                        nativeReader.setGlobalHeaderStartTagIndex(getGlobalHeaderStartTagIndex());
                        nativeReader.setGlobalHeaderEndTagIndex(getGlobalHeaderEndTagIndex());
                        nativeReader.setPrePmtInfoStartIndex(getPrePmtInfoStartIndex());
                        nativeReader.setPrePmtInfoEndIndex(getPrePmtInfoEndIndex());
                        nativeReader.initPreStartDataType();
                        nativeReader.setByteCount(getByteCount());
                        nativeReader.setTotalDeleted(getTotalDeleted());
                        nativeReader.setSize(getSize());
                        nativeReader.lastTransactionEndInd = this.lastTransactionEndInd;
                        nativeReader.setAppHdrCreDt(this.getAppHdrCreDt());
                } catch (Exception e) {
                        logger.error("configureNativeReader failed",e);
                }               
        }

        @Override
        public void setFileMessageTypeData(FileMessageTypeData fileMessageTypeData) {
                super.setFileMessageTypeData(fileMessageTypeData);
                this.g3DataType = (G3Msg_SingleTypeBatch)fileMessageTypeData;
        }
        
        
        //
        // BODebulkFile related
        //
        
        @Override
        public void onTransactionEnded(XmlTransactionReaderBase readerBase,FileIndexDataType txInfo) {
                txInfo.setPaymentType(g3DataType.getPaymentTypeName());
                this.lastTransactionEndInd = Integer.parseInt(Long.toString(txInfo.getTransactionEndTag()));

        }

        
        //
        // relation with native reader
        //
        
        private boolean hadTransactions = false;
        
        @Override
        public boolean hasNext() {
                try {
                        init();
                        if (!initialized){
                                return false;
                        }
                } catch (Exception e) {
                        throw new BulkFileParsingExecption(e);
                }
                if (nativeReader.getNumOfTrxActuallyReadFromFile() == 0){
                        setNewBulk(true);
                }else{
                        setNewBulk(false);
                }
                boolean hasNext = nativeReader.hasNext(); 
                if (hasNext){
                        hadTransactions = true;
                }else{
                        if (!hadTransactions){
                                hadTransactions = true;
                                this.lastTransactionEndInd = (int)getGlobalHeaderEndTagIndex();
                                return true;
                        }
                }
                this.setByteBuffer(nativeReader.getByteBuffer());
                this.setTotalDeleted(nativeReader.getTotalDeleted());
                this.setByteCount(nativeReader.getByteCount());
                if (listener != null && hasNext){
                        listener.onTransactionEnded(this, null);
                }
                return hasNext;
        }
        
        @Override
        public Object next() {
                return nativeReader.next();                                             
        }
        
        @Override
        protected boolean readTransactionsOfChunkSize() {
                //this method wouldn't be read. hasNext is via native reader
                return false;
        }

        @Override
        public String getXmlofChunk(Object chunk) {
                return nativeReader.getXmlofChunk(chunk);
        }

        @Override
        public int getRecCountInChunk(Object chunk) {
                return nativeReader.getRecCountInChunk(chunk);
        }
        
        @Override
        public String getMsgId() {
                if (StringUtils.isEmpty(super.getMsgId()) && nativeReader != null)
                        return nativeReader.getMsgId();
                
                return super.getMsgId();
        }

        @Override
        public int getPmtInfCount() {
                if (super.getPmtInfCount() == 0 && nativeReader != null)
                        return nativeReader.getPmtInfCount();
                
                return super.getPmtInfCount();
        }

        @Override
        public int getTrnsCount() {             
                if (super.getTrnsCount() == 0 && nativeReader != null)
                        return nativeReader.getTrnsCount();
                
                return super.getTrnsCount();
        }

        @Override
        public String getCtrlSum() {
                if (StringUtils.isEmpty(super.getCtrlSum()) && nativeReader != null)
                        return nativeReader.getCtrlSum();
                
                return super.getCtrlSum();
        }

        @Override
        public String getPartyName() {
                if (StringUtils.isEmpty(super.getPartyName()) && nativeReader != null)
                        return nativeReader.getPartyName();
                
                return super.getPartyName();
        }

        @Override
        public String getInitiatingPartyCustCode() {
                if (StringUtils.isEmpty(super.getInitiatingPartyCustCode()) && nativeReader != null)
                        return nativeReader.getInitiatingPartyCustCode();
                
                return super.getInitiatingPartyCustCode();
        }

        @Override
        public List<PDO> getPDOsFromChunk(PerformDebulkingMultiRequestDocument doc,
                        String chunkId, String sInternalFileID, FileSummary fileSummary,
                        Map[] arrMapSharedPDOContextHolder, boolean bShouldLogInfo)
                        throws Throwable {
                // TODO Auto-generated method stub
                return null;
        }

        @Override
        public void init(InputStream inputStream) throws Exception {
                // TODO Auto-generated method stub
                
        }

        @Override
        public void onBulkEnd(long FndtBatchTagLastIndex,
                        long transactionEndTagIndex,long newTxStartIndex) {
        }

        @Override
        public boolean isBulkEnd() {
                if(listener!=null)
                        return listener.isBulkEnd();
                return false;
        }

        @Override
        public long getBatchIndexOffset() {
                // TODO Auto-generated method stub
                return 0;
        }

        @Override
        public void markBulkFullReject() {
                // TODO Auto-generated method stub
                
        }

}