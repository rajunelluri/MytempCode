package backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi;

import static backend.core.module.MessageConstantsInterface.MESSAGE_TYPE_PAIN_001;
import static backend.core.module.MessageConstantsInterface.MESSAGE_TYPE_PAIN_008;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.xml.stream.XMLStreamException;

import org.apache.cxf.common.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi.FndtMultiBatchMessageStreamBasedParser.FndtMultiBatchMsgParseResult;

import com.fundtech.cache.entities.FileSummary;
import com.fundtech.cache.entities.InterfaceTypes;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.scl.debulkingProcessService.FileIndexDataType;
import com.fundtech.scl.debulkingProcessService.PerformDebulkingMultiRequestDocument;
import com.fundtech.util.GlobalConstants;

public class FndtBatchMsg_MultiTypeBatch_TransactionReader  extends MultiXmlTransactionReader implements XmlTransactionReaderListener {
	private static final Logger logger = LoggerFactory.getLogger(FndtBatchMsg_MultiTypeBatch_TransactionReader.class);
	
	private FndtBatchMsg_MultiTypeBatch fndtMultiBatchDataType; //to avoid casting	
	private XmlTransactionReaderBase nativeReader;

	private boolean initialized;
	
	private String rcvgInst;
	private String sndBic;
	private String sndgDn;
	private String sndgNm;
	private String rcvgDn;
	private String rcvgNm;
	
	private String initParty;
	private String pDate;
//	private int numCTBlk;
//	private int numDDBlk;
	private int numVCRBlk;
	private int numRFRBlk;
	private int numREJBlk;
	private int fundInd;

	private long bulkLastIndex;

	private long transactionLastIndex;

	private String fileOpeningTag;
	
	public static final String FNDT_MSG_START = "<FndtMsg xmlns=\"http://fundtech.com/SCL/CommonTypes\"><Msg>";
	public static final String FNDT_MSG_PMNT_START = "<Pmnt>";
	public static final String FNDT_MSG_PMNT_END = "</Pmnt>";
	public static final String FNDT_MSG_END = "</Msg></FndtMsg>";
	
	private boolean endOfBulk=false;

	public FndtBatchMsg_MultiTypeBatch_TransactionReader() {
	}
	
	public FndtBatchMsg_MultiTypeBatch_TransactionReader(FndtBatchMsg_MultiTypeBatch fileDataType) {
		setFileMessageTypeData(fileDataType);
	}
	
	public FndtBatchMsg_MultiTypeBatch_TransactionReader(File file,int chunkSize,FileMessageTypeData fileMessageTypeData) {
		super(file,chunkSize,fileMessageTypeData);
	}

	public FndtBatchMsg_MultiTypeBatch_TransactionReader(File file, int chunkSize,FileMessageTypeData fileMessageTypeData, String fileType) {
		this.setFile(file);
		this.setChunkSize(chunkSize);

		try {
			setRandomeFile(new RandomAccessFile(file, "r"));
			setFileSize(getRandomeFile().length()) ;
		} catch (Exception e) {
			logger.error("Problem loading file "+file.getName()+e.getMessage());
		}
		setUtils(new RandomAccessFileUtils(getFile()));
		setCurrentChunk(PerformDebulkingMultiRequestDocument.Factory.newInstance());
		getCurrentChunk().addNewPerformDebulkingMultiRequest();
		setFileMessageTypeData(fileMessageTypeData);
		setByteBuffer(new ByteArrayListOptimized());
		setSize(getFileSize() - getByteCount() > BUFFER_SIZE ? BUFFER_SIZE : getFileSize() - getByteCount());
		setByteCount(getByteCount() + getSize());
		getUtils().readToByteArrayListEnd(getByteBuffer(), (int)getSize());
		readDocumentStartData();
		readPreTransactionData();
		setCompiledPattern();
		try {
			init();
		} catch (Exception e) {
			logger.error("",e);
		}
	}
	
	@Override
	public void init()  throws IOException,XMLStreamException {
		init(null);
	}
		
	@Override
	public void init(InputStream inputStream)  throws IOException,XMLStreamException {
		if (initialized){
			try {
				if(inputStream!=null){ //for parsing bulks 2nd and higher
					parseFileHead(inputStream);
					nativeReader.init(inputStream);
				}else{//for parsing the first bulkin the file
					nativeReader.init();
				}
			} catch (Exception e) {
				logger.error(e.getMessage(), e) ;
			}
			return;
		}
		initialized = true;
		parseFileHead();
		this.setNewBulk(true);
		configureNativeReader();
		INTERFACE_TYPE = InterfaceTypes.INTERFACE_TYPE_MASSPMNTS;
		INTERFACE_SUB_TYPE = InterfaceTypes.INTERFACE_SUB_TYPE_DEB;
		setSinglePayment(false);
	}

	/**
	 * basic parsing from the file head.
	 */
	private void parseFileHead() throws IOException,XMLStreamException {
		parseFileHead(null);
	}
		
	private void parseFileHead(InputStream inputStream) throws IOException,XMLStreamException {
		FileInputStream fileInputStream = null;
		FndtMultiBatchMessageStreamBasedParser parser=null;
		FndtMultiBatchMsgParseResult result=null;
		try{
			if (inputStream==null) {
				fileInputStream = new FileInputStream(getFile());
				parser = new FndtMultiBatchMessageStreamBasedParser(fileInputStream);//original file
				result = parser.parseHead();
				this.setSendingInst(result.getSndgInst());
				this.setReceivingInst(result.getRcvgInst());
				this.setSenderName(result.getSndgNm());
				this.setFileReference(result.getFileRef());
				this.setFileSource(result.getfSrc());
				this.setM_fileType(result.getfType());
				DateFormat formatter = new SimpleDateFormat("yyyy-mm-dd");
				try {
					this.setFileDtTm((Date)formatter.parse(result.getfDtTm()));
					this.setNumCTBlk(Integer.parseInt(result.getNumCTBlk()));
					this.setNumDDBlk(Integer.parseInt(result.getNumDDBlk()));
				} catch (ParseException e) {
					logger.warn("Failed to retrieve file header properties.");
				}
				
			}else{
				parser = new FndtMultiBatchMessageStreamBasedParser(inputStream);//trimmed file without processed bulks
				result = parser.parseHead();
			}
			extractFileOpeningTag(result.getDocumentStartTagLocation(),result.getFndtPrtryAppHdrStartTagLocation());
		}finally{// close fileInputStream
			try
			{
				if (fileInputStream !=null) fileInputStream.close();
			}catch(Exception e){
        		logger.error("Exception - could not close FileInputStream-fileInputStream at FndtBatchMsg_MultiTypeBatch_TransactionReader.parseFileHead");
			}
			
		}
	}

	/** 
	 * extracts the file opening tag, so it can be attached to later bulks xml outtakes from file
	 * @param documentStartTagLocation
	 * @param secondTagStart
	 */
	private void extractFileOpeningTag(long documentStartTagLocation,long secondTagStart) {
		if (StringUtils.isEmpty(getFileOpeningTag())) {
			setFileOpeningTag(getUtils().getFileSectionFromIndexes(
					documentStartTagLocation, secondTagStart));
		}		
	}

	private void setFileOpeningTag(String fileOpeningTag) {
		this.fileOpeningTag=fileOpeningTag;
	}
	
	public String getFileOpeningTag() {
		return fileOpeningTag;
	}

	private void configureNativeReader() {		
		try {
			FndtBatchMsg_SingleTypeBatch fndtBatchMsg_SingleTypeBatch=new FndtBatchMsg_SingleTypeBatch();
			nativeReader = fndtBatchMsg_SingleTypeBatch.getReader(getFile(),getChunkSize());
			nativeReader.setListener(this);
		} catch (Exception e) {
			logger.error("configureNativeReader failed",e);
		}		
	}

	@Override
	public void setFileMessageTypeData(FileMessageTypeData fileMessageTypeData) {
		super.setFileMessageTypeData(fileMessageTypeData);
		this.fndtMultiBatchDataType = (FndtBatchMsg_MultiTypeBatch)fileMessageTypeData;
	}
	
	//
	// BODebulkFile related
	//
	
	@Override
	public void onTransactionEnded(XmlTransactionReaderBase readerBase,FileIndexDataType txInfo) {
	}
	
	public void onBulkEnd(long fndtBatchTagLastIndex,long transactionEndTagIndex,long newTxStartIndex){
		if(bulkLastIndex==0 || fndtBatchTagLastIndex==-1 || bulkLastIndex<fndtBatchTagLastIndex)
			setBulkLastIndex(fndtBatchTagLastIndex);
		if(transactionLastIndex<transactionEndTagIndex)
			setTransactionLastIndex(transactionEndTagIndex);
		if(getBulkLastIndex()<newTxStartIndex && getBulkLastIndex()!=-1)
			endOfBulk=true;
	}
	
	//
	// BODebulkProcessing related
	//
	
	public long getBulkLastIndex() {
		return bulkLastIndex;
	}

	public void setBulkLastIndex(long bulkLastIndex) {
		this.bulkLastIndex = bulkLastIndex;
	}

	public long getTransactionLastIndex() {
		return transactionLastIndex;
	}

	public void setTransactionLastIndex(long transactionLastInde) {
		this.transactionLastIndex = transactionLastInde;
	}

	
	//
	// relation with native reader
	//
	
	@Override
	public boolean hasNext() {
		try {
			init();
		} catch (Exception e) {
			throw new BulkFileParsingExecption(e);
		}
		
		boolean hasNext=nativeReader.hasNext();
		if (!hasNext) {//If current bulk ended. Look for chunk in a new bulk
			calcBulks();
			if(getBulkLastIndex()==-1)// reached EOF
				return false;
			
			String remainingFile = getUtils().getFileSectionFromIndexes(
					getBulkLastIndex(), getFileSize());//create inputStream from new bulk
			
			try {
				String newBulkString = getFileOpeningTag() + remainingFile;
				((FndtBatchMsg_SingleTypeBatch_TransactionReader) nativeReader)
						.setBatchIndexOffset(getBulkLastIndex()-getFileOpeningTag().getBytes().length);
				setBulkLastIndex(0);
				this.endOfBulk=false;
				init(new ByteArrayInputStream(
						newBulkString.getBytes("UTF-8")));
				hasNext = nativeReader.hasNext();
			} catch (Exception e) {
				logger.error("Failed to get chunk from bulk. "+e.getMessage());
			}
		}
		setNewBulk(nativeReader.isNewBulk());
		return hasNext;
	}
	
	private void calcBulks(){
		String msgType = ((FndtBatchMsg_SingleTypeBatch_TransactionReader)nativeReader).getBulkType();
		if (msgType.equals(MESSAGE_TYPE_PAIN_008)){
			setCalcNumDDBlk(getCalcNumDDBlk() + 1);
		}
		if (msgType.equals(MESSAGE_TYPE_PAIN_001)){
			setCalcNumCTBlk(getCalcNumCTBlk() + 1);
		}
	}
	
	@Override
	public List<PDO> getPDOsFromChunk( PerformDebulkingMultiRequestDocument doc
			  ,String chunkId
			  ,String internalFileID
			  ,final FileSummary fileSummary
			  ,final Map[] sharedPDOContextHolder) throws Throwable {
		return this.nativeReader.getPDOsFromChunk(doc, chunkId, internalFileID, fileSummary, sharedPDOContextHolder);
	}
	
	@Override
	public Object next() {
		return nativeReader.next();						
	}
	
	@Override
	public String getXmlofChunk(Object chunk) {
		return nativeReader.getXmlofChunk(chunk);
	}

	@Override
	public int getRecCountInChunk(Object chunk) {
		return nativeReader.getRecCountInChunk(chunk);
	}
	
	@Override
	public String getMsgId() {
		if (StringUtils.isEmpty(super.getMsgId()) && nativeReader != null)
			return nativeReader.getMsgId();
		
		return super.getMsgId();
	}

	@Override
	public int getPmtInfCount() {
		if (super.getPmtInfCount() == 0 && nativeReader != null)
			return nativeReader.getPmtInfCount();
		
		return super.getPmtInfCount();
	}

	@Override
	public int getTrnsCount() {		
		if (super.getTrnsCount() == 0 && nativeReader != null)
			return nativeReader.getTrnsCount();
		
		return super.getTrnsCount();
	}

	@Override
	public String getCtrlSum() {
		if (StringUtils.isEmpty(super.getCtrlSum()) && nativeReader != null)
			return nativeReader.getCtrlSum();
		
		return super.getCtrlSum();
	}

	@Override
	public String getPartyName() {
		if (StringUtils.isEmpty(super.getPartyName()) && nativeReader != null)
			return nativeReader.getPartyName();
		
		return super.getPartyName();
	}

	@Override
	public String getInitiatingPartyCustCode() {
		if (StringUtils.isEmpty(super.getInitiatingPartyCustCode()) && nativeReader != null)
			return nativeReader.getInitiatingPartyCustCode();
		
		return super.getInitiatingPartyCustCode();
	}

	public String getRcvgInst() {
		return rcvgInst;
	}

	public void setRcvgInst(String receivingBic) {
		this.rcvgInst = receivingBic;
	}

	public String getSndBic() {
		return sndBic;
	}

	public void setSndBic(String sndBic) {
		this.sndBic = sndBic;
	}

	public String getSndgDn() {
		return sndgDn;
	}

	public void setSndgDn(String sndgDn) {
		this.sndgDn = sndgDn;
	}

	public String getSndgNm() {
		return sndgNm;
	}

	public void setSndgNm(String sndgNm) {
		this.sndgNm = sndgNm;
	}

	public String getRcvgDn() {
		return rcvgDn;
	}

	public void setRcvgDn(String rcvgDn) {
		this.rcvgDn = rcvgDn;
	}

	public String getRcvgNm() {
		return rcvgNm;
	}

	public void setRcvgNm(String rcvgNm) {
		this.rcvgNm = rcvgNm;
	}

	public String getpDate() {
		return pDate;
	}

	public void setpDate(String pDate) {
		this.pDate = pDate;
	}

	public int getNumVCRBlk() {
		return numVCRBlk;
	}

	public void setNumVCRBlk(int numVCRBlk) {
		this.numVCRBlk = numVCRBlk;
	}

	public int getNumRFRBlk() {
		return numRFRBlk;
	}

	public void setNumRFRBlk(int numRFRBlk) {
		this.numRFRBlk = numRFRBlk;
	}

	public int getNumREJBlk() {
		return numREJBlk;
	}

	public void setNumREJBlk(int numREJBlk) {
		this.numREJBlk = numREJBlk;
	}

	public int getFundInd() {
		return fundInd;
	}

	public void setFundInd(int fundInd) {
		this.fundInd = fundInd;
	}

	public String getInitParty() {
		return initParty;
	}

	public void setInitParty(String initParty) {
		this.initParty = initParty;
	}	
	@Override
	public long getBulkNumOfTx(){
		return nativeReader.getBulkNumOfTx();
	}
	@Override
	public long getBulkCtrlSum(){
		return nativeReader.getBulkCtrlSum();
	}
	@Override
	public  BigDecimal getBulkTotalAmt(){
		return nativeReader.getBulkTotalAmt();
	}
	
	@Override
	public String getFileType() {
		return GlobalConstants.BPFILE;
	}

	@Override
	public boolean isBulkEnd() {
		return endOfBulk;
	}

	@Override
	public void markBulkFullReject() {
		// TODO Auto-generated method stub
		
	}

}