package backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.namespace.QName;
import javax.xml.stream.XMLStreamException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.cache.entities.Customrs;
import com.fundtech.cache.entities.InterfaceTypes;
import com.fundtech.cache.entities.SwiftId;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.paymentprocess.data.paymenttypes.PaymentType;
import com.fundtech.scl.debulkingProcessService.FileIndexDataType;
import com.fundtech.scl.debulkingProcessService.PerformDebulkingMultiRequestDocument;
import com.fundtech.scl.debulkingProcessService.PerformDebulkingMultiRequestType;
import com.fundtech.scl.debulkingProcessService.PreStartDataType;
import com.fundtech.util.ExceptionController;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalUtils;

/**
 * XmlTransactionReader for multi message types.
 * It will read and index the transactions for multi message types.
 *
 * @see XmlTransactionReader
 *
 * @author haimv
 * @author dmitryp
 */
public class MultiXmlTransactionReader extends XmlTransactionReader{

	private static final int MINUMUM_CHARS_FOR_TRANSACTION = 150;
	private ArrayList<FileIndexDataType> listFileIndexDataType = null;
	private ArrayList<PreStartDataType>  listPreStartDataType= null;
	protected XmlTransactionReader currReader = null;
	private static final Logger logger = LoggerFactory.getLogger(MultiXmlTransactionReader.class);
//	private RandomAccessFileUtils utils = null;
	
	public MultiXmlTransactionReader()
	{
		listFileIndexDataType = new ArrayList<FileIndexDataType>();
		listPreStartDataType = new ArrayList<PreStartDataType>();
	}
	public MultiXmlTransactionReader(File file, int chunkSize,FileMessageTypeData fileMessageTypeData) {
		super(file,chunkSize,fileMessageTypeData);
//		utils = new RandomAccessFileUtils(m_file);
//		m_utils = new RandomAccessFileUtils(m_file);
		listFileIndexDataType = new ArrayList<FileIndexDataType>();
		listPreStartDataType = new ArrayList<PreStartDataType>();
		readTillNextPaymentTypeAndChangeReader();
		getHeaderPropertiesFromCurrentReader();
	}



	/**
	 * This method is for reading and indexing the transactions header,start and end tags for multi message type.
	 * It will store the indexes in the input fileIndexData.
	 *
	 * @see backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi.XmlTransactionReader#readTransactions(java.util.List, backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi.FileMessageTypeData, java.nio.channels.FileChannel, java.lang.StringBuilder, int, java.nio.MappedByteBuffer, int, byte[], long, long, int, int)
	 */

	public int getRecCountInChunk (Object chunk)
	{
		PerformDebulkingMultiRequestDocument doc = (PerformDebulkingMultiRequestDocument)chunk;
		PerformDebulkingMultiRequestType debulkingMultyRequest = doc.getPerformDebulkingMultiRequest();
		return debulkingMultyRequest.getFileIndexDataTypeListArray().length;
	}

 	@Override
 	public String getXmlofChunk(Object chunk)
	{
		PerformDebulkingMultiRequestDocument doc = (PerformDebulkingMultiRequestDocument)chunk;
		return doc.xmlText();
	}




	@Override
	public void remove() {
		//TODO Auto-generated method stub

	}


	@Override
	public void init() throws IOException, XMLStreamException
	{
		INTERFACE_TYPE = InterfaceTypes.INTERFACE_TYPE_MASSPMNTS;
		INTERFACE_SUB_TYPE = InterfaceTypes.INTERFACE_SUB_TYPE_DEB;
		setSinglePayment(false);

        initHeader();

	}//EOM init()

	public void setAdditionalDocumentData(Object request, String chunkId, String status, String internalFileId, String path, String workFlow, String bulkId)
	{

		PerformDebulkingMultiRequestDocument doc = (PerformDebulkingMultiRequestDocument)request;
		PerformDebulkingMultiRequestType req = doc.getPerformDebulkingMultiRequest();
		req.setChunkId(chunkId);
		req.setStatus(status);
		req.setInternalFileId(internalFileId);
		req.setPath(path);
		req.setWorkflow(workFlow);
		req.setBulkId(bulkId);
	}

	@Override
	public void initHeader ()
	{
		Pattern sndtPattern = Pattern.compile(":SndgInst>(.*)</");
	    Pattern receiverPattern = Pattern.compile(":RcvgInst>(.*)</");
		
		String headerEndTag = this.getFileMessageTypeData().getGrpHdrEndTag();
		int index= this.getByteBuffer().indexOf(headerEndTag.getBytes());
		byte[] arr = this.getFileMessageTypeData().getGrpHdrEndTag().getBytes();

		
		String header =  new String(Arrays.copyOfRange(this.getByteBuffer().getArray(),0,(index +arr.length)));

		Matcher m = receiverPattern.matcher(header);
		String receivingBic = null;
		String sndBic = null;
		while (m.find())
        {
        	if (m.group(1) != null) {
        		receivingBic = m.group(1) + "XXX" ;
        	}
        }
		
		m = sndtPattern.matcher(header);
		while (m.find())
        {
        	if (m.group(1) != null) {
        		sndBic = m.group(1) + "XXX" ;
        	}
        }
		
		setInitiatingPartyCustCode(getSenderReceivingCustCode(receivingBic, sndBic));
		setSendingInst(sndBic);
		setCtrlSum(GlobalConstants.MINUS_ONE_STRING);
		this.getByteBuffer().removeRange(0, index +arr.length);
		this.setTotalDeleted(this.getTotalDeleted() + (index +arr.length));
	}


	// member to store the current FileMessageTypeData in the file.
	FileMessageTypeData currTransactionsMsgDataType = null;
	byte[] paymentsGrpHdrEnd = null;
	int currSGrpHdrEndTagInChunkIndex = -1;
	byte[] paymentsGrpHdrStart = null;
	byte[] tagClosure = new String(">").getBytes();
	byte[] tagEquals = new String("=").getBytes();
	byte[] tagDots = new String(":").getBytes();
	int currSGrpHdrTagStartInChunkIndex = -1;

	byte[] paymentsType = new String("xmlns").getBytes();

	long currSGrpHdrStartTagIndex = -1;
	long currSGrpHdrEndTagIndex = -1;
	int currEndXmlNs = -1;
	int currEqualsInd = -1;
	int currDotsInd = -1;
	String currXmlScheme = "";
	private boolean shouldChangeReader;
	
	/**
	 * the method gets an index in which a new payment type scheme should be initiated
	 * ,finds the correct scheme and initiate it.
	 * returns an indication if this is the first reader of the file
	 * @param index
	 */
	boolean  changePaymentType(int index) {

		try {
		// find the nearest GrpHdr start tag index.
			boolean isFirst= false;
			if (getNewSchemeIndex() != -1 ) {
				setCurrentSchemaToCurrTrnMsgType(getNewSchemeIndex() , getNewSchemeIndexEnd());
				 isFirst = false;
				}else {
					
					int startSchema = getByteBuffer().indexOf(GlobalConstants.LESS_THEN.getBytes());
					
					int endSchema =  getByteBuffer().indexOf(GlobalConstants.GREATER_THEN.getBytes());
					setDocPreStartTagIndex(getTotalDeleted()  + startSchema);
					setDocPreEndTagIndex(getTotalDeleted()  + endSchema);
					// we retrieve the schema tag <schema xmlns="....."> using absolute indexes in the file 
					setCurrentSchemaToCurrTrnMsgType(getTotalDeleted()  + startSchema ,getTotalDeleted()  + endSchema  + GlobalConstants.GREATER_THEN.length());
					getByteBuffer().removeRangeFromBeginning(endSchema);
					setTotalDeleted(getDocPreEndTagIndex());
					isFirst = true;
				
				}
			return isFirst;
		}
		catch (Exception e)
		{
			logger.error(e.getMessage());
			return false;
		}
						


	}
	/**
	 * 
	 * @param index1 start schema tag index
	 * @param index2 end schema tag index <XXXX xmlns="....">
	 * This method retrieves  the schema ( <XXXX xmlns="....">) tag from the input file, 
	 * finds the namespace and updates the currTransactionsMsgDataType
	 */
	protected void setCurrentSchemaToCurrTrnMsgType(long index1 , long index2 ) {
		String nameSpace;
		String newSchemaText =  getUtils().getFileSectionFromIndexes(index1, index2);
		String[] results = newSchemaText.split(GlobalConstants.QUOTE);
		nameSpace = results[1];
		QName qname= new QName(nameSpace, "Document");

		currTransactionsMsgDataType = (FileMessageTypeData)PaymentType.valueOf(qname).getTrnsReaderNewInstance();

		currTransactionsMsgDataType.formatTags(currXmlScheme);
	}

	/**
	 *reads transactions until number of transaction per chunk is achieved or until end of file is reached.
	 */
	@Override
	protected boolean readTransactionsOfChunkSize()
	{
		//till the end of file or until the current transactions chunk is full
		// TODO make the condition dynamic and simpler. 
		while (fileContainsMoreTransactions()  &&  !this.shouldChangeReader())
		{
			try {

				if (currReader != null && currReader.hasNext() ) {
					setByteCount(currReader.getByteCount());
					setTotalDeleted(currReader.getTotalDeleted());
					return true;
				} else {
					setByteCount(currReader.getByteCount());
					setTotalDeleted(currReader.getTotalDeleted());
					setNewSchemeIndex(currReader.getNewSchemeIndex());
					setNewSchemeIndexEnd(currReader.getNewSchemeIndexEnd());
					setDocPreStartTagIndex(currReader.getDocPreStartTagIndex());
					this.setCurrentChunk(currReader.getCurrentChunk());
					this.setNumOfTrxActuallyReadFromFile(currReader.getNumOfTrxActuallyReadFromFile());
					if (!currReader.headerContainsNumberOfTransactions()) {
						this.setTrnsCount(this.getTrnsCount() + currReader.getNumOfTrxActuallyReadFromFile());
					}
					this.setShouldChangeReader(true);
					return true;	
				}

			}
			catch (Exception e)
			{
				logger.error(e.getMessage());
				ExceptionController.getInstance().handleException(e, this);
				throw new RuntimeException("Problem reading " + getByteCount() + " chunk");
			}
		}
		return false;
	}
	
	
	private boolean fileContainsMoreTransactions() {
		return (((getByteCount() < getFileSize()) || (getFileSize() - getTotalDeleted() > MINUMUM_CHARS_FOR_TRANSACTION)) )
				&& listFileIndexDataType.size() < getChunkSize();
	}

	
	private void getHeaderPropertiesFromCurrentReader() {
		this.setMsgId(currReader.getMsgId());
		//this.setTrnsCount(getTrnsCount() +  currReader.getTrnsCount());
		if (GlobalUtils.isNullOrEmpty(this.getCtrlSum()))
			this.setCtrlSum(currReader.getCtrlSum());
		this.setPartyName(currReader.getPartyName());
		if (GlobalUtils.isNullOrEmpty(this.getInitiatingPartyCustCode()))
			this.setInitiatingPartyCustCode(currReader.getInitiatingPartyCustCode());
	}

	public void readTillNextPaymentTypeAndChangeReader() {

		if (!this.fileContainsMoreTransactions()){
			return;
		}
		
		try {
		// look for the first appearing tag from the start
		// transaction tag list
		
		XmlTransactionReader readerForStateTransffer =  (currReader == null ? this : currReader);
		this.setByteBuffer(readerForStateTransffer.getByteBuffer());	
		int temp  = -1;
	    if (!(getNewSchemeIndex() != -1) ){
		temp = this.findAndReadTillNearestTagInChunk(paymentsType, 0);
		}
		// if new scheme indicating tag found, change the scheme
		boolean isFirst =  this.changePaymentType(temp);
	
		long tempTotalDeleted = readerForStateTransffer.getTotalDeleted();
		XmlTransactionReader currReaderNew = this.getReaderForMessageType(currTransactionsMsgDataType
				.getTypeIdentifier());
		
		String grpHdrEndTag =  currReaderNew.getFileMessageTypeData().getGrpHdrEndTag();
		
		
		super.headerContainsNumberOfTransactions = currReaderNew.headerContainsNumberOfTransactions();
		// set the reader with the current reader state so the read will
		// continue from
		// the needed position
		
		//XmlTransactionReader readerForStateTransffer =  (currReader == null ? this : currReader);
		currReaderNew.setFileMessageTypeData(currTransactionsMsgDataType);
		currReaderNew.setTotalDeleted(readerForStateTransffer.getTotalDeleted());
		currReaderNew.setFileSize(readerForStateTransffer.getFileSize());
		currReaderNew.setByteCount(readerForStateTransffer.getByteCount());
		currReaderNew.setUtils(readerForStateTransffer.getUtils());
		currReaderNew.setIsFromMultiReader(true);
		// TODO investigate if this shortcut is good enough, perhaps change the pattern regex ?? 
		//currReaderNew.setMmlns(currXmlScheme);
		currReaderNew.setNamespacePrefix("");
		currReaderNew.setByteBuffer(readerForStateTransffer.getByteBuffer());
		currReaderNew.setCurrentChunk(PerformDebulkingMultiRequestDocument.Factory
				.newInstance());
		currReaderNew.getCurrentChunk().addNewPerformDebulkingMultiRequest();
		currReaderNew.readPreTransactionData();
		currReaderNew.readDocumentStartData();
		if (!isFirst) {
			currReaderNew.setDocPreStartTagIndex(getNewSchemeIndex() == -1 ? tempTotalDeleted : getNewSchemeIndex());
			currReaderNew.setDocPreEndTagIndex(getNewSchemeIndexEnd() == -1 ? tempTotalDeleted : getNewSchemeIndexEnd());
		}else {
			currReaderNew.setDocPreEndTagIndex(getDocPreEndTagIndex());
			currReaderNew.setDocPreStartTagIndex(getDocPreStartTagIndex());
		}
		((AbstractSingleInMuliSchemaReader)currReaderNew).findAndReadTillNearestTagInChunk( grpHdrEndTag.getBytes() , 0);
		currReaderNew.initMembers();
		currReaderNew.testMethod();
		readerForStateTransffer.setTrnsCount(readerForStateTransffer.getTrnsCount() + currReaderNew.getTrnsCount());
		this.currReader = currReaderNew;
		}
		catch (Exception e)
		{
				logger.error(e.getMessage());
				ExceptionController.getInstance().handleException(e, this);
				throw new RuntimeException("Problem reading " + getByteCount() + " chunk");
		}
	}


	protected XmlTransactionReader getReaderForMessageType(String msgType)
	{
		if (msgType.equals("urn:iso:std:iso:20022:tech:xsd:pacs.008.001.02"))
			return new PacsTransactionReader(getFile(), getRandomeFile(), getChunkSize(), currTransactionsMsgDataType);

		if (msgType.equals("urn:iso:std:iso:20022:tech:xsd:pacs.004.001.02"))
			return new PacsTransactionReader(getFile(), getRandomeFile(), getChunkSize(), currTransactionsMsgDataType);
		
		if (msgType.equals("urn:iso:std:iso:20022:tech:xsd:camt.029.001.03"))
			return new CamtTransactionReader(getFile(), getRandomeFile(), getChunkSize(), currTransactionsMsgDataType , false);
	
		if (msgType.equals("urn:iso:std:iso:20022:tech:xsd:camt.056.001.01"))
			return new CamtTransactionReader(getFile(), getRandomeFile(), getChunkSize(), currTransactionsMsgDataType , true);

		return null;
	}
	@Override
	protected void readPreTransactionData() {
		// TODO
	}


	@Override
	public boolean hasNext(){
		return readTransactionsOfChunkSize();

	}



	@Override
	public Object next() {
		Object ob = currReader.next();
		if (currReader.getNewSchemeIndex() != -1)
			currReader = null;
		return ob;
	}



	@Override
	protected void readDocumentStartData() {
		// TODO

	}
	public static String getSenderReceivingCustCode(String rcvgInst, String sendInst){
		
		String custCode = null;
		
		if (!GlobalUtils.isNullOrEmpty(rcvgInst) && !GlobalUtils.isNullOrEmpty(sendInst)){
			SwiftId swiftId = CacheKeys.swiftIdPerSwiftIdKey.getSingle(rcvgInst);
			if (swiftId != null){
				String office = swiftId.getOffice();
				Customrs cust = CacheKeys.customrsBICandOfficeKey.getSingle(sendInst,office);
				if (cust != null){
					custCode = cust.getCustCode();
				}
			}
		}		
		return custCode;
	}
	
	
	
	public void setShouldChangeReader(boolean changeReader) {
		this.shouldChangeReader = changeReader;
	}

	public boolean shouldChangeReader(){
		return this.shouldChangeReader;
	}
	@Override
	public void init(InputStream inputStream) throws Exception {
		// TODO Auto-generated method stub
		
	}
	@Override
	public long getBatchIndexOffset() {
		// TODO Auto-generated method stub
		return 0;
	}
	
}//MultiXmlTransactionReader