package backend.paymentprocess.debulkingprocess.parsing.xml.processing;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import net.sourceforge.wife.services.ConversionService;
import net.sourceforge.wife.services.IConversionService;
import net.sourceforge.wife.swift.model.SwiftBlock1;
import net.sourceforge.wife.swift.model.SwiftBlock2;
import net.sourceforge.wife.swift.model.SwiftBlock2Output;
import net.sourceforge.wife.swift.model.SwiftBlock3;
import net.sourceforge.wife.swift.model.SwiftBlock4;
import net.sourceforge.wife.swift.model.SwiftMessage;
import net.sourceforge.wife.swift.model.Tag;
import net.sourceforge.wife.swift.parser.SwiftParser;

import org.apache.commons.lang.StringUtils;

import backend.paymentprocess.debulkingprocess.common.WorkflowType;

import com.fundtech.cache.entities.Banks;
import com.fundtech.cache.entities.Customrs;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.security.Admin;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.SwiftParserUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TransactionReaderSwift  extends TransactionReader  {

	private static final Logger logger = LoggerFactory.getLogger(TransactionReaderSwift.class);

	private SwiftMessage swiftIncomingMsg;
	private SwiftBlock1 incomingSwiftBlock1;
	private SwiftBlock2 incomingSwiftBlock2;
	private SwiftBlock3 incomingSwiftBlock3;
	private SwiftBlock4 incomingSwiftBlock4;

	private String origMT;
	private boolean is101;
	private boolean is102;
	private boolean is203;
	private boolean is201;

	private int numberOfPayments;



	private Map<String, List<Tag>> seqA;
	private List<Map<String, List<Tag>>> seqB;
	private Map<String, List<Tag>> seqC;
	private IConversionService srv;
	private Iterator<Map<String, List<Tag>>> seqBIterator;
	//private transient final GlobalTracer logger;

	public TransactionReaderSwift(File file) throws IOException
	{
		super();
		//logger = Admin.m_contextTracer.get();
		m_randomeFile = new RandomAccessFile(file, "r");
		byte[] byteArr = new byte[(int)file.length()];
		m_randomeFile.read(byteArr);

		String message = new String(byteArr);
		m_randomeFile.close();

		init(message);
		init();
		this.seqBIterator = this.seqB.iterator();

		m_inMsgContext = "INCOMING_SWIFT";
	}

	public TransactionReaderSwift(String message) throws IOException
	{
		super();
		//logger = Admin.m_contextTracer.get();
		m_input = message;
		init(message);			
		init();
		this.seqBIterator = this.seqB.iterator();
		m_inMsgContext = "INCOMING_SWIFT";
	}


	@Override
	public void init(String message) throws IOException {
		this.swiftIncomingMsg = (new SwiftParser(message)).message();
		

		this.incomingSwiftBlock1 = swiftIncomingMsg.getBlock1();
		this.incomingSwiftBlock2 = swiftIncomingMsg.getBlock2();
		this.incomingSwiftBlock3 = swiftIncomingMsg.getBlock3();
		this.incomingSwiftBlock4 = swiftIncomingMsg.getBlock4();
		m_fileName = this.incomingSwiftBlock2.getBlockValue();
		this.origMT = this.incomingSwiftBlock2.getMessageType();
		is102 = "102".equals(this.origMT);
		is101 = "101".equals(this.origMT);
		is203 = "203".equals(this.origMT);
		is201 = "201".equals(this.origMT);
		this.m_msgType = "SWIFT_" + this.origMT;

		if ((is101 || is102 || is203 || is201) && incomingSwiftBlock4.getTagByName("20") != null) m_msgId = incomingSwiftBlock4.getTagByName("20").getValue();


		String senderBic = ((SwiftBlock2Output) this.incomingSwiftBlock2).getMIRLogicalTerminal();
		//A is a swift identifier character and not part of the BIC so needs to be removed from position 9


		if (! (is101 || is102 || is203 || is201)) m_stringBuffer = new StringBuilder(message);
		
		if (is203 || is201) {
			this.numberOfPayments = this.swiftIncomingMsg.getBlock4().getTagCount("20");
		} else if (is101 || is102) {
			this.numberOfPayments = this.swiftIncomingMsg.getBlock4().getTagCount("21");
		}

		this.seqA = new LinkedHashMap<String, List<Tag>>();
		this.seqB = new ArrayList<Map<String, List<Tag>>>();
		this.seqC = new LinkedHashMap<String, List<Tag>>();	
		this.srv = new ConversionService();


		String receiverBic = StringUtils.substring(this.incomingSwiftBlock1.getLogicalTerminal(),0,8) + StringUtils.substring(this.incomingSwiftBlock1.getLogicalTerminal(),9);


		String sLookupSwiftID = receiverBic.substring(0, 8) + "XXX";
		Banks banks = CacheKeys.banksPerSwiftIDKey.getSingle(sLookupSwiftID);

		if(banks != null) m_office = banks.getOffice();
		else m_office = GlobalConstants.DEFAULT_SERVER_OFFICE_NAME;


		senderBic = StringUtils.substring(senderBic,0,8) + StringUtils.substring(senderBic,9);
		Customrs cust = CacheKeys.customrsBICandOfficeKey.getSingle(senderBic, m_office);

		if (cust != null ) m_initiatingPartyCustCode = cust.getCustCode(); 
		
		setWorkflow(WorkflowType.SWIFT.name());

	}	



	@Override
	public String getHeader() {
		return "";
	}

	@Override
	public String getCurrentPmtInfHeader() {
		return "";
	}

	@Override
	public int getNumOfTxs() {
		return numberOfPayments;
	}	

	@Override
	public String getCtrlSum(){
		
//		Number setteledAmount = new BigDecimal (0);   
//		String amount = null;
//		if (is102) {
//			//should return 32 from block C
//			String tag32A = incomingSwiftBlock4.getTagValue("32A");
//			amount = StringUtils.substring(tag32A, 6);	
//			amount  = SwiftParserUtils.getNumericSuffix(amount);
//		} else if (is203 || is201) {
//			amount = incomingSwiftBlock4.getTagValue("19");
//		} else if (is101) {
//			amount = "-1";
//		} 
//
//		try
//		{
//			setteledAmount = SwiftParserUtils.getNumber(amount);
//		}
//		catch (ParseException e)
//		{
//			// TODO Auto-generated catch block
//			logger.error(e.getMessage());
//		}
//		return setteledAmount.toString();
		
		return "-1";
	}

	@Override
	public String getPartyName(){
		return "";
	}	


	@Override
	public int getPmtInfCount() {
		return -1;
	}

	@Override
	public int getTrnsCountInPmtInf() {
		return -1;
	}	

	@Override
	public boolean isSinglePayment(){
		return false;		
	}	

	@Override
	public void close() throws IOException {		
	}	

	@Override
	public int indexOfIgnoreWhiteSpaces(String text, String tag, String endTag) 
	{	int indx = -1;
	if (tag == null )
		indx= 0;
	else indx = text.indexOf(tag);

	return indx;

	}
	@Override
	public void init() {
		m_trnsStartTag="{";
		m_trnsEndTag="-}";
		m_chunkEnd = "-}";

		Iterator i = incomingSwiftBlock4.tagIterator();
		String seqInd = "A";
		Map<String, List<Tag>> singlePayment = null;
		while (i.hasNext()) {
			Tag tag = (Tag) i.next();        	
			// Seq transition
			if (((is101 || is102) && "A".equals(seqInd) && "21".equals(tag.getName()))
					|| ((is201 || is203) && "A".equals(seqInd) && "20".equals(tag.getName()))) {
				seqInd = "B";
			} else if (is102 && "B".equals(seqInd) && "32A".equals(tag.getName())) {
				seqInd = "C";
			}

			if ("A".equals(seqInd)) {
				List tags;
				if (seqA.containsKey(tag.getName())) {
					tags = seqA.get(tag.getName());        				
				} else {
					tags = new ArrayList<Tag>();
					seqA.put(tag.getName(), tags);
				}
				tags.add(tag);          			
			} else if ("B".equals(seqInd)) {        			
				if (((is101 || is102) && "21".equals(tag.getName()))
						|| ((is201 || is203) && "20".equals(tag.getName()))) {
					singlePayment = new LinkedHashMap<String, List<Tag>>();
					seqB.add(singlePayment);
				} 					
				if (singlePayment != null) {
					List tags;
					if (singlePayment.containsKey(tag.getName())) {
						tags = singlePayment.get(tag.getName());        				
					} else {
						tags = new ArrayList<Tag>();
						singlePayment.put(tag.getName(), tags);
					}
					tags.add(tag); 
				}					 
			} else if ("C".equals(seqInd)) {
				List tags;
				if (seqC.containsKey(tag.getName())) {
					tags = seqC.get(tag.getName());        				
				} else {
					tags = new ArrayList<Tag>();
					seqC.put(tag.getName(), tags);
				}
				tags.add(tag);        			
			} 
		}			
	}


	private SwiftBlock4 getSingleBlock4FromMT102(Map<String, List<Tag>> curSeqB) {
		SwiftBlock4 currentPaymentBlock4 = new SwiftBlock4();

		//Seq B 21 -> 20
		if (curSeqB.containsKey("21")) {
			currentPaymentBlock4.addTag(new Tag("20", curSeqB.get("21").get(0).getValue()));
		}
		//Seq C 13C -> 13C
		if (seqC.containsKey("13C")) {
			currentPaymentBlock4.addTags(seqC.get("13C"));        		
		}
		//Seq A 23 -> 23B Or 23E 
		if (seqA.containsKey("23")) {
			List<Tag> tags = seqA.get("23");
			Tag t23E = null;
			for (Tag tag : tags) {					
				if ("CHQB".equals(tag.getValue())) {
					t23E = new Tag("23E", tag.getValue());
				} else {
					currentPaymentBlock4.addTag(new Tag("23B", tag.getValue().substring(0, 4)));
				}					
			}
			if (t23E != null) {
				currentPaymentBlock4.addTag(t23E);
			}
		}

		//Seq A / B 26T -> 26T
		if (seqA.containsKey("26T")) {
			currentPaymentBlock4.addTag(seqA.get("26T").get(0));
		} else if (curSeqB.containsKey("26T")) {
			currentPaymentBlock4.addTag(curSeqB.get("26T").get(0));
		} 

		//Seq B 32B (currency + Amount), Seq C 32A (value date) -> 32A
		Tag t32A = new Tag();
		t32A.setName("32A");
		String val = seqC.get("32A").get(0).getValue().substring(0, 6);
		val +=  curSeqB.get("32B").get(0).getValue();
		t32A.setValue(val);
		currentPaymentBlock4.addTag(t32A);

		//Seq B  33B - > 33B
		if (curSeqB.containsKey("33B")) {
			currentPaymentBlock4.addTags(curSeqB.get("33B"));        		
		} 

		//Seq A / B 36 -> 36
		if (seqA.containsKey("36")) {
			currentPaymentBlock4.addTag(seqA.get("36").get(0));
		} else if (curSeqB.containsKey("36")) {
			currentPaymentBlock4.addTag(curSeqB.get("36").get(0));
		} 

		//Seq A / B 50a -> 50a
		if (seqA.containsKey("50A")) {
			currentPaymentBlock4.addTag(seqA.get("50A").get(0));
		} else if (curSeqB.containsKey("50A")) {
			currentPaymentBlock4.addTag(curSeqB.get("50A").get(0));
		} else if (seqA.containsKey("50F")) {
			currentPaymentBlock4.addTag(seqA.get("50F").get(0));
		} else if (curSeqB.containsKey("50F")) {
			currentPaymentBlock4.addTag(curSeqB.get("50F").get(0));
		} else if (seqA.containsKey("50K")) {
			currentPaymentBlock4.addTag(seqA.get("50K").get(0));
		} else if (curSeqB.containsKey("50K")) {
			currentPaymentBlock4.addTag(curSeqB.get("50K").get(0));
		} 

		//Seq A 51A -> 51A
		if (seqA.containsKey("51A")) {
			currentPaymentBlock4.addTag(seqA.get("51A").get(0));
		} 

		//Seq A / B 52a -> 52a
		if (seqA.containsKey("52A")) {
			currentPaymentBlock4.addTag(seqA.get("52A").get(0));
		} else if (curSeqB.containsKey("52A")) {
			currentPaymentBlock4.addTag(curSeqB.get("52A").get(0));
		} else if (seqA.containsKey("52D")) {
			currentPaymentBlock4.addTag(seqA.get("52D").get(0));
		} else if (curSeqB.containsKey("52D")) {
			currentPaymentBlock4.addTag(curSeqB.get("52D").get(0));
		} 

		//Seq C 53a -> 53a 
		if (seqC.containsKey("53A")) {
			currentPaymentBlock4.addTag(seqC.get("53A").get(0));
		} else if (seqC.containsKey("53C")) {
			currentPaymentBlock4.addTag(new Tag("53B", seqC.get("53C").get(0).getValue()));
		}

		//Seq C 54a -> 54a 
		if (seqC.containsKey("54A")) {
			currentPaymentBlock4.addTag(seqC.get("54A").get(0));
		} else if (seqC.containsKey("54B")) {
			currentPaymentBlock4.addTag(seqC.get("54B").get(0));
		} else if (seqC.containsKey("54D")) {
			currentPaymentBlock4.addTag(seqC.get("54D").get(0));
		}        	

		//Seq B 57a -> 57a 
		if (curSeqB.containsKey("57A")) {
			currentPaymentBlock4.addTag(curSeqB.get("57A").get(0));
		} else if (curSeqB.containsKey("57B")) {
			currentPaymentBlock4.addTag(curSeqB.get("57B").get(0));
		} else if (curSeqB.containsKey("57C")) {
			currentPaymentBlock4.addTag(curSeqB.get("57C").get(0));
		} else if (curSeqB.containsKey("57D")) {
			currentPaymentBlock4.addTag(curSeqB.get("57D").get(0));
		} 

		//Seq B 59a -> 59a
		if (curSeqB.containsKey("59")) {
			currentPaymentBlock4.addTag(curSeqB.get("59").get(0));
		} else if (curSeqB.containsKey("59A")) {
			currentPaymentBlock4.addTag(curSeqB.get("59A").get(0));
		}

		//Seq B 70 -> 70
		if (curSeqB.containsKey("70")) {
			currentPaymentBlock4.addTag(curSeqB.get("70").get(0));
		}

		//Seq A / B 71A -> 71A
		if (seqA.containsKey("71A")) {
			currentPaymentBlock4.addTag(seqA.get("71A").get(0));
		} else if (curSeqB.containsKey("71A")) {
			currentPaymentBlock4.addTag(curSeqB.get("71A").get(0));
		}

		//Seq B 71F -> 71F
		if (curSeqB.containsKey("71F")) {
			currentPaymentBlock4.addTags(curSeqB.get("71F"));
		}      

		//Seq B 71G -> 71G
		if (curSeqB.containsKey("71G")) {
			currentPaymentBlock4.addTag(curSeqB.get("71G").get(0));
		}          	

		//Seq C 72 -> 72 
		if (seqC.containsKey("72")) {
			currentPaymentBlock4.addTag(seqC.get("72").get(0));
		}

		//Seq A / B 77B -> 77B
		if (seqA.containsKey("77B")) {
			currentPaymentBlock4.addTag(seqA.get("77B").get(0));
		} else if (curSeqB.containsKey("77B")) {
			currentPaymentBlock4.addTag(curSeqB.get("77B").get(0));
		}  

		return currentPaymentBlock4;
	}

	private SwiftBlock4 getSingleBlock4FromMT101(Map<String, List<Tag>> curSeqB) {
		SwiftBlock4 currentPaymentBlock4 = new SwiftBlock4();

		//Seq B 21 -> 20 
		// SRA As per figure 21 of 101 is mapped to 70 of 103
		if (curSeqB.containsKey("21")) {
			currentPaymentBlock4.addTag(new Tag("20", curSeqB.get("21").get(0).getValue()));
		}

		//23B always CRED
		currentPaymentBlock4.addTag(new Tag("23B", "CRED"));
		boolean isRTGS = false;
		//Seq B 23E -> 23E
		if (curSeqB.containsKey("23E")) {
			List<Tag> tags = curSeqB.get("23E");
			String elements[] = {"SDVA", "INTC", "REPA", "CORT", "HOLD", "CHQB", "PHOB", "TELB", "PHON",
					"TELE", "PHOI", "TELI"};
			Set<String> codes = new HashSet<String>(Arrays.asList(elements));
			String elements70[] = {"CMSW", "CMTO", "CMZB", "NETS", "URGP"};
			Set<String> codes70 = new HashSet<String>(Arrays.asList(elements70));

			for (Tag tag : tags) {
				if (codes.contains(tag.getValue())) {
					// Handle PHON to PHOB here
					if ("PHON".equals(tag.getValue())) {
						currentPaymentBlock4.addTag(new Tag("23E", "PHOB"));
					} else {
						// 23E valid code
						currentPaymentBlock4.addTag(tag);
					}
				} else if (codes70.contains(tag.getValue())) {
					// 23E in 101 may contains codes CMSW, CMTO, CMZB, NETS, URGP should
					// be mapped to 70 of 103.
					if (currentPaymentBlock4.getTagByName("70") == null)
						currentPaymentBlock4.addTag(new Tag("70", tag.getValue()));
					else
						logger.error("Tag 70 already added in Block 4");
				} else if ("RTGS".equals(tag.getValue())) {
					isRTGS = true;
				} 
			}
		}


		//Seq B 32B (currency + Amount), Seq A 30 (value date) -> 32A
		Tag t32A = new Tag();
		t32A.setName("32A");
		String val = seqA.get("30").get(0).getValue().substring(0, 6);
		val +=  curSeqB.get("32B").get(0).getValue();
		t32A.setValue(val);
		currentPaymentBlock4.addTag(t32A);

		//Seq B  33B - > 33B
		if (curSeqB.containsKey("33B")) {
			currentPaymentBlock4.addTags(curSeqB.get("33B"));        		
		} else if (curSeqB.containsKey("32B")) {
			currentPaymentBlock4.addTag(new Tag("33B", curSeqB.get("32B").get(0).getValue()));
		}

		//Seq  B 36 -> 36
		if (curSeqB.containsKey("36")) {
			currentPaymentBlock4.addTag(curSeqB.get("36").get(0));
		} 

		//Seq A / B 50a -> 50a
		if (seqA.containsKey("50G")) {
			currentPaymentBlock4.addTag(new Tag("50A", seqA.get("50G").get(0).getValue()));
		} else if (curSeqB.containsKey("50G")) {
			currentPaymentBlock4.addTag(new Tag("50A", curSeqB.get("50G").get(0).getValue()));
		} else if (seqA.containsKey("50F")) {
			currentPaymentBlock4.addTag(seqA.get("50F").get(0));
		} else if (curSeqB.containsKey("50F")) {
			currentPaymentBlock4.addTag(curSeqB.get("50F").get(0));
		} else if (seqA.containsKey("50H")) {
			currentPaymentBlock4.addTag(new Tag("50K", seqA.get("50H").get(0).getValue()));
		} else if (curSeqB.containsKey("50H")) {
			currentPaymentBlock4.addTag(new Tag("50K", curSeqB.get("50H").get(0).getValue()));
		} 

		//Seq A 51A -> 51A
		//				if (seqA.containsKey("51A")) {
		//					currentPaymentBlock4.addTag(seqA.get("51A").get(0));
		//				} // SRA commented as per notes

		//Seq A / B 52a -> 52a
		if (seqA.containsKey("52A")) {
			currentPaymentBlock4.addTag(seqA.get("52A").get(0));
		} else if (curSeqB.containsKey("52A")) {
			currentPaymentBlock4.addTag(curSeqB.get("52A").get(0));
		} else if (seqA.containsKey("52D")) {
			currentPaymentBlock4.addTag(seqA.get("52D").get(0));
		} else if (curSeqB.containsKey("52D")) {
			currentPaymentBlock4.addTag(curSeqB.get("52D").get(0));
		} 

		//Seq B 56a -> 56a 
		if (curSeqB.containsKey("56A")) {
			currentPaymentBlock4.addTag(curSeqB.get("56A").get(0));
		} else if (curSeqB.containsKey("56C")) {
			currentPaymentBlock4.addTag(curSeqB.get("56C").get(0));
		} else if (curSeqB.containsKey("56D")) {
			currentPaymentBlock4.addTag(curSeqB.get("56D").get(0));
		}

		//Seq B 57a -> 57a 
		//if 23E contains RTGS
		String rt = isRTGS?"//RT":"";
		if (curSeqB.containsKey("57A")) {
			currentPaymentBlock4.addTag(new Tag("57A",rt+curSeqB.get("57A").get(0).getValue()));
		} else if (curSeqB.containsKey("57C")) {
			currentPaymentBlock4.addTag(new Tag("57C",rt+curSeqB.get("57C").get(0).getValue()));
		} else if (curSeqB.containsKey("57D")) {
			currentPaymentBlock4.addTag(new Tag("57D",rt+curSeqB.get("57D").get(0).getValue()));
		} 				

		//Seq B 59a -> 59a
		if (curSeqB.containsKey("59")) {
			currentPaymentBlock4.addTag(curSeqB.get("59").get(0));
		} else if (curSeqB.containsKey("59A")) {
			currentPaymentBlock4.addTag(curSeqB.get("59A").get(0));
		}

		//Seq B 70 -> 70
		// Add 70 tag if it is not added earlier...
		if (curSeqB.containsKey("70")&& currentPaymentBlock4.getTagByName("70") == null) {
			currentPaymentBlock4.addTag(curSeqB.get("70").get(0));
		}else
			logger.error("Tag 70 already added in Block 4");


		//Seq B 71A -> 71A
		if (curSeqB.containsKey("71A")) {
			currentPaymentBlock4.addTag(curSeqB.get("71A").get(0));
		}

		//Seq  B 77B -> 77B
		if (curSeqB.containsKey("77B")) {
			currentPaymentBlock4.addTag(curSeqB.get("77B").get(0));
		}  

		return currentPaymentBlock4;
	}


	private SwiftBlock4 getSingleBlock4FromMT203(Map<String, List<Tag>> curSeqB) {
		SwiftBlock4 currentPaymentBlock4 = new SwiftBlock4();

		//Seq B 20-> 20
		if (curSeqB.containsKey("20")) {
			currentPaymentBlock4.addTag(curSeqB.get("20").get(0));
		}
		//Seq B 21-> 21
		if (curSeqB.containsKey("21")) {
			currentPaymentBlock4.addTag(curSeqB.get("21").get(0));
		}				

		//Seq B 32B (currency + Amount), Seq A 30 (value date) -> 32A
		Tag t32A = new Tag();
		t32A.setName("32A");
		String val = seqA.get("30").get(0).getValue().substring(0, 6);
		val +=  curSeqB.get("32B").get(0).getValue();
		t32A.setValue(val);
		currentPaymentBlock4.addTag(t32A);

		//Seq A 52a -> 52a
		if (seqA.containsKey("52A")) {
			currentPaymentBlock4.addTag(seqA.get("52A").get(0));
		} else if (seqA.containsKey("52D")) {
			currentPaymentBlock4.addTag(seqA.get("52D").get(0));
		} 

		//Seq A 53a -> 53a 
		if (seqA.containsKey("53A")) {
			currentPaymentBlock4.addTag(seqA.get("53A").get(0));
		} else if (seqA.containsKey("53B")) {
			currentPaymentBlock4.addTag(seqA.get("53B").get(0));
		} else if (seqA.containsKey("53D")) {
			currentPaymentBlock4.addTag(seqA.get("53D").get(0));
		}

		//Seq A 54a -> 54a 
		if (seqA.containsKey("54A")) {
			currentPaymentBlock4.addTag(seqA.get("54A").get(0));
		} else if (seqA.containsKey("54B")) {
			currentPaymentBlock4.addTag(seqA.get("54B").get(0));
		} else if (seqA.containsKey("54D")) {
			currentPaymentBlock4.addTag(seqA.get("54D").get(0));
		} 

		//Seq B 56a -> 56a 
		if (curSeqB.containsKey("56A")) {
			currentPaymentBlock4.addTag(curSeqB.get("56A").get(0));
		} else if (curSeqB.containsKey("56D")) {
			currentPaymentBlock4.addTag(curSeqB.get("56D").get(0));
		} 				

		//Seq B 57a -> 57a 
		if (curSeqB.containsKey("57A")) {
			currentPaymentBlock4.addTag(curSeqB.get("57A").get(0));
		} else if (curSeqB.containsKey("57B")) {
			currentPaymentBlock4.addTag(curSeqB.get("57B").get(0));
		} else if (curSeqB.containsKey("57D")) {
			currentPaymentBlock4.addTag(curSeqB.get("57D").get(0));
		} 

		//Seq B 58a -> 58a
		if (curSeqB.containsKey("58A")) {
			currentPaymentBlock4.addTag(curSeqB.get("58A").get(0));
		} else if (curSeqB.containsKey("58D")) {
			currentPaymentBlock4.addTag(curSeqB.get("58D").get(0));
		}	     

		//Seq B 72 -> 72 
		if (curSeqB.containsKey("72")) {
			currentPaymentBlock4.addTag(curSeqB.get("72").get(0));
		}

		return currentPaymentBlock4;
	}
	
	private SwiftBlock4 getSingleBlock4FromMT201(Map<String, List<Tag>> curSeqB) {
		SwiftBlock4 currentPaymentBlock4 = new SwiftBlock4();

		//Seq B 20-> 20
		if (curSeqB.containsKey("20")) {
			currentPaymentBlock4.addTag(curSeqB.get("20").get(0));
		}			

		//Seq B 32B (currency + Amount), Seq A 30 (value date) -> 32A
		Tag t32A = new Tag();
		t32A.setName("32A");
		String val = seqA.get("30").get(0).getValue().substring(0, 6);
		val +=  curSeqB.get("32B").get(0).getValue();
		t32A.setValue(val);
		currentPaymentBlock4.addTag(t32A);

		//Seq A 53B -> 53B
		if (seqA.containsKey("53B")) {
			currentPaymentBlock4.addTag(seqA.get("53B").get(0));
		}  

		//Seq B 56a -> 56a 
		if (curSeqB.containsKey("56A")) {
			currentPaymentBlock4.addTag(curSeqB.get("56A").get(0));
		} else if (curSeqB.containsKey("56D")) {
			currentPaymentBlock4.addTag(curSeqB.get("56D").get(0));
		} 				

		//Seq B 57a -> 57a 
		if (curSeqB.containsKey("57A")) {
			currentPaymentBlock4.addTag(curSeqB.get("57A").get(0));
		} else if (curSeqB.containsKey("57B")) {
			currentPaymentBlock4.addTag(curSeqB.get("57B").get(0));
		} else if (curSeqB.containsKey("57D")) {
			currentPaymentBlock4.addTag(curSeqB.get("57D").get(0));
		}      

		//Seq B 72 -> 72 
		if (curSeqB.containsKey("72")) {
			currentPaymentBlock4.addTag(curSeqB.get("72").get(0));
		}

		return currentPaymentBlock4;
	}
	


	@Override
	public boolean hasNext() {
		return (is101 || is102 || is203 || is201) ? this.seqBIterator.hasNext() : super.hasNext();
	}

	@Override
	public String next() {

		if (! (is101 || is102 || is203 || is201)) {
			return super.next();
		}

		String trns = null;

		SwiftMessage currentPayment = new SwiftMessage();
		currentPayment.setBlock1(incomingSwiftBlock1);
		currentPayment.setBlock2(incomingSwiftBlock2);
		currentPayment.setBlock3(incomingSwiftBlock3);

		if (is101) {
			currentPayment.getBlock2().setMessageType("103");
			currentPayment.setBlock4(getSingleBlock4FromMT101(seqBIterator.next()));				
		} else if (is102) {
			currentPayment.getBlock2().setMessageType("103");
			currentPayment.setBlock4(getSingleBlock4FromMT102(seqBIterator.next()));	
		} else if (is203) {	
			currentPayment.getBlock2().setMessageType("202");
			currentPayment.setBlock4(getSingleBlock4FromMT203(seqBIterator.next()));
		} else if (is201) {	
			currentPayment.getBlock2().setMessageType("200");
			currentPayment.setBlock4(getSingleBlock4FromMT201(seqBIterator.next()));
		}

		trns = srv.getFIN(currentPayment);
		return trns;
	}

	@Override
	public void remove() {
		throw new UnsupportedOperationException("Removing a payment from a MultiPayment is not supported");
	}


	public static void main(String[] args) throws Exception {
		String messageToParse=  "{1:F01FNDTUS2LAXXX8571371521}{2:O1021036090925BCOMPTPLAXXX02182191590909251136N}{3:{108:0553763607}}{4:\r\n" +     
		":20:5362/MPB\r\n" +
		":23:CREDIT\r\n" + 
		":50K:/1234567890\r\n" + 
		"CONSORTIA PENSION SCHEME\r\n" + 
		"FRIEDRICHSTRASSE, 27\r\n" + 
		"8022-ZURICH\r\n" + 
		":71A:OUR\r\n" +
		":36:1,6\r\n" +
		":21:ABC/123\r\n" + 
		":32B:EUR1250,\r\n" + 
		":59:/001161685134\r\n" +
		"JOHANN WILLEMS\r\n" + 
		"Birmingham\r\n" + 
		"1040 BRUSSELS\r\n" + 
		":70:PENSION PAYMENT SEPTEMBER 2009\r\n" +
		":33B:CHF2000,\r\n" +
		":71G:EUR5,\r\n" + 
		":21:ABC/124\r\n" + 
		":32B:EUR1875,\r\n" +
		":59:/510007547061\r\n" + 
		"JOAN MILLS\r\n" + 
		"AVENUE LOUISE 213\r\n" + 
		"1050 BRUSSELS\r\n" + 
		":70:PENSION PAYMENT SEPTEMBER 2003\r\n" + 
		":33B:CHF3000,\r\n" + 
		":71G:EUR5,\r\n" +
		":32A:090828EUR3135,\r\n" +
		":19:3125,\r\n" +
		":71G:EUR10,\r\n" +
		"-}{5:{CHK:4E875776D0B2}}" ;  

		IterableTransactionReader iterableReader = new IterableTransactionReader(messageToParse);

		System.out.println("While loop\n");
		TransactionReader i = iterableReader.iterator();
		while (i.hasNext()) {
			System.out.println("Message\n" + i.next());
		}
		System.out.println("For each loop\n");
		for(String message : iterableReader) {
			System.out.println("Message\n" + message);
		}

	}

}
