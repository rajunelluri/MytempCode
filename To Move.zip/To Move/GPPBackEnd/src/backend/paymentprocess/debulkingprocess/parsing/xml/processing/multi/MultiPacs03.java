package backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi;

import java.util.HashSet;
import java.util.Set;

import com.fundtech.core.paymentprocess.data.paymenttypes.PaymentType;

/**
 * Concrete MultiMessageTypeData for pacs 03.
 * 
 * @author haimv
 * @author dmitryp
 */
public class MultiPacs03 extends MultiMessageTypeData{

	// TODO Do not use hard-coded tags - take it from logical_fields_xpath cache.	
	public MultiPacs03(PaymentType paymentType) {
	
	}
	
	@Override
	public String getGrpHdrEndTag() {
		return "</S2SDDDnf:NumREJBlk>";
	}

	@Override
	public String getGrpHdrStartTag() {
		return "<S2SDDDnf:SndgInst>";
	}

	@Override
	public String getTypeIdentifier() {
		return "MPEDDDnfBlkDirDeb";
	}
	
	
	@Override
	public void initTags(PaymentType paymentType)
	{
//		PaymentType paymentType = PaymentType.valueOf(getPaymentType());    
//        Map<String, LogicalFieldsXpath> map =CacheKeys.LogicalFieldsXPathKey.getSingle(paymentType);  
//       
	}

	@Override
	public String getPreDocumentEnd() {
		//TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getDocumentElementStartTag() {
		//TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getPrePmtInfEnd() {
		//TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getPaymentInfoElementStartTag() {
		//TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getDocumentElementEndTag() {
		//TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getPaymentInfoElementEndTag() {
		//TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getXmlClosingTags() {
		//TODO Auto-generated method stub
		return null;
	}

	@Override
	public void formatTags(String namespace) {
		//TODO Auto-generated method stub
		
	}

	@Override
	public byte[] getPaymentInfoElementStartTagBytes() {
		//TODO Auto-generated method stub
		return null;
	}

	@Override
	public byte[] getTransactionEndTagBytes() {
		//TODO Auto-generated method stub
		return null;
	}

	@Override
	public byte[] getTransactionStartTagBytes() {
		//TODO Auto-generated method stub
		return null;
	}

	@Override
	public byte[] getPaymentInfoElementEndTagBytes() {
		// TODO
		return null;
	}

	@Override
	public String getXmlStartingTags() {
		// TODO Auto-generated method stub
		return null;
	}

	
}