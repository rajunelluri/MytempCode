package backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi;

import static backend.core.module.MessageConstantsInterface.CREDIT_TRANSFER;
import static backend.core.module.MessageConstantsInterface.DIRECT_DEBIT;
import static backend.core.module.MessageConstantsInterface.MESSAGE_TYPE_PACS_004;
import static backend.paymentprocess.SubBatchProcessInterface.STATUS_FILE_COMPLETED;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.D_FILE_REJECT_REASON;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.D_RJCT_RSN;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_ACK_STS;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_FOLLOWUP;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_MSG_TYPE;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.X_INSTR_ID;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.X_ORGNL_INSTR_ID;
import static com.fundtech.errors.ProcessErrorConstants.ORFRejectionOfReturn;
import static com.fundtech.errors.ProcessErrorConstants.PaymentWasRejected;
import static com.fundtech.util.GlobalConstants.TRN_STS_ACTC;
import static com.fundtech.util.GlobalConstants.TRN_STS_RJCT;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.events.XMLEvent;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.commons.lang.StringUtils;
import org.codehaus.xfire.util.STAXUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import backend.paymentprocess.SubBatchProcessInterface;
import backend.paymentprocess.dao.DAOPayments;
import backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi.Pacs002XmlTransactionReader.BulkStatus;
import backend.paymentprocess.erroraudit.ErrorAuditUtils;
import backend.paymentprocess.highvalueprocess.businessobjects.BOHighValueProcess;

import com.ctc.wstx.stax.WstxInputFactory;
import com.fundtech.cache.entities.FileSummary;
import com.fundtech.cache.entities.InterfaceTypes;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.core.paymentprocess.data.paymenttypes.PaymentType;
import com.fundtech.core.security.Admin;
import com.fundtech.interfaces.gateway.MessageContext;
import com.fundtech.scl.debulkingProcessService.PerformDebulkingMultiRequestDocument;
import com.fundtech.scl.massPayment.PaymentReferenceType;
import com.fundtech.scl.massPayment.PerformDebulkingAckRequsetDocument;
import com.fundtech.scl.massPayment.PerformDebulkingAckRequsetType;
import com.fundtech.spring.SpringApplicationContext;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalUtils;

/**
 * @author liron.aravot This class represents a XML reader for CVF files.
 */
public abstract class AckXmlTransactionReader extends
		AbstractSingleInMuliSchemaReader implements AckXmlTransactionReaderIfc {

	private final static String NAK_FOR_PACS004 ="NAK_received_for_Pacs.004";
	final static String TRACE_PDO_BATCH_SAVE_BEFORE = "BEFORE calling 'PaymentDataFactory.batchSave'";
	final static String TRACE_PDO_BATCH_SAVE_AFTER = "AFTER calling 'PaymentDataFactory.batchSave'";
	
	private static final Logger logger = LoggerFactory
			.getLogger(AckXmlTransactionReader.class);
	XMLInputFactory factory = null;
	XMLStreamReader staxXmlReader;
	XMLEventReader reader;
	public Queue<PerformDebulkingAckRequsetDocument> chunks;
	private String bulkStatus;
	private StringBuilder builder;
	XPathFactory xpathFactory;
	XPath xpath;
	protected static final int chunkSize = 200;
	boolean isInMiddleOfGrpProcess = false;
	private FileInputStream fis;
	int transactionCount = 0;
	// boolean for indicating if the reader was already initiated
	protected boolean isInitiated = false;
	protected DocumentBuilderFactory docFactory;
	protected String fileStatus;

	/**
	 * @author liron.aravot private enum representing the different file reject
	 *         statuses - information received from BA team.
	 */
	protected enum FileRejectStatus {
		FILE_ACCEPTED, FILE_REJECTED, FILE_PARTIALLY_ACCEPTED;

		private String statusCode;
		private String reasonCode;

		/**
		 * method for getting the correct file reject status for given reject
		 * code presented in the XML file
		 * 
		 * @param value
		 * @return FileRejectStatus
		 */
		public static FileRejectStatus getStatusByValue(String value) {
			// there is large range of different file reject statuses, so it's
			// enum value is defined
			// as the default value
			FileRejectStatus toReturn = FILE_REJECTED;

			if (value.equals("A00"))
				toReturn = FILE_ACCEPTED;

			if (value.equals("A01"))
				toReturn = FILE_PARTIALLY_ACCEPTED;

			toReturn.statusCode = value;
			return toReturn;
		}

		public String getStatusCode() {
			return this.statusCode;
		}
		
		public String getReasonCode() {
			return this.reasonCode;
		}
		
		public void setReasonCode(String reasonCd) {
			this.reasonCode = reasonCd;
		}
	}

	/**
	 * @author liron.aravot private enum representing the different group
	 *         feedback statuses - information received from BA team.
	 */
	protected enum GroupStatus {
		PART_REJECTED("PART"), WHOLE_REJECTED(TRN_STS_RJCT), WHOLE_ACCEPTED(
				TRN_STS_ACTC);

		private String grpStatusInText;
		private static final Map<String, GroupStatus> mapGrpStatus = new HashMap<String, GroupStatus>();
		static {
			for (GroupStatus stts : GroupStatus.values()) {
				mapGrpStatus.put(stts.toString(), stts);
			}
		}

		private GroupStatus(String grpStatusInText) {
			this.grpStatusInText = grpStatusInText;
		}

		/**
		 * method for getting the correct group status for given group status in
		 * in the XML file
		 * 
		 * @param value
		 * @return GroupStatus
		 */
		public static GroupStatus getStatusByValue(String value) {
			return mapGrpStatus.get(value);
		}

		@Override
		public String toString() {
			return this.grpStatusInText;
		}
	}

	private enum TransactionStatus {
		REJECTED(TRN_STS_RJCT), ACCEPTED("ACPT"), PARTIAL(
				"PART");

		private String txStatusInText;
		private static final Map<String, TransactionStatus> mapTxStatus = new HashMap<String, TransactionStatus>();
		static {
			for (TransactionStatus stts : TransactionStatus.values()) {
				mapTxStatus.put(stts.toString(), stts);
			}
		}

		private TransactionStatus(String txStatusInText) {
			this.txStatusInText = txStatusInText;
		}

		/**
		 * method for getting the correct group status for given group status in
		 * in the XML file
		 * 
		 * @param value
		 * @return GroupStatus
		 */
		public static TransactionStatus getStatusByValue(String value) {
			return mapTxStatus.get(value);
		}

		@Override
		public String toString() {
			return this.txStatusInText;
		}
	}

	public AckXmlTransactionReader() {

	}

	public String getFileStatus() {
		return fileStatus;
	}

	public String getoriginalFileInternalId() {
		return originalFileInternalId;
	}

	public static class CvfTransactionReader extends AckXmlTransactionReader {

		private static final Logger logger = LoggerFactory
				.getLogger(CvfTransactionReader.class);

		public CvfTransactionReader(File file, int chunkSize,
				FileMessageTypeData fileMessageTypeData) {
			super(file, chunkSize, fileMessageTypeData);
		}

		@Override
		public void readerSpecificInit() throws XMLStreamException {

			String header = getXMLBetweenTags("SndgInst", "FileCycleNo");
			Document doc = this.getXMLDocumentFromString("<TempDoc>" + header
					+ "</TempDoc>");

			try {
				XPathExpression sndgInstXpath = xpath.compile("//SndgInst");
				XPathExpression rcvgInstXpath = xpath.compile("//RcvgInst");
				XPathExpression fileRefXpath = xpath.compile("//FileRef");
				XPathExpression fileRjctRsnXpath = xpath
						.compile("//FileRjctRsn");
				XPathExpression origFRef = xpath.compile("//OrigFRef");
				XPathExpression fileBusDtXpath = xpath.compile("//FileBusDt");
				XPathExpression fTypeXpath = xpath.compile("//FType");

				this.setM_fileType(fTypeXpath.evaluate(doc));

				String str_date = fileBusDtXpath.evaluate(doc);

				DateFormat formatter = new SimpleDateFormat("yyyy-mm-dd");
				this.setBusinessDate((Date) formatter.parse(str_date));

				String fileRjctRsn = fileRjctRsnXpath.evaluate(doc);
				status = FileRejectStatus.getStatusByValue(fileRjctRsn);

				String sendInst = sndgInstXpath.evaluate(doc) + "XXX";
				String rcvgInst = rcvgInstXpath.evaluate(doc) + "XXX";

				setInitiatingPartyCustCode(MultiXmlTransactionReader
						.getSenderReceivingCustCode(rcvgInst, sendInst));

				setSendingInst(sendInst);

				this.setMsgId(fileRefXpath.evaluate(doc));

				String tempFileRef = origFRef.evaluate(doc);

				if (tempFileRef != null && !tempFileRef.isEmpty()) {
					originalFileInternalId = daoFilesProcessing
							.performFileMatching(tempFileRef);
				} else {
					XPathExpression origFNameXpath = xpath
							.compile("//OrigFName");
					String origFName = origFNameXpath.evaluate(doc);
					originalFileInternalId = daoFilesProcessing
							.performFileMatching(origFName, rcvgInst);
				}

				if (originalFileInternalId == null
						|| originalFileInternalId.isEmpty()) {
					fileStatus = SubBatchProcessInterface.STATUS_NOT_MATCHED;
				}

			} catch (XPathExpressionException e) {
				logger.error(e.getMessage());
			} catch (ParseException e) {
				logger.error(e.getMessage());
			}

		}

		@Override
		public void init(InputStream inputStream) throws Exception {
			// TODO Auto-generated method stub

		}

		@Override
		public List<PDO> getPDOsFromChunk(
				PerformDebulkingMultiRequestDocument doc, String chunkId,
				String sInternalFileID, FileSummary fileSummary,
				Map[] arrMapSharedPDOContextHolder, boolean bShouldLogInfo)
				throws Throwable {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public long getBatchIndexOffset() {
			// TODO Auto-generated method stub
			return 0;
		}
	}

	protected Document getXMLDocumentFromString(String t) {
		DocumentBuilder docBuilder;
		org.w3c.dom.Document doc = null;
		try {
			docBuilder = docFactory.newDocumentBuilder();
			InputSource source = new InputSource(new StringReader(t));
			doc = docBuilder.parse(source);
		} catch (ParserConfigurationException e) {
			logger.error(e.getMessage());
		} catch (SAXException e) {
			logger.error(e.getMessage());
		} catch (IOException e) {
			logger.error(e.getMessage());
		}

		return doc;
	}

	public static class CcfTransactionReader extends AckXmlTransactionReader {

		public CcfTransactionReader(File file, int chunkSize,
				FileMessageTypeData fileMessageTypeData) {
			super(file, chunkSize, fileMessageTypeData);
		}

		@Override
		public void readerSpecificInit() throws XMLStreamException {

			String header = getXMLBetweenTags("SndgInst", "FileCycleNo");
			Document doc = this.getXMLDocumentFromString("<TempDoc>" + header
					+ "</TempDoc>");
			try {
				XPathExpression sndgInstXpath = xpath.compile("//SndgInst");
				XPathExpression rcvgInstXpath = xpath.compile("//RcvgInst");
				XPathExpression fTypeXpath = xpath.compile("//FType");
				XPathExpression fileRefXpath = xpath.compile("//FileRef");
				XPathExpression fileBusDtXpath = xpath.compile("//FileBusDt");

				String sendInst = sndgInstXpath.evaluate(doc) + "XXX";
				String rcvgInst = rcvgInstXpath.evaluate(doc) + "XXX";
				this.setM_fileType(fTypeXpath.evaluate(doc));
				this.setMsgId(fileRefXpath.evaluate(doc));
				String str_date = fileBusDtXpath.evaluate(doc);
				DateFormat formatter = new SimpleDateFormat("yyyy-mm-dd");
				this.setBusinessDate((Date) formatter.parse(str_date));

				setInitiatingPartyCustCode(MultiXmlTransactionReader
						.getSenderReceivingCustCode(rcvgInst, sendInst));

				setSendingInst(sendInst);

				// FILE_PARTIALLY_ACCEPTED
				status = FileRejectStatus.getStatusByValue("A01");

			} catch (XPathExpressionException e) {
				logger.error(e.getMessage());
			} catch (ParseException e) {
				logger.error(e.getMessage());
			}
		}

		@Override
		public void init(InputStream inputStream) throws Exception {
			// TODO Auto-generated method stub

		}

		@Override
		public List<PDO> getPDOsFromChunk(
				PerformDebulkingMultiRequestDocument doc, String chunkId,
				String sInternalFileID, FileSummary fileSummary,
				Map[] arrMapSharedPDOContextHolder, boolean bShouldLogInfo)
				throws Throwable {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public long getBatchIndexOffset() {
			// TODO Auto-generated method stub
			return 0;
		}

	}

	public abstract void readerSpecificInit() throws XMLStreamException;

	/**
	 * @param file
	 * @param chunkSize
	 * @param fileMessageTypeData
	 */
	public AckXmlTransactionReader(File file, int chunkSize,
			FileMessageTypeData fileMessageTypeData) {
		super(file, chunkSize, fileMessageTypeData);
		// TODO
	}

	// @Override
	// protected boolean readTransactionsOfChunkSize() {
	//
	// }

	@Override
	protected void readPreTransactionData() {
		// TODO

	}

	@Override
	protected void readDocumentStartData() {
		// TODO

	}

	@Override
	public void remove() {
		super.remove();
		try {
			reader.close();
			staxXmlReader.close();
			fis.close();
		} catch (XMLStreamException e) {
			logger.error(e.getMessage());
		} catch (IOException e) {
			logger.error(e.getMessage());
		}

	}// EOM remove

	/**
	 * this method used for initiation of the class members. the member
	 * isInitiated used as state indicator and indicates if the reader member
	 * are already initiated.
	 */
	public void init() {
		INTERFACE_TYPE = InterfaceTypes.INTERFACE_TYPE_MASSPMNTS;
		INTERFACE_SUB_TYPE = InterfaceTypes.INTERFACE_SUB_TYPE_DEB_ACK;

		wasProcessed = false;
		xpathFactory = XPathFactory.newInstance();
		xpath = xpathFactory.newXPath();
		docFactory = DocumentBuilderFactory.newInstance();
		docFactory.setNamespaceAware(true);
		daoFilesProcessing = new DAOFilesProcessing();
		builder = new StringBuilder();
		chunks = new LinkedList<PerformDebulkingAckRequsetDocument>();
		factory = new WstxInputFactory();
		// if the transaction reader wasn't initiated already - initiation
		// should be performed.
		if (!isInitiated) {
			File file = this.getFile();
			setCtrlSum("-1");

			try {
				fis = new FileInputStream(file);

				staxXmlReader = STAXUtils
						.createXMLStreamReader(new InputStreamReader(fis));
				reader = factory.createXMLEventReader(staxXmlReader);
			} catch (FileNotFoundException e1) {
				logger.error("FIle {} not found",file.getName());
			} catch (XMLStreamException e) {
				logger.error(e.getMessage());
			}

			try {
				this.readerSpecificInit();
			} catch (XMLStreamException e) {
				
			}
			isInitiated=true;
		}
	}

	/**
	 * Utility method. the method reads till the mentioned tag and retrieves the
	 * tag value.
	 * 
	 * @param tag
	 * @return
	 * @throws XMLStreamException
	 */
	protected String getTagValue(String tag) throws XMLStreamException {
		this.readTillNextTag(tag, false);
		return this.getCurrentXmlValue();
	}

	@Override
	public Object next() {
		return this.chunks.poll();
	}

	/**
	 * returns if there are more chunks retrieved from the file processing
	 * process.
	 */
	@Override
	public boolean hasNext() {
		
		return this.readTransactionsOfChunkSize();
		
	}

	protected boolean isAnotherGroupFound = true;

	/**
	 * @return
	 * @throws XMLStreamException
	 */
	private boolean processBulkMsgType()
			throws XMLStreamException {
		String group = this.getCompleteNode("OrgnlGrpInfAndSts");
		XPathExpression orgnlMsgNmId;
		org.w3c.dom.Document doc = null;
		String msgType="";
		XPathExpression grpStatusPath;
		String grpStatusRsnCD = null;
		String grpDescriptionRsn = null;
		try {

			if (group == null || group.isEmpty()) {
				return false;
			}

			orgnlMsgNmId = xpath.compile("//OrgnlGrpInfAndSts/OrgnlMsgNmId");
			DocumentBuilderFactory factory = DocumentBuilderFactory
					.newInstance();
			factory.setNamespaceAware(true); // never forget this!
			DocumentBuilder builder;
			builder = factory.newDocumentBuilder();
			InputSource source = new InputSource(new StringReader(group));
			doc = builder.parse(source);
			msgType=orgnlMsgNmId.evaluate(doc);
			
			if(msgType!=null && msgType.contains("pacs.008")){
				this.setBulkType(CREDIT_TRANSFER);
			}else if(msgType!=null && msgType.contains("pacs.003")){
				this.setBulkType(DIRECT_DEBIT);
			}
			
			//grpStatusPath = xpath.compile("//OrgnlGrpInfAndSts/StsRsnInf/Rsn/Cd");
			XPathExpression grpDescriptionPath = xpath.compile("//OrgnlGrpInfAndSts/StsRsnInf/Rsn/Prtry");
			//grpStatusRsnCD = grpStatusPath.evaluate(doc);
			grpDescriptionRsn = grpDescriptionPath.evaluate(doc);
			status.setReasonCode(grpDescriptionRsn);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return true;
	}
	
	/**
	 * @return
	 * @throws XMLStreamException
	 */
	public boolean processFileTransactionsAndGroups()
			throws XMLStreamException {
		String group = this.getCompleteNode("OrgnlGrpInfAndSts");
		XPathExpression groupStatus;
		XPathExpression orgnlMsgId;
		XPathExpression orgnlMsgNmId;
		XPathExpression grpStatusPath;
		XPathExpression grpDescriptionPath;
		String grpStatusRsn = "";
		String grpDescriptionRsn = "";
		org.w3c.dom.Document doc = null;
		String gSts = "";
		String orgMsg = "";
		String msgType="";
		try {

			if (group == null || group.isEmpty()) {
				return false;
			}

			groupStatus = xpath.compile("//OrgnlGrpInfAndSts/GrpSts");
			orgnlMsgId = xpath.compile("//OrgnlGrpInfAndSts/OrgnlMsgId");
			orgnlMsgNmId = xpath.compile("//OrgnlGrpInfAndSts/OrgnlMsgNmId");
			DocumentBuilderFactory factory = DocumentBuilderFactory
					.newInstance();
			factory.setNamespaceAware(true); // never forget this!
			DocumentBuilder builder;
			builder = factory.newDocumentBuilder();
			InputSource source = new InputSource(new StringReader(group));
			doc = builder.parse(source);
			gSts = groupStatus.evaluate(doc);
			orgMsg = orgnlMsgId.evaluate(doc);
			msgType=orgnlMsgNmId.evaluate(doc);
			
		} catch (Exception e) {
			logger.error(e.getMessage());
		}

		if (!StringUtils.isEmpty(gSts)) {
			GroupStatus grpStatus = GroupStatus.getStatusByValue((gSts));
			switch (grpStatus) {
			case PART_REJECTED:
				try {
					grpStatusPath = xpath
							.compile("//OrgnlGrpInfAndSts/StsRsnInf/Rsn/Cd");
					grpDescriptionPath = xpath
							.compile("//OrgnlGrpInfAndSts/StsRsnInf/Rsn/Prtry");
					grpStatusRsn = grpStatusPath.evaluate(doc);
					grpDescriptionRsn = grpDescriptionPath.evaluate(doc);
				} catch (XPathExpressionException e) {
					logger.error(e.getMessage());
				}

				if (isAnotherGroupFound)
					isAnotherGroupFound = this.rejectTransactions(grpStatusRsn,
							grpDescriptionRsn, orgMsg);
				break;
			case WHOLE_REJECTED:
				this.rejectGroup(orgMsg);
				break;
			case WHOLE_ACCEPTED:
				break;
			}
		}else
			isAnotherGroupFound=false;
		
		return isAnotherGroupFound;

	}

	protected boolean rejectTransactions(String grpStatusRsn,
			String grpDescriptionRsn, String orgnlMsgId)
			throws XMLStreamException {
		String startGroup = "OrgnlGrpInfAndSts";
		String startTransaction = "TxInfAndSts";
		Set<String> tagsSet = new HashSet<String>();
		// tagsSet.add(startGroup);
		tagsSet.add(startTransaction);
		String statusRsn = "";
		String txStatus = "";
		String paymentMID = "";
		String orgnlInstrIdStr = "";
		// group reason and description

		XPathExpression statusPath = null;
		XPathExpression descriptionPath = null;
		XPathExpression orgnlInstrId = null;
		XPathExpression orgnlTxId = null;
		XPathExpression txStatusPath = null;

		try {
			txStatusPath = xpath.compile("//TxInfAndSts/TxSts");
			statusPath = xpath.compile("//TxInfAndSts/StsRsnInf/Rsn/Cd");
			descriptionPath = xpath
					.compile("//TxInfAndSts/StsRsnInf/Rsn/Prtry");
			orgnlInstrId = xpath.compile("//TxInfAndSts/OrgnlInstrId");
			orgnlTxId = xpath.compile("//TxInfAndSts/OrgnlTxId");
		} catch (XPathExpressionException e) {

		} finally {

		}

		String tmp = null;
		try {
			tmp = this.readTillFirstAppearingTagInBulk(tagsSet, true);
		} catch (Exception e1) {
			logger.error(e1.getMessage());
		}
		if (tmp == null) {
			// no transaction start tag nor new group were found.
			return false;
		}

		List<PaymentReferenceType> listPaymentRefernceType = new ArrayList<PaymentReferenceType>();

		PerformDebulkingAckRequsetDocument newChunk = this
				.createChunk(orgnlMsgId);
		while (tmp != null && transactionCount < chunkSize) {
			// means that the current encountered tag is a group tag
			if (tmp.equals(startGroup)) {
				// means that is a chunk for the consumer to get
				break;
			}
			// means that the current encountered tag is a transaction tag
			else {
				String node = this.getCompleteNode(tmp);
				transactionCount++;
				if (tmp.equals(startTransaction)) {

					try {
						Document doc = this.getXMLDocumentFromString(node);

						txStatus = txStatusPath.evaluate(doc);
						TransactionStatus transactionStatus = TransactionStatus
								.getStatusByValue(txStatus);
						switch (transactionStatus) {
						case PARTIAL:
						case REJECTED: {
							statusRsn = statusPath.evaluate(doc);
							if (GlobalUtils.isNullOrEmpty(statusRsn)) {
								statusRsn = descriptionPath.evaluate(doc);
							}
							if (GlobalUtils.isNullOrEmpty(statusRsn)) {
								statusRsn = (!GlobalUtils
										.isNullOrEmpty(grpStatusRsn)) ? grpStatusRsn
										: grpDescriptionRsn;
							}
							orgnlInstrIdStr = orgnlInstrId.evaluate(doc);
							paymentMID = !GlobalUtils
									.isNullOrEmpty(orgnlInstrIdStr) ? orgnlInstrIdStr
									: orgnlTxId.evaluate(doc);

							PaymentReferenceType paymentInfo = PaymentReferenceType.Factory
									.newInstance();
							paymentInfo.setPaymentReference(paymentMID);
							paymentInfo.setReason(statusRsn);
							listPaymentRefernceType.add(paymentInfo);
						}
							break;
						}

					} catch (Exception e) {
						logger.error(e.getMessage());
					}
				}
			}
			tmp = this.readTillFirstAppearingTagInBulk(tagsSet, true);
		}

		if (listPaymentRefernceType.size() > 0) {
			newChunk.getPerformDebulkingAckRequset()
					.setPaymentReferenceTypeListArray(
							listPaymentRefernceType
									.toArray(new PaymentReferenceType[listPaymentRefernceType
											.size()]));
			if (!StringUtils.isEmpty(status.getStatusCode())) {
				// newChunk.getPerformDebulkingAckRequset().setRejectReason(status.toString());
				newChunk.getPerformDebulkingAckRequset().setRejectReason(
						status.getStatusCode());
			}
			this.chunks.add(newChunk);
			return true;
		} else {
			return false;
		}
	}

	public PerformDebulkingAckRequsetDocument createChunk(String orgnlMsgId) {
		PerformDebulkingAckRequsetDocument doc = PerformDebulkingAckRequsetDocument.Factory
				.newInstance();
		doc.addNewPerformDebulkingAckRequset();
		doc.getPerformDebulkingAckRequset().setOrgnlMsgId(orgnlMsgId);
		return doc;
	}

	protected String getCompleteNode(String tag) throws XMLStreamException {
		return this.getXMLBetweenTags(tag, tag);
	}

	protected String getXMLBetweenTags(String tagStart, String tagEnd)
			throws XMLStreamException {
		XMLEvent event = null;
		boolean isReadSuccesful = false;

		boolean isEndFound = false;
		isReadSuccesful = this.readTillNextTag(tagStart, true);
		if (isReadSuccesful) {
			builder.delete(0, builder.length());
			builder.append("<" + staxXmlReader.getLocalName() + ">");
			while (staxXmlReader.hasNext() && !isEndFound) {
				event = reader.nextEvent();
				if (event.isStartElement()) {
					builder.append("<" + staxXmlReader.getLocalName() + ">");
				}
				// mean it's end element
				else {
					if (event.isEndElement())

					{
						builder.append("</" + staxXmlReader.getLocalName()
								+ ">");
						if (staxXmlReader.getLocalName().equals(tagEnd))
							isEndFound = true;
					} else {
						if (event.isCharacters()) {
							if (event.asCharacters().getData().indexOf("\n") == -1) {
								builder.append(event.asCharacters().getData());
							}
						}
					}
				}
			}
		} else {
			reLoadReaders();
		}
		return builder.toString();
	}

	private void reLoadReaders() {
		File file = this.getFile();
		try {
			fis = new FileInputStream(file);
			staxXmlReader = STAXUtils
					.createXMLStreamReader(new InputStreamReader(fis));
			reader = factory.createXMLEventReader(staxXmlReader);
		} catch (Exception e) {
			logger.error("Failed to reload readers.");
		}

	}

	public void rejectGroup(String outGroupId) {
		DAOFilesProcessing daoFilesProcessing = new DAOFilesProcessing();
		List<String> chunksOfGroup = daoFilesProcessing
				.loadChunksOfGroup(outGroupId);
		List<PerformDebulkingAckRequsetDocument> chunks = this
				.getChunksFromStringList(chunksOfGroup, outGroupId);
		this.chunks.addAll(chunks);
	}

	public void rejectWholeFile(String internalFileId) {
		List<String[]> chunksOfFile = daoFilesProcessing
				.loadChunksOfFile(internalFileId);
		List<PerformDebulkingAckRequsetDocument> chunks = this
				.getChunksFromStringListForWholeFileReject(chunksOfFile);
		this.chunks.addAll(chunks);
	}

	protected List<PerformDebulkingAckRequsetDocument> getChunksFromStringListForWholeFileReject(
			List<String[]> chunksIds) {
		if (chunksIds == null || chunksIds.size() == 0)
			return Collections.emptyList();

		List<PerformDebulkingAckRequsetDocument> chunks = new ArrayList<PerformDebulkingAckRequsetDocument>();

		for (Iterator iterator = chunksIds.iterator(); iterator.hasNext();) {
			String[] values = (String[]) iterator.next();
			PerformDebulkingAckRequsetDocument doc = PerformDebulkingAckRequsetDocument.Factory
					.newInstance();
			doc.addNewPerformDebulkingAckRequset();
			doc.getPerformDebulkingAckRequset().setOutChunkID(values[0]);
			doc.getPerformDebulkingAckRequset().setOrgnlMsgId(values[1]);
			doc.getPerformDebulkingAckRequset().setRejectReason(
					status.getReasonCode());
			chunks.add(doc);
		}
		return chunks;
	}

	private List<PerformDebulkingAckRequsetDocument> getChunksFromStringList(
			List<String> chunksIds, String orgnlMsgId) {
		if (chunksIds == null || chunksIds.size() == 0)
			return Collections.emptyList();

		List<PerformDebulkingAckRequsetDocument> chunks = new ArrayList<PerformDebulkingAckRequsetDocument>();
		for (String chunkId : chunksIds) {
			PerformDebulkingAckRequsetDocument doc = PerformDebulkingAckRequsetDocument.Factory
					.newInstance();
			doc.addNewPerformDebulkingAckRequset();
			doc.getPerformDebulkingAckRequset().setOrgnlMsgId(orgnlMsgId);
			doc.getPerformDebulkingAckRequset().setOutChunkID(chunkId);
			doc.getPerformDebulkingAckRequset().setRejectReason(
					status.getStatusCode());
			chunks.add(doc);
		}
		return chunks;
	}

	protected String originalFileInternalId;
	protected FileRejectStatus status;
	protected boolean wasProcessed;
	protected DAOFilesProcessing daoFilesProcessing;

	protected void getStatus(GroupStatus groupStatus) {
		switch (groupStatus) {
		case PART_REJECTED:
			status = FileRejectStatus.FILE_PARTIALLY_ACCEPTED;
			break;
		case WHOLE_REJECTED:
			status = FileRejectStatus.FILE_REJECTED;
			break;
		case WHOLE_ACCEPTED:
			status = FileRejectStatus.FILE_ACCEPTED;
			break;
		}
	}
	
	@Override
	public boolean readTransactionsOfChunkSize() {
		// indicating there was an error reading the file.
		boolean error = false;

		// In case file was not matched...
		if (!GlobalUtils.isNullOrEmpty(fileStatus) && !STATUS_FILE_COMPLETED.equals(fileStatus)) {
			return false;
		}

		if (this.chunks.size() > 0) {
			return true;
		}

		try {

			switch (status) {
			case FILE_ACCEPTED:
				if (!wasProcessed) {
					// TODO: change to the needed status
					fileStatus = STATUS_FILE_COMPLETED;
					wasProcessed = true;
				}
				break;
			case FILE_PARTIALLY_ACCEPTED:
				Boolean hasChunks=this.processFileTransactionsAndGroups();
				if (hasChunks) {
					fileStatus = STATUS_FILE_COMPLETED;
				}
				return hasChunks; 
				// break;
			case FILE_REJECTED:
				if (!wasProcessed) {
					this.rejectWholeFile(originalFileInternalId);
					wasProcessed = true;
				} 
				else {							
					if (this.chunks.isEmpty()) {
						processFileTransactionsAndGroups();
					}
				}
				break;
			}

		} catch (XMLStreamException e) {
			logger.error(e.getMessage());
		} finally {

		}
		return this.chunks.size() > 0;
		// return false;
	}

	protected boolean changeFileStatus(String internalFileId, String status) {
		return daoFilesProcessing.updateFileStatus(internalFileId, status);
	}

	protected String getCurrentXmlValue() throws XMLStreamException {
		return staxXmlReader.getElementText();
	}

	protected boolean readTillNextTag(String tag, boolean isIncludeCurrentTag)
			throws XMLStreamException {
		if (staxXmlReader.isStartElement()
				&& tag.equals((staxXmlReader.getLocalName()))
				&& isIncludeCurrentTag) {
			return true;
		}

		XMLEvent event = null;
		while (reader.hasNext()) {
			event = reader.nextEvent();
			if (event.isStartElement()) {
				if (staxXmlReader.getLocalName().equals(tag)) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * this method recieves a set of xml tags and search the current xml for the
	 * first appearing tag from the set
	 * 
	 * @author liron.aravot
	 * @param tagsSet
	 *            - set of xml tags
	 * @return String (the first appearing tags).
	 * @throws XMLStreamException
	 */

	protected String readTillFirstAppearingTagInBulk(Set<String> tagsSet,
			boolean isIncludeCurrentTag) throws XMLStreamException {
		if (staxXmlReader.isStartElement()
				&& tagsSet.contains(staxXmlReader.getLocalName())
				&& isIncludeCurrentTag) {
			return staxXmlReader.getLocalName();
		}

		XMLEvent event = null;
		while (reader.hasNext()) {
			event = reader.nextEvent();
			if (event.isEndElement()){
				if("FIToFIPmtStsRpt".equals(staxXmlReader.getLocalName()))		// Mark the end of Bulk
					return null;
			}
			
			if (event.isStartElement()) {
				String local = staxXmlReader.getLocalName();
				if (tagsSet.contains(staxXmlReader.getLocalName())) {
					return staxXmlReader.getLocalName();
				}
			}
		}
		return null;
	}

	private String readTillFirstAppearingTagTillEndTag(Set<String> tagsSet,
			String endTag) throws XMLStreamException {
		XMLEvent event = null;
		while (reader.hasNext()) {
			event = reader.nextEvent();
			if (event.isStartElement()) {
				if (tagsSet.contains(staxXmlReader.getLocalName())) {
					return staxXmlReader.getLocalName();
				}
			}
			// mean it's end element
			else {
				if (endTag.equals(staxXmlReader.getLocalName())) {
					return "";
				}
			}
		}
		return "";
	}

	@Override
	public void setAdditionalDocumentData(Object request, String chunkId,
			String status, String internalFileId, String path, String workFlow,
			String bulkId) {

		PerformDebulkingAckRequsetDocument doc = (PerformDebulkingAckRequsetDocument) request;
		PerformDebulkingAckRequsetType debulkingAckRequest = doc
				.getPerformDebulkingAckRequset();
		debulkingAckRequest.setInternalFileID(internalFileId);
		debulkingAckRequest.setInChunkID(chunkId);
		debulkingAckRequest.setStatus(status);
		if(chunks.contains(doc)){
			logger.info(doc.getPerformDebulkingAckRequset().getInternalFileID());
		}
	}

	@Override
	public int getRecCountInChunk(Object chunk) {
		// TODO: Need to implement !!
		return 0;
	}

	// TODO: check about the meaning.

	@Override
	public String getXmlofChunk(Object chunk) {
		PerformDebulkingAckRequsetDocument doc = (PerformDebulkingAckRequsetDocument) chunk;
		return doc.xmlText();
	}

	public static List<PDO> getPDOsFromChunk(
			PerformDebulkingAckRequsetDocument doc, String chunkId,
			String sInternalFileID, final Map[] arrMapSharedPDOContextHolder) throws Throwable 
	{
		DAOPayments daoPayments = (DAOPayments) SpringApplicationContext.getBean("daoPayments");
		List<PDO> toReturn = null;

		//Internal file ID is using for BP process.
		//In this case we get the partition ID from the Internal file ID , in order to get the information from the relevant partition
		Integer partitionID = GlobalUtils.getPartitionIDByMID(sInternalFileID);

		String fileRejectReason = doc.getPerformDebulkingAckRequset().getRejectReason();
		String rejectReason;
		if (!GlobalUtils.isNullOrEmpty(doc.getPerformDebulkingAckRequset().getOutChunkID())) 
		{
			String outChunkId = doc.getPerformDebulkingAckRequset()
					.getOutChunkID();
			String groupMsgId = doc.getPerformDebulkingAckRequset()
					.getOrgnlMsgId();
			
			toReturn=daoPayments.loadByOutChunkId(outChunkId, partitionID);
			

			// set the reject reason for each of the PDOs
			for (PDO pdo : toReturn) {
				if (!MESSAGE_TYPE_PACS_004.equals(pdo.get(P_MSG_TYPE))) // OWF
				{
					pdo.set(D_RJCT_RSN, fileRejectReason);
					pdo.set(D_FILE_REJECT_REASON, fileRejectReason);	
					pdo.set(P_ACK_STS, TRN_STS_RJCT);
				}
				else // ORF
				{
					pdo.set(P_FOLLOWUP, NAK_FOR_PACS004);
				}
				ErrorAuditUtils.setError(PaymentWasRejected,pdo.getMID(), pdo.getIsHistory(),null,fileRejectReason);
			}
			
			if (MESSAGE_TYPE_PACS_004.equals(toReturn.get(0).get(P_MSG_TYPE))) 
			{
				writeFileErrors(sInternalFileID, partitionID, BulkStatus.RJCT.name());
			}
		}
		else {// File was partially rejected
			HashMap<String, String> reasonMap = new HashMap<String, String>();

			String groupMsgId = doc.getPerformDebulkingAckRequset()
					.getOrgnlMsgId();
			
			boolean isORF = groupMsgId.contains("ORD");
			
			PaymentReferenceType[] refArr = doc.getPerformDebulkingAckRequset()
					.getPaymentReferenceTypeListArray();
			int numberOfRefernces = refArr.length;
			String[] paymentRef = new String[numberOfRefernces];

			int i = 0;
			for (PaymentReferenceType paymentReferenceType : refArr) {
				paymentRef[i] = paymentReferenceType.getPaymentReference();
				reasonMap.put(paymentReferenceType.getPaymentReference(),
						paymentReferenceType.getReason());
				i++;
			}
				
			//Internal file ID is using for BP process.
			//In this case we get the partition ID from the Internal file ID , in order to get the information from the relevant partition
			StringBuilder lastFiveDays = new StringBuilder(partitionID.toString());
			for (int j = 1; j < 5; j++) 
			{
				lastFiveDays.append(",");
				lastFiveDays.append(GlobalUtils.subtractDays(partitionID.toString(), j));
			}

			
			if(isORF){
				//For DEV - loading the related ORD Pdo's for the matching ORF file
				//			using the Original File ID and the MFamily functionality
				toReturn = daoPayments.loadRelatedORDPDOsForORF(paymentRef, groupMsgId, lastFiveDays.toString());
			}else{
				try {	// OWF
					toReturn=daoPayments.loadPDOsByInstrIds(paymentRef, groupMsgId, lastFiveDays.toString());
				} catch (Exception e) {	
					logger.error(e.getMessage());
					//toReturn = PaymentDataFactory.loadByMids(paymentRef, groupMsgId);
				}
			}
			
			// set the reject reason for each of the PDOs
			for (PDO pdo : toReturn) {
				
				if (!MESSAGE_TYPE_PACS_004.equals(pdo.get(P_MSG_TYPE))) // OWF 
				{
					rejectReason = !GlobalUtils.isNullOrEmpty(reasonMap.get(pdo.getString(X_INSTR_ID))) ? 
							reasonMap.get(pdo.getString(X_INSTR_ID)) : fileRejectReason;
					pdo.set(D_RJCT_RSN, rejectReason);
					pdo.set(D_FILE_REJECT_REASON, fileRejectReason);

					BOHighValueProcess.performTerminationSubFlow(pdo,null);
					
					pdo.set(P_ACK_STS, TRN_STS_RJCT);
					
				}
				else // ORF
				{
					rejectReason = !GlobalUtils.isNullOrEmpty(reasonMap.get(pdo.getString(X_ORGNL_INSTR_ID))) ? 
							reasonMap.get(pdo.getString(X_ORGNL_INSTR_ID)) : fileRejectReason;
					pdo.set(P_FOLLOWUP, NAK_FOR_PACS004);

				}
				
				ErrorAuditUtils.setError(PaymentWasRejected,pdo.getMID(),pdo.getIsHistory(),null,rejectReason);
				
			}
			
			if (toReturn != null && !toReturn.isEmpty() && MESSAGE_TYPE_PACS_004.equals(toReturn.get(0).get(P_MSG_TYPE))) 
			{
				writeFileErrors(sInternalFileID, partitionID, BulkStatus.PART.name());
			}
		}
		return toReturn;
	}

	private static void writeFileErrors(String internalFileID, Integer partitionID, String fileStatus)
	{

		PDO filePdo = writeFileErr(internalFileID, fileStatus, partitionID);
		
		FileSummary fileSummary = filePdo.getNSetIncomingFileSummary() ;
		writeFileErr(fileSummary.getREL_INTERNAL_FILE_ID(), fileStatus, partitionID);
		ErrorAuditUtils.setError(ORFRejectionOfReturn,fileSummary.getREL_INTERNAL_FILE_ID(),partitionID,null, fileStatus);
		
	}
	
	private static PDO writeFileErr(String internalFileID, String fileStatus, Integer partitionID)
	{
		
		PDO tempPdo = PaymentDataFactory.newPDO(PaymentType.valueOf(PaymentType.PT_PACS_008), true/*bTransient*/);
		Admin.setContextPDO(tempPdo);	
		tempPdo.set(PDOConstantFieldsInterface.P_IN_INTERNAL_FILEID, internalFileID);
		tempPdo.setMID(internalFileID);
		tempPdo.setThinMode(true);
		tempPdo.set(PDOConstantFieldsInterface.P_IS_HISTORY, partitionID);
		ErrorAuditUtils.setError(ORFRejectionOfReturn,internalFileID, partitionID,null, fileStatus);
		
		try {
			logger.info(TRACE_PDO_BATCH_SAVE_BEFORE);	
			PaymentDataFactory.batchSave(true, tempPdo);
			logger.info(TRACE_PDO_BATCH_SAVE_AFTER);
		} catch (Throwable e) {
			logger.error("fail to save pdo, mid = {} with error: ",internalFileID,e.getMessage());	
		}
		return tempPdo; 
	}
	
	protected void configureNativeReader() {
	}

	public void setBulkStatus(String status) {
		bulkStatus = status;
	}
	public String getBulkStatus() {
		return bulkStatus;
	}
}
