package backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi;

import com.fundtech.core.paymentprocess.data.paymenttypes.PaymentType;

public class MultiFndtMessage extends MultiMessageTypeData{
	
	public MultiFndtMessage(PaymentType paymentType) {
	
	}
	
	// TODO Do not use hard-coded tags - take it from logical_fields_xpath cache.	

	@Override
	public String getGrpHdrEndTag() {
		return "</S2SCTScf:FileCycleNo>";
	}

	@Override
	public String getGrpHdrStartTag() {
		return "<S2SCTScf:SndgInst>";
	}

	@Override
	public String getTypeIdentifier() {
		return "SCTScfBlkCredTrf";
	}
	
	@Override
	public void initTags(PaymentType paymentType)
	{
//		PaymentType paymentType = PaymentType.valueOf(getPaymentType());    
//        Map<String, LogicalFieldsXpath> map =CacheKeys.LogicalFieldsXPathKey.getSingle(paymentType);  
//       
	}
	@Override
	public String getPreDocumentEnd() {
		//TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getDocumentElementStartTag() {
		//TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getPrePmtInfEnd() {
		//TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getPaymentInfoElementStartTag() {
		//TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getDocumentElementEndTag() {
		//TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getPaymentInfoElementEndTag() {
		//TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getXmlClosingTags() {
		//TODO Auto-generated method stub
		return null;
	}

	@Override
	public void formatTags(String namespace) {
		//TODO Auto-generated method stub
		
	}

	@Override
	public byte[] getPaymentInfoElementStartTagBytes() {
		//TODO Auto-generated method stub
		return null;
	}

	@Override
	public byte[] getTransactionEndTagBytes() {
		//TODO Auto-generated method stub
		return null;
	}

	@Override
	public byte[] getTransactionStartTagBytes() {
		//TODO Auto-generated method stub
		return null;
	}
	
	public byte[] getPaymentInfoElementEndTagBytes()
	{
		return null;
	}
	
}