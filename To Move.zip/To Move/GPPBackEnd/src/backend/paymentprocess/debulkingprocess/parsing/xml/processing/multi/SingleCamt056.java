package backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi;
import static backend.core.module.MessageConstantsInterface.MESSAGE_TYPE_CAMT_056;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.X_GRP_INFO;

import java.io.File;
import java.io.RandomAccessFile;
import java.util.Map;

import com.fundtech.cache.entities.LogicalFieldsXpath;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.paymenttypes.PaymentType;




public class SingleCamt056 extends SingleMessageTypeData{

	private Map<String, LogicalFieldsXpath> logicalFieldsXPathMap;
	
	public SingleCamt056(PaymentType paymentType){
		super(paymentType);
		this.setPaymentType(paymentType);
		logicalFieldsXPathMap = CacheKeys.LogicalFieldsXPathKey.getSingle(PaymentType.valueOf(MESSAGE_TYPE_CAMT_056));
	}
	
	@Override
	public String getTypeIdentifier() {
		return "urn:iso:std:iso:20022:tech:xsd:camt.056.001.01";
	}
	
	@Override
	public String getPaymentTypeName() {
		return "Camt_056";
	}
	
	@Override
	public void initTags(PaymentType paymentType) {
        Map<String, LogicalFieldsXpath> map =CacheKeys.LogicalFieldsXPathKey.getSingle(paymentType);  
        
       TRANSACTION_START_TAG =  this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_PMT_INFO).getTagName(),false);
       TRANSACTION_END_TAG =  this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_PMT_INFO).getTagName(), true);
       
       	PAYMENT_INFO_START_TAG = this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_GRP_INFO_MULTI).getTagName(), true);
		PAYMENT_INFO_END_TAG = this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_GRP_INFO_MULTI).getTagName(), true);
		
		MULTI_PAYMENT_GROUPING_TAG_START =  this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_UNDRLYG).getTagName(), false);
		MULTI_PAYMENT_GROUPING_TAG_END =  this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_UNDRLYG).getTagName(), true);
		
		
		GROUP_HEADER_START_TAG = PAYMENT_INFO_START_TAG;
		GROUP_HEADER_END_TAG   = this.formatTagToCorrectStructure(map.get(PDOConstantFieldsInterface.X_CRTL_DATA).getTagName(), true);;
		
		CLOSE_XML_TAGS = "</%sFIToFIPmtCxlReq></%sDocument>";
	}
		

	@Override
	public String getPreDocumentEnd() {
		return getGrpHdrStartTag();
	}

	@Override
	public String getPrePmtInfEnd() {
		return getTransactionStartTag();
	}
	
	@Override
	public XmlTransactionReaderBase getReader() {
		if (defaultCtorReader == null) {
			defaultCtorReader= new CamtTransactionReader(this , true);
		}
		return defaultCtorReader;
		
	}

	@Override
	public XmlTransactionReaderBase getReader(File file, int chunkSize) {
		if (reader == null) {
			reader = new CamtTransactionReader(file, chunkSize,this , true);
		}
		return reader;
	}
	
	@Override
	public XmlTransactionReaderBase getReaderWithoutInit(File file,
			int chunkSize, RandomAccessFile accessFile) {
		if (reader == null) {
			reader = new CamtTransactionReader(file,accessFile, chunkSize,this , true);
		}
		return reader;
	}

	@Override
	public String getXmlClosingTags() {
		return super.getXmlClosingTags();
	}

	@Override
	public String getWorkflow() {
		// TODO Auto-generated method stub
		return null;
	}

//	@Override
//	public void formatTags(String namespace)
//	{
//		super.formatTags(namespace);
//		this.CAMT_056_PRE_PMT_INF_END = String.format(this.CAMT_056_PRE_PMT_INF_END,namespace);
//	}

	@Override
	public byte[] getPaymentInfoElementStartTagBytes() {
		return getPaymentInfoElementStartTag().getBytes();
	}

	
	@Override
	public byte[] getPaymentInfoElementEndTagBytes() {
		return getPaymentInfoElementEndTag().getBytes();
	}

	@Override
	public String getHeaderTag() {
		LogicalFieldsXpath logicalFieldsXpath = logicalFieldsXPathMap.get(X_GRP_INFO);
		return logicalFieldsXpath.getTagName(); // FIToFIPmtCxlReq		
	}
}
