package backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi;

import java.io.File;

import com.fundtech.core.paymentprocess.data.paymenttypes.FileMeaasgeTypeDataInterface;
import com.fundtech.core.paymentprocess.data.paymenttypes.PaymentType;

/**
 * This abstract class represents the file message data types for multi message types.
 * 
 * @see FileMessageTypeData
 * 
 * @author haimv
 * @author dmitryp
 */
public abstract class MultiMessageTypeData implements FileMessageTypeData, FileMeaasgeTypeDataInterface{

	protected PaymentType paymentType = null;
	protected XmlTransactionReaderBase reader = null;
	
	@Override
	public void setPaymentType(PaymentType paymentType) {
		this.paymentType = paymentType;
	}
	
	@Override
	public String getRootElement()
	{
		return paymentType.getLocalPart();
	}
	
	public String getMultiFileStartTag()
	{
		return "";
	}
	
	public String getMultiFileEndTag()
	{
		return "";
	}
	/**
	 * @return null - not relevant for multi types, we already have it in each type.
	 */
	public String getTransactionStartTag() {
		return null;
	}

	/**
	 * @return null - not relevant for multi types, we already have it in each type.
	 */
	public String getTransactionEndTag() {
		return null;
	}
	
	/**
	 * @return null - not relevant for multi types, we already have it in each type.
	 */	
	public String getPaymentTypeName() {
		return null;
	}

	@Override
	public XmlTransactionReaderBase getReader(File file, int chunkSize) {
		return new MultiXmlTransactionReader(file, chunkSize,this);
	}
	
	@Override
	public XmlTransactionReaderBase getReader() {
		// TODO Auto-generated method stub
		return new MultiXmlTransactionReader();
	}

	@Override
	public String getWorkflow() {
		// TODO
		return null;
	}
	
	public String getMultiPaymentGroupingTagStart(){
		return "";
	}
	
	public String getMultiPaymentGroupingTagEnd(){
		return "";
	}
	

	@Override
	public String getXmlStartingTags() {
		// TODO Auto-generated method stub
		return null;
	}
	
}