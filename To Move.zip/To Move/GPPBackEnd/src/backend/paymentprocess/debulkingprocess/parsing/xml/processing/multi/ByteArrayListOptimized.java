package backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * ArrayList of byte primitives.
 * @author LironAravot
 */
public class ByteArrayListOptimized implements Serializable {

  /**
         * 
         */
        private static final int START_POINTER_NEAR_END_OF_BUFFER = 300;

private byte[] array;
  
  private int size;
  private int start;
  private int end;
  private FindWordResponse  temp = null;;

  public final static int initialCapacity = 192000;

  /**
   * Constructs an empty list with an initial capacity.
   */
  public ByteArrayListOptimized() {
    this(initialCapacity);
  }

  /**
   * Constructs an empty list with the specified initial capacity.
   */
  public ByteArrayListOptimized(int initialCapacity) {
    if (initialCapacity < 0) {
      throw new IllegalArgumentException("Capacity can't be negative: " + initialCapacity);
    }
    array = new byte[initialCapacity];
    size = 0;
    start = 0;
    end = 0;
    temp = new FindWordResponse();
  }


        public byte[] getArray() {
                return array;
        }


  /**
   * Returns the number of elements in this list.
   */
  public int getSize() {
    return size;
  }
  
  public void setSize(int size) {
            this.size = size;
  }
          
  /**
   * get the actual array.
 * @return return array which is the actual array (from 'start' to 'end' indexes') 
 */
        public byte[] returnActualArray() {
                int length = 0;
                // target array
                byte[] byteArray = null;
                byteArray = new byte[size];
                //one copy only should be made
                if (end > start) {
                        length = end - start;
                        System.arraycopy(this.array, start, byteArray, 0, length);
                // means that the array is 'rotated' and two array copy actions should be done
                } else {
                        System.arraycopy(this.array, start, byteArray, 0, array.length
                                        - start);
                        // number of elements copied in the first copy action
                        length = size - (array.length - start);
                        System.arraycopy(this.array, 0, byteArray, size - length, size
                                        - (array.length - start));
                }
                // return the newly created array
                return byteArray;
        }


        /**
         * Deprecated, Calls - removeRangeFromBeginning
         * which remove until the end of the array, Removes from this list all of the elements whose index is between
         * fromIndex, inclusive and toIndex, exclusive. Shifts any succeeding
         * elements to the left (reduces their index).
         */
        @Deprecated
        public void removeRange(long fromIndex, long toIndex) {
                this.removeRangeFromBeginning((int)toIndex);
        }

        /**
         * Removes from this list all of the elements to
         * the given length
         */
    public void removeRangeFromBeginning(int length) 
    {
      this.start += length;
      // if start index is over the array length, it should
      // be initialized back to the array start.
          if(overlapped())
          {
                this.start = this.start - (this.array.length);  
          }
          this.size -= length;
   } 
    
    
        /**
         * @return - true if we exceeded the array length 
         * with the current array start
         */
        private boolean overlapped() {
                return this.start > this.array.length;
        }
  
        /**
         * does nothing at the moment
         * 
         * @author Dmitryp
         */
        @Deprecated
        public void append(byte[] data, int offset, int length) {
        }
   
  
  /**
   * Removes all of the elements from this list.
   * The list will be empty after this call returns.
   */
  public void clear() {
    size = 0;
    start = 0;
    end = 0;
  }


  /**
   * Searches for the first occurence of the given argument.
   * @author Liron.Aravot
   */
  public int indexOf(byte[] subarray){
        return indexOfWithStartEndIndex(subarray, 0, this.size);
  }
  
  
     /**
   * Searches for the first occurence of the given argument.
   * @author Liron Aravot
   */
   public int indexOf(byte[] subarray, int startIndex) {
        return this.indexOfWithStartEndIndex(subarray, startIndex, this.size);
  }

   
   
   
     /**
   * Searches for the first occurence of the given argument between the given startIndex and endIndex
   * @author Liron Aravot
   */
   public int indexOfWithStartEndIndex(byte[] subarray, int startIndex, int endIndex) {
         temp.location = -1;
         temp.foundBytes = 0;
         temp.watchWord = subarray;
         int subArrayOrigLength = subarray.length;
         // indicating the 'true' end index of the array if it wasn't
         int trueEndIndex = start + endIndex ;
         
         if (trueEndIndex > array.length && this.end > this.start) trueEndIndex = array.length - 1;
         // indicating the true start index for the search
         int trueStartIndex =  start + startIndex;
         
         // value to return
         int toReturn = -1;
         // 
                // if the array is 'rotated' - which means some of the elements
                // are between 'start' and array.length and some are between 0 and 'end'
                if (trueEndIndex > array.length) {
                        // if the true start index is higher then the array length, we need to check only the
                        // part between this index and 'end'
                        if (trueStartIndex > array.length) {
                                // search between the needed start index and the array length
                                toReturn = indexOfWithStartIndex(subarray,trueStartIndex-(array.length), endIndex-(array.length - start));
                                if (toReturn != -1) {
                                        toReturn += array.length - start;
                                        return toReturn;
                                }

                        }
                        else
                        {//Once there is a need to check till end of file and to check from new start of file (0) till endIndex-(array.length-start) 
                                indexOfWithStartIndexAndStartInWordIndex(subarray,temp,start+startIndex, array.length);
                                if (temp.foundBytes < subarray.length) 
                                {
                                        if (temp.foundBytes > 0) 
                                        {
                                                temp.location -= start;
                                        } 
                                        indexOfWithStartIndexAndStartInWordIndex(subarray,temp,0, endIndex-(array.length-start));
                                        if (temp.location != -1 && subarray.length == temp.foundBytesInCurrentIneration) 
                                        {
                                                temp.location += array.length - start;
                                        }
                                        return temp.location;
                                } 
                                else 
                                {
                                        temp.location -= start;
                                        return temp.location;
                                }
                        }
                }
        // we should look only from the start index till the end index.
         else
         {
        
                toReturn = indexOfWithStartIndex(subarray, start+ startIndex, trueEndIndex);
                if (toReturn != -1)
                        toReturn -= start;
                return toReturn;
         }

        return toReturn;
  }//EOM indexOf
   
   
   
   
   
        /**
   * Searches for the first occurence of the given argument between the given startIndex and endIndex
   * this version is using mod calculation to get the correct index for checking, and there might be 
   * with worse performance - check needed to be done
   * @author Liron Aravot
   */
   public int indexOfWithStartEndIndexWithModulo(byte[] subarray, int startIndex, int endIndex) {

        int toReturn  = -1;
        // cacl actual start/end indexes for the search
        startIndex += start;
        endIndex += start;
        // actual index in the rotating array for checking
        int intAfterModIndex = 0;
        // search for the given word
    for (int i = startIndex; i < endIndex ; i++) 
    {
        boolean found = true;
        
        if (i + subarray.length > endIndex) 
        {
            break;
        }
        for (int j = 0; j < subarray.length; j++) {
                intAfterModIndex = (i+j) / this.size;
            final byte a = array[intAfterModIndex];
            final byte b = subarray[j];
            if (a != b) {
                found = false;
                break;
            }
        }
        if (found) 
        {
                toReturn = i;
            return toReturn;
        }
    }//for

    return toReturn;
  }//EOM indexOf
   
  
      public int getStart() {
                        return start;
                }

                public void setStart(int start) {
                        this.start = start;
                }

                public int getEnd() {
                        return end;
                }

                public void setEnd(int end) {
                        this.end = end;
                }











        /**
 * @author liron.aravot
 * class to be used as response - contains word, its found index and the number
 * of found bytes.
 */
public class FindWordResponse
  {
        byte[] watchWord = null;
        int location = -1;
        int foundBytes = 0;
        int foundBytesInCurrentIneration = 0;
        
        
        public int getFoundBytes() {
                return foundBytes;
        }
        public void setFoundBytes(int foundBytes) {
                this.foundBytes = foundBytes;
        }
        
        public byte[] getWatchWord() {
                return watchWord;
        }
        public void setWatchWord(byte[] watchWord) {
                this.watchWord = watchWord;
        }
        public Integer getLocation() {
                return location;
        }
        public void setLocation(Integer location) {
                this.location = location;
        }
        
        public int getFoundBytesInCurrentIneration() {
                return foundBytesInCurrentIneration;
        }
        public void setFoundBytesInCurrentIneration(int foundBytesInCurrentIneration) {
                this.foundBytesInCurrentIneration = foundBytesInCurrentIneration;
        }
        
  }
  
    /**
   * Searches for the first occurence of any of the given words
   * @author Liron Aravot
   */
  public FindWordResponse indexOfFirstAppearingWord(ArrayList<byte[]> words, int startIndex) {
          byte[] copyArray =  Arrays.copyOf(array, array.length);
          int copyStart = start;
         return this.indexOfFirstAppearingWord(words, startIndex, this.size , copyArray , copyStart);
  }//EOM indexOf
  

  public boolean startPointerApproachingEndOfBuffer(){
          return  getEnd()  - getStart() < START_POINTER_NEAR_END_OF_BUFFER;
  }
  
        /**
   * Searches for the first occurrence of any of the given byte arrays in the given byte array, returns the first 
   * found word and sets location to it's index.
   */
        @Deprecated
        private FindWordResponse indexOfFirstWordWithStartIndex(int startIndex, int endIndex,
                        ArrayList<byte[]> watchWords) {
                return null;
        }
  
   /**
   * Searches for the first occurrence of the given argument, starting from the given index
   * @author lirona
  */
  private int indexOfWithStartIndex(byte[] subarray, int startIndex, int endIndex) 
  {
        int toReturn  = -1;
        int i = startIndex >=  0 ? startIndex: 0;
        for (; i < endIndex ; i++) 
    {
        boolean found = true;
        
        if (i + subarray.length > endIndex) 
        {
        	found = ((i -  startIndex+1) == subarray.length);
            break;
        }
        for (int j = 0; j < subarray.length; j++) {
                if (i + j >= array.length -1){
                found = false;
                break;
            }  
                final byte a=array[i + j];
                final byte b = subarray[j];
            if (a != b) {
            	found = false;
                break;
            }
        }
        if (found) 
        {
                toReturn = i;
            return toReturn;
        }
    }//for

    return toReturn;
  }//EOM indexOfWithStartIndex
  
  
  

  /**
   * The method receives a word and start end indexes, the index of the found word will be returned
   * in the response given variable.
 * @param subarray - word
 * @param response - response to edit with the found index
 * @param startIndex - start index to look from
 * @param endIndex - end index to look from
 */
private void indexOfWithStartIndexAndStartInWordIndex(byte[] subarray,FindWordResponse response, int startIndex, int endIndex) 
  {
          response.watchWord = subarray;
          response.foundBytesInCurrentIneration = 0;
    for (int i = startIndex; i < endIndex ; i++) 
    { 
        int tempVariable = response.foundBytes;
        for (int j = 0; j+tempVariable < subarray.length; j++) {
                if (i+j >= array.length)
                {
                	return;
                }
            final byte a = array[i + j];
            final byte b = subarray[response.foundBytes];
            if (a != b) {
                response.foundBytes = 0;
                response.foundBytesInCurrentIneration = 0;
                response.location = -1;
                break;
            }
            else
            {
                if (response.location == -1) response.location = i;
                response.foundBytes++;
                response.foundBytesInCurrentIneration++;
                if (response.foundBytes == subarray.length)
                        return;
            }
        }

    }//for
    return;
  }//EOM indexOfWithStartIndex





        private FindWordResponse indexOfWithStartIndexAndStartInWordSIndex(
                        ArrayList<byte[]> subarrays, ArrayList<FindWordResponse> responses,
                        int startIndex, int endIndex) {
                FindWordResponse response= null;;
                FindWordResponse toReturn= null;;
                byte[] subarray = null;
                for (int k = 0; k < subarrays.size(); k++) {
                        response=responses.get(k);
                        subarray = subarrays.get(k);
                        for (int i = startIndex; i < endIndex; i++) {
                                // if (i + subarray.length > endIndex)
                                // {
                                // break;
                                // }
                                int tempVariable = response.foundBytes;
                                for (int j = 0; j + tempVariable < subarray.length; j++) {
                                        if (i + j >= array.length)
                                                break;
                                        final byte a = array[i + j];
                                        final byte b = subarray[response.foundBytes];
                                        if (a != b) {
                                                response.foundBytes = 0;
                                                response.location = -1;
                                                break;
                                        } else {
                                                if (response.location == -1)
                                                {
                                                        response.location = i;
                                                }
                                                response.foundBytes++;
                                                if (response.foundBytes == subarray.length)
                                                {
                                                        toReturn = response;
                                                        return toReturn;
                                                }
                                        }
                                }

                        }// for
                }
                return toReturn;
        }// EOM indexOfWithStartIndex





/**
 * searches for appearance of first word in the buffer
 * @param words
 * @param startIndex
 * @param endIndex
 * @param copyArray
 * @param copyStart
 * @return FindWordResponse wrapping the 1st found word
 */
public FindWordResponse indexOfFirstAppearingWord(ArrayList<byte[]> words, int startIndex, int endIndex , byte[] copyArray , int  copyStart)
  {
        // new response for return
        this.temp.watchWord = null;
        this.temp.location = -1;
        this.temp.foundBytes = 0;
        
        byte[] bestArray  =  Arrays.copyOf(copyArray, copyArray.length);
        int bestStart = copyStart;
        
        
        int tempBestLocation= endIndex;
        int bestLocation = endIndex;
        byte[] tempBestWord = null;
        
        for (int i=0; i<words.size(); i++)
        {
                this.array = Arrays.copyOf(copyArray, copyArray.length);;
                this.start = copyStart;
                //tempBestLocation = this.indexOfWithStartEndIndex(words.get(i),startIndex - words.get(i).length , bestLocation);
                tempBestLocation = this.indexOfWithStartEndIndex(words.get(i),startIndex  , bestLocation);
                if (tempBestLocation != -1 &&  (tempBestLocation < bestLocation))
                {
                        bestLocation = tempBestLocation;
                        tempBestWord = words.get(i);
                        bestArray  =  Arrays.copyOf(copyArray, copyArray.length);
                        bestStart = start;
                }
        }
        this.temp.watchWord = tempBestWord;
        this.temp.location = bestLocation;
        this.array = Arrays.copyOf(bestArray, bestArray.length);
        this.start = bestStart;
        
        if (temp.watchWord == null) {
                this.temp.foundBytes = 0;
                this.array = Arrays.copyOf(copyArray, copyArray.length);
                this.start = copyStart;
                this.temp.location = -1;
        }else {
                this.temp.foundBytes = temp.watchWord.length;
        }
        
        return temp;
  }//EOM indexOfWithStartIndex



  /**
   * Tests if this list has no elements.
   */
  public boolean isEmpty() {
    return size == 0;
  }
  
 


//  // ---------------------------------------------------------------- capacity
//
  /**
   * Increases the capacity of this ArrayList instance, if necessary,
   * to ensure that it can hold at least the number of elements specified by
   * the minimum capacity argument.
   */
  @Deprecated
  public void ensureCapacity(int mincap) {
    if (mincap > array.length) {
      int newcap = ((array.length * 3) >> 1) + 1;
      byte[] olddata = array;
      array = new byte[newcap < mincap ? mincap : newcap];
      System.arraycopy(olddata, 0, array, 0, size);
    }
  }


  // ---------------------------------------------------------------- privates
 @Deprecated
  private void checkRange(long index) {
    if (index < 0 || index > size) {
      throw new IndexOutOfBoundsException("Index should be at least 0 and less than " + size + ", found " + index);
    }
  }


}