package backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.namespace.QName;
import javax.xml.stream.XMLStreamException;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.core.paymentprocess.data.paymenttypes.PaymentType;

/**
 * This interface represents the file message data types for both multi and single message types.
 * It main purpose is to retrieve the file message type tags.
 * 
 * TODO
 * For a moment fits Pain01 structure
 * Change it!!!
 *
 * @author haimv
 * @author dmitryp
 */
public interface FileMessageTypeData{
	
	public String getMultiFileStartTag();
	
	public String getMultiFileEndTag();
	
	public String getTypeIdentifier();

	public String getGrpHdrStartTag();

	public String getGrpHdrEndTag();
	
	public String getRootElement();
	
	public void initTags(PaymentType paymentType);
	/**
	 * For single type only - for multi we already have it in each type
	 */
	public String getTransactionStartTag();
	public byte[] getTransactionStartTagBytes();

	/**
	 * For single type only - for multi we already have it in each type 
	 */
	public String getTransactionEndTag();
	public byte[] getTransactionEndTagBytes();

	/**
	 * For single type only - for multi we already have it in each type 
	 */	
	public String getPaymentTypeName();

	public XmlTransactionReaderBase getReader(File file, int chunkSize);
	public XmlTransactionReaderBase getReader();
	
	
	//PAIN_01
	public String getDocumentElementStartTag();
	
	public String getPreDocumentEnd();
	public String getPrePmtInfEnd();
	
	public String getPaymentInfoElementStartTag();
	public byte[] getPaymentInfoElementStartTagBytes();
	
	public String getPaymentInfoElementEndTag();	
	public byte[] getPaymentInfoElementEndTagBytes();
	
	public String getDocumentElementEndTag();
	
	
	//public byte[] getGrpHdrStartTagBytes();

	//public byte[] getGrpHdrEndTagBytes();
	public String getXmlClosingTags();
	public String getXmlStartingTags();
	
	String getMultiPaymentGroupingTagStart();
	
	String getMultiPaymentGroupingTagEnd();
	
	
	public void formatTags(String namespace);
	public String getWorkflow();
	
	public static class Factory{
		private static final Logger logger = LoggerFactory.getLogger(FileMessageTypeData.Factory.class);
		
		/**
		 * Factory method for FileMessageTypeData.
		 * It will read first 200 bytes of the input file and return the FileMessageTypeData according to it.  
		 * 
		 * @param file
		 * @param messageDataTypes
		 * @return
		 * @throws IOException
		 */
		public static FileMessageTypeData getFileMessageTypeData(File file) throws IOException {
			String messageSnippet = XmlParsingHelper.readHead(file,1024*2);
			
			if(FndtBatchMsgSupport.isFndtBulkBatchMsg(messageSnippet)) 
				return new FndtBatchMsg_MultiTypeBatch();
			
			if(FndtBatchMsgSupport.isFndtBatchMsg(messageSnippet)) 
				return new FndtBatchMsg_SingleTypeBatch();
			
			QName qname = XmlParsingHelper.extractRootNamespace(messageSnippet);
			
			if (qname == null) 
				throw new RuntimeException("couldn't determine the File Message Data Type");
			
			return getFileMessageTypeData(qname);			
		}

		public static FileMessageTypeData getFileMessageTypeData(QName qname) {
			FileMessageTypeData dataType = (FileMessageTypeData)PaymentType.valueOf(qname).getTrnsReaderNewInstance();
				
			logger.debug("qname: {}, file message data type: {}",qname,dataType);
			
			return dataType;
		}
		
		public static FileMessageTypeData getFileMessageTypeData(String paymentType) {
			FileMessageTypeData dataType = (FileMessageTypeData)PaymentType.valueOf(paymentType).getTrnsReaderNewInstance();
				
			logger.debug("payment type: {}, file message data type: {}",paymentType,dataType);
			
			return dataType;
		}
	}//Factory
	
	
	
	
}//EOC FileMessageTypeData