package backend.paymentprocess.debulkingprocess.ejbinterfaces;

import com.fundtech.core.general.flows.FlowException;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.SimpleResponseDataComponent;
import javax.ejb.Remote;

@Remote
public abstract interface DebulkFile
{
  public static final String REMOTE_JNDI_NAME = "ejb/DebulkFileBean";

  public abstract SimpleResponseDataComponent debulkFile(Admin paramAdmin, String paramString)
    throws FlowException;

  public abstract SimpleResponseDataComponent debulkString(Admin paramAdmin, String paramString)
    throws FlowException;

  public abstract SimpleResponseDataComponent debulkFileByIndex(Admin paramAdmin, String paramString)
    throws FlowException;

  public abstract SimpleResponseDataComponent debulkStringByIndex(Admin paramAdmin, String paramString)
    throws FlowException;

  public abstract SimpleResponseDataComponent redebulkFileByIndex(Admin paramAdmin, String paramString)
    throws FlowException;
  
  public  SimpleResponseDataComponent createChunksForRejectedFile(Admin paramAdmin, String internalFileId) 
		  throws Throwable;
}

/* Location:           C:\Documents and Settings\ofer.baranes\Desktop\OCBC\MassPayment\RND_import\classes\debulkingprocess\ejbinterfaces\
 * Qualified Name:     backend.paymentprocess.debulkingprocess.ejbinterfaces.DebulkFile
 * JD-Core Version:    0.6.0
 */