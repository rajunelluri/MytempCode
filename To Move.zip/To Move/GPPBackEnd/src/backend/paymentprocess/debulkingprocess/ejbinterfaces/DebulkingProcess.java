package backend.paymentprocess.debulkingprocess.ejbinterfaces;

import com.fundtech.core.general.flows.FlowException;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.datacomponent.response.SimpleResponseDataComponent;
import javax.ejb.Remote;

@Remote
public abstract interface DebulkingProcess
{
  public static final String REMOTE_JNDI_NAME = "ejb/DebulkingProcessBean";

  public abstract SimpleResponseDataComponent performDebulkPreProcessing(Admin paramAdmin, String paramString)
    throws FlowException;

  public abstract Feedback performAccumulations(Admin paramAdmin, String paramString)
    throws FlowException;

  public abstract SimpleResponseDataComponent performDebulkMultiPreProcessing(Admin paramAdmin, String paramString)
    throws FlowException;

  public abstract SimpleResponseDataComponent performDebulkMultiPreProcessingForWaitingPayments(Admin paramAdmin, String paramString)
    throws FlowException;

  public abstract SimpleResponseDataComponent performAckDebulkPreProcessing(Admin paramAdmin, String paramString)
    throws FlowException;
}

/* Location:           C:\Documents and Settings\ofer.baranes\Desktop\OCBC\MassPayment\RND_import\classes\debulkingprocess\ejbinterfaces\
 * Qualified Name:     backend.paymentprocess.debulkingprocess.ejbinterfaces.DebulkingProcess
 * JD-Core Version:    0.6.0
 */