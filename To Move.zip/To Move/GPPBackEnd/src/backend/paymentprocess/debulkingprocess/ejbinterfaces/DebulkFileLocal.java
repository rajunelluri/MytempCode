package backend.paymentprocess.debulkingprocess.ejbinterfaces;

import javax.ejb.Local;

@Local
public abstract interface DebulkFileLocal extends DebulkFile
{
}

/* Location:           C:\Documents and Settings\ofer.baranes\Desktop\OCBC\MassPayment\RND_import\classes\debulkingprocess\ejbinterfaces\
 * Qualified Name:     backend.paymentprocess.debulkingprocess.ejbinterfaces.DebulkFileLocal
 * JD-Core Version:    0.6.0
 */