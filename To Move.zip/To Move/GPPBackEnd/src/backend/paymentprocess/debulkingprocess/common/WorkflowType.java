package backend.paymentprocess.debulkingprocess.common;

import static backend.core.module.MessageConstantsInterface.MESSAGE_STATUS_COMPLETE;
import static backend.core.module.MessageConstantsInterface.MESSAGE_STATUS_SCHEDULE;
import static backend.core.module.MessageConstantsInterface.MESSAGE_STATUS_WAITSUBBATCH;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_IN_INTERNAL_FILEID;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_MSG_STS;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_UNIQUE_GROUPING_ID;

import static com.fundtech.util.GlobalUtils.isNullOrEmpty;


import java.io.File;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.xmlbeans.XmlCursor;

import backend.businessobject.BOProxies;
import backend.core.module.MessageConstantsInterface;
import backend.core.module.security.businessobjects.BOFileSecurity;
import backend.core.module.security.businessobjects.BOSecurity;
import backend.paymentprocess.SubBatchProcessInterface;
import backend.paymentprocess.baseprocess.businessobjects.BOBaseProcess;
import backend.paymentprocess.debulkingprocess.businessobjects.BODebulkFile;
import backend.paymentprocess.debulkingprocess.businessobjects.BOMassPayment.StoreRequest;
import backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi.FileMessageTypeData;
import backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi.RandomAccessFileUtils;
import backend.paymentprocess.enrichment.commons.InterfaceSubTypeFlow;
import backend.paymentprocess.highvalueprocess.businessobjects.BOHighValueProcess;
import backend.paymentprocess.interfaces.common.TransmissionType;
import backend.paymentprocess.mopselection.common.MsgClassType;
import backend.paymentprocess.rebulking.businessobject.BORebulkProcess.RebulkFileData;
import backend.paymentprocess.subbatchcompletion.businessobjects.BOSubBatchCompletion;
import backend.util.ServerConstants;
import backend.util.ServerUtils;

import com.fundtech.cache.entities.CurrencyBu;
import com.fundtech.cache.entities.FileSummary;
import com.fundtech.cache.entities.LogicalFieldsXpath;
import com.fundtech.cache.entities.MsgTypes;
import com.fundtech.cache.entities.PreProcessAccumulations;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.cache.infrastructure.regions.CacheKeys.ProcessPdoPerUniqueGroupIdKey.ProcessPdoPerGroupIdEntry;
import com.fundtech.core.general.flows.FlowException;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.core.paymentprocess.data.DefaultDeepPDOCloneHandler.CloningContext;
import com.fundtech.core.paymentprocess.data.das.DASInterface;
import com.fundtech.core.paymentprocess.data.paymenttypes.PaymentType;
import com.fundtech.core.paymentprocess.errorhandling.BusinessException;
import com.fundtech.core.security.Admin;
import com.fundtech.core.security.Admin.CallSource;
import com.fundtech.datacomponent.request.UserCredentials;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.scl.commonTypes.FndtBatchMsgType;
import com.fundtech.scl.commonTypes.FndtMsgBatchDocument;
import com.fundtech.scl.commonTypes.FndtMsgExtensionType;
import com.fundtech.scl.commonTypes.FndtMsgType;
import com.fundtech.scl.commonTypes.ProcessingPersistentInfoType;
import com.fundtech.scl.commonTypes.UserContextType;
import com.fundtech.scl.debulkingProcessService.FileIndexDataType;
import com.fundtech.scl.debulkingProcessService.PerformDebulkingMultiRequestDocument;
import com.fundtech.scl.debulkingProcessService.PreStartDataType;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalDateTimeUtil;
import com.fundtech.util.GlobalFileUtil;
import com.fundtech.util.GlobalUtils;
import com.fundtech.util.GlobalConstants.LoginModeType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public enum WorkflowType
{
	
	

	Template
	{

		public PDO[] executeFlow(String sXmlChunk, String internalFileID, String chunkId,
				  double[] stlmAmt,double[] stlmAmtDuplicate, double[] stlmAmtRejected,double[] stlmAmtRepair, int[] duplicateCount,int[] rejectedCount,int[] repairCount,
				  final FileSummary fileSummary, List<PDO> persistentPdoList, final Map[] arrMapSharedPDOContextHolder, Map<String, StoreRequest> requestMap, Feedback feedback) throws Throwable
		  {
//			  FndtBatchMsgType fndMsgType = FndtBatchMsgType.Factory.parse(chunk);

//			  MessageSubmitRequestDocument doc = MessageSubmitRequestDocument.Factory.parse(chunk);

			  FndtMsgBatchDocument doc = FndtMsgBatchDocument.Factory.parse(sXmlChunk);
			  UserContextType credentialsXbean = doc.getFndtMsgBatch().getFndtHeader().getCredentials();
			  String userId = credentialsXbean == null ? CallSource.File.name() : credentialsXbean.getUserID();
			  String role = credentialsXbean == null ? CallSource.File.name() : credentialsXbean.getRole();
				final Admin admin = newContextAdmin(userId, CallSource.File);

				String handledPDODataPrefix = "Debulking process for message submit service";
				UserCredentials userCredentials = new UserCredentials(userId, LoginModeType.FILE, null, null) ;
				userCredentials.setAdditionalParam(UserCredentials.KEY_ROLE_NAME, role);
				feedback.setFeedback(m_security.login(userCredentials).getFeedback());

				if (feedback.m_bIsSuccessful)
				{

					FndtBatchMsgType batchMsgType = (FndtBatchMsgType)doc.getFndtMsgBatch();
					batchMsgType.getFndtHeader().setDSKIPPERSISTONERROR(false);
//					set internal file id for all payments.
					for (FndtMsgType fndMsg : batchMsgType.getFndtPmntTxInf().getFndtMsgArray())
					{
						FndtMsgExtensionType extn = fndMsg.getMsg().getExtn();
						ProcessingPersistentInfoType info =extn.getProcessingPersistentInfo();
						info.setPININTERNALFILEID(internalFileID);
						info.setPCHUNKID(chunkId);
						if (extn.getOperationalSection() == null ) extn.addNewOperationalSection();
						extn.getOperationalSection().setDBUTTONID("Submit");
						info.setPISHISTORY(2);
					}
//					if (m_messageHandle == null) m_messageHandle = ServiceLocator.getInstance().SLSBlookup(MessageHandle.class);
					Object response = BOProxies.m_messageHandleLogging.submitMessageService(admin, (Serializable)doc.getFndtMsgBatch());

					if (response instanceof FndtBatchMsgType)
					{
						batchMsgType = (FndtBatchMsgType)response;

						for (FndtMsgType fndMsg : batchMsgType.getFndtPmntTxInf().getFndtMsgArray())
						{
							String mid = fndMsg.getHeader().getPMID().getStringValue();
							PDO pdo = PaymentDataFactory.load(mid);
							performFinalStep(pdo, handledPDODataPrefix, stlmAmt, stlmAmtDuplicate, stlmAmtRejected, stlmAmtRepair,duplicateCount, rejectedCount, repairCount,internalFileID, chunkId,null,
									requestMap, feedback);
						}

					}else if (response instanceof Feedback)
					{
						feedback.setFeedback((Feedback)response);
					}
				}


				return null;
			 }


	}
	,
	File
	{
		public PDO[] executeFlow(String sXmlChunk, String internalFileID, String chunkId,
				  double[] stlmAmt,double[] stlmAmtDuplicate, double[] stlmAmtRejected,double[] stlmAmtRepair,int[] duplicateCount,int[] rejectedCount,int[] repairCount,
				  final FileSummary fileSummary, List<PDO> persistentPdoList, final Map[] arrMapSharedPDOContextHolder, Map<String, StoreRequest> requestMap, Feedback feedback) throws Throwable
		  {
//			  FndtBatchMsgType fndMsgType = FndtBatchMsgType.Factory.parse(chunk);

//			  MessageSubmitRequestDocument doc = MessageSubmitRequestDocument.Factory.parse(chunk);

			  FndtMsgBatchDocument doc = FndtMsgBatchDocument.Factory.parse(sXmlChunk);
			  
			  UserContextType credentialsXbean = doc.getFndtMsgBatch().getFndtHeader().getCredentials();
			  String userId = credentialsXbean == null ? CallSource.File.name() : credentialsXbean.getUserID();
			  String role = credentialsXbean == null ? CallSource.File.name() : credentialsXbean.getRole();
				final Admin admin = newContextAdmin(userId, CallSource.File);

				String handledPDODataPrefix = "Debulking process for message submit service";
				UserCredentials userCredentials = new UserCredentials(userId, LoginModeType.FILE, null, null) ;
				userCredentials.setAdditionalParam(UserCredentials.KEY_ROLE_NAME, role);
				feedback.setFeedback(m_security.login(userCredentials).getFeedback());

				if (feedback.m_bIsSuccessful)
				{

					FndtBatchMsgType batchMsgType = (FndtBatchMsgType)doc.getFndtMsgBatch();
					batchMsgType.getFndtHeader().setDSKIPPERSISTONERROR(false);
//					set internal file id for all payments.
					for (FndtMsgType fndMsg : batchMsgType.getFndtPmntTxInf().getFndtMsgArray())
					{
						FndtMsgExtensionType extn = fndMsg.getMsg().getExtn();
						ProcessingPersistentInfoType info =extn.getProcessingPersistentInfo();
						if (info == null)
							info = extn.addNewProcessingPersistentInfo();
						info.setPININTERNALFILEID(internalFileID);
						info.setPCHUNKID(chunkId);
						if (extn.getOperationalSection() == null ) extn.addNewOperationalSection();
						extn.getOperationalSection().setDBUTTONID("Submit");
					}
//					if (m_messageHandle == null) m_messageHandle = ServiceLocator.getInstance().SLSBlookup(MessageHandle.class);
					Object response = BOProxies.m_messageHandleLogging.submitMessageService(admin, (Serializable)doc.getFndtMsgBatch());

					if (response instanceof FndtBatchMsgType)
					{
						batchMsgType = (FndtBatchMsgType)response;

						for (FndtMsgType fndMsg : batchMsgType.getFndtPmntTxInf().getFndtMsgArray())
						{
							String mid = fndMsg.getHeader().getPMID().getStringValue();
							PDO pdo = PaymentDataFactory.load(mid);
							performFinalStep(pdo, handledPDODataPrefix, stlmAmt, stlmAmtDuplicate, stlmAmtRejected, stlmAmtRepair,duplicateCount, rejectedCount, repairCount,internalFileID, chunkId,null,requestMap
									, feedback);
						}

					}else if (response instanceof Feedback)
					{
						feedback.setFeedback((Feedback)response);
					}
				}


				return null;
			 }

	}
	,Pacs_004
	{


		public List<PDO> getPDOsFromChunk(String sXmlChunk, String chunkId, String sInternalFileID, final FileSummary fileSummary , final Map[] arrMapSharedPDOContextHolder) throws Throwable
		{
			return SWIFT.getPDOsFromChunk(sXmlChunk, chunkId, sInternalFileID, fileSummary, arrMapSharedPDOContextHolder);
		}

		public List<PDO> getPDOsFromChunk(PerformDebulkingMultiRequestDocument doc, String chunkId, String sInternalFileID, final FileSummary fileSummary , final Map[] arrMapSharedPDOContextHolder) throws Throwable
		{
			return SWIFT.getPDOsFromChunk(doc, chunkId, sInternalFileID, fileSummary, arrMapSharedPDOContextHolder);
		}


		@Override
		protected PDO[] executeFlowInner(List<PDO> pdoList, String internalFileId, String chunkId, double[] stlmAmt,double[] stlmAmtDuplicate, double[] stlmAmtRejected, double[] stlmAmtRepair,
					int[] duplicateCount, int[] rejectedCount,int[] repairCount,List<PDO> persistentPdoList, Map<String, StoreRequest> requestMap, Feedback feedback) throws Throwable
		{
			// TODO Auto-generated method stub
		      int iChunkSize = pdoList.size();
		      PDO[] pdoArr = new PDO[iChunkSize];
		      int i = 0;
		      String sHandledPDODataPrefix = null;

		      for(PDO pdo: pdoList)
		      {
		      	String mid = pdo.getMID();
		      	sHandledPDODataPrefix = String.format("Debulking process for PDO %s out of %s - MID: %s, Chunk ID: %s, PDO ID: %s; ", (i+1), iChunkSize, mid, chunkId, pdo);

		        pdo.set(PDOConstantFieldsInterface.P_IN_INTERNAL_FILEID, internalFileId);
		        pdo.set(PDOConstantFieldsInterface.P_CHUNK_ID, chunkId);
		        pdo.set(PDOConstantFieldsInterface.P_BATCH_MSG_TP, "I");
//		        pdo.set(P_OFFICE, office);
		        pdo.promoteToPrimary();
		        feedback = BOProxies.m_setBasicPropertiesLogging.setBasicProperties(Admin.getContextAdmin(), pdo.getMID());
//		        pdo.set(P_DEPARTMENT, department);
		        if (feedback.m_bIsSuccessful)
		        {
			        String sOldStatus = pdo.getString(PDOConstantFieldsInterface.P_MSG_STS);
			        logger.info(sHandledPDODataPrefix + "executes base processing; PDO Status: %s", sOldStatus);
			//
			      	  if (GlobalUtils.isNullOrEmpty(pdo.getString(PDOConstantFieldsInterface.P_DISPLAY_MSG_TYPE)))
			      	  {
								MsgTypes msgTypes = CacheKeys.msgTypesKey.getSingle(pdo.getString(PDOConstantFieldsInterface.P_MSG_TYPE), ServerConstants.EMPTY_STRING);
								String sDisplayMsgType = msgTypes != null ? msgTypes.getDisplayMsgType() : "NMT";
								pdo.set(PDOConstantFieldsInterface.P_DISPLAY_MSG_TYPE, !isNullOrEmpty(sDisplayMsgType) ? sDisplayMsgType : msgTypes.getMsgType());

			      	  }
			          feedback = BOProxies.m_incomingRejectReturnLocalLogging.handleIncomingRejectReturn(Admin.getContextAdmin(), mid);
			          String sNewStatus = pdo.getString(PDOConstantFieldsInterface.P_MSG_STS);
			          logger.info(sHandledPDODataPrefix + "finished base processing; Old Status: %s, New status: %s, Feedback: %s",new Object[]{ sOldStatus, sNewStatus, ServerUtils.getFeedbackString(feedback)});
		        }
//		        PDO has to be committed to DB.
		        persistentPdoList.add(pdo);
		      }

		      logger.info(sHandledPDODataPrefix + "finished handling for this message");

		      return pdoArr;
		}

	}//Pacs_004

	,Pacs_008
	{
		String endOfFileTags = null;
		public PDO[] executeFlow(String sXmlChunk, String internalFileID, String chunkId,
				  double[] stlmAmt,double[] stlmAmtDuplicate, double[] stlmAmtRejected,double[] stlmAmtRepair,int[] duplicateCount,int[] rejectedCount,int[] repairCount,
				  final FileSummary fileSummary, List<PDO> persistentPdoList, final Map[] arrMapSharedPDOContextHolder, Map<String, StoreRequest> requestMap, Feedback feedback) throws Throwable
		  {
			return SWIFT.executeFlow(sXmlChunk, internalFileID, chunkId, stlmAmt, stlmAmtDuplicate, stlmAmtRejected,stlmAmtRepair,
					duplicateCount, rejectedCount, repairCount,fileSummary, persistentPdoList, arrMapSharedPDOContextHolder, requestMap, feedback);
		  }


		public List<PDO> getPDOsFromChunk(String sXmlChunk, String chunkId, String sInternalFileID, final FileSummary fileSummary , final Map[] arrMapSharedPDOContextHolder) throws Throwable
		{
			return SWIFT.getPDOsFromChunk(sXmlChunk, chunkId, sInternalFileID, fileSummary, arrMapSharedPDOContextHolder);
		}



		public PDO[] executeFlow(PerformDebulkingMultiRequestDocument doc, String internalFileID, String chunkId,
				  double[] stlmAmt,double[] stlmAmtDuplicate, double[] stlmAmtRejected,double[] stlmAmtRepair,int[] duplicateCount,int[] rejectedCount,int[] repairCount,
				  final FileSummary fileSummary, List<PDO> persistentPdoList, final Map[] arrMapSharedPDOContextHolder, Map<String, StoreRequest> requestMap,
				  Feedback feedback) throws Throwable
				  {
					return SWIFT.executeFlow(doc, internalFileID, chunkId, stlmAmt, stlmAmtDuplicate, stlmAmtRejected,stlmAmtRepair,
							duplicateCount, rejectedCount, repairCount,fileSummary, persistentPdoList, arrMapSharedPDOContextHolder,requestMap, feedback);
				  }


		public List<PDO> getPDOsFromChunk(PerformDebulkingMultiRequestDocument doc, String chunkId, String sInternalFileID, final FileSummary fileSummary , final Map[] arrMapSharedPDOContextHolder) throws Throwable
		{
			return SWIFT.getPDOsFromChunk(doc, chunkId, sInternalFileID, fileSummary, arrMapSharedPDOContextHolder);
		}

		@Override
		public String getOutFileHeader(RebulkFileData rebulkFileData, PDO pdo) {

			PaymentType paymentType = PaymentType.valueOf(PaymentType.PT_MULTI_TYPE1);
		    final Map mapLogicalFieldsXPathCache = CacheKeys.LogicalFieldsXPathKey.getSingle(paymentType);
			//final LogicalFieldsXpath logicalFieldsXpath = (LogicalFieldsXpath) mapLogicalFieldsXPathCache.get(PDOConstantFieldsInterface.X_GRP_INFO) ;
			final LogicalFieldsXpath logicalFieldsXpath = (LogicalFieldsXpath) mapLogicalFieldsXPathCache.get(PDOConstantFieldsInterface.X_FITOFI_CSTMRCDTTRF) ;

		    //String sSystemDate = GlobalDateTimeUtil.getSTATIC_DATA_XML_DATE_TIME_SimpleDateFormat().format(new Date());
			String sSystemDate = GlobalDateTimeUtil.dateTimeToStaticDataXMlString(new Date());
		    String sLineSeparator = System.getProperty("line.separator");

		    StringBuilder sbFileHeader = new StringBuilder();

		    //Liron Additions:
		    // creat dummy PDO for getting generically the needed file header.


		    PDO dummyPDO = PaymentDataFactory.newPDO(paymentType);
		    dummyPDO.set(PDOConstantFieldsInterface.X_SNDG_INST,rebulkFileData.getLocalOfficeBic());
			dummyPDO.set(PDOConstantFieldsInterface.X_RCVG_INST,rebulkFileData.getReceivingInst());
			dummyPDO.set(PDOConstantFieldsInterface.X_FILE_REF,rebulkFileData.getFileReference());
			dummyPDO.set(PDOConstantFieldsInterface.X_SRVC_ID,"IDF".equals(rebulkFileData.getsPL_FileType()) ? "SDD" : "SCT");
			dummyPDO.set(PDOConstantFieldsInterface.X_TST_CODE,rebulkFileData.getProdTestCode());
			dummyPDO.set(PDOConstantFieldsInterface.X_FTYPE,rebulkFileData.getsPL_FileType());

			dummyPDO.set(PDOConstantFieldsInterface.X_FDTTM,sSystemDate);
			dummyPDO.set(PDOConstantFieldsInterface.X_NUM_CT_BLK,"1");
			dummyPDO.set(PDOConstantFieldsInterface.X_NUM_PCR_BLK,"0");
			dummyPDO.set(PDOConstantFieldsInterface.X_NUM_RFR_BLK,"0");
			dummyPDO.set(PDOConstantFieldsInterface.X_NUM_ROI_BLK,"0");



			XmlCursor cur = dummyPDO.getXmlDocumentsMap().get("XML_MSG").getXml().newCursor();
			cur.toParent();
			cur.getObject();
			LogicalFieldsXpath xpath = (LogicalFieldsXpath)CacheKeys.LogicalFieldsXPathKey.getSingle(paymentType).get(PDOConstantFieldsInterface.X_NUM_ROI_BLK);
			try {
				PaymentDataFactory.formatPDO(dummyPDO);
			} catch (BusinessException e) {
				// TODO
				logger.error(e.getMessage());
			}

			sbFileHeader.append(cur.getObject());
			cur.dispose();
			String tmp = xpath.getTagName();
			int closureTagIndexTemp = sbFileHeader.lastIndexOf(tmp) + tmp.length() +1;
			int closureTagIndex = sbFileHeader.indexOf(">", closureTagIndexTemp -1) +1;
			// init the end of file tags by the given end of file
			endOfFileTags = "</" + logicalFieldsXpath.getTagName() + ">" + sbFileHeader.substring(closureTagIndex, sbFileHeader.length());
			sbFileHeader.delete(closureTagIndex, sbFileHeader.length());


		    // ** end of liron additions


//		    sbFileHeader.append("<?xml version=\"1.0\" encoding=\"utf-8\"?>").append(sLineSeparator);
//		    sbFileHeader.append("<S2SCTIcf:SCTIcfBlkCredTrf xsi:schemaLocation=\"urn:S2SCTIcf:xsd:$SCTIcfBlkCredTrf SCTIcfBlkCredTrf.xsd\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:S2SCTIcf=\"urn:S2SCTIcf:xsd:$SCTIcfBlkCredTrf\">").append(sLineSeparator);
//		    sbFileHeader.append("<S2SCTIcf:SndgInst>").append(rebulkFileData.getLocalOfficeBic()).append("</S2SCTIcf:SndgInst>").append(sLineSeparator);   //[NoaG - Taken from FILESUMMARY.SENDING_INST]
//		    sbFileHeader.append("<S2SCTIcf:RcvgInst>").append(rebulkFileData.getReceivingInst()).append("</S2SCTIcf:RcvgInst>").append(sLineSeparator);   //  [NoaG - Taken from FILESUMMARY.RECEIVING_INST]
//		    sbFileHeader.append("<S2SCTIcf:FileRef>").append(rebulkFileData.getFileReference()).append("</S2SCTIcf:FileRef> ").append(sLineSeparator);   //      [NoaG - Taken from FILESUMMARY.FILE_REFERENCE]
//		    sbFileHeader.append("<S2SCTIcf:SrvcId>").append("IDF".equals(rebulkFileData.getsPL_FileType()) ? "SDD" : "SCT").append("</S2SCTIcf:SrvcId>").append(sLineSeparator);   //       [NoaG - Taken from FILESUMMARY.SERVICE_IDENTIFIER]
//		    sbFileHeader.append("<S2SCTIcf:TstCode>").append(rebulkFileData.getProdTestCode()).append("</S2SCTIcf:TstCode>").append(sLineSeparator);   //      [NoaG - Taken from FILESUMMARY.PROD_TEST_CODE]
//		    sbFileHeader.append("<S2SCTIcf:FType>").append(rebulkFileData.getsPL_FileType()).append("</S2SCTIcf:FType>").append(sLineSeparator);   //  [NoaG - Taken from FILESUMMARY.PL_FILE_TYPE]
//
//		    sbFileHeader.append("<S2SCTIcf:FDtTm>").append(sSystemDate).append("</S2SCTIcf:FDtTm>").append(sLineSeparator);   // [NoaG - system time]
//		    sbFileHeader.append("<S2SCTIcf:NumCTBlk>1</S2SCTIcf:NumCTBlk>").append(sLineSeparator);   // [NoaG - Always '1']
//		    sbFileHeader.append("<S2SCTIcf:NumPCRBlk>0</S2SCTIcf:NumPCRBlk>").append(sLineSeparator);   // [NoaG - Always '0']
//		    sbFileHeader.append("<S2SCTIcf:NumRFRBlk>0</S2SCTIcf:NumRFRBlk>").append(sLineSeparator);   //          [NoaG - Always '0']
//		    sbFileHeader.append("<S2SCTIcf:NumROIBlk>0</S2SCTIcf:NumROIBlk>").append(sLineSeparator);   //          [NoaG - Always '0']
//
//
//




		    //sbFileHeader.append("<S2SCTIcf:FIToFICstmrCdtTrf xmlns=\"urn:iso:std:iso:20022:tech:xsd:pacs.008.001.02\">").append(sLineSeparator);






		    //PREVIOUS COMMENT
//		    sbFileHeader.append("<GrpHdr>");
//		    sbFileHeader.append("<MsgId>").append(rebulkFileData.getFileReference()).append("-1 </MsgId>");   //[NoaG - Taken from FILESUMMARY.FILE_REFERENCE concatenated with '-1' at the end]
//		    sbFileHeader.append("<CreDtTm>").append(sSystemDate).append("</CreDtTm>").append(sLineSeparator);// [NoaG - system time]
//		    sbFileHeader.append("<NbOfTxs>").append(rebulkFileData.getTotalMsgCount()).append("</NbOfTxs>").append(sLineSeparator);// [NoaG - the sum of OUT_FILE_BUFFERS.TOTAL_MSG_COUNT_NB of the entries that were included in the files]
//		    sbFileHeader.append("<TtlIntrBkSttlmAmt Ccy=\"").append(rebulkFileData.getSettlementCurrency()).append("\">").append(rebulkFileData.getTotalOfCredit()).append("</TtlIntrBkSttlmAmt>").append(sLineSeparator);
//		    sbFileHeader.append("<IntrBkSttlmDt>").append(rebulkFileData.getSttlmDate()).append("</IntrBkSttlmDt>").append(sLineSeparator); // [NoaG - no value. The value date will be included in each of the individual transactions]
//		    sbFileHeader.append("<SttlmInf>").append(sLineSeparator);
//		    sbFileHeader.append("<SttlmMtd>CLRG</SttlmMtd>").append(sLineSeparator); // [NoaG - Always 'CLRG']
		//
//		    if (!GlobalUtils.isNullOrEmpty(rebulkFileData.getFinCopyService()))
//		    {
//			    sbFileHeader.append("<ClrSys>").append(sLineSeparator); //
//			    sbFileHeader.append("<Prtry>").append(rebulkFileData.getFinCopyService()).append("</Prtry>").append(sLineSeparator); // [NoaG - Taken from FILESUMMARY.FINCOPYSERVICE]
//			    sbFileHeader.append("</ClrSys>").append(sLineSeparator); //
//		    }
//		    sbFileHeader.append("</SttlmInf>").append(sLineSeparator); //
//		    sbFileHeader.append("<InstgAgt>").append(sLineSeparator); //
//		    sbFileHeader.append("<FinInstnId>").append(sLineSeparator); //
//		    sbFileHeader.append("<BIC>").append(rebulkFileData.getsSendingInst()).append("</BIC>").append(sLineSeparator); //        [NoaG - Taken from FILESUMMARY.SENDING_INST]
//		    sbFileHeader.append("</FinInstnId>").append(sLineSeparator); //
//		    sbFileHeader.append("</InstgAgt>").append(sLineSeparator); //
//		    sbFileHeader.append("</GrpHdr>").append(sLineSeparator); //


		    pdo.set(PDOConstantFieldsInterface.X_TX_NO, rebulkFileData.getTotalMsgCount() + "");
		    pdo.set(PDOConstantFieldsInterface.X_MSG_ID, pdo.getString(PDOConstantFieldsInterface.P_OUT_CHUNK_ID));
		    pdo.set(PDOConstantFieldsInterface.X_STTLM_MTD, "CLRG");
		    pdo.set(PDOConstantFieldsInterface.X_TTL_INTR_BNK_STTLM_AMT, BigDecimal.valueOf(rebulkFileData.getTotalOfCredit()));
		    pdo.set(PDOConstantFieldsInterface.X_TTL_INTR_BNK_STTLM_CCY, rebulkFileData.getSettlementCurrency());

			String grpInfoPath = paymentType.getXpathlNamespaceCaluse() + "." + logicalFieldsXpath.getFieldPath() ;

		    final XmlCursor xmlcur = pdo.getXml(DASInterface.CURRENT_XML_MSG_KEY).newCursor();
		    xmlcur.toParent();

		    xmlcur.selectPath(grpInfoPath) ;
		    xmlcur.toNextSelection() ;
		    final String sXmlText = xmlcur.getObject().xmlText(GlobalConstants.m_outputXmlbeansOptions) ;
		    xmlcur.dispose() ;
		    sbFileHeader.append(sXmlText,0, sXmlText.length()- logicalFieldsXpath.getTagName().length() - 3);

		    return sbFileHeader.toString();

		}

		@Override
		public String getOutFileTrailer() {
			return endOfFileTags;
			//return "</S2SCTIcf:FIToFICstmrCdtTrf></S2SCTIcf:SCTIcfBlkCredTrf>";
		}

	},//Pacs_008
	Pacs_003
	{
		@Override
		public String getOutFileHeader(RebulkFileData rebulkFileData, PDO pdo) {
		    //String sSystemDate = GlobalDateTimeUtil.getSTATIC_DATA_XML_DATE_TIME_SimpleDateFormat().format(new Date());
			String sSystemDate = GlobalDateTimeUtil.dateTimeToStaticDataXMlString(new Date());
		    String sLineSeparator = System.getProperty("line.separator");

		    StringBuilder sbFileHeader = new StringBuilder();

		    sbFileHeader.append("<?xml version=\"1.0\" encoding=\"utf-8\"?>").append(sLineSeparator);
		    sbFileHeader.append("<S2SDDIdf:MPEDDIdfBlkDirDeb xsi:schemaLocation=\"urn:S2SDDIdf:xsd:$MPEDDIdfBlkDirDeb MPEDDIdfBlkDirDeb.xsd\" " +
		    		"xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:S2SDDIdf=\"urn:S2SDDIdf:xsd:$MPEDDDnfBlkDirDeb\">").append(sLineSeparator);
		    sbFileHeader.append("<S2SDDIdf:SndgInst>").append(rebulkFileData.getLocalOfficeBic()).append("</S2SDDIdf:SndgInst>").append(sLineSeparator);
		    sbFileHeader.append("<S2SDDIdf:RcvgInst>").append(rebulkFileData.getReceivingInst()).append("</S2SDDIdf:RcvgInst>").append(sLineSeparator);
		    sbFileHeader.append("<S2SDDIdf:FileRef>").append(rebulkFileData.getFileReference()).append("</S2SDDIdf:FileRef> ").append(sLineSeparator);
		    sbFileHeader.append("<S2SDDIdf:SrvcId>").append("IDF".equals(rebulkFileData.getsPL_FileType()) ? "SDD" : "SCT").append("</S2SDDIdf:SrvcId>").append(sLineSeparator);
		    sbFileHeader.append("<S2SDDIdf:TstCode>").append(rebulkFileData.getProdTestCode()).append("</S2SDDIdf:TstCode>").append(sLineSeparator);
		    sbFileHeader.append("<S2SDDIdf:FType>").append(rebulkFileData.getsPL_FileType()).append("</S2SDDIdf:FType>").append(sLineSeparator);


		    sbFileHeader.append("<S2SDDIdf:FDtTm>").append(sSystemDate).append("</S2SDDIdf:FDtTm>").append(sLineSeparator);
		    sbFileHeader.append("<S2SDDIdf:NumDDBlk>1</S2SDDIdf:NumDDBlk>").append(sLineSeparator);
		    sbFileHeader.append("<S2SDDIdf:NumPCRBlk>0</S2SDDIdf:NumPCRBlk>").append(sLineSeparator);
		    sbFileHeader.append("<S2SDDIdf:NumREJBlk>0</S2SDDIdf:NumREJBlk>").append(sLineSeparator);
		    sbFileHeader.append("<S2SDDIdf:NumRVSBlk>0</S2SDDIdf:NumRVSBlk>").append(sLineSeparator);
		    sbFileHeader.append("<S2SDDIdf:NumRFRBlk>0</S2SDDIdf:NumRFRBlk>").append(sLineSeparator);
		    sbFileHeader.append("<S2SDDIdf:NumRRVBlk>0</S2SDDIdf:NumRRVBlk>").append(sLineSeparator);
		    sbFileHeader.append("<S2SDDIdf:FIToFICstmrDrctDbt xmlns=\"urn:iso:std:iso:20022:tech:xsd:pacs.003.001.02\">").append(sLineSeparator);

		    pdo.set(PDOConstantFieldsInterface.X_TX_NO, rebulkFileData.getTotalMsgCount() + "");
		    pdo.set(PDOConstantFieldsInterface.X_MSG_ID, pdo.getString(PDOConstantFieldsInterface.P_OUT_CHUNK_ID));
		    pdo.set(PDOConstantFieldsInterface.X_STTLM_MTD, "CLRG");
		    pdo.set(PDOConstantFieldsInterface.X_TTL_INTR_BNK_STTLM_AMT, BigDecimal.valueOf(rebulkFileData.getTotalOfCredit()));
		    pdo.set(PDOConstantFieldsInterface.X_TTL_INTR_BNK_STTLM_CCY, rebulkFileData.getSettlementCurrency());
		    final PaymentType enumPaymentType = pdo.getPaymentType(DASInterface.CURRENT_XML_MSG_KEY) ;
		    final Map mapLogicalFieldsXPathCache = CacheKeys.LogicalFieldsXPathKey.getSingle(enumPaymentType);
			final LogicalFieldsXpath logicalFieldsXpath = (LogicalFieldsXpath) mapLogicalFieldsXPathCache.get(PDOConstantFieldsInterface.X_GRP_INFO) ;
			String grpInfoPath = enumPaymentType.getXpathlNamespaceCaluse() + "." + logicalFieldsXpath.getFieldPath() ;

		    final XmlCursor xmlcur = pdo.getXml(DASInterface.CURRENT_XML_MSG_KEY).newCursor();
		    xmlcur.toParent();

		    xmlcur.selectPath(grpInfoPath) ;
		    xmlcur.toNextSelection() ;
		    final String sXmlText = xmlcur.getObject().xmlText(GlobalConstants.m_outputXmlbeansOptions) ;
		    xmlcur.dispose() ;
		    sbFileHeader.append(sXmlText);

		    return sbFileHeader.toString();
		}

		@Override
		public String getOutFileTrailer() {
			// TODO Auto-generated method stub
			return "</S2SDDIdf:FIToFICstmrDrctDbt></S2SDDIdf:MPEDDIdfBlkDirDeb>";
		}
	},//Pacs_003
		Pacs_007
	{

	}//Pacs_003
	,
	SWIFT
	{
		public PDO[] executeFlow(String sXmlChunk, int i, String internalFileID, String chunkId,
				  double[] stlmAmt,double[] stlmAmtDuplicate, double[] stlmAmtRejected,double[] stlmAmtRepair,int[] duplicateCount,int[] rejectedCount,int[] repairCount,
				  final FileSummary fileSummary, List<PDO> persistentPdoList, final Map[] arrMapSharedPDOContextHolder,Map<String, StoreRequest> requestMap, Feedback feedback) throws Throwable
		  {
		      List<PDO> pdoList = getPDOsFromChunk(sXmlChunk, chunkId, internalFileID, fileSummary, arrMapSharedPDOContextHolder);

		     return executeFlowInner(pdoList, internalFileID,chunkId, stlmAmt, stlmAmtDuplicate, stlmAmtRejected,stlmAmtRepair, duplicateCount, rejectedCount,repairCount, persistentPdoList, requestMap,feedback);

		  }


		public List<PDO> getPDOsFromChunk(String sXmlChunk, String chunkId, String sInternalFileID, final FileSummary fileSummary , final Map[] arrMapSharedPDOContextHolder) throws Throwable
		{
		  	final String COLUMN_OFFICE = "OFFICE";
		  	final String COLUMN_INITG_PTY_CUST_CODE = "INITG_PTY_CUST_CODE";
		  	final String COLUMN_MSG_TYPE = "MSG_TYPE";

		  	boolean isSinglePayment = false;
		  	

		    String sTracePrefix = String.format("'getPDOsFromChunk', (internal file ID: %s, chunk ID: %s); ", sInternalFileID, chunkId);

		  	// Gets related FILE_SUMMARY's OFFICE & INITG_PTY_CUST_CODE values.
		    final String sFileSummary_OFFICE =  fileSummary.getOffice() ;
		    final String sFileSummary_INITG_PTY_CUST_CODE = fileSummary.getInitgPtyCustCode() ;
		    final String msgType = fileSummary.getMsgType() ;

		  	logger.info(sTracePrefix + "calls 'BODebulkFile.debulkFile' for parsing passed XML chunk content...");
		  	List<String> listChunk = new ArrayList<String>();
		  	isSinglePayment = m_boDebulkFile.debulkFile(sXmlChunk, 1,listChunk, false);
		    logger.info(sTracePrefix + "after call to 'BODebulkFile.debulkFile'; size of returned list: %s", listChunk.size());

		    List<PDO> pdoList = new ArrayList<PDO>();

		    listChunk.size();
		    String officeCurrency = CacheKeys.banksKey.getSingle(sFileSummary_OFFICE).getCurrency();

		    for (String sPDOXml : listChunk)
		    {
		      if(!GlobalUtils.isNullOrEmpty(sPDOXml))
		      {
		        	// XML parsing for legality check.
		          final List<String> list = new ArrayList<String>() ;
//		          XmlObject.Factory.parse(sPDOXml, new XmlOptions().setErrorListener(list));
//		          if(!list.isEmpty()) System.out.println(list) ;

//		          if it is single payment then add office currency to the end of payment line for settlemnt currency.
		          if (isSinglePayment)
		          {
		          	sPDOXml = (sPDOXml.endsWith(GlobalConstants.NEWLINE) ? sPDOXml.substring(0,sPDOXml.length() - 2) : sPDOXml) + officeCurrency + sFileSummary_OFFICE;
		          }
		          PDO pdo = PaymentDataFactory.newPDO(sPDOXml, true /*transient*/, false/*primary*/, false /*conjoined*/, null);
		          pdo.set(PDOConstantFieldsInterface.P_IS_HISTORY, MP_PARTITION);
		          pdo.set(PDOConstantFieldsInterface.X_TX_NO, 1+"");
		          String sMID = pdo.getMID();
		          String sP_MSG_STS = pdo.getString(PDOConstantFieldsInterface.P_MSG_STS);

		  		pdo.set(PDOConstantFieldsInterface.P_RAW_MSG_TYPE, msgType);


		          pdo.set(PDOConstantFieldsInterface.P_ORG_INITG_PTY_CUST_CD, sFileSummary_INITG_PTY_CUST_CODE);

		          // Sets chunk ID.
		          pdo.set(PDOConstantFieldsInterface.P_CHUNK_ID, chunkId);

		          // Adds the MID to the returned list that later on will be used in the caller method for executing base processing for each MID.
		          pdoList.add(pdo);

		          logger.info(String.format(sTracePrefix + "created following PDO - MID: %s, Status: %s, Chunk ID: %s, PDO ID: %s", sMID, sP_MSG_STS, chunkId, pdo));
		        }
		    }

		    

		    return pdoList;
		  }

		public PDO[] executeFlow(PerformDebulkingMultiRequestDocument doc, String internalFileID, String chunkId,
			  double[] stlmAmt,double[] stlmAmtDuplicate, double[] stlmAmtRejected,double[] stlmAmtRepair,int[] duplicateCount,int[] rejectedCount,int[] repairCount,
			  final FileSummary fileSummary, List<PDO> persistentPdoList, final Map[] arrMapSharedPDOContextHolder, Map<String, StoreRequest> requestMap,Feedback feedback) throws Throwable
	  	{

	      List<PDO> pdoList = getPDOsFromChunk(doc, chunkId, internalFileID, fileSummary, arrMapSharedPDOContextHolder);

	      return  executeFlowInner(pdoList,internalFileID,chunkId,stlmAmt,stlmAmtDuplicate,stlmAmtRejected,stlmAmtRepair,duplicateCount,rejectedCount,repairCount,persistentPdoList
	    		  ,requestMap, feedback);

	 	}//EOM executeFlow

	 	public List<PDO> getPDOsFromChunk(PerformDebulkingMultiRequestDocument doc,String chunkId, String sInternalFileID,final FileSummary fileSummary,
			  final Map[] arrMapSharedPDOContextHolder) throws Throwable
	  	{
		  	final String COLUMN_OFFICE = "OFFICE";
		  	final String COLUMN_INITG_PTY_CUST_CODE = "INITG_PTY_CUST_CODE";
		  	final String COLUMN_MSG_TYPE = "MSG_TYPE";

		  	boolean isSinglePayment = false;
		  	

		    String sTracePrefix = String.format("'getPDOsFromChunk', (internal file ID: %s, chunk ID: %s); ", sInternalFileID, chunkId);

		  	// Gets related FILE_SUMMARY's OFFICE & INITG_PTY_CUST_CODE values.
		    final String sFileSummary_OFFICE =  fileSummary.getOffice() ;
		    final String sFileSummary_INITG_PTY_CUST_CODE = fileSummary.getInitgPtyCustCode() ;
		    final String msgType = fileSummary.getMsgType() ;

		  	logger.info(sTracePrefix + "calls 'BODebulkFile.debulkFile' for parsing passed XML chunk content...");
		  	List<String> listChunk = new ArrayList<String>();
		    logger.info(sTracePrefix + "after call to 'BODebulkFile.debulkFile'; size of returned list: %s", listChunk.size());
		    String path = doc.getPerformDebulkingMultiRequest().getPath();
		    File file = new File(path);
		    if (!file.isFile())
		    {
		    	path = path.substring(0,path.lastIndexOf(java.io.File.separator)) + java.io.File.separator + GlobalFileUtil.ARCHIVE_DIR +  path.substring(path.lastIndexOf(java.io.File.separator));
		    	file = new File(path);
		    }

		    String endTags 			= doc.getPerformDebulkingMultiRequest().getEndTags();
		    PreStartDataType preStartDataType = doc.getPerformDebulkingMultiRequest().getPreStartDataListArray()[0];
		    long preDocumentStartTag = preStartDataType.getPreDocumentStartTag();
		    long preDocumentEndTag 	= preStartDataType.getPreDocumentEndTag();
		    long prePmtInfStartTag 	= preStartDataType.getPrePmtInfStartTag();
		    long prePmtInfEndTag 	= preStartDataType.getPrePmtInfEndTag();

		    RandomAccessFileUtils utils = new RandomAccessFileUtils(file);

		    boolean bAddPmtInf = (prePmtInfStartTag!=0);
		    List<PDO> pdoList = new ArrayList<PDO>();

		    listChunk.size();
		    String officeCurrency = CacheKeys.banksKey.getSingle(sFileSummary_OFFICE).getCurrency();


		    {
		    	StringBuilder sb = new StringBuilder();

	    		String documentPartTillFirstTransaction = utils.getDocumentPartTillFirstTransaction(
	    						preDocumentStartTag,bAddPmtInf ? prePmtInfStartTag : preDocumentEndTag,
	    						prePmtInfStartTag,prePmtInfEndTag,endTags,
	    						bAddPmtInf,false,false/*isMulti */,null/*fileMessageTypeData*/);
//
//	    		String documentPartTillFirstTransaction = Utils.getDocPartTillFirstTransaction(file,preDocumentStartTag,prePmtInfStartTag
//	    				,prePmtInfStartTag,prePmtInfEndTag,endTags,true,false);

	    		FileIndexDataType[] arr = doc.getPerformDebulkingMultiRequest().getFileIndexDataTypeListArray();

		  	    for (FileIndexDataType fileIndexDataType : arr)
		  	    {

		  	    	//Xml document without payment info section
		  	    	sb.append(documentPartTillFirstTransaction);

		  	    	//Transaction
		  	    	sb.append(utils.getFileSectionFromIndexes(fileIndexDataType.getTransactionStartTag(),fileIndexDataType.getTransactionEndTag()));
		  	    	sb.append(endTags);
		  	    	//Transaction
		  	    	PDO pdo = PaymentDataFactory.newPDO(sb.toString(), true /*transient*/, false/*primary*/, false /*conjoined*/, null);

			          String sMID = pdo.getMID();
			          String sP_MSG_STS = pdo.getString(PDOConstantFieldsInterface.P_MSG_STS);
			          pdo.set(PDOConstantFieldsInterface.P_IS_HISTORY, MP_PARTITION);
			          pdo.set(PDOConstantFieldsInterface.X_TX_NO, 1+"");
			  		pdo.set(PDOConstantFieldsInterface.P_RAW_MSG_TYPE, msgType);


			          pdo.set(PDOConstantFieldsInterface.P_ORG_INITG_PTY_CUST_CD, sFileSummary_INITG_PTY_CUST_CODE);

			          // Sets chunk ID.
			          pdo.set(PDOConstantFieldsInterface.P_CHUNK_ID, chunkId);

			          // Adds the MID to the returned list that later on will be used in the caller method for executing base processing for each MID.
			          pdoList.add(pdo);


			    	logger.info(String.format(sTracePrefix + "created following PDO - MID: %s, Status: %s, Chunk ID: %s, PDO ID: " +
			    		"%s", sMID, pdo.getString(PDOConstantFieldsInterface.P_MSG_STS), chunkId, pdo));

			    	sb.delete(0,sb.length());

				}//for

		    }//if feedback.m_bIsSuccessful

		    utils.dispose();

		    

		    return pdoList;

		 }//EOM getPDOsFromChunk by Index

		/**
	    * executeFlowInner
	    *
	    * get list of PDO's from xml PerformDebulkingMultiRequestDocument
	    * and performLowValuePreProcessingTransactionSubFlow for each
	    *
	    * @author dmitryp
	   */
		protected PDO[] executeFlowInner(List<PDO> pdoList,String internalFileId, String chunkId,double[] stlmAmt,double[] stlmAmtDuplicate, double[] stlmAmtRejected,double[] stlmAmtRepair,int[] duplicateCount,int[] rejectedCount,int[] repairCount,
				  List<PDO> persistentPdoList,Map<String, StoreRequest> requestMap,Feedback feedback) throws Throwable
		{
	      int iChunkSize = pdoList.size();
	      PDO[] pdoArr = new PDO[iChunkSize];
	      int i = 0;
	      String sHandledPDODataPrefix = null;

	      for(PDO pdo: pdoList)
	      {
	      	String mid = pdo.getMID();
	      	sHandledPDODataPrefix = String.format("Debulking process for PDO %s out of %s - MID: %s, Chunk ID: %s, PDO ID: %s; ", (i+1), iChunkSize, mid, chunkId, pdo);

	        pdo.set(PDOConstantFieldsInterface.P_IN_INTERNAL_FILEID, internalFileId);
	        pdo.set(PDOConstantFieldsInterface.P_CHUNK_ID, chunkId);
	        pdo.set(PDOConstantFieldsInterface.P_BATCH_MSG_TP, "I");
	        pdo.promoteToPrimary();
	        feedback = BOProxies.m_setBasicPropertiesLogging.setBasicProperties(Admin.getContextAdmin(), pdo.getMID());
	        if (feedback.m_bIsSuccessful)
	        {
		        String sOldStatus = pdo.getString(PDOConstantFieldsInterface.P_MSG_STS);
		        logger.info(sHandledPDODataPrefix + "executes base processing; PDO Status: %s", sOldStatus);

		        if (GlobalUtils.isNullOrEmpty(pdo.getString(PDOConstantFieldsInterface.P_DISPLAY_MSG_TYPE)))
		      	  {
							MsgTypes msgTypes = CacheKeys.msgTypesKey.getSingle(pdo.getString(PDOConstantFieldsInterface.P_MSG_TYPE), ServerConstants.EMPTY_STRING);
							String sDisplayMsgType = msgTypes != null ? msgTypes.getDisplayMsgType() : "NMT";
							pdo.set(PDOConstantFieldsInterface.P_DISPLAY_MSG_TYPE, !isNullOrEmpty(sDisplayMsgType) ? sDisplayMsgType : msgTypes.getMsgType());

		      	  }
		          feedback = BOProxies.m_internalBaseProcessLogging.performBaseProcessing(Admin.getContextAdmin(), mid);
		          String sNewStatus = pdo.getString(PDOConstantFieldsInterface.P_MSG_STS);
		          logger.info(sHandledPDODataPrefix + "finished base processing; Old Status: %s, New status: %s, Feedback: %s",new Object[]{ sOldStatus, sNewStatus, ServerUtils.getFeedbackString(feedback)});
	        }
	          if(!feedback.m_bIsSuccessful)
	          {
	            BOHighValueProcess.performTerminationSubFlow(pdo, MessageConstantsInterface.MESSAGE_STATUS_REPAIR);
	          }

	          else
	          {
	            BOHighValueProcess.performTerminationSubFlow(pdo, null);
	          }

	          performFinalStep(pdo, sHandledPDODataPrefix, stlmAmt, stlmAmtDuplicate, stlmAmtRejected, stlmAmtRepair,duplicateCount, rejectedCount, repairCount,internalFileId, chunkId, persistentPdoList,
	        		  requestMap, feedback);
	          pdoArr[i++] = pdo;
	        }

	        logger.info(sHandledPDODataPrefix + "finished handling for this message");

	      return pdoArr;

	  	}//EOM executeFlowInner


	}//SWIFT
	,Pain_008
	{
		@Override
		public void performPostexecutions(Object o) throws Throwable
		{
			// TODO Auto-generated method stub
			super.performPostexecutions(o);
			List<ProcessPdoPerGroupIdEntry> processPdoPerGoupIdList =(List<ProcessPdoPerGroupIdEntry>)o;
			Admin admin = Admin.getContextAdmin();
			Feedback feedback = new Feedback();
			for (ProcessPdoPerGroupIdEntry processPdoPerGroupIdEntry : processPdoPerGoupIdList) {
				List<PDO> listPDO = processPdoPerGroupIdEntry.getEntry();
				PDO pdo = listPDO.get(0);
				String internalFileId = pdo.getString(PDOConstantFieldsInterface.P_IN_INTERNAL_FILEID);
				String chunkId = pdo.getString(PDOConstantFieldsInterface.P_CHUNK_ID);
				String uniqueGroupId = pdo.getString(PDOConstantFieldsInterface.P_UNIQUE_GROUPING_ID);

				//Decide if message status is final or not
				String paymentMsgSts = listPDO.get(0).getString(PDOConstantFieldsInterface.P_MSG_STS);
				String msgSts = MESSAGE_STATUS_WAITSUBBATCH.equals(paymentMsgSts) ? MESSAGE_STATUS_COMPLETE : MESSAGE_STATUS_SCHEDULE;
				Integer isHistory = pdo.getIsHistory();

				Map<String,Object> dataMap = new HashMap<String, Object>();
				dataMap.put(P_IN_INTERNAL_FILEID, internalFileId);
				dataMap.put(P_UNIQUE_GROUPING_ID, uniqueGroupId);
				dataMap.put(P_MSG_STS, msgSts);
				dataMap.put(PDOConstantFieldsInterface.P_IS_HISTORY, isHistory);
				
				m_subBatchCompletion.processPayments(listPDO, processPdoPerGroupIdEntry, chunkId, dataMap, admin, feedback);
			}
		}
	}

	, Default;//ENUM members end


	private static BODebulkFile m_boDebulkFile = new BODebulkFile();
	private static final BOSecurity m_security = new BOFileSecurity();
	private static final BOSubBatchCompletion m_subBatchCompletion = new BOSubBatchCompletion();

	public static final int MP_PARTITION = 0; //TBD 3
	
   /**
	*
	* Original
	*
   */
   public PDO[] executeFlow(String sXmlChunk, String internalFileID, String chunkId,double[] stlmAmt,double[] stlmAmtDuplicate, double[] stlmAmtRejected,double[] stlmAmtRepair,
			int[] duplicateCount,int[] rejectedCount,int[] repairCount,final FileSummary fileSummary, List<PDO> persistentPdoList, final Map[] arrMapSharedPDOContextHolder,
			Map<String, StoreRequest> requestMap, Feedback feedback) throws Throwable
	{
	  List<PDO> pdoList = getPDOsFromChunk(sXmlChunk, chunkId, internalFileID, fileSummary, arrMapSharedPDOContextHolder);

      return  executeFlowInner(pdoList,internalFileID,chunkId,stlmAmt,stlmAmtDuplicate,stlmAmtRejected,stlmAmtRepair,duplicateCount,rejectedCount,repairCount,persistentPdoList, requestMap, feedback);

    }//EOM executeFlow

  /**
   *
   * Original
   *
   */
   public List<PDO> getPDOsFromChunk(String sXmlChunk, String chunkId, String sInternalFileID, final FileSummary fileSummary, final Map[] arrMapSharedPDOContextHolder) throws Throwable
	  {
	  	final String COLUMN_OFFICE = "OFFICE";
	  	final String COLUMN_INITG_PTY_CUST_CODE = "INITG_PTY_CUST_CODE";
	  	final String COLUMN_MSG_TYPE = "MSG_TYPE";

	  	String sTracePrefix = null ;
	  	boolean isSinglePayment = false;


	  	sTracePrefix = String.format("'getPDOsFromChunk', (internal file ID: %s, chunk ID: %s); ", sInternalFileID, chunkId);
	  	

	  	// Gets related FILE_SUMMARY's OFFICE & INITG_PTY_CUST_CODE values.
	  	String sFileSummary_OFFICE =  fileSummary.getOffice() ;
	  	String sFileSummary_INITG_PTY_CUST_CODE = fileSummary.getInitgPtyCustCode() ;
	  	String msgType = fileSummary.getMsgType() ;

	  	logger.info(sTracePrefix + "calls 'BODebulkFile.debulkFile' for parsing passed XML chunk content...");
	  	List<String> listChunk = new ArrayList<String>();
	  	isSinglePayment = m_boDebulkFile.debulkFile(sXmlChunk, 1,listChunk, true);
	  	logger.info(sTracePrefix + "after call to 'BODebulkFile.debulkFile'; size of returned list: %s", listChunk.size());

	    List<PDO> pdoList = new ArrayList<PDO>();

	    listChunk.size();
	    String officeCurrency = CacheKeys.banksKey.getSingle(sFileSummary_OFFICE).getCurrency();

		String flowType = InterfaceSubTypeFlow.getFlowType(fileSummary.getPlFileType());

	    PDO templatePDO = PaymentDataFactory.newPDO(m_boDebulkFile.getPmtInfSec(sXmlChunk),true/*bTransient*/, true/*bConjoinedMode*/);
	    arrMapSharedPDOContextHolder[0] = templatePDO.getSharedContext() ;

	    templatePDO.set(PDOConstantFieldsInterface.X_STTLM_CCY, officeCurrency);
	    templatePDO.set(PDOConstantFieldsInterface.X_STTLM_AMT, new BigDecimal(0));
	    templatePDO.set(PDOConstantFieldsInterface.P_IN_INTERNAL_FILEID, sInternalFileID);
	    //templatePDO.getNSetIncomingFileSummary();
	    templatePDO.setIncomingFileSummary(fileSummary) ;
	    Feedback feedback = BOProxies.m_processFlowsLocal.performLowValuePreProcessingPaymentSubFlow(Admin.getContextAdmin(), templatePDO.getMID());
	    CloningContext context = new CloningContext(templatePDO, null/*sCreationMID*/, null/*cloneHandler*/, arrMapSharedPDOContextHolder[0]);

	    templatePDO.set(PDOConstantFieldsInterface.P_RAW_MSG_TYPE, msgType);
	    templatePDO.set(PDOConstantFieldsInterface.P_ORG_INITG_PTY_CUST_CD, sFileSummary_INITG_PTY_CUST_CODE);
	    // Sets chunk ID.
	    templatePDO.set(PDOConstantFieldsInterface.P_CHUNK_ID, chunkId);
	    boolean isDD = templatePDO.getNSetMsgTypes().getMsgClass().indexOf("DD") > -1;
	    String trnsInfoLogicalField = isDD ? "X_DIRECT_DBT_TRNF_INFO" : PDOConstantFieldsInterface.X_CDT_TRNF_INFO;

	    // Continues even if feedback is a failure one so the single payments will be created and will fall to REPAIR;
	    // this will be done in 'BOProcessFlows.performLowValuePreProcessingTransactionSubFlow' method.
	    //if (feedback.m_bIsSuccessful)
	    {
	    	final List groups = CacheKeys.LogicalFieldsXPathGroupsKey.get(null, templatePDO.getPaymentType("XML_MSG"), "XML_MSG");

		    for (String sPDOXml : listChunk)
		    {
		      //if(!GlobalUtils.isNullOrEmpty(sPDOXml))
		    	if(!(sPDOXml == null || sPDOXml.isEmpty()))
		      {
		      	// XML parsing for legality check.
		        //final List<String> list = new ArrayList<String>() ;
		//        XmlObject.Factory.parse(sPDOXml, new XmlOptions().setErrorListener(list));
		//        if(!list.isEmpty()) System.out.println(list) ;

		//        if it is single payment then add office currency to the end of payment line for settlemnt currency.
		        if (isSinglePayment)
		        {
		        	sPDOXml = (sPDOXml.endsWith(GlobalConstants.NEWLINE) ? sPDOXml.substring(0,sPDOXml.length() - 2) : sPDOXml) + officeCurrency + sFileSummary_OFFICE;
		        }

//		        PDO pdo = PaymentDataFactory.clone(templatePDO, null, sPDOXml, PDOConstantFieldsInterface.X_CDT_TRNF_INFO,true, groups);

		        PDO pdo = PaymentDataFactory.clonePDO(context, sPDOXml, trnsInfoLogicalField, true, groups);
	  	    	pdo.set(PDOConstantFieldsInterface.P_IS_HISTORY, GlobalConstants.BP.equals(flowType) ? GlobalUtils.getPartitionIDByMID(pdo.getMID()) : MP_PARTITION);
		        pdo.set(PDOConstantFieldsInterface.X_TX_NO, 1+"");

		        String sMID = pdo.getMID();

		        // Adds the MID to the returned list that later on will be used in the caller method for executing base processing for each MID.
		        pdoList.add(pdo);

		        logger.info(String.format(sTracePrefix + "created following PDO - MID: %s, Status: %s, Chunk ID: %s, PDO ID: " +
		        		"%s", sMID, pdo.getString(PDOConstantFieldsInterface.P_MSG_STS), chunkId, pdo));
		      }
		    }
	    }
	    // Updates the ChunkPDOKey cache key with created PDOs.
//	    CacheServiceInterface.eINSTANCE.putAll(CacheKeys.chunkPDOKey, pdoList, chunkId);

	    
	    return pdoList;

	  }//EOM getPDOsFromChunk


   /**
    * executeFlow
    *
    * get list of PDO's from xml PerformDebulkingMultiRequestDocument
    * and performLowValuePreProcessingTransactionSubFlow for each
    *
    * @author dmitryp
   */
	public PDO[] executeFlow(PerformDebulkingMultiRequestDocument doc, String internalFileId, String chunkId,double[] stlmAmt,double[] stlmAmtDuplicate, double[] stlmAmtRejected,double[] stlmAmtRepair,
			int[] duplicateCount,int[] rejectedCount,int[] repairCount, final FileSummary fileSummary, List<PDO> persistentPdoList, final Map[] arrMapSharedPDOContextHolder,
			Map<String, StoreRequest> requestMap, Feedback feedback) throws Throwable {

	  	  List<PDO> pdoList = getPDOsFromChunk(doc,chunkId,internalFileId,fileSummary, arrMapSharedPDOContextHolder);

	      return  executeFlowInner(pdoList,internalFileId,chunkId,stlmAmt,stlmAmtDuplicate,stlmAmtRejected,stlmAmtRepair,duplicateCount,rejectedCount,repairCount,persistentPdoList,requestMap,feedback);

	}//EOM executeFlow


   /**
    * executeFlowInner
    *
    * get list of PDO's from xml PerformDebulkingMultiRequestDocument
    * and performLowValuePreProcessingTransactionSubFlow for each
    *
    * @author dmitryp
   */
	protected PDO[] executeFlowInner(List<PDO> pdoList,String internalFileId, String chunkId,double[] stlmAmt,double[] stlmAmtDuplicate, double[] stlmAmtRejected,double[] stlmAmtRepair,int[] duplicateCount,int[] rejectedCount,int[] repairCount,
			  List<PDO> persistentPdoList,Map<String, StoreRequest> requestMap, Feedback feedback) throws Throwable
	{
	      int iChunkSize = pdoList.size();
	      PDO[] pdoArr = new PDO[iChunkSize];
	      int i = 0;
	      String sHandledPDODataPrefix = null;

	      for(PDO pdo: pdoList)
	      {
	      	String mid = pdo.getMID();
	      	sHandledPDODataPrefix = String.format("Debulking process for PDO %s out of %s - MID: %s, Chunk ID: %s, PDO ID: %s; ", (i+1), iChunkSize, mid, chunkId, pdo);

	        pdo.set(PDOConstantFieldsInterface.P_IN_INTERNAL_FILEID, internalFileId);
	        pdo.set(PDOConstantFieldsInterface.P_CHUNK_ID, chunkId);
	        pdo.set(PDOConstantFieldsInterface.P_BATCH_MSG_TP, "I");

	        String sOldStatus = pdo.getString(PDOConstantFieldsInterface.P_MSG_STS);

	        logger.info(sHandledPDODataPrefix + "executes base processing; PDO Status: %s", sOldStatus);
	        {

	      	  if (GlobalUtils.isNullOrEmpty(pdo.getString(PDOConstantFieldsInterface.P_DISPLAY_MSG_TYPE)))
	      	  {
				MsgTypes msgTypes = CacheKeys.msgTypesKey.getSingle(pdo.getString(PDOConstantFieldsInterface.P_MSG_TYPE), ServerConstants.EMPTY_STRING);
				String sDisplayMsgType = msgTypes != null ? msgTypes.getDisplayMsgType() : "NMT";
				pdo.set(PDOConstantFieldsInterface.P_DISPLAY_MSG_TYPE, !isNullOrEmpty(sDisplayMsgType) ? sDisplayMsgType : msgTypes.getMsgType());
	      	  }

	      	  pdo.promoteToPrimary();
	  	  	  feedback = BOProxies.m_processFlowsLocal.performLowValuePreProcessingTransactionSubFlow(Admin.getContextAdmin(), mid);
	          String sNewStatus = pdo.getString(PDOConstantFieldsInterface.P_MSG_STS);
	          logger.info(sHandledPDODataPrefix + "finished base processing; Old Status: %s, New status: %s, Feedback: %s",new Object[]{ sOldStatus, sNewStatus, ServerUtils.getFeedbackString(feedback)});

	          performFinalStep(pdo, sHandledPDODataPrefix, stlmAmt, stlmAmtDuplicate, stlmAmtRejected, stlmAmtRepair,duplicateCount, rejectedCount,repairCount, internalFileId, chunkId, persistentPdoList, requestMap, feedback);
	          pdoArr[i++] = pdo;
	        }

	        logger.info(sHandledPDODataPrefix + "finished handling for this message");
	      }

	      return pdoArr;

	  }//EOM executeFlowInner

   /**
    * getPDOsFromChunk
    *
    * get list of PDO's from xml chunk of PerformDebulkingMultiRequestDocument
    *
    * @author dmitryp
   */
   public List<PDO> getPDOsFromChunk(PerformDebulkingMultiRequestDocument doc,String chunkId, String sInternalFileID,final FileSummary fileSummary,
			  final Map[] arrMapSharedPDOContextHolder) throws Throwable
	  {
	  	final String COLUMN_OFFICE = "OFFICE";
	  	final String COLUMN_INITG_PTY_CUST_CODE = "INITG_PTY_CUST_CODE";
	  	final String COLUMN_MSG_TYPE = "MSG_TYPE";

	  	String sTracePrefix = null ;
	  	boolean isSinglePayment = false;


	  	
	  		
	  	sTracePrefix = String.format("'getPDOsFromChunk', (internal file ID: %s, chunk ID: %s); ", sInternalFileID, chunkId);
	  	

	  	// Gets related FILE_SUMMARY's OFFICE & INITG_PTY_CUST_CODE values.
	  	String sFileSummary_OFFICE =  fileSummary.getOffice() ;
	  	String sFileSummary_INITG_PTY_CUST_CODE = fileSummary.getInitgPtyCustCode() ;
	  	String msgType = fileSummary.getMsgType() ;

	  	logger.info(sTracePrefix + "calls 'BODebulkFile.debulkFile' for parsing passed XML chunk content...");

	  	FileIndexDataType[] arr = doc.getPerformDebulkingMultiRequest().getFileIndexDataTypeListArray();

	  	isSinglePayment = (arr.length == 1);

	  	logger.info(sTracePrefix + "after call to 'BODebulkFile.debulkFile'; size of returned list: %s", arr.length);

	    List<PDO> pdoList = new ArrayList<PDO>();

	    String officeCurrency = CacheKeys.banksKey.getSingle(sFileSummary_OFFICE).getCurrency();

	    //read file from "archive" dir
	    String path = doc.getPerformDebulkingMultiRequest().getPath();
	    File file = new File(path);
	    if (!file.isFile())
	    {
	    	path = path.substring(0,path.lastIndexOf(java.io.File.separator)) + java.io.File.separator + GlobalFileUtil.ARCHIVE_DIR +  path.substring(path.lastIndexOf(java.io.File.separator));
	    	file = new File(path);
	    }

	    //This xml fragment should include:
	    //1)Document info
	    //2)GrpHdr
	    //3)PmtInfo
	    //4)XmlClose tags
	    //
	    //Note:PmtInfo may be different from transaction to transaction
	    //Example:
	    //
//	    <?xml version='1.0' encoding='UTF-8'?>
//	    <Document xmlns="urn:iso:std:iso:20022:tech:xsd:pain.001.001.03">
//   		<CstmrCdtTrfInitn>
//      	<GrpHdr>
//         <MsgId>MASS_TRUE_TPH_20</MsgId>
//         <CreDtTm>2011-04-28T06:19:06</CreDtTm>
//         <NbOfTxs>2</NbOfTxs>
//         <CtrlSum>2000</CtrlSum>
//         <InitgPty>
//            <Nm>THE FX COMPANY</Nm>
//            <Id>
//               <OrgId>
//                  <Othr>
//                     <Id>9057139638</Id>
//                  </Othr>
//               </OrgId>
//            </Id>
//         </InitgPty>
//      	</GrpHdr>
//      	<PmtInf>
//         <PmtMtd>TRF</PmtMtd>
//         <ReqdExctnDt>2011-04-28</ReqdExctnDt>
//         <Dbtr>
//            <Nm>THE FX COMPANY</Nm>
//            <Id>
//               <OrgId>
//                  <Othr>
//                     <Id>9057139638</Id>
//                  </Othr>
//               </OrgId>
//            </Id>
//         </Dbtr>
//         <DbtrAcct>
//            <Id>
//               <IBAN>GB72IRVT70022591176123</IBAN>
//            </Id>
//            <Ccy>EUR</Ccy>
//         </DbtrAcct>
//         <DbtrAgt>
//            <FinInstnId>
//               <BIC>IRVTGB2LXXX</BIC>
//            </FinInstnId>
//         </DbtrAgt>
//         </PmtInf></CstmrCdtTrfInitn></Document>

	    String endTags 			= doc.getPerformDebulkingMultiRequest().getEndTags();
	    PreStartDataType preStartDataType = doc.getPerformDebulkingMultiRequest().getPreStartDataListArray()[0];
	    long preDocumentStartTag = preStartDataType.getPreDocumentStartTag();
	    long preDocumentEndTag 	= preStartDataType.getPreDocumentEndTag();
	    long prePmtInfStartTag 	= preStartDataType.getPrePmtInfStartTag();
	    long prePmtInfEndTag 	= preStartDataType.getPrePmtInfEndTag();
	    long paymentInfoStartTag = arr[0].getPaymentInfoStartTag();
	    long paymentInfoEndTag 	= arr[0].getPaymentInfoEndTag();

	    RandomAccessFileUtils utils = new RandomAccessFileUtils(file);

	    //Pain01
		String documentPartTillFirstTransaction2 = utils.getDocumentPartTillFirstTransaction(
	    		preDocumentStartTag,prePmtInfEndTag,
	    		paymentInfoStartTag,paymentInfoEndTag,
	    		endTags,true,true,false/*isMulti */,null/*fileMessageTypeData*/);


		String documentPartTillFirstTransaction = documentPartTillFirstTransaction2.replaceFirst("<S2SCTIcf:FIToFICstmrCdtTrf", "<Document");

		String flowType = InterfaceSubTypeFlow.getFlowType(fileSummary.getPlFileType());
		
	    PDO templatePDO = PaymentDataFactory.newPDO(documentPartTillFirstTransaction,true/*bTransient*/, true/*bConjoinedMode*/);


	    //LIRON TEMP - REMOVE


	    arrMapSharedPDOContextHolder[0] = templatePDO.getSharedContext() ;

	    templatePDO.set(PDOConstantFieldsInterface.X_STTLM_CCY, officeCurrency);
	    templatePDO.set(PDOConstantFieldsInterface.X_STTLM_AMT, new BigDecimal(0));
	    templatePDO.set(PDOConstantFieldsInterface.P_IN_INTERNAL_FILEID, sInternalFileID);
	    //templatePDO.getNSetIncomingFileSummary();
	    templatePDO.setIncomingFileSummary(fileSummary) ;
	    Feedback feedback = BOProxies.m_processFlowsLocal.performLowValuePreProcessingPaymentSubFlow(Admin.getContextAdmin(), templatePDO.getMID());
	    CloningContext context = new CloningContext(templatePDO, null/*sCreationMID*/, null/*cloneHandler*/, arrMapSharedPDOContextHolder[0]);

	    templatePDO.set(PDOConstantFieldsInterface.P_RAW_MSG_TYPE, msgType);
	    templatePDO.set(PDOConstantFieldsInterface.P_ORG_INITG_PTY_CUST_CD, sFileSummary_INITG_PTY_CUST_CODE);
	    // Sets chunk ID.
	    templatePDO.set(PDOConstantFieldsInterface.P_CHUNK_ID, chunkId);
	    boolean isDD = templatePDO.getNSetMsgTypes().getMsgClass().indexOf("DD") > -1;
	    String trnsInfoLogicalField = isDD ? "X_DIRECT_DBT_TRNF_INFO" : PDOConstantFieldsInterface.X_CDT_TRNF_INFO;
	    // Continues even if feedback is a failure one so the single payments will be created and will fall to REPAIR;
	    // this will be done in 'BOProcessFlows.performLowValuePreProcessingTransactionSubFlow' method.
	    //if (feedback.m_bIsSuccessful)
	    {
	    	final List groups = CacheKeys.LogicalFieldsXPathGroupsKey.get(null, templatePDO.getPaymentType("XML_MSG"), "XML_MSG");

	    	StringBuilder sb = new StringBuilder();
    		documentPartTillFirstTransaction2 =
    			utils.getDocPartTillFirstTransaction(preDocumentStartTag,prePmtInfEndTag,prePmtInfStartTag,prePmtInfEndTag,endTags,false,false,arr[0].getPaymentInfoElementStartTag());

    		documentPartTillFirstTransaction = documentPartTillFirstTransaction2.replaceFirst("<S2SCTIcf:FIToFICstmrCdtTrf", "<Document");

	  	    for (FileIndexDataType fileIndexDataType : arr)
	  	    {
	  	    	//Xml document without payment info section
	  	    	sb.append(documentPartTillFirstTransaction);

	  	    	//PaymentInfo Element
	  	    	//sb.append(Utils.getFileSectionFromIndexes(file,fileIndexDataType.getPaymentInfoStartTag(),fileIndexDataType.getPaymentInfoEndTag()));
	  	    	//Transaction Element
	  	    	sb.append(utils.getFileSectionFromIndexes(fileIndexDataType.getTransactionStartTag(),fileIndexDataType.getTransactionEndTag()));
	  	    	sb.append(endTags);
	  	    	//sb.append(endTags.replace("</PmtInf>",""));

	  	    	PDO pdo = PaymentDataFactory.clonePDO(context, sb.toString(), trnsInfoLogicalField, true, groups);
	  	    	pdo.set(PDOConstantFieldsInterface.P_IS_HISTORY, GlobalConstants.BP.equals(flowType) ? GlobalUtils.getPartitionIDByMID(pdo.getMID()) : MP_PARTITION);
	  	    	pdo.set(PDOConstantFieldsInterface.X_TX_NO, 1+"");
	  	    	String sMID = pdo.getMID();
	  	    	pdoList.add(pdo);

		    	logger.info(String.format(sTracePrefix + "created following PDO - MID: %s, Status: %s, Chunk ID: %s, PDO ID: " +
		    		"%s", sMID, pdo.getString(PDOConstantFieldsInterface.P_MSG_STS), chunkId, pdo));

		    	sb.delete(0,sb.length());

			}//for

	    }//if feedback.m_bIsSuccessful

	    utils.dispose();

	     

	    return pdoList;

   }//EOM getPDOsFromChunk


   protected void performFinalStep(PDO pdo, String sHandledPDODataPrefix, double[] stlmAmt, double[] stlmAmtDuplicate, double[] stlmAmtRejected,double[] stlmAmtRepair,
			  int[] duplicateCount, int[] rejectedCount,int[] repairCount, String internalFileID, String chunkId, List<PDO> persistentPdoList, Map<String, StoreRequest> requestMap, Feedback feedback) throws Exception
	{
		  
		  String sNewStatus = pdo.getString(PDOConstantFieldsInterface.P_MSG_STS);
	      logger.info(sHandledPDODataPrefix + "status after graceful termination: %s", sNewStatus);

	      double amount = pdo.getDecimal(PDOConstantFieldsInterface.OX_STTLM_AMT) != null ? pdo.getDecimal(PDOConstantFieldsInterface.OX_STTLM_AMT).doubleValue() : 0;
	      stlmAmt[0]+=amount;

	      if(   feedback.m_bIsSuccessful
	         && (   sNewStatus.equals(MessageConstantsInterface.MESSAGE_STATUS_WAITSUBBATCH) || sNewStatus.equals(MessageConstantsInterface.MESSAGE_STATUS_WAITSCHEDSUBBATCH)
	        		 || sNewStatus.equals(MessageConstantsInterface.MESSAGE_STATUS_PENDING_FILE_APPROVAL)) )
	      {
	    	  logger.info(sHandledPDODataPrefix + "successful base processing; calls 'performAccumulations' method...");
	        feedback = performAccumulations(internalFileID, chunkId, pdo.getMID());
	        pdo.makeNew();
	      }
	      else if (pdo.getTransient("LALA") != null)
	      {}
	      else
	      {
	    	  if (persistentPdoList != null) persistentPdoList.add(pdo);
	    	  if (MessageConstantsInterface.MESSAGE_STATUS_REJECTEDDUPEX.equals(sNewStatus) || MessageConstantsInterface.MESSAGE_STATUS_DUPEX.equals(sNewStatus))
	    	  {
	    		  logger.info(sHandledPDODataPrefix + "un-Successful base processing; increments total duplicate amount and total duplicate payments count");
		            stlmAmtDuplicate[0]+=amount;
		            duplicateCount[0]++;
	    	  }
	    	  else if (MessageConstantsInterface.MESSAGE_STATUS_REPAIR.equals(sNewStatus))
              {
                  logger.info(sHandledPDODataPrefix + "un-Successful base processing; increments total repair amount and total repair payments count");
                    stlmAmtRepair[0]+=amount;
                    repairCount[0]++;
	    	  }else
	    	  {
	    		logger.info(sHandledPDODataPrefix + "un-Successful base processing; increments total rejected amount and total rejected payments count");
	            stlmAmtRejected[0]+=amount;
	            rejectedCount[0]++;
	    	  }
	      }

	  }



   public Feedback performAccumulations(String sInternalFileID, String sChunkId, String sMID) throws FlowException
	  {
	  	final String TRACE_METHOD_RESULTS = "updated accumultions map - key: %s, Total debit amount: %s, Total credit amount: %s, Total base amount: %s, Messages count: %s.";

	  	
	  	String sTracePrefix = null ;
	  	sTracePrefix = String.format("'performAccumulations', (Internal file ID: %s, Chunk ID: %s, MID: %s; ); ", sInternalFileID, sChunkId, sMID);

	  	Feedback feedback = null;

	  	PDO pdo = PaymentDataFactory.load(sMID);
	  	MsgClassType msgClass = BOBaseProcess.isDD(pdo) ? MsgClassType.DD : MsgClassType.CT;
	  	String chunkId = pdo.getString(PDOConstantFieldsInterface.P_CHUNK_ID);

	  	// Map in which: key - unique grouping ID
	  	//               value - PreProcessAccumulations object, which will be used for future insert into FILE_SUBSET_CHUNKS table.
	    Map<String, PreProcessAccumulations> accumulationsMap = CacheKeys.preProcessAccumulationsKey.getSingle(chunkId);

	    if(accumulationsMap == null)
	    {
	      logger.info(sTracePrefix + "creates new accumulations map");
	      accumulationsMap = new HashMap<String, PreProcessAccumulations>();
	      CacheKeys.preProcessAccumulationsKey.putSingle(chunkId, accumulationsMap);
	    }

//	        pdo.set(D_RULE_TYPE_ID,RULE_TYPE_ID_MSG_TYPE_SELECTION);
//
////	        update p_msg_sts using mapPaymentInfoUsingRules service as follows:
////	                two message type selection rules should be defined with conditions:
////	                1) If P_BATCH_MSG_TYPE = 'I' and P_PROC_DT <= F_OFFICE_BDT then result 'WaitSubBatch'
////	                2) If P_BATCH_MSG_TYPE = 'I' and P_PROC_DT > F_OFFICE_BDT then result 'WaitSchedSubBatch'
//	        feedback = m_mapPaymentInfoUsingRules.handleRuleExecutionAndMappingToPDO(Admin.getContextAdmin(), sMID).getFeedback();
//	        by default the key to accumulations is set to mid because if the unique grouping id won't be generated for some reason, then
//	        the message should be inserted as it is, not part of some group.
	    String sAccumulationsMapKey = sInternalFileID;
	    String office = pdo.getString(PDOConstantFieldsInterface.P_OFFICE);
	    String sttlmCcy = pdo.getString(PDOConstantFieldsInterface.X_STTLM_CCY);

	    CurrencyBu currency = CacheKeys.currencyBuKey.getSingle(office, sttlmCcy);
	    String suspenseAccUid = office + "^" + currency.getBatchSuspenseAccUid() + "^" + sttlmCcy;
	    pdo.set(PDOConstantFieldsInterface.P_SUSPENSE_ACCT_UID, suspenseAccUid);
	    // Executes rule with rule type MSG TYPE SELECTION and then script execution of type 'Bulk unique group id' which will update
	    // P_UNIQUE_GROUPING_ID logical field.
	    pdo.set(PDOConstantFieldsInterface.D_RULE_TYPE_ID, MessageConstantsInterface.RULE_TYPE_ID_UNIQUE_GROUPING_RULE_SELECTION);
	    pdo.set(PDOConstantFieldsInterface.D_ACTION_ID, pdo.get(PDOConstantFieldsInterface.P_OFFICE));
	    logger.info(sTracePrefix + "executes unique grouping ID selection MANIPULATION rule, (rule type ID 140)");
	    feedback =BOProxies.m_messageHandleLogging.manipulateMessageData(Admin.getContextAdmin(), sMID,
	                                                     new String[]{pdo.getString(PDOConstantFieldsInterface.P_OFFICE), ServerConstants.DEFAULT_SERVER_OFFICE_NAME}).getFeedback();

	    // Success; sets the
	    if(feedback.m_bIsSuccessful)
	    {
	    	// if every thing executed successfully, set the key as unique grouping id
	      String sUniqueGroupingID = pdo.getString(PDOConstantFieldsInterface.P_UNIQUE_GROUPING_ID);

	      // If P_UNIQUE_GROUPING_ID already has a value, it will be used as the key for the later storage in the accumulations map.
	      if(sUniqueGroupingID != null) sAccumulationsMapKey = sUniqueGroupingID;

	      // If P_UNIQUE_GROUPING_ID is null, the key will be the MID.
	      else pdo.set(PDOConstantFieldsInterface.P_UNIQUE_GROUPING_ID, sAccumulationsMapKey);

	      logger.info(sTracePrefix + "successful manipulation rule execution; sets unique grouping ID to %s", sAccumulationsMapKey);
	    }
	    else
	    {
	    	logger.info(sTracePrefix + "un-Successful manipulation rule execution; only one payment will be stored");
	    }

	    // If requires, upadtes the accumulations map.
	    if(!accumulationsMap.containsKey(sAccumulationsMapKey))
	    {
	    	logger.info(sTracePrefix + "updates accumulations map - entry key: %s", sAccumulationsMapKey);

	      // If this is new entry in the accumulation map, create new accumulation object
	      String status = !pdo.getDate(PDOConstantFieldsInterface.P_PROC_DT).after(pdo.getDate(PDOConstantFieldsInterface.F_OFFICE_BDT))
	      						? SubBatchProcessInterface.STATUS_READY_FOR_SUB_BATCH : SubBatchProcessInterface.STATUS_SCHEDULE_SUB_BATCH;

	      String sourceCcyLogicalField = msgClass == MsgClassType.DD ? PDOConstantFieldsInterface.P_CDT_ACCT_CCY : PDOConstantFieldsInterface.X_STTLM_CCY;
	      String destCcyLogicalField = msgClass == MsgClassType.DD ? PDOConstantFieldsInterface.X_STTLM_CCY : PDOConstantFieldsInterface.P_DBT_ACCT_CCY;

	      // Adds new object to map with static arguments.
	      accumulationsMap.put(sAccumulationsMapKey,
	      		                 new PreProcessAccumulations(sAccumulationsMapKey, sMID,status,pdo.getString(PDOConstantFieldsInterface.P_OFFICE),
	                                                       pdo.getString(msgClass.getSourceAccoutNoLogicalField()),new java.sql.Date(pdo.getDate(PDOConstantFieldsInterface.X_STTLM_DT_1B).getTime()),null,
	                                                       new java.sql.Date(pdo.getDate(PDOConstantFieldsInterface.P_PROC_DT).getTime()),
	                                                       pdo.getString(destCcyLogicalField),pdo.getString(sourceCcyLogicalField),
	                                                       pdo.getString(PDOConstantFieldsInterface.P_BASE_CCY), pdo.getString(PDOConstantFieldsInterface.P_SUSPENSE_ACCT_UID), msgClass.name(), null));
	    }

	    // Gets the relared accumulations entry and upadtes it.
	    PreProcessAccumulations accumulations = accumulationsMap.get(sAccumulationsMapKey);
//	    accumulations.addPdo(pdo);
	    //
	    // Upadtes total credit amount.
	    double amount = pdo.getDecimal(PDOConstantFieldsInterface.X_STTLM_AMT) != null ? pdo.getDecimal(PDOConstantFieldsInterface.X_STTLM_AMT).doubleValue() : 0;
	    accumulations.addToSttlmTotalAmt(amount);
	    //
	    // Upadtes total debit amount.
	    amount = pdo.getDecimal(msgClass.getSourceAmountLogicalField()) != null ? pdo.getDecimal(msgClass.getSourceAmountLogicalField()).doubleValue() : 0;
	    accumulations.addToPartyTotalAmt(amount);
	    //
	    // Upadtes total base amount.
	    amount = pdo.getDecimal(PDOConstantFieldsInterface.P_BASE_AMT) != null ? pdo.getDecimal(PDOConstantFieldsInterface.P_BASE_AMT).doubleValue() : 0;
	    accumulations.addToBaseTotalAmt(amount);
	    //
	    // Increments message count.
	    accumulations.incMsgCount();

	    logger.info(sTracePrefix + TRACE_METHOD_RESULTS,new Object[]{ sAccumulationsMapKey, accumulations.getPartyTotalAmt(), accumulations.getSttlmTotalAmt(), accumulations.getBaseTotalAmt(), accumulations.getMsgCount()});

	     

	    return feedback;
	  }


   public void performPostexecutions(Object o)throws Throwable
   {

   }

   public String getOutFileHeader(RebulkFileData rebulkFile, PDO pdo)
   {
	   return "";
   }

   public String getOutFileTrailer()
   {
	   return "";
   }

   
   public final Admin newContextAdmin(final String sContextId, final CallSource enumCallSource) { 
		//first check if there is a context admin and if so use it
		Admin admin = Admin.getContextAdmin() ;
		
		if(admin != null) { 
			//System.err.println(String.format("admin %s already exists, aborting creation for context id %s and callsource %s", admin, sContextId, enumCallSource))  ; 
			return admin ; 
		}//EO if admin was already created 
		//else initialise the admin for the complete initialisation flow
       admin = enumCallSource.newAdmin(sContextId) ; 
       
       //initialise the webfile tracer (getInstance() will initialise it) and 
       //set the context root for future use 
       //Admin.m_contextTracer.set(this.m_tracer) ;
       //set the admin in its thread local context 
       Admin.setContextAdmin(admin) ; 
       
       return admin ; 
	}//EOM
   
   private static final Logger logger = LoggerFactory.getLogger(WorkflowType.class);
}//EOE WorkflowType
