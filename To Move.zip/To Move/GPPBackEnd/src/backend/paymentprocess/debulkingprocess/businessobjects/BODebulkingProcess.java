package backend.paymentprocess.debulkingprocess.businessobjects;

import static com.fundtech.util.GlobalUtils.isNullOrEmpty;

import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.xmlbeans.XmlObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.businessobject.BOProxies;
import backend.businessobject.tx.RemoveDupexFromCacheLastResourceHandler;
import backend.core.module.MessageConstantsInterface;
import backend.core.module.ejbinterfaces.TxIsolation;
import backend.paymentprocess.SubBatchProcessInterface;
import backend.paymentprocess.baseprocess.businessobjects.BOBaseProcess;
import backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi.AckXmlTransactionReader;
import backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi.FileMessageTypeData;
import backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi.FndtBatchMsgSupport;
import backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi.XmlTransactionReaderBase;
import backend.paymentprocess.enrichment.commons.InterfaceSubTypeFlow;
import backend.paymentprocess.erroraudit.ErrorAuditUtils;
import backend.paymentprocess.g3utils.G3BulkChecksumCalculation;
import backend.paymentprocess.interfaces.common.TransmissionType;
import backend.paymentprocess.mopselection.common.MsgClassType;
import backend.paymentprocess.processedchunks.businessobjects.BOProcessedChunks;
import backend.staticdata.profilehandler.message.dataaccess.dao.DAOFILE_SUMMARY;
import backend.util.ServerConstants;
import backend.util.ServerUtils;

import com.fundtech.cache.entities.Banks;
import com.fundtech.cache.entities.FileSummary;
import com.fundtech.cache.entities.InterfaceTypes;
import com.fundtech.cache.entities.MsgTypes;
import com.fundtech.cache.entities.PreProcessAccumulations;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.cache.infrastructure.regions.CacheKeys.ProcessPdoPerUniqueGroupIdKey.ProcessPdoPerGroupIdEntry;
import com.fundtech.core.general.flows.FlowException;
import com.fundtech.core.general.tx.LastResourceInterface;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.core.paymentprocess.data.das.DASInterface.XmlLocationType;
import com.fundtech.core.paymentprocess.data.paymenttypes.PaymentType;
import com.fundtech.core.paymentprocess.errorhandling.ProcessError;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.datacomponent.response.SimpleResponseDataComponent;
import com.fundtech.errors.ProcessErrorConstants;
import com.fundtech.interfaces.InterfaceTypeConstants;
import com.fundtech.jndi.ServiceLocator;
import com.fundtech.scl.debulkingProcessService.FileIndexDataType;
import com.fundtech.scl.debulkingProcessService.PerformDebulkingMultiRequestDocument;
import com.fundtech.scl.massPayment.PerformDebulkingAckRequsetDocument;
import com.fundtech.scl.massPayment.ProcessSubBatchGenerationRequestDocument;
import com.fundtech.util.ExceptionController;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalDateTimeUtil;
import com.fundtech.util.GlobalUtils;



public class BODebulkingProcess extends BOMassPayment implements SubBatchProcessInterface, PDOConstantFieldsInterface, MessageConstantsInterface
{

	private static final Logger logger = LoggerFactory.getLogger(BODebulkingProcess.class);
	private static final String CLEAR_PDOS_FAILURE_MSG = "The following error occured while trying to clear the pdo's from the cache";

	private static final String SERVICE_DEBULKING_PROCESS = "Debulking process, (preprocessing)";
	private static final String LAST_STEP = "Last step: ";
	private static final String STEP_GET_XML_OBJECT_FROM_FILE_PROCESS_DISTRIBUTION = "Getting xml object from FILE_PROCESS_DISTRIBUTION";
	private static final String STEP_GET_PDO_OBJECTS_FROM_CHUNK = "Getting PDO objects from XML chunk";
	private static final String STEP_BASE_PROCESSING_EXECUTION = "Executes base processing for PDO {} out total chunk size of {}, MID: {}.";
	private static final String STEP_GRACEFUL_TERMINATION = "Graceful termination for PDO {} out total chunk size of {}, MID: {}.";
	private static final String STEP_PERFORM_ACCUMULATIONS = "Perform accumulation for PDO {} out total chunk size of {}, MID: {}.";
	private static final String STEP_BATCH_SAVE = "Batch save for chunk {} with total size of {}.";
	private static final String STEP_FILE_PROCESS_DISTRIBUTION_UPDATE = "FILE_PROCESS_DISTRIBUTION update";
	private static final String STEP_FILE_SUBSET_CHUNKS_UPDATE = "FILE_SUBSET_CHUNKS update";


	private static Method m_performDebulkPreProcessingInner = null;
	private static Method m_performDebulkMultiPreProcessingInner = null;
	private static Method m_performDebulkMultiPreProcessingForWaitingPaymentsInner = null;
	private static Method m_performAckDebulkPreProcessingInner = null;
	
	static
	{
		try
		{
			m_performDebulkPreProcessingInner = BODebulkingProcess.class.getDeclaredMethod("performDebulkPreProcessingInner", String.class);
			m_performDebulkMultiPreProcessingInner = BODebulkingProcess.class.getDeclaredMethod("performDebulkMultiPreProcessingInner", String.class);
			m_performDebulkMultiPreProcessingForWaitingPaymentsInner = BODebulkingProcess.class.getDeclaredMethod("performDebulkMultiPreProcessingForWaitingPaymentsInner", String.class);
			m_performAckDebulkPreProcessingInner = BODebulkingProcess.class.getDeclaredMethod("performAckDebulkPreProcessingInner", String.class);
		}catch(Exception e)
		{
			logger.error(e.getMessage());
		}
	}
	/**
	 *
	 */
	public  SimpleResponseDataComponent performDebulkPreProcessing(String tuple) throws FlowException
	{
		return (SimpleResponseDataComponent) super.executeInProtectedBoundaries(m_performDebulkPreProcessingInner, tuple);
	}

	public  SimpleResponseDataComponent performDebulkMultiPreProcessing(String tuple) throws FlowException
	{
		return (SimpleResponseDataComponent) super.executeInProtectedBoundaries(m_performDebulkMultiPreProcessingInner, tuple);
	}


	public  SimpleResponseDataComponent performDebulkMultiPreProcessingForWaitingPayments(String tuple) throws FlowException
	{
		return (SimpleResponseDataComponent) super.executeInProtectedBoundaries(m_performDebulkMultiPreProcessingForWaitingPaymentsInner, tuple);
	}

	public  SimpleResponseDataComponent performAckDebulkPreProcessing(String tuple) throws FlowException
	{
		return (SimpleResponseDataComponent) super.executeInProtectedBoundaries(m_performAckDebulkPreProcessingInner, tuple);
	}

	/**
	 * performDebulkMultiPreProcessing
	 *
	 * @author dmitryp
	 */
	private  SimpleResponseDataComponent performDebulkMultiPreProcessingInner(String tuple) throws FlowException
	{
		PerformDebulkingMultiRequestDocument doc = null;
		SimpleResponseDataComponent response = new SimpleResponseDataComponent();

		try {

			doc = PerformDebulkingMultiRequestDocument.Factory.parse(tuple);

		} catch (Exception e) {

			throw new FlowException(e);
		}

		response.setFeedback(runDebulk(doc));

		return response;

	}//EOM performDebulkMultiPreProcessing

	/**
	 * performAckDebulkPreProcessingInner
	 */
	private  SimpleResponseDataComponent performAckDebulkPreProcessingInner(String tuple) throws FlowException
	{
		PerformDebulkingAckRequsetDocument doc = null;
		SimpleResponseDataComponent response = new SimpleResponseDataComponent();

		try {

			doc = PerformDebulkingAckRequsetDocument.Factory.parse(tuple);

		} catch (Exception e) {

			throw new FlowException(e);
		}

		response.setFeedback(runDebulk(doc));

		return response;

	}//EOM performValidationDebulkPreProcessingInner


	private  SimpleResponseDataComponent performDebulkMultiPreProcessingForWaitingPaymentsInner(String tuple) throws FlowException
	{
		SimpleResponseDataComponent response = new SimpleResponseDataComponent();

		try {

			String[] tupleArr = tuple.split(",");
			String interfaceName = tupleArr[0];
			String internalFileId = tupleArr[1];
			String chunkId = tupleArr[2];
			String groupId = tupleArr.length > 3 ? tupleArr[3] : null;

			ProcessPdoPerGroupIdEntry processPdoPerGroup = getProcessPdoPerGroupId(internalFileId, chunkId, groupId);
			List<PDO> listPDO = processPdoPerGroup != null ? processPdoPerGroup.getEntry() : new ArrayList<PDO>();
			InterfaceTypes interfaceType = CacheKeys.interfaceTypesNameKey.getSingle(interfaceName);
			if (interfaceType != null ) interfaceType.getInHandler().handleIn(listPDO);
			runDebulkInner(listPDO, internalFileId, SubBatchProcessInterface.STATUS_FILE_DISTRIBUTED, chunkId, 500, null, null, true, new Feedback(), null);			
			m_dao.updateFileInterfaceBuffersStatus(null, BOProcessedChunks.STATUS_PROCESSED, internalFileId, chunkId, groupId);
			CacheKeys.processPdoPerUniqueGroupIdKey.removeSingle(processPdoPerGroup);
		} catch (Throwable e) {
			throw new FlowException(e);
		}
		return response;

	}//EOM performDebulkMultiPreProcessing





	private SimpleResponseDataComponent performDebulkPreProcessingInner(String tuple) throws FlowException
	{
		String[] arr = tuple.split(GlobalConstants.PERMISSIONS_DELIMITER);
		tuple = arr[0];
		String message = arr[1];
		arr = GlobalConstants.m_commaSplitPattern.split(tuple, 0) ;
		SimpleResponseDataComponent response = new SimpleResponseDataComponent() ;
		response.setFeedback(runDebulk(arr[0], arr[1],arr[2],message, arr.length == 4 ? arr[3] : null, false, null));

		return response;
	}

	/**
	 * runDebulk
	 *
	 * @author dmitryp
	 */
	private Feedback runDebulk(PerformDebulkingMultiRequestDocument doc) throws FlowException
	{

		logger.info("[DAODebulkingProcess.runDebulk()] - START");

		String chunkId = doc.getPerformDebulkingMultiRequest().getChunkId();
		String bulkId = doc.getPerformDebulkingMultiRequest().getBulkId();
		String internalFileId = doc.getPerformDebulkingMultiRequest().getInternalFileId();
		String status = doc.getPerformDebulkingMultiRequest().getStatus();
		String ccy = null;
		String sTracePrefix = String.format("'runDebulk', (Internal file ID: %s, Chunk ID: %s); ", internalFileId, chunkId);

		//logger.info(TRACE_START);
		logger.info(sTracePrefix);
		//logger.info(TRACE_START);


		Feedback feedback = new Feedback();

		String sLastStep = null;


		PDO[] pdoArr= null;

		try
		{

			int priority = 500;



			// Gets xml object from file_process_distribution table.
			sLastStep = STEP_GET_XML_OBJECT_FROM_FILE_PROCESS_DISTRIBUTION;
			//
			boolean bXMLChunkWasFound = doc != null;
			logger.debug(sTracePrefix + "XML file was found: {}", bXMLChunkWasFound);

			// XML file was found.
			if(bXMLChunkWasFound) {
				final Map[] arrMapSharedPDOContextHolder = new Map[1];
				sLastStep = STEP_GET_PDO_OBJECTS_FROM_CHUNK;

				PDO tempPdo = PaymentDataFactory.newPDO(PaymentType.valueOf(PaymentType.PT_PACS_008), true/*bTransient*/);
				//set the temp pdo in the admin
				Admin.setContextPDO(tempPdo);

				tempPdo.set(PDOConstantFieldsInterface.P_IN_INTERNAL_FILEID, internalFileId);

				final FileSummary incomingFileSummary = fileSummaryAttemptRetrieve(tempPdo) ;
				
				FileIndexDataType fileIndexData = doc.getPerformDebulkingMultiRequest().getFileIndexDataTypeListArray(0);
				String paymentType = fileIndexData.getPaymentType();
				
				XmlTransactionReaderBase reader = getReader(paymentType);
				
				List<PDO> pdoList = reader.getPDOsFromChunk(doc, chunkId, internalFileId, incomingFileSummary,arrMapSharedPDOContextHolder);
				Banks office = CacheKeys.banksKey.getSingle(incomingFileSummary.getOffice());
				for (PDO pdo : pdoList){//workaround for sending only 2 digits after decimal point
					BigDecimal amount = pdo.getDecimal(PDOConstantFieldsInterface.X_STTLM_AMT);
					ccy = office != null ? office.getCurrency() : pdo.getNSetOffice().getCurrency();
					pdo.set(PDOConstantFieldsInterface.X_STTLM_AMT, GlobalUtils.adjustPrecisionBD(amount,ccy));
				}
				
				runDebulkInner(pdoList, internalFileId, status, chunkId, priority, arrMapSharedPDOContextHolder,paymentType, false,feedback, bulkId);
				
			}

			else
			{
				logger.info("ERROR: XML chunk wasn't found in database - Internal file ID: {}, Chunk ID: {}.", internalFileId, chunkId);
			}
		}
		catch(Throwable e)
		{
			logger.info(LAST_STEP + sLastStep);
			Feedback failureFeedback = new Feedback();
			ProcessError pError = new ProcessError(ProcessErrorConstants.ServiceFailureWithLastStep, new Object[]{SERVICE_DEBULKING_PROCESS, sLastStep});
			configureErrorFeedback(1, pError.getDescription(), failureFeedback);
			logger.info(ServerUtils.getFeedbackString(failureFeedback));

			clearPdosFromCache(pdoArr);



			ExceptionController.getInstance().handleException(e, this);
			throw new FlowException(e);
		}
		finally
		{
			//clear the CacheKeys.preProcessAccumulationsKey region
			CacheKeys.preProcessAccumulationsKey.removeSingle(chunkId) ;
		}

		//logger.info(TRACE_END);
		logger.info(sTracePrefix);
		//logger.info(TRACE_END);

		if(!feedback.m_bIsSuccessful) logger.info(ServerUtils.getFeedbackString(feedback));

		return feedback;

	}//EOM runDebulk

	/**
	 * Workaround, Since in some cases MQ is commited before the DB
	 * see Defect #82304
	 * @param pdo
	 * @return
	 */
	private FileSummary fileSummaryAttemptRetrieve(PDO pdo)
	{
		FileSummary fileSummary = pdo.getNSetIncomingFileSummary();
		if(fileSummary==null)
		{
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				logger.error(e.getMessage(),e);
			}
			fileSummary = pdo.getNSetIncomingFileSummary();
		}
		return fileSummary;
	}
	
	private XmlTransactionReaderBase getReader(String paymentTypeName) {
		XmlTransactionReaderBase reader = null;
		
		//TBD , maybe add FndtBatchMsg as Dummy PaymentType
		if (FndtBatchMsgSupport.isFndtMsgPaymentType(paymentTypeName))
			return FndtBatchMsgSupport.getReader(paymentTypeName);
			
		PaymentType paymentType = PaymentType.valueOf(paymentTypeName);
		reader = ((FileMessageTypeData)paymentType.getTrnsReaderNewInstance()).getReader();
		return reader;
	}

	/**
	 * runDebulk for Ack (Validation) File
	 */
	private Feedback runDebulk(PerformDebulkingAckRequsetDocument doc) throws FlowException
	{

		final String startMethodTrace = "reuDebulk for Ack file - Internel file ID : {} , Chunk ID : {} ";
		 

		boolean continueToNextStep = false;
		String internalFileId = doc.getPerformDebulkingAckRequset().getInternalFileID();
		String outChunkId = doc.getPerformDebulkingAckRequset().getOutChunkID();//The original Out chunk
		String AckChunkId = doc.getPerformDebulkingAckRequset().getInChunkID();//Ack Chunk ID (Belong to the CVF file)
		String status = doc.getPerformDebulkingAckRequset().getStatus();
		logger.info(startMethodTrace,internalFileId,outChunkId);

		Feedback feedback = new Feedback();
		String sLastStep = null;
		Map<String, PreProcessAccumulations> accumulationsMap =  new HashMap<String, PreProcessAccumulations>();


		try
		{
			final Map[] arrMapSharedPDOContextHolder = new Map[1] ;
			sLastStep = STEP_GET_PDO_OBJECTS_FROM_CHUNK;

			List<PDO> pdoList = AckXmlTransactionReader.getPDOsFromChunk(doc,outChunkId,internalFileId,arrMapSharedPDOContextHolder);

			rejectPayments(pdoList,internalFileId,AckChunkId,accumulationsMap, feedback);

			continueToNextStep = !MESSAGE_TYPE_PACS_004.equals(pdoList.get(0).get(P_MSG_TYPE));
			
			if (continueToNextStep) 
			{
				//Transmit and Update FILE_PROCESS_DISTRIBUTION ,  FILE_VALIDATION_SUBSET_CHUNKS
				feedback = runDebulkInner(internalFileId,AckChunkId,status,accumulationsMap,feedback);
			}
			
			if (feedback.isSuccessful()) 
			{
				int iSize = pdoList.size();
				PDO[] arrPDO = pdoList.toArray(new PDO[iSize]);
				PaymentDataFactory.batchSave(false, arrPDO);
				CacheKeys.ProcessPDOKey.removeFromLocalAndRemote(pdoList);
			}

		}
		catch(Throwable e)
		{
			logger.info(LAST_STEP + sLastStep);
			Feedback failureFeedback = new Feedback();
			ProcessError pError = new ProcessError(ProcessErrorConstants.ServiceFailureWithLastStep, new Object[]{SERVICE_DEBULKING_PROCESS, sLastStep});
			configureErrorFeedback(1, pError.getDescription(), failureFeedback);
			logger.info(ServerUtils.getFeedbackString(failureFeedback));

			ExceptionController.getInstance().handleException(e, this);
			throw new FlowException(e);
		}

		 

		if(!feedback.m_bIsSuccessful) logger.info(ServerUtils.getFeedbackString(feedback));

		return feedback;
	}

	private void rejectPayments(List<PDO> pdoList, String internalFileId,
			String ackChunkId,
			Map<String, PreProcessAccumulations> accumulationsMap,
			Feedback feedback) {
		for(PDO pdo:pdoList){
			String prevStatus=pdo.getString(PDOConstantFieldsInterface.P_MSG_STS);
			
			if (!prevStatus.equals(MESSAGE_STATUS_REJECTED))
			{
				pdo.set(PDOConstantFieldsInterface.P_MSG_STS, MESSAGE_STATUS_REJECTED);
				
				String[] arrErrorParams = new String[] { prevStatus, MESSAGE_STATUS_REJECTED };
				ProcessError pError = new ProcessError(ProcessErrorConstants.MessageStatusChanged, (Object[]) arrErrorParams);
				ErrorAuditUtils.setErrors(pError, pdo);
				
				pdo.getField(P_MSG_STS).setOriginalValue(MESSAGE_STATUS_REJECTED);
				
				logger.info(pError.getDescription());
			}
		}
	}

	private boolean executeBusinessFlowSelector(List<PDO> pdoList ,String internalFileId ,String chunkId ,Map<String, PreProcessAccumulations> accumulationsMap,Feedback feedback ) throws Throwable{

		 
		String sHandledPDODataPrefix = null;
		int iChunkSize = pdoList.size();
		int i = 0;
		final boolean shouldPerformNextStep = iChunkSize > 0 ;

		Admin admin = Admin.getContextAdmin();
		for(PDO pdo: pdoList)
		{
			String mid = pdo.getMID();
			sHandledPDODataPrefix = String.format("Debulking process for PDO %s out of %s - MID: %s, Chunk ID: %s, PDO ID: %s; ", (i+1), iChunkSize, mid, chunkId, pdo);
			String sOldStatus = pdo.getString(PDOConstantFieldsInterface.P_MSG_STS);
			logger.info(sHandledPDODataPrefix + "executes base processing; PDO Status: {}", sOldStatus);
			//Execute flow on payment
			pdo.promoteToPrimary();
			final HashMap mapContext = new HashMap() ;
			final SimpleResponseDataComponent interfaceResponse =	BOProxies.m_internalInterfacesLogging.performOutgoingRequestHandler(admin,pdo.getMID(),"FLOWS","OUT",mapContext) ;

			String sNewStatus = pdo.getString(PDOConstantFieldsInterface.P_MSG_STS);
			feedback = interfaceResponse.getFeedback();

			logger.info("{} finished base processing; Old Status: {}, New status: {}, Feedback: {}", new Object[]{sHandledPDODataPrefix,sOldStatus,
					sNewStatus,ServerUtils.getFeedbackString(feedback)});

			//If get feedback failure after execute flow on the payment throw exceptoin in order to stop the process

			if (feedback.m_bIsSuccessful)
				performAccumulationsForValidationFile(accumulationsMap ,internalFileId, chunkId, pdo.getMID()) ;
			else
				throw new FlowException(feedback);

			logger.info(sHandledPDODataPrefix + "finished handling for this message");

		}

		 

		return shouldPerformNextStep;
	}//EOM executeBusinessFlowSelector

	protected PDO[] executeBusinessFlowSelector(List<PDO> pdoList,String internalFileId, String chunkId,AmountHolder amounts,List<PDO> persistentPdoList,Map<String, StoreRequest> requestMap,
			String workflowType, Map<String, PreProcessAccumulations> accumulationsMap , Map<String, List<PDO>> paymentsForCahce , Feedback feedback) throws Throwable {
		int iChunkSize = pdoList.size();
		PDO[] pdoArr = new PDO[iChunkSize];
		int i = 0;
		String sHandledPDODataPrefix = null;
		Admin admin = Admin.getContextAdmin();
		FileSummary incomingFileSummary = null;
		String pmntSrc = null;
		
		for(PDO pdo: pdoList)
		{
			
			String mid = pdo.getMID();
			sHandledPDODataPrefix = String.format("[PDO %s(%s)(%s)]: ", (i+1), iChunkSize, chunkId);
			String sOldStatus = pdo.getString(PDOConstantFieldsInterface.P_MSG_STS);

			logger.info("{} executes base processing; PDO Status: {}. PDO: {}", new Object[]{sHandledPDODataPrefix,sOldStatus,pdo});
			preparePDO(pdo, internalFileId, chunkId, workflowType);
			
			if (null==pmntSrc)
			{
				incomingFileSummary = fileSummaryAttemptRetrieve(pdo);
				pmntSrc = incomingFileSummary != null ? incomingFileSummary.getFileSource() : MessageConstantsInterface.PMNT_SRC_FDR;
				logger.debug("pmntSrc was set for the first time to {}",pmntSrc);
			}
			pdo.set(PDOConstantFieldsInterface.P_PMNT_SRC, pmntSrc);
			Admin.setContextPDO(pdo);
			Admin.enrichMDC("I(P)");
			BOProxies.m_businessFlowSelectorLogging.executeFlow(admin,pdo.getMID(),false,ServerConstants.EMPTY_OBJECT_ARRAY);
			String sNewStatus = pdo.getString(PDOConstantFieldsInterface.P_MSG_STS);
			logger.info("{} finished base processing; Old Status: {}, New status: {}, Feedback: {}"
					,new Object[]{ sHandledPDODataPrefix,sOldStatus,sNewStatus, ServerUtils.getFeedbackString(feedback)});

			performFinalStep(pdo, sHandledPDODataPrefix, amounts, internalFileId, chunkId, persistentPdoList,
					requestMap, accumulationsMap, paymentsForCahce, feedback);
			pdoArr[i++] = pdo;

			logger.info("{} finished handling for this message",sHandledPDODataPrefix);
		}

		return pdoArr;

			}//EOM executeFlowInner


	protected void performFinalStep(PDO pdo, String sHandledPDODataPrefix, AmountHolder amounts, String internalFileID, String chunkId, List<PDO> persistentPdoList, Map<String, StoreRequest> requestMap,
			Map<String, PreProcessAccumulations> accumulationsMap , Map<String, List<PDO>> paymentsForCahce , Feedback feedback) throws Throwable
			{
				
				String sNewStatus = pdo.getString(PDOConstantFieldsInterface.P_MSG_STS);
				String sOrgMsgType = pdo.getString(PDOConstantFieldsInterface.P_ORIG_MSG_TYPE);
				logger.info("{} status after graceful termination: {}, performing final step", sHandledPDODataPrefix,sNewStatus);
		
				boolean hasWaitStatus = false;
				boolean hasMsgstatus = false;
				boolean hasPainMsg = false;
				hasWaitStatus = isBulkInterfaceHasWaitStatus(pdo);
				
				hasMsgstatus = sNewStatus.equals(MessageConstantsInterface.MESSAGE_STATUS_WAITSUBBATCH)
								|| sNewStatus.equals(MessageConstantsInterface.MESSAGE_STATUS_WAITSCHEDSUBBATCH)
								|| sNewStatus.equals(MessageConstantsInterface.MESSAGE_STATUS_PENDING_FILE_APPROVAL);
				
				hasPainMsg = sOrgMsgType.indexOf("Pain")>-1;
		
				boolean isValidPainMsg = hasPainMsg && hasMsgstatus && feedback.m_bIsSuccessful;
				boolean isValidNonPainMsg = !hasPainMsg && !(MESSAGE_STATUS_REJECTED.equals(sNewStatus) || MESSAGE_STATUS_REPAIR.equals(sNewStatus) || MESSAGE_STATUS_ROFI.equals(sNewStatus));
				double amount = pdo.getDecimal(OX_STTLM_AMT) != null ? pdo.getDecimal(OX_STTLM_AMT).doubleValue() : 0;
				
				if (!hasWaitStatus){
					amounts.addStlmAmt(amount);
				}
				
				//TODO: In below condition to check if it is SCF the hasPainMsg condition needs to be replaced with file_summary.pl_file_type != SCF
				/*if(   feedback.m_bIsSuccessful
						&& (   sNewStatus.equals(MessageConstantsInterface.MESSAGE_STATUS_WAITSUBBATCH) || sNewStatus.equals(MessageConstantsInterface.MESSAGE_STATUS_WAITSCHEDSUBBATCH)
								|| sNewStatus.equals(MessageConstantsInterface.MESSAGE_STATUS_PENDING_FILE_APPROVAL) || hasWaitStatus))*/
				
				if (isValidNonPainMsg || hasWaitStatus || isValidPainMsg ) {
					if (hasWaitStatus){
						String cacheKey = pdo.getString(PDOConstantFieldsInterface.P_UNIQUE_GROUPING_ID);
						cacheKey = cacheKey == null ? "":cacheKey;

						if (!paymentsForCahce.containsKey(cacheKey)) 
							paymentsForCahce.put(cacheKey, new ArrayList<PDO>());
						
						paymentsForCahce.get(cacheKey).add(pdo);
					} else {
						feedback = performAccumulations(internalFileID, chunkId, pdo.getMID(),accumulationsMap, paymentsForCahce,false);
					}
				} else {
					feedback=setUniqueGroupingID(pdo);
					if (GlobalUtils.isNullOrEmpty(pdo.getString(PDOConstantFieldsInterface.P_UNIQUE_GROUPING_ID)))
					{
						pdo.set(PDOConstantFieldsInterface.P_UNIQUE_GROUPING_ID,internalFileID);			
					}
					feedback = performAccumulations(internalFileID, chunkId, pdo.getMID(),accumulationsMap, paymentsForCahce,true);
					handleFailure(persistentPdoList, pdo, sNewStatus, sHandledPDODataPrefix, amount,amounts);
				}
				
				handleBatchInterfaceAndReturnHasWaitStatus(pdo, requestMap);
			}


	public void handleFailure(List<PDO> persistentPdoList, PDO pdo, String sNewStatus, String sHandledPDODataPrefix, double amount, AmountHolder amounts)
	{
		if (persistentPdoList != null) persistentPdoList.add(pdo);
		if (MessageConstantsInterface.MESSAGE_STATUS_REJECTEDDUPEX.equals(sNewStatus) || MessageConstantsInterface.MESSAGE_STATUS_DUPEX.equals(sNewStatus))
		{
			logger.info(sHandledPDODataPrefix + "un-Successful base processing; increments total duplicate amount and total duplicate payments count");
			amounts.addStlmAmtDuplicate(amount);
			amounts.incDuplicateCount();
		}
		else if ((MessageConstantsInterface.MESSAGE_STATUS_REPAIR.equals(sNewStatus)) || (MessageConstantsInterface.MESSAGE_STATUS_ROFI.equals(sNewStatus)))
        {
            logger.info(sHandledPDODataPrefix + "un-Successful base processing; increments total repair amount and total repair payments count");
            amounts.addStlmAmtRepair(amount);
            amounts.incRepairCount();
		}else
		{
			logger.info(sHandledPDODataPrefix + "un-Successful base processing; increments total rejected amount and total rejected payments count");
			amounts.addStlmAmtRejected(amount);
			amounts.incRejectedCount();
		}

	}

	public Feedback setUniqueGroupingID(PDO pdo)
	{
    	// Executes rule with rule type MSG TYPE SELECTION and then script execution of type 'Bulk unique group id' which will update
    	// P_UNIQUE_GROUPING_ID logical field.
    	pdo.set(PDOConstantFieldsInterface.D_RULE_TYPE_ID, MessageConstantsInterface.RULE_TYPE_ID_UNIQUE_GROUPING_RULE_SELECTION);
    	pdo.set(PDOConstantFieldsInterface.D_ACTION_ID, pdo.get(PDOConstantFieldsInterface.P_OFFICE));
    	logger.info("executes unique grouping ID selection MANIPULATION rule, (rule type ID 140)");
    	Feedback feedback =BOProxies.m_messageHandleLogging.manipulateMessageData(Admin.getContextAdmin(), pdo.getString(P_MID),
    			new String[]{pdo.getString(PDOConstantFieldsInterface.P_OFFICE), ServerConstants.DEFAULT_SERVER_OFFICE_NAME}).getFeedback();
    	return feedback;
	}
	
	public Feedback performAccumulations(String sInternalFileID, String sChunkId, String sMID, 
			Map<String, PreProcessAccumulations> accumulationsMap , Map<String, List<PDO>> paymentsForCahce,boolean isRejected) throws Throwable
			{
		final String TRACE_METHOD_RESULTS = "updated accumultions map - key: {}, Total debit amount: {}, Total credit amount: {}, Total base amount: {}, Messages count: {} value Time {}.";

		
		String sTracePrefix = null ;
		sTracePrefix = String.format("'performAccumulations', (Internal file ID: %s, Chunk ID: %s, MID: %s; ); ", sInternalFileID, sChunkId, sMID);

		Feedback feedback = new Feedback();

		PDO pdo = PaymentDataFactory.load(sMID);
		MsgClassType msgClass = BOBaseProcess.isDD(pdo) ? MsgClassType.DD : MsgClassType.CT;
		
		String sAccumulationsMapKey = sInternalFileID;
//		if ("false".equals(pdo.get(PDOConstantFieldsInterface.OX_BTCH_BOOKG))) {
//			logger.debug("no need to derive suspense account as batch booking is false");
//		} else {
//			logger.debug("derive suspense account");
		logger.debug("About to derive suspense account");
		BOProxies.m_suspenseAccountDerivationLogging.suspenseAccountDerivation(Admin.getContextAdmin(), sMID);
	//	}
		
		feedback=setUniqueGroupingID(pdo);

		// Success; sets the
		if(feedback.isSuccessful())
		{
			// if every thing executed successfully, set the key as unique grouping id
			String sUniqueGroupingID = pdo.getString(PDOConstantFieldsInterface.P_UNIQUE_GROUPING_ID);

			// If P_UNIQUE_GROUPING_ID already has a value, it will be used as the key for the later storage in the accumulations map.
			if(sUniqueGroupingID != null) sAccumulationsMapKey = sUniqueGroupingID;

			// If P_UNIQUE_GROUPING_ID is null, the key will be the MID.
			else pdo.set(PDOConstantFieldsInterface.P_UNIQUE_GROUPING_ID, sAccumulationsMapKey);

			logger.info(sTracePrefix + "successful manipulation rule execution; sets unique grouping ID to {}", sAccumulationsMapKey);
		}else { 
			logger.info(sTracePrefix + "un-Successful manipulation rule execution; only one payment will be stored");
		}
		
		// If requires, upadtes the accumulations map.

		if(!accumulationsMap.containsKey(sAccumulationsMapKey))
		{
			logger.info(sTracePrefix + "updates accumulations map - entry key: {}", sAccumulationsMapKey);

			// If this is new entry in the accumulation map, create new accumulation object
			String status = !pdo.getDate(PDOConstantFieldsInterface.X_STTLM_DT_1B).after(pdo.getDate(PDOConstantFieldsInterface.F_OFFICE_BDT))
			? SubBatchProcessInterface.STATUS_READY_FOR_SUB_BATCH : SubBatchProcessInterface.STATUS_SCHEDULE_SUB_BATCH;

			String sourceCcyLogicalField = msgClass == MsgClassType.DD ? PDOConstantFieldsInterface.P_CDT_ACCT_CCY : PDOConstantFieldsInterface.X_STTLM_CCY;
			String destCcyLogicalField = msgClass == MsgClassType.DD ? PDOConstantFieldsInterface.X_STTLM_CCY : PDOConstantFieldsInterface.P_DBT_ACCT_CCY;
			XmlObject payment = PaymentDataFactory.transformToXml(pdo.getMID(),PaymentType.valueOf("ORIG_PERSISTENT_DATA"), XmlLocationType.XML_MSG, null,null);
			// Adds new object to map with static arguments.
			
			// Workaround for Defect #79853 - in case of RT Bulk
			// The account inquiry execution moved to sub-batch generation and sub-batch completion flows
			// and so: {msgClass.getSourceAccoutNoLogicalField(), destCcyLogicalField} might contain null values.
			String sourceAcctNo = msgClass.getSourceAccoutNoLogicalField();
			if(GlobalConstants.RT.equals(pdo.get("P_BUSINESS_FLOW_TP")))
			{
				if(msgClass == MsgClassType.CT)
				{
					if(pdo.getString(msgClass.getSourceAccoutNoLogicalField()) == null)
						sourceAcctNo = PDOConstantFieldsInterface.X_DBTR_ACCT_ID;
					if(pdo.getString(destCcyLogicalField) == null)
						destCcyLogicalField = PDOConstantFieldsInterface.X_DBTR_ACCT_CCY;
				}
				if(msgClass == MsgClassType.DD)
				{
					if(pdo.getString(msgClass.getSourceAccoutNoLogicalField()) == null)
						sourceAcctNo = PDOConstantFieldsInterface.X_CDTR_ACCT_ID;
					if(pdo.getString(destCcyLogicalField) == null)
						destCcyLogicalField = PDOConstantFieldsInterface.X_CDTR_ACCT_CCY;
				}
			}
				
			
			accumulationsMap.put(sAccumulationsMapKey,
					new PreProcessAccumulations(sAccumulationsMapKey, sMID,status,pdo.getString(PDOConstantFieldsInterface.P_OFFICE),
							pdo.getString(sourceAcctNo),
							new java.sql.Date(pdo.getDate(PDOConstantFieldsInterface.X_STTLM_DT_1B).getTime()),null,
							new java.sql.Date(pdo.getDate(PDOConstantFieldsInterface.P_PROC_DT).getTime()),
							pdo.getString(destCcyLogicalField),pdo.getString(sourceCcyLogicalField),
							pdo.getString(PDOConstantFieldsInterface.P_BASE_CCY), pdo.getString(PDOConstantFieldsInterface.P_SUSPENSE_ACCT_UID), msgClass.name(),payment));
		}

		if (!paymentsForCahce.containsKey(sAccumulationsMapKey)){
			paymentsForCahce.put(sAccumulationsMapKey, new ArrayList<PDO>());
		}

		// Gets the relared accumulations entry and upadtes it.
		PreProcessAccumulations accumulations = accumulationsMap.get(sAccumulationsMapKey);
		paymentsForCahce.get(sAccumulationsMapKey).add(pdo);
		//
		// Upadtes total credit amount.
		double amount = pdo.getDecimal(PDOConstantFieldsInterface.X_STTLM_AMT) != null ? pdo.getDecimal(PDOConstantFieldsInterface.X_STTLM_AMT).doubleValue() : 0;
		accumulations.addToSttlmTotalAmt(amount);
		
		
		if (!isRejected) {
			accumulations.addToSttlmTotalNetAmt(amount);
		}
		//
		// Upadtes total debit amount.
		amount = pdo.getDecimal(msgClass.getSourceAmountLogicalField()) != null ? pdo.getDecimal(msgClass.getSourceAmountLogicalField()).doubleValue() : 0;
		accumulations.addToPartyTotalAmt(amount);
		//
		if (!isRejected) {
			// Upadtes total base amount.
			amount = pdo.getDecimal(PDOConstantFieldsInterface.P_BASE_AMT) != null ? pdo.getDecimal(PDOConstantFieldsInterface.P_BASE_AMT).doubleValue() : 0;
			accumulations.addToBaseTotalAmt(amount);
		}
		//
		// Increments message count.
		accumulations.incMsgCount();
		
		accumulations.addToChecksumAmt(G3BulkChecksumCalculation.calcTxChecksum(pdo));
		
		//value time aggregation
		//1. Currently use D_BULK_INDIVIDUAL_VALUE_TIME as common field for value time on the individual PDO.
		//The individual flow is responsible to set value to this field
		//2. Currently, the aggregation selects the earliest time
		//TBD define and add mechanism which supports flexibility on the Bulk processing	
		accumulations.setValueTime(earliestTime(pdo.getDate(D_BULK_INDIVIDUAL_VALUE_TIME),accumulations.getValueTime()));
		
		logger.info(sTracePrefix + TRACE_METHOD_RESULTS
				,new Object[]{sAccumulationsMapKey, accumulations.getPartyTotalAmt(), accumulations.getSttlmTotalAmt()
				, accumulations.getBaseTotalAmt(), accumulations.getMsgCount(),accumulations.getValueTime()});
		 

		return feedback;
	}

	private Date earliestTime(java.util.Date date1, Date date2) {
		if (date1 == null)
			return date2;
		
		Date time1 = zeroDateFields(date1);
		
		if (date2 == null)
			return time1;
		
		Date time2 = zeroDateFields(date2);
		
		try {		
			return time1.before(time2) ? time1 : time2;
		} catch (NullPointerException e) {		
			return time1 != null ? time1 : time2;
		}
	}

	private Date zeroDateFields(java.util.Date date1){
		if (date1 == null)
			return null;
		
		String sHour = GlobalDateTimeUtil.getSTATIC_DATA_TIME_SimpleDateFormat().format(date1);
		long lHour = 0;
		try {
			lHour = GlobalDateTimeUtil.getSTATIC_DATA_TIME_SimpleDateFormat().parse(sHour).getTime();
		} catch (ParseException e) {
			logger.error("failed to parse hour ({}) to Date",sHour);
			return null;
		}
		return new java.sql.Date(lHour);
	}
	
	private void performAccumulationsForValidationFile(Map<String, PreProcessAccumulations> accumulationsMap ,String sInternalFileID, String sChunkId, String sMID) throws Throwable{

		final String TRACE_METHOD_RESULTS = "updated accumultions map - key: {}, Total debit amount: {}, Total credit amount: {}, Total base amount: {}, Messages count: {}.";
		 
		String startMethodTrace = null;
		startMethodTrace = String.format("'performAccumulations', (Internal file ID: %s, Chunk ID: %s, MID: %s; ); ", sInternalFileID, sChunkId, sMID);

		Feedback feedback = null;

		PDO pdo = PaymentDataFactory.load(sMID);
		MsgClassType msgClass = BOBaseProcess.isDD(pdo) ? MsgClassType.DD : MsgClassType.CT;
        
		String sUniqueGroupingID = pdo.getString(PDOConstantFieldsInterface.P_UNIQUE_GROUPING_ID);
		//TODO - change key to MID of Accounting payment ( will be transient filed - get pdo from chunks will map it from out_file_buffers
//		String sOutGroupindID = pdo.getString(PDOConstantFieldsInterface.P_OUT_GROUPING_ID);
        String accountingMID = pdo.getString(PDOConstantFieldsInterface.ACCOUNTING_MID);
		
		String SPaymentAccumulationsMapKey = "S_" + sUniqueGroupingID;
		String APaymentAccumulationsMapKey = "A_" + accountingMID;
		//Entry for the S Payment
		if(!accumulationsMap.containsKey(SPaymentAccumulationsMapKey))
		{
			CreateEntryInAccumulationMap(SPaymentAccumulationsMapKey,accumulationsMap,pdo,msgClass);
		}
		//Entry for the A Payment
		if(!accumulationsMap.containsKey(APaymentAccumulationsMapKey))
		{
			CreateEntryInAccumulationMap(APaymentAccumulationsMapKey,accumulationsMap,pdo,msgClass);
		}

		//Update Accumulation Map
		UpdateAccumulationMap(SPaymentAccumulationsMapKey,accumulationsMap,pdo,msgClass);
		UpdateAccumulationMap(APaymentAccumulationsMapKey,accumulationsMap,pdo,msgClass);

		 
	}

	private void UpdateAccumulationMap(String Key, Map<String, PreProcessAccumulations> accumulationsMap,PDO pdo,MsgClassType msgClass)
	{
		 

		PreProcessAccumulations accumulations = accumulationsMap.get(Key);
		// Upadtes total credit amount.
		double amount = pdo.getDecimal(PDOConstantFieldsInterface.X_STTLM_AMT) != null ? pdo.getDecimal(PDOConstantFieldsInterface.X_STTLM_AMT).doubleValue() : 0;
		accumulations.addToSttlmTotalAmt(amount);

		// Upadtes total debit amount.
		amount = pdo.getDecimal(msgClass.getSourceAmountLogicalField()) != null ? pdo.getDecimal(msgClass.getSourceAmountLogicalField()).doubleValue() : 0;
		accumulations.addToPartyTotalAmt(amount);

		// Upadtes total base amount.
		amount = pdo.getDecimal(PDOConstantFieldsInterface.P_BASE_AMT) != null ? pdo.getDecimal(PDOConstantFieldsInterface.P_BASE_AMT).doubleValue() : 0;
		accumulations.addToBaseTotalAmt(amount);

		// Increments message count.
		accumulations.incMsgCount();
		 

	}

	private void CreateEntryInAccumulationMap(String Key, Map<String, PreProcessAccumulations> accumulationsMap,PDO pdo ,MsgClassType msgClass) throws Throwable
	{

		 

		logger.info("Updates accumulations map - entry key: {}", Key);

		// If this is new entry in the accumulation map, create new accumulation object
		String status =  SubBatchProcessInterface.STATUS_READY_FOR_SUB_BATCH ;

		String sourceCcyLogicalField = msgClass == MsgClassType.DD ? PDOConstantFieldsInterface.P_CDT_ACCT_CCY : PDOConstantFieldsInterface.X_STTLM_CCY;
		String destCcyLogicalField = msgClass == MsgClassType.DD ? PDOConstantFieldsInterface.X_STTLM_CCY : PDOConstantFieldsInterface.P_DBT_ACCT_CCY;
		String destMOPLogicalField = GlobalUtils.getDestinationMopLogicalField(pdo);
		//get source account from msgClass and decide the method....
		String customerMethod = "GROSS";
		String mopMethod = "GROSS";
		
		XmlObject payment = PaymentDataFactory.transformToXml(pdo.getMID(),PaymentType.valueOf("PERSISTENT_DATA"), XmlLocationType.XML_ORIG_MSG, null,null);
		PreProcessAccumulations newAccumulation =   new PreProcessAccumulations(Key, pdo.getMID(),status,pdo.getString(PDOConstantFieldsInterface.P_OFFICE),
				pdo.getString(msgClass.getSourceAccoutNoLogicalField()),new java.sql.Date(pdo.getDate(PDOConstantFieldsInterface.X_STTLM_DT_1B).getTime()),null,
				new java.sql.Date(pdo.getDate(PDOConstantFieldsInterface.P_PROC_DT).getTime()),
				pdo.getString(destCcyLogicalField),pdo.getString(sourceCcyLogicalField),
				pdo.getString(PDOConstantFieldsInterface.P_BASE_CCY), pdo.getString(PDOConstantFieldsInterface.P_SUSPENSE_ACCT_UID), msgClass.name(), payment);

		newAccumulation.setCustomerMethod(customerMethod);
		newAccumulation.setMopMethod(mopMethod);
		// Adds new object to map with static arguments.
		accumulationsMap.put(Key, newAccumulation);


		 
	}


	private void preparePDO(PDO pdo, Object internalFileId, Object chunkId, String workflow)
	{
		pdo.set(PDOConstantFieldsInterface.P_IN_INTERNAL_FILEID, internalFileId);
		pdo.set(PDOConstantFieldsInterface.P_CHUNK_ID, chunkId);
		pdo.set(PDOConstantFieldsInterface.P_BATCH_MSG_TP, BATCH_MESSAGE_TYPE_INDIVIDUAL);
		pdo.set("D_MDC_ENRICHMENT", "");//ugly fix. clear what it dervied from the Template message
		if (GlobalUtils.isNullOrEmpty(pdo.getString(PDOConstantFieldsInterface.P_DISPLAY_MSG_TYPE)))
		{
			MsgTypes msgTypes = CacheKeys.msgTypesKey.getSingle(pdo.getString(PDOConstantFieldsInterface.P_MSG_TYPE), ServerConstants.EMPTY_STRING);
			String sDisplayMsgType = msgTypes != null ? msgTypes.getDisplayMsgType() : "NMT";
			pdo.set(PDOConstantFieldsInterface.P_DISPLAY_MSG_TYPE, !isNullOrEmpty(sDisplayMsgType) ? sDisplayMsgType : msgTypes.getMsgType());
		}
		pdo.set("D_BULK_INDIVIDUAL_STATE", "BULK_INDIVIDUAL_STATE_PRE_PROCESSING");
		pdo.set(PDOConstantFieldsInterface.MF_BULK_INDIVIDUAL_STATE, MessageConstantsInterface.MONITOR_BULK_INDIVIDUAL_STATE_PRE_PROCESSING);
	}
	/**
	 *
	 * Original
	 *
	 */
	private Feedback runDebulk(String internalFileID, String chunkId, String fileSummaryStatus, String chunkXml, String workFlowStr,boolean isInterfaceResponse, String bulkId) throws FlowException
	{
		final String TRACE_START = "START START START - DEBULKING PROCESS - START START START";
		final String TRACE_END = "END END END - DEBULKING PROCESS - END END END";

		logger.info("[DAODebulkingProcess.runDebulk()] - START");

		String sTracePrefix = String.format("'runDebulk', (Internal file ID: %s, Chunk ID: %s); ", internalFileID, chunkId);

		//logger.info(TRACE_START);
		logger.info(sTracePrefix);
		//logger.info(TRACE_START);

		Connection conn = null;
		PreparedStatement subFilePs = null;
		PreparedStatement insertToFileSubSetPs = null;
		ResultSet rs = null;
		PreparedStatement updateFileProcessDistributionPs = null;
		Feedback feedback = new Feedback();

		String sLastStep = null;

		boolean[] isFileSummaryNumOfPreprocessedWasUpdated = new boolean[]{false};
		PDO[] pdoArr= null;

		try
		{
			conn = m_dao.getConnection();

			int priority = 500;
			
			
//			double[] stlmAmt = new double[]{0};
//			double[] stlmAmtRejected = new double[]{0};
//			double[] stlmAmtRepair = new double[]{0};
//			int[] rejectedCount = new int[]{0};
//			int[] duplicateCount = new int[]{0};
//			int[] repairCount = new int[]{0};
//			double[] stlmAmtDuplicate = new double[]{0};

			
			AmountHolder amountHolder = new AmountHolder();

			// Gets xml object from file_process_distribution table.
			sLastStep = STEP_GET_XML_OBJECT_FROM_FILE_PROCESS_DISTRIBUTION;
			//    	subFilePs = m_dao.getSubFileXml(conn, internalFileID, chunkId);
			//    	rs = subFilePs.executeQuery();


			boolean bXMLChunkWasFound = chunkXml != null;
			logger.info(sTracePrefix + "XML file was found: {}", bXMLChunkWasFound);

			// XML file was found.
			if(bXMLChunkWasFound)
			{

				final Map[] arrMapSharedPDOContextHolder = new Map[1] ;
				sLastStep = STEP_GET_PDO_OBJECTS_FROM_CHUNK;

				PDO tempPdo = PaymentDataFactory.newPDO(PaymentType.valueOf(PaymentType.PT_PACS_008), true/*bTransient*/);
				//set the temp pdo in the admin
				Admin.setContextPDO(tempPdo);

				tempPdo.set(PDOConstantFieldsInterface.P_IN_INTERNAL_FILEID, internalFileID);

				List<PDO> persistentPdoList = new ArrayList<PDO>();

//				final FileSummary incomingFileSummary = tempPdo.getNSetIncomingFileSummary() ;
//				WorkflowType workFlow = null;
//				if (workFlowStr != null && !"null".equals(workFlowStr)) workFlow = WorkflowType.valueOf(workFlowStr);
//				else workFlow = (incomingFileSummary != null && !GlobalUtils.isNullOrEmpty(incomingFileSummary.getWorkflow())
//						? WorkflowType.valueOf(incomingFileSummary.getWorkflow()) : WorkflowType.Default) ;

								
				Map<String, StoreRequest> requestMap = new HashMap<String, StoreRequest>();
//				pdoArr = workFlow.executeFlow(chunkXml, internalFileID, chunkId, stlmAmt, stlmAmtDuplicate, stlmAmtRejected,stlmAmtRepair, duplicateCount, rejectedCount,repairCount
//						, incomingFileSummary, persistentPdoList, arrMapSharedPDOContextHolder,requestMap, feedback);
				Map<String, PreProcessAccumulations> accumulationsMap = new HashMap<String, PreProcessAccumulations>(); 
				Map<String, List<PDO>> paymentsForCahce = new HashMap<String, List<PDO>>();
				runDebulkInner(pdoArr, persistentPdoList, internalFileID, fileSummaryStatus, chunkId, amountHolder, 
						priority, arrMapSharedPDOContextHolder, workFlowStr,  requestMap,isInterfaceResponse,
						accumulationsMap, paymentsForCahce, feedback, bulkId);
			}

			else
			{
				logger.info("ERROR: XML chunk wasn't found in database - Internal file ID: {}, Chunk ID: {}.", internalFileID, chunkId);
			}
		}
		catch(Throwable e)
		{
			logger.info(LAST_STEP + sLastStep);
			Feedback failureFeedback = new Feedback();
			ProcessError pError = new ProcessError(ProcessErrorConstants.ServiceFailureWithLastStep, new Object[]{SERVICE_DEBULKING_PROCESS, sLastStep});
			configureErrorFeedback(1, pError.getDescription(), failureFeedback);
			logger.info(ServerUtils.getFeedbackString(failureFeedback));

			clearPdosFromCache(pdoArr);

			if (isFileSummaryNumOfPreprocessedWasUpdated[0])
				try {
					ServiceLocator.getInstance().SLSBlookup(TxIsolation.class).decNumOfProcessChunksInFileSummary(Admin.getContextAdmin(), internalFileID);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					throw new FlowException(e1);
				}

				ExceptionController.getInstance().handleException(e, this);
				throw new FlowException(e);
		}
		finally
		{
			m_dao.releaseResources(conn, subFilePs, updateFileProcessDistributionPs,rs,insertToFileSubSetPs);

			//clear the CacheKeys.preProcessAccumulationsKey region
			CacheKeys.preProcessAccumulationsKey.removeSingle(chunkId) ;
		}

		//logger.info(TRACE_END);
		logger.info(sTracePrefix);
		//logger.info(TRACE_END);

		if(!feedback.m_bIsSuccessful) 
			logger.info(ServerUtils.getFeedbackString(feedback));

		return feedback;

	}//EOM runDebulk

	private void clearPdosFromCache(PDO[] pdoArr) {
		// Clear the pdo's from the cache
		if (pdoArr != null && pdoArr.length > 0) {
			try {
				PaymentDataFactory.performFailureCompensation(pdoArr) ;
			} catch (Throwable e1) {
				// Do nothing only write to log
				logger.error(CLEAR_PDOS_FAILURE_MSG);
				logger.error(e1.getMessage());
			}
		}
	}


	public Feedback runDebulkInner(List<PDO> pdoList, String internalFileId, String status,
			String chunkId,int priority,Map[] arrMapSharedPDOContextHolder, String workflow,boolean isInterfaceResponse, Feedback feedback, String bulkId) throws Throwable{
		logger.debug("runDebulkInner: internalFileId {},chunkId {},status {}, chunk size {}",new Object[]{internalFileId,chunkId,status,pdoList.size()});
		
		Map<String, StoreRequest> requestMap = new HashMap<String, StoreRequest>();

		AmountHolder amounts = new AmountHolder();
		List<PDO> persistentPdoList = new ArrayList<PDO>();
		Map<String, PreProcessAccumulations> accumulationsMap = new HashMap<String, PreProcessAccumulations>(); 
		Map<String, List<PDO>> paymentsForCahce = new HashMap<String, List<PDO>>();

		PDO[] pdoArr = executeBusinessFlowSelector(pdoList, internalFileId, chunkId, amounts,
				persistentPdoList, requestMap, workflow, accumulationsMap, paymentsForCahce, feedback);

		return runDebulkInner(pdoArr, persistentPdoList, internalFileId, status,  chunkId, amounts, priority, arrMapSharedPDOContextHolder,null, requestMap,isInterfaceResponse, 
				accumulationsMap,paymentsForCahce, feedback, bulkId);
	}

	private Feedback runDebulkInner(PDO[] pdoArr, List<PDO> persistentPdoList, String internalFileId, String status, String chunkId,AmountHolder amountHolder,int priority,Map[] arrMapSharedPDOContextHolder
			, String workflow,Map<String, StoreRequest> requestMap, boolean isInterfaceResponse, 
			Map<String, PreProcessAccumulations> accumulationsMap , Map<String, List<PDO>> paymentsForCahce, Feedback feedback, String bulkId) throws Throwable
			{
		PreparedStatement updateFileProcessDistributionPs=null;
		PreparedStatement insertToFileSubSetPs = null;
		PreparedStatement[] updateAndInsertToFileSubSetPs = new PreparedStatement[2];
		String fileProcessDistStatus = STATUS_PRE_PROCESSED;
		String interfaceSubType = InterfaceTypeConstants.INTERFACE_SUB_TYPE_GEN_OUT;
		Connection conn=null;
		try
		{
			conn = m_dao.getConnection();
			if (feedback.m_bIsSuccessful && pdoArr != null && pdoArr.length>0)
			{
				
	            String flowType = DAOFILE_SUMMARY.getInstance().getFlowType(internalFileId);
	                    
	            /*
	             * Save the PDO in bulking process stage only if flow type = RT.
	             * BP files will be saved at SubBatchCompletion stage. This is to avoid having rejected payments saved to DB if entire file is rejected.
	             * Procedure was reinstated to allow for business layer implementation and to fix QC# 71632.
	             * 
	             */
	            if (persistentPdoList.size() > 0 && (GlobalConstants.RT.equals(flowType)))
	            {
	                        	logger.debug("persisting (not DDI/CTI) rejected individuals");
								PaymentDataFactory.batchSave(false, persistentPdoList.toArray(new PDO[persistentPdoList.size()]));
								final List<String> dupexKeyList = new ArrayList<String>() ;
				        	    for (PDO pdo : persistentPdoList) 
				        	    {
									String sDupexKey = pdo.getString(PDOConstantFieldsInterface.P_DUPLICATE_INDEX);
					                if (!GlobalUtils.isNullOrEmpty(sDupexKey)) dupexKeyList.add(sDupexKey);
				        	    }
				        	  
					        	List<String> dupexKeys = dupexKeyList;
					        	LastResourceInterface removeDupexFromCacheLastResourceHandler = new RemoveDupexFromCacheLastResourceHandler(dupexKeys);
					        	Admin admin = Admin.getContextAdmin();
	        	  admin.registerLastResource(removeDupexFromCacheLastResourceHandler);
				}
				pdoArr = null;
				updateFileInterfaceBuffers(conn, requestMap, internalFileId, chunkId, InterfaceTypeConstants.INTERFACE_NAME_MP_DEBULK_WAITING_CHUNK);
				transmitChunkToNextStep(internalFileId, status, interfaceSubType, priority );

				// FILE_PROCESS_DISTRIBUTION update, (sets status to 'PreProcessed').
				updateFileProcessDistributionPs = m_dao.updateFileProcessDistributionStatusAndAmounts(conn, fileProcessDistStatus, internalFileId,
						chunkId,amountHolder);
				updateFileProcessDistributionPs.executeUpdate();

				// FILE_SUBSET_CHUNKS update.
				List<ProcessPdoPerGroupIdEntry> processPdoPerGroupIdEntryList = new ArrayList<ProcessPdoPerGroupIdEntry>();
				if (isInterfaceResponse) {
					updateAndInsertToFileSubSetPs = m_dao.insertOrUpdateToFileSubsetChunksAndUpdateProcessPdoCache(conn, internalFileId,chunkId,
							priority, null, processPdoPerGroupIdEntryList, accumulationsMap, paymentsForCahce, bulkId);
				}else{
					insertToFileSubSetPs = m_dao.insertToFileSubsetChunksAndUpdateProcessPdoCache(conn,internalFileId,chunkId,priority
							, arrMapSharedPDOContextHolder[0],processPdoPerGroupIdEntryList,accumulationsMap,paymentsForCahce, bulkId);
				}

				

				if (insertToFileSubSetPs != null) 
				{
						logger.debug("Before insertToFileSubSetPs");
						insertToFileSubSetPs.executeBatch();
						logger.debug("After insertToFileSubSetPs");
				}
				if (updateAndInsertToFileSubSetPs != null)
				{
					logger.debug("Before updateAndInsertToFileSubSetPs");
					if (updateAndInsertToFileSubSetPs[0] != null) 
					{
						logger.debug("updateAndInsertToFileSubSetPs[0]");
						updateAndInsertToFileSubSetPs[0].executeBatch();	
					}
					if (updateAndInsertToFileSubSetPs[1] != null)
					{
						logger.debug("updateAndInsertToFileSubSetPs[1]");
						updateAndInsertToFileSubSetPs[1].executeBatch();						
					}
					logger.debug("After updateAndInsertToFileSubSetPs");
				}
				else logger.info("No update was done to FILE_SUBSET_CHUNKS !!!");


				//			  workflow.performPostexecutions(processPdoPerGroupIdEntryList);
			}
		}finally
		{
			m_dao.releaseResources(conn, updateFileProcessDistributionPs, insertToFileSubSetPs,updateAndInsertToFileSubSetPs[0],updateAndInsertToFileSubSetPs[1]);
		}

		return feedback;
			}

	/*
	 * DebulkInner for Ack(Validation) files
	 */
	private Feedback runDebulkInner(String internalFileId,String chunkId ,String status,Map<String, PreProcessAccumulations> accumulationsMap,Feedback feedback) throws Throwable
	{
		 
		int priority = 500;
		String interfaceSubType = InterfaceTypeConstants.INTERFACE_SUB_TYPE_ACK_GEN_OUT;
		int[] updateRows;
		String fileProcessDistStatus = STATUS_PRE_PROCESSED;
		Connection conn=null;
		try
		{
			//Send the Chunk for the next step
			transmitChunkToNextStep(internalFileId, status, interfaceSubType, priority);

			// FILE_PROCESS_DISTRIBUTION update, (sets status to 'PreProcessed').
			conn = m_dao.getConnection();
			m_dao.updateFileProcessDistributionStatusAndAmounts(conn,fileProcessDistStatus, internalFileId,chunkId);

			// FILE_VALIDATION_SUBSET_CHUNKS update
			conn = m_dao.getConnection();
			updateRows = m_dao.insertToFileValidationSubsetChunks(conn,internalFileId,chunkId,priority,accumulationsMap);
			if (updateRows == null) 
				logger.info("No update was done to FILE_VALIDATION_SUBSET_CHUNKS !!!");
		}
		catch(Throwable t)
		{
			logger.error(t.getLocalizedMessage());
		}
		 
		return feedback;

	}

	private void transmitChunkToNextStep(String internalFileId, String status, String interfaceSubType ,int priority) throws Throwable
	{
		if (SubBatchProcessInterface.STATUS_FILE_DISTRIBUTED.equals(status))
		{
			InterfaceTypes interfaceType= CacheKeys.interfaceTypesNameKey.getSingle(InterfaceTypeConstants.INTERFACE_NAME_MP_PRE_PROCESSED_CHUNKS);

			String subBatchGenerationRequest =  internalFileId + ","+status ;


			ProcessSubBatchGenerationRequestDocument subBatchReq = ProcessSubBatchGenerationRequestDocument.Factory.newInstance();
			//Only if interfaceName is not null
			subBatchReq.addNewProcessSubBatchGenerationRequest();
			subBatchReq.getProcessSubBatchGenerationRequest().setProcessInformation(subBatchGenerationRequest);
			subBatchReq.getProcessSubBatchGenerationRequest().setSubTypeInterface(interfaceSubType);
			

			HashMap mapContext = new HashMap();
			mapContext.put( "PRIORITY", priority);
			
			logger.debug("transmit chunks (ProcessSubBatchGenerationRequestDocument) to next step");
			
			if (interfaceType != null) 
				TransmissionType.valueOf(interfaceType.getRequestProtocol()).transmitInTx(subBatchReq.xmlText(), null, interfaceType, null, mapContext);
		}

	}

	private void updateProcessPdoPerUniqueGroupCache(String chunkId)
	{
		Map<String, PreProcessAccumulations> accumulationsMap = CacheKeys.preProcessAccumulationsKey.getSingle(chunkId);

		if (accumulationsMap != null)
		{
			Iterator<PreProcessAccumulations> accumulationIter = accumulationsMap.values().iterator();

			while(accumulationIter.hasNext())
			{
				PreProcessAccumulations accumulations = accumulationIter.next();

			}
		}

	}


	public static class AmountHolder{
		private double stlmAmt=0;
		private double stlmAmtDuplicate=0;
		private double stlmAmtRejected=0;
		private double stlmAmtRepair=0;
		private int duplicateCount=0;
		private int rejectedCount=0;
		private int repairCount=0;
		public void addStlmAmt(double stlmAmt) {
			this.stlmAmt+= stlmAmt;
		}
		public double getStlmAmt() {
			return stlmAmt;
		}
		public void addStlmAmtRejected(double stlmAmtRejected) {
			this.stlmAmtRejected+= stlmAmtRejected;
		}
		public double getStlmAmtRejected() {
			return stlmAmtRejected;
		}
		public void addStlmAmtDuplicate(double stlmAmtDuplicate) {
			this.stlmAmtDuplicate+= stlmAmtDuplicate;
		}
		public double getStlmAmtDuplicate() {
			return stlmAmtDuplicate;
		}
        public void addStlmAmtRepair(double stlmAmtRepair) {
            this.stlmAmtRepair+= stlmAmtRepair;
        }
        public double getStlmAmtRepair() {
            return stlmAmtRepair;
        }
		public void addDuplicateCount(int duplicateCount) {
			this.duplicateCount+= duplicateCount;
		}
		
		public void incDuplicateCount() {
			this.duplicateCount++;
		}

		public int getDuplicateCount() {
			return duplicateCount;
		}
		public void addRejectedCount(int rejectedCount) {
			this.rejectedCount+= rejectedCount;
		}
		
		public void incRejectedCount() {
			this.rejectedCount++;
		}

		public int getRejectedCount() {
			return rejectedCount;
		}

        public void addRepairCount(int repairCount) {
            this.repairCount+= repairCount;
        }
        
		public void incRepairCount() {
            this.repairCount++;
        }

        public int getRepairCount() {
            return repairCount;
        }
		@Override
		public String toString() {
			return "AmountHolder [duplicateCount=" + duplicateCount
					+ ", rejectedCount=" + rejectedCount + ", repairCount="+repairCount+", stlmAmt="
					+ stlmAmt + ", stlmAmtDuplicate=" + stlmAmtDuplicate
					+ ", stlmAmtRejected=" + stlmAmtRejected + ", stlmAmtRepair="+stlmAmtRepair+"]";
		}
		
		
	}
}
