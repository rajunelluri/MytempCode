package backend.paymentprocess.debulkingprocess.businessobjects;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi.G3MultiBulkTransactionReader;
import backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi.G3MultiPacs002BulkTransactionReader;
import backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi.XmlTransactionReader;
import backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi.XmlTransactionReaderBase;

import com.fundtech.core.security.Admin;

public class BOG3BPDebulkFile extends BODebulkFile {

	private static Logger logger = LoggerFactory
			.getLogger(BOG3BPDebulkFile.class);

	@Override
	protected XmlTransactionReaderBase getTransactionReader(File file,
			int chunkSize) {
		XmlTransactionReaderBase reader = null;
		try {
			reader = getReader(file, chunkSize);
		} catch (IOException e) {
			logger.error("File {} not found", file.getName());
		}
		if(Admin.getContextAdmin().getIncomingInterfaceType() != null)
		{
			((XmlTransactionReader) reader).setFileSource(Admin.getContextAdmin()
				.getIncomingInterfaceType().getPaymentSource());
		}
		return reader;
	}

	private XmlTransactionReaderBase getReader(File file, int chunkSize) throws IOException {

		XmlTransactionReaderBase reader = null;
		String line = null;
		BufferedReader br = null;
		try{
			br = new BufferedReader(new FileReader(file));
			line = br.readLine();
	
			while (line != null && !line.contains("xmlns")) {
				line = br.readLine();
			}
			
			if (line == null || !line.contains("pacs.002.001.03")) {
				reader = new G3MultiBulkTransactionReader(file, chunkSize);
			}else
				reader = new G3MultiPacs002BulkTransactionReader(file, chunkSize);
		}finally{// close BufferedReader
			try{
				if (br !=null) br.close();
			}catch(Exception e){
				logger.debug("Exception - could not close BufferedReader-br at BOG3BPDebulkFile.getReader");
			}
		}
		
		return reader;
	}
}
