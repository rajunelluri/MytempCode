package backend.paymentprocess.debulkingprocess.businessobjects;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import backend.businessobject.BOBasic;
import backend.paymentprocess.debulkingprocess.dao.DAODebulkingProcess;

import com.baml.payments.paymentsNotificationV001.EventParameterType;
import com.baml.rp.service.paymentsNotificationV001.PaymentsNotificationDocument;
import com.fundtech.cache.entities.InterfaceTypes;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.cache.infrastructure.regions.CacheKeys.ProcessPdoPerUniqueGroupIdKey.ProcessPdoPerGroupIdEntry;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalUtils;
import backend.paymentprocess.debulkingprocess.common.WorkflowType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class BOMassPayment extends BOBasic{
	private static final Logger logger = LoggerFactory.getLogger(BOMassPayment.class);
	
	protected static DAODebulkingProcess m_dao = DAODebulkingProcess.getInstance();

	protected boolean handleBatchInterfaceAndReturnHasWaitStatus(PDO pdo, Map<String,StoreRequest> requestMap) throws Throwable
	{
		boolean hasWaitStatus = false;
		Map<String, Serializable> storeRequestMap = (Map<String, Serializable>)pdo.getTransient("STORE_REQUEST");
		if (storeRequestMap != null) {
			Iterator<Entry<String, Serializable>> iter = storeRequestMap.entrySet().iterator();
			Entry<String, Serializable> entry;
			StringBuilder sb=null;
			String uniqueGroupId = pdo.getString(PDOConstantFieldsInterface.P_UNIQUE_GROUPING_ID);
			while (iter.hasNext())
			{
				entry = iter.next();
				String key = entry.getKey();
				String[] keyArr = key.split(GlobalConstants.AT_SIGN);
				InterfaceTypes interfaceType = CacheKeys.interfaceTypesNameKey.getSingle(keyArr[0]);
				hasWaitStatus = hasWaitStatus || !GlobalUtils.isNullOrEmpty(interfaceType.getMessageWaitStatus());
				key = key + GlobalConstants.AT_SIGN + (uniqueGroupId != null ? uniqueGroupId : "");
				if (!requestMap.containsKey(key)){
					PDO clonedPdo = pdo.cloneCurrent();
					String targetMsgType = pdo.getString("D_STORE_REQUEST_TARGET_MSG_TYPE");
					if (!GlobalUtils.isNullOrEmpty(targetMsgType)){
						clonedPdo.transform(targetMsgType);
					}
					clonedPdo.set(PDOConstantFieldsInterface.X_TX_NO, "1");
					StoreRequest sr = new StoreRequest(clonedPdo);
					requestMap.put(key, sr);
				}else{
					PDO localPdo = requestMap.get(key).payment;
					localPdo.set(PDOConstantFieldsInterface.X_STTLM_AMT, getTotalAmount(localPdo, pdo, PDOConstantFieldsInterface.X_STTLM_AMT));
					localPdo.set(PDOConstantFieldsInterface.P_CDT_AMT, getTotalAmount(localPdo, pdo, PDOConstantFieldsInterface.P_CDT_AMT));
					localPdo.set(PDOConstantFieldsInterface.P_DBT_AMT, getTotalAmount(localPdo, pdo, PDOConstantFieldsInterface.P_DBT_AMT));
					localPdo.set(PDOConstantFieldsInterface.P_BASE_AMT, getTotalAmount(localPdo, pdo, PDOConstantFieldsInterface.P_BASE_AMT));
					String txCount = localPdo.getString(PDOConstantFieldsInterface.X_TX_NO);
					txCount = (Integer.parseInt(txCount)+1) + "";
					localPdo.set(PDOConstantFieldsInterface.X_TX_NO, txCount);
				}

				requestMap.get(key).request.append(entry.getValue());
			}
		}	    
		return hasWaitStatus;
	}

	protected boolean isBulkInterfaceHasWaitStatus(PDO pdo) {

		boolean hasWaitStatus = false;
		Map<String, Serializable> storeRequestMap = (Map<String, Serializable>)pdo.getTransient("STORE_REQUEST");
		if (storeRequestMap != null) {
			Iterator<Entry<String, Serializable>> iter = storeRequestMap.entrySet().iterator();
			Entry<String, Serializable> entry;
			while (iter.hasNext() && !hasWaitStatus)
			{
				entry = iter.next();
				String key = entry.getKey();
				String[] keyArr = key.split(GlobalConstants.AT_SIGN);
				InterfaceTypes interfaceType = CacheKeys.interfaceTypesNameKey.getSingle(keyArr[0]);
				hasWaitStatus = !GlobalUtils.isNullOrEmpty(interfaceType.getMessageWaitStatus());
			}
		}
		
		logger.debug("isBulkInterfaceHasWaitStatus: {}",hasWaitStatus);
		
		return hasWaitStatus;

	}

	private BigDecimal getTotalAmount(PDO pdo1, PDO pdo2, String logicalField){
		double amount1 = pdo1.getDecimal(logicalField) != null ? pdo1.getDecimal(logicalField).doubleValue() : 0;
		double amount2 = pdo2.getDecimal(logicalField) != null ? pdo2.getDecimal(logicalField).doubleValue() : 0;

		return BigDecimal.valueOf(amount1 + amount2);
	}

	protected void updateFileInterfaceBuffers(Connection conn, Map<String, StoreRequest> requestMap, String internalFileId, String chunkId, String nextStep) throws Throwable{
		if (requestMap != null && requestMap.size() > 0){
			PreparedStatement insertToFileInterfaceBuffers = null;
			Connection localCon = null;
			try{
				localCon = conn != null ? conn : m_dao.getConnection();
				insertToFileInterfaceBuffers = m_dao.insertToFileInterfaceBuffers(localCon, internalFileId, chunkId, requestMap, nextStep);
				if (insertToFileInterfaceBuffers != null) insertToFileInterfaceBuffers.executeBatch();
			}finally{
				m_dao.releaseResources(insertToFileInterfaceBuffers, (conn == null ? localCon : null));
			}
		}

	}


	public static class StoreRequest{
		public StringBuilder request;
		public PDO payment;

		public StoreRequest(PDO payment){
			request = new StringBuilder();
			this.payment = payment;
		}
	}


	protected ProcessPdoPerGroupIdEntry getProcessPdoPerGroupId(String internalFileId, String chunkId, String uniqueGroupId){
		logger.debug("getProcessPdoPerGroupId Start");
		ProcessPdoPerGroupIdEntry processPdoPerGroup = null;
		try
		{
			processPdoPerGroup = CacheKeys.processPdoPerUniqueGroupIdKey.getSingle(internalFileId, chunkId, uniqueGroupId);
		}
		catch(Throwable e)
		{
			try
			{
				logger.debug("getProcessPdoPerGroupId processPdoPerGroup was not found with getSingle");
				processPdoPerGroup = getScheduleProcessPdoEntriesFromPersistence(internalFileId, chunkId, uniqueGroupId);
			}catch(Throwable e1)
			{
				logger.error("Failed to get processPdoPerGroup from cache, will set processPdoPerGroup to null", e);
				processPdoPerGroup = null;
			}
		}
		logger.debug("getProcessPdoPerGroupId End");
		return processPdoPerGroup;
	}
	
	public ProcessPdoPerGroupIdEntry getScheduleProcessPdoEntriesFromPersistence(
			String sInternalFileID, String sChunkID, String sUniqueGroupingID) throws Throwable {
			ProcessPdoPerGroupIdEntry processPdoPerGroup = null;
			
			List<PDO> list = PaymentDataFactory.load(sInternalFileID,sChunkID, sUniqueGroupingID, 0, "P_MSG_STS in ('WAITSCHEDSUBBATCH','WAITSUBBATCH','WAIT_RELEASE_SUBBATCH')");

			if (list.size() > 0) {
				processPdoPerGroup = new CacheKeys.ProcessPdoPerUniqueGroupIdKey.ProcessPdoPerGroupIdEntry(list, null);
//				CacheKeys.processPdoPerUniqueGroupIdKey.removeSingle(processPdoPerGroup);
				processPdoPerGroup.setAlreadyCommit(true);
				CacheKeys.processPdoPerUniqueGroupIdKey.putSingle(processPdoPerGroup);				
			}
		return processPdoPerGroup;
	}
	  public Map<String, Object> getValuesFromNotification(PaymentsNotificationDocument notification) {
			Map<String, Object> values = new HashMap<String, Object>();
			EventParameterType[] parameters = notification.getPaymentsNotification().getNotificationEvent().getParameters().getParameterArray();
			for (EventParameterType eventParameterType : parameters) {
				values.put(eventParameterType.getName(), eventParameterType.getValue());
			}
			return values;
		}

}
