package backend.paymentprocess.debulkingprocess.businessobjects;

import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.F_FILE_STATUS;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_BUSINESS_FLOW_TP;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_IN_INTERNAL_FILEID;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.transaction.UserTransaction;
import javax.xml.stream.XMLStreamException;

import org.apache.commons.lang.StringUtils;
import org.hibernate.TransactionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.businessobject.BOBasic;
import backend.businessobject.BOProxies;
import backend.businessobject.tx.RemoveDupexFromCacheLastResourceHandler;
import backend.core.module.MessageConstantsInterface;
import backend.dataaccess.dao.DAOBasic;
import backend.paymentprocess.SubBatchProcessInterface;
import backend.paymentprocess.baseprocess.businessobjects.BOBaseProcess;
import backend.paymentprocess.debulkingprocess.dao.DAODebulkingProcess;
import backend.paymentprocess.debulkingprocess.parsing.xml.processing.IterableTransactionReader;
import backend.paymentprocess.debulkingprocess.parsing.xml.processing.TransactionReader;
import backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi.AckXmlTransactionReaderIfc;
import backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi.G3MultiPacs002BulkTransactionReader;
import backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi.IterableXmlTransactionReader;
import backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi.MultiXmlTransactionReader;
import backend.paymentprocess.debulkingprocess.parsing.xml.processing.multi.XmlTransactionReaderBase;
import backend.paymentprocess.enrichment.commons.InterfaceSubTypeFlow;
import backend.paymentprocess.erroraudit.ErrorAuditUtils;
import backend.paymentprocess.highvalueprocess.businessobjects.BOHighValueProcess;
import backend.paymentprocess.interfaces.common.TransmissionType;
import backend.paymentprocess.matchingcheck.output.MatchingCheckOutputData;
import backend.staticdata.profilehandler.DAOBasicProfileHandler;
import backend.staticdata.profilehandler.message.FILE_SUMMARYProfileHandler;
import backend.staticdata.profilehandler.message.dataaccess.dao.DAOFILE_SUMMARY;
import backend.util.ServerConstants;
import backend.util.ServerUtils;

import com.fundtech.cache.entities.Customrs;
import com.fundtech.cache.entities.FileSummary;
import com.fundtech.cache.entities.InterfaceTypes;
import com.fundtech.cache.entities.OutFileBuffers;
import com.fundtech.cache.entities.RuleResult;
import com.fundtech.cache.entities.RuleResults;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.cache.syspar.SystemParametersInterface;
import com.fundtech.core.general.flows.FlowException;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.core.paymentprocess.data.paymenttypes.PaymentType;
import com.fundtech.core.paymentprocess.errorhandling.ProcessError;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.request.DebulkFileByIndexData;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.datacomponent.response.SimpleResponseDataComponent;
import com.fundtech.errors.ProcessErrorConstants;
import com.fundtech.jndi.ServiceLocator;
import com.fundtech.scl.debulkingProcessService.PerformDebulkingRequestDocument;
import com.fundtech.scl.massPayment.PerformDebulkingAckRequsetDocument;
import com.fundtech.scl.massPayment.PerformDebulkingAckRequsetType;
import com.fundtech.util.BeanIOUtils;
import com.fundtech.util.ExceptionController;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalUtils;
import com.fundtech.util.datetime.NewASDateTimeUtils;

public class BODebulkFile extends BOBasic implements SubBatchProcessInterface, MessageConstantsInterface
{

  private static final Logger logger = LoggerFactory.getLogger(BODebulkFile.class);
  private static final DAOBasicProfileHandler m_daoBasicProfileHandle = new DAOBasicProfileHandler();
  private static DAODebulkingProcess m_daoDebulkingProcess = DAODebulkingProcess.getInstance();
  private static DAOFILE_SUMMARY m_daoFileSummary = DAOFILE_SUMMARY.getInstance();
  private static FILE_SUMMARYProfileHandler fsHandler = FILE_SUMMARYProfileHandler.getInstance();

  private static String IN_DISTRIBUTION = "InDistribution";
  private static Method m_debulkFileInner = null;
  private static Method m_debulkStringInner = null;

  private static Method m_redebulkFileInnerByIndex = null;
  private static Method m_debulkFileInnerByIndex = null;
  private static Method m_debulkStringInnerByIndex = null;
  private static List<String> emptyFileSupportList = Arrays.asList(new String[]{"IRD","IWD","ORD","ORF"});
  private String USER_ID = "SYSTEM";
  private static final String SEVERITY_ERROR = "ERROR";

  private static final DAOBasicProfileHandler errorLog = new DAOBasicProfileHandler();
    


  static
  {
	  try
	  {
		  m_debulkFileInner = BODebulkFile.class.getDeclaredMethod("debulkFileInner", String.class);
		  m_debulkStringInner = BODebulkFile.class.getDeclaredMethod("debulkStringInner", String.class);

		  
		  m_debulkFileInnerByIndex = BODebulkFile.class.getDeclaredMethod("debulkFileInnerByIndex", String.class);
		  m_debulkStringInnerByIndex = BODebulkFile.class.getDeclaredMethod("debulkStringInnerByIndex", String.class);
		  m_redebulkFileInnerByIndex = BODebulkFile.class.getDeclaredMethod("redebulkFileInnerByIndex", DebulkFileByIndexData.class);
		  
	  }catch(Exception e)
	  {
		  logger.error(e.getMessage());
	  }
  }

  public  SimpleResponseDataComponent debulkFile(String filePath) throws Throwable
  {
	  return (SimpleResponseDataComponent) super.executeInProtectedBoundaries(m_debulkFileInner, filePath);
//	  return debulkFileInner(filePath);
  }

  public  SimpleResponseDataComponent debulkString(String message) throws Throwable
  {
	  return (SimpleResponseDataComponent) super.executeInProtectedBoundaries(m_debulkStringInner, message);
  }

  /**
   *
   */
  public boolean debulkFile(String xmlString, int chunkSize, List listChunks, boolean onlyTrnsSec) throws FlowException
  {
  	
	logger.debug("debulkFile: chunkSize {}",chunkSize);

    TransactionReader reader = TransactionReader.TransactionReaderFactory(xmlString);
    StringBuilder sb = new StringBuilder();
    int indx = 1;
    while (indx != 0)
    {
      indx = onlyTrnsSec ? getTrnsChuck(reader, sb, chunkSize) : getChuck(reader,sb,chunkSize, new String[1]);
      if (indx != 0)
      {
      	listChunks.add(sb.toString());
        sb.delete(0,sb.length());
      }
    }

    //

    return reader.isSinglePayment();
  }

  /**
   *
   */


  private void executeDebulking(TransactionReader reader, String startPrefix, String inputName, long inputLastModified, long inputSize, String inputPath,
		  SimpleResponseDataComponent response) throws Throwable
  {




//	    UserTransaction[] arrTxHolder = new UserTransaction[1];

	    String[] sFileSummaryOffice = new String[1];
	    String[] sValidationsStatus = new String[1];
	    String[] internalFileId = new String[1];
	    String[] priority = new String[1];
	    String[] sStatus = new String[1];
	    int[] numOfChunks = new int[]{0};

		    int chunkSize = Integer.parseInt(CacheKeys.SystParKey.getSingleParmValue(sFileSummaryOffice[0], SystemParametersInterface.SYS_PAR_FILE_CHUNCK_SIZE));
	    	Feedback feedback = handleFileSummaryPart(reader, startPrefix, inputName, inputLastModified, inputSize, inputPath, sFileSummaryOffice
	    			,sValidationsStatus,internalFileId,priority,sStatus,chunkSize);

	        if (feedback.isSuccessful() && !STATUS_FILE_NOT_VALID_INITIATING_PARTY.equals(sValidationsStatus[0]))
	        {
		    	feedback = createChunks(sStatus, sFileSummaryOffice, internalFileId, priority, reader, chunkSize,numOfChunks);
	        }
	        if (feedback.isSuccessful())
	        {
	        	createFileSummary(internalFileId[0],inputName, inputPath, inputLastModified, inputSize, priority[0], numOfChunks[0], sStatus[0], reader);
	        	BOHighValueProcess.performNotificationFlow(Admin.getContextPDO());
	        }
  }


  private void createFileSummary(String internalFileId, String inputName, String inputPath, long inputLastModified, Long inputSize, String priority,int numOfChunks , String status
		  ,TransactionReader reader) throws Exception
  {
	  Connection conn = null;
	  try
	  {
		  PDO pdo = Admin.getContextPDO();
		  FileSummary fileSummary = pdo.getNSetIncomingFileSummary();
		  conn = m_daoDebulkingProcess.getConnection();
		  Customrs cust = CacheKeys.customrsCCKey.getSingle(fileSummary.getInitgPtyCustCode());

		  m_daoDebulkingProcess.createFileSummaryEntry(conn,fileSummary.getOffice(),fileSummary.getDepartment(),internalFileId
				  ,inputName, inputPath, inputLastModified, null, inputSize,
				  "",new Timestamp(fileSummary.getPlCreateDate().getTime()),status ,fileSummary.getInitgPtyCustCode(),reader.getPartyName()
					,cust != null ? cust.getBaseNo() : null,priority
				,reader.getCtrlSum(),reader.getMsgId(),reader.getNumOfTxs(),reader.getInputAsString(), reader.getWorkflow(),reader.getMsgType(),numOfChunks,
				null,null,"I",null,null,null,null,null,null,null,null,null,null,null,null,null,false/*ackIndicator*/,null,null,null,0,0,0,0);
	  }finally
	  {
		  m_daoDebulkingProcess.releaseResources(conn);
	  }
  }

  private Feedback defineStatus(String[] sStatus, String[] sValidationsStatus, String[] sFileSummaryOffice, String[] internalFileId, String startPrefix
		  								, TransactionReader reader) throws FlowException
  {
	  logger.debug("defineStatus");
	  final UserTransaction[] arrTxHolder = new UserTransaction[1] ;
	  Connection conn = null;
	  Feedback feedback = new Feedback();
	  boolean shouldCommit = true;
	  try
	  {
		  feedback = BOBasic.startTransaction(arrTxHolder) ;
	      if(!feedback.isSuccessful()) throw new Exception(feedback.toString()) ;

	      if(!STATUS_FILE_DUPLICATE.equals(sStatus[0]))
	      {

		        conn = m_daoDebulkingProcess.getConnection();
		        PDO pdo = Admin.getContextPDO();
		        
		        pdo.set(PDOConstantFieldsInterface.P_ORG_INITG_PTY_CUST_CD, reader.getInitiatingPartyCustCode());
		        // Passed validations successfully.
		        if (reader.isSinglePayment())
		        {
		        	sStatus[0] = STATUS_FILE_DISTRIBUTED;
		        }
		        else if(sValidationsStatus == null || sValidationsStatus[0] == null)
		        {
		        	logger.info("executes incoming file filter rule, (rule type ID 141) ({})",startPrefix);
		          List<RuleResult> resultList = BOProxies.m_internalRuleExecutionLogging.executeRule(Admin.getContextAdmin(),RULE_TYPE_ID_INCOMING_FILE_FILTER,
		                                                                    null,pdo.getMID(),new String[]{sFileSummaryOffice[0]}).getResults();

		          sStatus[0] = resultList.size() > 0 ? resultList.get(0).getAction() : STATUS_FILE_DISTRIBUTED;
		          logger.info("status after rule execution: {} ({}) ", sStatus[0],startPrefix);
		        }

		        // Failed validations.
		        else
		        {
		          sStatus[0] = sValidationsStatus[0];
		        }
		        String oldFileStatus = pdo.getString(PDOConstantFieldsInterface.F_FILE_STATUS);
		        m_daoDebulkingProcess.updateFileSummaryStatusAndAudit(conn, sStatus[0] /*New File_Summary Status*/
		        		, oldFileStatus, pdo.getString(P_IN_INTERNAL_FILEID) /* Internal File ID */);
		        pdo.set(PDOConstantFieldsInterface.F_FILE_STATUS, sStatus[0]);
	      }
	  }catch(Throwable e)
	  {
		  ExceptionController.getInstance().handleException(e, this);
		  shouldCommit = false;
		  throw new FlowException(e);
	  }finally
	  {
		  feedback = BOBasic.endTransaction(arrTxHolder[0], shouldCommit)  ;
		  DAODebulkingProcess.releaseResources(conn);
	  }
	  return feedback;
  }

  private Feedback createChunks(String[] sValidationsStatus,String[] sFileSummaryOffice,String[] internalFileId,String[] priority,TransactionReader reader
		  ,  int chunkSize, int[] numOfChunk) throws FlowException {
	  logger.debug("createChunks: internalFileId {},chunkSize {}",internalFileId,chunkSize);
	  
	  Feedback feedback = new Feedback();
	  PreparedStatement chunkPs = null;
	  boolean shouldCommit = true;
	  Connection conn = null;
      int indx = 1;
      StringBuilder sb = new StringBuilder();
      StringBuilder sbToSend = new StringBuilder();

      final String insertString = "insert into file_process_distribution ( INTERNAL_FILE_ID,  CHUNK_ID,  OBJ_INSTANCE,  STATUS,  START_OFFSET,  END_OFFSET,  REC_COUNT,  BATCH_ID,  LAST_MID" +
		    ",  METHOD,  BULK_MSG_ID, TRANS_NO_START_FROM,  FROM_PMTINF_SEQ,  FROM_PMTINFID,  FROM_TRNINF_SEQ,  FROM_PMTID,  TO_PMTINF_SEQ,  TO_PMTINFID,  TO_TRNINF_SEQ" +
		    ",  TO_PMTID, UID_FILE_PROCESS_DISTRIBUTION, OFFICE, DEPARTMENT, PRIORITY, EFFECTIVE_DATE, REC_STATUS, PROFILE_CHANGE_STATUS, PENDING_ACTION, TIME_STAMP) "+
		    " values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, 'AC', 'NO', 'CR', "+
		    DAOBasic.ms_DBType.getToCharFormat(DAOBasic.ms_DBType.getCurrentTimestampKeyword(),DAOBasic.SQL_FORMAT_TIME_STAMP) + ")";
      // Determines chunk size.



	  try
	  {
//    	  feedback = BOBasic.startTransaction(arrTxHolder) ;
    	  conn = m_daoDebulkingProcess.getConnection();
    	  chunkPs = conn.prepareStatement(insertString);
    	  String[] workFlow = new String[1];
    	  HashMap mapContext = new HashMap();
          mapContext.put( "PRIORITY", priority[0]);

	      while(indx != 0)
	      {


		    	  if(!feedback.isSuccessful()) throw new TransactionException(feedback.toString()) ;
		          String sChunkStatus = STATUS_FILE_DISTRIBUTED;

	      		  if(!feedback.isSuccessful()) throw new Exception(feedback.toString()) ;
	      		  String chunkId=GlobalUtils.generateGUID();
	      		  workFlow[0] = null;
	      		  indx = getChuck(reader,sb,chunkSize, workFlow);
	      		  sbToSend.append(internalFileId[0]).append(",").append(chunkId).append(",").append(sValidationsStatus[0]).append(",")
	      		  	.append(workFlow[0]).append(GlobalConstants.PERMISSIONS_DELIMITER).append(sb);
	      		  if (indx != 0)
	      		  {
	      			  numOfChunk[0]++;
	      			  m_daoDebulkingProcess.insertIntoFILE_PROCESS_DISTRIBUTION(chunkPs,internalFileId[0],chunkId,indx, priority[0],reader.getPmtInfCount(),
	            		                                                      reader.getTrnsCountInPmtInf(),sChunkStatus, sFileSummaryOffice[0], ServerConstants.DEFAULT_SERVER_DEPARTMENT);


	      			  InterfaceTypes interfaceType= CacheKeys.interfaceTypesKey.getSingle(sFileSummaryOffice[0], InterfaceTypes.INTERFACE_TYPE_MASSPMNTS, InterfaceTypes.INTERFACE_SUB_TYPE_DEB);

	          		  PerformDebulkingRequestDocument debulkRequest =  PerformDebulkingRequestDocument.Factory.newInstance();
	          		  debulkRequest.setPerformDebulkingRequest(sbToSend.toString());

	          		  if (interfaceType != null) {
	          			  logger.debug("transmiting debulk request");
	          			  TransmissionType.valueOf(interfaceType.getRequestProtocol()).transmitInTx(debulkRequest, null, interfaceType, null, mapContext);
	          		  }

	      			  sb.delete(0,sb.length());
	      			  sbToSend.delete(0,sbToSend.length());
	      		  }
	      }

      chunkPs.executeBatch();
	  }catch(Throwable e)
	  {
		  shouldCommit = false;
		  throw new FlowException(e);
	  }finally
	  {
		  m_daoDebulkingProcess.releaseResources(conn, chunkPs);
//		  feedback = BOBasic.endTransaction(arrTxHolder[0], shouldCommit);
	  }

      return feedback;

  }


  private Feedback handleFileSummaryPart(TransactionReader reader, String startPrefix, String inputName, long inputLastModified, Long inputSize, String inputPath
		  , String[] sFileSummaryOffice, String[] sValidationsStatus, String[] internalFileId,String[] priority,String[] sStatus,int chunkSize) throws FlowException
  {
	  final String TRACE_EXISTING_FILE_SUMMARY_ENTRY_DETAILS = "Existing file summary entry details: Internal file ID: {}, Status: {}, Priority: {}, Message ID: {}, Reported number of transactions: {}, Party name: {}, Party ID: {}, Initiating party cust code: {}.";
	  final String TRACE_NEW_FILE_SUMMARY_ENTRY_DETAILS = "New file summary entry - Internal file ID: {}.";
	  final String TRACE_FILE_PROCESS_DISTRIBUTION_TO_PMTINF_SEQ_AND_TO_TRNINF_SEQ = "FILE_PROCESS_DISTRIBUTION data - TO_PMTINF_SEQ: {}, TO_TRNINF_SEQ: {}.";

	  Feedback feedback = new Feedback();
	  Connection conn = null;
	  PreparedStatement fileSummaryPs = null, fileProcessDistributionPs = null;
	  ResultSet fileSummaryRs = null, fileProcessDistributionRs = null;
	  boolean shouldCommit = true;
	  try
	  {
//		  feedback = BOBasic.startTransaction(arrTxHolder) ;
		  if(!feedback.isSuccessful()) throw new Exception(feedback.toString()) ;
		  conn = m_daoDebulkingProcess.getConnection();
	      logger.info("checks if file summary entry already exists... ({})",startPrefix);

	      priority[0] = "500";
	      int pmtInfSeq = 0;
	      int trnsInPmtInfSeq = 0;
	      int reportedNbOfTrns = -1;
	      String sMsgID=null; String sPartyName=null;String sPartyID=null;String sCtrlSum=null;String sInitiatingPartyCustCode=null;
	      boolean bFileSummaryEntryAlreadyExists = false;

	      fileSummaryPs = m_daoDebulkingProcess.getFileSummaryInternalFileIdAndStatus(conn,inputName,new Timestamp(inputLastModified));
	      fileSummaryRs = fileSummaryPs.executeQuery();

	      // File summary entry already exists.
	      if (fileSummaryRs.next())
	      {
	      	logger.info("file summary entry already exists... ({})",startPrefix);

	      	bFileSummaryEntryAlreadyExists = true;

	        internalFileId[0] = fileSummaryRs.getString(1);
	        sStatus[0] = fileSummaryRs.getString(2);
	        priority[0] = fileSummaryRs.getString(3);
	        sMsgID = fileSummaryRs.getString(4);
	        reportedNbOfTrns = fileSummaryRs.getInt(5);
	        sPartyName= fileSummaryRs.getString(6);
	        sPartyID = fileSummaryRs.getString(7);

	        // ASAF: No need anymore for the logic of getting the initiating party cust code,
	        //       after a change done by Eli for the Chile demo, because in case of a new FILE_SUMMARY entry,
	        //       the new record will be already set with this value, (INITG_PTY_CUST_CODE column).
	        //sInitiatingPartyCustCode = BOLoadCustomer.getInitiatingPartyCustCode(sPartyName, sPartyID, office);
	        sInitiatingPartyCustCode = fileSummaryRs.getString(8);

	        sFileSummaryOffice[0] = fileSummaryRs.getString(9);
	      }

	      // No entry yet; creates new internal file id.
	      else
	      {
	      	logger.info("no file summary entry yet, creates new internal file ID... ({})",startPrefix);
	        internalFileId[0] = GlobalUtils.generateGUID();
	      }

	      // Traces output accoridng to above results.
	      if(bFileSummaryEntryAlreadyExists) 
	    	  logger.info(TRACE_EXISTING_FILE_SUMMARY_ENTRY_DETAILS, new Object[]{internalFileId[0], sStatus[0], priority[0], sMsgID, reportedNbOfTrns, sPartyName, sPartyID, sInitiatingPartyCustCode});
	      else logger.info(TRACE_NEW_FILE_SUMMARY_ENTRY_DETAILS, internalFileId[0]);

          PDO pdo = PaymentDataFactory.newPDO(PaymentType.valueOf(PaymentType.PT_PACS_008), true/*bTransient*/);

          pdo.setMID(internalFileId[0]);
          pdo.set(PDOConstantFieldsInterface.P_MID, internalFileId[0]);

          pdo.set(PDOConstantFieldsInterface.P_IN_INTERNAL_FILEID, internalFileId[0]);;
          pdo.set(PDOConstantFieldsInterface.P_OFFICE, sFileSummaryOffice[0]);

	      // New entry for this file or entry which was terminated abnormally.
	        // No status yet; creates new file summary entry.
	      if (!IN_DISTRIBUTION.equals(sStatus[0]))
	      {
	        	if (sStatus == null || sStatus[0] == null)
	        		sStatus[0] =  IN_DISTRIBUTION;
	        	else
	        	{
	        		sStatus[0] = STATUS_FILE_DUPLICATE;
	        		logger.info( "duplicate file summary entry , creates new internal file ID... ({})",startPrefix);
	        		internalFileId[0] = GlobalUtils.generateGUID();

	        	}
	        	logger.info("no status yet, (no file summary entry); gets information from input XML file... ({})",startPrefix);

	            // Gets the info from the xml file.
	            if (sMsgID == null) sMsgID = reader.getMsgId();
	            if (reportedNbOfTrns == -1)
	            {
	                reportedNbOfTrns=reader.getNumOfTxs();
	            }
	            if (sCtrlSum == null) sCtrlSum=reader.getCtrlSum();

	            if (sPartyName == null) sPartyName=reader.getPartyName();

	            // ASAF: Previously, we used to set the party ID.
	            //       Change done by Eli for the Chile demo: the PAIN file will include the cust code, and later
	            //       on, we'll derive the party ID using the CUSTOMRS.BASE_NO column of the CUSTOMRS record
	            //       that stands for the cust code.
	            //if (sPartyID == null) sPartyID=m.group(5);
	            if (sInitiatingPartyCustCode == null) sInitiatingPartyCustCode=reader.getInitiatingPartyCustCode();

	          // In case this is a new file summary entry, initializes the office and the party ID according to the
	          // initiating party cust code.
	          if(!bFileSummaryEntryAlreadyExists)
	          {
	        	  sFileSummaryOffice[0] = reader.getOffice();

	        	if (sFileSummaryOffice == null || sFileSummaryOffice[0] == null)
	        	{

		            // Loads CUSTOMRS cache entry for above cust code.
		            Customrs customrs = CacheKeys.customrsCCKey.getSingle(sInitiatingPartyCustCode);
		            if(customrs != null)
		            {
		            	// Sets the future FILE_SUMARY.OFFICE to be the customer's office.
		            	sFileSummaryOffice[0] = customrs.getOffice();

		            	sPartyID = customrs.getBaseNo();
		            }
		            else
		            {
		            	logger.info( "ERROR: No CUSTOMRS record was found for initiating party cust code: {}" + 
		            			"; related FILE_SUMMARY status will be set to 'FileNotValidInitgPty' and office will be set to '***'. ({})"
		            			,sInitiatingPartyCustCode,startPrefix);

		            	// Sets the future FILE_SUMARY.OFFICE to be the default office; status will be set to 'FileNotValidInitgPty'
		            	// and when the user will fix it in the GUI, the correct office will be set as well.
		            	sFileSummaryOffice[0] = ServerConstants.DEFAULT_SERVER_OFFICE_NAME;
		            }
	        	}
	          }


	          // Multiple transcations.
	          logger.info("multiple transactions process; calls 'BOLoadCustomer' for getting initiating party cust code... ({})",startPrefix);

	          // ASAF: No need anymore for the logic of getting the initiating party cust code,
	          //       after a change done by Eli for the Chile demo.
	          //sInitiatingPartyCustCode = BOLoadCustomer.getInitiatingPartyCustCode(sPartyName, sPartyID, office);
	          logger.info("initiating party cust code: {} ({})", sInitiatingPartyCustCode,startPrefix);

	          Date currentTime = NewASDateTimeUtils.getCurrentDateAndZoneByOffice(sFileSummaryOffice[0]).getDate();

	          FileSummary fileSummary = new FileSummary(inputName,"I",inputSize,null,sMsgID,currentTime,reportedNbOfTrns,null,sInitiatingPartyCustCode,sPartyName,sPartyID
	        		  , sFileSummaryOffice[0],ServerConstants.DEFAULT_SERVER_DEPARTMENT, reader.getWorkflow());
	          
	          pdo.setIncomingFileSummary(fileSummary);
	          logger.info("executes file priority rule, (rule type ID 147) {{}}",startPrefix);
	          List<RuleResult> resultList = BOProxies.m_internalRuleExecutionLogging.executeRule(Admin.getContextAdmin(),RULE_TYPE_ID_FILE_PRIORITY,
	                                                                    null,pdo.getMID(),new String[]{sFileSummaryOffice[0]}).getResults();
	          if(resultList.size() > 0)
	          {
	          	priority[0] = resultList.get(0).getAction();
	          }
	          logger.info("priority: {} ({})", priority[0],startPrefix);

	          // Validates the file prior to FILE_SUMMARY entry creation, (duplicate validation && initiating party cust code validation).
	          sValidationsStatus[0] = 
	        	  STATUS_FILE_DUPLICATE.equals(sStatus[0]) 
					? sStatus[0] 
					: validateFile(null,conn, sMsgID, sPartyName, sPartyID,sInitiatingPartyCustCode, startPrefix, pdo);

	          logger.info("creates new file summary entry... ({})",startPrefix);

	          defineStatus(sStatus,sValidationsStatus,sFileSummaryOffice,internalFileId,startPrefix,reader);



	          //if the tx had failed, throw an exception

	        }//if (!IN_DISTRIBUTION.equals(sStatus))

	        // Status exists; gets the pmt and trns sequence from file_process_distribution.
	        else
	        {
	        	logger.info("status exists, (file summary file entry exists); gets TO_PMTINF_SEQ & TO_TRNINF_SEQ from FILE_PROCESS_DISTRIBUTION... ({})",startPrefix);

	          fileProcessDistributionPs = m_daoDebulkingProcess.getFileProcessDistributionPmtAndTrnsSeq(conn,internalFileId[0]);
	          fileProcessDistributionRs = fileProcessDistributionPs.executeQuery();

	          if (fileProcessDistributionRs.next())
	          {
	            pmtInfSeq = fileProcessDistributionRs.getInt(1);
	            trnsInPmtInfSeq = fileProcessDistributionRs.getInt(2);
	            logger.info(TRACE_FILE_PROCESS_DISTRIBUTION_TO_PMTINF_SEQ_AND_TO_TRNINF_SEQ, pmtInfSeq, trnsInPmtInfSeq);

	            // skip to next processed payment info.
	            if(pmtInfSeq > 0 && trnsInPmtInfSeq > 0) reader.goTo(pmtInfSeq, trnsInPmtInfSeq);
	          }
	        }
	  }catch(Throwable t)
	  {
		  ExceptionController.getInstance().handleException(t, this);
		  shouldCommit = false;
		  throw new FlowException(t);
	  }finally
	  {
		  DAODebulkingProcess.releaseResources(conn,fileSummaryPs,fileSummaryRs,fileProcessDistributionPs,fileProcessDistributionRs);
//		  feedback = BOBasic.endTransaction(arrTxHolder[0], shouldCommit)  ;
	  }

	  return feedback;

  }


  private void handleOneTransaction(TransactionReader reader, String startPrefix,  SimpleResponseDataComponent response) throws Exception
  {
    	logger.info(startPrefix + "single transaction; calls high value process...");

    	StringBuilder message = new StringBuilder();
      	getChuck(reader, message, 1, new String[1]);
    	Feedback singleTransFeedback = BOProxies.m_businessFlowSelectorLogging.executeBusinessFlow(Admin.getContextAdmin(), message.toString(),
    			reader.getInMsgContext(), null);
//      	Feedback singleTransFeedback = m_highValue.performHighValueProcessFromFile(Admin.getContextAdmin(),inputPath,sFileSummaryOffice);
      	logger.info(startPrefix + "finished single transaction high value process");
      	if(!singleTransFeedback.isSuccessful()) logger.info(ServerUtils.getFeedbackString(singleTransFeedback));

        response.setFeedback(singleTransFeedback);


  }

  private SimpleResponseDataComponent debulkFileInner(String filePath) throws Throwable {
	  //Decide which debulk service to invoke according to syst_par
	  String oSystPar = CacheKeys.SystParKey.getSingleParmValue(GlobalConstants.DEFAULT_SERVER_OFFICE_NAME, SystemParametersInterface.SYST_PAR_DEBULK_FILE_BY_INDEX);

	  if (GlobalConstants.Yes.equals(oSystPar)) {
		  logger.debug("enforce debulking by index due to system parameter {}",SystemParametersInterface.SYST_PAR_DEBULK_FILE_BY_INDEX);
		  return debulkFileInnerByIndex(filePath);
	  }
	  
	  SimpleResponseDataComponent response = new SimpleResponseDataComponent();

	  logger.info("Debulk File(not by index): input {}; ", filePath);	  

	  long time = System.nanoTime();
	  File file = getFileToDebulk(filePath);

	  String startPrefix = String.format("Debulk File path: %s; ", filePath);
	  logger.info(startPrefix);
	  if (file.isFile())

	  {
		  IterableTransactionReader iterReader = new IterableTransactionReader(file);

		  TransactionReader reader = iterReader.iterator();
		  try
		  {
			  if (reader.getNumOfTxs() > 1 || reader.getNumOfTxs() == GlobalConstants.MINUS_ONE_INT)
				  executeDebulking(reader, startPrefix, file.getName(), file.lastModified(), file.length(), file.getAbsolutePath(), response);
			  else
				  handleOneTransaction(reader, startPrefix, response);
		  }finally
		  {
			  reader.close();
		  }
	  }else
	  {
		  logger.info("Debulk File: file not found");
	  }

	  

	  return response;
  }


  private SimpleResponseDataComponent debulkStringInner(String message) throws Throwable {
	    SimpleResponseDataComponent response = new SimpleResponseDataComponent();

	    String startPrefix = "input is String message";
	    logger.info(startPrefix);

	    IterableTransactionReader iterReader = new IterableTransactionReader(message);

	    TransactionReader reader = iterReader.iterator();
	    try {
		    try {
		    	//Swift inputs should be handled as mass payment event though it holds only one message.
		    	if (reader.getNumOfTxs() > 1 || reader.getMsgType().indexOf("SWIFT") > -1)
		    		executeDebulking(reader, startPrefix, reader.getFileName() != null ? reader.getFileName() : "Text", new Date().getTime(), message.length(), GlobalConstants.EMPTY_STRING, response);
		    	else
		    		handleOneTransaction(reader, startPrefix, response);
		    }finally
		    {
		    	if (reader != null) reader.close();
		    }
	    } catch(Exception e) {
	    	throw new FlowException(e);
	    }
	    
	    return response;
  }


  /*
   *
   */
  private File getFileToDebulk(String sFilePath) throws Exception
  {
  	

    if (sFilePath.indexOf("/") == -1 && sFilePath.indexOf("\\") == -1)
    {
      String path = ServiceLocator.getInstance().urlLookup("InputFileLocationPath").getPath();

      if (!path.endsWith("/") && !path.endsWith("\\"))
      {
          path = path+File.separator;
      }
      sFilePath = path + sFilePath;
    }

    File file = new File(sFilePath);
    file.lastModified();
    int indx = 0;

    // For ESB.
    while (!file.isFile() && indx < 3)
    {
      Thread.sleep(10);
      indx++;
      file = new File(sFilePath);
    }

    

    return file;
  }

  /**
 * @param data 
 * @throws Throwable 
   *
   */
	public String validateFile(DebulkFileByIndexData data, Connection conn, String sMsgID,
			String sInitiatingPartyName, String sInitiatingPartyID,
			String sInitiatingPartyCustCode, String suffix, PDO pdo) throws Throwable {

		final String TRACE_DUPLICATION_VALIDATION = "performs duplication validation...";
		final String TRACE_INITIATING_PARTY_VALIDATION = "initiating party cust code is null; sets status to 'FileNotValidInitgPty'...";
		final String TRACE_METHOD_RESULT = "method result: {} ({})";

		String sValidationStatus = null;

		// File duplicate validation.
		try {	
			boolean bSkipDuplicateValidation = (data != null) ? data.isSkipDuplicateValidation() : false;
			if(!bSkipDuplicateValidation){
				sValidationStatus = validateFileDuplication(suffix, pdo,TRACE_DUPLICATION_VALIDATION, sValidationStatus);
				if (data != null) //OB
					data.setDuplicateIndex(pdo.getString(PDOConstantFieldsInterface.F_FILE_DUPLICATE_INDEX));
			}
		} catch (Exception e) {
			ExceptionController.getInstance().handleException(e, this);
		}

		// Initiating party validation.
		boolean bSkipInitiatingParty = (data != null) ? data.isSkipInitgPtyValidation() : false;
		if (sValidationStatus == null && !bSkipInitiatingParty) {			
			sValidationStatus = validateInitiatingParty(sInitiatingPartyCustCode, suffix,TRACE_INITIATING_PARTY_VALIDATION, sValidationStatus);
		}

		

		logger.info(TRACE_METHOD_RESULT,sValidationStatus,suffix);

		return sValidationStatus;
	}

/**
 * @param sInitiatingPartyCustCode
 * @param sTracePrefix
 * @param TRACE_INITIATING_PARTY_VALIDATION
 * @param sValidationStatus
 * @return
 */
private String validateInitiatingParty(String sInitiatingPartyCustCode,
		String suffix, final String TRACE_INITIATING_PARTY_VALIDATION,
		String sValidationStatus) {
	Customrs customrs = CacheKeys.customrsCCKey
			.getSingle(sInitiatingPartyCustCode);
	if (customrs == null) {
		sValidationStatus = STATUS_FILE_NOT_VALID_INITIATING_PARTY;
		logger.info(TRACE_INITIATING_PARTY_VALIDATION+" [{}]",suffix);
	}
	return sValidationStatus;
}

/**
 * @param sTracePrefix
 * @param pdo
 * @param TRACE_DUPLICATION_VALIDATION
 * @param sValidationStatus
 * @return
 * @throws Throwable 
 */
private String validateFileDuplication(String suffix, PDO pdo,final String TRACE_DUPLICATION_VALIDATION, String sValidationStatus) throws Throwable {
	
	
	logger.info(TRACE_DUPLICATION_VALIDATION+" [{}]",suffix);
	
	pdo.set(PDOConstantFieldsInterface.D_FILE_DUPLICATE_CHECK, true);

	MatchingCheckOutputData output = (MatchingCheckOutputData) BOProxies.m_matchingCheckLogging
			.performDuplicateCheck(Admin.getContextAdmin(),
					pdo.getMID(),false,false);
	boolean bDuplicate = !GlobalUtils.isNullOrEmpty(output.getMID());
	String fileDupexKey = (String) pdo.get(PDOConstantFieldsInterface.F_FILE_DUPLICATE_INDEX);
	FileSummary fileSummary = pdo.getNSetIncomingFileSummary();
	fileSummary.setFILE_DUPLICATE_INDEX(fileDupexKey);
	
	if (bDuplicate){
		sValidationStatus = STATUS_FILE_POSSIBLE_DUPLICATE;
		//Error 40501: File |1 failed duplication check
		String fileName = pdo.getString(PDOConstantFieldsInterface.F_FILE_NAME);
		ProcessError processError = new ProcessError(ProcessErrorConstants.BulkFileDuplicate
					,new Object[]{fileName});		    
		ErrorAuditUtils.setErrors(processError,pdo.getIsHistory());
		addEntryToInterfaceErrorTable(pdo, ProcessErrorConstants.BulkFileDuplicate, fileName);
	}
	return sValidationStatus;
}

  private void addEntryToInterfaceErrorTable(PDO pdo, int errorCode, String fileName) throws Throwable
  {
		String businessFlowType = pdo.getString(PDOConstantFieldsInterface.P_BUSINESS_FLOW_TP);
		if (businessFlowType.equals(GlobalConstants.BP))
		{
			// get last session id for log table writing
			int sessionId = errorLog.getLastSessionId();
			
			String interfaceName = null;
			InterfaceTypes interfaceType= CacheKeys.interfaceTypesKey.getSingle(GlobalConstants.DEFAULT_SERVER_OFFICE_NAME, InterfaceTypes.INTERFACE_TYPE_MASSPMNTS, InterfaceTypes.INTERFACE_SUB_TYPE_DEB);
			if (interfaceType != null)
			{
				interfaceName = interfaceType.getInterfaceName();
			}
			
			String description = GlobalUtils.getEditedErrorText(errorCode, fileName);
			errorLog.addInterfaceErrorLog(USER_ID, sessionId, interfaceName, SEVERITY_ERROR, description);
			// print into trace log			
			logger.error(description);			
		}	  
  }

  public String getPmtInfSec(String xml)
  {
	  TransactionReader reader = TransactionReader.TransactionReaderFactory(xml);
	  StringBuilder sb = new StringBuilder();
	  reader.next();
	  sb.append(reader.getHeader()).append(reader.getCurrentPmtInfHeader()).append(reader.getTrnsStartTag()).append(">").append(reader.getTrnsEndTag()).append(reader.getChunkEnd());
	  return sb.toString();
  }

  /**
   *
   */
  private int getChuck(TransactionReader reader, StringBuilder sb, int chunkSize, String[] workflow) {
	  logger.debug("getting chunk, size={}",chunkSize);
  	// The sameHeaderInChunkRequired is required for multi type files - for the same type change we stay in the same chunk with different header
	boolean sameHeaderInChunkRequired = false;
    int indx = 0;
    while (reader.hasNext())
    {
    	String trns = reader.next();
    	if (trns.length() > 0)
    	{

    	  if (workflow[0] == null) workflow[0] = reader.getWorkflow();
	      if (indx == 0 || sameHeaderInChunkRequired)
	      {
	    	sameHeaderInChunkRequired = false;
	        sb.append(reader.getHeader()).append(reader.getCurrentPmtInfHeader());
	        trns = trns.substring(reader.indexOfIgnoreWhiteSpaces(trns,reader.getTrnsStartTag(),reader.getTrnsEndTag()));
	      }

	      indx++;

	      sb.append(trns);

	      // Extract chunk end tag - for multi type files the end tag can change in the following hasNext method, so we extract it before the change
	      String chunkEnd = reader.getChunkEnd();

	      if (indx == chunkSize || !reader.hasNext() || reader.isMessageTypeChanged())
	      {
	    	  sb.append(chunkEnd);
	    	  // If isSameHeaderInChunkRequired is true we continue the loop - multi type files can have more than one header in the chunk
	    	  if (reader.isSameHeaderInChunkRequired()) {
	    		  sameHeaderInChunkRequired = true;
	    	  } else {
	    		  break;
	    	  }
	      }
	    }
    }
    

    return indx;
  }

  private int getTrnsChuck(TransactionReader reader, StringBuilder sb, int chunkSize) {
	  logger.debug("getTrnsChuck, size={}",chunkSize);
	    int indx = 0;
	    while (reader.hasNext())
	    {
	    	String trns = reader.next();
	    	if (trns.length() > 0){

		      if (indx == 0)
		      {
		        sb.append(reader.getEmptyHeader()).append(reader.getPmtInfoStartTag()).append(">");
		        trns = trns.substring(reader.indexOfIgnoreWhiteSpaces(trns,reader.getTrnsStartTag(),reader.getTrnsEndTag()));
		      }

		      indx++;
		      if (indx == chunkSize || !reader.hasNext())
		      {
		        sb.append(trns).append(reader.getChunkEnd());
		        	break;
		      }
	    	  sb.append(trns);
		    }
	    }
	    //

	    return indx;
	  }

  //****************************Start Using new XmlTransactionReader By Index - Iterator*******************************

  /**
   * debulkFileByIndex
   *
   *
   * @author dmitryp
   *
  */
  public  SimpleResponseDataComponent debulkFileByIndex(String filePath) throws Throwable
  {
	  return (SimpleResponseDataComponent) super.executeInProtectedBoundaries(m_debulkFileInnerByIndex, filePath);

  }//EOM debulkFileByIndex

 
  
  /**
   * debulkStringByIndex
   *
   *
   * @author dmitryp
   *
  */
  public  SimpleResponseDataComponent debulkStringByIndex(String message) throws Throwable
  {
	  return (SimpleResponseDataComponent) super.executeInProtectedBoundaries(m_debulkStringInnerByIndex, message);

  }//EOM debulkStringByIndex



  /**
   * executeDebulking
   *
   *
   *
   * @author dmitryp
  */
  private Feedback executeDebulkingByIndex(DebulkFileByIndexData data) throws Throwable {
	  logger.debug("executing Debulking By Index, data {}",data);
	  Feedback feedback = handleFileSummaryPartByIndex(data);

        if (feedback.isSuccessful() 
        		&& !STATUS_FILE_NOT_VALID_INITIATING_PARTY.equals(data.getValidationsStatus())
        		&& !STATUS_FILE_DUPLICATE.equals(data.getStatus())
        		&& !STATUS_FILE_POSSIBLE_DUPLICATE.equals(data.getStatus())
        		&& !STATUS_FILE_REJECTED.equals(data.getStatus())
        		&& !STATUS_FILE_CANCELED.equals(data.getStatus()))
        {
        	feedback = createChunksByIndex(data);
        }
        return feedback;


  }//EOM executeDebulkingByIndex


  /**
   * createFileSummary
   *
   *
   * @author dmitryp
   *
  */
  private void createFileSummaryByIndex(DebulkFileByIndexData data) throws Exception {
	  logger.debug("creating File Summary By Index, data {}",data);
	  Connection conn = null;
	  try
	  {
		  PDO pdo = Admin.getContextPDO();
		  
		  //Updating the Number Of Chunks
		  pdo.set(PDOConstantFieldsInterface.F_NUM_OF_CHUNKS, data.getNumOfChunks());
		  
		  FileSummary fileSummary = pdo.getNSetIncomingFileSummary();
		  conn = m_daoDebulkingProcess.getConnection();
		  Customrs cust = CacheKeys.customrsCCKey.getSingle(fileSummary.getInitgPtyCustCode());

		  XmlTransactionReaderBase reader = (XmlTransactionReaderBase) data.getReader();
		  
			String custId = (cust != null) ? cust.getBaseNo() : null;
			
			//Setting the PlCreateDt to the AppHdr CreDt from the original file AppHdr, Defect #65465
			Date appHdrCreDT = reader.getAppHdrCreDt();
			
			if(data.isRebulk()){	
		        String oldFileStatus = pdo.getString(PDOConstantFieldsInterface.F_FILE_STATUS);
		        m_daoDebulkingProcess.updateFileSummaryStatusAndAudit(conn, data.getStatus(), 
		        		oldFileStatus, pdo.getString(P_IN_INTERNAL_FILEID));
		        fileSummary.setStatus(data.getStatus());
		        pdo.set(PDOConstantFieldsInterface.F_FILE_STATUS,data.getStatus());
			} else {
				m_daoDebulkingProcess.createFileSummaryEntry(conn, 
					fileSummary.getOffice(), fileSummary.getDepartment(),
					data.getInternalFileID(), 
					data.getFile().getName(), 
					data.getFile().getPath(), 
					data.getFile().lastModified(),
					appHdrCreDT,
				  	data.getFile().length(),reader.getSendingInst(),
				  	new Timestamp(fileSummary.getPlCreateDate().getTime()),
				  	data.getStatus(),
				  	fileSummary.getInitgPtyCustCode(),
					reader.getPartyName(),
					custId,
					data.getPriority(),
					reader.getCtrlSum(),
					reader.getFileReference(),
					reader.getTrnsCount(),

					//TODO remove null
//					reader.getInputAsString(),
//					reader.getWorkflow(),
//					reader.getMsgType(),
					null,null,null,
					data.getNumOfChunks(),
					null,null,"I",null,null,null,null,null,null,null,null,reader.getReceivingInst(),null,reader.getFileType(),
					fileSummary.getFILE_DUPLICATE_INDEX(),reader.getBusinessDate(),false/*ackIndicator*/,
					data.getRelInternalFileID(),reader.getSenderName(),reader.getFileSource(),
					reader.getNumCTBlk(),reader.getNumDDBlk(),
					reader.getCalcNumCTBlk(), reader.getCalcNumDDBlk());
				fileSummary.setPlCreateDate(appHdrCreDT);
			}

	  } catch (Exception e) {
		  logger.error(e.getMessage());	
	  } finally {
		  DAODebulkingProcess.releaseResources(conn);
	  }

  }//EOM createFileSummaryByIndex


  /**
   * Using new MultiXmlTransactionReader - Iterator
   *
   * @param chunkSize - parameter from SysPar table
   *
   * @author dmitryp
   * @param chunksList
   * @throws IOException
  */
//  private Feedback createChunksByIndex(String[] sValidationsStatus,String[] sFileSummaryOffice,String[] internalFileId,String[] priority,int chunkSize,
//		  int[] numOfChunk, String path,XmlTransactionReaderBase xmlTransactionReader, List<String> chunksList) throws FlowException
  private Feedback createChunksByIndex(DebulkFileByIndexData data) throws FlowException {
	  logger.debug("creating chunks By Index, data {}",data);
	  Feedback feedback = new Feedback();
	  PreparedStatement chunkPs = null;
	  Connection conn = null;
      int indx = 1;
      boolean shouldCommit = true;
      final UserTransaction[] arrTxHolder = new UserTransaction[1] ;
      final String insertString = "insert into file_process_distribution ( INTERNAL_FILE_ID,  CHUNK_ID,  OBJ_INSTANCE,  STATUS,  START_OFFSET,  END_OFFSET,  REC_COUNT,  BATCH_ID,  LAST_MID" +
		    ",  METHOD,  BULK_MSG_ID, TRANS_NO_START_FROM,  FROM_PMTINF_SEQ,  FROM_PMTINFID,  FROM_TRNINF_SEQ,  FROM_PMTID,  TO_PMTINF_SEQ,  TO_PMTINFID,  TO_TRNINF_SEQ" +
		    ",  TO_PMTID, UID_FILE_PROCESS_DISTRIBUTION, OFFICE, DEPARTMENT, PRIORITY, EFFECTIVE_DATE, REC_STATUS, PROFILE_CHANGE_STATUS, PENDING_ACTION, TIME_STAMP) "+
		    " values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, 'AC', 'NO', 'CR', "+
		    DAOBasic.ms_DBType.getToCharFormat(DAOBasic.ms_DBType.getCurrentTimestampKeyword(),DAOBasic.SQL_FORMAT_TIME_STAMP) + ")";

	XmlTransactionReaderBase xmlTransactionReader = (XmlTransactionReaderBase)data.getReader();
	
	try {
	      conn = m_daoDebulkingProcess.getConnection();
    	  chunkPs = conn.prepareStatement(insertString);
    	  
          String sChunkStatus = STATUS_FILE_DISTRIBUTED;

  		  String chunkId=GlobalUtils.generateGUID();
  		  String bulkId = null;
		  boolean fileHaveChunks = false;
          int i=0;
          
          while(xmlTransactionReader.hasNext())
          {
        	  //Get xml of chunk size
        	  Object request = xmlTransactionReader.next();
        	  // in case there's a group which does not return chunks (whole_accepted for example)
        	  // but we still need to process other groups
        	  if (request == null)
        		  continue;
        	  
        	  // File have chunks to process.
        	  fileHaveChunks = true;
        	  
        	  if (xmlTransactionReader.isNewBulk()){
				  bulkId = GlobalUtils.generateGUID();
				  m_daoDebulkingProcess.createBulkSummaryEntry(data.getFileSummaryOffice(), data.getFileSummaryDepartment(), 
						  data.getInternalFileID(), bulkId, xmlTransactionReader.getBulkNumOfTx(), xmlTransactionReader.getBulkCtrlSum(), 
						  xmlTransactionReader.getBulkTotalAmt(),xmlTransactionReader.getBulkType(),xmlTransactionReader.getBulkCreDtTm());
			  }
        	  
        	  xmlTransactionReader.setAdditionalDocumentData(
						request,
						chunkId, 
						data.getStatus(),
						data.getInternalFileID(), 
						data.getFile().getPath(),
						xmlTransactionReader.getWorkflow(), bulkId);
				
        	  int iLength = xmlTransactionReader.getRecCountInChunk(request);

        	  //Update FILE_PROCESS_DISTRIBUTION table
    		  m_daoDebulkingProcess.insertIntoFILE_PROCESS_DISTRIBUTION(chunkPs,data.getInternalFileID(),chunkId,iLength, data.getPriority(),
    				  xmlTransactionReader.getPmtInfCount(),iLength,sChunkStatus, data.getFileSummaryOffice(), ServerConstants.DEFAULT_SERVER_DEPARTMENT);

	  		  sChunkStatus = STATUS_FILE_DISTRIBUTED;
			  chunkId=GlobalUtils.generateGUID();

			  i++;
			  if (i==500)
			  {
				  chunkPs.executeBatch();
				  m_daoDebulkingProcess.releaseResources(chunkPs);
				  chunkPs = conn.prepareStatement(insertString);

				  i=0;
			  }
			  // Instead of sending the chunk store it in this list and send all of the chunks together
			  data.getChunksList().add(xmlTransactionReader.getXmlofChunk(request));
			  
			  // Incrementing the number of chunks
			  data.incNumOfChunks();
			  
			  // Here we check if a multi reader is marked as needed to change the schema specific reader
			  if (xmlTransactionReader instanceof MultiXmlTransactionReader)  { 
				  if  ( ((MultiXmlTransactionReader) xmlTransactionReader).shouldChangeReader() ){
					  ((MultiXmlTransactionReader) xmlTransactionReader).readTillNextPaymentTypeAndChangeReader();
					  ((MultiXmlTransactionReader) xmlTransactionReader).setShouldChangeReader(false);
				  }
			  }

          }//while has next
		  String prevFileStatus = data.getStatus();

		  feedback = BOBasic.startTransaction(arrTxHolder) ;
	      if(!feedback.isSuccessful()) throw new Exception(feedback.toString());
		  
		  // In case file has only AppHdr and is included in empty File Support List it will be assigned as FileCompleted see CR #134 (64443)
		  if(emptyFileSupportList.contains(xmlTransactionReader.getFileType())
				  && fileHaveChunks == false)
		  {
			  data.setStatus(STATUS_FILE_COMPLETED);
			  m_daoFileSummary.updateFileSummaryStatusNoAudit(data.getInternalFileID(),STATUS_FILE_COMPLETED);
			  fsHandler.fileStatusAudit(STATUS_FILE_COMPLETED, prevFileStatus, data.getInternalFileID());
			  PDO pdo = Admin.getContextPDO();
			  pdo.set(PDOConstantFieldsInterface.F_FILE_STATUS, STATUS_FILE_COMPLETED);
			  prevFileStatus = STATUS_FILE_COMPLETED;
		  }
		  
          //Related only to AckXmlTransactionReader
		  if (xmlTransactionReader instanceof AckXmlTransactionReaderIfc) {
				// Set the internal file ID of related outgoing file
				String relInternalFileId = ((AckXmlTransactionReaderIfc) xmlTransactionReader)
						.getoriginalFileInternalId();
				if (!GlobalUtils.isNullOrEmpty(relInternalFileId))
					data.setRelInternalFileID(relInternalFileId);
				// Need to Update Status of CVF to NOT_MATCHED or to
				// SubBatchCompletion in some cases
				// if (fileHaveChunks) {
				String fileStatus = ((AckXmlTransactionReaderIfc) xmlTransactionReader)
						.getFileStatus();
				if (!GlobalUtils.isNullOrEmpty(fileStatus))
					data.setStatus(fileStatus);
				// }
				if (xmlTransactionReader instanceof G3MultiPacs002BulkTransactionReader)
					m_daoFileSummary.updateFileSummaryNumberOfChunksAndStatus(
									data.getInternalFileID(),data.getStatus(), prevFileStatus,
									((G3MultiPacs002BulkTransactionReader) xmlTransactionReader)
											.getNumberOfChunks());
											
			}
          
      	  chunkPs.executeBatch();
	}catch(Throwable e)
	{
		  shouldCommit = false;
		  throw new FlowException(e);
	}finally
	{
		  feedback = BOBasic.endTransaction(arrTxHolder[0], shouldCommit)  ;
		  DAODebulkingProcess.releaseResources(conn, chunkPs);
		  xmlTransactionReader.remove();
	}

      return feedback;

  }//EOM createChunksByIndex Iterable XmlTransactionReader

  
  public SimpleResponseDataComponent redebulkFileByIndex(String sdata) throws Throwable {
	  DebulkFileByIndexData data = new DebulkFileByIndexData();
	  data.fromString(sdata);	  
	  return (SimpleResponseDataComponent) super.executeInProtectedBoundaries(m_redebulkFileInnerByIndex, data);
  }
  
  /**
   * 
   * @param filePath
   * @return
   * @throws Throwable
   */
  private SimpleResponseDataComponent redebulkFileInnerByIndex(DebulkFileByIndexData data) throws Throwable {
	  String originator = innerCloseTx();
	  SimpleResponseDataComponent response = new SimpleResponseDataComponent();
	  
	  logger.info("Re-Debulk File: input {}; ", data.getInternalFileID());
	  
	  Connection conn = null;
	  PreparedStatement fileSummaryPs = null;	  
	  ResultSet fileSummaryRs = null;
	  
	  String filePath = null;
	  try{
		  conn = m_daoDebulkingProcess.getConnection();
		  fileSummaryPs = m_daoDebulkingProcess.selectFileSummeryByInternalFileID(conn, data.getInternalFileID());
		  fileSummaryRs = fileSummaryPs.executeQuery();
		  if (fileSummaryRs.next()) {
			  filePath = fileSummaryRs.getString(10);
			  File file = new File(filePath);
			  data.setFile(file);			  
		  }
	  } finally {
		  DAODebulkingProcess.releaseResources(conn, fileSummaryPs,fileSummaryRs);
	  }
	  
	  response = debulkFileInnerByIndex(filePath, data, originator);	  
	  return response;	  
  }
  
  /**
   * 
   * @param filePath
   * @return
   * @throws Throwable
   */
  private SimpleResponseDataComponent debulkFileInnerByIndex(String filePath) throws Throwable {
	  String originator = innerCloseTx();
	  return debulkFileInnerByIndex(filePath, null, originator);
  }
  
  /**
   * debulkFileInnerByIndex
   *
   *
   * @author dmitryp
   *
   */
  private SimpleResponseDataComponent debulkFileInnerByIndex(String filePath, DebulkFileByIndexData data, String originator) throws Throwable {
    logger.info("debulkFileInnerByIndex, file {}", filePath);

    SimpleResponseDataComponent response = new SimpleResponseDataComponent();

	Admin admin;
    long time = System.nanoTime();
    File file = getFileToDebulk(filePath);
    String sValidationsStatus = null;
    String internalFileId = null;
    String priority = null;
    String sStatus = null;
    int numOfChunks = 0;
	boolean trxStarted = false;
	List<String> dupexKey = new ArrayList<String>();
    
	String startPrefix = String.format("Debulk File path: %s; ", filePath);

	XmlTransactionReaderBase reader = null;
	
    if (file.isFile()) {    	
	    try {
	    	String sFileSummaryOffice = "";
	    	String sFileSummaryDepartment = "";
	    	
	    	int chunkSize = Integer.parseInt(CacheKeys.SystParKey.getSingleParmValue(
	    			sFileSummaryOffice, SystemParametersInterface.SYS_PAR_FILE_CHUNCK_SIZE));
	    	
	    	Feedback feedback = new Feedback();
	    	
	    	//Note: it's too early to init the reader now as there is no PDO yet 
	    	//and on if the file is invalid XML, no advice would be generated  
	    	reader = getTransactionReader(file, chunkSize);
	    	
	    	List<String> chunksList= new ArrayList<String>();

	    	if(data != null){
	    		data.setStatus(sStatus);
	    		data.setPriority(priority);
	    		data.setFileSummaryOffice(sFileSummaryOffice);
	    		data.setReader(reader);
	    		data.setStartPrefix(startPrefix);
	    		data.setFile(file);
	    		data.setChunkSize(chunkSize);
	    		data.setChunksList(chunksList);
	    		data.setNumOfChunks(numOfChunks);
	    		data.setValidationsStatus(sValidationsStatus);
	    		data.setResponse(response);
	    	} else {
	    		data = new DebulkFileByIndexData<XmlTransactionReaderBase>(
						internalFileId, sStatus, priority, sFileSummaryOffice,sFileSummaryDepartment,
						reader, startPrefix, file, chunkSize, chunksList,
						numOfChunks, sValidationsStatus, response);
	    	}
	    	
	    	
	    	feedback = executeDebulkingByIndex(data);

    		trxStarted = super.startTx(originator) != null;

    		//Remove file duplicate index from cache after end of transaction
		    admin = Admin.getContextAdmin();
			if (data.getDuplicateIndex() != null) {
			    dupexKey.add(data.getDuplicateIndex());
				RemoveDupexFromCacheLastResourceHandler removeFileDupexKey = new RemoveDupexFromCacheLastResourceHandler(dupexKey);
				admin.registerLastResource(removeFileDupexKey);
			}
			
    		if (feedback.isSuccessful()) {
    			createFileSummaryByIndex(data);	
    			//Related to CVF file (Ack)
    			if (!GlobalUtils.isNullOrEmpty(data.getRelInternalFileID())) {
    				m_daoDebulkingProcess.updateOutGoingFileRelFileID(data);    				
    			}
    			
    			if(!data.getStatus().equals(STATUS_FILE_DUPLICATE) &&
    					!data.getStatus().equals(STATUS_FILE_POSSIBLE_DUPLICATE)&&
    					!data.getStatus().equals(STATUS_FILE_REJECTED)&&
    					!data.getStatus().equals(STATUS_FILE_CANCELED)){
    				
    				transmitChunks(data);
    			}    
    			//XmlTransactionReaderBase xmlTransactionReader = (XmlTransactionReaderBase)data.getReader();
    			//if(xmlTransactionReader instanceof G3MultiPacs002BulkTransactionReader){
				//	createBulksForRejectedChunks(data);
    			//}
	        }
	    } catch (Exception e) {
	    	logger.error("",e);
	    	
	    	e = getCause(e,XMLStreamException.class);
	    	
	    	if (e != null)
	    	{
	    		onInvalidXmlFile((XMLStreamException)e,file);
	    		
	    		PDO pdo = null;
	    		if ((pdo = Admin.getContextPDO()) != null)
	    		{
	    			logger.info("debulkFileInnerByIndex : InvalidXmlFile - Set payment status to REJECTED ");
	    			pdo.set(PDOConstantFieldsInterface.P_MSG_STS,MessageConstantsInterface.MESSAGE_STATUS_REJECTED);
	    		}
	    	}
	    } finally {
	    	PDO pdo = null;
	    	if ((pdo = Admin.getContextPDO()) != null){
	    		
	    		//For DEV: rechangeFileStatus is used in order to support rule 172 FileRecieved starting status which is needed and agreed (BA decision)
	    		boolean rechangeFileStatus = STATUS_FILE_DISTRIBUTED.equals(pdo.getString(F_FILE_STATUS));
	    		
	    		if(rechangeFileStatus)
	    			pdo.set(PDOConstantFieldsInterface.F_FILE_STATUS, STATUS_FILE_RECIEVED);	//Do NOT Audit

	    		applyFileLevelNotificationFlow(pdo);
	    		
	    		if(rechangeFileStatus)
	    			pdo.set(PDOConstantFieldsInterface.F_FILE_STATUS, STATUS_FILE_DISTRIBUTED); //Do NOT Audit

				PaymentDataFactory.batchSave(false, pdo);
			}
	    	
	    	if (reader != null)
	    		reader.remove();
	    	
	    	if (!trxStarted) 
	    		super.startTx(originator);
	    }
    } else {
    	logger.info("Debulk File: file not found");
    }

    return response;
  }//EOM debulkFileInnerByIndex
  
  /**
   * incase of processing a multi bulk pacs002 file
   * with bulks in full reject status.
   * this method will create and transmit the chunks to the
   * next stage.
 * @param BulkType - which bulks are full reject
 * @param  
 * @throws Throwable 
 */
  private void createBulksForRejectedChunks(DebulkFileByIndexData data) throws Throwable {
	  String internalFileId=data.getRelInternalFileID();
	  List<String> chunks = data.getChunksList();
	  String outChunkID = null;
	  PerformDebulkingAckRequsetDocument doc = null;
	  String chunkIDs = new String();
	  for(String chunk : chunks){
		  try {

				doc = PerformDebulkingAckRequsetDocument.Factory.parse(chunk);

			} catch (Exception e) {

				throw new FlowException(e);
			}
		  PerformDebulkingAckRequsetType debulkingAckRequest = doc.getPerformDebulkingAckRequset();
		  outChunkID = debulkingAckRequest.getOutChunkID();
		  if(outChunkID!=null)
			  chunkIDs+= chunkIDs.isEmpty() ? "'"+outChunkID+"'" : "'"+outChunkID+"',"+chunkIDs;
	  }
	  if(!GlobalUtils.isNullOrEmpty(chunkIDs))
		  createRejectedChunks(chunkIDs,internalFileId);
	  
  }

protected XmlTransactionReaderBase getTransactionReader(File file, int chunkSize){
	  return new IterableXmlTransactionReader(file,chunkSize).iterator();
  }

  
  private void onInvalidXmlFile(XMLStreamException e,File file) {
	  if (Admin.getContextPDO() != null)
	  {
		  Admin.getContextPDO().set(PDOConstantFieldsInterface.F_FILE_STATUS,STATUS_FILE_NOT_VALID_XML+":"+e.getMessage());
		  Admin.getContextPDO().set(PDOConstantFieldsInterface.F_FILE_NAME,file.getName());
		  logger.debug("Set Pdo F_FILE_STATUS to {} set F_FILE_NAME to {}",STATUS_FILE_NOT_VALID_XML+":"+e.getMessage(),file.getName());	  
	  }
	  
	  //File |1 failed format validation	|1 - File name
	  ProcessError processError = new ProcessError(ProcessErrorConstants.BulkFileInvalidXml
				,new Object[]{file.getName()});		    
	  ErrorAuditUtils.setErrors(processError);
  }

  private void applyFileLevelNotificationFlow(PDO pdo) throws Throwable {
	  logger.debug("perform file level notification flow on file with internal file ID = {}",pdo.getMID());	  
	  BOHighValueProcess.performNotificationFlow(pdo);	
  }

/**
 * @return
 * @throws Throwable
 */
private String innerCloseTx() throws Throwable {
	// End the user transaction in order to handle large files, it is resumed in the finally block
	// TODO Find a better solution that keeps us in the transaction E.G. use setTransactionTimeout (currently it doesn't work in websphere)
	String originator = (String)Admin.getContextAdmin().getSessionData("ORIGINATOR");
	
	UserTransaction userTx = null;
	if (originator != null) {
		// startTx acts like getTx
		userTx = super.startTx(originator);
		super.closeTx(originator, true);
	}
	return originator;
}

/**
 * @param data
 * @param reader
 * @param chunksList
 * @throws Throwable
 */
private void transmitChunks(DebulkFileByIndexData data)throws Throwable {
	XmlTransactionReaderBase reader = (XmlTransactionReaderBase) data.getReader();
	List<String> chunksList = data.getChunksList();
	
	String interfaceSubType = reader.getInterfaceSubType();
	InterfaceTypes interfaceType = CacheKeys.interfaceTypesKey.getSingle(data.getFileSummaryOffice(), InterfaceTypes.INTERFACE_TYPE_MASSPMNTS, interfaceSubType);
	Map<String, String> mapContext = new HashMap<String, String>();
	mapContext.put("PRIORITY", data.getPriority());	
	
	for(String chunkStr : chunksList) {
		if (interfaceType != null) {
			logger.debug("transmit chunk: {}",chunkStr);
			String requestProtocol = interfaceType.getRequestProtocol();
			TransmissionType.valueOf(requestProtocol).transmitInTx(chunkStr, null, interfaceType, null, (HashMap)mapContext);
		}
	}
}

private void transmitChunks(List<String> chunksList, String interfaceSubType, String priority, String fileSummaryOffice)throws Throwable {
	
	InterfaceTypes interfaceType = CacheKeys.interfaceTypesKey.getSingle(fileSummaryOffice, InterfaceTypes.INTERFACE_TYPE_MASSPMNTS, interfaceSubType);
	Map<String, String> mapContext = new HashMap<String, String>();
	mapContext.put("PRIORITY", priority);	
	
	for(String chunkStr : chunksList) {
		if (interfaceType != null) {
			logger.debug("transmit chunk: {}",chunkStr);
			String requestProtocol = interfaceType.getRequestProtocol();
			TransmissionType.valueOf(requestProtocol).transmitInTx(chunkStr, null, interfaceType, null, (HashMap)mapContext);
		}
	}
}


  /**
   * debulkStringInnerByIndex
   *
   *
   * @author dmitryp
   *
  */
  private SimpleResponseDataComponent debulkStringInnerByIndex(String message) throws Throwable
  {

	  	final String TRACE_INPUT = "Method input - string message.";

	    

	    logger.info(TRACE_INPUT);

	    SimpleResponseDataComponent response = new SimpleResponseDataComponent();
	    /*
	    String startPrefix = String.format("String input");
	    logger.info(startPrefix);

	    long time = System.nanoTime();

	    String[] sFileSummaryOffice = new String[1];
    	int chunkSize = Integer.parseInt(CacheKeys.SystParKey.getSingleParmValue(sFileSummaryOffice[0], SystemParametersInterface.SYS_PAR_FILE_CHUNCK_SIZE));
    	XmlTransactionReaderBase reader = new IterableXmlTransactionReader(file,chunkSize).iterator();

	    try
	    {
		    try
		    {
				//Swift inputs should be handled as mass payment event though it holds only one message.
		    	if (reader.getTrnsCount() > 1 || reader.getMsgType().indexOf("SWIFT") > -1)
		    		executeDebulkingByIndex(reader, startPrefix, reader.getFileName() != null ? reader.getFileName() : "Text",
		    				new Date().getTime(), message.length(), GlobalConstants.EMPTY_STRING, response);
		    	else
		    		handleOneTransactionByIndex(reader, TRACE_INPUT, response);
		    }finally
		    {
		    	if (reader != null) reader.remove();
		    }
	    }catch(Exception e)
	    {
	    	throw new FlowException(e);
	    }

	    */

	    logger.info(TRACE_INPUT);

	    

	    return response;



  }//EOM debulkStringInnerByIndex


  
  /**
   * handleFileSummaryPartByIndex
   *
   *
   * @author dmitryp
 * @throws Throwable 
   *
  */
  private Feedback handleFileSummaryPartByIndex(DebulkFileByIndexData data) throws Throwable {
	  logger.debug("handleFileSummaryPartByIndex, data {}",data);
	  
	  final String TRACE_EXISTING_FILE_SUMMARY_ENTRY_DETAILS = "Existing file summary entry details: Internal file ID: {}, Status: {}, Priority: {}, Message ID: {}, Reported number of transactions: {}, Party name: {}, Party ID: {}, Initiating party cust code: {}.";
	  final String TRACE_NEW_FILE_SUMMARY_ENTRY_DETAILS = "New file summary entry - Internal file ID: {}.";
	  final String TRACE_FILE_PROCESS_DISTRIBUTION_TO_PMTINF_SEQ_AND_TO_TRNINF_SEQ = "FILE_PROCESS_DISTRIBUTION data - TO_PMTINF_SEQ: {}, TO_TRNINF_SEQ: {}.";

	  Feedback feedback = new Feedback();
	  
	  Connection conn = null;
	  PreparedStatement fileSummaryPs = null; 
	  PreparedStatement fileProcessDistributionPs = null;
	  ResultSet fileSummaryRs = null;
	  ResultSet fileProcessDistributionRs = null;
	  boolean shouldCommit = true;
	  
	  try {
		  if(!feedback.isSuccessful())
			  throw new Exception(feedback.toString()) ;
		  
		  conn = m_daoDebulkingProcess.getConnection();
	      String suffix = data.getStartPrefix();
	      
	      logger.info("checks if file summary entry already exists... [{}]",suffix);		
	      
	      data.setPriority("500");
	      int pmtInfSeq = 0;
	      int trnsInPmtInfSeq = 0;
	      int reportedNbOfTrns = -1;
	      String sMsgID=null;
	      String sPmnInf=null;
	      String receivingInst=null;
	      String sPartyName=null;
	      String sPartyID=null;
	      String sCtrlSum=null;
	      String sInitiatingPartyCustCode=null;
	      String sFileDst = null;
	      String fileType = null;
	      String sBusinessFlowType = null;
	      boolean bFileSummaryEntryAlreadyExists = false;

	      
	      if(!data.isRebulk()){
				fileSummaryPs = m_daoDebulkingProcess
						.getFileSummaryInternalFileIdAndStatus(conn, data
								.getFile().getName(), new Timestamp(data
								.getFile().lastModified()));
	      } else {
				fileSummaryPs = m_daoDebulkingProcess
						.selectFileSummeryByInternalFileID(conn,
								data.getInternalFileID());
	      }
	      
    	  fileSummaryRs = fileSummaryPs.executeQuery();	      
    	  
    	  // File summary entry already exists.
	      if (fileSummaryRs.next()) {
	    	  
	      	logger.info("file summary entry already exists... [{}]",suffix);

	      	bFileSummaryEntryAlreadyExists = true;

	        data.setInternalFileID(fileSummaryRs.getString(1));
	        data.setStatus(fileSummaryRs.getString(2));
	        data.setPriority(fileSummaryRs.getString(3));
	        sMsgID = fileSummaryRs.getString(4);
	        reportedNbOfTrns = fileSummaryRs.getInt(5);
	        sPartyName= fileSummaryRs.getString(6);
	        sPartyID = fileSummaryRs.getString(7);

	        // ASAF: No need anymore for the logic of getting the initiating party cust code,
	        //       after a change done by Eli for the Chile demo, because in case of a new FILE_SUMMARY entry,
	        //       the new record will be already set with this value, (INITG_PTY_CUST_CODE column).
	        //sInitiatingPartyCustCode = BOLoadCustomer.getInitiatingPartyCustCode(sPartyName, sPartyID, office);
	        sInitiatingPartyCustCode = fileSummaryRs.getString(8);

	        data.setFileSummaryOffice(fileSummaryRs.getString(9));
	        sFileDst = fileSummaryRs.getString(10);
	        fileType = fileSummaryRs.getString(11);
	        
	        logger.info(
					TRACE_EXISTING_FILE_SUMMARY_ENTRY_DETAILS,
					new Object[]{data.getInternalFileID(), data.getStatus(),
					data.getPriority(), sMsgID, reportedNbOfTrns,
					sPartyName, sPartyID, sInitiatingPartyCustCode});
	      }
	      // No entry yet; creates new internal file id.
	      else
	      {
	      	logger.info("no file summary entry yet, creates new internal file ID... [{}]",suffix);
	        data.setInternalFileID(GlobalUtils.generateGUID());
	        logger.info(TRACE_NEW_FILE_SUMMARY_ENTRY_DETAILS,
					data.getInternalFileID());
	      }
	      XmlTransactionReaderBase reader = (XmlTransactionReaderBase) data.getReader();
	      reader.init();
	      
	      boolean isEmptyPayload = emptyBPReaderEnhancement(data.getFile().getName(), reader);
	      
	      // New entry for this file or entry which was terminated abnormally.
	      // No status yet; creates new file summary entry.
	      if (!IN_DISTRIBUTION.equals(data.getStatus())) {
	        	if (data.getStatus() == null || data.isRebulk()){
	        		data.setStatus(IN_DISTRIBUTION);
	        	} else {
	        		data.setStatus(STATUS_FILE_DUPLICATE);
	        		logger.info("duplicate file summary entry , creates new internal file ID... [{}]",suffix);
	        		data.setInternalFileID(GlobalUtils.generateGUID());
	        	}
	        	
	        	logger.info("no status yet, (no file summary entry); gets information from input XML file... [{}]",suffix);

	        	
	        	
	        	if (fileType == null)
	        	{
	            	 fileType = reader.getFileType();
	            }
	        	
	        	sBusinessFlowType = InterfaceSubTypeFlow.getFlowType(fileType);
	        	boolean isBPFlow = GlobalConstants.BP.equals(sBusinessFlowType);
	        	PDO pdo=null;
	        	
	        	if (!isBPFlow)
	        	{
	        		String bulkType=reader.getBulkType();
	        		pdo= PaymentDataFactory.newPDO(PaymentType.valueOf(bulkType), true/*bTransient*/, true/*bPrimary*/, false/*conjoined orig & current mode*/, null/*sCreationMID*/, isBPFlow);
	        	}
	        	else 
	        	{
	        		pdo = PaymentDataFactory.newPDO(PaymentType.valueOf(PaymentType.PT_PACS_008), true/*bTransient*/, true/*bPrimary*/, false/*conjoined orig & current mode*/, null/*sCreationMID*/, isBPFlow);
	        		if(isEmptyPayload)
	        		{
	        			pdo.set(PDOConstantFieldsInterface.D_FILE_MISSING_PAYLOAD, true);
	        		}
	        	}

	            pdo.setThinMode(true);
	            
	            pdo.setMID(data.getInternalFileID());
	            pdo.set(PDOConstantFieldsInterface.P_MID, data.getInternalFileID());

	            pdo.set(PDOConstantFieldsInterface.P_IN_INTERNAL_FILEID, data.getInternalFileID());
	            pdo.set(PDOConstantFieldsInterface.P_OFFICE, data.getFileSummaryOffice());
	            
	        	
	        	
	            // ASAF: Previously, we used to set the party ID.
	            //       Change done by Eli for the Chile demo: the PAIN file will include the cust code, and later
	            //       on, we'll derive the party ID using the CUSTOMRS.BASE_NO column of the CUSTOMRS record
	            //       that stands for the cust code.
	            //if (sPartyID == null) sPartyID=m.group(5);
	            

	          // In case this is a new file summary entry, initializes the office and the party ID according to the
	          // initiating party cust code.
	          if(!bFileSummaryEntryAlreadyExists) {
		        	if (sInitiatingPartyCustCode == null) 
		        		sInitiatingPartyCustCode = reader.getInitiatingPartyCustCode();
		        	  
		        	data.setFileSummaryOffice(reader.getOffice());

		        	if (data.getFileSummaryOffice() == null) {
		        		if (!StringUtils.isEmpty(sInitiatingPartyCustCode)) {
				            // Loads CUSTOMRS cache entry for above cust code.
				            Customrs customrs = CacheKeys.customrsCCKey.getSingle(sInitiatingPartyCustCode);
				            if(customrs != null) {
				            	// Sets the future FILE_SUMARY.OFFICE to be the customer's office.
				            	data.setFileSummaryOffice(customrs.getOffice());
		
				            	sPartyID = customrs.getBaseNo();
				            } else {
				            	logger.info("ERROR: No CUSTOMRS record was found for initiating party cust code: '" 
				                				+"'; related FILE_SUMMARY status will be set to 'FileNotValidInitgPty' and office will be set to '***'. [{}]",sInitiatingPartyCustCode,suffix);
		
				            	// Sets the future FILE_SUMARY.OFFICE to be the default office; status will be set to 'FileNotValidInitgPty'
				            	// and when the user will fix it in the GUI, the correct office will be set as well.
				            	data.setFileSummaryOffice(ServerConstants.DEFAULT_SERVER_OFFICE_NAME);
				            }
		        		} else {
		        			logger.debug("there is no Initiating Party on the file, derive office using setBasicProperties");
		        			data.setSkipInitgPtyValidation(true);
		        			BOProxies.m_setBasicPropertiesLogging.setBasicProperties(Admin.getContextAdmin(), pdo.getMID());
		        			BOBaseProcess.executeMapPaymentInfoUsingRules(pdo.getMID(), RULE_TYPE_ID_DEPARTMENT, null);
		        			data.setFileSummaryOffice(pdo.getString("P_OFFICE"));
		        			data.setFileSummaryDepartment(pdo.getString("P_DEPARTMENT"));
		        		}
		        	}
	          }

	          // Multiple transcations.
	          logger.info("multiple transactions process; calls 'BOLoadCustomer' for getting initiating party cust code... [{}]",suffix);

	          // ASAF: No need anymore for the logic of getting the initiating party cust code,
	          //       after a change done by Eli for the Chile demo.
	          //sInitiatingPartyCustCode = BOLoadCustomer.getInitiatingPartyCustCode(sPartyName, sPartyID, office);
	          logger.info("initiating party cust code: {} [{}]",sInitiatingPartyCustCode,suffix);

	          Date currentTime = NewASDateTimeUtils.getCurrentDateAndZoneByOffice(data.getFileSummaryOffice()).getDate();
	         
	          //init the reader to read its header parts, that might failed if header is invalid xml
	         // reader.init();
	          
        	  // Gets the info from the xml file.
              if (sMsgID == null) 
                sMsgID = reader.getMsgId();
            
              if (reportedNbOfTrns == -1)
                reportedNbOfTrns=reader.getTrnsCount();
            
              if (sCtrlSum == null) 
                sCtrlSum=reader.getCtrlSum();

             if (sPartyName == null) 
            	sPartyName=reader.getPartyName();
             
             if (sPmnInf == null) 
                 sPmnInf = reader.getPmtInfId();
             
             if (receivingInst == null){
            	 receivingInst = reader.getReceivingInst();
             }
             
             if (fileType == null)
             {
            	 fileType = reader.getFileType();
            	 sBusinessFlowType = InterfaceSubTypeFlow.getFlowType(fileType);
             }
             
	          logger.info("creates new file summary entry... [{}]",suffix);
	          FileSummary fileSummary = new FileSummary(data.getFile().getName(), "I",
	        		  	data.getFile().length(), reader.getSendingInst(), reader.getFileReference(), currentTime, reportedNbOfTrns,
	        		  	receivingInst, sInitiatingPartyCustCode, sPartyName, sPartyID,
						data.getFileSummaryOffice(),data.getFileSummaryDepartment(), reader.getWorkflow(),reader.getFileSource()
						,reader.getNumCTBlk(),reader.getNumDDBlk(),reader.getSenderName());
	          
	          fileSummary.setPlFileType(fileType);
	          
	          pdo.set(PDOConstantFieldsInterface.X_MSG_ID, sMsgID); //allow duplicate check over this field
	          pdo.set(PDOConstantFieldsInterface.X_TX_ID, sPmnInf); //allow duplicate check over this field-only deut bank
	          
			  pdo.set(P_BUSINESS_FLOW_TP, sBusinessFlowType);		//First assignment for cases of DUPLICATE_FILE, None Duplicate cases will get reassigned in BoDebulkingProcess  - Defect #53470
	          
	          pdo.setIncomingFileSummary(fileSummary);
	          
	          setFilePriority(data, suffix, pdo);

	          // Validates the file prior to FILE_SUMMARY entry creation, (duplicate validation && initiating party cust code validation).	  
	          
        	  if((STATUS_FILE_DUPLICATE.equals(data.getStatus())|| STATUS_FILE_POSSIBLE_DUPLICATE.equals(data.getStatus())) && data.isSkipDuplicateValidation()){
        		  data.setValidationsStatus(data.getStatus());
        	  } else {
        		  String validateFileStatus = validateFile(data, conn,sMsgID, sPartyName, sPartyID, sInitiatingPartyCustCode,suffix, pdo);
        		  data.setValidationsStatus(validateFileStatus);		        	    
        	  }
	        
	          defineStatusByIndex(data);

	        }//if (!IN_DISTRIBUTION.equals(sStatus))

	        // Status exists; gets the pmt and trns sequence from file_process_distribution.
	        else
	        {
	        	logger.info("status exists, (file summary file entry exists); gets TO_PMTINF_SEQ & TO_TRNINF_SEQ from FILE_PROCESS_DISTRIBUTION... [{}]",suffix);

	          fileProcessDistributionPs = m_daoDebulkingProcess.getFileProcessDistributionPmtAndTrnsSeq(conn,data.getInternalFileID());
	          fileProcessDistributionRs = fileProcessDistributionPs.executeQuery();

	          if (fileProcessDistributionRs.next())
	          {
	            pmtInfSeq = fileProcessDistributionRs.getInt(1);
	            trnsInPmtInfSeq = fileProcessDistributionRs.getInt(2);
	            logger.info(TRACE_FILE_PROCESS_DISTRIBUTION_TO_PMTINF_SEQ_AND_TO_TRNINF_SEQ, pmtInfSeq, trnsInPmtInfSeq);

	            // skip to next processed payment info.
	            //if(pmtInfSeq > 0 && trnsInPmtInfSeq > 0) reader.goTo(pmtInfSeq, trnsInPmtInfSeq);
	          }
	        }
	  }catch(Throwable t)
	  {
		  ExceptionController.getInstance().handleException(t, this);
		  shouldCommit = false; 
		  int iSessionId= m_daoBasicProfileHandle.getSessionId();
		  String internalFileId=data.getInternalFileID();
          m_daoBasicProfileHandle.addInterfaceErrorLog("SYSTEM", iSessionId, "Feeder", "ERROR","Error parsing Header File for internalIdFile: "+internalFileId +" "+ t.getMessage() );
      	  throw new FlowException(t);
	  }finally
	  {
		  DAODebulkingProcess.releaseResources(conn,fileSummaryPs,fileSummaryRs,fileProcessDistributionPs,fileProcessDistributionRs);
	  }

	  return feedback;

  }//EOM handleFileSummaryPartByIndex

/**
 * CR64443 (134) IRD/ORD files will be supported and saved to File_summary table even if it only contains an AppHdr
 * 				 So we need to assign some missing private members of the reader to support this enhancement
 * CR "Handling Return BP Files without Payload" - adding support for IWD files
 * @param fileName
 * @param reader 
 */
  private boolean emptyBPReaderEnhancement(String fileName, XmlTransactionReaderBase reader) {
	String fileReference = null;
	boolean isEmptyPayload = false;
	if(reader.getFileType() == null && reader.getFileReference() == null)
	{
		String bizMsgIdr = reader.getAppHdrBizMsgIdr();
		boolean validEmptyFileReference = (fileReference = BeanIOUtils.extractFileReference(fileName)) != null;
		
		if(validEmptyFileReference)
		{
			String newFileType = fileReference.substring(3, 6);
			if(emptyFileSupportList.contains(newFileType))
			{
				logger.info(String.format("Recieved a supported empty file (%s) with fileType = %s", fileName, newFileType));
				String msgId = !GlobalUtils.isNullOrEmpty(bizMsgIdr) ? bizMsgIdr : fileReference;
				reader.setM_fileType(newFileType);
				reader.setFileReference(fileReference);
				reader.setMsgId(msgId);
				isEmptyPayload = true;
			}
			else
			{
				logger.info(String.format("The Recieved file (%s) is Not a supported empty file (fileType = %s)", fileName, newFileType));
			}
		}
		else
		{
			logger.error(String.format("The Recieved file (%s) is Not a Business Layer supported empty file", fileName));
		}
	}
	
	return isEmptyPayload;
}

/**
 * @param data
 * @param startPrefix
 * @param pdo
 * @throws Exception
 */
private void setFilePriority(DebulkFileByIndexData data, String suffix,PDO pdo) throws Exception {
	logger.info("executes file priority rule, (rule type ID 147) [{}]",suffix);
	  
	  List<RuleResult> resultList = BOProxies.m_internalRuleExecutionLogging
											.executeRule(Admin.getContextAdmin(),
													RULE_TYPE_ID_FILE_PRIORITY, null, pdo.getMID(),
													new String[] { data.getFileSummaryOffice() })
													.getResults();
	  
	  if(resultList.size() > 0) {
		  data.setPriority(resultList.get(0).getAction());
	  }
	  logger.info("priority: {} [{}]", data.getPriority(),suffix);
}


  /**
   * handleOneTransactionByIndex
   *
   *
   * @author dmitryp
   *
  */
  private void handleOneTransactionByIndex(XmlTransactionReaderBase reader, String startPrefix,  SimpleResponseDataComponent response) throws Exception
  {
	  /*
    	logger.info(startPrefix + "single transaction; calls high value process...");

    	StringBuilder message = new StringBuilder();
      	//getChuck(reader, message, 1, new String[1]);
    	Feedback singleTransFeedback =
    		BOProxies.m_businessFlowSelectorLogging.executeBusinessFlow(Admin.getContextAdmin(), message.toString(), reader.getInMsgContext(), null);
      	logger.info(startPrefix + "finished single transaction high value process");
      	if(!singleTransFeedback.isSuccessful()) logger.info(ServerUtils.getFeedbackString(singleTransFeedback));

        response.setFeedback(singleTransFeedback);

       */

  }//EOM handleOneTransactionByIndex


  /**
   * defineStatusByIndex
   *
   *
   * @author dmitryp
   *
  */
//  private Feedback defineStatusByIndex(String[] sStatus, String[] sValidationsStatus, String[] sFileSummaryOffice, String[] internalFileId, String startPrefix, XmlTransactionReaderBase reader)
  private Feedback defineStatusByIndex(DebulkFileByIndexData data) throws FlowException {
	  logger.debug("defineStatusByIndex, data {}",data);
	  Connection conn = null;
      PreparedStatement fileProcessDistributionPs = null;
	  Feedback feedback = new Feedback();
	  boolean shouldCommit = true;
	  final UserTransaction[] arrTxHolder = new UserTransaction[1] ;

	  try
	  {
		  feedback = BOBasic.startTransaction(arrTxHolder) ;
	      if(!feedback.isSuccessful()) throw new Exception(feedback.toString()) ;
	      
	      conn = m_daoDebulkingProcess.getConnection();
	      PDO pdo = Admin.getContextPDO();
	      
	      XmlTransactionReaderBase reader = (XmlTransactionReaderBase) data.getReader();
	      
	      if(!STATUS_FILE_DUPLICATE.equals(data.getStatus()) && !STATUS_FILE_POSSIBLE_DUPLICATE.equals(data.getStatus()))
	      {
				pdo.set(PDOConstantFieldsInterface.P_ORG_INITG_PTY_CUST_CD, reader .getInitiatingPartyCustCode());
				
				String oldStatus = data.isRebulk() ? STATUS_FILE_DISTRIBUTED : STATUS_FILE_RECIEVED;
		        
				// Passed validations successfully.
		        if (reader.isSinglePayment())
		        {
		        	data.setStatus(STATUS_FILE_DISTRIBUTED);
		        }
		        else if(data.getValidationsStatus() == null)
		        {
		        	logger.info(data.getStartPrefix() + "executes incoming file filter rule, (rule type ID 141)");
		        	
		        	String[] arrObjectIDs = new String[] { data.getFileSummaryOffice(), ServerConstants.DEFAULT_SERVER_OFFICE_NAME };
		        	
		        	//F_FILE_STATUS update moved to this stage for it to be used in upcoming INCOMING_FILE_FILTER rule.
		  	      	pdo.set(PDOConstantFieldsInterface.F_FILE_STATUS, data.getValidationsStatus());
		  	      	
					RuleResults ruleResults = BOProxies.m_internalRuleExecutionLogging
															.executeRule(
																	Admin.getContextAdmin(),
																	RULE_TYPE_ID_INCOMING_FILE_FILTER,
																	null,
																	pdo.getMID(),
																	arrObjectIDs);

					List<RuleResult> resultList = ruleResults.getResults();

					//String oldStatus = data.getStatus();
					if(resultList.size() > 0){
						
		        		data.setStatus(resultList.get(0).getAction());
		        		
						String usage = resultList.get(0).getSecAction();
						if (!GlobalUtils.isNullOrEmpty(usage)){
							ProcessError usageProcessError = new ProcessError(Integer.parseInt(usage)
								,new Object[]{});		    
							ErrorAuditUtils.setErrors(usageProcessError);
						}
					} else {
						data.setStatus(STATUS_FILE_DISTRIBUTED);
					}

					logger.info("{} status after rule execution: {}", data.getStartPrefix(),data.getStatus());
					
		        }else if (STATUS_FILE_POSSIBLE_DUPLICATE.equals(data.getValidationsStatus())){

		        	logger.info(data.getStartPrefix() + "executes incoming file filter rule, (rule type ID 141)");
		        	
		        	fsHandler.fileStatusAudit(STATUS_FILE_POSSIBLE_DUPLICATE /* New File Status */, 
							oldStatus /* Old File Status */, data.getInternalFileID() /* internal file id*/);
					
		        	oldStatus = STATUS_FILE_POSSIBLE_DUPLICATE;

		        	String[] arrObjectIDs = new String[] { data.getFileSummaryOffice(), ServerConstants.DEFAULT_SERVER_OFFICE_NAME };
		        	
		        	//F_FILE_STATUS update moved to this stage for it to be used in upcoming INCOMING_FILE_FILTER rule.
		  	      	pdo.set(PDOConstantFieldsInterface.F_FILE_STATUS, data.getValidationsStatus());
		  	      	
		        	RuleResults ruleResults = BOProxies.m_internalRuleExecutionLogging
		        			.executeRule(
		        					Admin.getContextAdmin(),
		        					RULE_TYPE_ID_INCOMING_FILE_FILTER,
		        					null,
		        					pdo.getMID(),
		        					arrObjectIDs);

		        	List<RuleResult> resultList = ruleResults.getResults();

		        	if(resultList.size() > 0){
		        		
		        		data.setStatus(resultList.get(0).getAction());
		        		
						String usage = resultList.get(0).getSecAction();
						if (!GlobalUtils.isNullOrEmpty(usage) 
								&& !usage.equals("0"))					//prules.SEC_RULE_ACTION_UID default value is assigned with 0, but should be ignored as there is no error code with '0'
						{
							ProcessError usageProcessError = new ProcessError(Integer.parseInt(usage)
								,new Object[]{});		    
							ErrorAuditUtils.setErrors(usageProcessError);
						}
		        	}else{
		        		data.setStatus(data.getValidationsStatus());
		        	}

		        	logger.info("{} status after rule execution: {}", data.getStartPrefix(),data.getStatus());

		        }
		        // Failed validations.
		        else
		        {
		        	data.setStatus(data.getValidationsStatus());
		        }

		        //For DEV - At this stage the file_summary entry isn't ready yet
		        //But we still need to audit the status change from FileRecieved to FileDistributed/FileRejected
		        fsHandler.fileStatusAudit(data.getStatus() /* New File Status */, 
						oldStatus /* Old File Status */, data.getInternalFileID() /* internal file id*/);
		        
		        pdo.set(PDOConstantFieldsInterface.F_FILE_STATUS, data.getStatus());
	      }
	  }catch(Throwable e)
	  {
		  ExceptionController.getInstance().handleException(e, this);
		  shouldCommit = false;
		  throw new FlowException(e);
	  }finally
	  {
		  feedback = BOBasic.endTransaction(arrTxHolder[0], shouldCommit)  ;
		  DAODebulkingProcess.releaseResources(conn, fileProcessDistributionPs);
	  }
	  return feedback;

  }//EOM defineStatusByIndex


  //****************************End Using new XmlTransactionReader By Index - Iterator*********************************


  public void createChunksForRejectedFile(String internalFileId) throws Throwable{
	  createChunksForRejectedFile(internalFileId,null);
  }
  
  public void createRejectedChunks(String chunkIDList,String internalFileId) throws Throwable{

	  final String insertString = "insert into file_process_distribution ( INTERNAL_FILE_ID,  CHUNK_ID,  OBJ_INSTANCE,  STATUS,  START_OFFSET,  END_OFFSET,  REC_COUNT,  BATCH_ID,  LAST_MID" +
			  ",  METHOD,  BULK_MSG_ID, TRANS_NO_START_FROM,  FROM_PMTINF_SEQ,  FROM_PMTINFID,  FROM_TRNINF_SEQ,  FROM_PMTID,  TO_PMTINF_SEQ,  TO_PMTINFID,  TO_TRNINF_SEQ" +
			  ",  TO_PMTID, UID_FILE_PROCESS_DISTRIBUTION, OFFICE, DEPARTMENT, PRIORITY, EFFECTIVE_DATE, REC_STATUS, PROFILE_CHANGE_STATUS, PENDING_ACTION, TIME_STAMP) "+
			  " values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, 'AC', 'NO', 'CR', "+
			  DAOBasic.ms_DBType.getToCharFormat(DAOBasic.ms_DBType.getCurrentTimestampKeyword(),DAOBasic.SQL_FORMAT_TIME_STAMP) + ")";

	  Connection conn = null;
	  PreparedStatement chunkPs = null;
	  try{
		  conn = m_daoDebulkingProcess.getConnection();
		  chunkPs = conn.prepareStatement(insertString);

		  FileSummary fileSummary = m_daoDebulkingProcess.getFileSummary(internalFileId);
		  
		  if(fileSummary == null){
			  logger.error("Error occur while retrieving file summary record for internal file ID {}",internalFileId);
			  return;
		  }
		  
		  String priority = (fileSummary.getPriority() != null) ? fileSummary.getPriority().toString() : "";

		  List<OutFileBuffers> outChunks;
		  
		  outChunks = m_daoDebulkingProcess.getOutChunksByFileIDAndChunkList(
					m_daoDebulkingProcess.getConnection(), internalFileId,chunkIDList);
		  
		  List<String> chunks = new ArrayList<String>();
		  int i=0;
		  for (OutFileBuffers outChunk : outChunks){
			  String chunkId=GlobalUtils.generateGUID();
			  PerformDebulkingAckRequsetDocument doc = PerformDebulkingAckRequsetDocument.Factory.newInstance();
			  PerformDebulkingAckRequsetType request = doc.addNewPerformDebulkingAckRequset();
			  request.setInternalFileID(internalFileId);
			  request.setOrgnlMsgId(fileSummary.getFileReference());
			  request.setOutChunkID(outChunk.getOutChunkId());
			  request.setInChunkID(chunkId);
			  request.setStatus(SubBatchProcessInterface.STATUS_FILE_DISTRIBUTED);
			  chunks.add(doc.toString());


			  m_daoDebulkingProcess.insertIntoFILE_PROCESS_DISTRIBUTION(chunkPs,internalFileId,chunkId,outChunk.getTotalMsgCountNb(), priority,
					  1,outChunk.getTotalMsgCountNb(),STATUS_FILE_DISTRIBUTED, fileSummary.getOffice(), fileSummary.getDepartment());

			  
			  i++;
			  if (i==500)
			  {
				  chunkPs.executeBatch();
				  DAODebulkingProcess.releaseResources(chunkPs);
				  chunkPs = conn.prepareStatement(insertString);

				  i=0;
			  }
		  }

		  chunkPs.executeBatch();

		  m_daoFileSummary.updateFileSummaryNumberOfChunks(internalFileId, chunks.size());
		  
		  transmitChunks(chunks, InterfaceTypes.INTERFACE_SUB_TYPE_DEB_ACK, priority, fileSummary.getOffice());
	  }catch(Throwable e)
	  {
		  throw new FlowException(e);
	  }finally
	  {
		  DAODebulkingProcess.releaseResources(conn, chunkPs);
	  }

  }
  
  public void createChunksForRejectedFile(String internalFileId,String bulkType) throws Throwable{

	  final String insertString = "insert into file_process_distribution ( INTERNAL_FILE_ID,  CHUNK_ID,  OBJ_INSTANCE,  STATUS,  START_OFFSET,  END_OFFSET,  REC_COUNT,  BATCH_ID,  LAST_MID" +
			  ",  METHOD,  BULK_MSG_ID, TRANS_NO_START_FROM,  FROM_PMTINF_SEQ,  FROM_PMTINFID,  FROM_TRNINF_SEQ,  FROM_PMTID,  TO_PMTINF_SEQ,  TO_PMTINFID,  TO_TRNINF_SEQ" +
			  ",  TO_PMTID, UID_FILE_PROCESS_DISTRIBUTION, OFFICE, DEPARTMENT, PRIORITY, EFFECTIVE_DATE, REC_STATUS, PROFILE_CHANGE_STATUS, PENDING_ACTION, TIME_STAMP) "+
			  " values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, 'AC', 'NO', 'CR', "+
			  DAOBasic.ms_DBType.getToCharFormat(DAOBasic.ms_DBType.getCurrentTimestampKeyword(),DAOBasic.SQL_FORMAT_TIME_STAMP) + ")";

	  Connection conn = null;
	  PreparedStatement chunkPs = null;
	  try{
		  conn = m_daoDebulkingProcess.getConnection();
		  chunkPs = conn.prepareStatement(insertString);

		  FileSummary fileSummary = m_daoDebulkingProcess.getFileSummary(internalFileId);
		  
		  if(fileSummary == null){
			  logger.error("Error occur while retrieving file summary record for internal file ID {}",internalFileId);
			  return;
		  }
		  String flowType = InterfaceSubTypeFlow.getFlowType(fileSummary.getPlFileType());
		  if(GlobalConstants.BP.equals(flowType) && GlobalUtils.isNullOrEmpty(bulkType))
		  {
			  bulkType = "ALL";
		  }
		  
		  String priority = (fileSummary.getPriority() != null) ? fileSummary.getPriority().toString() : "";

		  List<OutFileBuffers> outChunks;
		if (bulkType==null) {
			outChunks = m_daoDebulkingProcess.getOutChunksByOutFileID(
					m_daoDebulkingProcess.getConnection(), internalFileId);
		}else{
			outChunks = m_daoDebulkingProcess.getOutChunksByFileIDAndBulk(
					m_daoDebulkingProcess.getConnection(), internalFileId,bulkType);
		}
		  List<String> chunks = new ArrayList<String>();
		  int i=0;
		  for (OutFileBuffers outChunk : outChunks){
			  String chunkId=GlobalUtils.generateGUID();
			  PerformDebulkingAckRequsetDocument doc = PerformDebulkingAckRequsetDocument.Factory.newInstance();
			  PerformDebulkingAckRequsetType request = doc.addNewPerformDebulkingAckRequset();
			  request.setInternalFileID(internalFileId);
			  request.setOrgnlMsgId(fileSummary.getFileReference());
			  request.setOutChunkID(outChunk.getOutChunkId());
			  request.setInChunkID(chunkId);
			  request.setStatus(SubBatchProcessInterface.STATUS_FILE_DISTRIBUTED);
			  chunks.add(doc.toString());


			  m_daoDebulkingProcess.insertIntoFILE_PROCESS_DISTRIBUTION(chunkPs,internalFileId,chunkId,outChunk.getTotalMsgCountNb(), priority,
					  1,outChunk.getTotalMsgCountNb(),STATUS_FILE_DISTRIBUTED, fileSummary.getOffice(), fileSummary.getDepartment());

			  
			  i++;
			  if (i==500)
			  {
				  chunkPs.executeBatch();
				  DAODebulkingProcess.releaseResources(chunkPs);
				  chunkPs = conn.prepareStatement(insertString);

				  i=0;
			  }
		  }

		  chunkPs.executeBatch();

		  m_daoFileSummary.updateFileSummaryNumberOfChunks(internalFileId, chunks.size());
		  
		  transmitChunks(chunks, InterfaceTypes.INTERFACE_SUB_TYPE_DEB_ACK, priority, fileSummary.getOffice());
	  }catch(Throwable e)
	  {
		  throw new FlowException(e);
	  }finally
	  {
		  DAODebulkingProcess.releaseResources(conn, chunkPs);
	  }

  }

  /**
   * extract specific Exception from the Exception tree  
   */
  private Exception getCause(Throwable root, Class expecptionClass) {
	  if (root == null || expecptionClass == null)
		  return null;
	  
	  while (root != null && !expecptionClass.isAssignableFrom(root.getClass())) 
		  root = root.getCause();
	  
	  if (root != null && expecptionClass.isAssignableFrom(root.getClass()))
		  return (Exception)root;
	  
      return null;
  }



}//EOC BODebulkFile
