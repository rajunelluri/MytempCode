package backend.paymentprocess.debulkingprocess.dao;

import static backend.paymentprocess.SubBatchProcessInterface.STATUS_FILE_COMPLETED;
import static backend.paymentprocess.SubBatchProcessInterface.STATUS_FILE_SENT_PENDING_ACK;
import static backend.paymentprocess.SubBatchProcessInterface.STATUS_FILE_TIME_OUT;
import static com.fundtech.util.GlobalUtils.isNullOrEmpty;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectOutputStream;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.xmlbeans.XmlObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.dataaccess.dao.DAOBasic;
import backend.dataaccess.dto.CallableStatementParameter;
import backend.dataaccess.dto.DTODataHolder;
import backend.dataaccess.dto.DTOSingleValue;
import backend.paymentprocess.SubBatchProcessInterface;
import backend.paymentprocess.debulkingprocess.businessobjects.BODebulkingProcess.AmountHolder;
import backend.paymentprocess.debulkingprocess.businessobjects.BOMassPayment.StoreRequest;
import backend.paymentprocess.rebulking.dao.DAORebulkProcess;
import backend.staticdata.profilehandler.message.FILE_SUMMARYProfileHandler;
import backend.util.ServerConstants;

import com.fundtech.cache.entities.Banks;
import com.fundtech.cache.entities.BulkSummary;
import com.fundtech.cache.entities.FileSummary;
import com.fundtech.cache.entities.InterfaceTypes;
import com.fundtech.cache.entities.OutFileBuffers;
import com.fundtech.cache.entities.PreProcessAccumulations;
import com.fundtech.cache.infrastructure.CacheException;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.cache.infrastructure.regions.CacheKeys.ProcessPdoPerUniqueGroupIdKey.ProcessPdoPerGroupIdEntry;
import com.fundtech.core.general.StatementParameter;
import com.fundtech.core.general.flows.FlowException;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.core.paymentprocess.data.das.DASInterface.XmlLocationType;
import com.fundtech.core.paymentprocess.data.paymenttypes.PaymentType;
import com.fundtech.datacomponent.request.DebulkFileByIndexData;
import com.fundtech.datacomponent.response.layout.LayoutConstants;
import com.fundtech.util.ExceptionController;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalDateTimeUtil;
import com.fundtech.util.GlobalUtils;

public class DAODebulkingProcess extends DAOBasic
{

  private static final Logger logger = LoggerFactory.getLogger(DAODebulkingProcess.class);
  private static DAODebulkingProcess m_daoDebulkingProcess = new DAODebulkingProcess();
  private static DAORebulkProcess m_daoRebulkProcess = DAORebulkProcess.getInstance();
  private static Map<String, Integer>  chunksStatus;
  private static FILE_SUMMARYProfileHandler fsHandler = FILE_SUMMARYProfileHandler.getInstance();
  final static String FILE_STATUS_AND_AUDIT_UPDATE = "About to update and Audit Internal File Id: {} ,from status:{}, to Status:{}.";

  static
  {
    chunksStatus = new HashMap<String, Integer>();
    chunksStatus.put(SubBatchProcessInterface.STATUS_SUB_BATCH_NSF,1);
    chunksStatus.put(SubBatchProcessInterface.STATUS_SCHEDULE_SUB_BATCH,2);
    chunksStatus.put(SubBatchProcessInterface.STATUS_PAYMENTS_COMPLETED,3);
    chunksStatus.put(SubBatchProcessInterface.STATUS_SUB_BATCH_COMPLETED,4);
    chunksStatus.put(SubBatchProcessInterface.STATUS_PAYMENTS_FAILURE,5);
    chunksStatus.put(SubBatchProcessInterface.STATUS_SUB_BATCH_TIMEHOLD,6);
    chunksStatus.put(SubBatchProcessInterface.STATUS_SUB_BATCH_MP_WAIT,7);
    chunksStatus.put(SubBatchProcessInterface.STATUS_SUB_BATCH_WAIT_INDIVIDUAL,8);
    chunksStatus.put(SubBatchProcessInterface.STATUS_SUB_BATCH_REPAIR,9);
    chunksStatus.put(SubBatchProcessInterface.STATUS_FILE_REJECTED,10);
    chunksStatus.put(SubBatchProcessInterface.STATUS_READY_FOR_SUB_BATCH,11);
  }
  /**
   * Private constructor.
   */
  private DAODebulkingProcess()
  {
  }

  public static DAODebulkingProcess getInstance()
  {
    return m_daoDebulkingProcess;
  }
  //POC
  /**
   * Performs call to SP_GET_NEXT_CHUNK_Q stored procedure.
   */
  public DTODataHolder executeSP_CLOSE_INCOMING_FILE(String fileCurrentStatus, String processCurrentStatus, String fileNewStatus)
  {
	logger.debug("executeSP_CLOSE_INCOMING_FILE");
	
    final String SP_GET_NEXT_CHUNK_Q = "{call SP_CLOSE_INCOMING_FILE(?,?,?,?,?,?)}";


    final int P_FILE_CURRENT_STATUS  = 0;                // IN VARCHAR2, (as FILE_PROCESS_DISTRIBUTION.STATUS).
    final int P_PROCESS_CURRENT_STATUS  = 1;            // IN VARCHAR2
    final int P_FILE_NEW_STATUS  = 2;      				// IN VARCHAR2, (as FILE_PROCESS_DISTRIBUTION.INTERNAL_FILE_ID).
    final int P_CHANGED_INTERNAL_FILE_ID  = 3;              // OUT VARCHAR2, (as FILE_PROCESS_DISTRIBUTION.CHUNK_ID).
    final int P_SQLERR   = 4;              // OUT VARCHAR2, (as FILE_PROCESS_DISTRIBUTION.PRIORITY).
    final int INDEX_RETCODE = 5;               // OUT NUMBER - '0/1' value for success/failure.
    CallableStatementParameter[] arrParams = new CallableStatementParameter[6];
    // OUT parameters - all are VARCHAR type.
    for(int i=0; i<=2; i++)
    {
      arrParams[i] = new CallableStatementParameter();
    }
    //  Initializes all IN store procedures parameters.
    arrParams[P_FILE_CURRENT_STATUS].init(fileCurrentStatus, Types.VARCHAR);
    arrParams[P_PROCESS_CURRENT_STATUS].init(processCurrentStatus, Types.VARCHAR);
    arrParams[P_FILE_NEW_STATUS].init(fileNewStatus, Types.VARCHAR);
    for(int i=3; i<5; i++)
    {
      arrParams[i] = new CallableStatementParameter(CallableStatementParameter.OUTPUT_ONLY);
      arrParams[i].init(GlobalConstants.EMPTY_STRING, Types.VARCHAR);
    }
    // OUT parameter.
    // Special initailization for the RETCODE parameter.
    arrParams[INDEX_RETCODE] = new CallableStatementParameter(CallableStatementParameter.OUTPUT_RETURN_CODE);
    arrParams[INDEX_RETCODE].init(null, Types.NUMERIC);

    return executeCallableStatement(SP_GET_NEXT_CHUNK_Q, arrParams);
  }
  /**
   * Performs call to SP_GET_NEXT_CHUNK_Q stored procedure.
   */
  public DTODataHolder executeSP_GET_NEXT_CHUNK_Q(String sStatus, String sQueueName)
  {
	logger.debug("executeSP_GET_NEXT_CHUNK_Q");
	
    final String SP_GET_NEXT_CHUNK_Q = "{call SP_GET_NEXT_CHUNK_Q(?,?,?,?,?,?)}";

    final int INDEX_STATUS = 0;                // IN VARCHAR2, (as FILE_PROCESS_DISTRIBUTION.STATUS).
    final int INDEX_QUEUE_NAME = 1;            // IN VARCHAR2
    final int INDEX_INTERNAL_FILE_ID = 2;      // OUT VARCHAR2, (as FILE_PROCESS_DISTRIBUTION.INTERNAL_FILE_ID).
    final int INDEX_CHUNK_ID = 3;              // OUT VARCHAR2, (as FILE_PROCESS_DISTRIBUTION.CHUNK_ID).
    final int INDEX_PRIORITY = 4;              // OUT NUMBER, (as FILE_PROCESS_DISTRIBUTION.PRIORITY).
    final int INDEX_RETCODE = 5;               // OUT NUMBER - '0/1' value for success/failure.

    CallableStatementParameter[] arrParams = new CallableStatementParameter[6];

    // Params 0-1 are input; the default 'CallableStatementParameter' constructor
    // sets the parameter to be an input one.
    for(int i=0; i<=1; i++)
    {
      arrParams[i] = new CallableStatementParameter();
    }

    //  Initializes all IN store procedures parameters.
    arrParams[INDEX_STATUS].init(sStatus, Types.VARCHAR);
    arrParams[INDEX_QUEUE_NAME].init(sQueueName, Types.VARCHAR);

    // OUT parameters - all are VARCHAR type.
    for(int i=2; i<4; i++)
    {
      arrParams[i] = new CallableStatementParameter(CallableStatementParameter.OUTPUT_ONLY);
      arrParams[i].init(GlobalConstants.EMPTY_STRING, Types.VARCHAR);
    }

    // OUT parameter.
    // Priority
    arrParams[INDEX_PRIORITY] = new CallableStatementParameter(CallableStatementParameter.OUTPUT_ONLY);
    arrParams[INDEX_PRIORITY].init(GlobalConstants.EMPTY_STRING, Types.NUMERIC);

    // OUT parameter.
    // Special initailization for the RETCODE parameter.
    arrParams[INDEX_RETCODE] = new CallableStatementParameter(CallableStatementParameter.OUTPUT_RETURN_CODE);
    arrParams[INDEX_RETCODE].init(null, Types.NUMERIC);

    return executeCallableStatement(SP_GET_NEXT_CHUNK_Q, arrParams);
  }

  /**
   *
   */
  public PreparedStatement getSubFileXml(Connection conn, String internalFileId, String chunkId) throws Exception
  {
	logger.debug("getSubFileXml(file_process_distribution): internalFileId {}, chunkId {}",new String[]{internalFileId,chunkId});

    String query = "select file_process_distribution.sub_file_xml, file_process_distribution.priority, " +
						    	 "file_summary.office, file_summary.department " +
						    	 "from file_process_distribution, file_summary " +
						    	 "where file_process_distribution.internal_file_id = ? " +
						    	 "and file_process_distribution.chunk_id = ? " +
						    	 "and file_summary.internal_file_id = file_process_distribution.internal_file_id";

    PreparedStatement statement = conn.prepareStatement(query);

    com.fundtech.util.GlobalUtils.setObject(statement,1,internalFileId);
    com.fundtech.util.GlobalUtils.setObject(statement,2,chunkId);

    

    return statement;
  }
  
  
  /**
   * 
   * @param conn
   * @param internalFileId
   * @return
   * @throws SQLException
   */
  public PreparedStatement selectFileSummeryByInternalFileID(Connection conn, String internalFileId) throws SQLException{
	  logger.debug("selectFileSummeryByInternalFileID(internal_file_id), internalFileId {}",internalFileId);
	  
	  String query = "select internal_file_id, status, priority, file_reference, nb_of_txs, INITG_PTY_CUST_NAME, " + 
	  					"INITG_PTY_CUST_ID, INITG_PTY_CUST_CODE, OFFICE, FILE_DES, PL_FILE_TYPE from file_summary where internal_file_id = ?";
	  
	  PreparedStatement statement = conn.prepareStatement(query);
	  
	  com.fundtech.util.GlobalUtils.setObject(statement, 1,internalFileId);
	  
	  
	    
	  return statement;            
  }
  
  /**
   *
   */
  public PreparedStatement updateFileProcessDistributionStatus(Connection conn, String status, String internalFileId, String chunkId) throws Exception
  {
	logger.debug("updateFileProcessDistributionStatus(file_process_distribution): internalFileId {}, chunkId {}, status {}",new String[]{internalFileId,chunkId,status});

  	String query = "update file_process_distribution set status = ?, time_stamp = "+ms_DBType.getToCharFormat(ms_DBType.getCurrentTimestampKeyword(),DAOBasic.SQL_FORMAT_TIME_STAMP) +
		", queue_msg_id = null, queue_name = null where internal_file_id = ? ";

  	if (chunkId != null)
  	{
  		query = query+" and chunk_id = ?";
  	}
    PreparedStatement statement = conn.prepareStatement(query);

    com.fundtech.util.GlobalUtils.setObject(statement, 1,status);
    com.fundtech.util.GlobalUtils.setObject(statement, 2,internalFileId);
    if (chunkId != null) com.fundtech.util.GlobalUtils.setObject(statement, 3,chunkId);

    

    return statement;
  }

  /**
   *
   */
  public PreparedStatement updateFileProcessDistributionStatusAndAmounts(Connection conn, String status, String internalFileId, String chunkId, AmountHolder amounts) throws Exception
  {
	logger.debug("updateFileProcessDistributionStatusAndAmounts(file_process_distribution): internalFileId {}, chunkId {}, status {}, amounts {}",new Object[]{internalFileId,chunkId,status,amounts.toString()});

    String query = "update file_process_distribution set status = ?, total_stlmt_amt = nvl(total_stlmt_amt,0)+ ?, total_rjct_count =nvl(total_rjct_count,0)+ ?, " +
    		" total_rjct_stlmt_amt = nvl(total_rjct_stlmt_amt,0) + ?, total_repair_count =nvl(total_repair_count,0)+ ?, total_repair_stlmt_amt = nvl(total_repair_stlmt_amt,0) + ?, total_duplicate_count = nvl(total_duplicate_count,0) + ?, " +
    		"total_duplicate_stlmt_amt = nvl(total_duplicate_stlmt_amt,0) + ?, time_stamp = " + ms_DBType.getToCharFormat(ms_DBType.getCurrentTimestampKeyword(),DAOBasic.SQL_FORMAT_TIME_STAMP) +
                   ", queue_msg_id = null, queue_name = null where internal_file_id = ? and chunk_id = ?";

    PreparedStatement statement = conn.prepareStatement(query);
    com.fundtech.util.GlobalUtils.setObject(statement, 1,status);
    com.fundtech.util.GlobalUtils.setObject(statement, 2,amounts.getStlmAmt());
    com.fundtech.util.GlobalUtils.setObject(statement, 3,amounts.getRejectedCount());
    com.fundtech.util.GlobalUtils.setObject(statement, 4,amounts.getStlmAmtRejected());
    com.fundtech.util.GlobalUtils.setObject(statement, 5,amounts.getRepairCount());
    com.fundtech.util.GlobalUtils.setObject(statement, 6,amounts.getStlmAmtRepair());
    com.fundtech.util.GlobalUtils.setObject(statement, 7,amounts.getDuplicateCount());
    com.fundtech.util.GlobalUtils.setObject(statement, 8,amounts.getStlmAmtDuplicate());
    com.fundtech.util.GlobalUtils.setObject(statement, 9,internalFileId);
    com.fundtech.util.GlobalUtils.setObject(statement, 10,chunkId);

    return statement;
  }

   /**
   *
   */
  public int updateFileProcessDistributionStatusAndAmounts(Connection conn, String status, String internalFileId, String chunkId) throws Exception
  {
	logger.debug("updateFileProcessDistributionStatusAndAmounts(file_process_distribution): internalFileId {}, chunkId {}, status {}",new String[]{internalFileId,chunkId,status});
	  
  	int updateRows;

  	String query = "update file_process_distribution set status = ?, " +
    			   "time_stamp = " + ms_DBType.getToCharFormat(ms_DBType.getCurrentTimestampKeyword(),DAOBasic.SQL_FORMAT_TIME_STAMP) +
                   ", queue_msg_id = null, queue_name = null where internal_file_id = ? and chunk_id = ?";

    PreparedStatement updateFileProcessDistributionPs = conn.prepareStatement(query);
    com.fundtech.util.GlobalUtils.setObject(updateFileProcessDistributionPs, 1,status);
    com.fundtech.util.GlobalUtils.setObject(updateFileProcessDistributionPs, 2,internalFileId);
    com.fundtech.util.GlobalUtils.setObject(updateFileProcessDistributionPs, 3,chunkId);

    try
    {
    	updateRows = updateFileProcessDistributionPs.executeUpdate();
    }
    finally
	{
    	DAODebulkingProcess.releaseResources(conn, updateFileProcessDistributionPs);
	}

    


    return updateRows;
  }
  
  
  public PreparedStatement insertToFileInterfaceBuffers(Connection con,String internalFileId, String chunkId
		  , Map<String, StoreRequest> requestMap, String nextStep) throws Throwable{
	  logger.debug("insertToFileInterfaceBuffers(file_interface_buffers): internalFileId {}, chunkId {}, nextStep {}, requestMap {}",new Object[]{internalFileId,chunkId,nextStep,requestMap != null ? requestMap.toString() : ""});
	  
	  PreparedStatement ps=null;
	  String query = "insert into file_interface_buffers (IN_FILE_ID, CHUNK_ID, UNIQUE_GROUPING_ID, INTERFACE_NAME, INTERFACE_TYPE, INTERFACE_SUB_TYPE, STATUS, INTERFACE_FILE_BUFFER, PAYMENT, NEXT_STEP) " +
	  		"values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	  if (requestMap != null && requestMap.size() > 0){
		  Iterator<Entry<String, StoreRequest>> iter = requestMap.entrySet().iterator();
		  Entry<String, StoreRequest> entry=null;
		  InterfaceTypes interf=null;
		  String interfaceType=null;
		  String interfaceSubType=null;
		  String bulkInterfaceName=null;
		  ps = con.prepareStatement(query);
		  String[] keyArr;

		  while(iter.hasNext()){
			  entry = iter.next();
			  interfaceType=null;
			  interfaceSubType=null;
			  bulkInterfaceName=null;
			  keyArr = entry.getKey().split(GlobalConstants.AT_SIGN);
			  interf = CacheKeys.interfaceTypesNameKey.getSingle(keyArr[0]);
			  if (interf != null){
				  bulkInterfaceName = interf.getBulkInterfaceName();
				  interf = CacheKeys.interfaceTypesNameKey.getSingle(bulkInterfaceName);
				  if (interf != null){
					  interfaceType=interf.getInterfaceType();
					  interfaceSubType=interf.getInterfaceSubType();
				  }
			  }
			  int index=1;
			  PDO pdo = entry.getValue().payment;
			  XmlObject paymentXml = null;
			  if (pdo != null){
				  pdo.promoteToPrimary();
				  paymentXml = entry.getValue().payment != null ? PaymentDataFactory.transformToXml(entry.getValue().payment.getMID(),
						  PaymentType.valueOf("PERSISTENT_DATA"), XmlLocationType.XML_MSG, null,null) : null;
			  }

			  GlobalUtils.setObject(ps, index++, internalFileId, Types.VARCHAR);
			  GlobalUtils.setObject(ps, index++, chunkId, Types.VARCHAR);
			  GlobalUtils.setObject(ps, index++, keyArr.length > 3 ? keyArr[3] : null, Types.VARCHAR);
			  GlobalUtils.setObject(ps, index++, bulkInterfaceName, Types.VARCHAR);
			  GlobalUtils.setObject(ps, index++, interfaceType, Types.VARCHAR);
			  GlobalUtils.setObject(ps, index++, interfaceSubType, Types.VARCHAR);
			  GlobalUtils.setObject(ps, index++, "PENDING", Types.VARCHAR);
			  GlobalUtils.setObject(ps, index++, entry.getValue().request.toString());
			  GlobalUtils.setObject(ps, index++, paymentXml != null ? paymentXml.xmlText(): null);
			  GlobalUtils.setObject(ps, index++, nextStep);
			  ps.addBatch();
		}
	  }
	  return ps;
  }

  public int[] insertToFileValidationSubsetChunks(Connection conn,String internalFileId, String chunkId, int priority ,
		  Map<String, PreProcessAccumulations> accumulationsMap) throws Exception {
	  logger.debug("insertToFileInterfaceBuffers(file_interface_buffers): internalFileId {}, chunkId {}, priority {}, accumulationsMap {}",new Object[]{internalFileId,chunkId,""+priority,accumulationsMap != null ? accumulationsMap.toString() :""});

	  final String SPayment = "S";
	  final String APayment = "A";
	  int[] updateRows = null;
	  PreparedStatement insertToFileValidationSubSetPs= null;
	  String query = "INSERT INTO FILE_VALIDATION_SUBSET_CHUNKS (INTERNAL_FILE_ID,CHUNK_ID,UNIQUE_GROUPING_ID,BATCH_MSG_TP,CREDIT_CURRENCY,DEBIT_CURRENCY," +
	  		"TOTAL_PARTY_AMOUNT,TOTAL_MSG_COUNT_NB,STATUS,OFFICE,PARTY_ACCT_NB,DIRECT_DEBIT_TP,TOTAL_BASE_AM,INDIVIDUAL_MID,REC_STATUS,PROFILE_CHANGE_STATUS," +
	  		"EFFECTIVE_DATE,PENDING_ACTION,UID_FILE_SUBSET_CHUNKS,BASE_CURRENCY,PRIORITY,TOTAL_STTLM_AMOUNT,SUSPENSE_ACCT_UID,CUSTOMER_METHOD,MOP_METHOD,VALUE_DATE,PROCESS_DATE)" +
	  		"VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

	  if (accumulationsMap != null && accumulationsMap.size() > 0)
	  {
      	  insertToFileValidationSubSetPs = conn.prepareStatement(query);
      	  Iterator<String> iter = accumulationsMap.keySet().iterator();

     	  while(iter.hasNext()) {
      	  	   int indx = 1;

      	  	   String groupId = iter.next();
      	  	   PreProcessAccumulations acc = accumulationsMap.get(groupId);
      	  	   String batchMsgTp = groupId.startsWith("S_") ? SPayment : APayment ;

      	  	   String finalGroupId = groupId.substring(2);

      	  	   com.fundtech.util.GlobalUtils.setObject(insertToFileValidationSubSetPs, indx++,internalFileId);
      	  	   com.fundtech.util.GlobalUtils.setObject(insertToFileValidationSubSetPs, indx++,chunkId);
      	  	   com.fundtech.util.GlobalUtils.setObject(insertToFileValidationSubSetPs, indx++,finalGroupId);
      	  	   com.fundtech.util.GlobalUtils.setObject(insertToFileValidationSubSetPs, indx++,batchMsgTp);
		       com.fundtech.util.GlobalUtils.setObject(insertToFileValidationSubSetPs, indx++,acc.getCdtCcy());
        	   com.fundtech.util.GlobalUtils.setObject(insertToFileValidationSubSetPs, indx++,acc.getDbtCcy());
        	   com.fundtech.util.GlobalUtils.setObject(insertToFileValidationSubSetPs, indx++,acc.getPartyTotalAmt());
        	   com.fundtech.util.GlobalUtils.setObject(insertToFileValidationSubSetPs, indx++,acc.getMsgCount());
        	   com.fundtech.util.GlobalUtils.setObject(insertToFileValidationSubSetPs, indx++,acc.getStatus());
        	   com.fundtech.util.GlobalUtils.setObject(insertToFileValidationSubSetPs, indx++,acc.getOffice());
        	   com.fundtech.util.GlobalUtils.setObject(insertToFileValidationSubSetPs, indx++,acc.getPartyAccNo());
        	   com.fundtech.util.GlobalUtils.setObject(insertToFileValidationSubSetPs, indx++, acc.getDirectDebitType());  // DIRECT_DEBIT_TP
        	   com.fundtech.util.GlobalUtils.setObject(insertToFileValidationSubSetPs, indx++,acc.getBaseTotalAmt());
        	   com.fundtech.util.GlobalUtils.setObject(insertToFileValidationSubSetPs, indx++,acc.getMid());
        	   com.fundtech.util.GlobalUtils.setObject(insertToFileValidationSubSetPs, indx++, LayoutConstants.REC_STATUS_ACTIVE);        // REC_STATUS
       	 	   com.fundtech.util.GlobalUtils.setObject(insertToFileValidationSubSetPs, indx++, LayoutConstants.PROFILE_CHANGE_STATUS_NO); // PROFILE_CHANGE_STATUS
 			   com.fundtech.util.GlobalUtils.setObject(insertToFileValidationSubSetPs, indx++, new java.sql.Date(new Date().getTime()));  // EFFECTIVE_DATE
       	 	   com.fundtech.util.GlobalUtils.setObject(insertToFileValidationSubSetPs, indx++, LayoutConstants.PENDING_ACTION_CREATED);   // PENDING_ACTION
       	 	   com.fundtech.util.GlobalUtils.setObject(insertToFileValidationSubSetPs, indx++,internalFileId + GlobalConstants.POWER_SIGN+ finalGroupId + GlobalConstants.POWER_SIGN + chunkId);
       	 	   com.fundtech.util.GlobalUtils.setObject(insertToFileValidationSubSetPs, indx++,acc.getBaseCcy());
        	   com.fundtech.util.GlobalUtils.setObject(insertToFileValidationSubSetPs, indx++,priority);
			   com.fundtech.util.GlobalUtils.setObject(insertToFileValidationSubSetPs, indx++,acc.getSttlmTotalAmt());
               com.fundtech.util.GlobalUtils.setObject(insertToFileValidationSubSetPs, indx++, acc.getSuspenseAcctUid());  // SUSPENSE_ACCT_UID
			   com.fundtech.util.GlobalUtils.setObject(insertToFileValidationSubSetPs, indx++, acc.getCustomerMethod()); //Customer method
			   com.fundtech.util.GlobalUtils.setObject(insertToFileValidationSubSetPs, indx++, acc.getMopMethod()); //MOP method
			   com.fundtech.util.GlobalUtils.setObject(insertToFileValidationSubSetPs, indx++,acc.getValueDate());
        	   com.fundtech.util.GlobalUtils.setObject(insertToFileValidationSubSetPs, indx++,acc.getProcessDate());
      	       insertToFileValidationSubSetPs.addBatch();
      	  }
     	  
	      try
	   	  {
	   	  	  updateRows = insertToFileValidationSubSetPs.executeBatch();
	   	  }
	   	  finally
	   	  {
	   		DAODebulkingProcess.releaseResources(conn, insertToFileValidationSubSetPs);
	   	  }
	  }
	  

	  return updateRows;
  }



  private Set<String> getExistingGroupingPerChunk(Connection conn, String internalFileId, String chunkId) throws FlowException{
	  String query = "select unique_grouping_id from file_subset_chunks where internal_file_id = ? and chunk_id = ?";

	  PreparedStatement ps = null;
	  ResultSet rs = null;
	  Set<String> groupingIds = new HashSet<String>();
	  try{

		  ps = conn.prepareStatement(query);
		  GlobalUtils.setObject(ps, 1, internalFileId);
		  GlobalUtils.setObject(ps, 2, chunkId);
		  rs = ps.executeQuery();

		  while (rs.next()){
			  groupingIds.add(rs.getString(1));
		  }

	  }catch(Throwable t){
		  throw new FlowException(t);
	  }finally{
		  super.releaseResources(ps, rs);
	  }

	  return groupingIds;
  }

  private PreparedStatement insertToFileSubsetChunks(Connection conn, PreparedStatement statement, String internalFileId, String chunkId
		  , String groupId, PreProcessAccumulations acc, int priority, String bulkId) throws Throwable{
	  logger.debug("insertToFileSubsetChunks(FILE_SUBSET_CHUNKS): internalFileId {}, chunkId {}, priority {}, groupId {}",new Object[]{internalFileId,chunkId,""+priority,groupId});
	  
	  String query = "INSERT INTO FILE_SUBSET_CHUNKS (INTERNAL_FILE_ID, CHUNK_ID, UNIQUE_GROUPING_ID, TOTAL_PARTY_AMOUNT, TOTAL_STTLM_AMOUNT, INDIVIDUAL_MID, STATUS,CREDIT_CURRENCY, " +
	    		           "DEBIT_CURRENCY,TOTAL_MSG_COUNT_NB,OFFICE,PARTY_ACCT_NB,VALUE_DATE,PROCESS_DATE, TIME_STAMP, UID_FILE_SUBSET_CHUNKS,TOTAL_BASE_AM,BASE_CURRENCY,PRIORITY, " +
	    		           "REC_STATUS,PROFILE_CHANGE_STATUS,PENDING_ACTION,EFFECTIVE_DATE,SUSPENSE_ACCT_UID,DIRECT_DEBIT_TP, PAYMENT,VALUE_TIME,CHECKSUM_AMOUNT, BULK_ID,TOTAL_STTLM_NET_AMOUNT) " +
	    		           "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	  if (statement == null) statement = conn.prepareStatement(query);
	  int indx = 1;
	  String sTimeStamp = GlobalDateTimeUtil.getSimpleDateFormatByFormat(GlobalDateTimeUtil.STATIC_DATA_TIME_STAMP).format(new Date());
	  
	  com.fundtech.util.GlobalUtils.setObject(statement, indx++,internalFileId);
      com.fundtech.util.GlobalUtils.setObject(statement, indx++,chunkId);
      com.fundtech.util.GlobalUtils.setObject(statement, indx++,groupId);
      com.fundtech.util.GlobalUtils.setObject(statement, indx++,acc.getPartyTotalAmt());
      com.fundtech.util.GlobalUtils.setObject(statement, indx++,acc.getSttlmTotalAmt());
      com.fundtech.util.GlobalUtils.setObject(statement, indx++,acc.getMid());
      com.fundtech.util.GlobalUtils.setObject(statement, indx++,acc.getStatus());
      com.fundtech.util.GlobalUtils.setObject(statement, indx++,acc.getCdtCcy());
      com.fundtech.util.GlobalUtils.setObject(statement, indx++,acc.getDbtCcy());
      com.fundtech.util.GlobalUtils.setObject(statement, indx++,acc.getMsgCount());
      com.fundtech.util.GlobalUtils.setObject(statement, indx++,acc.getOffice());
      com.fundtech.util.GlobalUtils.setObject(statement, indx++,acc.getPartyAccNo());
      com.fundtech.util.GlobalUtils.setObject(statement, indx++,acc.getValueDate());
      com.fundtech.util.GlobalUtils.setObject(statement, indx++,acc.getProcessDate());
      com.fundtech.util.GlobalUtils.setObject(statement, indx++,sTimeStamp);
      com.fundtech.util.GlobalUtils.setObject(statement, indx++,internalFileId + GlobalConstants.POWER_SIGN+groupId + GlobalConstants.POWER_SIGN + chunkId);
      com.fundtech.util.GlobalUtils.setObject(statement, indx++,acc.getBaseTotalAmt());
      com.fundtech.util.GlobalUtils.setObject(statement, indx++,acc.getBaseCcy());
      com.fundtech.util.GlobalUtils.setObject(statement, indx++,priority);

      com.fundtech.util.GlobalUtils.setObject(statement, indx++, LayoutConstants.REC_STATUS_ACTIVE);        // REC_STATUS
      com.fundtech.util.GlobalUtils.setObject(statement, indx++, LayoutConstants.PROFILE_CHANGE_STATUS_NO); // PROFILE_CHANGE_STATUS
      com.fundtech.util.GlobalUtils.setObject(statement, indx++, LayoutConstants.PENDING_ACTION_CREATED);   // PENDING_ACTION
      com.fundtech.util.GlobalUtils.setObject(statement, indx++, new java.sql.Date(new Date().getTime()));  // EFFECTIVE_DATE
      com.fundtech.util.GlobalUtils.setObject(statement, indx++, acc.getSuspenseAcctUid());  // SUSPENSE_ACCT_UID
      com.fundtech.util.GlobalUtils.setObject(statement, indx++, acc.getDirectDebitType());  // DIRECT_DEBIT_TP
	  com.fundtech.util.GlobalUtils.setObject(statement, indx++, acc.getPayment() != null ? acc.getPayment().xmlText() : null);  
	  com.fundtech.util.GlobalUtils.setObject(statement, indx++, valueTimeAsString(acc.getValueTime()));
	  com.fundtech.util.GlobalUtils.setObject(statement, indx++, acc.getChecksumAmt());
	  com.fundtech.util.GlobalUtils.setObject(statement, indx++, bulkId);
	  com.fundtech.util.GlobalUtils.setObject(statement, indx++, acc.getSttlmTotalNetAmt());
	  
      statement.addBatch();
      return statement;
  }

  private String valueTimeAsString(Date valueTime) {	  
	  return valueTime == null ? null : new SimpleDateFormat("HH:mm:ss").format(valueTime);
  }

private PreparedStatement updateFileSubsetChunks(Connection conn, PreparedStatement statement, String internalFileId, String chunkId
		  , String groupId, PreProcessAccumulations acc) throws Exception{

	  logger.debug("updateFileSubsetChunks(FILE_SUBSET_CHUNKS): internalFileId {}, chunkId {}, groupId {}",new Object[]{internalFileId,chunkId,groupId});
	  
	  String query = "update FILE_SUBSET_CHUNKS set  TOTAL_PARTY_AMOUNT=TOTAL_PARTY_AMOUNT + ?, " +
			  				"TOTAL_STTLM_NET_AMOUNT=TOTAL_STTLM_NET_AMOUNT + ?, " +
	  						"TOTAL_STTLM_AMOUNT= TOTAL_STTLM_AMOUNT + ?" +
	  					", TOTAL_MSG_COUNT_NB = TOTAL_MSG_COUNT_NB + ?" +
	  					",TOTAL_BASE_AM = TOTAL_BASE_AM + ? " +
	  					",CHECKSUM_AMOUNT = CHECKSUM_AMOUNT + ? " +
	  					"WHERE INTERNAL_FILE_ID=? and CHUNK_ID=? and UNIQUE_GROUPING_ID=? ";

	  if (statement == null) statement = conn.prepareStatement(query);
	  int indx = 1;
      com.fundtech.util.GlobalUtils.setObject(statement, indx++,acc.getPartyTotalAmt());
      com.fundtech.util.GlobalUtils.setObject(statement, indx++,acc.getSttlmTotalNetAmt());
      com.fundtech.util.GlobalUtils.setObject(statement, indx++,acc.getSttlmTotalAmt());
      com.fundtech.util.GlobalUtils.setObject(statement, indx++,acc.getMsgCount());
      com.fundtech.util.GlobalUtils.setObject(statement, indx++,acc.getBaseTotalAmt());
      com.fundtech.util.GlobalUtils.setObject(statement, indx++,acc.getChecksumAmt());
	  com.fundtech.util.GlobalUtils.setObject(statement, indx++,internalFileId);
      com.fundtech.util.GlobalUtils.setObject(statement, indx++,chunkId);
      com.fundtech.util.GlobalUtils.setObject(statement, indx++,groupId);


      statement.addBatch();
      return statement;
  }

  public PreparedStatement[] insertOrUpdateToFileSubsetChunksAndUpdateProcessPdoCache(Connection conn, String internalFileId, String chunkId, int priority
		  , final Map mapSharedPDOContext, List<ProcessPdoPerGroupIdEntry> processPdoPerGroupIdEntryList
		  , Map<String, PreProcessAccumulations> accumulationsMap , Map<String, List<PDO>> paymentsForCahce, String bulkId) throws Throwable{
	  logger.debug("insertOrUpdateToFileSubsetChunksAndUpdateProcessPdoCache(processPdoPerUniqueGroupIdKey): internalFileId {}, chunkId {}, priority {}",new Object[]{internalFileId,chunkId,priority+""});
	  PreparedStatement[] psArr =new PreparedStatement[2];
	  Set<String> existingGroupIds = getExistingGroupingPerChunk(conn, internalFileId, chunkId);
	  if (accumulationsMap != null && accumulationsMap.size() > 0){

	      Iterator<String> iter = accumulationsMap.keySet().iterator();
	      while(iter.hasNext()){
	    	  String groupId = iter.next();
	    	  PreProcessAccumulations acc = accumulationsMap.get(groupId);
	    	  ProcessPdoPerGroupIdEntry processPdoPerGroup = null;
	    	  if (existingGroupIds.contains(groupId)) {
	    		  psArr[0] = updateFileSubsetChunks(conn, psArr[0], internalFileId, chunkId, groupId, acc);

	    		  try{
	    			  processPdoPerGroup = CacheKeys.processPdoPerUniqueGroupIdKey.getSingle(internalFileId, chunkId, groupId);
	    		  }catch(Exception e){
	    			  processPdoPerGroup = null;
	    		  }
	    		  if (processPdoPerGroup != null) 
	    			  processPdoPerGroup.addEntry(paymentsForCahce.get(groupId));
	    	  }else{
	    		  psArr[1] = insertToFileSubsetChunks(conn, psArr[1], internalFileId, chunkId, groupId, acc, priority, bulkId);
	    	  }
	    	  if (processPdoPerGroup == null ) 
	    		  processPdoPerGroup = new CacheKeys.ProcessPdoPerUniqueGroupIdKey.ProcessPdoPerGroupIdEntry(paymentsForCahce.get(groupId), mapSharedPDOContext);
	    	  CacheKeys.processPdoPerUniqueGroupIdKey.putSingle(processPdoPerGroup);

	    	  processPdoPerGroupIdEntryList.add(processPdoPerGroup);
	      }
	    }
	  return psArr;
  }


  /**
   *
   */
  public PreparedStatement insertToFileSubsetChunksAndUpdateProcessPdoCache(Connection conn, String internalFileId, String chunkId, int priority
		  , final Map mapSharedPDOContext, List<ProcessPdoPerGroupIdEntry> processPdoPerGroupIdEntryList, Map<String, PreProcessAccumulations> accumulationsMap
		  , Map<String, List<PDO>> paymentsForCahce, String bulkId) throws Throwable
  {
    logger.debug("insertToFileSubsetChunksAndUpdateProcessPdoCache(processPdoPerUniqueGroupIdKey): internalFileId {}, chunkId {}, priority {}",new Object[]{internalFileId,chunkId,priority+""});
  	//

    PreparedStatement statement= null;


    if (accumulationsMap != null && accumulationsMap.size() > 0)
    {
      Iterator<String> iter = accumulationsMap.keySet().iterator();

      while(iter.hasNext())
      {

        String groupId = iter.next();
        PreProcessAccumulations acc = accumulationsMap.get(groupId);
        statement = insertToFileSubsetChunks(conn, statement, internalFileId, chunkId, groupId,acc,priority, bulkId);
        logger.debug("After insertToFileSubsetChunks");
      }
    }
    if (paymentsForCahce != null && paymentsForCahce.size() > 0){
    	logger.debug("paymentsForCahce size is {}",paymentsForCahce.size());
    	Iterator<List<PDO>> iter =  paymentsForCahce.values().iterator();
    	while(iter.hasNext()){
            ProcessPdoPerGroupIdEntry processPdoPerGoupIdEntry = new CacheKeys.ProcessPdoPerUniqueGroupIdKey.ProcessPdoPerGroupIdEntry(iter.next(), mapSharedPDOContext);
            logger.debug("paymentsForCahce before put single to Cache");
            CacheKeys.processPdoPerUniqueGroupIdKey.putSingle(processPdoPerGoupIdEntry);
            logger.debug("paymentsForCahce after put single to Cache");
//            handleCacheEntryRemoval(processPdoPerGoupIdEntry, null);
            processPdoPerGroupIdEntryList.add(processPdoPerGoupIdEntry);
            logger.debug("paymentsForCahce Has next End");
    	}

    }


   // 

    return statement;
  }

  /**
   *
   */
  public void insertIntoFILE_PROCESS_DISTRIBUTION(PreparedStatement ps, String internalFileId,String chunkId, int recCount, String priority,
                                                  int pmtInfCount, int pmtInfTrnsCount, String sStatus, String sOffice, String sDepartment) throws Exception
  {
  	
	  logger.debug("insertIntoFILE_PROCESS_DISTRIBUTION: internalFileId {}, chunkId {}, recCount {},priority {}" +
	  		",sStatus {}",new Object[]{internalFileId,chunkId,recCount+"",priority+"",recCount});
	  
	  if (recCount > 0 )
	  {
      String INTERNAL_FILE_ID=internalFileId;
      String CHUNK_ID =chunkId;
      String OBJ_INSTANCE=" ";
      String STATUS=sStatus;
      int START_OFFSET=0;
      int END_OFFSET=0;
      int REC_COUNT=recCount;
      int BATCH_ID=0;
      String LAST_MID="0";
      String METHOD="";
      String BULK_MSG_ID="0";
      int TRANS_NO_START_FROM=0;
      int FROM_PMTINF_SEQ =0;
      String FROM_PMTINFID="0";
      int FROM_TRNINF_SEQ=0;
      String FROM_PMTID ="0";
      int TO_PMTINF_SEQ =pmtInfCount;
      String TO_PMTINFID="0";
      int TO_TRNINF_SEQ =pmtInfTrnsCount;
      String TO_PMTID ="0";

      int indx = 1;
      com.fundtech.util.GlobalUtils.setObject(ps, indx++,INTERNAL_FILE_ID);
      com.fundtech.util.GlobalUtils.setObject(ps, indx++,CHUNK_ID);
      com.fundtech.util.GlobalUtils.setObject(ps, indx++,OBJ_INSTANCE);
      com.fundtech.util.GlobalUtils.setObject(ps, indx++,STATUS);
      com.fundtech.util.GlobalUtils.setObject(ps, indx++,START_OFFSET);
      com.fundtech.util.GlobalUtils.setObject(ps, indx++,END_OFFSET);
      com.fundtech.util.GlobalUtils.setObject(ps, indx++,REC_COUNT);
      com.fundtech.util.GlobalUtils.setObject(ps, indx++,BATCH_ID);
      com.fundtech.util.GlobalUtils.setObject(ps, indx++,LAST_MID);
      com.fundtech.util.GlobalUtils.setObject(ps, indx++,METHOD);
      com.fundtech.util.GlobalUtils.setObject(ps, indx++,BULK_MSG_ID);
      com.fundtech.util.GlobalUtils.setObject(ps, indx++,TRANS_NO_START_FROM);
      com.fundtech.util.GlobalUtils.setObject(ps, indx++,FROM_PMTINF_SEQ);
      com.fundtech.util.GlobalUtils.setObject(ps, indx++,FROM_PMTINFID);
      com.fundtech.util.GlobalUtils.setObject(ps, indx++,FROM_TRNINF_SEQ);
      com.fundtech.util.GlobalUtils.setObject(ps, indx++,FROM_PMTID);
      com.fundtech.util.GlobalUtils.setObject(ps, indx++,TO_PMTINF_SEQ);
      com.fundtech.util.GlobalUtils.setObject(ps, indx++,TO_PMTINFID);
      com.fundtech.util.GlobalUtils.setObject(ps, indx++,TO_TRNINF_SEQ);
      com.fundtech.util.GlobalUtils.setObject(ps, indx++,TO_PMTID);
      com.fundtech.util.GlobalUtils.setObject(ps, indx++,CHUNK_ID);
//        InputStream is = new ByteArrayInputStream(segment.getBytes());
//            OutputStream outStream = new FileOutputStream("/opt/Data/Temp/segment"+CHUNK_ID+".xml");
//            ObjectOutputStream outPut = new ObjectOutputStream(outStream);
//
//            outPut.writeObject(segment);
//            outPut.flush();
//            outPut.close();
//      InputStream is = new ByteArrayInputStream(segment.getBytes());
//      super.ms_DBType.getXmlDao().bindXmlColumn(indx++,is,ps);
      com.fundtech.util.GlobalUtils.setObject(ps, indx++, sOffice);
      com.fundtech.util.GlobalUtils.setObject(ps, indx++, sDepartment);
      com.fundtech.util.GlobalUtils.setObject(ps, indx++,priority);
      com.fundtech.util.GlobalUtils.setObject(ps, indx++, new java.sql.Date(new Date().getTime()));
//      is.close();
//        InputStream is = new FileInputStream("c:/XMLInput/pain-002-load_1000.xml");
//        final XmlObjectBase o = (XmlObjectBase) XmlObject.Factory.parse(new File("c:/XMLInput/pain-002-load_1000.xml")) ;
//        final XMLType poXML = XMLType.createXML(ps.getConnection(), o.newInputStream()) ;
//
//
//        ps.setObject(1, poXML) ;

      

      ps.addBatch();
    }
  }

  /**
   *
   */
  /**
   *
   */
  public void createFileSummaryEntry(Connection conn,String office, String department, String internalFileId, String inputName, 
		  							 String path, long lastModified, Date appHdrCreDt,
                                     Long fileSize, String sendingInst, Timestamp currentTime, String status, String custCode,
                                     String custName, String custId, String priority, String ctrlSum, String fileReference,
                                     int nbOfTxs, String input, String workflow,String msgType, Integer numOfChunks, String bulkingProfileUid
                                     , String outGroupId, String direction, String finCopeService,Long maxCountNum, Long minCountNum, String mop
                                     ,String timeToSend,String lastCompletedMid, String mopGroup
                                     , Boolean isCreditLumpSum, String receivingIns, String testCode, String fileType,String fileDuplicateIndex, Date dateOfficeBusinessDate,
                                     Boolean ackIndicator,String relInternalFileID,String senderName,String fileSource,int nmCtBulk,int nmDDBulk,int calcNmCtBulk,int calcNmDDBulk
                                     ) throws SQLException  {

	  	logger.debug("createFileSummaryEntry(file_summary): internalFileId {}, path {}, status {}, priority {},workflow {}",new Object[]{internalFileId,path,status,priority+"",workflow});
	  	Connection localConnection = null;
  		

		/* LIRON CHANGE - this code was set to be run only if dateOfficeBusinessDate is null  */
		if (dateOfficeBusinessDate == null) {
			Banks banks = CacheKeys.banksKey.getSingle(office);
			if (banks == null)
				banks = CacheKeys.banksKey
						.getSingle(ServerConstants.DEFAULT_SERVER_OFFICE_NAME);
			dateOfficeBusinessDate = banks.getBsnessdate();
		}

		int  DELIVERY_NOTIF  =0;

		java.sql.Timestamp PL_CREATE_DATE = new Timestamp(appHdrCreDt != null ? appHdrCreDt.getTime() : lastModified);
		String ERROR_DESCRIPTION  ="";
		java.sql.Timestamp EFFECTIVE_DATE = currentTime;
		java.sql.Timestamp OUT_MSG_MIN_CREATE_DATE = currentTime;
		java.sql.Timestamp OUT_MSG_MAX_CREATE_DATE = currentTime;
		String UID_FILE_SUMMARY = internalFileId;

	  	String insertString = "insert into file_summary ( DEPARTMENT, INTERNAL_FILE_ID, FILE_NAME, DIRECTION, STATUS, TIME_STAMP," +
		  					          " FILE_SIZE, ACK_INDICATOR, DELIVERY_NOTIF," +
								          " SENDING_INST, PL_CREATE_DATE, FILE_DES," +
								          " LAST_CHECK_TIME_STAMP, REC_STATUS, PROFILE_CHANGE_STATUS, PENDING_ACTION, " +
								          "EFFECTIVE_DATE, ERROR_DESCRIPTION, OUT_MSG_MIN_CREATE_DATE, OUT_MSG_MAX_CREATE_DATE, " +
								          " OFFICE, UID_FILE_SUMMARY, INITG_PTY_CUST_CODE, INITG_PTY_CUST_NAME, INITG_PTY_CUST_ID,BSNESSDATE,PRIORITY,CTRL_SUM" +
								          ",FILE_REFERENCE,NB_OF_TXS,FILE_XML, WORKFLOW,MSG_TYPE, NUM_OF_PREPROCESSED_CHUNKS,NUM_OF_COMPLETED_CHUNKS,NUM_OF_CHUNKS,Bulking_Profile" +
								          ",Out_Group_Id,FinCopyService,Max_Count_Nb,Min_Count_Nb,MOP,Office_Time_To_Send,Last_Completed_Mid" +
								          ",SERVICE_IDENTIFIER,Credit_Lump_Sum,RECEIVING_INST,PROD_TEST_CODE,PL_FILE_TYPE," +
								          "F_FILE_DUPLICATE_INDEX,REL_INTERNAL_FILE_ID,SENDER_NAME,FILE_SOURCE,NUM_CT_BLK,NUM_DD_BLK,CALC_NUM_CT_BLK,CALC_NUM_DD_BLK)"+
								          "values (?,?,?,?,?,"+ms_DBType.getToCharFormat(ms_DBType.getCurrentTimestampKeyword(),DAOBasic.SQL_FORMAT_TIME_STAMP)+",?,?,?,?,?,?" +
		                      ","+ms_DBType.getToCharFormat(ms_DBType.getCurrentTimestampKeyword(),DAOBasic.SQL_FORMAT_TIME_STAMP)+",?,?,?,TRUNC(?),?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?," +
		                      		"?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement ps = null;

	    try
	    {
		  	  localConnection = conn==null ? super.getConnection() : conn;
        	  ps = localConnection.prepareStatement(insertString);
      		  int colNdx=1;
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,department);
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,internalFileId);
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,inputName);
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,direction);
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,status);
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,fileSize);
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,ackIndicator);
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,DELIVERY_NOTIF);
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,sendingInst );
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,PL_CREATE_DATE );
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,path );
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,LayoutConstants.REC_STATUS_ACTIVE);
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,LayoutConstants.PROFILE_CHANGE_STATUS_NO);  // PROFILE_CHANGE_STATUS
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,LayoutConstants.PENDING_ACTION_CREATED);    // PENDING_ACTION
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,EFFECTIVE_DATE );
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,ERROR_DESCRIPTION);
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,OUT_MSG_MIN_CREATE_DATE);
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,OUT_MSG_MAX_CREATE_DATE);
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,office);
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,UID_FILE_SUMMARY);
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,custCode);
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,custName);
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,custId);
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++, new java.sql.Date(dateOfficeBusinessDate.getTime())); // Business date.
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,priority);
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,ctrlSum);
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,fileReference);
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,nbOfTxs);
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,input);
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,workflow);
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,msgType);
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,0);
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,0);
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,numOfChunks);
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,bulkingProfileUid);
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,outGroupId);
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,finCopeService);
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,maxCountNum);
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,minCountNum);
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,mop);
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,timeToSend);
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,lastCompletedMid);
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,mopGroup);
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,isCreditLumpSum);
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,receivingIns);
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,testCode);
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,fileType);
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,fileDuplicateIndex);
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,relInternalFileID);
		      
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,senderName);
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,fileSource);
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,nmCtBulk);
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,nmDDBulk);
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,calcNmCtBulk);
		      com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,calcNmDDBulk);
		      
		      ps.executeUpdate();
	    }
    	catch(Exception e)
    	{
    		 throw new SQLException(e);
    	}
    	finally
    	{
    		releaseResources(ps);
    		if (conn==null) releaseResources(localConnection);
    	}
	    
  }
  
 
  /**
   * Insert to bulk summary table
   * @param conn
   * @param office
   * @param department
   * @param internalFileId
   * @param bulkId
   * @param numOfTx
   * @param ctrlSum
   * @param totalAmt
   * @throws SQLException
   */
  public void createBulkSummaryEntry(String office, String department, String internalFileId, String bulkId, long numOfTx, long ctrlSum,
		  BigDecimal totalAmt, String bulkType, String creDt) throws SQLException  {

	  logger.debug("createBulkSummaryEntry(bulk_summary): internalFileId {}",new Object[]{internalFileId});
	  Connection localConnection = null;

	  String insertString = "insert into bulk_summary (OFFICE, DEPARTMENT, INTERNAL_FILE_ID, BULK_ID, BLK_NB_OF_TXS, BLK_CTRL_SUM, BULK_TYPE, BLK_TTL_AMT, UID_BULK_SUMMARY, TIME_STAMP,ORIG_CRE_DT) "+
			  "values (?,?,?,?,?,?,?,?,?," +  ms_DBType.getToCharFormat(ms_DBType.getCurrentTimestampKeyword(),DAOBasic.SQL_FORMAT_TIME_STAMP)+ ",?)";
	  PreparedStatement ps = null;

	  try
	  {
		  localConnection = super.getConnection();
		  ps = localConnection.prepareStatement(insertString);
		  int colNdx=1;
		  com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,office);
		  com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,department);
		  com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,internalFileId);
		  com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,bulkId);
		  com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,numOfTx);
		  com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,ctrlSum);
		  com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,bulkType);
		  com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,totalAmt);
		  com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,internalFileId + GlobalConstants.POWER_SIGN + bulkId);
		  com.fundtech.util.GlobalUtils.setObject(ps, colNdx++,creDt);

		  ps.executeUpdate();
	  }
	  catch(Exception e)
	  {
		  throw new SQLException(e);
	  }
	  finally
	  {
		  releaseResources(ps);
		  releaseResources(localConnection);
	  }

  }

  public void updateOutGoingFileRelFileID (DebulkFileByIndexData data) throws SQLException{
	  
	  logger.debug("updateOutGoingFileRelFileID(file_summary): internalFileId {}, RelInternalFileID {}",new Object[]{data.getInternalFileID(),data.getRelInternalFileID()});
	  
	  String query = "UPDATE FILE_SUMMARY SET REL_INTERNAL_FILE_ID = ? WHERE INTERNAL_FILE_ID = ? ";

	  Connection con = null;
	  PreparedStatement ps = null;
	  try
	  {
		  con = super.getConnection();

		  ps = con.prepareStatement(query);

		  GlobalUtils.setObject(ps, 1, data.getInternalFileID());
		  GlobalUtils.setObject(ps, 2, data.getRelInternalFileID());

		  ps.executeUpdate();
		  
	  }finally
	  {
		  super.releaseResources(ps, con);
	  }

  }
  
  public String getProperFileSummaryStatus(Connection conn , String internalFileId ) throws SQLException {
	  
	  
	  
	  final String COLUMN_MSG_STS = "STATUS";
	  final String STARTING_STATUS = "tempStatus";
	  String query = "SELECT STATUS , COUNT(*) NUM_OF_CHUNKS FROM FILE_SUBSET_CHUNKS WHERE  INTERNAL_FILE_ID = ? GROUP BY STATUS";
	    
	  Connection localConn = null;
	  PreparedStatement ps= null;
	  ResultSet rs = null;
	  String status = STARTING_STATUS;
	  boolean shouldContinue = true;
    
	  try {
		  localConn = conn != null ? conn : super.getConnection();
     	  ps = localConn.prepareStatement(query);
		  ps.setObject(1,internalFileId);
		  rs = ps.executeQuery();
		  
		  while(rs.next() && shouldContinue) {
			 String tempStatus = rs.getString(COLUMN_MSG_STS);
			 switch(chunksStatus.get(tempStatus)) {
			 case 1:status = SubBatchProcessInterface.STATUS_SUB_BATCH_NSF;
				 	shouldContinue = false;
					break;
			 case 2:status = SubBatchProcessInterface.STATUS_SCHEDULE_SUB_BATCH;
				    break;
			 case 3:if (STARTING_STATUS.equals(status))
				 		status = SubBatchProcessInterface.STATUS_FILE_COMPLETED;
				 	break;
			 case 4:if (STARTING_STATUS.equals(status))
				 		status = SubBatchProcessInterface.STATUS_SUB_BATCHS_COMPLETED;
				 	break;
			 case 5:if (STARTING_STATUS.equals(status))
				 		status = SubBatchProcessInterface.STATUS_FILE_SUB_BATCH_FAILURE;
			 		break;
			 case 6:if (STARTING_STATUS.equals(status))
				 		status = SubBatchProcessInterface.STATUS_TIMEHOLD_SUB_BATCH;
			 		break;
			 case 7:if (STARTING_STATUS.equals(status))
				 		status = SubBatchProcessInterface.STATUS_SUB_BATCH_MP_WAIT;
			 		break;
			 case 8:if (STARTING_STATUS.equals(status))
				 		status = SubBatchProcessInterface.STATUS_SUB_BATCH_WAIT_INDIVIDUAL;
			 		break;
			 case 9:if (STARTING_STATUS.equals(status))
				 		status = SubBatchProcessInterface.STATUS_SUB_BATCH_REPAIR;
			 		break;
			 case 10:status = SubBatchProcessInterface.STATUS_FILE_REJECTED;
			 		shouldContinue = false;
			 		break;
			 default:if (STARTING_STATUS.equals(status))
				 	status = SubBatchProcessInterface.STATUS_FILE_COMPLETED;
				 	break;
			 }
		  }
		  //If no results Status should be File Rejected ( For example for all Reject from OFAC)
		  if (STARTING_STATUS.equals(status)) {
			  status = SubBatchProcessInterface.STATUS_FILE_COMPLETED;
		  }

	  }catch(Exception ex) {
        throw new SQLException(ex);
      }finally {
        super.releaseResources(conn == null ? localConn : null,  ps);
      }

	  
	  return status;
  }
  
  /**
   * 
   * @param conn
   * @param newFileStatus
   * @param internalFileID
   * @throws SQLException
   */
  public void updateFileSummaryStatusAndAudit(Connection conn, String newFileStatus, String internalFileID) throws SQLException
  {
	String oldFileStatus = null;
	
	try{
		DTOSingleValue dtoFileStatus = m_daoRebulkProcess.getFILE_SUMMARY_Status(internalFileID);
		oldFileStatus = dtoFileStatus.isFeedBackSuccess() ? dtoFileStatus.getValue() : null;
	}catch(Exception e){
		logger.error("unable to retrieve the current File Status of internal file id:{}",internalFileID);
		return ;
	}
	
	updateFileSummaryStatusAndAudit(conn, newFileStatus, oldFileStatus, internalFileID);
  }
  
  /**
   * 
   * @param conn
   * @param newFileStatus
   * @param fileSummary
   * @throws SQLException
   */
  public void updateFileSummaryStatusAndAudit(Connection conn, String newFileStatus, String oldFileStatus, String internalFileID) throws SQLException
  {
	logger.info(FILE_STATUS_AND_AUDIT_UPDATE, new Object[]{internalFileID, oldFileStatus, newFileStatus});
	
    int updatedCount = updateFileSummaryStatus(conn, newFileStatus, internalFileID);
    
    if(updatedCount > 0)
	    fsHandler.fileStatusAudit(newFileStatus, oldFileStatus, internalFileID);

  }
  
  /**
   * 
   * @param conn
   * @param newFileStatus
   * @param internalFileId
   * @return
   * @throws SQLException
   */
  private int updateFileSummaryStatus(Connection conn, String newFileStatus, String internalFileId) throws SQLException
  {
	  // For DEV - No File_summary status audit is needed as it will be done externally later.
	  logger.debug("updateFileSummaryStatus(file_summary): internalFileId {}, new File Status {}",
			  new Object[]{internalFileId,newFileStatus});  	

    PreparedStatement statement= null;
    Connection localConn = null;
    int updatedCount = 0;

    try
    {
      String query =  "update file_summary set status = ?, time_stamp = " + ms_DBType.getToCharFormat(ms_DBType.getCurrentTimestampKeyword(),DAOBasic.SQL_FORMAT_TIME_STAMP)
                     +" where internal_file_id = ? ";
      localConn = conn != null ? conn : super.getConnection();
      statement = localConn.prepareStatement(query);

      com.fundtech.util.GlobalUtils.setObject(statement, 1,newFileStatus);
      com.fundtech.util.GlobalUtils.setObject(statement, 2,internalFileId);

      updatedCount = statement.executeUpdate();
    }
    catch(Exception ex)
    {
        throw new SQLException(ex);
    }finally
    {
        super.releaseResources(conn == null ? localConn : null,  statement);
    }
    
    return updatedCount;
  }
  
  public void updateFileSummaryRelFileRef(Connection conn, String internalFileId, String relFileRef) throws SQLException
  {
	  logger.debug("updateFileSummaryStatus(file_summary): internalFileId {}, related file reference {}",new Object[]{internalFileId,relFileRef});  	

    PreparedStatement statement= null;
    Connection localConn = null;

    try
    {
      String query =  "update file_summary set rel_file_reference = ?, time_stamp = " + ms_DBType.getToCharFormat(ms_DBType.getCurrentTimestampKeyword(),DAOBasic.SQL_FORMAT_TIME_STAMP)
                     +" where internal_file_id = ? ";
      localConn = conn != null ? conn : super.getConnection();
      statement = localConn.prepareStatement(query);

      com.fundtech.util.GlobalUtils.setObject(statement, 1,relFileRef);
      com.fundtech.util.GlobalUtils.setObject(statement, 2,internalFileId);

      statement.executeUpdate();
    }
    catch(Exception ex)
    {
        throw new SQLException(ex);
    }finally
    {
        super.releaseResources(conn == null ? localConn : null,  statement);
    }

    
  }

  /**
   *
   */
  public boolean checkForDuplicates(Connection conn, String sFileID, String sInitiatingPartyCustCode,
                                    String sInitiatingPartyName, String sInitiatingPartyID) throws SQLException
  {
  	final StringBuilder sbQuery = new StringBuilder("select 1 from file_summary where file_reference = ? and direction = 'I' ");

    boolean bDuplicate = false;

    List<Object> paramsList = new ArrayList<Object>();
    paramsList.add(sFileID);
    PreparedStatement statement = null;
    ResultSet rs = null;

    try
    {
      if(!isNullOrEmpty(sInitiatingPartyCustCode))
      {
        sbQuery.append(" and initg_pty_cust_code = ?");
        paramsList.add(sInitiatingPartyCustCode);
      }
      else
      {
        if (!isNullOrEmpty(sInitiatingPartyName))
        {
          sbQuery.append(" and initg_pty_cust_name = ? ");
          paramsList.add(sInitiatingPartyName);
        }
        if (!isNullOrEmpty(sInitiatingPartyID))
        {
          sbQuery.append(" and initg_pty_cust_id = ? ");
          paramsList.add(sInitiatingPartyID);
        }
      }

      if(paramsList.size() > 1)
      {
        statement = conn.prepareStatement(sbQuery.toString());
        int counter = 1;
        for(Object param : paramsList)
        {
          com.fundtech.util.GlobalUtils.setObject(statement, counter++, param);
        }
        rs = statement.executeQuery();
        if(rs.next() && !bDuplicate)
        {
          bDuplicate = (rs.getInt(1)> 0);
        }
      }
    }
    catch(Exception e)
    {
      throw new SQLException(e);
    }
    finally
    {
      super.releaseResources(statement,rs);
    }

    

    logger.debug("checkForDuplicates(file_summary): sbQuery {},paramsList {} , duplicate: {}", new Object[]{sbQuery,paramsList, bDuplicate});

    return bDuplicate;
  }

  /**
   *
   */
  public PreparedStatement getFileSummaryInternalFileIdAndStatus(Connection conn, String fileName, Timestamp createDate) throws Exception
  {
  	

    PreparedStatement statement= null;

    String query = "select internal_file_id, status, priority, file_reference, nb_of_txs, INITG_PTY_CUST_NAME, " +
    		"INITG_PTY_CUST_ID, INITG_PTY_CUST_CODE, OFFICE ,FILE_DES, PL_FILE_TYPE from file_summary where file_name = ? and pl_create_date = ?";
    statement = conn.prepareStatement(query);

    statement.setObject(1,fileName);
    createDate.setNanos(0);
    statement.setObject(2,createDate);

    

    return statement;
  }

  /**
   *
   */
  public PreparedStatement getFileProcessDistributionPmtAndTrnsSeq(Connection conn, String internalFileId) throws Exception
  {
  	

    PreparedStatement statement= null;

    String query = "select to_pmtinf_seq, to_trninf_seq "+
                   "   from file_process_distribution "+
                   "  where internal_file_id = ? "+
                   "    and time_stamp = "+
                   "        (select max(time_stamp) "+
                   "           from file_process_distribution "+
                   "          where internal_file_id = ?) ";
    statement = conn.prepareStatement(query);

    statement.setObject(1,internalFileId);
    statement.setObject(2,internalFileId);

    

    return statement;
  }

  public FileSummary getFileSummary(String InternalFileID)
  {
	  
	  FileSummary fileSummary = null;
	  String SELECT_STATEMENT = "SELECT OFFICE,DEPARTMENT,INTERNAL_FILE_ID,FILE_NAME,DIRECTION,STATUS,TIME_STAMP,BULKING_PROFILE,SENDER_DN,RECEIVER_DN," +
                "SWIFT_ID,SWIFT_SERVICE,SENDER_ENDTOEND_ID,REQUEST_TYPE,PDM_FLAG,FILE_SIZE,ACK_INDICATOR,DELIVERY_NOTIF," +
                "FILE_INFO,SENDING_INST,RECEIVING_INST,FILE_REFERENCE,SERVICE_IDENTIFIER,PROD_TEST_CODE,NUM_CANS,NUM_RETS,NUM_REPAIR," +
                "FILE_REJECT_RSN,PL_CREATE_DATE,LAST_COMPLETED_MID,PAYMENT_COMPLETION_STATUS,FILE_DES,CREATED_OBJ_INSTANCE," +
                "LAST_CHECK_TIME_STAMP,OUT_GROUP_ID,MAX_COUNT_NB,MIN_COUNT_NB,FINCOPYSERVICE,PL_FILE_TYPE,MOP,OFFICE_TIME_TO_SEND," +
                "REL_FILE_REFERENCE,REL_FILE_NAME,PL_REL_TIME_STAMP,FILE_CYCLE_NR,ROUT_IND,SENT_TIME,REC_STATUS,PROFILE_CHANGE_STATUS," +
                "EFFECTIVE_DATE,PENDING_ACTION,LATEST_SEND_TIME_IND,A_OBJ_INSTANCE,A_LAST_MID,ERROR_DESCRIPTION,OUT_MSG_MIN_CREATE_DATE," +
                "OUT_MSG_MAX_CREATE_DATE," +
                "NUM_DD,NUM_REJS,NUM_REVS,NB_OF_TXS,CALC_NB_OF_TXS,CTRL_SUM,CALC_CTRL_SUM," +
                "UID_FILE_SUMMARY,CREDIT_LUMP_SUM,INITG_PTY_CUST_CODE,OVERRIDE_LIMIT_CHECK, " +
                "BSNESSDATE, TOTAL_BASE_AMT, INITG_PTY_CUST_NAME, INITG_PTY_CUST_ID, PRIORITY, QUEUE_NAME, QUEUE_MSG_ID,WORKFLOW," +
                "FILE_SOURCE,NUM_CT_BLK,NUM_DD_BLK,CALC_NUM_CT_BLK,CALC_NUM_DD_BLK,REL_INTERNAL_FILE_ID " + 
                "FROM FILE_SUMMARY WHERE INTERNAL_FILE_ID = ?";

		List<FileSummary> list = getDataRows(SELECT_STATEMENT, FileSummary.class, 0, new StatementParameter(InternalFileID,Types.VARCHAR));
		fileSummary = !list.isEmpty() ? list.get(0) : null;
		return fileSummary;
  }

  public int incNumOfProcessChunksInFileSummary(String internalFileId) throws Exception
  {
	  logger.debug("incNumOfProcessChunksInFileSummary(file_summary): internalFileId {}", new Object[]{internalFileId});
	  
	  String query = "update file_summary set num_of_preprocessed_chunks = num_of_preprocessed_chunks + 1 where internal_file_id=? and num_of_preprocessed_chunks + 1 < num_of_chunks";

	  Connection con = null;
	  PreparedStatement ps = null;
	  int updatedRows = 0;
	  try
	  {
		  con = super.getConnection();

		  ps = con.prepareStatement(query);

		  GlobalUtils.setObject(ps, 1, internalFileId);

		  updatedRows = ps.executeUpdate();
	  }finally
	  {
		  super.releaseResources(ps, con);
	  }

	  return updatedRows;
  }

  public int incNumOfCompletedChunksInFileSummary(String internalFileId) throws Exception
  {
	  logger.debug("incNumOfCompletedChunksInFileSummary(file_summary): internalFileId {}", new Object[]{internalFileId});
	  
	  String query = "update file_summary set num_of_completed_chunks = num_of_completed_chunks + 1 where internal_file_id=? and num_of_completed_chunks + 1 < num_of_group_chunks";

	  Connection con = null;
	  PreparedStatement ps = null;
	  int updatedRows = 0;
	  try
	  {
		  con = super.getConnection();

		  ps = con.prepareStatement(query);

		  GlobalUtils.setObject(ps, 1, internalFileId);

		  updatedRows = ps.executeUpdate();
	  }finally
	  {
		  super.releaseResources(ps, con);
	  }

	  return updatedRows;
  }



  public int decNumOfProcessChunksInFileSummary(String internalFileId) throws Exception
  {
	  logger.debug("decNumOfProcessChunksInFileSummary(file_summary): internalFileId {}", new Object[]{internalFileId});
	  String query = "update file_summary set num_of_preprocessed_chunks = num_of_preprocessed_chunks - 1 where internal_file_id=?";

	  Connection con = null;
	  PreparedStatement ps = null;
	  int updatedRows = 0;
	  try
	  {
		  con = super.getConnection();

		  ps = con.prepareStatement(query);

		  GlobalUtils.setObject(ps, 1, internalFileId);

		  updatedRows = ps.executeUpdate();
	  }finally
	  {
		  super.releaseResources(con, ps);
	  }

	  return updatedRows;
  }

  public int decNumOfCompletedChunksInFileSummary(String internalFileId) throws Exception
  {
	  logger.debug("decNumOfCompletedChunksInFileSummary(file_summary): internalFileId {}", new Object[]{internalFileId});
	  String query = "update file_summary set num_of_completed_chunks = num_of_completed_chunks - 1 where internal_file_id=?";

	  Connection con = null;
	  PreparedStatement ps = null;
	  int updatedRows = 0;
	  try
	  {
		  con = super.getConnection();

		  ps = con.prepareStatement(query);

		  GlobalUtils.setObject(ps, 1, internalFileId);

		  updatedRows = ps.executeUpdate();
	  }finally
	  {
		  super.releaseResources(con, ps);
	  }

	  return updatedRows;
  }


  public int updateNumOfProcessChunksInFileSummary(String internalFileId) throws Exception
  {
	  logger.debug("updateNumOfProcessChunksInFileSummary(file_summary): internalFileId {}", new Object[]{internalFileId});
	  String query = "update file_summary set num_of_preprocessed_chunks = num_of_chunks where internal_file_id=?";

	  Connection con = null;
	  PreparedStatement ps = null;
	  int updatedRows = 0;
	  try
	  {
		  con = super.getConnection();

		  ps = con.prepareStatement(query);

		  GlobalUtils.setObject(ps, 1, internalFileId);

		  updatedRows = ps.executeUpdate();
	  }finally
	  {
		  super.releaseResources(con, ps);
	  }

	  return updatedRows;
  }


	public final void handleCacheEntryRemoval(final ProcessPdoPerGroupIdEntry cacheEntry, final Object oCacheEntryKey) throws CacheException {
		logger.debug("handleCacheEntryRemoval(FILE_SUBSET_CHUNKS_SPOOL,): oCacheEntryKey.getCacheKey {}", new Object[]{cacheEntry.getCacheKey()});
		//serialize the entry and persist
		final String INSERT_STATEMENT = "insert into FILE_SUBSET_CHUNKS_SPOOL (INTERNAL_FILE_ID,CHUNK_ID,UNIQUE_GROUPING_ID,BUFFER) " +
				"values (?,?,?,?)" ;

		//load the chunk-per-group id serialized cache entry from the database and return it
		ResultSet rs = null;
		PreparedStatement ps = null;
		ByteArrayOutputStream bous = new ByteArrayOutputStream() ;
		ObjectOutputStream oos = null ;
		ByteArrayInputStream bais = null ;

		Context context = null ;
		try{

			context = new Context(cacheEntry.getCacheKey(), '^') ;
			ps = this.prepareStatement(INSERT_STATEMENT, context) ;

			//split the UID into the actual column values
			logger.debug("[ProcessPdoPerUniqueGroupIdCacheHandler.handleCacheEntryRemoval()]: Eviction for " + context.sUID);

			oos = new ObjectOutputStream(bous) ;
			oos.writeObject(cacheEntry) ;
			oos.flush() ;

			bais = new ByteArrayInputStream(bous.toByteArray()) ;
			ps.setBinaryStream(4, bais, bais.available()) ;

			ps.executeUpdate() ;
		}catch(Throwable t) {
			final CacheException ce = (!(t instanceof CacheException) ? new CacheException(t) : (CacheException) t) ;
			throw ce ;
		}finally{
			this.releaseResources(rs, ps, context.conn);

			try{
				if(oos != null) oos.close() ;
				if(bais != null) bais.close() ;
			}catch(Throwable t1) {
				throw new CacheException(t1) ;
			}//EO catch block

		}//EO catch block

	}//EOM



	private static final class Context {
		private Connection conn ;
		private String sUID ;
		private String sFileId ;
		private String sChunkId ;
		private String sGroupId ;
		final char chrKeyDelimiter ;

		Context(final String sUID, final char chrKeyDelimiter, Object...arrKeyParts) {
			this.sUID = sUID ;
			this.chrKeyDelimiter = chrKeyDelimiter ;

			if(arrKeyParts == null || arrKeyParts.length == 0) arrKeyParts = sUID.toString().split("\\Q"+ this.chrKeyDelimiter +"\\E") ;
			this.setKeyParts(arrKeyParts) ;
		}//EOM

		private final void setKeyParts(final Object...arrKeyParts) {
			//set the file, chunk and group id binding variables
			this.sFileId =  (String) arrKeyParts[0];
			this.sChunkId = (String) arrKeyParts[1];
			this.sGroupId = (String) arrKeyParts[2];
		}//EOM

	}//EO inner class context

	private final PreparedStatement prepareStatement(final String sStatement, final Context context) throws Throwable{


		Connection conn = context.conn ;
		if(conn == null) conn = context.conn = this.getConnection() ;
		final PreparedStatement ps = conn.prepareStatement(sStatement) ;

		//first 3 arguments must always be in the following order:
		//file, chunk, group id
		GlobalUtils.setObject(ps, 1, context.sFileId) ;
		GlobalUtils.setObject(ps, 2, context.sChunkId) ;
		GlobalUtils.setObject(ps, 3, context.sGroupId) ;

		return ps;
	}//EOM


	public int updateFileInterfaceBuffersStatus(Connection conn, String status, String internalFileId, String chunkId, String unqueGroupingId) {
		logger.debug("updateFileInterfaceBuffersStatus(file_interface_buffers): internalFileId {},chunkId {}, status {}, unqueGroupingId {}"
				,new Object[]{internalFileId,chunkId,status,unqueGroupingId});
		
		PreparedStatement ps=null;
		int updatedEntries = -1;
		Connection localConn = null;
		String query = "update file_interface_buffers set status = ? where in_file_id = ? and status = 'SENT' and " +
				"file_interface_buffers.chunk_id = ? and (file_interface_buffers.unique_grouping_id=? or file_interface_buffers.unique_grouping_id is null and ? is null) ";
		try{
			localConn = conn != null ? conn : super.getConnection();
			ps = localConn.prepareStatement(query);
			GlobalUtils.setObject(ps, 1, status);
			GlobalUtils.setObject(ps, 2, internalFileId);
			GlobalUtils.setObject(ps, 3, chunkId);
			GlobalUtils.setObject(ps, 4, unqueGroupingId);
			GlobalUtils.setObject(ps, 5, unqueGroupingId);
			updatedEntries = ps.executeUpdate();
		}catch(Throwable t){
			throw new FlowException(t);
		}finally{
			super.releaseResources(ps, (conn == null ? localConn : null));
		}

		return updatedEntries;
	}
	
	public List<BulkSummary> getBulksPerFileId(Connection conn, String fileId) throws SQLException{
		String query = "select * from bulk_summary where internal_file_id = ?";
		List<BulkSummary> bulks = new ArrayList<BulkSummary>();
		PreparedStatement ps = null;
		ResultSet rs = null;
		Connection localConn = null;
		try {
			localConn = conn != null ? conn : super.getConnection();
			ps = localConn.prepareStatement(query);
			GlobalUtils.setObject(ps, 1, fileId);
			rs = ps.executeQuery();
			populateJPAObjects(bulks, rs, BulkSummary.class);
		} catch (SQLException e) {
			throw new SQLException(e);
		}finally{
			releaseResources(ps, rs, (conn == null ? localConn : null));
		}
		
		return bulks;
	}
	
	
	public void  updateIndividualStatusToReject(Connection conn, String fileId,String msgStatus) throws SQLException{
		
		PreparedStatement ps=null;
		int updatedEntries = -1;
		Connection localConn = null;
		String query="UPDATE MINF M SET M.P_MSG_STS='REJECTED' WHERE P_MSG_STS=? AND P_IN_INTERNAL_FILEID= ? ";
		ps = conn.prepareStatement(query);
		try{
			localConn = conn != null ? conn : super.getConnection();
			ps = localConn.prepareStatement(query);
			GlobalUtils.setObject(ps, 1, msgStatus);
			GlobalUtils.setObject(ps, 2, fileId);
			updatedEntries = ps.executeUpdate();
		}catch(Throwable t){
			throw new FlowException(t);
		}finally{
			super.releaseResources(ps, (conn == null ? localConn : null));
		}

		logger.debug(Integer.toString(updatedEntries));
	}
	
	public int[] updateBulkSummaryCalcEntries(Connection conn, String fileId, List<BulkSummary> bulks) throws SQLException{
		String query = "update bulk_summary set blk_calc_ctrl_sum = ?, blk_calc_nb_of_txs = ?, blk_calc_ttl_amt = ? where internal_file_id = ? and bulk_id = ?";
		PreparedStatement ps = null;
		int effectedRows[] = null;
		Connection localConn = null;
		try {
			localConn = conn != null ? conn : super.getConnection();
			ps = localConn.prepareStatement(query);
			for(BulkSummary bulk : bulks){
				GlobalUtils.setObject(ps, 1, bulk.getBulkCalcCtrlSum());
				GlobalUtils.setObject(ps, 2, bulk.getBulkCalcNumberOfTxs());
				GlobalUtils.setObject(ps, 3, bulk.getBulkCalcTotalAmt());
				GlobalUtils.setObject(ps, 4, fileId);
				GlobalUtils.setObject(ps, 5, bulk.getBulkId());
				ps.addBatch();
			}
			effectedRows = ps.executeBatch();
		} catch (SQLException e) {
			throw new SQLException(e);
		}finally{
			releaseResources(ps, (conn == null ? localConn : null));
		}

		return effectedRows;
	}
	
	public String findMatchingFile(Connection conn, String fileRef) throws SQLException{
//		String query = "select internal_file_id from file_summary where file_reference = ? and direction = 'O' and status in(?,?)";
		String query = "select internal_file_id from file_summary where file_reference = ? and status in(?,?,?)";
		PreparedStatement ps = null;
		ResultSet rs = null;
		String matchingFile = null;
		Connection localConn = null;
		try {
			localConn = conn != null ? conn : super.getConnection();
			ps = localConn.prepareStatement(query);
			GlobalUtils.setObject(ps, 1, fileRef);
			GlobalUtils.setObject(ps, 2, STATUS_FILE_TIME_OUT);
			GlobalUtils.setObject(ps, 3, STATUS_FILE_SENT_PENDING_ACK);
			GlobalUtils.setObject(ps, 4, STATUS_FILE_COMPLETED);		//added due to a case when MIXED pacs002 already acked ONE bulk and still looking to ack the next one (DD and CT)
			rs = ps.executeQuery();
			if (rs.next()){
				matchingFile = rs.getString("internal_file_id");
			}
		} catch (SQLException e) {
			throw new SQLException(e);
		}finally{
			releaseResources(ps, rs, (conn == null ? localConn : null));
		}
		
		return matchingFile;
	}
	
	
	public List<OutFileBuffers> getOutChunksByOutFileID(Connection conn, String internalFileId) throws SQLException{
		String chunksQuery = "select out_chunk_id, total_msg_count_nb from out_file_buffers where out_file_id = ?";
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<OutFileBuffers> outChunks = new ArrayList<OutFileBuffers>();
		Connection localConn = null;
		try {
			localConn = conn != null ? conn : super.getConnection();
			ps = localConn.prepareStatement(chunksQuery);
			GlobalUtils.setObject(ps, 1, internalFileId);
			rs = ps.executeQuery();
			while (rs.next()){
				OutFileBuffers ofb = new OutFileBuffers();
				ofb.setOutChunkId(rs.getString("out_chunk_id"));
				ofb.setTotalMsgCountNb(rs.getInt("total_msg_count_nb"));
				outChunks.add(ofb);
			}
			
		} catch (SQLException e) {
			throw new SQLException(e);
		}finally{
			releaseResources(ps, rs, (conn == null ? localConn : null));
		}

		return outChunks;
	}
	
	/**
	 * @param conn
	 * @param internalFileId
	 * @param bulkType
	 * @return
	 * @throws SQLException
	 */
	public List<String[]> getChunksByFileIDAndBulk(String fileReference,String bulkType) throws SQLException{
		String chunksQuery = "select fpd.chunk_id,fs.file_reference from file_process_distribution fpd,file_summary fs,"
							+"file_subset_chunks fsc where fpd.chunk_id=fsc.chunk_id and fs.internal_file_id = fpd.internal_file_id "
							+"and fs.file_reference=? and fsc.direct_debit_tp=?";
            
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<String[]> chunks = new ArrayList<String[]>();
		Connection conn = null;
		
		try {
			conn = super.getConnection();
			ps = conn.prepareStatement(chunksQuery);
			GlobalUtils.setObject(ps, 1, fileReference);
			GlobalUtils.setObject(ps, 2, bulkType);
			rs = ps.executeQuery();
			while (rs.next()){
				chunks.add(new String[]{rs.getString("chunk_id"),rs.getString("file_reference")});
			}
			
		} catch (SQLException e) {
			ExceptionController.getInstance().handleException(e, this);
			return Collections.emptyList();
		}finally{
			super.releaseResources(rs, ps);
		}

		return chunks;
	}
	
	/**
	 * @param conn
	 * @param internalFileId
	 * @param bulkType
	 * @return
	 * @throws SQLException
	 */
	public List<OutFileBuffers> getOutChunksByFileIDAndChunkList(Connection conn, String internalFileId,String chunkIDList) throws SQLException{
		String chunksQuery = "select fpd.chunk_id,fpd.rec_count from file_process_distribution fpd left OUTER join "+
							"file_subset_chunks fsc on fpd.chunk_id=fsc.chunk_id where "+
							"fpd.internal_file_id=? and fsc.chunk_id in ";
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<OutFileBuffers> outChunks = new ArrayList<OutFileBuffers>();
		Connection localConn = null;
		chunksQuery += "("+chunkIDList+")";
		try {
			localConn = conn != null ? conn : super.getConnection();
			ps = localConn.prepareStatement(chunksQuery);
			GlobalUtils.setObject(ps, 1, internalFileId);
			//GlobalUtils.setObject(ps, 2, chunkIDList);
			rs = ps.executeQuery();
			while (rs.next()){
				OutFileBuffers ofb = new OutFileBuffers();
				ofb.setOutChunkId(rs.getString("chunk_id"));
				ofb.setTotalMsgCountNb(rs.getInt("rec_count"));
				outChunks.add(ofb);
			}
			
			
		} catch (SQLException e) {
			throw new SQLException(e);
		}finally{
			releaseResources(ps, rs, (conn == null ? localConn : null));
		}

		return outChunks;
	}
	
	public List<OutFileBuffers> getOutChunksByFileIDAndBulk(Connection conn, String internalFileId,String bulkType) throws SQLException{
		String chunksQuery = "select fpd.chunk_id,fpd.rec_count from file_process_distribution fpd left OUTER join "+
							"file_subset_chunks fsc on fpd.chunk_id=fsc.chunk_id where "+
							"fpd.internal_file_id=?";
		String bulkCondition= " and fsc.direct_debit_tp=?";
		boolean applyBulkCondition = false;
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<OutFileBuffers> outChunks = new ArrayList<OutFileBuffers>();
		Connection localConn = null;
		
		if(GlobalUtils.isNullOrEmpty(bulkType) || !"ALL".equalsIgnoreCase(bulkType)){
			applyBulkCondition = true;
			chunksQuery = chunksQuery.concat(bulkCondition);
		}
		try {
			localConn = conn != null ? conn : super.getConnection();
			ps = localConn.prepareStatement(chunksQuery);
			GlobalUtils.setObject(ps, 1, internalFileId);
			if(applyBulkCondition)
				GlobalUtils.setObject(ps, 2, bulkType);
			rs = ps.executeQuery();
			while (rs.next()){
				OutFileBuffers ofb = new OutFileBuffers();
				ofb.setOutChunkId(rs.getString("chunk_id"));
				ofb.setTotalMsgCountNb(rs.getInt("rec_count"));
				outChunks.add(ofb);
			}
			
			
		} catch (SQLException e) {
			throw new SQLException(e);
		}finally{
			releaseResources(ps, rs, (conn == null ? localConn : null));
		}

		return outChunks;
	}

	public void insertJornalMessages(Connection conn, String fileId) throws SQLException{
		PreparedStatement ps=null;
		int updatedEntries = -1;
		Connection localConn = null;
		Date dSystemDate = new Date();
		String sSystemDate = GlobalDateTimeUtil.getFormattedDateString(dSystemDate, GlobalDateTimeUtil.STATIC_DATA_DATE_TIME);
        String sTimeStamp = GlobalDateTimeUtil.getSimpleDateFormatByFormat(GlobalDateTimeUtil.STATIC_DATA_TIME_STAMP).format(new Date());
		String query="INSERT INTO newjournal (OFFICE,ERROR_PARAMS, MID,STATUS,Field_Logical_Id,Zone_Code,ERROR_CODE,PARTITION_ID,TIME_STAMP,UPDATE_DATE) "+
	    "SELECT 'SG1','@@TIMEHOLD@@STRING@@@@,@@REJECTED@@STRING@@',MINF.P_MID,'REJECTED','MISSING_FIELD_LOGICAL_ID','SGT','1001',0,'"+sTimeStamp+"',TO_DATE(? , 'YYYY-MM-DD HH24:MI:SS') "+
	    "FROM MINF	WHERE MINF.P_IN_INTERNAL_FILEID=?" ;
		ps = conn.prepareStatement(query);
		try{
			localConn = conn != null ? conn : super.getConnection();
			ps = localConn.prepareStatement(query);
			GlobalUtils.setObject(ps, 1,sSystemDate);
			GlobalUtils.setObject(ps, 2,fileId );
			updatedEntries = ps.executeUpdate();
		}catch(Throwable t){
			throw new FlowException(t);
		}finally{
			super.releaseResources(ps, (conn == null ? localConn : null));
		}

		logger.debug(Integer.toString(updatedEntries));
	}
	

}
