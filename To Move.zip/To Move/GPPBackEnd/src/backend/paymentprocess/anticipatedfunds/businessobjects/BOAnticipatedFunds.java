
package backend.paymentprocess.anticipatedfunds.businessobjects;

import static backend.core.module.MessageConstantsInterface.*;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.*;
import static com.fundtech.util.GlobalUtils.isNullOrEmpty;

import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.paymentprocess.glm.basic.businessobjects.BOGLMMatchingBase;
import backend.paymentprocess.matchingcheck.businessobjects.MatchType;
import backend.paymentprocess.matchingcheck.output.MatchingCheckOutputData;

import com.fundtech.annotations.Wrap;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.util.ExceptionController;

@Wrap (tx="Bean")
public class BOAnticipatedFunds extends BOGLMMatchingBase {
	private static final Logger logger = LoggerFactory.getLogger(BOAnticipatedFunds.class);
	
	/**
	 * Matches AF to a other message: 
	 * If MT210, match to one of {inbound PAY,PI,SN} 
	 * If MT210RVR, match to one of {outbound PAY,OSN,SC} 
	 * The main PDO is the 210 one.
	 */
	public Feedback matchAnticipatedFundTo(String mid) {
		Admin admin = Admin.getContextAdmin();
		
		Feedback feedback = new Feedback();		
		PDO pdoAF = null;
		
		MatchType[] candidateMatches = new MatchType[]{
				 MatchType.AF_Payment
				,MatchType.AF_SN
				,MatchType.AF_SC};
		
		logger.debug("match AF to Payment,candidate matches: {}",Arrays.asList(candidateMatches));
		
		MatchType currentMatch = null;
		
		try {
			pdoAF = PaymentDataFactory.load(mid);
			
			boolean alreadyMatched = false;
			
			for (MatchType candidateMatch : candidateMatches) {
				currentMatch = candidateMatch;
				String previousMatchStatus = getMatchStatus(pdoAF, currentMatch);
				
				MatchingCheckOutputData matchingResult = performMatching(pdoAF,currentMatch);
				
				if (matchingResult == null) { //no matching attempt had been done: already matched
					alreadyMatched = true;
					continue;					
				}
				
				postAFMatching(admin,pdoAF,currentMatch,matchingResult,previousMatchStatus);
				
				if (shouldStopAFMatching(matchingResult)) {
					logger.debug("AF^Payment matches stopped, last match {} ends with '{}'"
							,currentMatch,getMatchStatus(pdoAF, currentMatch));
					
					return matchingResult.getFeedback();
				}
			}
			
			if (!alreadyMatched)
				unmatchedAF(pdoAF);
		} catch (Throwable t) {
			logger.error("failed on matching type {}"+currentMatch);			
			ExceptionController.getInstance().handleException(t, this);
			feedback.setFailure();
		} finally {			
		}

		return feedback;
	}

	/** 
	 * Matches other message to AF:
	 * 	If message is one of {inbound PAY,PI,SN}, match to MT210
	 * 	If message is one of {outbound PAY,OSN,SC} match to MT210RVR
	 * The main PDO is a none AF message.
	 */
	public Feedback matchToAnticipatedFund(String mid) {
		Admin admin = Admin.getContextAdmin();
		
		Feedback feedback = new Feedback();
		
		PDO pdoOther = PaymentDataFactory.load(mid);
		
		String otherClass = pdoOther.getString(P_MSG_CLASS);
		
		MatchType matchType = null;
		
		if (MSG_CLASS_SN.equals(otherClass))
			matchType = MatchType.SN_AF;
		if (MSG_CLASS_SC.equals(otherClass))
			matchType = MatchType.SC_AF;
		if (PAYMENT_CLASSES.contains(otherClass))
			matchType = MatchType.Payment_AF;
		
		if (matchType == null)
			return feedback;
		
		try {
			MatchingCheckOutputData matchingResult = performMatching(pdoOther,matchType);
			
			if (matchingResult == null) //no matching attempt had been done: already matched
				return feedback;
			
			postMatchingToAF(admin,pdoOther,matchType,matchingResult);
			
			return matchingResult.getFeedback();			
		} catch (Throwable t) {
			logger.error("failed on matching type {}"+matchType);			
			ExceptionController.getInstance().handleException(t, this);
			feedback.setFailure();
		} finally {
		}

		return feedback;		
	}
	

	private boolean shouldStopAFMatching(MatchingCheckOutputData matchingResult) {
		//stop on success match or action 'stop'
		return !isNullOrEmpty(matchingResult.getMID()) || matchingResult.isStopMatchingAction();
	}

	private void postAFMatching( Admin admin
								,PDO pdoAF
								,MatchType matchType
								,MatchingCheckOutputData matchingResult
								,String previousMatchStatus) {
		String matchStatus = getMatchStatus(pdoAF, matchType);
				
		if (MONITOR_FLAG_MATCH.equals(matchStatus)) {
			postSuccessMatch(pdoAF,matchType);
		} else if (MONITOR_FLAG_NONE.equals(getMatchStatus(pdoAF,matchType))) {
			if (!matchingResult.foundMatchingCheckProfile()) {
				if (!isNullOrEmpty(previousMatchStatus)) {
					logger.debug("no matching profile found for {},however preserving old matching status {}"
							,matchType,previousMatchStatus);
					setMatchStatus(pdoAF,matchType,previousMatchStatus);
				}
			} 
		} else if (MONITOR_FLAG_WAITING.equals(getMatchStatus(pdoAF,matchType))) {
			if (matchingResult.isMultipleMatches()) {			
			}
		}
	}
	
	private void postMatchingToAF(Admin admin,PDO pdoOther,MatchType matchType,MatchingCheckOutputData matchingResult) {
		String matchStatus = getMatchStatus(pdoOther, matchType);
		
		if (MONITOR_FLAG_MATCH.equals(matchStatus)) {
			postSuccessMatch(pdoOther,matchType);					
		}
	}
	
	private void unmatchedAF(PDO pdoAF) {
		setStatus(pdoAF,MESSAGE_STATUS_WAIT_MATCH);		
	}		
}//class	

