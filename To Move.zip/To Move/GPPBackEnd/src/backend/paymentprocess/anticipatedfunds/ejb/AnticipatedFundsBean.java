package backend.paymentprocess.anticipatedfunds.ejb;

import javax.ejb.Stateless;
import backend.core.SuperSLSB;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;

import backend.businessobject.proxies.interceptors.InterceptorSetType;
import backend.paymentprocess.anticipatedfunds.ejbinterfaces.AnticipatedFundsLocal;
import backend.paymentprocess.anticipatedfunds.ejbinterfaces.AnticipatedFunds;
import backend.paymentprocess.matchingcheck.businessobjects.MatchType;

@Stateless
public class AnticipatedFundsBean extends SuperSLSB<AnticipatedFunds> implements AnticipatedFundsLocal, AnticipatedFunds{
	
	public AnticipatedFundsBean() { super(backend.paymentprocess.anticipatedfunds.businessobjects.BOAnticipatedFunds.class, InterceptorSetType.Complete) ; }//EOM
	
	
	/** 
	 * Matches a 210 payment to a payment message.
	 * The main PDO is the 210 one.
	 */
	public com.fundtech.datacomponent.response.Feedback matchAnticipatedFundTo(final Admin admin, java.lang.String sMID ) {
		return this.m_bo.matchAnticipatedFundTo(admin, sMID ) ;
	}//EOM

	/** 
	 * Matches a payment to a 210 message.
	 * The main PDO is the payment one.
	 */
	public com.fundtech.datacomponent.response.Feedback matchToAnticipatedFund(final Admin admin, java.lang.String sMID ) {
		return this.m_bo.matchToAnticipatedFund(admin, sMID ) ;
	}//EOM


	/*public Feedback performManualMatching(Admin admin, String mid1,
			String selfRelatedType, String relatedType, String mid2) {
		return this.m_bo.performManualMatching(admin,mid1,selfRelatedType,relatedType,mid2 ) ;		
	}*/


	public MatchType attemptThreeWayMatching(Admin admin, PDO pdo) {
		return this.m_bo.attemptThreeWayMatching(admin,pdo) ;	
	}


}//EOC