package backend.paymentprocess.anticipatedfunds.ejbinterfaces;

import javax.ejb.Local;

/**
 * Local interface for AnticipatedFunds.
 */
@Local
public interface AnticipatedFundsLocal extends AnticipatedFunds{} ; 