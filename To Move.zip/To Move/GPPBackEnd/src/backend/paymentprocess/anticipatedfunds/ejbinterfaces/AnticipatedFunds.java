package backend.paymentprocess.anticipatedfunds.ejbinterfaces;

import javax.ejb.Remote;

import backend.paymentprocess.matchingcheck.businessobjects.MatchType;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;

/**
 * Remote interface for AnticipatedFunds.
 */
@Remote
public interface AnticipatedFunds{

	public static final String REMOTE_JNDI_NAME="ejb/AnticipatedFundsBean";
	
	
	/** 
	 * Automatic matching of AF to a payment message: 
	 * 	If MT210, match to one of {inbound PAY,PI,SN}
	 *  If MT210RVR, match to one of {outbound PAY,OSN,SC} 
	 * The main PDO is the 210 one.
	 */
	public Feedback matchAnticipatedFundTo(final Admin admin, String mid);
	
	
	/** 
	 * Automatic matching of payment to AF: 
	 * 	If payment is one of {inbound PAY,PI,SN}, match to MT210
	 * 	If payment is one of {outbound PAY,OSN,SC} match to MT210RVR   
	 * The main PDO is the payment one.
	 */
	public Feedback matchToAnticipatedFund(final Admin admin, String mid);
	
	
	/**
	 * attempt to establis a three way matching for a given PDO 
	 * @param pdo one of {PAY,PI,SN,OSN,AF,SC}
	 * @return the established match or null if no match took place  
	 */
	public MatchType attemptThreeWayMatching(final Admin admin,PDO pdo); 
}//EOI  

/**
 * perform manual matching from other message (PAY,PI,SN,OSN,SC) to AF or vice versa
 
public Feedback performManualMatching( final Admin admin
							,String mid1
							,String mid1RelatedTypeSelf
							,String mid2RelatedType
							,String mid2);*/