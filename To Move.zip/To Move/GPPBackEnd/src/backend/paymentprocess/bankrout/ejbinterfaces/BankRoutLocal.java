package backend.paymentprocess.bankrout.ejbinterfaces;

import javax.ejb.Local;

/**
 * Local interface for BankRout.
 */
@Local
public interface BankRoutLocal extends BankRout{} ; 