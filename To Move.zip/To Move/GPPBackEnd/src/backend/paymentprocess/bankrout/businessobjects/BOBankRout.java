package backend.paymentprocess.bankrout.businessobjects;

import static backend.businessobject.BOProxies.m_paymentServicesLogging;


import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import com.fundtech.annotations.Expose;
import com.fundtech.annotations.Wrap;
import com.fundtech.cache.entities.BankRout;
import com.fundtech.cache.entities.CountryBu;
import com.fundtech.cache.entities.CountryCfg;
import com.fundtech.cache.entities.CountryCurrency;
import com.fundtech.cache.entities.CurrencyBu;
import com.fundtech.cache.entities.Customrs;
import com.fundtech.cache.entities.Msgerr;
import com.fundtech.cache.entities.Newjournal;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.cache.syspar.SystemParametersInterface;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.core.paymentprocess.data.fields.PaymentFieldInterface;
import com.fundtech.core.paymentprocess.errorhandling.ProcessError;
import com.fundtech.core.paymentprocess.findfirstinchain.FindFirstInChainConstants;
import com.fundtech.core.paymentprocess.findfirstinchain.MessageChainsData;
import com.fundtech.core.paymentprocess.findfirstinchain.FindFirstInChainConstants.ChainType;
import com.fundtech.core.paymentprocess.findfirstinchain.FindFirstInChainConstants.ChainTypeOrigin;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.datacomponent.response.SimpleResponseDataComponent;
import com.fundtech.errors.ProcessErrorConstants;
import com.fundtech.util.ExceptionController;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalUtils;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import backend.businessobject.BOBasic;
import backend.businessobject.BOProxies;
import backend.core.module.MessageConstantsInterface;
import backend.paymentprocess.bankrout.common.RoutingLevelType;
import backend.paymentprocess.bankrout.common.TransferMethodType;
import backend.paymentprocess.erroraudit.ErrorAuditUtils;
import backend.paymentprocess.findfirstinchain.businessobjects.BOFindFirstInChain;
import backend.util.ServerConstants;


@Wrap  

public class BOBankRout extends BOBasic implements MessageConstantsInterface, PDOConstantFieldsInterface
{

	private static final Logger logger = LoggerFactory.getLogger(BOBankRout.class);
	private static Random m_generator = new Random();
	
	@Expose
	public Feedback retrieveCorrespondent(String mid)
	{
		
		Feedback feedback = new Feedback();
		PDO pdo = PaymentDataFactory.load(mid);
		
		
//		get the current routing level
		String routingLevelStr = pdo.getString(D_ROUTING_LEVEL);
		RoutingLevelType routingLevel= GlobalUtils.isNullOrEmpty(routingLevelStr) ? RoutingLevelType.EMPTY : RoutingLevelType.valueOf(routingLevelStr);
		String instdAgentBic = pdo.getString(X_INSTD_AGT_BIC_2AND);
		
		logger.info("Retrieve Correspondent: mid = {}", mid);
		
		feedback.setFailure();
		
//		loop until the routing level is valid and feedback is still failure and X_INSTD_AGT_BIC_2AND logical field is empty.
		while (routingLevel != RoutingLevelType.CURRENCY && !feedback.isSuccessful() && GlobalUtils.isNullOrEmpty(instdAgentBic))
		{
			logger.info("Retrieve Correspondent: routing level = {}", routingLevel);
//			identify the agent per current routing level
			feedback = identifyTheAgentPerRoutingLevel(pdo, routingLevel,feedback);
			
			logger.info("Retrieve Correspondent: agent identification for routing level {} isSuccessful = {}", routingLevel, feedback.isSuccessful());
//			set next routing level
			routingLevel = advanceRoutingLevel(routingLevel);
//			set next routing level to PDO
			pdo.set(D_ROUTING_LEVEL, routingLevel.name());
		}
		
//		if feedback remained failure after the loop, 40137 error should be raised.
		if (!feedback.isSuccessful())
		{
			ProcessError pError=new ProcessError(ProcessErrorConstants.CorrespondentChainBuildFail);
	        configureErrorFeedback(pError.getErrorCode(),pError.getDescription(),feedback);
	        ErrorAuditUtils.setErrors(pError,pdo.getIsHistory());
	        
	        if (!GlobalUtils.isNullOrEmpty(instdAgentBic))
	        {
	        	logger.info("Retrieve Correspondent: agent identification failure because correspondent chain is full");
	        }else
	        {
	        	logger.info("Retrieve Correspondent: agent identification failure...");
	        }
		}
		
		return feedback; 
		
	}
	
/**
 * 	method which advances the routing level
 * @param routingLevel
 * @return
 */
	private RoutingLevelType advanceRoutingLevel(RoutingLevelType routingLevel)
	{
		switch(routingLevel)
		{
			case EMPTY: routingLevel = RoutingLevelType.RECEIVER;
						break;
			case RECEIVER: routingLevel = RoutingLevelType.COUNTRY;
						   break;
			case COUNTRY: routingLevel = RoutingLevelType.CURRENCY;
			   			  break;			
			default: routingLevel = null;
					 break;	
			
		}
		return routingLevel;
	}
/**
 * method which identifying the agent BIC according to routing level
 * @param pdo
 * @param routingLevel
 * @param feedback
 * @return
 */
	private Feedback identifyTheAgentPerRoutingLevel(PDO pdo, RoutingLevelType routingLevel, Feedback feedback)
	{
		feedback = feedback == null ? feedback = new Feedback() : feedback;
		
		
		switch (routingLevel) 
		{
			case EMPTY:
				feedback = retrieveReceiversCorrespondent(pdo, feedback);
				break;
			case RECEIVER:
				feedback = retrieveCountryCorrespondent(pdo, feedback);
				break;
			case COUNTRY:
				feedback = retrieveCurrencyCorrespondent(pdo, feedback);
				break;
	
			default:
				feedback.setFailure();
				break;
		}
		
		return feedback;
	}
	
	@Expose
	public Feedback retrieveReceiversCorrespondent(String mid)
	{
		PDO pdo = PaymentDataFactory.load(mid);
		Feedback feedback = new Feedback();
		return retrieveReceiversCorrespondent(pdo, feedback);
	}
	
	
	/**
	 * retrieve the agent BIC from credit customer
	 * @param pdo
	 * @param feedback
	 * @return
	 */
	private Feedback retrieveReceiversCorrespondent(PDO pdo, Feedback feedback)
	{
		
		feedback.setFailure();
		
		logger.info("Retrieve Correspondent: retrieve receiver correspondent");
//		get bank rout profile
		BankRout bankRout = getBankRout(pdo, pdo.getNSetCREDIT_CUSTOMER().getSwiftId());
		
		
		
		
		if (bankRout != null && !GlobalUtils.isNullOrEmpty(bankRout.getAgent()))
		{
			logger.info("Retrieve Correspondent: retrieve receiver correspondent - bank rout uid = {}", bankRout.getUidBankRout());
			Customrs customer = CacheKeys.customrsCCKey.getSingle(bankRout.getAgent());
			
			if (customer != null)
			{
				logger.info("Retrieve Correspondent: retrieve receiver correspondent - credit customer uid = {}", customer.getUidCustomrs());
//				set agent BIC to next in chain
				feedback = setNextInChain(pdo, customer.getSwiftId(), feedback);
				
//				update PDO with bank rout data.
				if (feedback.isSuccessful())
				{
					pdo.set(D_BANK_ROUT_AGENT, customer.getSwiftId());
					pdo.setBankRout(bankRout);
					
					logger.info("Retrieve Correspondent: retrieve receiver correspondent - successful, BIC = {}", customer.getSwiftId());
				}
			}else
			{
				logger.info("Retrieve Correspondent: retrieve receiver correspondent - no customer entry found for agent = {} and office ={}", 
						bankRout.getAgent(), bankRout.getOffice());
			}
		}else
		{
			logger.info("Retrieve Correspondent: retrieve receiver correspondent - no bank rout entry found");
		}
		
		if (!feedback.isSuccessful())
			logger.info("Retrieve Correspondent: retrieve receiver correspondent - no agent fount, continue to next routing level");
		
		
		return feedback;
	}
	
	/**
	 * method which defining the next in chain BIC
	 * @param pdo
	 * @param bic
	 * @param feedback
	 * @return
	 */
	private Feedback setNextInChain(PDO pdo, String bic, Feedback feedback)
	{
		logger.info("Retrieve Correspondent: setting BIC {} to...", bic);
		
		int iChainIndex = ((Integer)pdo.get(D_CHAIN_INDEX)).intValue();
		
		// X_INSTD_AGT_BIC_2AND (RECEIVER) is empty ?not populated yet.
		if(iChainIndex > 0)
		{
			// Sets successfull feedback.
			feedback.setSuccess();
			feedback.setErrorCode(0);
			feedback.setErrorText(ServerConstants.EMPTY_STRING);
			feedback.setUserErrorText(ServerConstants.EMPTY_STRING);
			BOFindFirstInChain.setChainField(true, iChainIndex - 1, ChainTypeOrigin.BIC, bic);
//			switch(iChainIndex)
//			{
//				// Sets the reciever field.
//				case 1:
//				{
//					pdo.set(X_INSTD_AGT_BIC_2AND, bic);
//					break;
//				}
//					
//				// Sets the 'Correspondent' field.
//				case 2:
//				{
//					pdo.set(P_CORRESPONDENT, bic);
//					break;
//				}
//
//				// 	Sets the 'Intermediary agent' field.
//				case 3:
//				{
//					pdo.set(X_INTRMY_AGT1_BIC_2AND, bic);
//					break;
//				}
//
//				// Sets the 'Creditor agent' field.
//				case 4:
//				{
//					pdo.set(X_CDTR_AGT_BIC_2AND, bic);
//					break;
//				}
//			}
		}

		else
		{
			feedback.setFailure();
			logger.info("Retrieve Correspondent: list of chains has been exhausted!");
		}
		
		return feedback;
	}
	
	private String getNextInChain(PDO pdo, int indx)
	{
		String nextInChainBic = null;
		
		switch(indx)
		{
			case 0: nextInChainBic = pdo.getString(X_INSTD_AGT_BIC_2AND);
					break;
			case 1: nextInChainBic = pdo.getString(P_CORRESPONDENT);
					break;
			case 2: nextInChainBic = pdo.getString(X_INTRMY_AGT1_BIC_2AND);
					break;
			case 3: nextInChainBic = pdo.getString(X_CDTR_AGT_BIC_2AND);
					break;
			case 4: nextInChainBic = pdo.getString(X_CDTR_BIC);
					break; 	
		}
		
		return nextInChainBic;
	}
	
	private BankRout getBankRoutUsingCustCode(PDO pdo, String custCode)
	{
		BankRout bankRout = null;
		Customrs customer = CacheKeys.customrsCCKey.getSingle(custCode);
		
		if (customer != null) bankRout = getBankRout(pdo, customer.getSwiftId());
		
		return bankRout;
	}
	
	/**
	 * method which returns the bank rout profile.
	 * @param pdo
	 * @return
	 */
	private BankRout getBankRout(PDO pdo, String destinationBIC)
	{
		BankRout bankRout = null;
		
		
		
//		retrieve customer record from cache using default office and credit customer's BIC as cache keys.
//		Customrs customer = CacheKeys.customrsBICandOfficeKey.getSingle(officeBic, ServerConstants.DEFAULT_SERVER_OFFICE_NAME);
		
		if (destinationBIC != null)
		{
//			String firstInChainCustCode = customer.getCustCode();
			String paymentCcy = pdo.getString(X_STTLM_CCY);
			String msgType = pdo.getString(P_MSG_TYPE);
			String office = pdo.getString(P_OFFICE);

//			first time use payment office while second time default office should be used.
			for (int i=0; i<2 && bankRout == null; i++)
			{
				String bic = destinationBIC;
				while (bic.length() > 5 && bankRout == null)
				{
	//				bank rout profile should be loaded using office, destination, currency and message type
	//				if failed, try again while message type is null
					bankRout = CacheKeys.bankRoutKey.getSingle(office, bic, paymentCcy, msgType);
					if (bankRout == null && msgType != null ) bankRout = CacheKeys.bankRoutKey.getSingle(office, bic, paymentCcy, null);
					bic = bic.length() == 11 ? bic.substring(0,8) : bic.substring(0, bic.length() - 2);
				}
//				set the office to default office (***) for second iteration 
				office = ServerConstants.DEFAULT_SERVER_OFFICE_NAME;
			}
		}
		
		if (bankRout != null)
		{
			logger.info("Retrieve Correspondent: bank rout record found with uid = {}",bankRout.getUidBankRout());
		}
		
		return bankRout;
		
	}
	
	@Expose
	public Feedback retrieveCountryCorrespondent(String mid)
	{
		PDO pdo = PaymentDataFactory.load(mid);
		
		Feedback feedback = new Feedback();
		
		return retrieveCountryCorrespondent(pdo, feedback);
	}
	
	/**
	 * retrieve the agent BIC from country 
	 * @param pdo
	 * @param feedback
	 * @return
	 */	
	private Feedback retrieveCountryCorrespondent(PDO pdo, Feedback feedback)
	{
		
		feedback.setFailure();
		String paymentCcy = pdo.getString(X_STTLM_CCY);
		String office = pdo.getString(P_OFFICE);
		String countryCode = pdo.getNSetCREDIT_CUSTOMER().getCountrycode();
		logger.info("Retrieve Correspondent: retrieve country correspondent - country code = {}", countryCode);
//		get countryCfg record from cache using credit customer's country code 
		CountryCfg countryCfg = CacheKeys.countryCfgKey.getSingle(countryCode);
		
		if (countryCfg != null)
		{
//			country currency
			String countryCcy = countryCfg.getCurrency();
			logger.info("Retrieve Correspondent: retrieve country correspondent - country currency = {}, payment currency = {}", countryCcy, paymentCcy);
//			continue if country currency equals to payment currency
			if (paymentCcy.equals(countryCcy))
			{
				CountryBu countryBu = CacheKeys.countryBuKey.getSingle(office, countryCode);
				if (countryBu != null)
				{
					logger.info("Retrieve Correspondent: retrieve country correspondent - country currency = {}, payment currency = {}", countryCcy, paymentCcy);
//					Defaultcorbic field may hold multiple BICs separated by comma
					String defaultCorBic = countryBu.getDefaultcorbic();
					
//					If more than one correspondent found, select one randomly
					String agentBic = getRandomBic(defaultCorBic);
					
					if (!GlobalUtils.isNullOrEmpty(agentBic))
					{
						feedback = setNextInChain(pdo, agentBic, feedback);
					}else
					{
						logger.info("Retrieve Correspondent: retrieve country correspondent - defaultCorBic field is empty - failure");
					}
				}
			}else
			{
				logger.info("Retrieve Correspondent: retrieve country correspondent - country currency not equals payment currency - failure");
			}
		}else
		{
			logger.info("Retrieve Correspondent: retrieve country correspondent - country cfg record not found - failure");
		}
		
		return feedback;
		
	}
	
	@Expose
	public Feedback retrieveCurrencyCorrespondent(String mid)
	{
		PDO pdo = PaymentDataFactory.load(mid);
		Feedback feedback = new Feedback();
		
		return retrieveCurrencyCorrespondent(pdo, feedback);
	}
	
	/**
	 * retrieve the agent BIC from currency 
	 * @param pdo
	 * @param feedback
	 * @return
	 */	
	private Feedback retrieveCurrencyCorrespondent(PDO pdo, Feedback feedback)
	{
		
		String office = pdo.getString(P_OFFICE);
		String paymentCcy = pdo.getString(X_STTLM_CCY);
		
		logger.info("Retrieve Correspondent: retrieve currency correspondent - office = {}, payment ccy = {}", office, paymentCcy);
//		get currency record from cache using payment office and currency
		CurrencyBu currencyBu = CacheKeys.currencyBuKey.getSingle(office, paymentCcy);

		if (currencyBu!=null)
		{
			logger.info("Retrieve Correspondent: retrieve currency correspondent - currency_bu uid = {}", currencyBu.getUidCurrencyBu());
//			Defaultnostrobic field may hold multiple BICs separated by comma
			String defaultNostroBic = currencyBu.getDefaultnostrobic();
			
//			If more than one correspondent found, select one randomly
			String agentBic = getRandomBic(defaultNostroBic);
			
			if (!GlobalUtils.isNullOrEmpty(agentBic))
			{
				feedback = setNextInChain(pdo, agentBic, feedback);
			}else
			{
				logger.info("Retrieve Correspondent: retrieve currency correspondent - defaultNostroBic field is empty - failure");
			}
		}else
		{
			logger.info("Retrieve Correspondent: retrieve currency correspondent - currency_bu record not found - failure");
		}
		
		
		
		return feedback;
	}

	
	private String getRandomBic(String commaSeparatedBICs)
	{
		String agentBic = null;
		
		if (!GlobalUtils.isNullOrEmpty(commaSeparatedBICs))
		{
			logger.info("Retrieve Correspondent: comma separated BIC field = {}", commaSeparatedBICs);
			if (commaSeparatedBICs.indexOf(",") == -1)
			{
				agentBic = commaSeparatedBICs; 
			}else
			{
				String[] defaultAgentBicArr = commaSeparatedBICs.split(",");
				int randomIndex = m_generator.nextInt(defaultAgentBicArr.length);
				
				agentBic = defaultAgentBicArr[randomIndex].trim();
			}
			
			logger.info("Retrieve Correspondent: randomly selected BIC = {}", agentBic);
		}			
		
		
		return agentBic;
	}
	
	/**
	 * Once the correspondent chain is built and the party (1st in credit chain/Provisional Receiver) can be reached (passed MOP selection) 
	 * GPP will identify the transfer method - Serial or Direct & Cover. 
	 *	
	 *	The process of transfer method identification is performed in a loop starting from the party closest to the beneficiary. 
	 *	If it fails, the service will perform the same steps on the next party and the next until it reaches the party closest to us (1st in chain)
     *
	 * @param mid
	 * @return
	 */
	@Expose
	public Feedback performTransferMethodIdentification(String mid, Boolean isBankRoutServiceExecuted) throws Exception
	{
		Feedback feedback = new Feedback();
		PDO pdo = PaymentDataFactory.load(mid);
		
		boolean isCdtMopBook = MessageConstantsInterface.MOP_BOOK.equals(pdo.getString(PDOConstantFieldsInterface.P_CDT_MOP));
		
		if (!isCdtMopBook)
		{
			logger.info("Transfer Method Identification: mid = {}", mid);
			
			
//			if (pdo.getString(PDOConstantFieldsInterface.P_MSG_TYPE).equals("SWIFT_202COV"))
//			{
//				pdo.set(PDOConstantFieldsInterface.MU_TRANSFER_METHOD, MessageConstantsInterface.MONITOR_FLAG_FORCE);
//			}
			
			
			String transferMethod = pdo.getString(PDOConstantFieldsInterface.P_TRANSFER_METHOD);
	//		not forced by the user or transfer method not in ('C', 'S') 
			if (!pdo.getString(PDOConstantFieldsInterface.MU_TRANSFER_METHOD).equals(MessageConstantsInterface.MONITOR_FLAG_FORCE)
					|| !(TransferMethodType.C.name().equals(transferMethod) && !TransferMethodType.S.name().equals(transferMethod)) )
			{
		//		reset the logical field
				pdo.set(P_TRANSFER_METHOD, (String)null);
			}
			transferMethod = null;
			ChainType[] chainTypeArr = FindFirstInChainConstants.ChainType.arrFirstInCreditChainType;
	//		loop until feedback is successful and transfer method not found and next in credit chain bic exist
			BankRout bankRout = null;
			if (isBankRoutServiceExecuted) bankRout = pdo.getBankRout() != null ? pdo.getBankRout() : getBankRout(pdo, pdo.getNSetCREDIT_CUSTOMER().getSwiftId());
			MessageChainsData.ChainData forwardInCreditCahin;
			MessageChainsData.ChainData nextInCreditChain;
			MessageChainsData.ChainData prevInCreditChain;
			Admin admin = Admin.getContextAdmin();
			isBankRoutServiceExecuted = isBankRoutServiceExecuted == null ? false : isBankRoutServiceExecuted;
			boolean shouldContinue = true;
			int i = 3;
			int chainIndex = pdo.getInteger(D_CHAIN_INDEX);
//			if the first in credit chain is 'Creditor' (59 or 58) then transfer method should be 'S'
			if (chainIndex > i)
			{
				pdo.set(PDOConstantFieldsInterface.P_TRANSFER_METHOD, TransferMethodType.S.name());
			}else
			{
			
				for (; i >= chainIndex
				     && feedback.isSuccessful() && shouldContinue ; i--)
				{
					forwardInCreditCahin = isBankRoutServiceExecuted ? null : m_paymentServicesLogging.getCreditChainData(admin, i+1);
					nextInCreditChain =    isBankRoutServiceExecuted ? pdo.getCreditChainData(chainTypeArr[i]) : m_paymentServicesLogging.getCreditChainData(admin, i); 
					prevInCreditChain =(i > 0) ? isBankRoutServiceExecuted ? pdo.getCreditChainData(chainTypeArr[i-1]) : m_paymentServicesLogging.getCreditChainData(admin, i-1) : null;
					
//						get transfer method
					shouldContinue = findTransferMethod(pdo, forwardInCreditCahin, nextInCreditChain, prevInCreditChain, i, bankRout, isBankRoutServiceExecuted, feedback);
				}
			}
				
			transferMethod = pdo.getString(PDOConstantFieldsInterface.P_TRANSFER_METHOD);
	//		if feedback is successful and transfer method found, update PDO
			if (feedback.isSuccessful() && !GlobalUtils.isNullOrEmpty(transferMethod))
			{
				logger.info("Transfer Method Identification: transfer method found: = {}", transferMethod);
			}else
			{
				logger.info("Transfer Method Identification: failure in finding thransfer method");
			}
		
		}		
		return feedback;
	}
	
	private boolean findTransferMethod(PDO pdo, MessageChainsData.ChainData forwardInCreditChain, MessageChainsData.ChainData nextInCreditChain
			,MessageChainsData.ChainData prevInCreditChain, int index, BankRout bankRout, boolean isBankRoutServiceExecuted,Feedback feedback)
	{
		String method=pdo.getString(PDOConstantFieldsInterface.P_TRANSFER_METHOD);
		String firstInCreditChain = pdo.getString(D_FIRST_IN_CDT_CHAIN_BIC); 
		String bankRoutAgent = pdo.getString(D_BANK_ROUT_AGENT);
		String bankRoutTransferMethod = bankRout != null ? bankRout.getTransferMethod() : "";
//		boolean isMsgType202COV = pdo.getString(PDOConstantFieldsInterface.P_MSG_TYPE).equals("SWIFT_202COV");
		boolean isManuallyForced = pdo.getString(PDOConstantFieldsInterface.MU_TRANSFER_METHOD).equals(MessageConstantsInterface.MONITOR_FLAG_FORCE);
		boolean shouldContinue = true;
		int iChainIndex = pdo.getInteger(D_CHAIN_INDEX);

		if (nextInCreditChain != null && nextInCreditChain.getChainTypeOrigin() == ChainTypeOrigin.BIC)
		{
			String inspectedParty = nextInCreditChain.getValue();
			boolean shouldOverrideUserTransferMethod = GlobalConstants.Yes.equals(
					CacheKeys.SystParKey.getSingleParmValue(pdo.getString(PDOConstantFieldsInterface.P_OFFICE), 
							SystemParametersInterface.SYST_PARAM_OVER_USER_TRANSF_METHOD));
			if(logger.isInfoEnabled()){
				logger.info("Transfer Method Identification: first in credit chain  = {}, inspected party = {} and should override user transfer method flag is {}" 
						,new Object[]{
						firstInCreditChain,
						inspectedParty,
						shouldOverrideUserTransferMethod
						});
			}
	//		If the inspected party is the closest party to us (1st in chain) then the transfer method is Serial
			if (index == iChainIndex)
			{
				if (isManuallyForced && TransferMethodType.C.name().equals(method) && !shouldOverrideUserTransferMethod)
				{
					ProcessError pError=new ProcessError(ProcessErrorConstants.UserHadSelectedManuallyCoverMethod);
			        configureErrorFeedback(pError.getErrorCode(),pError.getDescription(),feedback);
			        ErrorAuditUtils.setErrors(pError,pdo.getIsHistory());
				}else 
				{
					method = TransferMethodType.S.name();
					logger.info("Transfer Method Identification: first in credit chain  = {} equals inspected party = {} therefore transfer method = S" 
							, firstInCreditChain, inspectedParty);
				}
			}
			
			if (feedback.isSuccessful() && !isManuallyForced && GlobalUtils.isNullOrEmpty(method))
			{
				// if inspected party equals to bank rout agent or previous inspected party is BIC and equals to bank rout agent
				boolean isInspectedPartyOrPrevBicAndEqualsToBankRoutOrPrev = false;
				
				if (isBankRoutServiceExecuted)
				{
					// if inspected party equals to bank rout agent or previous inspected party is BIC and equals to bank rout agent
					isInspectedPartyOrPrevBicAndEqualsToBankRoutOrPrev = (   inspectedParty.equals(bankRoutAgent)
									|| ( prevInCreditChain != null && prevInCreditChain.getChainTypeOrigin() == ChainTypeOrigin.BIC && prevInCreditChain.getValue().equals(bankRoutAgent))	);
				}else 
				{
//					Per our discussion today here by is the detailed instruction - In the place where you check if the party in the chainIndex is a BIC and is equal to the 
//					D_BANK_ROUT_AGENT need to check against only if Bank rout was perform during this process. In the case it was not perform then need to check if we have a bank rout 
//					entry with the Destination cust_code equal the cust_code of the (chainIndex + 1) and the Agent cust_code equal the cust_code of this chainIndex. The second IF that 
//					refer to D_BANK_ROUT_AGENT is by comparing it to the BIC in the (chainIndex - 1), in that case we need to check if it is BIC and we have a bank rout entry 
//					with the Destination cust_code equal the cust_code of the (chainIndex) and the Agent cust_code equal the cust_code of this chainIndex - 1.
//					In order to be able to check the chain cust_code you need to call Asaf new method to retrieve the cust_code of the specific chain.    

					Customrs customer;
					if (forwardInCreditChain != null)
					{
						bankRout = getBankRoutUsingCustCode(pdo, forwardInCreditChain.getCustCode());
						if (bankRout != null)
						{
							customer = CacheKeys.customrsCCKey.getSingle(bankRout.getAgent());
							isInspectedPartyOrPrevBicAndEqualsToBankRoutOrPrev = customer != null && nextInCreditChain.getValue().equals(customer.getSwiftId());
						}
					}
					
					if (!isInspectedPartyOrPrevBicAndEqualsToBankRoutOrPrev && prevInCreditChain != null && prevInCreditChain.getChainTypeOrigin() == ChainTypeOrigin.BIC)
					{
						bankRout = getBankRoutUsingCustCode(pdo, nextInCreditChain.getCustCode());
						if (bankRout != null)
						{
							customer = CacheKeys.customrsCCKey.getSingle(bankRout.getAgent());
							isInspectedPartyOrPrevBicAndEqualsToBankRoutOrPrev = customer != null && prevInCreditChain.getValue().equals(customer.getSwiftId());
						}
						
					}
					
					if (isInspectedPartyOrPrevBicAndEqualsToBankRoutOrPrev) bankRoutTransferMethod = bankRout.getTransferMethod();
				}
					
					
				if (isInspectedPartyOrPrevBicAndEqualsToBankRoutOrPrev)
				{
					if ((TransferMethodType.C.name().equals(bankRoutTransferMethod) || TransferMethodType.S.name().equals(bankRoutTransferMethod)))
					{
						method = bankRoutTransferMethod;
						if(logger.isInfoEnabled()){
							logger.info("Transfer Method Identification: inspected party: {} equals bank rout agent: {} and transfer method = bank rout transfer method = {} " 
																,new Object[]{ 
																inspectedParty,
																bankRoutAgent, 
																bankRoutTransferMethod
																});
						}
					}
				}
			}
			
			if (feedback.isSuccessful() && GlobalUtils.isNullOrEmpty(method))
			{
				if(logger.isInfoEnabled()){
					logger.info("Transfer Method Identification: inspected party = {}, bank rout agent = {} and bank rout transfer method = {}. Get transfer method profile " 
							,new Object[]{
							inspectedParty,
							bankRoutAgent,
							bankRoutTransferMethod
							});
				}
	//			If the next party in the chain was not derived from the Bank Routing table, or it was derived from the Bank 
	//			Routing table but no method was provided in that entry (Transfer method = Transfer Method Profile), derive the method from the Transfer Method Profile
				CountryCurrency countryCurrency = getCountryCourency(pdo,nextInCreditChain.getCountryCode());
				
	//			if transfer method profile found, update the transfer method
				if (countryCurrency != null)
				{
					method = countryCurrency.getTransferMethod();
					logger.info("Transfer Method Identification: transfer method found in transfer method profile and equlas to {}", method);
				}
				
			}
			
			if (feedback.isSuccessful() && !GlobalUtils.isNullOrEmpty(method) && method.equals(TransferMethodType.S.name()) && index != iChainIndex && !isManuallyForced)
			{
				boolean isDirectCvrOverride = (pdo.getNSetDEBIT_CUSTOMER()!=null && pdo.getNSetDEBIT_CUSTOMER().getDirectCvrOverride() != null) ? pdo.getNSetDEBIT_CUSTOMER().getDirectCvrOverride() : false;
				
				if (isDirectCvrOverride)
				{
					method = TransferMethodType.C.name();
					logger.info("Transfer Method Identification: transfer method = 'S' and direct cvr override flag in debit customer is true, therefore, transfer method is 'C'");
				}
			}
			
	//		If the method was identified as Serial, further validate that all parties were mapped into the payment. 
	//		If not (X_INSTD_AGT_BIC_2AND is not null) then send the payment to a manual queue
	
			if (feedback.isSuccessful() && !GlobalUtils.isNullOrEmpty(method) && method.equals(TransferMethodType.S.name())) 
					
			{
				shouldContinue = false;
				//22/12/12 - Galit : A new condition was added : (pdo.isEnrichMode()) to avoid running this validation in case of OSN after an ACK was
				// received on the matched OPI. According to Liat - We want to execute this validation only in case of Enrich.
				if ((pdo.get(X_INSTD_AGT_BIC_2AND) != null)&&(pdo.isEnrichMode()))
				{
		            ProcessError pError=new ProcessError(ProcessErrorConstants.CannotSendSerialMethod);
		            configureErrorFeedback(pError.getErrorCode(),pError.getDescription(),feedback);
		            ErrorAuditUtils.setErrors(pError,pdo.getIsHistory());
		            logger.info("Transfer Method Identification: transfer method = 'S' and not all parties were mapped into the payment - error");
				}
			}
	//		If the method was identified as Cover the service will further validate that a direct payment can be sent to closest to beneficiary party (inspected party). 
	//		This will be done by performing RMA check for the party inspected		
			if (feedback.isSuccessful() && !GlobalUtils.isNullOrEmpty(method) && method.equals(TransferMethodType.C.name()))
			{
				String correspondent = CacheKeys.customrsKey.getSingle(pdo.getNSetOffice().getCustCode(), pdo.getString(P_OFFICE)).getSwiftId();
				Date processDate = pdo.getDate(P_PROC_DT);
				String mop = MOP_SWIFT; //pdo.getString(P_CDT_MOP);
				if(logger.isInfoEnabled()){
					logger.info("Transfer Method Identification: transfer method = 'C' perform RMA validation with issuer ={}, correspondent ={} and process date ={}"
							,new Object[]{
							inspectedParty, correspondent, processDate
							});
				}
				String issuer = inspectedParty.length() > 8 ? inspectedParty.substring(0, 8) : inspectedParty;
				correspondent = correspondent.length() > 8 ? correspondent.substring(0, 8) : correspondent;
	//			using temporary feedback for RMA because RMA failure should not stop the flow but continue to next in credit chain.
				Feedback rmaFeedback = BOProxies.m_mopSelectionLogging.performRmaValidation(Admin.getContextAdmin(), pdo.getMID(), issuer, correspondent, processDate, mop);
				
				if (!rmaFeedback.isSuccessful())
				{
					if (!isManuallyForced)
					{
						method = null;
					}else
					{
						shouldContinue = true;
					}
					
					logger.info("Transfer Method Identification: RMA validation failure...");
				}else
				{
					pdo.set(D_DIRECT_RECEIVER, inspectedParty);
					pdo.set(D_DIRECT_RECEIVER_INDEX, index+"");
					shouldContinue = false;
					logger.info("Transfer Method Identification: RMA validation successful method remains 'C'");
				}
			}
			pdo.set(PDOConstantFieldsInterface.P_TRANSFER_METHOD, method);
			
			
				
				
		}
		
		
		
		return GlobalUtils.isNullOrEmpty(method) || shouldContinue;
	}
	
	
	private CountryCurrency getCountryCourency(PDO pdo, String countryCode)
	{
		String office = pdo.getString(P_OFFICE);
		String paymentCcy = pdo.getString(X_STTLM_CCY);
		CountryCurrency countryCurrency = null;
		if(logger.isInfoEnabled()){
			logger.info("Transfer Method Identification: find transfer method profile with office ={}, currency ={} and country code={} "
					,new Object[]{ 
					office,
					paymentCcy,
					countryCode});
		}
//		derive the method from the Transfer Method Profile in the following order:
//		o	By currency (of the payment) and country (of the party being inspected)
//		o	By currency only (i.e. an entry with the currency but with no country)
//		o	By country only (i.e. an entry with the country but with no currency)

		int i=0;
		while (i<3 && countryCurrency == null)
		{
			switch(i)
			{
				case 0: countryCurrency = CacheKeys.countryCurrencyKey.getSingle(office, paymentCcy, countryCode);
						break;
				case 1: countryCurrency = CacheKeys.countryCurrencyKey.getSingle(office, paymentCcy, ServerConstants.EMPTY_STRING);
						break;
				case 2: countryCurrency = CacheKeys.countryCurrencyKey.getSingle(office, ServerConstants.EMPTY_STRING, countryCode);
						break;
			
			}
			i++;
		}
		
		if (countryCurrency != null)
		{
			logger.info("Transfer Method Identification: transfer method profile found with uid = {}", countryCurrency.getUidCountryCurrency());
		}else
		{
			logger.info("Transfer Method Identification: transfer method profile not found ");
		}
		return countryCurrency;
	}
	
	
	/**
	 * This service will be responsible to generate the Direct out of the Payment that was transformed to Cover message
	 * @param mid
	 * @return
	 */
	@Expose
	public Feedback generateDirectMessage(String mid)
	{
		logger.info("Generate Direct Message: mid = {} ", mid);
		Feedback feedback = new Feedback();
		PDO pdo = PaymentDataFactory.load(mid);
		String transferMethod = pdo.getString(P_TRANSFER_METHOD);
		
		boolean isTransferMethodCover = transferMethod !=null && transferMethod.equals(TransferMethodType.C.name()) ? true : false;
		boolean isDirectCoverGenerated = pdo.getString(MF_DIRECT_COVER_GENERATED).equals(MONITOR_FLAG_GENERATED);
		
		String sP_MSG_CLASS = pdo.getString(P_MSG_CLASS);
		
		logger.info("Generate Direct Message: transfer method = {}, direct cover generated monitor flag = {} "
				, transferMethod, pdo.getString(MF_DIRECT_COVER_GENERATED));
		
		if(isTransferMethodCover && !isDirectCoverGenerated && MSG_CLASS_OSN.equals(sP_MSG_CLASS))
		{
				//  Call generic Transaction Generation service with type 'Cover^Direct'. 
	  		SimpleResponseDataComponent generateTransactionResponse = BOProxies.m_generateTransactionLogging.generateRelatedTransaction(Admin.getContextAdmin(), mid, RELATION_TYPE_COVER, RELATION_TYPE_DIRECT);
			  
		    feedback = generateTransactionResponse.getFeedback();
		    Object[] arrData = generateTransactionResponse.getDataArray();	  	    
		      
		    if(feedback.isSuccessful() && arrData != null && arrData.length > 0 && !GlobalUtils.isNullOrEmpty((String)arrData[0]))
		    {	  	    	
		    	pdo.promoteToPrimary();
		    	
		    	try
		    	{
		    		// Sets the MF_DIRECT_COVER_GENERATED to be 'G' for the COVER message.
		    		pdo.set(MF_DIRECT_COVER_GENERATED, MONITOR_FLAG_GENERATED);
		    		
		    		// Sets the direct payment MID to be the primary one. 
		    		pdo.promoteLinkedToPrimary(RELATION_TYPE_DIRECT);
		    		
		    		PDO pdoDirectPayment = pdo.getLinkedMsg(RELATION_TYPE_DIRECT);
		    		
		    		// Sets the MF_DIRECT_COVER_GENERATED to be 'G' for the DIRECT message.
		    		pdoDirectPayment.set(MF_DIRECT_COVER_GENERATED, MONITOR_FLAG_GENERATED);

			    	String directGeneratedMid = (String)arrData[0];
			    	logger.info("Generate Direct Message: transaction generation service successful, direct generated mid = {}", directGeneratedMid);

			    	// Copy data from old direct message to new direct message
			    	
			    	pdoDirectPayment.setListMSGERR(pdo.getListMSGERR());
			    	if(pdo.countOccurrences(X_INSTR_NXT_AGT_OTHER_CODES)>0){
				    	pdoDirectPayment.setPaymentField(pdo.getField(X_INSTR_NXT_AGT_OTHER_CODES));
					}
			    	if(StringUtils.isNotEmpty(pdo.getString(P_MSG_SUB_TYPE))){
			    		pdoDirectPayment.set(P_MSG_SUB_TYPE, pdo.getString(P_MSG_SUB_TYPE));
			    	}	
			    	
			    	// NAGE specific
			    	if (pdo.isEnrichMode()) 	pdoDirectPayment.setEnrichMode();
			    	if (pdo.isThrottlingMode())	pdoDirectPayment.setThrottlingMode();
			    	
			    	pdoDirectPayment.set(P_PMNT_SRC, pdo.getString(P_PMNT_SRC));
			    	pdoDirectPayment.set(MI_HOST_PROCESSING, pdo.getString(MI_HOST_PROCESSING));
			    	pdoDirectPayment.set(X_MSG_USER_REF, pdo.getString(X_MSG_USER_REF)); // From XO_MSG_USER_REF?
			    	pdoDirectPayment.set(P_DUPLICATE_INDEX, pdo.getString(P_DUPLICATE_INDEX));
			    	
			    	//copy newjournal list from old direct
			    	List<Newjournal> newDirectNewJournalList = new ArrayList<Newjournal>();
			    	newDirectNewJournalList.addAll(pdo.getListNEWJOURNAL());
			    	//if there are journal messages with complete sts, change their sts to received 
			    	for (Newjournal j : newDirectNewJournalList){
			    		if (MESSAGE_STATUS_COMPLETE.equals(j.getStatus())){
			    			j.setStatus(MESSAGE_STATUS_RECEIVED);
			    		}
			    	}
			    	pdoDirectPayment.setListNEWJOURNAL(newDirectNewJournalList);			    				    	
			    	
			    	// ASAF: for now - 01/12/2009 - assumes that we're on the same JVM, thus calls the propagate method as follows:
					  // 1) 'bRemovePDOFromLocalCache' as false.
					  // 2) 'bSameJVM' as true.
			    	CacheKeys.ProcessSessionsKey.propagate(false, true);
			    	
			    	
			    	// Invokes the flow Selector with the direct generated PDO; will execute the 'BONonAccountingDirectFlow.executeNonAccountingDirectFlow' method.
			    	// Note: No need to assign the returned feedback with this process' returned feedback; in case of failure,
			    	//       the user will have to open the direct payment using the link from the cover payment and fix it.
	          		BOProxies.m_businessFlowSelectorLogging.executeFlow(Admin.getContextAdmin(), directGeneratedMid, false, ServerConstants.EMPTY_OBJECT_ARRAY);
			    
			    	CacheKeys.ProcessSessionsKey.apply();

			    	
			    	// Sets back the main payment MID to be the primary one.
			    	pdo.promoteToPrimary();
			    	
			    	// NAGE PPC - do not send out cover message (this message was a direct message, but it was transformed into a cover) 
			    	// since another cover is generated in PEGA.
			    	if (pdo.isEnrichMode() || pdo.isThrottlingMode()){
			    		pdo.set(P_MSG_STS, MESSAGE_STATUS_CANCELED);
			    		pdo.set(X_MSG_USER_REF, "");
						pdo.set(P_RELEASE_INDEX, "");	
			    		pdo.setListMFAMILY(null);
			    		feedback.setFailure();
			    	}

		    	}
		    	catch(Exception e)
		    	{
		    		ExceptionController.getInstance().handleException(e, this);
		    		pdo.promoteToPrimary();
		    	}
		    }
		    
		    else
		    {
		    	// If no related MID was generated then insert message error and return with failure
		        ProcessError pError=new ProcessError(ProcessErrorConstants.GenerateTransactionFailed, new Object[]{mid, 
		    			                                   RELATION_TYPE_COVER, RELATION_TYPE_DIRECT});
		        configureErrorFeedback(pError.getErrorCode(),pError.getDescription(),feedback);
		        ErrorAuditUtils.setErrors(pError,pdo.getIsHistory());
		        logger.info("Generate Direct Message: transaction generation service failed");	
		    }
		}
		else
		{
			logger.info("Generate Direct Message: exiting the service without generation...");
		}
		
		return feedback;
	}
	
}
