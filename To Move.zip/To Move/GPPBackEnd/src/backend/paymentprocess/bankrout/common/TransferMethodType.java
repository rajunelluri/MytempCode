package backend.paymentprocess.bankrout.common;

public enum TransferMethodType 
{
	S,C,D;
}
