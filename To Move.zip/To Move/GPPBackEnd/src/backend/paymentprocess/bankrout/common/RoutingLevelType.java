package backend.paymentprocess.bankrout.common;

public enum RoutingLevelType 
{
	EMPTY, RECEIVER, COUNTRY, CURRENCY;

}
