package backend.paymentprocess.bankrout.ejb;

import javax.ejb.Stateless;
import backend.core.SuperSLSB;
import com.fundtech.core.security.Admin;
import backend.businessobject.proxies.interceptors.InterceptorSetType;
import backend.paymentprocess.bankrout.businessobjects.BOBankRout;
import backend.paymentprocess.bankrout.ejbinterfaces.BankRoutLocal;
import backend.paymentprocess.bankrout.ejbinterfaces.BankRout;

@Stateless
public class BankRoutBean extends SuperSLSB<BankRout> implements BankRoutLocal, BankRout{
	
	public BankRoutBean() { super(backend.paymentprocess.bankrout.businessobjects.BOBankRout.class, InterceptorSetType.Complete) ; }//EOM
	
	
	public com.fundtech.datacomponent.response.Feedback retrieveCorrespondent(final Admin admin, java.lang.String mid ) {
		return this.m_bo.retrieveCorrespondent(admin, mid ) ;
	}//EOM

	public com.fundtech.datacomponent.response.Feedback retrieveReceiversCorrespondent(final Admin admin, java.lang.String mid ) {
		return this.m_bo.retrieveReceiversCorrespondent(admin, mid ) ;
	}//EOM

	public com.fundtech.datacomponent.response.Feedback retrieveCountryCorrespondent(final Admin admin, java.lang.String mid ) {
		return this.m_bo.retrieveCountryCorrespondent(admin, mid ) ;
	}//EOM

	public com.fundtech.datacomponent.response.Feedback retrieveCurrencyCorrespondent(final Admin admin, java.lang.String mid ) {
		return this.m_bo.retrieveCurrencyCorrespondent(admin, mid ) ;
	}//EOM

	/** 
	 * Once the correspondent chain is built and the party (1st in credit chain/Provisional Receiver) can be reached (passed MOP selection) 
	 * GPP will identify the transfer method - Serial or Direct & Cover. 
	 * The process of transfer method identification is performed in a loop starting from the party closest to the beneficiary. 
	 * If it fails, the service will perform the same steps on the next party and the next until it reaches the party closest to us (1st in chain)
	 * @param mid
	 * @return
	 */
	public com.fundtech.datacomponent.response.Feedback performTransferMethodIdentification(final Admin admin, java.lang.String mid, java.lang.Boolean isBankRoutServiceExecuted ) throws java.lang.Exception {
		return this.m_bo.performTransferMethodIdentification(admin, mid, isBankRoutServiceExecuted ) ;
	}//EOM

	/** 
	 * This service will be responsible to generate the Direct out of the Payment that was transformed to Cover message
	 * @param mid
	 * @return
	 */
	public com.fundtech.datacomponent.response.Feedback generateDirectMessage(final Admin admin, java.lang.String mid ) {
		return this.m_bo.generateDirectMessage(admin, mid ) ;
	}//EOM

}//EOC