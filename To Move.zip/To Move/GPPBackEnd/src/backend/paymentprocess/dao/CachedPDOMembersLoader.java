package backend.paymentprocess.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.dataaccess.dao.DAOBasic;
import backend.dataaccess.dto.DTOSingleValue;
import backend.paymentprocess.commons.MessageUtils;
import backend.paymentprocess.currencyconversion.dao.DAOCurrencyConversion;
import backend.paymentprocess.matchingcheck.businessobjects.BOMatchingCheck;
import backend.paymentprocess.matchingcheck.output.MatchingCheckOutputData;
import backend.util.ServerConstants;

import com.fundtech.cache.entities.AccountAdditionalOwners;
import com.fundtech.cache.entities.AccountDailyBalances;
import com.fundtech.cache.entities.AccountDailyBalancesId;
import com.fundtech.cache.entities.Accounts;
import com.fundtech.cache.entities.Banks;
import com.fundtech.cache.entities.BatchSubset;
import com.fundtech.cache.entities.BulkingProfile;
import com.fundtech.cache.entities.CurrencyBu;
import com.fundtech.cache.entities.Customrs;
import com.fundtech.cache.entities.FileSummary;
import com.fundtech.cache.entities.Mandate;
import com.fundtech.cache.entities.MatchingCheck;
import com.fundtech.cache.entities.MessageStpRules;
import com.fundtech.cache.entities.Mop;
import com.fundtech.cache.entities.MsgFees;
import com.fundtech.cache.entities.MsgParties;
import com.fundtech.cache.entities.MsgSpecialInstructions;
import com.fundtech.cache.entities.MsgStopFlags;
import com.fundtech.cache.entities.MsgTypes;
import com.fundtech.cache.entities.Msgerr;
import com.fundtech.cache.entities.Newjournal;
import com.fundtech.cache.entities.RateUsage;
import com.fundtech.cache.entities.SlaProfile;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.general.StatementParameter;
import com.fundtech.core.paymentprocess.currencyconversion.MessageRatesInputData;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.scl.commonTypes.CycleSttlmLineType;
import com.fundtech.scl.commonTypes.ExchrateRtrLineType;
import com.fundtech.scl.commonTypes.ForwardContractLineType;
import com.fundtech.scl.commonTypes.MFamilyLineType;
import com.fundtech.scl.commonTypes.MsgNotesLineType;
import com.fundtech.util.ExceptionController;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalDateTimeUtil;
import com.fundtech.util.GlobalUtils;


/**
 * 
 * May 20, 2008
 * CachedPDOMembersLoader.java
 * @author guys
 * 
 * Intermediary class to host the various PDO cached members load until
 * the time when their final location is determined 
 *
 */
public class CachedPDOMembersLoader implements PDOConstantFieldsInterface 
{
    private static DAOBasic m_daoBasic=new DAOBasic();
    private static final Logger logger = LoggerFactory.getLogger(CachedPDOMembersLoader.class);
    /**
     * 
     * May 20, 2008
     * guys
     *
     * @param pdo
     * @return entry for office 'BC1'
     */
    public static final Banks loadOffice(final PDO pdo) { 
        return CacheKeys.banksKey.getSingle(pdo.getString(P_OFFICE));
    }//EOM 
    
    /**
     * 
     * May 20, 2008
     * guys
     *
     * @param pdo
     * @return entry for office 'BC1' and currency 'GBP' 
     */
    public static final CurrencyBu loadCreditCurrency(final PDO pdo) { 
        return CacheKeys.currencyBuKey.getSingle(pdo.getString(P_OFFICE)
                , pdo.getString(P_CDT_ACCT_CCY))    ; 
    }//EOM 
    
    /**
     * 
     */
    public static final MessageStpRules loadMessageStpRules(final PDO pdo) { 
        return CacheKeys.messageStpRulesKey.getSingle(pdo.getString(P_PAYMENT_TP))    ;
    }//EOM 
    
    /**
     * 
     */
    public static final SlaProfile loadOfficeGenericSla(final PDO pdo) { 
        return CacheKeys.slaKey.getSingle(pdo.getString(P_OFFICE), pdo.getString(P_OFFICE_SLA))    ;
    }//EOM 
    
    /**
     * 
     */
    public static final SlaProfile loadDebitSla(final PDO pdo) { 
        return CacheKeys.slaKey.getSingle(pdo.getString(P_OFFICE), pdo.getString(P_DBT_SLA))    ;
    }//EOM 
    
    /**
     * 
     */
    public static final SlaProfile loadCreditSla(final PDO pdo) { 
        return CacheKeys.slaKey.getSingle(pdo.getString(P_OFFICE), pdo.getString(P_CDT_SLA))    ;
    }//EOM
    
    /**
     * 
     */
    public static final MsgTypes loadOrigMsgType(final PDO pdo) { 
        return CacheKeys.msgTypesKey.getSingle(pdo.getString(P_ORIG_MSG_TYPE), pdo.getString(P_ORIG_MSG_SUB_TYPE))    ;
    }//EOM     
    
    /**
     * 
     */
    public static final MsgTypes loadMsgType(final PDO pdo) { 
        return CacheKeys.msgTypesKey.getSingle(pdo.getString(P_MSG_TYPE), pdo.getString(P_MSG_SUB_TYPE))    ;
    }//EOM         

    /**
     * 
     * May 20, 2008
     * guys
     *
     * @param pdo
     * @return entry for office 'BC1' and currency 'EUR' 
     */
    public static final CurrencyBu loadDebitCurrency(final PDO pdo) { 
        return CacheKeys.currencyBuKey.getSingle(pdo.getString(P_OFFICE)
                , pdo.getString(P_DBT_ACCT_CCY))    ; 
    }//EOM 
    
    /**
     * 
     * May 20, 2008
     * guys
     *
     * @param pdo
     * @return entry for office 'BC1' and mop 'DDEBIT' 
     */
    public static final Mop loadCreditMop(final PDO pdo) { 
        return CacheKeys.mopKey.getSingle(pdo.getString(P_OFFICE)
                , pdo.getString(P_CDT_MOP))    ; 
    }//EOM 
    
    /**
     * 
     * May 20, 2008
     * guys
     */
    public static final Mop loadDebitMop(final PDO pdo) { 
        return CacheKeys.mopKey.getSingle(pdo.getString(P_OFFICE)
                , pdo.getString(P_DBT_MOP))    ; 
    }//EOM 
    
    /**
     * 
     */
    public static final MatchingCheck loadMatchingCheck(final PDO pdo, String sRuleSubType) 
    {
    	MatchingCheck matchingCheck = null;
    	
    	try
    	{
    		MatchingCheckOutputData matchingCheckOutputData = new MatchingCheckOutputData();
    		matchingCheck = BOMatchingCheck.getMatchingCheckProfile(pdo, sRuleSubType, matchingCheckOutputData);
    	}
    	catch(Exception e)
    	{
    		ExceptionController.getInstance().handleException(e, CachedPDOMembersLoader.class);
    	}
    	
    	return matchingCheck;
    }//EOM 

    /**
     * 
     * May 20, 2008
     * guys
     *
     * @param pdo
     * @return entry for office 'BC1' and currency 'USD' 
     */
    public static final CurrencyBu loadInstructionCurrency(final PDO pdo) { 
//    	TODO instruction currency loaded from OX_STTLM_CCY is for SYBOS
    	String currency = GlobalUtils.isNullOrEmpty(pdo.getString(X_STTLM_CCY)) ? pdo.getString(OX_STTLM_CCY) : pdo.getString(X_STTLM_CCY);
        return CacheKeys.currencyBuKey.getSingle(pdo.getString(P_OFFICE)
                , currency)    ; 
    }//EOM 
    
    /**
     * 
     * May 20, 2008
     * guys
     *
     * @param pdo
     * @return for UID_CUSTOMRS = 'XXXSAHABBPKKA166'
     */
    public static final Customrs loadCreditCustomer(final PDO pdo) { 
        return CacheKeys.customrsKey.getSingle(pdo.getString(P_CDT_CUST_CD), pdo.getString(P_OFFICE))   ;
    }//EOM 
    
    public static final Customrs loadOriginalSender(final PDO pdo)
    {
    	return CacheKeys.customrsBICandOfficeKey.getSingle(pdo.getString(OX_INSTG_AGT_BIC_2AND), pdo.getString(P_OFFICE));
    }
    
    /**
     * 
     * May 20, 2008
     * guys
     *
     * @param pdo
     * @return for UID_CUSTOMRS = 'XXXSAHABBPKKA166'
     */
    public static final Customrs loadDebitCustomer(final PDO pdo) { 
        return CacheKeys.customrsKey.getSingle(pdo.getString(P_DBT_CUST_CD), pdo.getString(P_OFFICE))   ;
    }//EOM 
    
    /**
     * 
     */
    public static final Customrs loadOfficeCustomer(final PDO pdo) { 
    	final Banks customerOffice = pdo.getNSetOffice() ; 
    	return (customerOffice == null ? null : CacheKeys.customrsKey.getSingle(customerOffice.getCustCode(), pdo.getString(P_OFFICE)) ) ; 
    }//EOM     
    
    /**
     * 
     */
    public static final RateUsage loadBaseRateUsage(final PDO pdo) 
    { 
    	return CacheKeys.rateUsageKey.getSingle(pdo.getString(P_BASE_RATE_USAGE_NM) ) ; 
    }     

    /**
     * 
     */
    public static final RateUsage loadDebitRateUsage(final PDO pdo) 
    { 
    	return CacheKeys.rateUsageKey.getSingle(pdo.getString(P_DBT_RATE_USAGE_NM) ) ; 
    }     

    /**
     * 
     */
    public static final RateUsage loadCreditRateUsage(final PDO pdo) 
    { 
    	return CacheKeys.rateUsageKey.getSingle(pdo.getString(P_CDT_RATE_USAGE_NM) ) ; 
    }     

    /**
     * 
     * May 20, 2008
     * guys
     *
     * @param pdo
     * @return for account = '22222222' currency = 'EUR' office = 'BC1'
     */
    public static final Accounts loadCreditAccount(final PDO pdo) { 
        return CacheKeys.accountsKey.getSingle(pdo.getString(P_CDT_ACCT_NB)
                , pdo.getString(P_CDT_ACCT_CCY), pdo.getString(P_CDT_ACCT_OFFICE))  ;
    }//EOM 
    
    public static final BulkingProfile loadBulkingProfile(final PDO pdo) { 
        return CacheKeys.bulkingProfileKey.getSingle(pdo.getString(P_BULKING_PROFILE))  ;
    }//EOM 
    
    /**
     * 
     * May 20, 2008
     * guys
     *
     * @param pdo
     * @return for account = '131206' currency = 'EUR' office = 'BC1'
     */
    public static final Accounts loadDebitAccount(final PDO pdo) { 
        return CacheKeys.accountsKey.getSingle(pdo.getString(P_DBT_ACCT_NB)
                , pdo.getString(P_DBT_ACCT_CCY), pdo.getString(P_DBT_ACCT_OFFICE))  ;
    }//EOM 
    
    /**
     * @param pdo
     * @return AccountAdditionalOwners
     */
    public static final AccountAdditionalOwners loadDebitAccountAdditionalOwner(final PDO pdo) { 
    	String accountUid = pdo.getString(P_DBT_ACCT_NB) + GlobalConstants.POWER_SIGN + pdo.getString(P_DBT_ACCT_CCY) + GlobalConstants.POWER_SIGN + 
    						pdo.getString(P_DBT_ACCT_OFFICE);
        return CacheKeys.accountAdditionalOwnersKey.getSingle(accountUid, pdo.getString(P_ORG_INITG_PTY_CUST_CD))  ;
    }//EOM 
    
    /**
     * 
     * May 29, 2008
     * vadimk
     *
     * @param pdo
     * @return instruction agent
     */
    public static final Customrs loadInstructionAgent(final PDO pdo) { 
        return CacheKeys.customrsKey.getSingle(pdo.getString(P_INSTG_AGT_CUST_CD), pdo.getString(P_OFFICE))   ;
    }//EOM
    /**
     * 
     */
    public static final Customrs loadOrigInitiatingCustomer(final PDO pdo) { 
      return CacheKeys.customrsKey.getSingle(pdo.getString(P_ORG_INITG_PTY_CUST_CD), pdo.getString(P_OFFICE))   ;
    }

    public static final ExchrateRtrLineType loadExchrateRTR(final PDO pdo) { 
        return CacheKeys.exchrateRTRKey.getSingle(pdo.getString(P_RTR_QUOTE_REQ_ID))   ;
      }
    
    public static final List<MsgSpecialInstructions> loadMsgSpecialInstructionList(final PDO pdo) 
    {
        final String selectQuery="SELECT MSI.*, MSI.MID || '^' || MSI.TIME_STAMP AS \"UID_MSG_SPECIAL_INSTRUCTIONS\" FROM MSG_SPECIAL_INSTRUCTIONS MSI WHERE MID = '"+pdo.getMID()+"' AND PARTITION_ID ='" + pdo.getIsHistory() + "'";
                            
        List<MsgSpecialInstructions> list=m_daoBasic.getDataRows(selectQuery,MsgSpecialInstructions.class ,0, (StatementParameter[]) null);
        return list;
    }//EOM
    
    public static final List<MsgParties> loadMsgParties(final PDO pdo){
    	
    	final String selectQuery = "SELECT * FROM MSG_PARTIES WHERE MID = ? AND PARTITION_ID = ?";
    	
    	return m_daoBasic.getDataRows(selectQuery, MsgParties.class, 0, 
    			new StatementParameter(pdo.getMID(), Types.CHAR),
    			new StatementParameter(pdo.getIsHistory(), Types.INTEGER));
    }//EOM
    
    public static final AccountDailyBalances loadAccountDailyBalances(final PDO pdo,final Date valueDate,String clearingCycle){
    	final String selectQuery = "SELECT * FROM ACCOUNT_DAILY_BALANCES WHERE UID_ACCOUNTS = ? AND VALUE_DATE=TO_DATE(?,'MM-DD-YYYY') and "+(GlobalUtils.isNullOrEmpty(clearingCycle)?"UID_POS_CYCLE is NULL":"UID_POS_CYCLE = ?");
    	Accounts account = pdo.getSTMT_ACCT();
    	String uidAccounts = account.getOffice()+"^"+account.getAccNo()+"^"+account.getCurrency();
    	
    	StatementParameter[] arrParams = new StatementParameter[GlobalUtils.isNullOrEmpty(clearingCycle)?2:3];
        arrParams[0] = new StatementParameter(uidAccounts,Types.CHAR);
        SimpleDateFormat simpleDateFormat = GlobalDateTimeUtil.getSimpleDateFormatByFormat(GlobalDateTimeUtil.DATE_FORMAT_US);
		String sValueDate = simpleDateFormat.format(valueDate);
        arrParams[1] = new StatementParameter(sValueDate, Types.CHAR);
        if (!GlobalUtils.isNullOrEmpty(clearingCycle)){
        	arrParams[2] = new StatementParameter(clearingCycle, Types.CHAR);
        }
    	List<AccountDailyBalances> accountDailyBalancesList  = m_daoBasic.getDataRows(selectQuery, AccountDailyBalances.class, 0, arrParams);
    	if (accountDailyBalancesList!=null && !accountDailyBalancesList.isEmpty()){
    		return accountDailyBalancesList.get(0);
    	}
    	AccountDailyBalancesId accountDailyBalancesId = new AccountDailyBalancesId(uidAccounts, valueDate,clearingCycle);
    	return new AccountDailyBalances(accountDailyBalancesId);
    }//EOM

    
    public static List<CycleSttlmLineType> loadCycleSttlm(final PDO pdo)
    {
    	String query = "select * from cycle_settlement where posting_message_id = ?";
    	
    	return m_daoBasic.getXmlObjectDataRows(query, CycleSttlmLineType.class, 0, new StatementParameter(pdo.getMID(), Types.CHAR) );
    }

    public static final List<MsgFees> loadMsgFeesList(final PDO pdo) 
    {
        final String selectQuery ="SELECT * FROM MSG_FEES WHERE MID = ? AND PARTITION_ID = ?";
        
        return m_daoBasic.getDataRows(selectQuery,MsgFees.class ,0,new StatementParameter(pdo.getMID(),Types.CHAR), new StatementParameter(pdo.getIsHistory(),Types.INTEGER));
        
    }//EOM
    
    public static final List<ForwardContractLineType> loadMessageRates(MessageRatesInputData messageRatesInputData)
    {
      return DAOCurrencyConversion.getInstance().getMessageRates(messageRatesInputData);
    }
    
    public static final List<MsgStopFlags> loadStopFlags(final PDO pdo)
    {
      final String SELECT_STATEMENT = "SELECT * FROM MSG_STOP_FLAGS WHERE MID = ? AND SF_STATUS IN (0, 1) AND PARTITION_ID = ?";
      
      return m_daoBasic.getDataRows(SELECT_STATEMENT, MsgStopFlags.class, 0, new StatementParameter(pdo.getMID(), Types.CHAR),
    		  new StatementParameter(pdo.getIsHistory(), Types.INTEGER));
    }
    
    public static final List<Msgerr> loadMsgErrors(final PDO pdo)
    {
      String SELECT_STATEMENT = "SELECT * FROM MSGERR WHERE MID = ? AND PARTITION_ID = ? AND TIME_STAMP > ? ORDER BY CREATE_DATE DESC";  
      
      String sMID = pdo.getMID();
      Integer iPartitionID = pdo.getIsHistory();
      
      String sLastSubmitTimeStamp = pdo.getString(P_LAST_SUBMIT_TS);
      sLastSubmitTimeStamp = sLastSubmitTimeStamp != null ? sLastSubmitTimeStamp : ServerConstants.SPACE;
      
      StatementParameter[] arrParams = new StatementParameter[3];
      arrParams[0] = new StatementParameter(sMID,Types.CHAR);   
      arrParams[1] = new StatementParameter(iPartitionID, Types.NUMERIC);
      arrParams[2] = new StatementParameter(sLastSubmitTimeStamp, Types.CHAR);
      
      return m_daoBasic.getDataRows(SELECT_STATEMENT, Msgerr.class, -1/*iNoOfRows - no limit*/, arrParams);
    }
    
    public static final List<com.fundtech.cache.entities.ExternalErrorMessage> loadExternalErrorMessages(final PDO pdo) 
    { 
        final String selectQuery ="SELECT * FROM EXTERNAL_ERROR_MESSAGES WHERE TRIM(EXTERNAL_ERROR_MESSAGES.MID) = ? AND PARTITION_ID = ?";
        
        return m_daoBasic.getDataRows(selectQuery,com.fundtech.cache.entities.ExternalErrorMessage.class ,0,
        		new StatementParameter(pdo.getMID(),Types.CHAR),
        		new StatementParameter(pdo.getIsHistory(),Types.INTEGER));
        
    }//EOM
    
    /**
     * 
     */
    public static final List<MFamilyLineType> loadMfamily(final PDO pdo)
    {
      String SELECT_STATEMENT = "SELECT * FROM MFAMILY WHERE ((P_MID = ? OR RELATED_MID = ?) AND PARTITION_ID = ? )";  
      
      String sMID = pdo.getMID();
      Integer iPartitionID = pdo.getIsHistory();
      StatementParameter[] arrParams = new StatementParameter[]{new StatementParameter(sMID, Types.VARCHAR),
	  new StatementParameter(sMID, Types.VARCHAR), new StatementParameter(iPartitionID, Types.NUMERIC)};
      
      return m_daoBasic.getXmlObjectDataRows(SELECT_STATEMENT, MFamilyLineType.class, 0, arrParams);
    }
    
    public static final List<Newjournal> loadMsgNewjournal(final PDO pdo)
    {
      String SELECT_STATEMENT = "SELECT TIME_STAMP, MID, OFFICE, ENDDATE, USERNAME, MODULE_ID, ERROR_PARAMS, STATUS, ACTIONID1, ACTIONID2, " +
                                "UPDATE_DATE, CLASS, PRICING_WEIGHT, FIELD_LOGICAL_ID, FAULT, AUDIT_SUBTYPE, " +
                                "ERROR_SEVERITY, HIT_INFO, ZONE_CODE, IP_ADDRESS, ERROR_CODE, FLOW_ID, MULTIPLE, TYPE_FIELDS_CHANGE_VERIFY, " +
                                "XMLSERIALIZE(CONTENT XML_RELATED_FIELDS_DATA as varchar(4000)) XML_RELATED_FIELDS_DATA " +
                                "FROM NEWJOURNAL WHERE MID = ? AND PARTITION_ID = ? ORDER BY TIME_STAMP DESC";  
      
      return m_daoBasic.getDataRows(SELECT_STATEMENT, Newjournal.class, 0, new StatementParameter(pdo.getMID(),Types.CHAR), new StatementParameter(pdo.getIsHistory(),Types.INTEGER));
    }
    
    /**
     * @param bLoadIncoming true - load related INCOMING FILE_SUMMARY entry.
     *                     false - load related OUTGOING FILE_SUMMARY entry. 
     */
    public static final FileSummary loadFileSummary(final PDO pdo, boolean bLoadIncoming)
    {
      String SELECT_STATEMENT = "SELECT OFFICE,DEPARTMENT,INTERNAL_FILE_ID,FILE_NAME,DIRECTION,STATUS,TIME_STAMP,BULKING_PROFILE,SENDER_DN,RECEIVER_DN," +
      		                    "SWIFT_ID,SWIFT_SERVICE,SENDER_ENDTOEND_ID,REQUEST_TYPE,PDM_FLAG,FILE_SIZE,ACK_INDICATOR,DELIVERY_NOTIF," +
      		                    "FILE_INFO,SENDING_INST,RECEIVING_INST,FILE_REFERENCE,SERVICE_IDENTIFIER,PROD_TEST_CODE,NUM_CANS,NUM_RETS,NUM_REPAIR," +
      		                    "FILE_REJECT_RSN,PL_CREATE_DATE,LAST_COMPLETED_MID,PAYMENT_COMPLETION_STATUS,FILE_DES,CREATED_OBJ_INSTANCE," +
      		                    "LAST_CHECK_TIME_STAMP,OUT_GROUP_ID,MAX_COUNT_NB,MIN_COUNT_NB,FINCOPYSERVICE,PL_FILE_TYPE,MOP,OFFICE_TIME_TO_SEND," +
      		                    "REL_FILE_REFERENCE,REL_FILE_NAME,PL_REL_TIME_STAMP,FILE_CYCLE_NR,ROUT_IND,SENT_TIME,REC_STATUS,PROFILE_CHANGE_STATUS," +
      		                    "EFFECTIVE_DATE,PENDING_ACTION,LATEST_SEND_TIME_IND,A_OBJ_INSTANCE,A_LAST_MID,ERROR_DESCRIPTION,OUT_MSG_MIN_CREATE_DATE," +
      		                    "OUT_MSG_MAX_CREATE_DATE," +
      		                    "NUM_DD,NUM_REJS,NUM_REVS,NB_OF_TXS,CALC_NB_OF_TXS,CTRL_SUM,CALC_CTRL_SUM," +
      		                    "UID_FILE_SUMMARY,CREDIT_LUMP_SUM,INITG_PTY_CUST_CODE,OVERRIDE_LIMIT_CHECK, " +
      		                    "BSNESSDATE, TOTAL_BASE_AMT, INITG_PTY_CUST_NAME, INITG_PTY_CUST_ID, PRIORITY, QUEUE_NAME, QUEUE_MSG_ID,WORKFLOW," +
      		                    "FILE_SOURCE,NUM_CT_BLK,NUM_DD_BLK,CALC_NUM_CT_BLK,CALC_NUM_DD_BLK,REL_INTERNAL_FILE_ID " + 
      		                    "FROM FILE_SUMMARY WHERE INTERNAL_FILE_ID = ?";
      
      String sInternalFileID = pdo.getString(bLoadIncoming ? P_IN_INTERNAL_FILEID :
                                                             P_OUT_INTERNAL_FILEID);
      
      FileSummary fileSummary = null;
      
      if(!GlobalUtils.isNullOrEmpty(sInternalFileID))
      {
    	  logger.debug("Before getDataRows");
        List<FileSummary> list = m_daoBasic.getDataRows(SELECT_STATEMENT, FileSummary.class, 1, new StatementParameter(sInternalFileID,Types.VARCHAR));
        logger.debug("After getDataRows");
        if (list != null && list.size() > 0)
            fileSummary = list.get(0);
      }
      
      return fileSummary;
    }
    
    public static final BatchSubset loadBatchSubset(final PDO pdo)
    {
    	//if the batchMsgType is not 'I' there is no need to continue 
      final String batchMsgType = pdo.getString(P_BATCH_MSG_TP) ;
      
      if(batchMsgType == null || !batchMsgType.equals("I") && !batchMsgType.equals("S")) return null ;
      
      String SELECT_STATEMENT = "SELECT * FROM BATCH_SUBSET WHERE INTERNAL_FILE_ID = ? AND UNIQUE_GROUPING_ID = ?";  
      
      String sInternalFileID = pdo.getString(P_IN_INTERNAL_FILEID);
      final String sUniqueGroupingID = pdo.getString(P_UNIQUE_GROUPING_ID) ; 
      
      final List<BatchSubset> listBatchSubsets = m_daoBasic.getDataRows(SELECT_STATEMENT, BatchSubset.class, 0, 
    		  new StatementParameter(sInternalFileID,Types.CHAR), 
    		  new StatementParameter(sUniqueGroupingID, Types.VARCHAR)) ; 
      
      //as there is no assurance that the query return a record, check first 
      return (listBatchSubsets.isEmpty() ? null : listBatchSubsets.get(0)) ; 
    }//EOM 
    
    public static final List<MsgNotesLineType> loadListMsgNotes(final PDO pdo) {
    	        
    	final String SELECT_STATEMENT = "SELECT MID, USER_ID, TEXT, TIME_STAMP, " + 
    	"TO_CHAR(CREATE_DATE, 'YYYY-MM-DD HH24:MI:SS') || CASE WHEN ZONE_CODE IS NULL " + 
        "THEN '' ELSE ' (' || ZONE_CODE || ')' END AS \"CREATE_DATE\", EXTERNAL_NOTE_IND,ATTACHED_FILE_LINK, REC_STATUS"+  
        " FROM MSGNOTES WHERE MID = ? AND PARTITION_ID = ? ORDER BY TIME_STAMP DESC"  ;
    	
    	return m_daoBasic.getXmlObjectDataRows(SELECT_STATEMENT, MsgNotesLineType.class, 0, new StatementParameter(pdo.getMID(),Types.CHAR) 
    			, new StatementParameter(pdo.getIsHistory(),Types.INTEGER));
    }//EOM 
    
    public static final Map<String,Object> loadLinkedMsg(final PDO primaryPDO, final String sClassTypeName) {
    	//the method shall load all relations for this instance's mid 
    	//moreover, it would already split each record to two map entries: one for the self relation (where by the this pdo would already be 
        //stored as the value and the second for the related msg where the value would remain the MID until first retrieval request  
    	final String STATEMENT = "SELECT MFAMILY.*, 0 AS \"IS_NEW\", 0 AS \"IS_UPDATED\" FROM MFAMILY WHERE P_MID = ? AND PARTITION_ID = ? " ; 
    	final String SELF_RELATED_TYPE_COLUMN = "SELF_RELATED_TYPE" ; 
    	final String RELATED_TYPE_COLUMN = "RELATED_TYPE" ;
    	final String RELATED_MID_COLUMN = "RELATED_MID"  ;
    	
    	Connection conn = null ; 
    	PreparedStatement ps = null ; 
    	ResultSet rs = null ; 
    	PDO linkedPDO  = null ; 
    	
    	final Map<String,Object> mapTempRelations = new HashMap<String,Object>() ; 
    	
    	try{
    		conn = m_daoBasic.getConnection() ; 
    		ps = conn.prepareStatement(STATEMENT) ; 
    		com.fundtech.util.GlobalUtils.setObject(ps,1, primaryPDO.getMID()) ; 
    		com.fundtech.util.GlobalUtils.setObject(ps,2, primaryPDO.getIsHistory()) ;
    		rs = ps.executeQuery() ; 
    		
    		while(rs.next()) { 
    			
    			//split the record in to two relations
    			
    			//put the self relation first where the key is the SELF_TYPE and the value, the pdo 
    			mapTempRelations.put(rs.getString(SELF_RELATED_TYPE_COLUMN), primaryPDO) ; 
    			//put the related msg relation RELATED_TYPE against the RELATED_MID
    			mapTempRelations.put(rs.getString(RELATED_TYPE_COLUMN), rs.getString(RELATED_MID_COLUMN)) ;
    			
    		}//EO while there are more records.     		
    		
    	}catch(SQLException e) { 
    		ExceptionController.getInstance().handleException(e, null) ;
    	}finally{ 
    		m_daoBasic.releaseResources(rs, ps, conn) ; 
    	}//EO catch block 
    	 
    	return mapTempRelations ;
    	
    }//EOM 
    
    public static final String loadTemplateUnchangedFields(final PDO pdo) {
        
    	final String SELECT_STATEMENT = "SELECT UNCHANGED_FIELDS FROM TEMPLATE_UNCHANGED_FIELDS WHERE MID=? AND PARTITION_ID = ?"  ;
    	
    	//if the template id exists, then this is a context of a payment linked to a template, 
    	//hence, use the former, else use the MID 
    	String sTemplateMID = pdo.getString(PDOConstantFieldsInterface.P_TEMPLATE_MID) ; 
    	Integer iPartitionID = pdo.getIsHistory();
    	if(sTemplateMID == null) sTemplateMID = pdo.getMID() ; 
    	
    	return m_daoBasic.getData(SELECT_STATEMENT,new StatementParameter(sTemplateMID, Types.VARCHAR), new StatementParameter(iPartitionID, Types.NUMERIC)).getColumnData("UNCHANGED_FIELDS");
    }//EOM 
    
    public static final String loadMsgAttachments(final PDO pdo) { 
    	final String SELECT_STATEMENT = "SELECT ATTACHMENT FROM MSG_ATTACHMENTS WHERE P_MID = ?" ; 
    	final DTOSingleValue results = m_daoBasic.getSingleValue(SELECT_STATEMENT, new StatementParameter[] { new StatementParameter(pdo.getMID(), Types.VARCHAR) }, null/*connection*/) ;
    	final String sMsgAttachmentsSection = results.getValue() ;
    	return (sMsgAttachmentsSection == null ? "" : sMsgAttachmentsSection) ;
    }//EOM 
    
    public static final Mandate loadMandate(final PDO pdo) {
    	boolean isDD = MessageUtils.isDirectDebit(pdo);
    	String usage = (isDD && pdo.isIncomingMessage()) ? GlobalConstants.DR : GlobalConstants.CR;
        return CacheKeys.mandateKey.getSingle(pdo.getString(PDOConstantFieldsInterface.X_MNDT_ID).toUpperCase(), pdo.getString(PDOConstantFieldsInterface.P_OFFICE), usage, pdo.getString(X_CDTR_ACCT_ID));
    }//EOM 
    
}//EOC