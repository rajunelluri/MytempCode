package backend.paymentprocess.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.apache.cxf.common.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import backend.core.module.MessageConstantsInterface;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.sun.xml.bind.v2.runtime.unmarshaller.XsiNilLoader.Array;

public class DAOPayments {

	private JdbcTemplate jdbcTemplate;
	final static Logger logger = LoggerFactory.getLogger(DAOPayments.class);

	final String SELECT_MINF_MIDS_BY_INSTR_ID = "SELECT * FROM MINF WHERE P_INSTR_ID =? ";
	final String SELECT_MINF_MIDS_BY_INSTR_ID_AND_IS_HISTORY = "SELECT * FROM MINF WHERE P_INSTR_ID = '%s' and P_IS_HISTORY in (%s)";
	final String SELECT_RELATED_MIDS_BY_INSTR_ID = "SELECT * FROM MFAMILY WHERE related_type= '"+ MessageConstantsInterface.RELATION_TYPE_OUTGOING_REJECT_RETURN + "' and P_MID = ? and PARTITION_ID = ?";
	final String SELECT_RELATED_MIDS_BY_ORIGINAL_PAYMENT = "SELECT * FROM MFAMILY WHERE related_type= '"+  MessageConstantsInterface.RELATION_TYPE_INCOMING_REJECT_RETURN + "' and P_MID = ? and PARTITION_ID = ?";
	final String SELECT_RELATED_INCOMING_REJECT_RETURN_MIDS_BY_ORIGINAL_PAYMENT = "SELECT * FROM MFAMILY WHERE self_related_type= '"+  MessageConstantsInterface.RELATION_TYPE_INCOMING_REJECT_RETURN + "' and P_MID = ? and PARTITION_ID = ?";

	public void setDataSource(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	@SuppressWarnings("unchecked")
	public List<MIDPartitionID> loadPaymentsMidsByInstrIdreturnObject(String instrID, String partitionIDRange) {
		String selectQuery = String.format(SELECT_MINF_MIDS_BY_INSTR_ID_AND_IS_HISTORY, instrID,partitionIDRange);
		List<MIDPartitionID> minfRecords = jdbcTemplate.query(selectQuery, new Object[] {}, new RowMapper() {
			 public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				 String singleMid =  rs.getString("P_MID");
				 String partitionID =  rs.getString("P_IS_HISTORY");
				 MIDPartitionID midAndPartitionID = new MIDPartitionID(singleMid, partitionID);
				 return midAndPartitionID;
			 }
		});
		return minfRecords;	
	}
	
	
	@SuppressWarnings("unchecked")
	public List<String> loadPaymentsMidsByInstrId(String instrID) {
		List<String> minfRecords = jdbcTemplate.query(SELECT_MINF_MIDS_BY_INSTR_ID, new Object[] {instrID}, new RowMapper() {
			 public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				 String singleMid =  rs.getString("P_MID");
				 return singleMid;
			 }
		});
		return minfRecords;	
	}
	
	
	@SuppressWarnings("unchecked")
	public List<PDO> loadPDOByInstrId(String instrID) {
		List<String> minfRecords = jdbcTemplate.query(SELECT_MINF_MIDS_BY_INSTR_ID, new Object[] {instrID}, new RowMapper() {
			 public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				 String singleMid =  rs.getString("P_MID");
				 return singleMid;
			 }
		});
		List<PDO>pdoList=new ArrayList<PDO>();
		for(String mid:minfRecords){
			PDO pdo=PaymentDataFactory.load(mid);
			if(pdo!=null)
				pdoList.add(pdo);
		}
		return pdoList;	
	}
	public List<PDO>loadByOutChunkId(String outChunkId, Integer iIsHistoryValue){
		final String SELECT_STATEMENT = "SELECT P_MID FROM MINF WHERE P_OUT_CHUNK_ID = ? AND P_IS_HISTORY = ?";
		List<PDO>pdoList=new ArrayList<PDO>();
		
		List<String> minfRecords = jdbcTemplate.query(SELECT_STATEMENT, new Object[] {outChunkId, iIsHistoryValue}, new RowMapper() {
			 public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				 String singleMid =  rs.getString("P_MID");
				 return singleMid;
			 }
		});
		for(String mid : minfRecords){
			pdoList.add(PaymentDataFactory.load(mid));
		}
		return pdoList;	
		
	}
	
	public List<PDO> loadRelatedORDPDOsForORF(String[]instrIDs,String groupMsgId,String partitionIDRange) {
		List<PDO>pdos=new ArrayList<PDO>();
		
		if (groupMsgId!=null && !StringUtils.isEmpty(groupMsgId)) {
			List<MIDPartitionID> midPartitionIDs = loadPaymentsMidsByInstrIds(instrIDs, partitionIDRange);
			if(midPartitionIDs == null || midPartitionIDs.isEmpty())
				return pdos;
			String[] midsArr = new String[midPartitionIDs.size()];
			
			// check if need to load the original mid's or the related mid
			// If related MISs exist, we know that the incoming file was pacs002 on pacs004, (ORF on ORD)
			// so we need to load all the I message of the related pacs004 and not the (OWD) original payments
			midPartitionIDs = loadRelatedMidsByOriginalPayments(midPartitionIDs);

			
			List<String> mids = fromMIFPartitionIDtoMIDList(midPartitionIDs);
			
			pdos.addAll(PaymentDataFactory.loadByMids(mids.toArray(midsArr), groupMsgId));
					
		}
		
		return pdos;
	}
	
	public List<PDO> loadPDOsByInstrIds(String[]instrIDs,String groupMsgId, String partitionIDRange ) {
		List<PDO>pdos=new ArrayList<PDO>();
		
		if (groupMsgId!=null && !StringUtils.isEmpty(groupMsgId)) 
		{
			List<MIDPartitionID> midPartitionID = loadPaymentsMidsByInstrIds(instrIDs, partitionIDRange);
			//List<String> mids = loadPaymentsMidsByInstrIds(instrIDs);
			String[] midsArr = new String[midPartitionID.size()];
			
			// check if need to load the mids or the related mid
			// If related MISs exist, we know that the incoming file was pacs002 on pacs004,
			// so we need to load all the I message of pacs004 and not according to the intrctId
			if (isNeedToLoadRelatedMids(midPartitionID)) 
			{
				// relation was found, need get a list of all the related mids
				midPartitionID = loadRelatedMidsByMid(midPartitionID);
			}

			List<String> mids = fromMIFPartitionIDtoMIDList(midPartitionID);
			pdos.addAll(PaymentDataFactory.loadByMids(mids.toArray(midsArr), groupMsgId));
					
		}else{
			for(String instrId:instrIDs){
				pdos.addAll(loadPDOByInstrId(instrId));
			}
		}
		return pdos;
	}
	
	private List<String> fromMIFPartitionIDtoMIDList(List<MIDPartitionID> midPartitionIDs) 
	{
		List<String> mids = new ArrayList<String>();
		for (MIDPartitionID midPartition: midPartitionIDs)
		{
			mids.add(midPartition.getMid());
		}
		
		return mids;
	}

	public List<MIDPartitionID> loadPaymentsMidsByInstrIds(String[]instrIDs, String partitionIDRange) {
		List<MIDPartitionID> minfRecords = new ArrayList<MIDPartitionID>();
		for(String instrId:instrIDs){
			minfRecords.addAll(loadPaymentsMidsByInstrIdreturnObject(instrId, partitionIDRange));
		}
		return minfRecords;	
	}

	
	/**
	 * The method check if list of mid according to the incoming instrIDs is required or the related MIDs
	 * If the mid has related mid with relation 'Outgoing Reject Return',
	 * the list of the return mid need to include all the related mid (pacs004)
	 * and not the list of mid according to the incoming instrIDs (pacs003/008)
	 * @param midsArr
	 * @return
	 */
	private boolean isNeedToLoadRelatedMids(List<MIDPartitionID> midsArr) {
		if (midsArr != null && !midsArr.isEmpty())
		{
			 List<MIDPartitionID> related = loadRelatedMidsByMid(midsArr.get(0).getMid(), midsArr.get(0).getPartitionID());
			 if (related != null && related.size() > 0)		
				 return true;	// relation was found, need to loads all the related			 
		}
		return false;
	}

	public List<MIDPartitionID> loadRelatedMidsByMid(List<MIDPartitionID> midPartitionIDs) {
		List<MIDPartitionID> minfRecords = new ArrayList<MIDPartitionID>();
		for(MIDPartitionID midPartitionID:midPartitionIDs){
			
			minfRecords.addAll(loadRelatedMidsByMid(midPartitionID.getMid(), midPartitionID.getPartitionID()));
		}
		return minfRecords;	
	}
	
	public List<MIDPartitionID> loadRelatedMidsByOriginalPayments(List<MIDPartitionID> midPartitionIDs) {
		List<MIDPartitionID> minfRecords = new ArrayList<MIDPartitionID>();
		for(MIDPartitionID midPartitionID: midPartitionIDs){
			String mid = midPartitionID.getMid();
			String partitionID = midPartitionID.getPartitionID();
			
			minfRecords.addAll(loadRelatedMidsByOriginalPayment(mid, partitionID));
		}
		return minfRecords;	
	}
	
	@SuppressWarnings("unchecked")
	public List<MIDPartitionID> loadRelatedMidsByMid(String mid , String partitionID) {
		List<MIDPartitionID> minfRecords = jdbcTemplate.query(SELECT_RELATED_MIDS_BY_INSTR_ID, new Object[] {mid, partitionID}, new RowMapper() {
			 public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				 
				 String singleMid =  rs.getString("RELATED_MID");
				 String partitionID =  rs.getString("PARTITION_ID");
				 MIDPartitionID midPartitionID = new MIDPartitionID(singleMid, partitionID);
				 return midPartitionID;
			 }
		});
		return minfRecords;	
	}
	
	@SuppressWarnings("unchecked")
	public List<MIDPartitionID> loadRelatedMidsByOriginalPayment(String mid, String partitionID) {
		List<MIDPartitionID> minfRecords = jdbcTemplate.query(SELECT_RELATED_MIDS_BY_ORIGINAL_PAYMENT, new Object[] {mid, partitionID}, new RowMapper() {
			 public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				 String singleMid =  rs.getString("RELATED_MID");
				 String partitionID =  rs.getString("PARTITION_ID");
				 MIDPartitionID midPartitionID = new MIDPartitionID(singleMid, partitionID);
				 return midPartitionID;
			 }
		});
		return minfRecords;	
	}
	
	@SuppressWarnings("unchecked")
	public List<String> loadRelatedIncomingRejectReturnMidsByOriginalPayment(String mid, Integer partitionID) {
		List<String> minfRecords = jdbcTemplate.query(SELECT_RELATED_INCOMING_REJECT_RETURN_MIDS_BY_ORIGINAL_PAYMENT, new Object[] {mid, partitionID}, new RowMapper() {
			 public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				 String singleMid =  rs.getString("RELATED_MID");
				 return singleMid;
			 }
		});
		return minfRecords;	
	}
	
}
