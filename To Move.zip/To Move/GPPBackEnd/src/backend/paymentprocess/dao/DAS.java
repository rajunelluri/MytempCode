package backend.paymentprocess.dao;

import static backend.core.module.MessageConstantsInterface.MESSAGE_TYPE_CAMT_056;
import static backend.core.module.MessageConstantsInterface.MESSAGE_TYPE_PACS_007;
import static backend.core.module.MessageConstantsInterface.RELATION_TYPE_ORIGINAL_PAYMENT;
import static com.fundtech.cache.infrastructure.regions.CacheKeys.LogicalFieldsIdKey;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_MSG_STS;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_MSG_TYPE;
import static com.fundtech.util.GlobalConstants.EMPTY_STRING;
import static com.fundtech.util.GlobalConstants.NO;
import static com.fundtech.util.GlobalUtils.isListNullOrEmpty;
import static com.fundtech.util.GlobalUtils.isNullOrEmpty;
import static com.fundtech.util.GlobalUtils.setObject;
import static java.sql.Types.CHAR;
import static java.sql.Types.VARCHAR;

import java.io.IOException;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.ConcurrentModificationException;
import java.util.Date;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.transaction.UserTransaction;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.namespace.QName;

import org.apache.xmlbeans.QNameSet;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.XmlCursor;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlOptions;
import org.apache.xmlbeans.XmlTokenSource;
import org.apache.xmlbeans.impl.values.TypeStore;
import org.apache.xmlbeans.impl.values.XmlObjectBase;
import org.hibernate.TransactionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Node;

import backend.businessobject.BOBasic;
import backend.core.module.MessageConstantsInterface;
import backend.core.module.genservices.dataaccess.dao.DAOGeneralServices;
import backend.dataaccess.dao.DAOBasic;
import backend.paymentprocess.currencyconversion.businessobjects.BOCurrencyConversion;
import backend.paymentprocess.erroraudit.ErrorAuditUtils;
import backend.paymentprocess.memopost.dao.DAOMemoPost;
import backend.paymentprocess.partylimit.businessobjects.BOPartyLimit;
import backend.util.ServerConstants;

import com.fundtech.cache.entities.APaymentPerGroupMsgID;
import com.fundtech.cache.entities.AccountAdditionalOwners;
import com.fundtech.cache.entities.AccountDailyBalances;
import com.fundtech.cache.entities.Accounts;
import com.fundtech.cache.entities.Banks;
import com.fundtech.cache.entities.BatchSubset;
import com.fundtech.cache.entities.BulkingProfile;
import com.fundtech.cache.entities.CurrencyBu;
import com.fundtech.cache.entities.Customrs;
import com.fundtech.cache.entities.DynamicPartyLimit;
import com.fundtech.cache.entities.ExternalErrorMessage;
import com.fundtech.cache.entities.FileSummary;
import com.fundtech.cache.entities.LogicalFields;
import com.fundtech.cache.entities.LogicalFieldsXpath;
import com.fundtech.cache.entities.Mandate;
import com.fundtech.cache.entities.MatchingCheck;
import com.fundtech.cache.entities.MessageExternalInteraction;
import com.fundtech.cache.entities.MessageStpRules;
import com.fundtech.cache.entities.Mop;
import com.fundtech.cache.entities.MsgFees;
import com.fundtech.cache.entities.MsgParties;
import com.fundtech.cache.entities.MsgRuleLog;
import com.fundtech.cache.entities.MsgSpecialInstructions;
import com.fundtech.cache.entities.MsgStopFlags;
import com.fundtech.cache.entities.MsgTypes;
import com.fundtech.cache.entities.Msgerr;
import com.fundtech.cache.entities.Newjournal;
import com.fundtech.cache.entities.Newjournal.SnapShotHolder;
import com.fundtech.cache.entities.RateUsage;
import com.fundtech.cache.entities.SlaProfile;
import com.fundtech.cache.entities.WebSessionInfo;
import com.fundtech.cache.infrastructure.CacheServiceInterface;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.cache.syspar.SystemParametersInterface;
import com.fundtech.core.general.PluginFactory;
import com.fundtech.core.message.MessageLoadConstantsInterface.LoadMessageStep;
import com.fundtech.core.paymentprocess.PDOException;
import com.fundtech.core.paymentprocess.currencyconversion.MessageRatesInputData;
import com.fundtech.core.paymentprocess.data.DefaultDeepPDOCloneHandler;
import com.fundtech.core.paymentprocess.data.DefaultDeepPDOCloneHandler.CloningContext;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDO.PDOModeType;
import com.fundtech.core.paymentprocess.data.PDO.XmlMetadata;
import com.fundtech.core.paymentprocess.data.PDOCloneHandlerInterface;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.PDOMemberConstants;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.core.paymentprocess.data.UnMarshallingInfo;
import com.fundtech.core.paymentprocess.data.das.DASInterface;
import com.fundtech.core.paymentprocess.data.das.LogicalFieldsXPathCursor;
import com.fundtech.core.paymentprocess.data.das.PaymentInputSourceType;
import com.fundtech.core.paymentprocess.data.das.listmembers.handlers.PDOListMemberHandlerInterface;
import com.fundtech.core.paymentprocess.data.fields.DataType;
import com.fundtech.core.paymentprocess.data.fields.FieldType;
import com.fundtech.core.paymentprocess.data.fields.PaymentField;
import com.fundtech.core.paymentprocess.data.fields.PaymentFieldInterface;
import com.fundtech.core.paymentprocess.data.fields.PaymentFieldInterface.ModificationType;
import com.fundtech.core.paymentprocess.data.fields.XmlPaymentField;
import com.fundtech.core.paymentprocess.data.fields.XmlPaymentField.DetachedXmlMultiOccurrencePaymentField;
import com.fundtech.core.paymentprocess.data.fields.XmlPaymentField.XmlMultiOccurencePaymentField;
import com.fundtech.core.paymentprocess.data.paymenttypes.PaymentType;
import com.fundtech.core.paymentprocess.data.paymenttypes.PaymentType.FndtMsgPaymentType;
import com.fundtech.core.paymentprocess.data.state.PDOStateHandlerInterface;
import com.fundtech.core.paymentprocess.data.tx.PaymentFormattingInterface;
import com.fundtech.core.paymentprocess.data.tx.PaymentFormattingInterface.PaymentFormattingException;
import com.fundtech.core.paymentprocess.errorhandling.BusinessException;
import com.fundtech.core.paymentprocess.errorhandling.ProcessError;
import com.fundtech.core.security.Admin;
import com.fundtech.core.security.Admin.CallSource;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.datacomponent.response.selectlist.ColumnMetaData;
import com.fundtech.errors.ProcessErrorConstants;
import com.fundtech.jndi.ServiceLocator;
import com.fundtech.scl.commonTypes.CycleSttlmLineType;
import com.fundtech.scl.commonTypes.ExchrateRtrLineType;
import com.fundtech.scl.commonTypes.ForwardContractLineType;
import com.fundtech.scl.commonTypes.MFamilyLineType;
import com.fundtech.scl.commonTypes.MsgNotesLineType;
import com.fundtech.scl.commonTypes.MtableDocument;
import com.fundtech.scl.commonTypes.UDFContainerType;
import com.fundtech.scl.commonTypes.impl.FndtMsgDocumentImpl;
import com.fundtech.spring.SpringApplicationContext;
import com.fundtech.util.ExceptionController;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalDateTimeUtil;
import com.fundtech.util.GlobalUtils;
import com.fundtech.util.TreeCursorInterface;
import com.fundtech.util.datetime.DateAndZone;
import com.fundtech.util.datetime.NewASDateTimeUtils;

public class DAS implements DASInterface, PDOConstantFieldsInterface, MessageConstantsInterface {

	private static final Logger logger = LoggerFactory.getLogger(DAS.class);

	private static final int MSG_NOTES_BATCH_UPDATE = 1;
	private static final int MSG_NOTES_BATCH_INSERT = 0;

	private static final int MESSAGE_EXTERNAL_INTERACTION_INSERT = 0;
	private static final int MESSAGE_EXTERNAL_INTERACTION_UPDATE = 1;

	private static final int CYCLE_SETTLEMENT_INTERACTION_INSERT = 0;
	private static final int CYCLE_SETTLEMENT_INTERACTION_UPDATE = 1;

	private static final int MESSAGE_EXTERNAL_INTERACTION_IS_EXIST = 2;

	private static final int TEMPLATE_UNCHANGED_FIELDS_DELETE = 0;
	private static final int TEMPLATE_UNCHANGED_FIELDS_INSERT = 1;
	private static String CURRENT_XML_KEY;
	private static String CURRENT_XML_ORIG_KEY;

	private static transient DAOGeneralServices m_dao = new DAOGeneralServices();
	private final String P_NON_STP_FLAG="NON_STP";
	private final String PDO_MEMBER_SINGLE_OBJECT_PREFIX = "m_o";
	private final String PDO_MEMBER_LIST_PREFIX = "m_list";
	private static ColumnMetaData[] m_minfColumnNames;
	private static String m_minfInsertQuery;
	private static Map<String, Object> m_minfDefaultValuesMap;
	private Map<String, String> m_mapDocumentXPaths = new HashMap<String, String>();
	private DAOMemoPost daoMemoPost = (DAOMemoPost) SpringApplicationContext.getBean("DAOMemoPost");
	private PDOStateHandlerInterface m_defaultPDOStateHandler ;

	// SQL STATEMENTS
	/////////////////////////////////////////////////////////////////////////////////
	
	// NEW_JOURNAL
	private static final String NEW_JOURNAL_INSERT_STATEMENT_WITH_XML = "INSERT INTO NEWJOURNAL (XML_RELATED_FIELDS_DATA, OFFICE, UPDATE_DATE, ENDDATE, USERNAME, MODULE_ID, ERROR_PARAMS, MID, "
			+ "STATUS, ACTIONID1, ACTIONID2, TIME_STAMP, CLASS, PRICING_WEIGHT, FIELD_LOGICAL_ID, FAULT, AUDIT_SUBTYPE,"
			+ "ERROR_SEVERITY, HIT_INFO, ZONE_CODE, IP_ADDRESS, ERROR_CODE, FLOW_ID, MULTIPLE, TYPE_FIELDS_CHANGE_VERIFY, PARTITION_ID) "
			+ "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

	private static final String NEW_JOURNAL_INSERT_STATEMENT_WITHOUT_XML = "INSERT INTO NEWJOURNAL (OFFICE, UPDATE_DATE, ENDDATE, USERNAME, MODULE_ID, ERROR_PARAMS, MID, "
			+ "STATUS, ACTIONID1, ACTIONID2, TIME_STAMP, CLASS, PRICING_WEIGHT, FIELD_LOGICAL_ID, FAULT, AUDIT_SUBTYPE,"
			+ "ERROR_SEVERITY, HIT_INFO, ZONE_CODE, IP_ADDRESS, ERROR_CODE, FLOW_ID, MULTIPLE, TYPE_FIELDS_CHANGE_VERIFY, PARTITION_ID) "
			+ "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

	// EXTERNAL_ERROR_MESSAGES
	private static final String EXTERNAL_MESSAGE_INSERT_STATEMENT= "INSERT INTO EXTERNAL_ERROR_MESSAGES (INTERFACE_CODE,ERROR_CODE, DESCRIPTION,  MID, ERROR_TIMESTAMP, PARTITION_ID) "
			+ "VALUES (?,?,?,?,?,?)";
				
	// MSGERR
	private static final String MSGERR_INSERT_STATEMENT = "INSERT INTO MSGERR (MID, FLOW_ID, ERROR_PARAMS, DISPLAY, TIME_STAMP, FIELD_LOGICAL_ID, "
			+ "PRICING_WEIGHT, ERROR_SEVERITY, FAULT, ERROR_CODE, ZONE_CODE, CREATE_DATE, MODULE_ID, PARTITION_ID) " + "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

	// MSG_SPECIAL_INSTRUCTION
	private static final String MSG_SPECIAL_INSTRUCITON_INSERT_STATEMENT = "INSERT INTO MSG_SPECIAL_INSTRUCTIONS "
			+ "(MID, ERROR_CODE, ERROR_PARAMS, SI_STATUS, PREVENT_STP_UID, PARTY_TYPE, OBJECT_ID," + " CREATE_DATE, ZONE_CODE, TIME_STAMP,USER_ID, PARTITION_ID)"
			+ " VALUES(?,?,?,?,?,?,?,?,?,?,?,?) ";

	private static final String MSG_SPECIAL_INSTRUCTION_UPDATE_STATEMENT = "UPDATE MSG_SPECIAL_INSTRUCTIONS SET TIME_STAMP=?, SI_STATUS = ?, USER_ID = ? WHERE MID = ? AND PARTY_TYPE = ? AND OBJECT_ID = ? AND PREVENT_STP_UID = ? AND PARTITION_ID = ?";

	
	// MSG_PARTIES
	private static final String MSG_PARTIES_INSERT_STATEMENT = "INSERT INTO MSG_PARTIES (MID, OFFICE, "
		+ "PARTY_ROLE, PARTY_ID_BIC, PARTY_ID_CUST_CODE, PARTY_ID_ABA, PARTITION_ID) VALUES (?, ?, ?, ?, ?, ?, ?)";

	private static final String MSG_PARTIES_DELETE_STATEMENT = "DELETE FROM MSG_PARTIES WHERE MID = ? AND PARTITION_ID = ? ";
	
	// DYNAMIC_PARTY_LIMIT
	private static final String DYNAMIC_PARTY_LIMIT_INSERT_STATEMENT = 
			"INSERT INTO DYNAMIC_PARTY_LIMIT " +
			"(MID, BUSINESS_DATE, ROLE, PARTY_ID_BIC, PARTY_ID_CUST_CODE, PARTY_ID_ABA, UID_PARTY_LIMITS, AMOUNT, PARTITION_ID) " +
			"VALUES (?,?,?,?,?,?,?,?,?)";

	private static final String DYNAMIC_PARTY_LIMIT_DELETE_STATEMENT = 
		"DELETE FROM DYNAMIC_PARTY_LIMIT WHERE MID = ? AND PARTITION_ID = ? " + 
		"AND ROLE IN (" + BOPartyLimit.getComaSeperatedOutgoingRoles() + ")";

	// MSG_FEES
	final String MSG_FEES_INSERT_STATMENT = "INSERT INTO MSG_FEES (MID, APPLY, FEE_CURRENCY, FEE_AMOUNT, FEE_BASE_AMOUNT, "
			+ "FEE_PNL_ACC_OFFICE, FEE_PNL_ACC_NO, FEE_PNL_ACCOUNT_CURRENCY, FEE_PNL_AMOUNT, FEE_MONITOR, "
			+ "DEDUCT_FROM, MANUAL_FEE, FEE_ACC_AMOUNT, PAYING_PARTY, FEE_FORMULA_UID, FEE_TYPE_UID, "
			+ "ORIG_FEE_AMOUNT, UNWIND_FEE, VERSION_ID, PNL_POSTING_STS, FEE_AMOUNT_IN_PMT_CCY, FEE_AMOUNT_PMT_CCY_PRE_IN_AF,FEE_POSTING_ENTRY_ID,PNL_POSTING_ENTRY_ID,PARTITION_ID) "
			+ "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

	private static final String MSG_FEES_DELETE_STATEMENT = "DELETE FROM MSG_FEES WHERE MID = ? AND PARTITION_ID = ?";

	// MSG_RULE
	private static final String MSG_RULE_LOG_INSERT_STATEMENT = "INSERT INTO MSG_RULE_LOG (TIME_STAMP, ZONE_CODE," + "FLOW_ID,DESCRIPTION, MID, PARTITION_ID) "
			+ "VALUES(?,?,?,?,?,?)";

	
	// BATCH_SUBSET
	private static final String BATCH_SUBSET_INSERT_STATEMENT = "INSERT INTO BATCH_SUBSET "
			+ "(MID, CREDIT_CURRENCY, DEBIT_CURRENCY, TOTAL_DEBIT_AM, TOTAL_MSG_COUNT_NB, STATUS, "
			+ "OFFICE, DB_ACC_NO, SUSPENSE_ACC_NO, VALUE_DATE, INTERNAL_FILE_ID, UNIQUE_GROUPING_ID, INDIVIDUAL_MID, "
			+ "UID_BATCH_SUBSET, REC_STATUS, PROFILE_CHANGE_STATUS, PENDING_ACTION, EFFECTIVE_DATE, TIME_STAMP) "
			+ "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

	private static final String BATCH_SUBSET_UPDATE_STATEMENT = "UPDATE BATCH_SUBSET SET STATUS = ? WHERE MID = ?";

	// MSG_NOTES
	private static final String MSG_NOTES_INSERT_STATEMENT = "INSERT INTO MSGNOTES (MID, USER_ID, TEXT, TIME_STAMP, ZONE_CODE, CREATE_DATE, EXTERNAL_NOTE_IND, ATTACHED_FILE_LINK, REC_STATUS, PARTITION_ID) \r\n"
			+ "VALUES (?,?,?,?,?,?,?,?,'AC',?)";

	private static final String MSG_NOTES_UPDATE_STATUS_STATEMENT = "UPDATE MSGNOTES SET UPDATED_USER_ID = ?, UPDATED_DATE_ZONE_CODE = ?, UPDATED_DATE = ?, REC_STATUS = 'DL' \r\n"
			+ "WHERE MID = ? AND TIME_STAMP = ? AND REC_STATUS = 'AC' AND PARTITION_ID = ?";

	// MFAMILY
	private static final String MFAMILY_INSERT_STATEMENT = "INSERT INTO MFAMILY "
			+ "(P_MID, SELF_RELATED_TYPE, RELATED_MID, RELATED_TYPE, TIME_STAMP, PARTITION_ID) VALUES (?,?,?,?,?,?)";

	private static final String MFAMILY_UPDATE_STATEMENT = "UPDATE MFAMILY " + "SET SELF_RELATED_TYPE = ?, RELATED_TYPE = ? "
			+ "WHERE P_MID = ? AND RELATED_MID = ? AND PARTITION_ID = ?";

	private static final String MFAMILY_DELETE_STATEMENT = "DELETE FROM MFAMILY WHERE RELATED_MID = ? and PARTITION_ID = ?";
	
	// MSG_RATES
	private static final String MSG_RATES_DELETE_STATEMENT = "DELETE FROM MESSAGERATES WHERE MID = ? AND PARTITION_ID = ?";

	private static final String MSG_RATES_INSERT_STATEMENT = "INSERT INTO MESSAGERATES (MID, CONVERSION_TYPE, CONTRACT, AMOUNT, RATE, "
			+ "FORWARD_CONTRACT, CUSTOMER_ID, SPREAD, MANUAL_SPREAD, CCY1, CCY2, PARTITION_ID) " + "VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";

	// MSG_STOP_FLAGS
	private static final String MSG_STOP_FLAGS_INSERT_STATEMENT = "INSERT INTO MSG_STOP_FLAGS (MID, STOP_FLAG_UID, SF_STATUS, OBJECT_TYPE, OBJECT_DIR, OBJECT_UID, PARTITION_ID) "
			+ "VALUES (?,?,?,?,?,?,?)";

	private static final String MSG_STOP_FLAGS_DELETE_STATEMENT = "DELETE FROM MSG_STOP_FLAGS WHERE MID = ? AND PARTITION_ID = ? AND SF_STATUS IN (0, 1)";

	
	// MINF
	private static final String MINF_DELETE_STATEMENT = "DELETE FROM MINF WHERE P_MID = ? AND P_IS_HISTORY = ?";

	
	// MESSAGE_EXTERNAL_INTERACTION
	public static final String MESSAGE_EXTERNAL_INTERACTION_INSERT_STATEMENT = "insert into message_external_interaction (mid, interface_name, interface_type, interface_sub_type, "
			+ "response_request_ind, interface_content,handle_status,msg_type,context, time_stamp, uid_message_external_inter, rec_status,resend_indicator) values(?,?,?,?,?,?,?,?,?,?,?,?,?)";

	private static final String MESSAGE_EXTERNAL_INTERACTION_UPDATE_STATEMENT = "update message_external_interaction set interface_content = ?, handle_status = ?"
			+ ",msg_type = ? ,context = ?, time_stamp = ?, uid_message_external_inter = ? , rec_status = ? where mid = ? and interface_name = ? and response_request_ind = ? and resend_indicator=?";
	
	private static final String MESSAGE_EXTERNAL_INTERACTION_IS_EXIST_STATEMENT = "select 1 from message_external_interaction where mid = ? and interface_name = ? and response_request_ind = ?";

	// CYCLE_SETTLLEMENT
	private static final String CYCLE_SETTLLEMENT_INSERT_STATEMENT = "insert into CYCLE_SETTLEMENT (DEPARTMENT, OFFICE, CLEARING_SYSTEM, TRANSACTION_DATE, BATCH_TIME, "
			+ "OUTWARD_DEBIT_COUNT, OUTWARD_DEBIT_AMOUNT, OUTWARD_DEBIT_ACCEPTED_COUNT, OUTWARD_DEBIT_ACCEPTED_AMOUNT, OUTWARD_DEBIT_REJECTED_COUNT, OUTWARD_DEBIT_REJECTED_AMOUNT, "
			+ "INWARD_CREDIT_COUNT, INWARD_CREDIT_AMOUNT, OUTWARD_RETURN_COUNT, OUTWARD_RETURN_AMOUNT, CALCULATED_NET_SETT_AMOUNT, SETTLEMENT_POSTING_TYPE, MESSAGE_USER_REFERENCE, "
			+ "UID_CYCLE_SETTLEMENT, XML_MSG,REC_STATUS,TIME_STAMP, POSTING_MESSAGE_ID) "
			+ "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

	private static final String CYCLE_SETTLLEMENT_UPDATE_STATEMENT = "UPDATE CYCLE_SETTLEMENT set DEPARTMENT = ?, OFFICE = ?, CLEARING_SYSTEM = ?, TRANSACTION_DATE = ?, BATCH_TIME = ?, "
			+ "OUTWARD_DEBIT_COUNT = ?, OUTWARD_DEBIT_AMOUNT = ?, OUTWARD_DEBIT_ACCEPTED_COUNT = ?, OUTWARD_DEBIT_ACCEPTED_AMOUNT = ?, OUTWARD_DEBIT_REJECTED_COUNT = ?, "
			+ "OUTWARD_DEBIT_REJECTED_AMOUNT = ?, INWARD_CREDIT_COUNT = ?, INWARD_CREDIT_AMOUNT = ?, OUTWARD_RETURN_COUNT = ?, OUTWARD_RETURN_AMOUNT = ?, CALCULATED_NET_SETT_AMOUNT = ?, "
			+ "SETTLEMENT_POSTING_TYPE = ?, MESSAGE_USER_REFERENCE=?, UID_CYCLE_SETTLEMENT=?, XML_MSG=? , REC_STATUS = ?, TIME_STAMP = ?, WHERE POSTING_MESSAGE_ID = ?";
	
	// TEMPLATE_UNCHANGED
	private static final String TEMPLATE_UNCHANGED_FIELDS_DELETE_STATEMENT = "DELETE FROM TEMPLATE_UNCHANGED_FIELDS WHERE MID = ? AND PARTITION_ID = ?";
	private static final String TEMPLATE_UNCHANGED_FIELDS_INSERT_STATEMENT = "INSERT INTO TEMPLATE_UNCHANGED_FIELDS (MID, UNCHANGED_FIELDS, PARTITION_ID) VALUES (?, ?, ?)";

	
	
	
	private static final int ACTIVE_MINF_PARTITION_ID = 0;
	private static final int HISTORICAL_MINF_PARTITION_ID = 1;
	private static final int TEMPLATE_MINF_PARTITION_ID = 2;

	private static Object lock = new Object();

	private static final String NEW_INSTANCE_METHOD_NAME = "newInstance";
	private static final String MUTATOR_PREFIX = "set";
	private static final String ACCESSOR_PREFIX = "get";
	private static final Class<?>[] EMPTY_CLASS_ARRAY = {};

	private static final Map<String, PDOListMemberResources> m_mapPDOListMemberResources = new HashMap<String, PDOListMemberResources>();
	private static final Map<String, Method> m_mapReferenceReflectionMethodsCache = new HashMap<String, Method>();
	static {
		CURRENT_XML_KEY = XmlLocationType.XML_MSG.name();
		CURRENT_XML_ORIG_KEY = XmlLocationType.XML_ORIG_MSG.name();
	}// EO static block

    private static final String FILE_SUMMARY_UPDATE_NUM_OF_COMPLETED_CHUNKS="update file_summary set num_of_completed_chunks = num_of_completed_chunks - ? where internal_file_id=? " +
	" and num_of_group_chunks > num_of_completed_chunks + 1";
	
	/**
	 * @since OCBC MassPayment Retrofit
	 */
	public DAS() { this.initialize() ; }//EOM
    
	/**
	 * @since OCBC MassPayment Retrofit
	 */
    private final void initialize() { 
    	//initialize the minf statement once here 
    	Connection conn = null ; 
    	try{ 
    		conn = m_dao.getConnection(); 
        
    		if (GlobalUtils.isNullOrEmpty(m_minfInsertQuery)) createMinfInsertQueryAndCoumnNames(conn);
    		
    		//initialize the default pdo state handler 
    		this.m_defaultPDOStateHandler = PluginFactory.get(PDOStateHandlerInterface.class) ; 
    	}catch(Throwable t) { 
    		if(!(t instanceof RuntimeException)) throw new RuntimeException(t) ;
    		else throw (RuntimeException) t;
    	}finally{ 
    		ServiceLocator.releaseResources(conn) ; 
    	}//EO catch block 
    }//EO
    
	private static enum PdoListMemberType {

		XBEAN {
			@Override
			public final Object unmarshall(final XmlObjectBase itemXbean, final String sObjRefDataId, final PDOListMemberResources listMemberResources) {
				return itemXbean;
			}// EOM

			@Override
			public final void marshall(final String sObjRefDataId, final XmlObjectBase memberParentXbean, final PaymentType enumTargetPaymenType,
					final Object oPdoListMember, final LogicalFieldsXpath memberXmlMetadata, final XmlElement anMarshallingMetadata,
					final DASInterface das) {

				memberParentXbean.get_store().array_setter(((List<? extends XmlObject>) oPdoListMember).toArray(new XmlObject[] {}),
						PaymentType.qname(memberXmlMetadata.getTagName(), enumTargetPaymenType.getSchemaNamespace()));
			}// EOM

			@Override
			public final Object getListItemFieldValue(final Object oListItem, final LogicalFields logicalField, final String sObjRefDataId,
					final Class<?> clsListMemberType) {
				return this.getListItemFieldValue(oListItem, logicalField.getFieldLogicalId(), sObjRefDataId, clsListMemberType);
			}// EOM

			@Override
			public final Object getListItemFieldValue(final Object oListItem, final String sFieldName, final String sObjRefDataId,
					final Class<?> clsListMemberType) {
				final XmlObjectBase xListItem = (XmlObjectBase) oListItem;

				final String sTargetNamesapce = PaymentType.qname(xListItem).getNamespaceURI();

				final XmlObject[] arrChildren = xListItem.selectChildren(PaymentType.qname(sFieldName, sTargetNamesapce));
				return (arrChildren == null || arrChildren.length == 0 ? null : ((XmlObjectBase) arrChildren[0]).getObjectValue());
			}// EOM

			@Override
			public final void setListItemFieldValue(final Object oListItem, final LogicalFields logicalField, final Object oFieldValue,
					final DASInterface das) throws IllegalAccessException {

				if (oFieldValue == null)
					return;

				final String sFieldName = logicalField.getFieldLogicalId();

				final XmlObjectBase xListItem = (XmlObjectBase) oListItem;

				final String sTargetNamesapce = PaymentType.qname(xListItem).getNamespaceURI();

				// else create the path to the node
				final XmlObjectBase memberFieldXbean = das.getOrCreateImmidiateChild(xListItem, sFieldName, 0 /* occurrence index */, sTargetNamesapce,
						null/* tagName */);

				// set the value in the node
				memberFieldXbean.setObjectValue(logicalField.getDataType().convert(oFieldValue));

			}// EOM

			@Override
			public final XmlObject ensureListItemState(final XmlObject itemXbean, final boolean bAboutToBePrunedFromXml) {
				return (bAboutToBePrunedFromXml ? itemXbean.copy() : itemXbean);
			}// EOM

		}, // EO XBean
		JPA {
			@Override
			public Object unmarshall(final XmlObjectBase itemXbean, final String sObjRefDataId, final PDOListMemberResources listMemberResources) {

				try {
					// create a new instance of the class using the newInstance method
					// retrieve the member's children from the cache.
					Method newInstanceMethod = listMemberResources.newInstanceMethod;

					if (newInstanceMethod == null) {
						newInstanceMethod = listMemberResources.clsListMemberInstance.getMethod(NEW_INSTANCE_METHOD_NAME);
						listMemberResources.newInstanceMethod = newInstanceMethod;
					}// EO if the new instance method for the given member type was not yet initialised

					// create the instance
					final Object oNewInstance = newInstanceMethod.invoke(null/* instance */);

					// iterate over the itemXbean children and for each child, attempt to retreive the
					// corresponding logical field using the node name as the logical field id.
					// if the field metadata was defined, rertieve the node's value, convert it to the
					// field's datatype and set it in the item instance using the logical field's location
					// Note: currently only immediate children are supported
					final XmlCursor xmlcur = itemXbean.newCursor();
					xmlcur.toFirstChild();
					String sChildFID = null, sChildLocation = null;
					XmlObjectBase itemChild = null;
					Object oChildValue = null;
					LogicalFields memberChildLogicalField = null;
					do {
						itemChild = (XmlObjectBase) xmlcur.getObject();
						sChildFID = itemChild.getDomNode().getLocalName();
						// attempt to retrieve the metadata from the logical fields cache
						memberChildLogicalField = CacheKeys.LogicalFieldsIdKey.getSingle(sChildFID);
						if (memberChildLogicalField == null)
							continue;
						// else
						// extract & convert the node's value
						oChildValue = memberChildLogicalField.getDataType().convert(itemChild.getObjectValue());

						if (oChildValue == null)
							continue;
						// else

						sChildLocation = memberChildLogicalField.getLocation();
						// attempt to retrieve the new instance setter method

						this.setMemberFieldValueInner(sChildLocation /* sMethodName */, MUTATOR_PREFIX, sObjRefDataId /* sMemberID */,
								listMemberResources.clsListMemberInstance, oNewInstance, oChildValue);

						// EO while there are are more child elements
					} while (xmlcur.toNextSibling());

					xmlcur.dispose();

					return oNewInstance;
				} catch (Exception e) {
					ExceptionController.getInstance().handleException(e, this);

					return null;
				}// EO catch block
			}// EOM

			@Override
			public final Object getListItemFieldValue(final Object oListItem, final LogicalFields logicalField, final String sObjRefDataId,
					final Class<?> clsListMemberType) {
				return this.getListItemFieldValue(oListItem, logicalField.getLocation(), sObjRefDataId, clsListMemberType);
			}// EOM

			@Override
			public final Object getListItemFieldValue(final Object oListItem, final String sMethodName, final String sObjRefDataId,
					final Class<?> clsListMemberType) {
				return this.getMemberFieldValueInner(sMethodName, ACCESSOR_PREFIX, sObjRefDataId /* sMemberID */, clsListMemberType, oListItem);
			}// EOM

			@Override
			public final void marshall(final String sObjRefDataId, final XmlObjectBase memberParentXbean, final PaymentType enumTargetPaymenType,
					final Object oPdoListMember, final LogicalFieldsXpath memberXmlMetadata, final XmlElement anMarshallingMetadata,
					final DASInterface das) {

				final List listPdoListMember = (List) oPdoListMember;

				// if the list is null, return null
				if (oPdoListMember == null)
					return;

				try {

					final List<LogicalFields> listChildFields = new ArrayList<LogicalFields>();

					CacheKeys.LogicalFieldsObjRefKey.get(listChildFields, sObjRefDataId);

					final String sTargetNamesapce = enumTargetPaymenType.getSchemaNamespace();
					String sLocation = null, sChildFieldId = null;
					Object oFieldValue = null;

					Class<?> clsListMemberType = null;
					final QName qnMarshallingType = PaymentType.qname(anMarshallingMetadata.name(), anMarshallingMetadata.namespace());
					XmlObjectBase marshalledInstanceXbean = null, marshalledChildXbean = null;
					final TypeStore parentTypeStore = memberParentXbean.get_store();
					Object oListItem = null;
					final int iLength = listPdoListMember.size();

					for (int i = 0; i < iLength; i++) {

						oListItem = listPdoListMember.get(i);
						if (clsListMemberType == null)
							clsListMemberType = oListItem.getClass();

						// create a new marshalling instance using the qnMarshallingType
						marshalledInstanceXbean = (XmlObjectBase) parentTypeStore.insert_element_user(qnMarshallingType, i);

						for (LogicalFields childLogicalField : listChildFields) {

							sChildFieldId = childLogicalField.getFieldLogicalId();
							sLocation = childLogicalField.getLocation();

							oFieldValue = this.getMemberFieldValueInner(sLocation /* sMethodName */, ACCESSOR_PREFIX, sObjRefDataId /* sMemberID */,
									clsListMemberType, oListItem);

							// if there is no value skip creation ]
							if (oFieldValue == null)
								continue;

							// else create the path to the node
							marshalledChildXbean = das.getOrCreateImmidiateChild(marshalledInstanceXbean, sChildFieldId, 0 /* occurrence index */,
									sTargetNamesapce, null/* tagName */);

							// set the value in the node
							childLogicalField.getDataType().setXbeanValue(marshalledChildXbean, oFieldValue);

						}// EO while there are more child fields

					}// EO while there are more items (records)
				} catch (Exception e) {
					ExceptionController.getInstance().handleException(e, this);
				}// EO catch block
			}// EOM

			@Override
			public final void setListItemFieldValue(final Object oListItem, final LogicalFields logicalField, final Object oFieldValue,
					final DASInterface das) throws NoSuchMethodException, IllegalAccessException, InvocationTargetException {

				final String sFieldLocation = logicalField.getLocation();
				final String sObjRefDataId = logicalField.getObjRefDataId();
				final Class<?> clsListMemberType = oListItem.getClass();

				this.setMemberFieldValueInner(sFieldLocation /* sMethodName */, MUTATOR_PREFIX, sObjRefDataId /* sMemberID */, clsListMemberType,
						oListItem, oFieldValue);
			}// EOM

			private final void setMemberFieldValueInner(final String sMethodName, final String sMethodPrefix, final String sMemberID,
					final Class<?> clsMemberType, final Object oMemberInstance, final Object oFieldValue) throws NoSuchMethodException,
					IllegalAccessException, InvocationTargetException {
				final Method memberChildMethod = this.getMemberMethod(sMethodName, sMethodPrefix, sMemberID, clsMemberType,
						(oFieldValue == null ? EMPTY_CLASS_ARRAY : new Class<?>[] { oFieldValue.getClass() }));

				final boolean bAccessible = memberChildMethod.isAccessible();
				memberChildMethod.setAccessible(true);
				memberChildMethod.invoke(oMemberInstance, oFieldValue);
				memberChildMethod.setAccessible(bAccessible);
			}// EOM

			private final Object getMemberFieldValueInner(final String sMethodName, final String sMethodPrefix, final String sMemberID,
					final Class<?> clsMemberType, final Object oMemberInstance) {

				Object oFieldValue = null;
				try {
					final Method memberChildMethod = this.getMemberMethod(sMethodName, sMethodPrefix, sMemberID, clsMemberType);

					final boolean bAccessible = memberChildMethod.isAccessible();
					memberChildMethod.setAccessible(true);
					oFieldValue = memberChildMethod.invoke(oMemberInstance);
					memberChildMethod.setAccessible(bAccessible);
					return oFieldValue;
				} catch (Exception e) {
					ExceptionController.getInstance().handleException(e, this);
				}// EO catch block

				return oFieldValue;
			}// EOM

			private final Method getMemberMethod(final String sMethodName, final String sMethodPrefix, final String sMemberID,
					final Class<?> clsMemberType, final Class<?>... arrFormalArgTypes) throws NoSuchMethodException {

				// attempt to retrieve the new instance setter method
				final String sChildMethodNameKey = sMethodPrefix + sMemberID + sMethodName;
				Method childMethod = m_mapReferenceReflectionMethodsCache.get(sChildMethodNameKey);

				if (childMethod == null) {
					childMethod = clsMemberType.getDeclaredMethod(sMethodPrefix + sMethodName, arrFormalArgTypes);
					m_mapReferenceReflectionMethodsCache.put(sChildMethodNameKey, childMethod);
				}// EO if the setter was not yet initialized

				return childMethod;
			}// EOM

		};// EO JPA

		public abstract Object unmarshall(final XmlObjectBase listItemXbean, final String sObjRefDataId,
				final PDOListMemberResources listMemberResources);

		public abstract void marshall(final String sObjRefDataId, final XmlObjectBase memberParentXbean, final PaymentType enumTargetPaymenType,
				final Object oPdoListMember, final LogicalFieldsXpath memberXmlMetadata, final XmlElement anMarshallingMetadata,
				final DASInterface das);

		public abstract Object getListItemFieldValue(final Object oListItem, final LogicalFields logicalField, final String sObjRefDataId,
				final Class<?> clsListMemberType);

		public abstract Object getListItemFieldValue(final Object oListItem, final String sFieldName, final String sObjRefDataId,
				final Class<?> clsListMemberType);

		public abstract void setListItemFieldValue(final Object oListItem, final LogicalFields logicalField, final Object oFieldValue,
				final DASInterface das) throws NoSuchMethodException, IllegalAccessException, InvocationTargetException;

		public XmlObject ensureListItemState(final XmlObject itemXbean, final boolean bAboutToBePrunedFromXml) {
			return itemXbean;
		}// EOM

		public static final PdoListMemberType unmarshallingRevrseVauleOf(final Class<?> clsItemType) {
			final Class<?> clsListItemEnclosingClass = clsItemType.getEnclosingClass();
			return ((clsListItemEnclosingClass != null && XmlObject.class.isAssignableFrom(clsListItemEnclosingClass))
					|| XmlObject.class.isAssignableFrom(clsItemType) ? XBEAN : JPA);
		}// EOM

		public static final PdoListMemberType marshallingReverseValueOf(final XmlElement anListTypeMetadata) {
			return (anListTypeMetadata == null ? XBEAN : JPA);
		}// EOM

	}// EOc PdoListMemberType

	/**
	 * 
	 * Jan 13, 2010 Guys
	 * 
	 * @param enumXmlLocationType
	 * @param mapMappedValues
	 * @param pdo
	 * @param bDeriveOrigFields
	 *            if the flag is true, a new derived payment field would be created for each payment field if the logicalFields.getOrigFieldId is not
	 *            null.
	 * @param bConjoinedMode
	 *            if the flag is true, the orig and current fields would be linked
	 * @param oInput
	 * @return
	 * @throws Exception
	 */
	private final XmlMetadata performXmlMapping(XmlLocationType enumXmlLocationType, Map mapMappedValues, final PDO pdo,
			final boolean bDeriveOrigFields, final boolean bConjoinedMode, final boolean bMergeContext, final Object oInput, XmlObject xmlOrigCopy)
			throws Exception {

		// use the xml dao to extract the input stream from the resultset and
		// initialise the xml document.
		// first parse the input
		
		logger.debug("DAS -performXmlMapping: xml mapping for xml type {} started", enumXmlLocationType);
		
		final PaymentInputSourceType enumInputSourceType = PaymentInputSourceType.reverseValueOf(oInput);
		logger.debug("DAS -performXmlMapping: payment input source type was derived");
		XmlObjectBase xmlDoc = null;
		String sParseErrorMsg = null;
		try {
			xmlDoc = enumInputSourceType.parse(enumXmlLocationType, oInput, pdo);			
			logger.debug("DAS -performXmlMapping: xml doc was recieved");
		} catch (PaymentFormattingException pfe) {
			sParseErrorMsg = pfe.getMessage();

			logger.error("PaymentFormattingException Stacktrace:\n{}",pfe.getStackTrace());
			
			logger.error("Parsing Error for Message {}, XML Type {} and input source content {} \nwith error message:\n{}",
					new Object[] { pdo.getMID(), enumXmlLocationType, oInput, sParseErrorMsg });

			// rertieve the document from the exception
			xmlDoc = pfe.getEncapsulatedRawMsgXbean();

			// if(!bEnsureWrapper) xmlDoc = (XmlObjectBase) FndtMsgPaymentType.getPmnt(xmlDoc) ;

			// add an error to the pdo
			ErrorAuditUtils.setErrors(new ProcessError(ProcessErrorConstants.PDOXmlInvalidFormat, new Object[] { sParseErrorMsg }), pdo);

			// mark the pdo as empty by setting the message mode as non global and the status as normal
			// the is empty() would be used in the newPdO() to determine whether the pdo should
			// be assigned a special AUTHEX status
			pdo.setIsGlobalPDO(false);

		}// EO catch block

		// Gets the payment type;
		final PaymentType enumPaymentType = PaymentType.valueOf(xmlDoc);

		if (enumPaymentType == null) {
			final SchemaType schemaType = xmlDoc.schemaType();
			QName elementQname = schemaType.getName();
			if (elementQname == null)
				elementQname = schemaType.getDocumentElementName();
			if (elementQname == null)
				elementQname = new QName(xmlDoc.getDomNode().getNamespaceURI(), xmlDoc.getDomNode().getLocalName());
			throw new IllegalArgumentException(elementQname + " is unsupported or invalid");
		}// EO if the payment type enumeration could not be derived

		logger.debug("DAS -performXmlMapping: payment type was determined");
		
		// create a new xml metadata regardless of whether the payment type is transient but only store it in
		// the pdo if it is not against the paymentTypes xmlLocationType
		// if the bDeriveOrigFields is set to true and the transient flag of the payment type is fales, clone the xml metadata
		// and store in the pdo
		XmlLocationType enumActualLocationType = enumXmlLocationType.configureLocation(enumPaymentType);
		final boolean bPaymentTypeTransient = bMergeContext || enumPaymentType.isTransient();

		final XmlMetadata xmlmetadata = pdo.addXmlDocument(enumActualLocationType, enumPaymentType, xmlDoc, !bPaymentTypeTransient);

		logger.debug("DAS -performXmlMapping: XmlMetadata was created");
		
		// if there is a need to store a cloned version of the doucment against the orig key counterparrt
		// store the orig xml document against the counter part key
		if (bDeriveOrigFields && !bPaymentTypeTransient) {
			if (xmlOrigCopy == null)
				xmlOrigCopy = (bConjoinedMode ? xmlDoc : PaymentType.m_contextXchemaTypeLoader.parse(xmlDoc.getDomNode(), null, null));
			if (bConjoinedMode && xmlOrigCopy != xmlDoc)
				xmlOrigCopy = xmlDoc;
			else if (!((XmlObjectBase) xmlOrigCopy).isInstanceOf(xmlDoc.schemaType())) {

				final XmlCursor origToParentXmlcur = xmlOrigCopy.newCursor();
				origToParentXmlcur.toParent();

				final XmlCursor curToParentXmlcur = xmlDoc.newCursor();
				curToParentXmlcur.toParent();
				// origToParentXmlcur.copyXml(curToParentXmlcur) ;
				origToParentXmlcur.getObject().set(curToParentXmlcur.getObject());
				curToParentXmlcur.dispose();

				origToParentXmlcur.toFirstChild();
				xmlOrigCopy = origToParentXmlcur.getObject();
				origToParentXmlcur.dispose();

			}// EO else if the orig document is not the same as the current
			pdo.addXmlDocument(enumActualLocationType.getCounterpartLocation(), enumPaymentType, (XmlObjectBase) xmlOrigCopy);
		}// EO if there is a need to store the xml document against the orig key as well

		this.performXmlMapping(enumActualLocationType, enumPaymentType, xmlDoc, mapMappedValues, pdo, bDeriveOrigFields, bConjoinedMode,
				bMergeContext, null/* listCustomizedXmlGruoups */);
		
		logger.debug("DAS -performXmlMapping: xml mapping for xml type %s ended succcessfully", enumXmlLocationType);

		return xmlmetadata;
	}// EOM

	public final void performXmlMapping(final XmlLocationType enumXmlLocationType, final PaymentType enumPaymentType, final XmlObjectBase xmlDoc,
			Map mapPaymentData, final PDO pdo, final boolean bDeriveOrigFields, final boolean bConjoinedMode, final boolean bMergeContext,
			List<LogicalFieldsXpath> listCustomizedXmlGroups) throws Exception {

		final String sXmlLocationType = enumXmlLocationType.name();

		// step 1: Retrieve the Logical Fields Path Parents (Groups) from cache if not provdided as a formal argument
		List<LogicalFieldsXpath> listXmlGroups = null;

		if (listCustomizedXmlGroups == null) {
			listXmlGroups = new ArrayList<LogicalFieldsXpath>();

			CacheKeys.LogicalFieldsXPathGroupsKey.get(listXmlGroups, enumPaymentType, sXmlLocationType);
		} else
			listXmlGroups = listCustomizedXmlGroups;

		// step 2: create two cursors from the xmlDoc, one for the parsing and one for removal comparison against the root doc
		// so as not to remove it accidentally
		final XmlCursor xmlcur = xmlDoc.newCursor(), rootDocumentXmlcur = xmlDoc.newCursor();
		// always nagivate to the node's immediate parent so as to support
		// full path from root for DB querys if the parent element is not a supported message type (for instance batch messages scenario)
		boolean bUseSelfAxis = false;

		xmlcur.push();
		xmlcur.toParent();
		if (((XmlObjectBase) xmlcur.getObject()).get_store().count_elements(enumPaymentType.qname()) > 1) {
			xmlcur.pop();
			bUseSelfAxis = true;
		}// EO if the parent element is not a valid pa

		xmlcur.clearSelections();

		// step 3: prepare an xquery template
		// final String sXqueryTemplate = "declare default element namespace '" +
		// enumPaymentType.getSchemaNamespace() + "';"+enumPaymentType.getXpathAdditionalNamespaceCaluse()+"." ;

		final String sXqueryTemplate = enumPaymentType.getXpathlNamespaceCaluse() + ".";

		// step 4: Iterator over the groups list
		// NOTE: for now the group node will not be stored in the map.
		// NOTE; if the node was not found, store a place holder in its place
		final Iterator<LogicalFieldsXpath> xmlgroupsIterator = listXmlGroups.iterator();

		LogicalFieldsXpath logicalFieldXpath = null, logicalFieldsXPathChild = null;
		LogicalFields logicalFieldGroup, logicalFieldsChild;
		List<LogicalFieldsXpath> listGroupChildren = new ArrayList<LogicalFieldsXpath>();
		String sLogicalFieldGroupId, sLogicalFieldChildId = null;
		Iterator<LogicalFieldsXpath> childrenIterator = null;
		PaymentFieldInterface aField = null;
		Object oNodeValue;
		Object newDocument = null;
		XmlObject xmlDocOrigCopy = null, newOrigXmlDoc = null;

		XmlMetadata currentPdoXmlMetadata = null;
		LogicalFieldsXpath currPdoPmntTypeLogicalFieldXpathMetadataChild = null, currPdoPmntTypeLogicalFieldXpathMetadataGroup = null;
		PaymentType currentPdoPaymentType = null;
		Map<String, LogicalFieldsXpath> mapCurrentPdoPaymentTypeFieldsXPaths = null;
		XmlObjectBase newMergedNode = null;
		String sPath = null;
		final boolean bIsNewPdo = pdo.isNew();
		boolean bNewField = false, bNonXmlField = false;

		try {

			while (xmlgroupsIterator.hasNext()) {

				logicalFieldXpath = xmlgroupsIterator.next();

				// step 5: bookmark the current cursor location and execute the group's xpath
				xmlcur.push();

				sLogicalFieldGroupId = logicalFieldXpath.getFieldLogicalId();

				// execute the xpath on the cursor
				sPath = logicalFieldXpath.getFieldPath();
				if (bUseSelfAxis)
					sPath = "/self::" + sPath.substring(1);

				xmlcur.selectPath(sXqueryTemplate + sPath);

				// step 6: if there was no selection continue (no need to pop the location as
				// it was not altered
				if (!xmlcur.toNextSelection())
					continue;

				// if the group is a document, recurse (as this is a breakdown of the document
				if (logicalFieldXpath.getDocumentInd()) {
					newDocument = xmlcur.getObject();

					logger.trace("Branching for xml type {} to sub-document :n{}", sXmlLocationType, newDocument);

					// if the derive orig fields is true, and the xmlDocOrigCopy is null, create a copy of the current xmldoc and
					// pass it to the recursion
					if (bDeriveOrigFields) {

						if (xmlDocOrigCopy == null)
							xmlDocOrigCopy = (bConjoinedMode ? xmlDoc : PaymentType.m_contextXchemaTypeLoader.parse(xmlDoc.getDomNode(), null, null));

						// if the bConjoinedMode is false select the same path but from the xmlDocOrigCopy (must be present as it is an exact copy of
						// the current doc
						// else use the new document as the "copy"
						newOrigXmlDoc = (bConjoinedMode ? (XmlObject) newDocument : xmlDocOrigCopy.selectPath(sXqueryTemplate
								+ logicalFieldXpath.getFieldPath())[0]);
					}// EO if the derive orig fields flag was set to true

					// use the new document's location instead of the current location
					this.performXmlMapping(enumXmlLocationType, mapPaymentData, pdo, bDeriveOrigFields, bConjoinedMode,
							bMergeContext/* merge context */, newDocument, newOrigXmlDoc);
					xmlcur.pop();
					continue;
				}// EO if the group is in fact a document to be branched into

				logicalFieldGroup = LogicalFieldsIdKey.getSingle(sLogicalFieldGroupId);

				// if the group is a multi occurrence one store the group itself
				// and skip the children
				if (FieldType.isXmlMulti(logicalFieldXpath.getFieldType())) {

					// This child is from field type MEMBER, which means that its value
					// should be assigned to a class member in the PDO which is either
					// a list or some object.
					// e.g. M_FC_LINE stands for the PDO 'm_MESSAGERATES' class member
					// which stands for a list of message rates, (MESSAGERATES table).
					if (logicalFieldGroup != null && logicalFieldGroup.getFieldType() == FieldType.MEMBER) {
						// the xpath should have selected all child node and inserted them into the cursor's selection buffer.
						// navigate to the immediate parent to the selection (this would not affect the actual selection) as the parent is required
						// for both the parsing and the removal actions
						xmlcur.toParent();
						this.handleMEMBERTypeField(logicalFieldGroup.getLocation(), logicalFieldXpath.getFieldType(), xmlcur, pdo,
								logicalFieldXpath.getRemoveFromXml());
						// handle the remove from xml instruction
						this.pruneXml(xmlcur, rootDocumentXmlcur, logicalFieldXpath.getRemoveFromXml(), true /* bForceRemove */);
						xmlcur.pop();
						continue;
					}// EO if the group was a member

					aField = (XmlPaymentField) mapPaymentData.get(sLogicalFieldGroupId);
					if (aField == null) {
						// retrieve the Group's LogicalFieds JPA instance
						// get the metadata's field type and use it to create the field
						aField = logicalFieldGroup.getFieldType().newPaymentField(sLogicalFieldGroupId, logicalFieldGroup,pdo);
						bNewField = true;
					}// EO else if the field already exists

					if (bMergeContext) {
						// if the field was a new one, retrieve the field's metadata first

						// init the current pdo's mertadata resources if not already created
						if (mapCurrentPdoPaymentTypeFieldsXPaths == null) {
							currentPdoXmlMetadata = pdo.getXmlMetadata(sXmlLocationType);
							currentPdoPaymentType = currentPdoXmlMetadata.getPaymentType();

							mapCurrentPdoPaymentTypeFieldsXPaths = CacheKeys.LogicalFieldsXPathKey.getSingle(currentPdoPaymentType);

						}// EO if not initialized yet
						if (bNewField) {
							currPdoPmntTypeLogicalFieldXpathMetadataGroup = mapCurrentPdoPaymentTypeFieldsXPaths.get(sLogicalFieldGroupId);
						}// EO if the field was not yet defined in the pdo
							// invoke the special set the from xml
						((XmlMultiOccurencePaymentField) aField).setFromXml(xmlcur, currentPdoXmlMetadata.getXml(),
								false/* useInstanceDocumentAsNodeRef */, logicalFieldXpath, currPdoPmntTypeLogicalFieldXpathMetadataGroup,
								enumPaymentType, currentPdoPaymentType, this);

					}// EO if merge context
					else
						((XmlMultiOccurencePaymentField) aField).setFromXml(xmlcur, logicalFieldXpath, enumPaymentType, !bIsNewPdo/* bupdateOrigVal */);

					mapPaymentData.put(sLogicalFieldGroupId, aField);

					// attempt to derive and link the field to the orig field
					this.handleOrigPaymentField(pdo, (Map) null /* xpath metadta map */, (XmlObjectBase) xmlcur.getObject(), aField,
							logicalFieldGroup, enumPaymentType, bDeriveOrigFields, bConjoinedMode, !bIsNewPdo/* bupdateOrigVal */);

					// handle the remove from xml instruction
					this.pruneXml(xmlcur, rootDocumentXmlcur, logicalFieldXpath.getRemoveFromXml(), true /* bForceRemove */);

					// pop the cursor back to the root document element
					xmlcur.pop();

					continue;

				}// EO if the group is a multi occurrence one
				else if (logicalFieldGroup.getFieldType() == FieldType.XML_SLF_EXT_GROUP) {
					/*
					 * handleSefExtractingGroup(final XmlObjectBase groupXbean, final XmlCursor xmlcur, final PaymentType enumTargetPaymentType, final
					 * Map<Object, PaymentFieldInterface> mapPaymentData, final PDO pdo, final boolean bDeriveOrigFields, final boolean
					 * bConjoinedMode) {
					 */
					this.handleSelfExtractingGroup(xmlcur, enumPaymentType, mapPaymentData, pdo, bDeriveOrigFields, bConjoinedMode);
					xmlcur.pop();
					continue;
				}// EO if self extracting group

				// if the group has a move-to-field id, then the only required action
				// is to move the group's node to the new location
				if (!GlobalUtils.isNullOrEmpty(logicalFieldGroup.getMoveToField())) {
					this.moveField(xmlcur, logicalFieldGroup, null, xmlDoc, rootDocumentXmlcur, enumPaymentType, mapPaymentData);
					continue;
				}// EO if this was a move to field operation

				// step 7: else if the group node was found, retrieve the node children list from the cache
				// using the Payment Type, Xml Type and logical field ID
				CacheKeys.LocicalFieldsXpathChildrenKey.get(listGroupChildren, sLogicalFieldGroupId, enumPaymentType, sXmlLocationType);

				// if there is no children metadata continue to the next
				if (listGroupChildren.isEmpty()) {
					xmlcur.pop();
					continue;
				}// EO if there were no children

				// step 8: iterate over the children and for each execute the relative path on the group node
				// (current cursor position)
				childrenIterator = listGroupChildren.iterator();

				while (childrenIterator.hasNext()) {

					// clear merge context resources
					currPdoPmntTypeLogicalFieldXpathMetadataChild = null;
					currPdoPmntTypeLogicalFieldXpathMetadataGroup = null;
					newMergedNode = null;
					bNewField = false;

					logicalFieldsXPathChild = childrenIterator.next();
					sLogicalFieldChildId = logicalFieldsXPathChild.getFieldLogicalId();

					// if the logicalfield is a group (a special scenario used only for data manipulation
					// removals, continue as the field should not participate in the procedure
					if (logicalFieldsXPathChild.getFieldType() == FieldType.XML_GROUP) {

						// handle the remove from xml instruction
						this.pruneXml(xmlcur, rootDocumentXmlcur, logicalFieldsXPathChild.getRemoveFromXml(), true /* bForceRemove */);

						continue;
					}// EO if the field was a removal group

					// step 9: bookmark the current cursor location and execute the child's xpath
					xmlcur.push();

					// execute the xpath
					xmlcur.selectPath(sXqueryTemplate + logicalFieldsXPathChild.getFieldPath());

					// get the metadata's field type and use it to create the field
					logicalFieldsChild = LogicalFieldsIdKey.getSingle(sLogicalFieldChildId);

					bNonXmlField = (logicalFieldsChild == null || !FieldType.isXmlType(logicalFieldsChild.getFieldType()));

					// This child is from field type MEMBER, which means that its value
					// should be assigned to a class member in the PDO which is either
					// a list or some object.
					// e.g. M_FC_LINE stands for the PDO 'm_MESSAGERATES' class member
					// which stands for a list of message rates, (MESSAGERATES table).
					if (logicalFieldsChild != null && logicalFieldsChild.getFieldType() == FieldType.MEMBER) {
						this.handleMEMBERTypeField(logicalFieldsChild.getLocation(), logicalFieldsXPathChild.getFieldType(), xmlcur, pdo,
								logicalFieldsXPathChild.getRemoveFromXml());

						// store a place holder as the field map represantation so that
						// the transformPDO's pdo.get on the id shall not attempt to createNSet
						aField = PaymentField.PLACE_HOLDER;

					}// EO if the element was a MEMBER (psuedo JPA)

					// step 10: if there was no selection, replace complete map value with a place holder
					// else create a new payment field
					// if the field type was not xml then this is a copy to field
					// (e.g. relational field whose value originates from the extension xml)
					// which means that the payment field to be set with the actual node's value
					// /and not the node reference
					else if (!xmlcur.toNextSelection()) {
						if (bIsNewPdo && !bNonXmlField)
							aField = PaymentField.PLACE_HOLDER;
						else {
							xmlcur.pop();
							continue;
						}// EO else if the context was not that of a new pdo, there would be no need to add place holder to the map (as it might
							// override)
					}// EO else if there was no child xml node

					else {// else if there was a child xml node in the xmlcur selection

						// if the child field has a move-to-field id, then the only required action
						// is to move the current cursor's node to the new location
						if (!GlobalUtils.isNullOrEmpty(logicalFieldsChild.getMoveToField())) {
							this.moveField(xmlcur, logicalFieldsChild, logicalFieldGroup, xmlDoc, rootDocumentXmlcur, enumPaymentType, mapPaymentData);
							continue;
						}// EO if this was a move to field operation

						if (bNonXmlField) {
							oNodeValue = null;
							try {
								oNodeValue = logicalFieldsChild.getDataType().convert(((XmlObjectBase) xmlcur.getObject()).getStringValue());
							} catch (Exception e) {
								logger.error("Xml Logical Field [{}] has an invalid value {}. Setting the field to null", logicalFieldsXPathChild, xmlcur.getObject());
							}

							// if the field metadata is null, create the field as derived
							if (logicalFieldsChild == null) {
								aField = FieldType.DERIVED.newPaymentField(sLogicalFieldChildId, oNodeValue, pdo);
							} else { // else if the field was not an xml field and had metadata
								if (mapPaymentData.containsKey(sLogicalFieldChildId)) {
									pdo.set(sLogicalFieldChildId, oNodeValue);
									aField = (PaymentFieldInterface) mapPaymentData.get(sLogicalFieldChildId);
								}// EO if the field was already present in the data map (merge)
								else {

									aField = logicalFieldsChild.getFieldType().newPaymentField(sLogicalFieldChildId, logicalFieldsChild,pdo);

									if (aField.getFieldType() == FieldType.MONITOR_CHILD)
										aField.extraInit(pdo);

									aField.set(oNodeValue, bIsNewPdo);
								}// EO else if the field was not yet created
							}// EO else if the metadata was present

						} else { // EO else if the field was an xml field

							// first attempt to retrieve the payment field from the map and if already exists
							// use it, otherwise create a new one
							// scenarios where the field might already exists: merge, initial create state where the payment field was created
							// as part of the linked fields functionality
							aField = (PaymentFieldInterface) mapPaymentData.get(sLogicalFieldChildId);
							if (aField == null || aField == PaymentField.PLACE_HOLDER) {
								aField = logicalFieldsChild.getFieldType().newPaymentField(sLogicalFieldChildId, logicalFieldsChild,pdo);
								bNewField = true;
							}// EO if the field was not already defined

							if (bMergeContext) {
								// init the current pdo's mertadata resources if not already created
								if (mapCurrentPdoPaymentTypeFieldsXPaths == null) {

									currentPdoXmlMetadata = pdo.getXmlMetadata(sXmlLocationType);
									currentPdoPaymentType = currentPdoXmlMetadata.getPaymentType();

									mapCurrentPdoPaymentTypeFieldsXPaths = CacheKeys.LogicalFieldsXPathKey.getSingle(currentPdoPaymentType);

								}// EO if not initialized yet

								currPdoPmntTypeLogicalFieldXpathMetadataChild = mapCurrentPdoPaymentTypeFieldsXPaths.get(sLogicalFieldChildId);

								// if the child does not exist for the payment's payment type, skip the creation
								if (currPdoPmntTypeLogicalFieldXpathMetadataChild == null) {
									oNodeValue = (logicalFieldsChild.getDataType().convert(((XmlObjectBase) xmlcur.getObject()).getStringValue()));
									aField = FieldType.DERIVED.newPaymentField(sLogicalFieldChildId, oNodeValue, pdo);
									// EO if the payment type does not have a definition for the given logical field
								} else {

									// set changed indication in order to save the xml column.
									pdo.getXmlMetadata(enumXmlLocationType.name()).setChanged();
									// if the element is multi invoke the set from xml which shall create the hierarchy,
									// else create the node here
									if (FieldType.isXmlMulti(currPdoPmntTypeLogicalFieldXpathMetadataChild.getFieldType())) {
										((XmlMultiOccurencePaymentField) aField).setFromXml(xmlcur, currentPdoXmlMetadata.getXml(),
												false /* useInstanceDocumentAsNodeRef */, logicalFieldsXPathChild,
												currPdoPmntTypeLogicalFieldXpathMetadataChild, enumPaymentType, currentPdoPaymentType, this);
									} else if (bNewField) {

										// retrieve the xpath parent xml metadata and from it the path from the root. append to the child path and
										// pass to the method
										currPdoPmntTypeLogicalFieldXpathMetadataGroup = mapCurrentPdoPaymentTypeFieldsXPaths
												.get(currPdoPmntTypeLogicalFieldXpathMetadataChild.getPathParentId());
										// create the the new node
										newMergedNode = this.getOrCreateXmlNode(currPdoPmntTypeLogicalFieldXpathMetadataGroup.getFieldPath()
												+ currPdoPmntTypeLogicalFieldXpathMetadataChild.getFieldPath(),
												currPdoPmntTypeLogicalFieldXpathMetadataChild.getTagName(), currentPdoXmlMetadata.getXml(),
												currentPdoPaymentType.getSchemaNamespace(), false /* member or multi */);
										// , sTagName, rootElement, sNamespace, bIsMemberAndMultiChild)

										((XmlPaymentField) aField).setFromXml(newMergedNode, xmlcur, currPdoPmntTypeLogicalFieldXpathMetadataChild,
												currentPdoPaymentType, false/* bupdateOrigVal */);

									}// EO else if not multi occurrence
									else
										((XmlPaymentField) aField).setFromXml((XmlObjectBase) xmlcur.getObject() /* new node */, xmlcur,
												logicalFieldsXPathChild, enumPaymentType, false/* bUpdateOrigVal */);
								}// else if exists in payment type

							}// EO if merge context
							else
								((XmlPaymentField) aField).setFromXml(xmlcur, logicalFieldsXPathChild, enumPaymentType, !bIsNewPdo/* bupdateOrigVal */);

						}// EO else if the field was of xml native type

					}// EO else if the node was prensent in the xml

					// step 11: if there is a copy to field associated with this field, create it (if not already created and assign the value to it
					// as well
					// note as the copy to field can be associated to more than one logical fields, the value would be overriden such that the
					// last assignment shall define the value
					this.handleCopyToField(aField, mapPaymentData, pdo);

					// step 12: handle orig field derivation and linkage which are currently supported only in joint xmls scneario in initial create
					// mode (user create)
					this.handleOrigPaymentField(pdo, (Map) null /* xpath metadta map */, (XmlObjectBase) xmlcur.getObject(), aField,
							logicalFieldsChild, enumPaymentType, bDeriveOrigFields, bConjoinedMode, !bIsNewPdo/* bupdateOrigVal */);

					// step 13: handle the remove from xml instruction
					this.pruneXml(xmlcur, rootDocumentXmlcur, logicalFieldsXPathChild.getRemoveFromXml(), true /* bForceRemove */);

					mapPaymentData.put(sLogicalFieldChildId, aField);

					// restore the cursor to the parent location
					xmlcur.pop();

				}// EO while there are more child fields to the current group

				// clear the children list
				listGroupChildren.clear();

				// handle the remove from xml instruction if present on the group
				this.pruneXml(xmlcur, rootDocumentXmlcur, logicalFieldXpath.getRemoveFromXml(), true /* bForceRemove */);

				// pop the cursor back to the root document element
				xmlcur.pop();
			}// EO while there are more xml groups to map.
		} catch (RuntimeException e) {
			logger.error(e.getMessage());
			logger.error("stack trace:\n {}",e.getStackTrace());
			final StringBuilder sMassege = new StringBuilder("************ DAS - performXmlMapping: LOAD XML FAILD type = ");
			if (sXmlLocationType != null)
				sMassege.append(sXmlLocationType).append(" with field ");
			else
				logger.error("sXmlLocationType is null");
			if (logicalFieldXpath != null)
			{
				if (logicalFieldXpath.getFieldLogicalId() != null)
					sMassege.append( logicalFieldXpath.getFieldLogicalId()).append(",");
				else
					logger.error("getFieldLogicalId() is null");
				
				if (logicalFieldXpath.getFieldPath() != null)
					sMassege.append(logicalFieldXpath.getFieldPath()).append("/");
				else
					logger.error("getFieldPath() is null");
				
				if (logicalFieldXpath.getTagName() != null)
					sMassege.append(logicalFieldXpath.getTagName());
				else
					logger.error("getTagName() is null");
			}

			if (logicalFieldsXPathChild != null) {
				sMassege.append(" and child = ").append(sLogicalFieldChildId).append(",")
					.append(logicalFieldsXPathChild.getFieldPath()).append("/").append(logicalFieldsXPathChild.getTagName());
			}// ifthe child path was present

			logger.error(sMassege.toString());
			ExceptionController.getInstance().handleException(e, this);
			throw new PDOException(String.format("Parse failure for MID %s with message %s", pdo.getMID(), sMassege));
		} finally {
			rootDocumentXmlcur.dispose();
			xmlcur.dispose();
		}// EO catch block
			// System.out.println("XML Mapping Time --> " + ((float)(System.nanoTime()-lBefore)/GlobalConstants.NANOS_TO_MS_DIVIDER));

	}// EOM

	/**
	 * Does not support the following features currently: 1. Multi occurrences, 2. removal groups 3. move to 4. member handling 5. merge of two
	 * different payment types
	 * 
	 * Feb 24, 2010 Guys
	 * 
	 * @param groupXbean
	 * @param xmlcur
	 * @param enumTargetPaymentType
	 * @param mapPaymentFields
	 * @param pdo
	 */
	private final void handleSelfExtractingGroup(final XmlCursor xmlcur, final PaymentType enumTargetPaymentType,
			final Map<Object, PaymentFieldInterface> mapPaymentData, final PDO pdo, final boolean bDeriveOrigFields, final boolean bConjoinedMode) {

		// determine whether the group is a user defined container. if so, extract the code and use as the object id part of the key to the cache
		boolean bUserDefinedContext = false;
		String sUDFObjectID = null;
		final boolean bIsNewPdo = pdo.isNew();
		final XmlObject groupXbean = xmlcur.getObject();

		if (bUserDefinedContext = UDFContainerType.type.isAssignableFrom(groupXbean.schemaType())) {
			sUDFObjectID = ((UDFContainerType) groupXbean).getCode();
			if (GlobalUtils.isNullOrEmpty(sUDFObjectID)) {
				logger.error(
						"User Defined Fields Container '{}' did not define a code attribute. there is no way to derive field id, aborting parse",
						groupXbean.getDomNode().getLocalName());
				return;
			}// EO the Object id was not defined for the given container
		}// EO if user defined context

		// iterate over the group's children and for each:
		// extract the node name and use as the field logical id
		// retrieve the logical field metadata from either the logical fields id region or the userdefined fields id region
		// depending on the context.
		// retrieve the payment type's logical fields xpath (for normal context) or create a new logical field xpath entry if not yet cached
		// create a new payment field
		// store in the pdo data map.
		xmlcur.toFirstChild();
		String sChildFID = null, sNodeName = null;
		XmlObjectBase itemChild = null;
		LogicalFields childLogicalField = null;
		LogicalFieldsXpath childXmlmlMetadata = null;
		Map<String, LogicalFieldsXpath> mapPaymentTypeLogicalFieldsXpath = null;
		PaymentFieldInterface paymentField = null;
		Object oNodeValue = null;
		FieldType enumFieldType = null;
		boolean bMergeContext = false;

		do {
			itemChild = (XmlObjectBase) xmlcur.getObject();
			sNodeName = sChildFID = itemChild.getDomNode().getLocalName();

			oNodeValue = itemChild.getStringValue();

			childLogicalField = (bUserDefinedContext ? CacheKeys.UserDefinedFieldsIdKey.getSingle(sUDFObjectID, sChildFID)
					: CacheKeys.LogicalFieldsIdKey.getSingle(sChildFID));

			// this is a user defined fields context, append the object id to the field id
			if (bUserDefinedContext)
				sChildFID = sUDFObjectID + '^' + sChildFID;

			// determine whether the field was already present in the data mpa (merge), and is not a place holder
			paymentField = mapPaymentData.get(sChildFID);
			bMergeContext = (paymentField != null && paymentField != PaymentField.PLACE_HOLDER);

			// if the field metadata is null, create a derived field and continue
			if (childLogicalField == null) {
				logger.error(
						"Could not locate any LogicalFields/UserDefinedField definition for field {} in message type '{}', Using a derived field instead.",
						sChildFID, enumTargetPaymentType);

				// create a bogus logical fields based on the field's data type
				childLogicalField = LogicalFields.newLF(sChildFID, FieldType.DERIVED, oNodeValue);

			}// EO if the logical fields metadata was null

			enumFieldType = childLogicalField.getFieldType();
			oNodeValue = childLogicalField.getDataType().convert(oNodeValue);

			if (!FieldType.isXmlType(enumFieldType)) {

				if (!bMergeContext)
					paymentField = enumFieldType.newPaymentField(sChildFID, childLogicalField, oNodeValue, pdo, true/*bSetValue*/);
				else
					pdo.set(sChildFID, oNodeValue);

			} else {

				if (mapPaymentTypeLogicalFieldsXpath == null)
					mapPaymentTypeLogicalFieldsXpath = CacheKeys.LogicalFieldsXPathKey.getSingle(enumTargetPaymentType);

				// rerteive the logical fields xpath. if not defiend and user defined context create a
				// new one and cache. else create a derived field instead
				childXmlmlMetadata = mapPaymentTypeLogicalFieldsXpath.get(sChildFID);
				if (childXmlmlMetadata == null) {

					if (bUserDefinedContext) {
						childXmlmlMetadata = new LogicalFieldsXpath(sChildFID, sNodeName/* field id is the tagname */, '/' + sNodeName/* field path */,
								enumFieldType, childLogicalField.getFieldXmlType(), childLogicalField.getPathParentId(),
								childLogicalField.getLocation());
						mapPaymentTypeLogicalFieldsXpath.put(sChildFID, childXmlmlMetadata);
					} else {
						logger.error("Could not locate any xpath definitions for field {} in message type '{}', creating a derived field instead.",
								sChildFID, enumTargetPaymentType);
						paymentField = FieldType.DERIVED.newPaymentField(sChildFID, childLogicalField, oNodeValue, pdo, true/*bSetValue*/);
					}// EO else if not user defined context

				}// EO if no logical fields xpath was found for the given payment type

				if (!bMergeContext) {
					paymentField = enumFieldType.newPaymentField(sChildFID, childLogicalField,pdo);
					((XmlPaymentField) paymentField).setFromXml(xmlcur, childXmlmlMetadata, enumTargetPaymentType, !bIsNewPdo/* bupdateOrigVal */);
					paymentField.extraInit(pdo);
				} else
					((XmlPaymentField) paymentField)
							.setFromXml(null /* new node */, xmlcur, childXmlmlMetadata, enumTargetPaymentType, false/* bUpdateOrigval */);

			}// EO if xml field

			// if there is a copy to field associated with this field, create it (if not already created and assign the value to it as well
			// note as the copy to field can be associated to more than one logical fields, the value would be overriden such that the
			// last assignment shall define the value
			this.handleCopyToField(paymentField, mapPaymentData, pdo);

			// handle orig field derivation and linkage which are currently supported only in joint xmls scneario in initial create mode (user create)
			this.handleOrigPaymentField(pdo, (Map) null /* xpath metadta map */, itemChild, paymentField, childLogicalField, enumTargetPaymentType,
					bDeriveOrigFields, bConjoinedMode, !bIsNewPdo/* bupdateOrigVal */);

			// store the payment field in the map (even if the map already contains it (mege)
			mapPaymentData.put(sChildFID, paymentField);

		} while (xmlcur.toNextSibling());

	}// EOM

	/**
	 * The xmlcursor's selection buffer should contain the result of the selectPath of the '//<member Handles MEMEBR type fields.
	 */
	private final void handleMEMBERTypeField(final String sLocation, final FieldType childFieldType, XmlCursor xmlcur, final PDO pdo,
			final boolean bAboutToBeRemoved) throws Exception {

		final int iNoOfRecords = xmlcur.getSelectionCount();

		if (iNoOfRecords == 0)
			return;

		// STEP 1 -
		// Inserts all the children for this MEMBER field type into
		// a list.
		// The field path for MEMEBR type fields includes '//' in it,
		// in order to get all the children from the same type, (e.g.
		// lines of forward contract).

		// the occurrences immediate parent should have been configured to be the cursor's location. attempt to use its local name to rertieve the
		// population resources from the pdoListTypeResources cache.
		// if the resources are not yet initialized,
		// create and store

		final QName listTypeQname = xmlcur.getObject().schemaType().getName();
		PDOListMemberResources memberTypeResources = m_mapPDOListMemberResources.get(listTypeQname.getLocalPart());

		if (memberTypeResources == null) {
			// Constructs the name of the related PDO class memebr.
			// The location stands for a part of the PDO class member name, where
			// the convention is as follows:
			// If LOGICAL_FIELDS_XPATH.FIELD_XML_TYPE for the dealt field is 'MULTI'
			// then we'll add a 'm_list' to the location and this is the PDO class member name;
			// otherwise we'll add a 'm_o' to the location and this is the PDO class member name.
			String sClassMemebrName = childFieldType == FieldType.XML_MULTI ? PDO_MEMBER_LIST_PREFIX + sLocation : PDO_MEMBER_SINGLE_OBJECT_PREFIX
					+ sLocation;

			final Field pdoListMemberField = PDO.class.getDeclaredField(sClassMemebrName);
			// extract the Marshalling info annotation and from it, the merge mode and uid element name
			final UnMarshallingInfo anMarshallingInfo = pdoListMemberField.getAnnotation(UnMarshallingInfo.class);

			memberTypeResources = new PDOListMemberResources(anMarshallingInfo, pdoListMemberField, listTypeQname.getNamespaceURI());

			m_mapPDOListMemberResources.put(listTypeQname.getLocalPart(), memberTypeResources);
		}// EO if the resources where not yet initialized

		// retrieve the list from the pdo
		final Field listTypeField = memberTypeResources.pdoListField;

		listTypeField.setAccessible(true);
		List listChildren = (List) listTypeField.get(pdo);

		// if the list is null, create a new one and set it in the pdo
		if (listChildren == null) {
			listChildren = new ArrayList();

			listTypeField.set(pdo, listChildren);

			// cache the XmlElement type annotation value defining the list items type
			memberTypeResources.clsListMemberInstance = listTypeField.getAnnotation(XmlElement.class).type();
			// if the class is enclosed by another and that other is an instance of xmlObject then the list items are xml beans
			// else the instance is a custom one (JPA)
			memberTypeResources.eunmListMemberType = PdoListMemberType.unmarshallingRevrseVauleOf(memberTypeResources.clsListMemberInstance);
		}// EO if the list member was not yet initialized
		listTypeField.setAccessible(false);

		final UnMarshallingInfo.MergeModeType enumMergeModeType = memberTypeResources.anMarshallingInfo.mergeMode();
		// if the merge type is replace, and the list is empty clear the list and add the current selection values to the list
		// TODO: deal with non-xmlbean list members conversions
		final int iNoOfExistingRecords = listChildren.size();
		if (iNoOfExistingRecords > 0 && enumMergeModeType == UnMarshallingInfo.MergeModeType.REPLACE_ALL)
			listChildren.clear();

		List<Object> listExistingItemsPks = null, listRemovalItems = null;

		XmlObject recordXBean = null;
		XmlObject[] arrPkXBean = null;
		;
		Object listInstance = null, oPkValue = null, oExistingRecordPkValue = null;
		int indexOfMatchingRecord = -1;

		for (int i = 0; i < iNoOfRecords; i++) {
			xmlcur.toSelection(i);
			recordXBean = xmlcur.getObject();

			// invoke the ensureListItemState so as to copy to xml object if the pdo member list type is xbean and the xmlparent
			// is about to be removed from the xml which would render them disconnected
			recordXBean = memberTypeResources.eunmListMemberType.ensureListItemState(recordXBean, bAboutToBeRemoved);

			// if the iMergeType is FULL_MERGE, search through the list members first to verify whether there
			// is a duplicate if so, remove it
			// Note: currently a single pk column value is supported
			if (enumMergeModeType == UnMarshallingInfo.MergeModeType.FULL_MERGE) {

				// retrieve the pk element value
				arrPkXBean = recordXBean.selectChildren(memberTypeResources.pkQname);
				if (arrPkXBean != null && arrPkXBean.length == 1) {

					// extract the current record's pk value
					oPkValue = ((XmlObjectBase) arrPkXBean[0]).getStringValue();

					// if the cached pk values for the existing records was not already constrsucted, do so now.
					// if the cached structure was already created, use it to dertermine whether the current element
					// is an update. if the element is an update, remove the current element from the list
					// else if the cache was not aready prepared iterate over the existing records 0-iNoOfExistingRecords
					// and for each invoke the eunmListMemberType get value passing the list member
					// cast the value to string and store it in a list in accordance with a actual list index
					if (listExistingItemsPks == null) {
						listExistingItemsPks = new ArrayList<Object>();
						listRemovalItems = new ArrayList<Object>();

						for (int j = 0; j < iNoOfExistingRecords; j++) {

							oExistingRecordPkValue = memberTypeResources.eunmListMemberType.getListItemFieldValue(listChildren.get(j),
									memberTypeResources.pkQname.getLocalPart(), sLocation, memberTypeResources.clsListMemberInstance);

							// note new records might have null as their pk values which might only be populated
							// prior to persistence
							listExistingItemsPks.add(oExistingRecordPkValue);
						}// EO while there are more existing records
					}// EO if the listExistingItemsPks was not already initialized

					// if the current record's pk value was matched against a given existing item. store the item
					// so that at the end of the loop the remove indices could be removed
					// Note: cannot remove the element here as the index location is crucial
					// and would be rendered invalid due to the remove
					if ((indexOfMatchingRecord = listExistingItemsPks.indexOf(oPkValue)) != -1)
						listRemovalItems.add(listExistingItemsPks.get(indexOfMatchingRecord));

				}// EO if the pk element was provided
			}// EO if the merge type was full merge

			// configure the element prior to the addition to the list
			listInstance = memberTypeResources.eunmListMemberType.unmarshall((XmlObjectBase) recordXBean, sLocation, memberTypeResources);

			// add the new instance to the pdo
			listChildren.add(listInstance);

		}// EO while there are more list member records

		// if the listRemovalItems is not null iterate over it and remove the elements from the list
		if (listRemovalItems != null) {
			for (Object oRemovalItem : listRemovalItems) {
				listChildren.remove(oRemovalItem);
			}// EO while there are more item to remove
		}// EO if the listRemovalItems

		// return the cursor to the parent node
		xmlcur.toParent();

	}// EOM

	@Override
	public final List getPDOListMember(final String sMemberID, final PDO pdo) {
		return (List) this.processPDOMember(sMemberID, true/* bMulti */, pdo, false /* bMarshall */, null/* member xbean parent */,
				null /* memberXmlMetadata */, null/* paymentType */, null /* custmizedValueExtractor */);
	}// EOM

	@Override
	public final void marshallListMember(final String sMemberFieldLogicalID, final PDO pdo, final XmlObjectBase memberParentXbean,
			final PaymentType enumTargetPaymentType, final PDOListMemberHandlerInterface custmizedValueExtractor) {

		final LogicalFields logicalFields = CacheKeys.LogicalFieldsIdKey.getSingle(sMemberFieldLogicalID);
		final Map<String, LogicalFieldsXpath> mapPaymentTypeLogicalFieldsXpath = CacheKeys.LogicalFieldsXPathKey.getSingle(enumTargetPaymentType);
		final LogicalFieldsXpath memberXmlMetadata = mapPaymentTypeLogicalFieldsXpath.get(sMemberFieldLogicalID);

		this.processPDOMember(logicalFields.getLocation(), true/* bIsMulti */, pdo, true/* bMarshall */, memberParentXbean, memberXmlMetadata,
				enumTargetPaymentType, custmizedValueExtractor);
	}// EOM

	public final Object processPDOMember(final String sObjectRefID, final boolean bIsMulti, final PDO pdo, final boolean bMarshall,
			final XmlObjectBase memberParentXbean, final LogicalFieldsXpath memberXmlMetadata, final PaymentType enumTargetPaymentType,
			final PDOListMemberHandlerInterface custmizedValueExtractor) {

		final String GET_METHOD_PREFIX = "get";
		final String GET_LIST_METHOD_PREFIX = "getNSetList";

		final String MESSAGERATES_OBJ_REF = "MESSAGERATES";
		final String MESSAGERATES_CR_SUFFIX = "_CR";
		final String MESSAGERATES_DR_SUFFIX = "_DR";

		//

		Object oValue = null;

		try {

			// if a custmoized list member hanlder was provided, it is other wise use this default implementation
			if (custmizedValueExtractor != null)
				oValue = custmizedValueExtractor.getListMember(pdo, sObjectRefID);
			else {

				final String sBasicGetMethodName = (bIsMulti ? GET_LIST_METHOD_PREFIX + sObjectRefID : GET_METHOD_PREFIX + sObjectRefID);

				Method getMethod = null;

				// MESSAGERATES case.
				if (MESSAGERATES_OBJ_REF.equals(sObjectRefID)) {

					final List<ForwardContractLineType> listMESSAGERATES = new ArrayList<ForwardContractLineType>();

					// Tries getting CREDIT records.
					String sFinalGetMethodName = sBasicGetMethodName + MESSAGERATES_CR_SUFFIX;
					getMethod = PDO.class.getMethod(sFinalGetMethodName);
					oValue = getMethod.invoke(pdo);

					if (oValue != null) {
						listMESSAGERATES.addAll((List<ForwardContractLineType>) oValue);
					}

					// Tries getting DEBIT records.
					sFinalGetMethodName = sBasicGetMethodName + MESSAGERATES_DR_SUFFIX;
					getMethod = PDO.class.getMethod(sFinalGetMethodName);
					oValue = getMethod.invoke(pdo);

					if (oValue != null) {
						listMESSAGERATES.addAll((List<ForwardContractLineType>) oValue);
					}

					if (!listMESSAGERATES.isEmpty()) {
						oValue = listMESSAGERATES;
					} else if (pdo.getListMESSAGERATES() != null) {
						oValue = pdo.getListMESSAGERATES();
					}
				}// EO if the object ref id was MESSAGERATES_OBJ_REF
				else {

					getMethod = PDO.class.getMethod(sBasicGetMethodName);

					oValue = getMethod.invoke(pdo);

				}// EO else if not hardcoded message rates

				if (bMarshall && oValue != null) {
					// attempt to retrieve the XmlElement annotation from the getMethod, use the annotation (or lack thereof), to derive
					// the PDOListMemberType enum and delegate the output marshalling to it
					final XmlElement anMarshallingMetadata = getMethod.getAnnotation(XmlElement.class);

					final PdoListMemberType enumPdoListMemberType = PdoListMemberType.marshallingReverseValueOf(anMarshallingMetadata);

					enumPdoListMemberType.marshall(sObjectRefID, memberParentXbean, enumTargetPaymentType, oValue, memberXmlMetadata,
							anMarshallingMetadata, this);
				}// EO if should marshall
			}// EO else if there was no customized list member handler

		} catch (Exception e) {
			ExceptionController.getInstance().handleException(e, this);
		}// EO catch block

		//

		return oValue;
	}// EOM

	@Override
	public final List<MessageExternalInteraction> performLoadFromMessageExternalInteraction(String mid, String interfaceName, String interfaceType,
			String interfaceSubType, String requestResponseInd) {
		final String STATEMENT = "SELECT * FROM MESSAGE_EXTERNAL_INTERACTION WHERE (? IS NULL OR MID = ?) AND INTERFACE_NAME = ? "
				+ "AND INTERFACE_TYPE = ? AND (INTERFACE_SUB_TYPE = ? OR INTERFACE_SUB_TYPE IS NULL)  AND RESPONSE_REQUEST_IND = ?";

		List<MessageExternalInteraction> resultList = new ArrayList<MessageExternalInteraction>();
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			con = m_dao.getConnection();

			ps = con.prepareStatement(STATEMENT);
			GlobalUtils.setObject(ps, 1, mid);
			GlobalUtils.setObject(ps, 2, mid);
			GlobalUtils.setObject(ps, 3, interfaceName);
			GlobalUtils.setObject(ps, 4, interfaceType);
			GlobalUtils.setObject(ps, 5, interfaceSubType);
			GlobalUtils.setObject(ps, 6, requestResponseInd);

			rs = ps.executeQuery();

			m_dao.populateJPAObjects(resultList, rs, MessageExternalInteraction.class);
		}

		catch (Exception e) {
			ExceptionController.getInstance().handleException(e, this);
		}

		finally {
			m_dao.releaseResources(con, ps, rs);
		}

		return resultList;
	}

	/**
     * 
     */
	@Override
	public final List<PDO> performLoadFromPersistence(final String sInternalFileID, final String sChunkID, final String sUniqueGroupingID,
			int isHistoryValue, final String sAdditionalCondition, final Connection connection) {
		final String SELECT_STATEMENT = "SELECT * FROM MINF WHERE P_IN_INTERNAL_FILEID = ? "
				+ "AND P_CHUNK_ID = ? AND (P_UNIQUE_GROUPING_ID = ? OR (P_UNIQUE_GROUPING_ID IS NULL AND ? IS NULL)) AND P_IS_HISTORY = ? ";
		final String AND = " AND ";

		List<PDO> listPDO = new ArrayList<PDO>();

		Connection internalConnection = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			internalConnection = (connection == null ? DAS.m_dao.getConnection() : connection);

			String sSelectStatement = new StringBuffer(SELECT_STATEMENT).append(
					isNullOrEmpty(sAdditionalCondition) ? ServerConstants.EMPTY_STRING : AND + sAdditionalCondition).toString();

			ps = internalConnection.prepareStatement(sSelectStatement);

			GlobalUtils.setObject(ps, 1, sInternalFileID);
			GlobalUtils.setObject(ps, 2, sChunkID);
			GlobalUtils.setObject(ps, 3, sUniqueGroupingID);
			GlobalUtils.setObject(ps, 4, sUniqueGroupingID);
			GlobalUtils.setObject(ps, 5, isHistoryValue);

			rs = ps.executeQuery();

			// Loops the ResultSet, gets from each row the MID value, and calls the 'performRelationalMapping'
			// for creating a PDO object that will be added to the returned list
			String sMID = null;
			Map mapPaymentData = null;
			PDO pdo = null;

			while (rs.next()) {

				mapPaymentData = new HashMap<Object, PaymentFieldInterface>();
				sMID = rs.getString(PDOConstantFieldsInterface.P_MID);

				pdo = new PDO(sMID, mapPaymentData, this, false);

				this.performRelationalMapping(rs, mapPaymentData, pdo);
				PaymentDataFactory.cachePDO(pdo);
				listPDO.add(pdo);
			}
		} catch (Exception e) {
			ExceptionController.getInstance().handleException(e, this);
		} finally {
			DAS.m_dao.releaseResources(rs, ps, (connection == null ? internalConnection : null));
		}

		return listPDO;
	}

	/**
	 * iPartitionID 0 - active 1 - history 2 - template
	 */
	private final boolean performLoadFromPersistence(final String sMID, final Connection connection, final Map mapMappedValues, final PDO pdo,
			final int iTablePartitionID) throws Exception {

		Connection internalConnection = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {

			internalConnection = (connection == null ? m_dao.getConnection() : connection);
			ps = internalConnection.prepareStatement("SELECT * FROM MINF WHERE P_MID = ? AND P_IS_HISTORY = ?");
			setObject(ps, 1, sMID);
			setObject(ps, 2, iTablePartitionID);

			rs = ps.executeQuery();

			// No record.
			if (!rs.next()) {
				/* if the payment was not found in the active partition: 
				 * 1. If the flow type = BP, search for the record in the relevant bulk partition.
				 * 2. Else, search for the record in the historical partition (this will only occur in matching request for charges, 
				 * sepa direct debit return and gui histoical payment load. these scenarios are sparse and therefore the overhead of 
				 * first checking the active and only then falling back to the historical is acceptable if however the payment was not 
				 * found in the historical parittion search in the template partition
				 * */
				if (iTablePartitionID == ACTIVE_MINF_PARTITION_ID) 
				{
					return this.performLoadFromPersistence(sMID, connection, mapMappedValues, pdo, TEMPLATE_MINF_PARTITION_ID);
				} 
				else if (iTablePartitionID == TEMPLATE_MINF_PARTITION_ID) 
				{
					return this.performLoadFromPersistence(sMID, connection, mapMappedValues, pdo, HISTORICAL_MINF_PARTITION_ID);
				}// EO if the record was not found in minf active partition and the historical flag was false
				else if (iTablePartitionID == HISTORICAL_MINF_PARTITION_ID) 
				{
					return this.performLoadFromPersistence(sMID, connection, mapMappedValues, pdo, GlobalUtils.getPartitionIDByMID(sMID));
				} 
				else 
				{
					logger.error("No MINF record was found for MID: " + pdo.getMID());
					return false;
				}// EO if the record was not found in the active parittion and the historical flag was true
			}// EO if the records for the MID was not found
				// else
			logger.info("Minf record found for MID {} with P_IS_HISTORY = {}",sMID,iTablePartitionID);
			this.performRelationalMapping(rs, mapMappedValues, pdo);

		} finally {
			this.m_dao.releaseResources(rs, ps, (connection == null ? internalConnection : null));
		}// EO catch block

		return true;
	}// EOM

	/**
	 * 
	 * Jul 9, 2009 Guys
	 * 
	 * @param rs
	 *            Assumed to already be positioned on the record to load
	 * @param mapMappedValues
	 * @param pdo
	 * @param listMappableXmlColumns
	 *            list of parsable XML columns, all others are ignored
	 * @throws Exception
	 */
	private final void performRelationalMapping(ResultSet rs, final Map mapMappedValues, final PDO pdo) throws Exception {

		final ResultSetMetaData metadata = rs.getMetaData();

		final Set<XmlLocationType> setXmlColumnNames = EnumSet.noneOf(XmlLocationType.class);

		final int iLength = metadata.getColumnCount();
		String sColumnName = null;
		XmlLocationType enumXmlLocationType = null;
		LogicalFields fieldMetadata = null;

		PaymentFieldInterface mapEntryWrapper = null;
		try {
			// iterate over the minf record and parse its content.
			// postpone the xml columns parsing until all relational columns have been parsed
			// so that the service_state_monitor field would already exist in the pdo.
			// the latter is required so as to indicate whether the payment is in its initial creation
			// state whereby there should be a single xml document instance shared between the orignal and the current xml
			// documents
			for (int i = 1; i <= iLength; i++) {

				sColumnName = metadata.getColumnName(i);

				// if the column name exists in the mapMappableXmlColumns then this is a special
				// xml column mapping. Store it in a buffer to be parse at the end
				if ((enumXmlLocationType = XmlLocationType.reverseMapping(sColumnName)) != null) {
					setXmlColumnNames.add(enumXmlLocationType);
					continue;
				}// EO if the column was xml column
					// else if the column type is xml (type is db dependent) and is not present
					// in the listMappableXmlColumns continue ;
				else if (DAOBasic.ms_DBType.getXmlDao().isXmlType(metadata.getColumnType(i)))
					continue;

				// else if the column type is not xml

				fieldMetadata = LogicalFieldsIdKey.getSingle(sColumnName);

				// if the column name cannot be mapped into a logical field, trace but
				// do not fail
				if (fieldMetadata == null) {
					logger.debug("Column [{}]] in table MINF does not have a fields definition entry", sColumnName);
					continue;
				}// EO if the field was not defined in logical fields

				// create a new relational field wrapper and set the value in it
				mapEntryWrapper = fieldMetadata.getFieldType().newPaymentField(fieldMetadata.getFieldLogicalId(), fieldMetadata,pdo);

				mapEntryWrapper.set(fieldMetadata.getDataType().getValue(rs, i), true);

				// if there is a copy to field associated with this field, create it (if not already created and assign the value to it as well
				// note as the copy to field can be associated to more than one logical fields, the value would be overriden such that the
				// last assignment shall define the value
				this.handleCopyToField(mapEntryWrapper, mapMappedValues, pdo);

				logger.debug("Just created a relational payment field: {}", mapEntryWrapper.toString());
				// store the wrapper in the map against the logical field id
				mapMappedValues.put(fieldMetadata.getFieldLogicalId(), mapEntryWrapper);

			}// EO while there are more columns
						
			logger.debug("All relational (p-fields) columns where populated successfully");

			// [0] - should derive orig fields from given xml
			// [1] - should perform xml mapping
			boolean[] arrShouldParseAndDeriveOrigFields = null;
			final boolean bConjoinedMode = pdo.isConjoined();

			// iterate over the xml columns and parse each
			for (XmlLocationType enumAnXmlLocationType : setXmlColumnNames) {
				enumXmlLocationType = enumAnXmlLocationType; // for exception handling

				arrShouldParseAndDeriveOrigFields = enumAnXmlLocationType.shouldPerformXmlMapping(pdo, bConjoinedMode);
				if (!arrShouldParseAndDeriveOrigFields[1])
					continue;

				// determine whether the xml mapping should be performed for the given xml coulnm
				this.performXmlMapping(enumXmlLocationType, mapMappedValues, pdo, arrShouldParseAndDeriveOrigFields[0], bConjoinedMode, false/*
																																			 * merge
																																			 * context
																																			 */, rs,
						null/* xml orig copy */);

			}// EO while there are more xml columns

		}// try
		catch (Exception e) {
			logger.error("************ DAS - performRelationalMapping: load pdo " + pdo.getMID() + " failed. Stack trace:\n " + e.getStackTrace());
			throw e;
		}// EO catch block

	}// EOM

	@Override
	public void performReferenceMapping(final String sObjRefId, final Object instance, final PDO pdo) {

		try {
			// retrieve all logical fields cached against the sRefId
			// iterate over them, retrieve the location from each logical field
			// instance, extract from the object instance and store in the mappedValues
			// against the logical field id
			final List<LogicalFields> listReferenceMappings = new ArrayList<LogicalFields>();

			CacheKeys.LogicalFieldsObjRefKey.get(listReferenceMappings, sObjRefId);

			PaymentFieldInterface mapEntryWrapper = null;
			String sMemberName, sLogicalFieldId = null;
			final boolean bShouldResetReferencedField = (instance == null);
			Object oFieldValue = null;
			String[] arrMemberObjGraph = null;

			// derive the pdo list type using the instance class type
			final Class<?> clsListMemberType = (bShouldResetReferencedField ? null : instance.getClass());
			final PdoListMemberType enumPdoListMemberType = PdoListMemberType.unmarshallingRevrseVauleOf(clsListMemberType);

			synchronized (lock) {

				for (LogicalFields logicalFieldMetadata : listReferenceMappings) {
					sMemberName = logicalFieldMetadata.getLocation();
					sLogicalFieldId = logicalFieldMetadata.getFieldLogicalId();
					// if the bShouldResetReferencedField is true, then remove the fields from the map
					if (bShouldResetReferencedField) {
						pdo.removePaymentField(sLogicalFieldId);
					} else {
						/*
						 * //split the member name on '.' so as to create the drill down object graph //for instance: 'member1.inner1.inner_inner2'
						 * stands for: //1. retrieve member1 //2. retrieve inner1 from member1 //3. retrive inner_inner2 from member1
						 * arrMemberObjGraph = sMemberName.split("\\.") ;
						 * 
						 * //asssign the root values as the initial ones currInstance = instance ; currInstanceClass = instanceClass ;
						 * 
						 * for(String sNextMemberName : arrMemberObjGraph) {
						 * 
						 * //first attempt to locate the Reflection Field instance associated with the //object instance in the
						 * mapReferenceReflectionFieldsCache //(should be stored against the refId + logicalFieldMetadata.getLocation() member =
						 * m_mapReferenceReflectionFieldsCache.get(sRefId + sNextMemberName) ; //if the member was not cached ,cache it now if(member
						 * == null) { member = currInstanceClass.getDeclaredField(sNextMemberName) ;
						 * 
						 * m_mapReferenceReflectionFieldsCache.put(sRefId + sNextMemberName, member) ; }//EO if this is it the first access to the
						 * field
						 * 
						 * //get the member's instance and class member.setAccessible(true) ; currInstance = member.get(currInstance) ;
						 * member.setAccessible(false) ;
						 * 
						 * //value can be null if (currInstance != null) currInstanceClass = currInstance.getClass() ;
						 * 
						 * }//EO while there are more objects to drill down into
						 */

						// extract the value for the child reference field
						oFieldValue = enumPdoListMemberType.getListItemFieldValue(instance, logicalFieldMetadata, sObjRefId, clsListMemberType);

						// create a new Reference field type wrapper and set the value in it
						mapEntryWrapper = FieldType.REFERENCE.newPaymentField(sLogicalFieldId, logicalFieldMetadata,pdo);
						mapEntryWrapper.set(oFieldValue, pdo.isNew());
						// finally set the value in the results map against the logical fields id
						// it is a conscious decision not to reuse the pdo.set() + recursion but to
						// directly add the field (overriding existing one)
						pdo.setPaymentField(mapEntryWrapper);
					}// EO if the context is not a reset
				}// EO while there are more reference fields mappping for this object
			}// EO synchronized block
		} catch (Exception e) {
			logger.error(e.getMessage());
		}// EO catch block

	}// EOM

	/**
	 * Note: need to accommodate sccenarios whereby the given pdo's list is not completly replaced but merged (e.g. list filters)
	 */
	@Override
	public final <T> void mergeMsgTables(final XmlObject messageTablesRoot, final PDO pdo) {
		if (messageTablesRoot == null)
			return;

		final String MSG_TABLES_NS = "http://fundtech.com/SCL/CommonTypes";

		final QName ID_ATTR_QNAME = new QName("", "id");
		final QName IS_NEW_ATTR_QNAME = new QName("", "isNew");
		final QName MSG_TABLE_ENTRY_VALUE_ATTR_QNAME = new QName("", "value");

		final QName MSG_TABLE_RECORD_QNAME = new QName(MSG_TABLES_NS, "record");

		final QNameSet ARR_COLUMNS_NAMESET = QNameSet.forArray(new QName[] { new QName(MSG_TABLES_NS, "FLOAT"), new QName(MSG_TABLES_NS, "DOUBLE"),
				new QName(MSG_TABLES_NS, "STRING"), new QName(MSG_TABLES_NS, "INTEGER"), new QName(MSG_TABLES_NS, "DECIMAL"),
				new QName(MSG_TABLES_NS, "LONG"), new QName(MSG_TABLES_NS, "NUMBER"), new QName(MSG_TABLES_NS, "BOOL"), });

		final String MSG_TABLE_ENTRIES_PATH = "declare default element namespace '%s'; $this/mtables//mtable";

		try {
			// retreive all mtable nodes
			final XmlObject[] arrMTables = messageTablesRoot.selectPath(String.format(MSG_TABLE_ENTRIES_PATH, MSG_TABLES_NS));

			// if there are no tables, abort
			if (arrMTables.length == 0)
				return;

			XmlObject[] arrTableFields = null, arrTableRecords = null;
			XmlObjectBase valueBean = null;
			LogicalFields msgTableMetadata = null, msgTableFieldMetadata = null;
			String sMTableId = null, sFieldId = null, sFieldLocation = null;
			DataType enumDataType = null;

			Class<T> listInstanceClass = null;
			Object listInstance = null;
			Field instanceField = null, listField = null;
			;
			boolean bAccessible = false;
			List listMTableInstances = new ArrayList<T>();
			Object oFieldValue = null;

			final String IS_NEW_FIELD_NAME = "isNew";

			// Gets the NEWJOURNAL JPA that is dedicated to user modified fields.
			final Newjournal newjournalUserModifiedFields = pdo.getUserModifiedFieldsNEWJOURNALEntry(true /* create if not yet instantiated */);
			Map<String, SnapShotHolder> mapStateSnapshots = newjournalUserModifiedFields.getStateSnapshotsHM();
			Method newInstanceMethod = null;

			Field isNewFlagField = null;
			boolean bAlreadyAttemptedToLookupIsNewFlag = false;

			for (XmlObject mTableBean : arrMTables) {

				sMTableId = ((XmlObjectBase) mTableBean.selectAttribute(ID_ATTR_QNAME)).getStringValue();

				// Updates the PDO's state snapshots map.
				// This String[] can't be null; if so, then this is a bug !!!
				String[] arrStateSnapshots = mapStateSnapshots.get(sMTableId).getValuesArr();
				//
				// Gets the XML for the new table data.
				String sTableNewValue = mTableBean.xmlText(new XmlOptions().setSavePrettyPrint());
				arrStateSnapshots[1] = sTableNewValue;

				// retieve the logical fields entry associated with the given
				// msg table id
				msgTableMetadata = CacheKeys.LogicalFieldsIdKey.getSingle(sMTableId);

				// rerteive the list member from the pdo
				listField = pdo.getClass().getDeclaredField(PDO_MEMBER_LIST_PREFIX + msgTableMetadata.getLocation());

				// extract the list's class type from the list's @XmlElement annotation residing within the marshalling info
				listInstanceClass = listField.getAnnotation(XmlElement.class).type();

				// derive the PdoListMemberType strategy
				final PdoListMemberType enumPdoListMemberType = PdoListMemberType.unmarshallingRevrseVauleOf(listInstanceClass);

				// if the newInstance method was not yer cached do so now
				if (newInstanceMethod == null)
					newInstanceMethod = listInstanceClass.getMethod(NEW_INSTANCE_METHOD_NAME);
				// if the isNewFlag member was not yet cached and the bAlreadyAttemptedToLookupIsNewFlag is false do so now

				if (!bAlreadyAttemptedToLookupIsNewFlag) {
					try {
						isNewFlagField = listInstanceClass.getDeclaredField(IS_NEW_FIELD_NAME);
						// set the field accessibility to true once for the duration of this method
						isNewFlagField.setAccessible(true);
					} catch (Exception e) {// Do nothing
					} finally {
						bAlreadyAttemptedToLookupIsNewFlag = true;
					}// EO catch block
				}// EO if the is new field was not already looked up

				// extract the table records from the xml and construct the JPA instance
				// for each
				arrTableRecords = mTableBean.selectChildren(MSG_TABLE_RECORD_QNAME);

				for (XmlObject recordBean : arrTableRecords) {

					listInstance = newInstanceMethod.invoke(null);

					// if the isNewFlagField was located (the field exists in the class), set it
					if (isNewFlagField != null) {
						isNewFlagField.set(listInstance, ((XmlObjectBase) recordBean.selectAttribute(IS_NEW_ATTR_QNAME)).getBooleanValue());
					}// EO if the isNewField was found in the instance class
						//
					// initialise the instance's fields by iterating over the mtable record node's
					// children, seleting the key & value from each,
					// retrieving the logical field's metadata associated with
					// each of the keys, then, extracting the field's location
					// and using it as the mapping to the member's class.
					// prior to setting the value, the metadata's datatype should
					// be used to retrieve the current value representation from the xmlbean value
					arrTableFields = recordBean.selectChildren(ARR_COLUMNS_NAMESET);

					for (XmlObject msgTableFieldBean : arrTableFields) {

						sFieldId = ((XmlObjectBase) msgTableFieldBean.selectAttribute(ID_ATTR_QNAME)).getStringValue();

						msgTableFieldMetadata = CacheKeys.LogicalFieldsIdKey.getSingle(sFieldId);

						// extract the location and the data type
						sFieldLocation = msgTableFieldMetadata.getLocation();

						valueBean = ((XmlObjectBase) msgTableFieldBean.selectAttribute(MSG_TABLE_ENTRY_VALUE_ATTR_QNAME));

						// if the value is null continue ;
						if (GlobalUtils.isNullOrEmpty(valueBean.getStringValue()))
							continue;
						// else

						oFieldValue = valueBean.getObjectValue();

						// if the location of msg table equals to object reference of field that should be saved
						// then insert the value in to the defined object
						if (msgTableMetadata.getLocation().equals(msgTableFieldMetadata.getObjRefDataId())) {

							enumPdoListMemberType.setListItemFieldValue(listInstance, msgTableFieldMetadata, oFieldValue, this);

							// else if the field is not from defined object, insert it to PDO
							// doesn't support the insertion to different object reference
						} else
							pdo.set(sFieldId, oFieldValue);

					}// EO while there are more table fields

					// and add the instance to the list
					listMTableInstances.add(listInstance);

				}// EO while there are more table records

				// if the isNewFlagField was located (the field exists in the class), restore the private visibility
				if (isNewFlagField != null)
					isNewFlagField.setAccessible(false);

				// retrieve the table's location (pdo member name)
				// map it to the pdo, list, and replace it with the new one
				// TODO: accommodate merge instead of replacement
				bAccessible = listField.isAccessible();
				listField.setAccessible(true);
				listField.set(pdo, listMTableInstances);
				listField.setAccessible(bAccessible);

				// reset the listMTableInstances, the isNewFlagField and the newinstance method
				isNewFlagField = null;
				newInstanceMethod = null;
				listMTableInstances = new ArrayList<T>();

			}// EO while there are more dirty message tables

		} catch (Exception e) {
			ExceptionController.getInstance().handleException(e, this);
		}// EO catch block

	}// EOM

	/**
	 * 
	 * May 19, 2008 guys
	 * 
	 * Loads and sets an object in the PDO the reference mapping would be perfomed as result of the member setting invocation
	 * 
	 * @param <T>
	 * @param pdo
	 * @param sObjectRefId
	 * @param returnClassType
	 * @param arrOptionalFormalArgs
	 * @return the loaded member instance
	 */
	@Override
	public final Object loadCachedMember(final PDO pdo, final String sObjectRefId, Object... arrOptionalFormalArgs) {
		//

		Object oCachedObject = null;

		final int iObjectRefIdHash = sObjectRefId.hashCode();

		try {
			switch (iObjectRefIdHash) {

			case PDOConstantFieldsInterface.BASE_RATE_USAGE_PDO_MEMBER_HASH_REF_ID: {
				final RateUsage baseRateUsage = CachedPDOMembersLoader.loadBaseRateUsage(pdo);
				if (baseRateUsage != null)
					pdo.setBaseRateUsage(baseRateUsage);
				oCachedObject = baseRateUsage;
			}
				break;

			case PDOConstantFieldsInterface.DEBIT_RATE_USAGE_PDO_MEMBER_HASH_REF_ID: {
				final RateUsage debitRateUsage = CachedPDOMembersLoader.loadDebitRateUsage(pdo);
				if (debitRateUsage != null)
					pdo.setDebitRateUsage(debitRateUsage);
				oCachedObject = debitRateUsage;
			}
				break;

			case PDOConstantFieldsInterface.CREDIT_RATE_USAGE_PDO_MEMBER_HASH_REF_ID: {
				final RateUsage creditRateUsage = CachedPDOMembersLoader.loadCreditRateUsage(pdo);
				if (creditRateUsage != null)
					pdo.setCreditRateUsage(creditRateUsage);
				oCachedObject = creditRateUsage;
			}
				break;

			case PDOConstantFieldsInterface.OFFICE_CUSTOMER_PDO_MEMBER_HASH_REF_ID: {
				final Customrs officeCustomer = CachedPDOMembersLoader.loadOfficeCustomer(pdo);
				if (officeCustomer != null)
					pdo.setOfficeCustomer(officeCustomer);
				oCachedObject = officeCustomer;
			}
				break;

			case PDOConstantFieldsInterface.MESSAGE_STP_RULES_PDO_MEMBER_HASH_REF_ID: {
				final MessageStpRules messageStpRules = CachedPDOMembersLoader.loadMessageStpRules(pdo);
				if (messageStpRules != null)
					pdo.setMessageStpRules(messageStpRules);
				oCachedObject = messageStpRules;
			}
				break;

			case PDOConstantFieldsInterface.OFFICE_GENERIC_SLA_PDO_MEMBER_HASH_REF_ID: {
				final SlaProfile slaProfile = CachedPDOMembersLoader.loadOfficeGenericSla(pdo);
				if (slaProfile != null)
					pdo.setOfficeGenericSla(slaProfile);
				oCachedObject = slaProfile;
			}
				break;

			case PDOConstantFieldsInterface.DEBIT_SLA_PDO_MEMBER_HASH_REF_ID: {
				final SlaProfile slaProfile = CachedPDOMembersLoader.loadDebitSla(pdo);
				if (slaProfile != null)
					pdo.setDebitSla(slaProfile);
				oCachedObject = slaProfile;
			}
				break;

			case PDOConstantFieldsInterface.CREDIT_SLA_PDO_MEMBER_HASH_REF_ID: {
				final SlaProfile slaProfile = CachedPDOMembersLoader.loadCreditSla(pdo);
				if (slaProfile != null)
					pdo.setCreditSla(slaProfile);
				oCachedObject = slaProfile;
			}
				break;

			case PDOConstantFieldsInterface.ORIG_MSG_TYPES_PDO_MEMBER_HASH_REF_ID: {
				final MsgTypes origMsgTypes = CachedPDOMembersLoader.loadOrigMsgType(pdo);
				if (origMsgTypes != null)
					pdo.setOrigMsgTypes(origMsgTypes);
				oCachedObject = origMsgTypes;
			}
				break;

			case PDOConstantFieldsInterface.MSG_TYPES_PDO_MEMBER_HASH_REF_ID: {
				final MsgTypes msgTypes = CachedPDOMembersLoader.loadMsgType(pdo);
				if (msgTypes != null)
					pdo.setMsgTypes(msgTypes);
				oCachedObject = msgTypes;
			}
				break;

			case PDOConstantFieldsInterface.MFAMILY_LIST_PDO_MEMBER_HASH_REF_ID: {
				oCachedObject = CachedPDOMembersLoader.loadMfamily(pdo);
			}
				break;

			case PDOConstantFieldsInterface.INCOMING_FILE_SUMMARY_PDO_MEMBER_HASH_REF_ID: {
				oCachedObject = CachedPDOMembersLoader.loadFileSummary(pdo, true);
				if (oCachedObject != null)
					pdo.setIncomingFileSummary((FileSummary) oCachedObject);
			}
				break;

			case PDOConstantFieldsInterface.OUTGOING_FILE_SUMMARY_PDO_MEMBER_HASH_REF_ID: {
				oCachedObject = CachedPDOMembersLoader.loadFileSummary(pdo, false);
				if (oCachedObject != null)
					pdo.setOutgoingFileSummary((FileSummary) oCachedObject);
			}
				break;

			case PDOConstantFieldsInterface.BATCH_SUBSET_PDO_MEMBER_HASH_REF_ID: {
				oCachedObject = CachedPDOMembersLoader.loadBatchSubset(pdo);
				if (oCachedObject != null)
					pdo.setBatchSubset((BatchSubset) oCachedObject);
			}
				break;

			case PDOConstantFieldsInterface.MSG_NEWJOURNAL_LIST_PDO_MEMBER_HASH_REF_ID: {
				oCachedObject = CachedPDOMembersLoader.loadMsgNewjournal(pdo);
			}
				break;

			case PDOConstantFieldsInterface.MSG_ERRORS_LIST_PDO_MEMBER_HASH_REF_ID: {
				oCachedObject = CachedPDOMembersLoader.loadMsgErrors(pdo);
			}
				break;
			
				
				
			case PDOConstantFieldsInterface.MSG_EXTERNALS_ERRORS_LIST_PDO_MEMBER_HASH_REF_ID: {
				oCachedObject = CachedPDOMembersLoader.loadExternalErrorMessages(pdo);
			}
				break;

			case PDOConstantFieldsInterface.MSG_STOP_FLAGS_LIST_PDO_MEMBER_HASH_REF_ID: {
				oCachedObject = CachedPDOMembersLoader.loadStopFlags(pdo);
			}
				break;

			case PDOConstantFieldsInterface.MESSAGERATES_LIST_PDO_MEMBER_HASH_REF_ID: {
				oCachedObject = CachedPDOMembersLoader.loadMessageRates((MessageRatesInputData) arrOptionalFormalArgs[0]);
			}
				break;
			case PDOConstantFieldsInterface.BULKING_PROFILE_PDO_MEMBER_HASH_REF_ID: {
				oCachedObject = CachedPDOMembersLoader.loadBulkingProfile(pdo);
				if (oCachedObject != null)
					pdo.setBulkingProfile((BulkingProfile) oCachedObject);
			}
				break;
			case PDOConstantFieldsInterface.MSG_NOTES_LIST_PDO_MEMBER_HASH_REF_ID: {
				oCachedObject = CachedPDOMembersLoader.loadListMsgNotes(pdo);
				if (oCachedObject != null)
					pdo.setListMSGNOTES((List<MsgNotesLineType>) oCachedObject);
				Boolean isExternalNote = isExternalNote(pdo);
				pdo.setTransient(PDOConstantFieldsInterface.D_EXTERNAL_NOTE, isExternalNote.toString().toUpperCase());
			}
				break;
			case PDOConstantFieldsInterface.OFFICE_PDO_MEMBER_HASH_REF_ID: {

				final Banks banks = CachedPDOMembersLoader.loadOffice(pdo);

				if (banks != null)
					pdo.setOffice(banks);

				oCachedObject = banks;
			}
				break;
			case PDOConstantFieldsInterface.CREDIT_CURRENCY_PDO_MEMBER_HASH_REF_ID: {

				final CurrencyBu currency = CachedPDOMembersLoader.loadCreditCurrency(pdo);

				if (currency != null)
					pdo.setCreditCurrency(currency);

				oCachedObject = currency;

			}
				break;
			case PDOConstantFieldsInterface.DEBIT_CURRENCY_PDO_MEMBER_HASH_REF_ID: {

				final CurrencyBu currency = CachedPDOMembersLoader.loadDebitCurrency(pdo);

				if (currency != null)
					pdo.setDebitCurrency(currency);

				oCachedObject = currency;

			}
				break;
			case PDOConstantFieldsInterface.INSTRUCTION_CURRENCY_PDO_MEMBER_HASH_REF_ID: {

				final CurrencyBu currency = CachedPDOMembersLoader.loadInstructionCurrency(pdo);

				if (currency != null)
					pdo.setINSTRUCTION_CURRENCY(currency);

				oCachedObject = currency;

			}
				break;

			case PDOConstantFieldsInterface.CREDIT_MOP_PDO_MEMBER_HASH_REF_ID: {

				final Mop mop = CachedPDOMembersLoader.loadCreditMop(pdo);

				if (mop != null)
					pdo.setCREDIT_MOP(mop);

				oCachedObject = mop;
			}
				break;

			case PDOConstantFieldsInterface.DEBIT_MOP_PDO_MEMBER_HASH_REF_ID: {

				final Mop mop = CachedPDOMembersLoader.loadDebitMop(pdo);

				if (mop != null)
					pdo.setDEBIT_MOP(mop);

				oCachedObject = mop;
			}
				break;

			case PDOConstantFieldsInterface.MATCHING_CHECK_PDO_MEMBER_HASH_REF_ID: {

				String sMatchingCheckSelectionRuleSubType = (String) arrOptionalFormalArgs[0];
				final MatchingCheck matchingCheck = CachedPDOMembersLoader.loadMatchingCheck(pdo, sMatchingCheckSelectionRuleSubType);

				if (matchingCheck != null)
					pdo.setMatchingCheck(sMatchingCheckSelectionRuleSubType, matchingCheck);

				oCachedObject = matchingCheck;
			}
				break;

			case PDOConstantFieldsInterface.CREDIT_CUSTOMER_PDO_MEMBER_HASH_REF_ID: {

				final Customrs customer = CachedPDOMembersLoader.loadCreditCustomer(pdo);

				if (customer != null)
					pdo.setCREDIT_CUSTOMER(customer);

				oCachedObject = customer;
			}
				break;
			case PDOConstantFieldsInterface.DEBIT_CUSTOMER_PDO_MEMBER_HASH_REF_ID: {

				final Customrs customer = CachedPDOMembersLoader.loadDebitCustomer(pdo);

				if (customer != null)
					pdo.setDEBIT_CUSTOMER(customer);

				oCachedObject = customer;
			}
				break;
			case PDOConstantFieldsInterface.CREDIT_ACCOUNT_PDO_MEMBER_HASH_REF_ID: {

				final Accounts account = CachedPDOMembersLoader.loadCreditAccount(pdo);

				if (account != null)
					pdo.setCREDIT_ACCOUNT(account);

				oCachedObject = account;
			}
				break;
			case PDOConstantFieldsInterface.DEBIT_ACCOUNT_PDO_MEMBER_HASH_REF_ID: {

				final Accounts account = CachedPDOMembersLoader.loadDebitAccount(pdo);

				if (account != null)
					pdo.setDEBIT_ACCOUNT(account);

				oCachedObject = account;
			}
				break;
			case PDOConstantFieldsInterface.DEBIT_ACCOUNT_ADD_OWNER_PDO_MEMBER_HASH_REF_ID: {

				final AccountAdditionalOwners accountAdditionalOwners = CachedPDOMembersLoader.loadDebitAccountAdditionalOwner(pdo);

				if (accountAdditionalOwners != null)
					pdo.setDEBIT_ACCOUNT_ADD_OWNER(accountAdditionalOwners);

				oCachedObject = accountAdditionalOwners;
			}
				break;
			case PDOConstantFieldsInterface.INSTRUCTING_AGENT_PDO_MEMBER_HASH_REF_ID: {

				final Customrs customer = CachedPDOMembersLoader.loadInstructionAgent(pdo);

				if (customer != null)
					pdo.setINSTRUCTING_AGENT(customer);

				oCachedObject = customer;
			}
				break;

			case PDOConstantFieldsInterface.ORIG_INITIATING_CUSTOMER_PDO_MEMBER_HASH_REF_ID: {

				final Customrs customer = CachedPDOMembersLoader.loadOrigInitiatingCustomer(pdo);

				if (customer != null)
					pdo.setORIG_INITIATING_CUSTOMER(customer);

				oCachedObject = customer;
			}
				break;

			case PDOMemberConstants.STATUS_CONTEXT_LIST_PDO_MEMBER_HASH_REF_ID: {

				final List<MsgSpecialInstructions> msgspecialinstruction = CachedPDOMembersLoader.loadMsgSpecialInstructionList(pdo);

				pdo.setMsgSpecialInstructionList(msgspecialinstruction);

				oCachedObject = msgspecialinstruction;
			}
				break;

			case PDOMemberConstants.MSG_PARTIES_PDO_MEMBER_HASH_REF_IF: {

				final List<MsgParties> msgParties = CachedPDOMembersLoader.loadMsgParties(pdo);

				pdo.setListMSG_PARTIES(msgParties);

				oCachedObject = msgParties;
			}
				break;
				
			case PDOMemberConstants.ACCT_DAILY_BAL_PDO_MEMBER_HASH_REF_ID: {
				Date valueDate = (Date)arrOptionalFormalArgs[0];
				String clearingCycle = (String)arrOptionalFormalArgs[1];
				final AccountDailyBalances acctDailyBalances = CachedPDOMembersLoader.loadAccountDailyBalances(pdo,valueDate,clearingCycle);
				if (acctDailyBalances != null)
					pdo.setACCT_DAILY_BAL(acctDailyBalances);

				oCachedObject = acctDailyBalances;
			}
				break;

			case PDOMemberConstants.MSG_FEES_LIST_PDO_MEMBER_HASH_REF_ID: {

				final List<MsgFees> msgfees = CachedPDOMembersLoader.loadMsgFeesList(pdo);

				pdo.setListMSG_FEES(msgfees);

				oCachedObject = msgfees;
			}
				break;
			case PDOMemberConstants.ORIGINAL_SENDER_PDO_MEMBER_HASH_REF_ID: {

				final Customrs customer = CachedPDOMembersLoader.loadOriginalSender(pdo);

				pdo.setOriginalSender(customer);

				oCachedObject = customer;
			}
				break;
			case PDOMemberConstants.LINKED_MSG_HASH_REF_ID: {
				oCachedObject = CachedPDOMembersLoader.loadLinkedMsg(pdo, (String) arrOptionalFormalArgs[0]);
			}
				break;
			case PDOMemberConstants.TEMPLATE_UNCHANGED_FIELDS_PDO_MEMBER_HASH_REF_ID: {
				oCachedObject = CachedPDOMembersLoader.loadTemplateUnchangedFields(pdo);
			}
				break;
			case PDOMemberConstants.EXCHRATE_RTR_PDO_MEMBER_HASH_REF_ID: {
				oCachedObject = CachedPDOMembersLoader.loadExchrateRTR(pdo);
				pdo.setEXCHRATE_RTR((ExchrateRtrLineType) oCachedObject);
			}
				break;
			case PDOMemberConstants.CYCLE_SETTLEMENT_PDO_MEMBER_HASH_REF_ID: {
				List<CycleSttlmLineType> cycleList = CachedPDOMembersLoader.loadCycleSttlm(pdo);
				if (cycleList != null && cycleList.size() > 0)
					pdo.setCycleSettlement(cycleList.get(0));
			}
				break;
				
			case PDOMemberConstants.MANDATE_PDO_MEMBER_HASH_REF_ID: {
				final Mandate mandate = CachedPDOMembersLoader.loadMandate(pdo);

				if (mandate != null)
					pdo.setMANDATE(mandate);

				oCachedObject = mandate;
			}
				break;

			default: // do some error handling
			}// EO switch block

		} catch (Exception e) {
			if (e instanceof RuntimeException)
				throw (RuntimeException) e;
			else
				throw new RuntimeException(e);
		}// EO catch block

		//

		return oCachedObject;
	}// EOM

	private void pruneXml(final XmlTokenSource nodeToRemove, final XmlCursor xmlRootCursor, final boolean bRemoveFromXml, final boolean bForceRemove) {

		if (!bRemoveFromXml)
			return;

		//

		final XmlCursor tidyingCursor = nodeToRemove.newCursor();

		if (bForceRemove || !tidyingCursor.toFirstChild()) {

			tidyingCursor.removeXml();
			tidyingCursor.toParent();

			// remove all empty parents
			while (!tidyingCursor.toFirstChild() && !tidyingCursor.isAtSamePositionAs(xmlRootCursor)) {// &&
																										// tidyingCursor.getObject().schemaType().getContentModel().getMinOccurs().intValue()
																										// == 0) {
				tidyingCursor.removeXml();
				tidyingCursor.toParent();
			}// EO while there are more empty parents

		}// EO if there was no first child

		// dispose of the tidyingCursor curosr
		tidyingCursor.dispose();

		//
	}// EOM

	/**
	 * 
	 * Oct 5, 2008 guys
	 * 
	 * @param xmlcur
	 * @param currentFieldMetadata
	 * @param currentParentMetadata
	 * @param xmlRoot
	 * @param mapPaymentFields
	 */
	private void moveField(final XmlCursor xmlcur, final LogicalFields currentFieldMetadata, final LogicalFields currentParentMetadata,
			final XmlObjectBase xmlRoot, final XmlCursor rootDocumentXmlcur, final PaymentType enumPaymentType,
			final Map<Object, PaymentFieldInterface> mapPaymentFields) {

		// extract the current xml node
		final XmlObject currentNode = xmlcur.getObject();

		// assuming that the path parent (if exists) is stored in a bookmark pop to it
		xmlcur.pop();

		// retrieve the logicalFieldsXpath metadata for the target field from cache
		final Map<String, LogicalFieldsXpath> mapFieldsXPaths = CacheKeys.LogicalFieldsXPathKey.getSingle(enumPaymentType);

		// retrieve the move target logical fields xpath metadata
		final LogicalFieldsXpath moveTargetXPathMetadata = mapFieldsXPaths.get(currentFieldMetadata.getMoveToField());

		// if the parent exists and the current field's parent id is the same as the parent's id
		// use the parent as the group parent, else, use the root
		final String sDestinationPathParentId = moveTargetXPathMetadata.getPathParentId();
		XmlObjectBase moveToFieldPathParent = null;

		// determine the path parent
		// if group removal operation
		if (currentParentMetadata == null) {
			moveToFieldPathParent = xmlRoot;
			// else if the current path parent is the same for the source and destination
		} else if (currentParentMetadata.getFieldLogicalId().equals(sDestinationPathParentId)) {
			moveToFieldPathParent = (XmlObjectBase) xmlcur.getObject();
			// else if the source's path parent is not the same as the destination's one
		} else {
			// get or create the path to the destination's path parent first
			final LogicalFieldsXpath pathParentXpathMetadata = mapFieldsXPaths.get(sDestinationPathParentId);

			moveToFieldPathParent = this.getOrCreateXmlNode(pathParentXpathMetadata, xmlRoot, enumPaymentType.getSchemaNamespace(), false);
		}// EO else if the source's path parent is not the same as the destination's one

		// invoke the getOrCreateXmlNode() which shall create the node required
		final XmlObjectBase newNode = this.getOrCreateXmlNode(moveTargetXPathMetadata, moveToFieldPathParent, enumPaymentType.getSchemaNamespace(),
				false);

		// set the current node in the new node
		newNode.set(currentNode);

		// remove the current node from its previous location and all subsequent empty parents
		this.pruneXml(currentNode, rootDocumentXmlcur, true/* remove from xml */, true /* bForceRemove */);

	}// EOM

	private final void handleCopyToField(final PaymentFieldInterface originField, final Map<Object, PaymentFieldInterface> mapPaymentFields,
			final PDO pdo) {
		String sCopyToFieldId = null;

		// guard condition
		if ((sCopyToFieldId = originField.getCopyToFieldId()) == null)
			return;

		final LogicalFields copyToFieldMetadata = LogicalFieldsIdKey.getSingle(sCopyToFieldId);

		// if the field metadata is null put a place holder
		PaymentFieldInterface copyToField = null;

		// if the field is not already present in the map, create and set it
		if ((copyToField = mapPaymentFields.get(sCopyToFieldId)) == null || copyToField == PaymentField.PLACE_HOLDER) {

			// TODO: Xml fields cannot be used as copy targets in the current design due to the fact that
			// performLoadFromPersistence processes relational fields first and xml last which creates
			// a scenario whereby the pdo xmlmetadata is empty and cannot be used for createNSet
			/*
			 * //if the logical field was of xml type, invoke the createNset to ensure that the xml node //would be created in case it is not already
			 * if(FieldType.isXmlType(copyToFieldMetadata.getFieldType())) { copyToField = this.createNSet(sCopyToFieldId, originField.get(), pdo,
			 * falsebLazyLoad) ; mapPaymentFields.put(sCopyToFieldId, copyToField) ; return ; }//EO if the payment field was an xml payment field
			 */

			copyToField = (copyToFieldMetadata == null ? PaymentField.PLACE_HOLDER : copyToFieldMetadata.getFieldType().newPaymentField(
					copyToFieldMetadata.getFieldLogicalId(), copyToFieldMetadata,pdo));

			mapPaymentFields.put(sCopyToFieldId, copyToField);

		}// EO if the copy to field was not already created

		// if the copy to field was not a place holder set the value
		if (copyToField != PaymentField.PLACE_HOLDER)
			copyToField.set(originField.get(), true);

	}// EOM

	@Override
	public final PaymentFieldInterface createNSet(final Object oValue, final PDO pdo, Object... arrLogicalPathToNode) {

		final CacheServiceInterface cache = CacheServiceInterface.eINSTANCE;
		final String sLogicalFID = (String) arrLogicalPathToNode[0];

		// get the field metadata from cache first
		LogicalFields fieldMetadata = LogicalFieldsIdKey.getSingle(sLogicalFID);

		if (fieldMetadata == null) {
			final String sErrorMsg = ErrorAuditUtils.getErrorText(ProcessErrorConstants.PDOLogicalFieldNotFound, pdo.getMID(), sLogicalFID);
			logger.error(sErrorMsg);
			return null;
		}// EO if the logical field does not exist
		PaymentFieldInterface paymentField = fieldMetadata.getFieldType().newPaymentField(sLogicalFID, fieldMetadata,pdo);
		if (FieldType.isXmlType(fieldMetadata.getFieldType()) || fieldMetadata.getFieldType() == FieldType.XML_DETACHED_MULTI) {

			// retreive the xml document metadata from the pdo associated with the fieldmetadata's location value
			final PDO.XmlMetadata xmlMetadata = pdo.getXmlMetadata(fieldMetadata.getLocation());

			// get the child relative path from the parent from the paths map
			// Note: when preparing the key, the field metadata's location member is used to retrieve
			// the associated document
			final Map<String, LogicalFieldsXpath> mapFieldsXPaths = CacheKeys.LogicalFieldsXPathKey.getSingle(xmlMetadata.getPaymentType());

			// if the xpath fields are not defined for the given payment type log and abort

			if (mapFieldsXPaths == null) {
				logger.error("Could not locate any xpath definitions for field {} in message type '{}', aborting.", sLogicalFID,
						xmlMetadata.getPaymentType());
				return null;
			}// EO if the mapFieldsXPaths was null for the given payment type ]

			// create a payment field for the object and return it.

			// this method call will create the path to the target element as well as capture this field's
			// immediate parent node reference.
			((XmlPaymentField.XmlMultiOccurencePaymentField) paymentField).setFromXml(xmlMetadata.getXml(), mapFieldsXPaths.get(sLogicalFID),
					xmlMetadata.getPaymentType(), oValue, false/* bUpdateOrigVal */, arrLogicalPathToNode);

			// create linked orig payment field if required
			// [0] - should derive orig fields from given xml
			// [1] - should perform xml mapping
			final boolean bConjoinedMode = pdo.isConjoined();
			final boolean[] arrShouldParseAndDeriveOrigFields = XmlLocationType.reverseMapping(fieldMetadata.getLocation()).shouldPerformXmlMapping(
					pdo, bConjoinedMode);

			this.handleOrigPaymentField(pdo, mapFieldsXPaths, ((XmlPaymentField) paymentField).getXml(), paymentField, fieldMetadata,
					xmlMetadata.getPaymentType(), arrShouldParseAndDeriveOrigFields[0], bConjoinedMode, false/* bUpdateOrigVal */);

		} else {
			((PaymentField.MonitorPaymentField) paymentField).set(oValue, arrLogicalPathToNode);
		}

		return paymentField;
	}// EOM

	@Override
	public final PaymentFieldInterface createNSet(String sLogicalFID, final Object oValue, final PDO pdo, final boolean bIsLazyLoad) {
		final CacheServiceInterface cache = CacheServiceInterface.eINSTANCE;
		final String ANY_ATTRIBUTE_PATH = "@*";
		// get the field metadata from cache first

		boolean bUserDefinedField = false;
		LogicalFields fieldMetadata = null;
		String[] arrUDFFieldParts = null;

		if ((bUserDefinedField = sLogicalFID.indexOf('^') != -1)) {
			arrUDFFieldParts = sLogicalFID.split("\\^");
			fieldMetadata = CacheKeys.UserDefinedFieldsIdKey.getSingle(arrUDFFieldParts[0], arrUDFFieldParts[1]);
		} else {
			fieldMetadata = LogicalFieldsIdKey.getSingle(sLogicalFID);
		}// EO else if the field was not user defined

		PaymentFieldInterface paymentField = null;

		if (fieldMetadata == null)
			return FieldType.DERIVED.newPaymentField(sLogicalFID, oValue, pdo);

		FieldType enumFieldType = fieldMetadata.getFieldType();
		final boolean bXmlField = FieldType.isXmlType(enumFieldType);
		// final boolean bXmlOrigField = !bXmlField && (XmlLocationType.reverseMapping(fieldMetadata.getLocation()) != null) ;
		final boolean bXmlOrigField = (fieldMetadata.getFieldType() == FieldType.ORIG_XML);

		// if the element does not exist or is not of xml type, trace and create a derived field using
		// the oValue as the data type indicator and subsequently the payment field indicator
		if (!bXmlField && !bXmlOrigField) {

			// if the field type is of type reference, then a load of the cached member is required
			// the value would not be used in this case as it would have been extracted from the loaded
			// cache member
			if (enumFieldType == FieldType.REFERENCE) {
				this.loadCachedMember(pdo, fieldMetadata.getObjRefDataId());

				// rertieve the payment field from the pdo's map as it had already been created
				final Map<Object, PaymentFieldInterface> mapPdoDataMap = pdo.getDataMap();
				paymentField = mapPdoDataMap.get(sLogicalFID);
				// if the payment field does not exist, after the cached member load, put a place holder in the map
				if (paymentField == null) {
					if (fieldMetadata == null) {
						paymentField = PaymentField.PLACE_HOLDER;
						mapPdoDataMap.put(sLogicalFID, paymentField);
					} else {
						paymentField = enumFieldType.newPaymentField(sLogicalFID, fieldMetadata,pdo);
						paymentField.set(oValue, pdo.isNew());
					}
				}// EO if there was no payment field
			} else if (!bIsLazyLoad && enumFieldType != FieldType.MEMBER || enumFieldType == FieldType.MONITOR_CHILD) { // only initilize if the
																														// context is not that of a
																														// lazy load
				paymentField = enumFieldType.newPaymentField(sLogicalFID, fieldMetadata,pdo);
				// invoke the extra init hook method
				paymentField.extraInit(pdo);
				if (!bIsLazyLoad)
					paymentField.set(oValue, pdo.isNew());
			}// EO else if the field type was not reference

			return paymentField;
		}// EO if not xml type

		// lazy load is prohibited for xml types. return null and not a
		// place holder as this method was invoked from the get() and not from the set()
		if (bIsLazyLoad)
			return null;

		// if the field is an orig field in a split mode simply create a derive field and return it
		final boolean bConjoinedMode = pdo.isConjoined();
		if (bXmlOrigField) {

			if (!bConjoinedMode) {
				paymentField = enumFieldType.newPaymentField(sLogicalFID, fieldMetadata,pdo);
				// invoke the extra init hook method
				paymentField.set(oValue, pdo.isNew());
				paymentField.extraInit(pdo);
				return paymentField;
			} else {
				// create the current xml payment field by switching the id and the metadata with that of the orig_field id
				// this process would eventually create the orig field
				sLogicalFID = fieldMetadata.getOrigFieldId();
				fieldMetadata = LogicalFieldsIdKey.getSingle(sLogicalFID);
				enumFieldType = fieldMetadata.getFieldType();
			}// EO else if conjoined mode

		}// EO if orig field

		// retreive the xml document metadata from the pdo associated with the fieldmetadata's location value
		final PDO.XmlMetadata xmlMetadata = pdo.getXmlMetadata(fieldMetadata.getLocation());

		// get the xpath metadata per namespace map from the cache

		Map<String, LogicalFieldsXpath> mapFieldsXPaths = CacheKeys.LogicalFieldsXPathKey.getSingle(xmlMetadata.getPaymentType());

		if (mapFieldsXPaths == null) {
			logger.error("Could not locate any xpath definitions for field {} in message type '{}', creating a derived field instead.", sLogicalFID,
					xmlMetadata.getPaymentType());
			return FieldType.DERIVED.newPaymentField(sLogicalFID, oValue, pdo);
		}// EO if the mapFieldsXPaths is null tarce the error and return null

		LogicalFieldsXpath targetElementXmlMetadata = mapFieldsXPaths.get(sLogicalFID);

		// if the field does was not defined for the given message type, create the field as derived and warn
		if (targetElementXmlMetadata == null) {

			// if the field is a user defined field, create a new bogus logicalfieldsXpath and store in the map for future uses
			if (bUserDefinedField) {
				// LogicalFieldsXpath(final String sFieldLogicalId, final String sTagName, final String sFieldPath, final FieldType enumFieldType,
				// final String sXmlType)
				targetElementXmlMetadata = new LogicalFieldsXpath(sLogicalFID, arrUDFFieldParts[1]/* field id is the tagname */,
						'/' + arrUDFFieldParts[1]/* field path */, enumFieldType, fieldMetadata.getFieldXmlType(), fieldMetadata.getPathParentId(),
						fieldMetadata.getLocation());
				mapFieldsXPaths.put(sLogicalFID, targetElementXmlMetadata);
			}// EO if user defined field
			else {
				logger.warn("Could not locate xml logical field '{}' definition for message type '{}', creating a derived field instead",
						sLogicalFID, xmlMetadata.getPaymentType());
				return FieldType.DERIVED.newPaymentField(sLogicalFID, oValue, pdo);
			}// EO if not user defined field
		}// EO if the target logical fields xpath was null

		String sTagName = targetElementXmlMetadata.getTagName();
		// get the group parent data
		String pathParentId = getPathParentId(fieldMetadata, targetElementXmlMetadata);
		final LogicalFieldsXpath groupParentXmlMetadata = mapFieldsXPaths.get(pathParentId);

		// construct the full path to the child
		String sPathToTargerNode = groupParentXmlMetadata.getFieldPath() + targetElementXmlMetadata.getFieldPath();

		// remove any leading '/'s
		int iSubStringStartIndex = 0;
		if (sPathToTargerNode.charAt(1) == '/')
			iSubStringStartIndex = 2;
		else if (sPathToTargerNode.charAt(0) == '/')
			iSubStringStartIndex = 1;

		String arrFullPathToChildNode[] = sPathToTargerNode.substring(iSubStringStartIndex).split("/");

		// prepare metadata required for the loop
		final String sNamespace = xmlMetadata.getPaymentType().getSchemaNamespace() ;
		
		// iterate over the path items, locate and if not present create
		int iLength = arrFullPathToChildNode.length;
		String sCurrentNodeName = null;
		// start from the root
		XmlObjectBase currentPathElement = xmlMetadata.getXml();

		for (int i = 0; i < iLength; i++) {

			sCurrentNodeName = arrFullPathToChildNode[i];
			// if(sCurrentNodeName.equals(ANY_ATTRIBUTE_PATH)) sCurrentNodeName = sTagName ;
			currentPathElement = this.getOrCreateImmidiateChild(currentPathElement, sCurrentNodeName, 0, sNamespace, sTagName,
					xmlMetadata.getPaymentType(), false);

		}// EO while there are more path items

		// if the element was not present return a place holder
		if (currentPathElement == null)
			return PaymentField.PLACE_HOLDER;

		// set the value in the object
		fieldMetadata.getDataType().setXbeanValue(currentPathElement, oValue);

		// create a payment field for the object and return it.
		paymentField = enumFieldType.newPaymentField(sLogicalFID, fieldMetadata,pdo);
		((XmlPaymentField) paymentField)
				.setFromXml(currentPathElement, targetElementXmlMetadata, xmlMetadata.getPaymentType(), false/* bUpdateOrigVal */);

		// if the payment is in initial create mode (user create) and the field has an orig field id value
		// create an additional payment field for the orig field, set the value in it, set the first instance in the second
		// and the second in the first

		// [0] - should derive orig fields from given xml
		// [1] - should perform xml mapping
		final boolean[] arrShouldParseAndDeriveOrigFields = XmlLocationType.reverseMapping(fieldMetadata.getLocation()).shouldPerformXmlMapping(pdo,
				bConjoinedMode);

		this.handleOrigPaymentField(pdo, mapFieldsXPaths, currentPathElement, paymentField, fieldMetadata, xmlMetadata.getPaymentType(),
				arrShouldParseAndDeriveOrigFields[0], bConjoinedMode, false/* bUpdateOrigVal */);

		// if the orig field id flag is true, then the actual payment field is the current one.
		// but the returned result is the orig. therefore, cache the current in the map
		if (bXmlOrigField) {
			pdo.getDataMap().put(sLogicalFID, paymentField);
			paymentField = paymentField.getLinkedPaymentField();
		}// EO if xml orig field

		// return the requestsed payment field (might be the linked field is the bOrigXmlField is true
		return paymentField;
	}// EOM

	/**
	 * get the overriden parent.
	 */
	private String getPathParentId(LogicalFields fieldMetadata, LogicalFieldsXpath fieldXPathMetadata) {
		String overridenParentId = fieldXPathMetadata.getPathParentId();
		if (overridenParentId != null && fieldXPathMetadata.getPathParentId().length() > 0)
			return overridenParentId;

		return fieldMetadata.getPathParentId();
	}

	@Override
	public final String getLogicalFieldXpath(final String sLogicalFieldId, final PaymentType enumPaymentType, final boolean bStartFromFndtMsg,
			final String sFndgMsgNsPrefix) {
		final String TRAILING_ANY_NODE_REPLACEMENT_REGEX = "/\\*$";
		final String ANY_ATTRIBUTE_PATH = "@*";
		final String ATTRIBUTE = "@";

		final Map<String, LogicalFieldsXpath> mapPaymentTypeFields = CacheKeys.LogicalFieldsXPathKey.getSingle(enumPaymentType);

		if (mapPaymentTypeFields == null)
			return null;

		LogicalFieldsXpath logicalFieldXpathMetadata = mapPaymentTypeFields.get(sLogicalFieldId);

		if (logicalFieldXpathMetadata == null) {
			// if the field is not a user defined field in the context of the extension payment type , return null
			if (enumPaymentType != PaymentType.valueOf(PaymentType.PT_EXTN) || sLogicalFieldId.indexOf('^') == -1)
				return null;

			// else retrieve the logical field and construct a bogus logical fieldsd xpath for the udf instance
			final LogicalFields udfLogicalFieldMetadata = CacheKeys.UserDefinedFieldsIdKey.getSingle(sLogicalFieldId);
			final String[] arrUDFFieldParts = sLogicalFieldId.split("\\^");

			logicalFieldXpathMetadata = new LogicalFieldsXpath(sLogicalFieldId, arrUDFFieldParts[1]/* field id is the tagname */,
					'/' + arrUDFFieldParts[1]/* field path */, udfLogicalFieldMetadata.getFieldType(), udfLogicalFieldMetadata.getFieldXmlType(),
					udfLogicalFieldMetadata.getPathParentId(), udfLogicalFieldMetadata.getLocation());

			mapPaymentTypeFields.put(sLogicalFieldId, logicalFieldXpathMetadata);

		}// EO if the logica lfields xpath metadata was not found

		final StringBuilder sbPathBuilder = new StringBuilder();

		String sFieldXPath = null;
		if (bStartFromFndtMsg) {

			// retrieve the path for the field's xml location type's associated document field id
			// if the field path was not present, construct and cache it
			final String sDocumentFieldId = XmlLocationType.valueOf(logicalFieldXpathMetadata.getLocation()).getDocumentLogicalFieldID();
			sFieldXPath = m_mapDocumentXPaths.get(sDocumentFieldId);

			if (sFieldXPath == null) {
				Map<String, LogicalFieldsXpath> mapPaymentDocumentTypeFields = CacheKeys.LogicalFieldsXPathKey.getSingle(PaymentType.PT_FNDT_MSG);
				final LogicalFieldsXpath documentXpathMetadata = mapPaymentDocumentTypeFields.get(sDocumentFieldId);
				sFieldXPath = documentXpathMetadata.getFieldPath();

				// ensure that there is no trailing any nodes chars
				sFieldXPath = sFieldXPath.replaceAll(TRAILING_ANY_NODE_REPLACEMENT_REGEX, "");

				if (sFndgMsgNsPrefix == null) {
					// if there is no namespace prefix then the field is in the same namespace of the fndtmsg which would mean
					// that the document path would contain the first element of the field's/group path
					// therefore, remove the last element of the doucment's path
					final int iLastOccurrenceOfPathSeperator = sFieldXPath.lastIndexOf('/');
					sFieldXPath = sFieldXPath.substring(0, iLastOccurrenceOfPathSeperator);
				}// EO if the field is in the same namespace of the document

				m_mapDocumentXPaths.put(sDocumentFieldId, sFieldXPath);

			}// EO sFieldXPath was not yet defined

			// if the sFndgMsgNsPrefix is not null replace '/' with '/sFndgMsgNsPrefix:'
			if (sFndgMsgNsPrefix != null)
				sFieldXPath = sFieldXPath.replaceAll("/", "/" + sFndgMsgNsPrefix + ":");

			sbPathBuilder.append(sFieldXPath);
		}// EO if should start from the fndt msg root

		// retrieve the group's parent xml metadata
		final LogicalFieldsXpath groupXPathMetadata = mapPaymentTypeFields.get(logicalFieldXpathMetadata.getPathParentId());
		if (groupXPathMetadata != null) {

			// ensure that there is no trailing any nodes chars
			sFieldXPath = groupXPathMetadata.getFieldPath().replaceAll(TRAILING_ANY_NODE_REPLACEMENT_REGEX, "");
			sbPathBuilder.append(sFieldXPath);
		}// EO if there was a path parent

		sbPathBuilder.append(logicalFieldXpathMetadata.getFieldPath());

		if (sbPathBuilder.toString().endsWith(ANY_ATTRIBUTE_PATH)) {
			// Change xpath from @* to @tagName
			String tagName = logicalFieldXpathMetadata.getTagName();
			String sbPathBuilderAddTagName = sbPathBuilder.toString().replace(ANY_ATTRIBUTE_PATH, ATTRIBUTE + tagName);
			return sbPathBuilderAddTagName;
		}
		return sbPathBuilder.toString();
	}// EOM

	/**
	 * Pre-Condition: Only Xml Payment Field IDs should be used
	 */
	@Override
	public final boolean fieldExists(final String sLogicalFieldID, final PDO pdo, final XmlLocationType enumXmlLocationType) {
		//
		// rertieve the xml document from the pdo's location, construct the xpath by concatenating the logical field'x path with
		// it group's path (if not group itself)
		final XmlMetadata xmlmetadata = pdo.getXmlMetadata(enumXmlLocationType.name());
		XmlObjectBase rootXbean = xmlmetadata.getXml();

		//

		return (getFieldFromXml(sLogicalFieldID, rootXbean) != null);
	}// EOM

	@Override
	public final Object getFieldFromXml(final String logicalField, XmlObjectBase rootXbean) {

		final XmlCursor xmlcur = rootXbean.newCursor();
		xmlcur.toParent();

		// actualRoot.getNodeType() == Node.DOCUMENT_NODE
		// only use the parent if it is a document wrapper else, the xml is already set on the correct node

		final PaymentType enumPaymentType = PaymentType
				.valueOf((xmlcur.getObject().getDomNode().getNodeType() == Node.DOCUMENT_NODE ? (XmlObjectBase) xmlcur.getObject() : rootXbean));

		rootXbean = (XmlObjectBase) xmlcur.getObject();

		xmlcur.dispose();

		final Map<String, LogicalFieldsXpath> mapPaymentLogicalFieldsXpaths = CacheKeys.LogicalFieldsXPathKey.getSingle(enumPaymentType);

		final LogicalFieldsXpath fieldXpathMetadata = mapPaymentLogicalFieldsXpaths.get(logicalField);
		if (fieldXpathMetadata == null)
			return null;
		// else if the field is not a group, retrieve the group's metadata from the map and concatenate it
		String sXpath = fieldXpathMetadata.getFieldPath();
		// if the field path does not contain the
		if (FieldType.isXmlMulti(fieldXpathMetadata.getFieldType()))
			sXpath = sXpath + '/' + fieldXpathMetadata.getTagName();

		if (!fieldXpathMetadata.getPathParentInd()) {
			LogicalFieldsXpath groupXmlMetadata = mapPaymentLogicalFieldsXpaths.get(fieldXpathMetadata.getPathParentId());
			sXpath = groupXmlMetadata.getFieldPath() + sXpath;

			if (groupXmlMetadata.getPathParentId() != null) {
				groupXmlMetadata = mapPaymentLogicalFieldsXpaths.get(groupXmlMetadata.getPathParentId());
				String parentPath = groupXmlMetadata.getFieldPath();
				if (groupXmlMetadata.getDocumentInd()) {
					final int iParentPathLength = parentPath.length();
					if (parentPath.endsWith("*"))
						parentPath = parentPath.substring(0, iParentPathLength - 2);
					else
						parentPath = parentPath.substring(0, (iParentPathLength - (groupXmlMetadata.getTagName().length() + 1)));
				}

				sXpath = parentPath + sXpath;

			}// EO if the field was not a group

		}// EO if the field was not a group

		// final String sXqueryTemplate = "declare default element namespace '" + enumPaymentType.getSchemaNamespace() + "'; $this" ;
		String sXqueryTemplate = enumPaymentType.getXpathlNamespaceCaluse() + ".";

		XmlObject[] arrSelection = rootXbean.selectPath(sXqueryTemplate + sXpath);

		if (arrSelection.length == 0) {
			sXqueryTemplate = enumPaymentType.getXpathlNamespaceCaluse() + "/";
			arrSelection = rootXbean.selectPath(sXqueryTemplate + sXpath);
		}
		if (arrSelection.length == 0) 
			return null;
		
		// else
		final XmlObjectBase seletionXbean = (XmlObjectBase) arrSelection[0];

		SchemaType schemaType = seletionXbean.schemaType();
		if (schemaType != null && schemaType.getBaseType() != null)
			schemaType = schemaType.getBaseType();

		return DataType.reverseValueOf(schemaType).convert(seletionXbean.getStringValue());
	}// EOM

	/**
	 * 
	 * Oct 4, 2009 guys
	 * 
	 * Creates a linked xml payment field using the origFieldId value of the logical fields metadata to determine the linked field's identity and the
	 * xml node's reference as the value's source. Currently the method shall only operate if the payment field is in MF_INITIAL_CREATE mode as it
	 * accomodates joint xml documents
	 * 
	 * TODO: support other payment field types
	 * 
	 * @param pdo
	 * @param mapFieldsXPaths
	 * @param oXeanNode
	 * @param sourcePaymentField
	 * @param sourceLogicalFieldMetadata
	 * @param enumPaymentType
	 */
	private final PaymentFieldInterface handleOrigPaymentField(final PDO pdo, Map<String, LogicalFieldsXpath> mapFieldsXPathMetadata,
			final XmlObjectBase oXeanNode, final PaymentFieldInterface sourcePaymentField, final LogicalFields sourceLogicalFieldMetadata,
			final PaymentType enumPaymentType, final boolean bDeriveOrigFields, final boolean bConjoinedMode, final boolean bUpdateOrigVal) {

		String sLinkedFieldId = null;
		if ((!bDeriveOrigFields && !bConjoinedMode) || sourcePaymentField == PaymentField.PLACE_HOLDER
				|| (sLinkedFieldId = sourceLogicalFieldMetadata.getOrigFieldId()) == null)
			return null;

		final Map<Object, PaymentFieldInterface> pdoDataMap = pdo.getDataMap();

		// else

		// if the mapFieldsXPathMetadata does not yet exist, retrieve it
		if (mapFieldsXPathMetadata == null) {
			mapFieldsXPathMetadata = CacheKeys.LogicalFieldsXPathKey.getSingle(enumPaymentType);
		}// EO if the mapFieldsXPathMetadata was not yet initialised

		final LogicalFields linkedFieldMetadata = LogicalFieldsIdKey.getSingle(sLinkedFieldId);
		final LogicalFieldsXpath linkedFieldXmlMetadata = mapFieldsXPathMetadata.get(sLinkedFieldId);

		if (linkedFieldMetadata == null) {
			logger.error("Original Logical Field '{}' is defined in the '{}' ORIG_FIELD_ID column but "
					+ "does not have an actual LOGICAL_FIELDS record, aborting creation", sLinkedFieldId, sourcePaymentField.getFieldId());

			return null;
		}// EO if the orig payment field did not have a logical field record

		// if the field type is xml create a derived field instead
		final FieldType linkedFieldType = linkedFieldMetadata.getFieldType();
		boolean bIsXmlMulti = linkedFieldType == FieldType.XML_DETACHED_MULTI;

		final PaymentFieldInterface linkedPaymentField = (!bIsXmlMulti ? FieldType.ORIG_XML.newPaymentField(linkedFieldMetadata.getFieldLogicalId(),
				linkedFieldMetadata,pdo) : linkedFieldType.newPaymentField(sLinkedFieldId, linkedFieldMetadata,pdo));

		if (bIsXmlMulti) {
			final XmlCursor xmlcur = oXeanNode.newCursor();
			((DetachedXmlMultiOccurrencePaymentField) linkedPaymentField).setFromXml(xmlcur, linkedFieldXmlMetadata, enumPaymentType, bUpdateOrigVal);
			xmlcur.dispose();

		} else {
			try {
				linkedPaymentField.set(linkedPaymentField.getDataType().convert(oXeanNode.getStringValue()), pdo.isNew());
			} catch (Exception e) {
				if (logger.isInfoEnabled()) {
					final String TRACE_NOTIFICATION = "ERROR - Exception during set of XMLBean for Field logical ID: {}, Field type: {}, Xml type: {}, Field path: {} \n"
							+ "          Value will remain null - exception type '{}' stack trace is printed ahead for future invetigation and will not stop the payment parsing process !!!";

					logger.info(TRACE_NOTIFICATION,
							new Object[] { sourceLogicalFieldMetadata.getFieldLogicalId(), linkedFieldXmlMetadata.getFieldType(),
									linkedFieldXmlMetadata.getXmlType(), linkedFieldXmlMetadata.getFieldPath(), e.getClass() });
				}
				pdo.setFieldIllegalXmlValue(linkedPaymentField.getFieldId(), oXeanNode.newCursor().getTextValue());
				
				// add an error to the pdo
			//	ErrorAuditUtils.setErrors(new ProcessError(ProcessErrorConstants.PDOXmlInvalidFormat, new Object[] { "Exception during set of XMLBean for Field path: " + linkedFieldXmlMetadata.getFieldPath() }), pdo);
				// mark the pdo as empty by setting the message mode as non global and the status as normal
				// the is empty() would be used in the newPdO() to determine whether the pdo should
				// be assigned a special AUTHEX status
				pdo.setIsGlobalPDO(false);
			}
		}

		// cache the linked payment field in the pdo
		pdoDataMap.put(sLinkedFieldId, linkedPaymentField);

		// if the bConjoinedMode is true set the linked payment field in the orig one and visa versa
		if (bConjoinedMode) {
			sourcePaymentField.setLinkedPaymentField(linkedPaymentField);
			linkedPaymentField.setLinkedPaymentField(sourcePaymentField);
		}// EO if bConjoinedMode

		// handle any copy to fields defined on the linked field
		this.handleCopyToField(linkedPaymentField, pdoDataMap, pdo);

		return linkedPaymentField;
	}// EOM

	@Override
	public final Object getFromMember(final String sLogicalFID, Object oValue, Object member, String memberId) {

		// get the field metadata from cache first
		final LogicalFields fieldMetadata = LogicalFieldsIdKey.getSingle(sLogicalFID);

		if (fieldMetadata != null && member != null) {

			final LogicalFields memberIdfieldMetadata = LogicalFieldsIdKey.getSingle(memberId);

			// Only if the member id (location field from root member) eqauls to object ref data id of logical field.
			if (memberIdfieldMetadata != null && fieldMetadata.getObjRefDataId() != null
					&& fieldMetadata.getObjRefDataId().equals(memberIdfieldMetadata.getLocation())) {

				final Class<?> clsListMemberType = member.getClass();
				final PdoListMemberType enumPdoListMemberType = PdoListMemberType.unmarshallingRevrseVauleOf(clsListMemberType);
				oValue = enumPdoListMemberType.getListItemFieldValue(member, fieldMetadata, memberId, clsListMemberType);

			}// EO if the reference field was properly defined
		}// EO if the member field was defined properly

		return oValue;
	}// EOM

	public final Object setXmlValue(final XmlObjectBase xmlNode, final Object oValue) {

		try {

			final Object oOriginalValue = xmlNode.getObjectValue();

			// get set overloaded set() corresponding to the formal arg's value
			final Class clazz = xmlNode.getClass();
			final Method setMethod = clazz.getMethod("set", oValue.getClass());
			setMethod.invoke(xmlNode, oValue);

			return oOriginalValue;
		} catch (Exception e) {
			logger.error(e.getMessage());

			return null;
		}// EO catch block
	}// EOM

	@Override
	public final XmlObjectBase getOrCreateImmidiateChild(XmlObjectBase currentPathElement, String sChildNodeName, final int iOccurrenceIndex,
			final String sNamespace, String tagName) {
		return this.getOrCreateImmidiateChild(currentPathElement, sChildNodeName, iOccurrenceIndex, sNamespace, tagName,
				null/* enumTargetPaymentType */, false/* bForceCreate */);
	}// EOM

	public final XmlObjectBase getOrCreateImmidiateChild(XmlObjectBase currentPathElement, String sChildNodeName, final int iOccurrenceIndex,
			String sNamespace, String tagName, final PaymentType enumTargetPaymentType, final boolean bForceCreate) {

		final String ANY_NS_PREFIX = "*:";
		final String ANY_ATTRIBUTE_PATH = "@*";
		final String PREDICATE_START = "[";

		QName qnmCurrentElementName = null, qnmCurrentPathElement = null;
		XmlObjectBase previousPathElement = currentPathElement;
		tagName = tagName == null ? sChildNodeName : tagName;
		String sPrefix = null;
		int iIndexOfNsPrefix = -1;

		// if the element has the '*:' prefix (any namespace) then remove it prior to continuing
		if (sChildNodeName.indexOf(ANY_NS_PREFIX) == 0)
			sChildNodeName = sChildNodeName.substring(ANY_NS_PREFIX.length());
		else if ((iIndexOfNsPrefix = sChildNodeName.indexOf(':')) != -1) {
			sPrefix = sChildNodeName.substring(0, iIndexOfNsPrefix);
			sChildNodeName = sChildNodeName.substring(iIndexOfNsPrefix + 1);
			String sTempNS = null;
			if (enumTargetPaymentType != null)
				sTempNS = enumTargetPaymentType.getNSforPrefix(sPrefix);
			if (sTempNS != null)
				sNamespace = sTempNS;
		}// EO if there is a namespace prefix
		if (sChildNodeName.indexOf(PREDICATE_START) != -1)
			sChildNodeName = sChildNodeName.substring(0, sChildNodeName.indexOf(PREDICATE_START));

		if (sChildNodeName.equals(ANY_ATTRIBUTE_PATH))
			sChildNodeName = "@" + tagName;

		if (sChildNodeName.length() > 0 && sChildNodeName.charAt(0) == '@') {
			// remove the first char
			sChildNodeName = sChildNodeName.substring(1);
			qnmCurrentElementName = new QName("", sChildNodeName);
			currentPathElement = (XmlObjectBase) currentPathElement.get_store().find_attribute_user(qnmCurrentElementName);

			if (currentPathElement == null)
				currentPathElement = (XmlObjectBase) previousPathElement.get_store().add_attribute_user(qnmCurrentElementName);
		} else {// EO if the current element is an attribute

			qnmCurrentElementName = PaymentType.qname(sChildNodeName, sNamespace);
			qnmCurrentPathElement = PaymentType.qname(currentPathElement);

			if (!bForceCreate && qnmCurrentPathElement.equals(qnmCurrentElementName))
				return currentPathElement;

			// currentPathElement.selectChildren(qnmCurrentElementName) ;
			currentPathElement = (XmlObjectBase) currentPathElement.get_store().find_element_user(qnmCurrentElementName, iOccurrenceIndex);

			if (currentPathElement == null)
				currentPathElement = (XmlObjectBase) previousPathElement.get_store().add_element_user(qnmCurrentElementName);

			previousPathElement = currentPathElement;

		}// EO else if the current element was not an attribute

		return currentPathElement;
	}// EOM

	@Override
	public final PDO newPDO(final Object oInput) {
		return this.newPDO(oInput, false/* bConjoinedOrigNCurrentMode */, null/* sCreationMID */);
	}// EOM

	@Override
	public final PDO newPDO(final Object oInput, final boolean bConjoinedOrigNCurrentMode, final String sCreationMID) {

		final Map mapPaymentData = new HashMap<Object, PaymentFieldInterface>();

		// generate the MID
		final String sMID = (sCreationMID == null ? GlobalUtils.generateGUID() : sCreationMID);

		// create the PDO
		final PDO pdo = new PDO(sMID, mapPaymentData, this, true);

		try {
			// if the bConjoinedOrigNCurrentMode is true, set the MF_INITIAL_CREATE to INITIAL_CREATE_MODE_ON
			// so as to ensure that links would be formed between the xml fields
			if (bConjoinedOrigNCurrentMode)
				pdo.set(MF_INITIAL_CREATE, INITIAL_CREATE_MODE_ON);

			final XmlMetadata xmlmetadata = this.performXmlMapping(XmlLocationType.XML_MSG, mapPaymentData, pdo, true /* bDeriveOrigFields */,
					bConjoinedOrigNCurrentMode, false/* merge context */, oInput, null/* xml orig copy */);

			final PaymentType enumPaymentType = pdo.getPaymentType(CURRENT_XML_KEY);
			final String sPaymentTypeName = enumPaymentType.name();

			// attempt to rertieve the currentxml extension document from the pdo if not found.
			// create one here. if conjoined, use the same instance
			XmlMetadata extnXmlMetadata = pdo.getXmlMetadata(XmlLocationType.XML_MSG_EXTN.name());
			if (extnXmlMetadata == null) {
				final PaymentType enumExtnPaymentType = PaymentType.valueOf(PaymentType.PT_EXTN);
				final XmlObjectBase extnXmlRoot = enumExtnPaymentType.newInstance();
				extnXmlMetadata = pdo.addXmlDocument(XmlLocationType.XML_MSG_EXTN, enumExtnPaymentType, extnXmlRoot);
				// add the orig extension
				pdo.addXmlDocument(XmlLocationType.XML_ORIG_MSG_EXTN, enumExtnPaymentType, (bConjoinedOrigNCurrentMode ? extnXmlRoot
						: enumExtnPaymentType.newInstance()));
				logger.debug("added new msg Extn to mid {} , is conjoined : {}",pdo.getMID(),bConjoinedOrigNCurrentMode);
			}// EO if the extension was not yet created
			else{
				logger.debug("msg Extn already exist in mid {} , is conjoined : {}",pdo.getMID(),bConjoinedOrigNCurrentMode);
			}
			pdo.set(PDOConstantFieldsInterface.P_MSG_STS, MESSAGE_STATUS_RECEIVED);
			// ensure that the xml and xmlorig msg are encslosed with a fndtMsg type as per the standard
			// FndtMsgPaymentType.newFndtMsg(xmlmetadata.getXml(), false/*bInspectDocumentRoot*/) ;
			// FndtMsgPaymentType.newFndtMsg(pdo.getXml(ORIG_XML_MSG_KEY), true/*bInspectDocumentRoot*/, true/*bExtractPmntAsIs*/, true
			// /*bReturnPmntSection*/) ;

			// if the pdo is not global, then there was a parsing error and therefore the status should be set to AUTHEX rather than RECEIVED
			// if there was a parsing error, set the create time stamp to the default office's time stamp
			if (!pdo.isGlobalPDO()) {
				pdo.set(P_CREATE_DT, NewASDateTimeUtils.getCurrentDateAndZoneByOffice(GlobalConstants.DEFAULT_SERVER_OFFICE_NAME).getDate());
				ErrorAuditUtils.setErrors(new ProcessError(ProcessErrorConstants.MessageStatusChanged, 
							new Object[] { pdo.getString(PDOConstantFieldsInterface.P_MSG_STS), MESSAGE_STATUS_AUTHEX }), pdo);
				pdo.set(PDOConstantFieldsInterface.P_MSG_STS, MESSAGE_STATUS_AUTHEX);
				pdo.set(PDOConstantFieldsInterface.P_OFFICE, GlobalConstants.DEFAULT_SERVER_OFFICE_NAME);
				pdo.set(P_DEPARTMENT, GlobalConstants.DEFAULT_SERVER_DEPARTMENT);
			}// EO if there was a parsing error

			// set the MID into the relational field for future reference
			pdo.set(PDOConstantFieldsInterface.P_MID, sMID);
			// set the msg type into the relational field for future reference
			pdo.set(PDOConstantFieldsInterface.P_MSG_TYPE, sPaymentTypeName);
			pdo.set(PDOConstantFieldsInterface.P_ORIG_MSG_TYPE, sPaymentTypeName);
			if (pdo.get(PDOConstantFieldsInterface.P_IS_HISTORY) == null)
				pdo.set(PDOConstantFieldsInterface.P_IS_HISTORY, 0);
		} catch (Exception e) {
			ExceptionController.getInstance().handleException(e, this);

			throw new IllegalArgumentException(e);
		}// EO catch block

		return pdo;
	}// EOM
	
	@Override
	public PDO newPDO(Object oInput, boolean bConjoinedOrigNCurrentMode,
			String sCreationMID, boolean isBPFlow) {
		final Map mapPaymentData = new HashMap<Object, PaymentFieldInterface>();

		// generate the MID
		final String sMID = (sCreationMID == null ? GlobalUtils.generateGUID() : sCreationMID);

		// create the PDO
		final PDO pdo = new PDO(sMID, mapPaymentData, this, true);

		try {
			// if the bConjoinedOrigNCurrentMode is true, set the MF_INITIAL_CREATE to INITIAL_CREATE_MODE_ON
			// so as to ensure that links would be formed between the xml fields
			if (bConjoinedOrigNCurrentMode)
				pdo.set(MF_INITIAL_CREATE, INITIAL_CREATE_MODE_ON);

			final XmlMetadata xmlmetadata = this.performXmlMapping(XmlLocationType.XML_MSG, mapPaymentData, pdo, true /* bDeriveOrigFields */,
					bConjoinedOrigNCurrentMode, false/* merge context */, oInput, null/* xml orig copy */);

			final PaymentType enumPaymentType = pdo.getPaymentType(CURRENT_XML_KEY);
			final String sPaymentTypeName = enumPaymentType.name();

			// attempt to rertieve the currentxml extension document from the pdo if not found.
			// create one here. if conjoined, use the same instance
			XmlMetadata extnXmlMetadata = pdo.getXmlMetadata(XmlLocationType.XML_MSG_EXTN.name());
			if (extnXmlMetadata == null) {
				final PaymentType enumExtnPaymentType = PaymentType.valueOf(PaymentType.PT_EXTN);
				final XmlObjectBase extnXmlRoot = enumExtnPaymentType.newInstance();
				extnXmlMetadata = pdo.addXmlDocument(XmlLocationType.XML_MSG_EXTN, enumExtnPaymentType, extnXmlRoot);
				// add the orig extension
				pdo.addXmlDocument(XmlLocationType.XML_ORIG_MSG_EXTN, enumExtnPaymentType, (bConjoinedOrigNCurrentMode ? extnXmlRoot
						: enumExtnPaymentType.newInstance()));
				logger.debug("added new msg Extn to mid {} , is conjoined : {}",pdo.getMID(),bConjoinedOrigNCurrentMode);
			}// EO if the extension was not yet created
			else{
				logger.debug("msg Extn already exist in mid {} , is conjoined : {}",pdo.getMID(),bConjoinedOrigNCurrentMode);
			}
			pdo.set(PDOConstantFieldsInterface.P_MSG_STS, MESSAGE_STATUS_RECEIVED);
			// ensure that the xml and xmlorig msg are encslosed with a fndtMsg type as per the standard
			// FndtMsgPaymentType.newFndtMsg(xmlmetadata.getXml(), false/*bInspectDocumentRoot*/) ;
			// FndtMsgPaymentType.newFndtMsg(pdo.getXml(ORIG_XML_MSG_KEY), true/*bInspectDocumentRoot*/, true/*bExtractPmntAsIs*/, true
			// /*bReturnPmntSection*/) ;

			// if the pdo is not global, then there was a parsing error and therefore the status should be set to AUTHEX rather than RECEIVED
			// if there was a parsing error, set the create time stamp to the default office's time stamp
			if (!pdo.isGlobalPDO()) {
				pdo.set(P_CREATE_DT, NewASDateTimeUtils.getCurrentDateAndZoneByOffice(GlobalConstants.DEFAULT_SERVER_OFFICE_NAME).getDate());
				ErrorAuditUtils.setErrors(new ProcessError(ProcessErrorConstants.MessageStatusChanged, 
							new Object[] { pdo.getString(PDOConstantFieldsInterface.P_MSG_STS), MESSAGE_STATUS_AUTHEX }), pdo);
				pdo.set(PDOConstantFieldsInterface.P_MSG_STS, MESSAGE_STATUS_AUTHEX);
				pdo.set(PDOConstantFieldsInterface.P_OFFICE, GlobalConstants.DEFAULT_SERVER_OFFICE_NAME);
				pdo.set(P_DEPARTMENT, GlobalConstants.DEFAULT_SERVER_DEPARTMENT);
			}// EO if there was a parsing error

			// set the MID into the relational field for future reference
			pdo.set(PDOConstantFieldsInterface.P_MID, sMID);
			// set the msg type into the relational field for future reference
			pdo.set(PDOConstantFieldsInterface.P_MSG_TYPE, sPaymentTypeName);
			pdo.set(PDOConstantFieldsInterface.P_ORIG_MSG_TYPE, sPaymentTypeName);
			
			if (pdo.get(PDOConstantFieldsInterface.P_IS_HISTORY) == null)
			{
				if(isBPFlow)
				{
					pdo.set(PDOConstantFieldsInterface.P_IS_HISTORY, GlobalUtils.getPartitionIDByMID(sMID));
				}
				else
				{
					pdo.set(PDOConstantFieldsInterface.P_IS_HISTORY, 0);
				}
			}
		} catch (Exception e) {
			ExceptionController.getInstance().handleException(e, this);

			throw new IllegalArgumentException(e);
		}// EO catch block

		return pdo;
	}

	/**
     * 
     */
	@Override
	public PDO newPDO() {
		return newPDO(null);
	}

	/**
	 * returns an empty pdo, used for message creation
	 */
	@Override
	public PDO newPDO(List<String> listLoadMessageStep) {

		// generate the MID
		final String sMID = GlobalUtils.generateGUID();

		final Map<Object, PaymentFieldInterface> mapMappedData = new HashMap<Object, PaymentFieldInterface>();
		// create the PDO
		final PDO pdo = new PDO(sMID, mapMappedData, this, true);
		// set the function id to 1 (i.e. creation)
		pdo.setAdditionalData(MessageConstantsInterface.FIELD_VIRTUAL_FUNCTION_ID, ServerConstants.ONE_VALUE);
		PaymentType enumPaymentType = null;

		if (listLoadMessageStep == null)
			enumPaymentType = PaymentType.valueOf(PaymentType.PT_PACS_008);
		else {
			try {
				LoadMessageStep enumLoadMessageStep = null;

				for (String sStep : listLoadMessageStep) {
					enumLoadMessageStep = LoadMessageStep.valueOf(sStep);
					if ((enumPaymentType = enumLoadMessageStep.getAssociatedPaymentType()) != null)
						break;
				}// EO while there are more steps
			} catch (Exception e) {
				ExceptionController.getInstance().handleException(e, this);
				enumPaymentType = PaymentType.valueOf(PaymentType.PT_PACS_008);
			}// EO catch block

		}// EO else if there is a custmised payment type creation step

		try {
			// create an fndt msg from the payment type and pass it to the perform xml mapping
			final XmlObjectBase rootXml = FndtMsgPaymentType.newFndtMsg(enumPaymentType);
			// set the same root for both the orig and the updated so that fields could be mapped to the orig as well
			this.performXmlMapping(XmlLocationType.XML_MSG, mapMappedData, pdo, true, true, false/* merge context */, rootXml, null/* xml orig copy */);

		} catch (Exception e) {
			logger.error("Error occur on perform xml mapping with message:\n{}",e.toString());
			ExceptionController.getInstance().handleException(e, this);
		}// EO catch block

		pdo.set(PDOConstantFieldsInterface.P_MSG_TYPE, enumPaymentType.name());
		pdo.set(PDOConstantFieldsInterface.P_ORIG_MSG_TYPE, enumPaymentType.name());
		pdo.set(PDOConstantFieldsInterface.P_MSG_STS, "(RECEIVED)");
		pdo.set(PDOConstantFieldsInterface.P_MID, sMID);
		pdo.set(PDOConstantFieldsInterface.P_IS_HISTORY, 0);
		// set the "share xml document" service monitor flag flag.
		pdo.set(MF_INITIAL_CREATE, INITIAL_CREATE_MODE_ON);

		return pdo;
	}// EOM

	/**
	 * <P>
	 * <B>Pre-Conditions:</B>
	 * </P>
	 * <BR>
	 * 1. templatePDO must be in conjoined mode (i.e. only the XML_MSG xml doc instance is updated with the merge data.<BR>
	 * 2. oMergeFragment must be of the same Payment type as the XML_MSG xml as no conversion would be perrfomed. 3. oMergeFragment must be assoicated
	 * with a logical field so as to provide xpath to the merge intersection. 4. Location is XML_MSG 5. oMergeFragment - if not a Global Element (i.e.
	 * complex Type) must adhere to the following convention: * Root element must be replaced by 'xml-fragment' element * xml-fragment root element
	 * must contain the namespace of the target namespace of the root element it replaced * Example: Before: <urn:CdtTrfTxInf
	 * xmlns:urn="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.02"> <urn:PmtId> <urn:ClrSysRef>BOFAH10220000001</urn:ClrSysRef>
	 * <urn:InstrId>10808H11599L0667</urn:InstrId> <urn:EndToEndId>RTG_O_01</urn:EndToEndId> <urn:TxId>1</urn:TxId> </urn:PmtId> <urn:IntrBkSttlmAmt
	 * Ccy="INR">110000.00</urn:IntrBkSttlmAmt> <urn:IntrBkSttlmDt>2010-04-01</urn:IntrBkSttlmDt> <urn:SttlmPrty>NORM</urn:SttlmPrty> <urn:InstdAmt
	 * Ccy="INR">110000</urn:InstdAmt> <urn:ChrgBr>SHAR</urn:ChrgBr> </urn:CdtTrfTxInf>
	 * 
	 * After <xml-fragment xmlns:urn="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.02"> <urn:PmtId> <urn:ClrSysRef>BOFAH10220000001</urn:ClrSysRef>
	 * <urn:InstrId>10808H11599L0667</urn:InstrId> <urn:EndToEndId>RTG_O_01</urn:EndToEndId> <urn:TxId>1</urn:TxId> </urn:PmtId> <urn:IntrBkSttlmAmt
	 * Ccy="INR">110000.00</urn:IntrBkSttlmAmt> <urn:IntrBkSttlmDt>2010-04-01</urn:IntrBkSttlmDt> <urn:SttlmPrty>NORM</urn:SttlmPrty> <urn:InstdAmt
	 * Ccy="INR">110000</urn:InstdAmt> <urn:ChrgBr>SHAR</urn:ChrgBr> </xml-fragment>
	 * 
	 * @throws Throwable
	 */
	@Override
	public final PDO clonePDO(final CloningContext cloningContext, final Serializable oMergeFragment, final String sFragmentFieldLogicalID,
			final boolean bExtractFragmentFromDocSkelleton, List<LogicalFieldsXpath> listGroupsToParse) throws Throwable {
		// first clone the pdo using the default deep clone handler
		final PDOCloneHandlerInterface cloneHandler = ServiceLocator.getInstance().getNsetSpringBean(DefaultDeepPDOCloneHandler.class.getName(),
				DefaultDeepPDOCloneHandler.class);

		final PDO clonedPDO = cloneHandler.clone(cloningContext);

		// now renew the pdo's content so as to make it "new" again
		this.renewPDO(clonedPDO, cloningContext.getCreationMID(), 0/* (Active) iHistoryValue */);

		// If oMergeFragment was not null, merge the fragment into the cloned pdo
		if (oMergeFragment != null)
			this.fragmentMerge(clonedPDO, oMergeFragment, sFragmentFieldLogicalID, bExtractFragmentFromDocSkelleton, listGroupsToParse);

		return clonedPDO;
	}// EOM

	@Override
	public final PDO clonePDO(final String sSourceMID, final String sCreationMID, Integer historyValue) {

		PDO pdo = null;

		try {
			// retrieve the pdo from the distributed container.
			// Note: a mock pdo would be returned if none was found corresponding to the MID
			// Note: it is assumed that the pdo was retrieved from the distirbuted cache and therefore
			// is a clone and can be altered
			pdo = CacheKeys.ProcessPDOKey.getSingle(sSourceMID);

			// if the pdo was not empty (i.e. no pdo was found for MID),
			// remove the source pdo from the local cache and propegate to the distributed cache so as to release the lock
			// Note: as the source pdo was not modified set it to thin mode
			if (!pdo.isEmpty()) {
				pdo.setThinMode(true);
				CacheKeys.ProcessPDOKey.removeFromLocalAndPropagateToRemote(pdo);
			}// EO if the pdo was lodaded properly

			// tweak the pdo's propeties so as to convert it into a new representation
			//
			/*
			 * pdo.setModeType(PDOModeType.New) ; //reset the timestamp pdo.removePaymentField(P_TIME_STAMP) ;
			 * 
			 * //remove the create date field pdo.removePaymentField(P_CREATE_DT) ;
			 * 
			 * //set the pdo's status in the derived D_ORIG_CLONED_MSG_STS //to be referenced later. pdo.set(D_ORIG_CLONED_MSG_STS,
			 * pdo.getString(P_MSG_STS)) ;
			 * 
			 * //duplicate the mid to the P_TEMPLATE_MID field pdo.set(P_TEMPLATE_MID, pdo.getMID());
			 * 
			 * pdo.set(P_IS_HISTORY, historyValue != null ? historyValue : 0); pdo.setMID(sCreationMID == null ? GlobalUtils.generateGUID() :
			 * sCreationMID) ;
			 */

			this.renewPDO(pdo, sCreationMID, historyValue);

			// finally, cache the pdo locally
			CacheKeys.ProcessPDOKey.putSingle(pdo);
		} catch (Exception e) {
			ExceptionController.getInstance().handleException(e, this);
		}// EO catch block

		return pdo;
	}// EOM

	private final void renewPDO(final PDO pdo, final String sCreationMID, final Integer iHistoryValue) {

		// tweak the pdo's propeties so as to convert it into a new representation
		//
		pdo.setModeType(PDOModeType.New);
		// reset the timestamp
		pdo.removePaymentField(P_TIME_STAMP);

		// remove the create date field
		pdo.removePaymentField(P_CREATE_DT);

		// set the pdo's status in the derived D_ORIG_CLONED_MSG_STS
		// to be referenced later.
		pdo.set(D_ORIG_CLONED_MSG_STS, pdo.getString(P_MSG_STS));

		// duplicate the mid to the P_TEMPLATE_MID field
		pdo.set(P_TEMPLATE_MID, pdo.getMID());

		pdo.set(P_IS_HISTORY, iHistoryValue != null ? iHistoryValue : 0);
		pdo.setMID(sCreationMID == null ? GlobalUtils.generateGUID() : sCreationMID);

	}// EOM

	@Override
	public final PDO load(final String sMID) {

		final long lBefore = System.nanoTime();

		PDO pdo = null;
		ProcessError processError = null;

		try {
			// create a connection to use in the relational load and the xml extraction
			final Map mapPaymentData = new HashMap<Object, PaymentFieldInterface>();

			// create the PDO
			pdo = new PDO(sMID, mapPaymentData, this, false);

			// perform the load from persistence from the active table partition (optimistic approach)
			// this load shall include relational column as well
			// as xml mappings as the xml is a column
			final boolean bExistsInPersistence = this.performLoadFromPersistence(sMID, null, mapPaymentData, pdo, ACTIVE_MINF_PARTITION_ID);

			// if the bExistsInPersistence is false, modify the isNew to true to indicate that the PDO was in fact an empty shell
			if (!bExistsInPersistence) {
				ErrorAuditUtils.setErrors(new ProcessError(ProcessErrorConstants.MessageStatusChanged, 
						new Object[] { pdo.getString(PDOConstantFieldsInterface.P_MSG_STS), MESSAGE_STATUS_AUTHEX }), pdo);
				pdo.set(P_MSG_STS, MESSAGE_STATUS_AUTHEX);
				processError = new ProcessError(ProcessErrorConstants.PDONoMinfRecord, sMID);
			}// EO if the pdo was not found in persistence
			else {// set X_CRE_DT_TM from P_CREATE_DT
				if (pdo.get(X_CRE_DT_TM) == null) {
					pdo.set(X_CRE_DT_TM, pdo.get(P_CREATE_DT));
				}

			}
			// invoke the message referenced types refresh
			// NYI

		} catch (Exception e) {
			pdo = new PDO(sMID, new HashMap<Object, PaymentFieldInterface>(), this, true/* bIsNew */);

			ExceptionController.trace(e, this);
			processError = new ProcessError(ProcessErrorConstants.PdoLoadFailure);
		} finally {

			if (processError != null) {
				pdo.setModeType(PDOModeType.New);
				pdo.setIsGlobalPDO(false);
				pdo.setMID(sMID);

				// as an error and configure so as to not persist the pdo
				ErrorAuditUtils.setErrors(processError, pdo);
				// set the D_SKIP_PERSIST_ON_ERROR to true so as to skip persistence
				pdo.set(D_SKIP_PERSIST_ON_ERROR, true);
			}// EO if there was a load error

			logger.debug("mid = {}, conjoined mode = {}, load time {} ms", new Object[] {sMID, pdo.isConjoined(),
					((System.nanoTime() - lBefore) / GlobalConstants.NANOS_TO_MS_DIVIDER)});

		}// EO catch block

		return pdo;
	}// EOM

	/**
	 * 
	 * Jul 9, 2009 Guys <br>
	 * <br>
	 * Provides an interface to load the pdo using an externally controlled DB query and connection.<br>
	 * Useful for scenarios where a partial MINF dataset is required as well as multiple sequential loads.
	 * 
	 * @See perform full calculations for an example
	 * 
	 * @param resultSet
	 *            JDBC resultset positioned on the recrord to load the PDO from.<br>
	 *            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Must Contain the {@link PDOConstantFieldsInterface#P_MID} column</b>
	 * @return {@link PDO}. If a failure had occured during the load procedure, an empty PDO would be returned
	 */
	@Override
	public final PDO load(final ResultSet resultSet) {

		PDO pdo = null;

		try {
			// create a connection to use in the relational load and the xml extraction
			final Map mapPaymentData = new HashMap<Object, PaymentFieldInterface>();

			// retrieve the MID from the result set
			final String sMID = resultSet.getString(PDOConstantFieldsInterface.P_MID);

			// create the PDO
			pdo = new PDO(sMID, mapPaymentData, this, false);

			// perform the load from persistence
			// this load shall include relational column as well
			// as xml mappings as the xml is a column
			this.performRelationalMapping(resultSet, mapPaymentData, pdo);

		} catch (Exception e) {
			ExceptionController.getInstance().handleException(e, this);
		}// EO catch block

		return pdo;
	}// EOM

	@Override
	public final PDO merge(final PDO pdo, final Object oInput) throws Exception {

		// ensure that the pdo is not in new context as otherwise, all non existent extension
		// fields would be overriden with placeholders
		final PDOModeType currentPDOModeType = pdo.setModeType(PDOModeType.Normal);

		// [0] - should derive orig fields from given xml
		// [1] - should perform xml mapping
		final boolean bConjoinedMode = pdo.isConjoined();
		final boolean[] arrShouldParseAndDeriveOrigFields = XmlLocationType.XML_MSG.shouldPerformXmlMapping(pdo, bConjoinedMode);

		this.performXmlMapping(XmlLocationType.XML_MSG, pdo.getDataMap(), pdo, arrShouldParseAndDeriveOrigFields[0]/* bDeriveOrigFields */,
				bConjoinedMode, true/* merge context */, oInput, null/* xml orig copy */);
		// restore the prior context
		pdo.setModeType(currentPDOModeType);

		// if the current pdo is in conjoined mode and the current xml msg had changed ,
		// set the dirty flag on the orig xml message xml as it is the same reference as the former
		if (bConjoinedMode && pdo.hadXmlChanged(CURRENT_XML_MSG_KEY))
			pdo.getXmlMetadata(ORIG_XML_MSG_KEY).setChanged();

		return pdo;
	}// EOM

	/**
	 * 
	 * Dec 1, 2010 Guys
	 * 
	 * <P>
	 * <B>Pre-Conditions:</B>
	 * </P>
	 * <BR>
	 * 1. PDO must be in conjoined mode (i.e. only the XML_MSG xml doc instance is updated with the merge data.<BR>
	 * 2. oInput must be of the same Payment type as the XML_MSG xml as no conversion would be perrfomed. 3. oInput must be assoicated with a logical
	 * field so as to provide xpath to the merge intersection. 4. Location is XML_MSG 5. oInput - if not a Global Element (i.e. complex Type) must
	 * adhere to the following convention: * Root element must be replaced by 'xml-fragment' element * xml-fragment root element must contain the
	 * namespace of the target namespace of the root element it replaced * Example: Before: <urn:CdtTrfTxInf
	 * xmlns:urn="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.02"> <urn:PmtId> <urn:ClrSysRef>BOFAH10220000001</urn:ClrSysRef>
	 * <urn:InstrId>10808H11599L0667</urn:InstrId> <urn:EndToEndId>RTG_O_01</urn:EndToEndId> <urn:TxId>1</urn:TxId> </urn:PmtId> <urn:IntrBkSttlmAmt
	 * Ccy="INR">110000.00</urn:IntrBkSttlmAmt> <urn:IntrBkSttlmDt>2010-04-01</urn:IntrBkSttlmDt> <urn:SttlmPrty>NORM</urn:SttlmPrty> <urn:InstdAmt
	 * Ccy="INR">110000</urn:InstdAmt> <urn:ChrgBr>SHAR</urn:ChrgBr> </urn:CdtTrfTxInf>
	 * 
	 * After <xml-fragment xmlns:urn="urn:iso:std:iso:20022:tech:xsd:pacs.008.001.02"> <urn:PmtId> <urn:ClrSysRef>BOFAH10220000001</urn:ClrSysRef>
	 * <urn:InstrId>10808H11599L0667</urn:InstrId> <urn:EndToEndId>RTG_O_01</urn:EndToEndId> <urn:TxId>1</urn:TxId> </urn:PmtId> <urn:IntrBkSttlmAmt
	 * Ccy="INR">110000.00</urn:IntrBkSttlmAmt> <urn:IntrBkSttlmDt>2010-04-01</urn:IntrBkSttlmDt> <urn:SttlmPrty>NORM</urn:SttlmPrty> <urn:InstdAmt
	 * Ccy="INR">110000</urn:InstdAmt> <urn:ChrgBr>SHAR</urn:ChrgBr> </xml-fragment>
	 * 
	 * @throws Throwable
	 */
	public final void fragmentMerge(final PDO pdo, final Object oInput, final String sFragmentLogicalFieldId,
			final boolean bExtractFragmentFromDocSkelleton, List<LogicalFieldsXpath> listGroupsToParse) throws Throwable {

		// if the pdo is not in conjoined mode raise an error
		final String sExceptionMsgPrefix = "[DAS.fragmentMerge(PDO - '%s')]: ";
		if (!pdo.isConjoined())
			throw new IllegalArgumentException(sExceptionMsgPrefix + " PDO must be in conjoined mode!");
		// else

		final String sXmlLocation = CURRENT_XML_KEY;
		final XmlLocationType enumXmlLocation = XmlLocationType.XML_MSG;

		// ensure that the pdo is not in new context as otherwise, all non existent extension
		// fields would be overriden with placeholders
		final PDOModeType currentPDOModeType = pdo.setModeType(PDOModeType.Normal);
		final XmlMetadata xmlMsgMetadata = pdo.getXmlMetadata(sXmlLocation);
		try {

			final PaymentType enumCurXmlPaymentType = xmlMsgMetadata.getPaymentType();
			// rertieve the sFragmentLogicalFieldId xpath metadata for the current payment type
			// Note: no need to null guard the map as the pdo is already parsed due to the fact that the logical fields
			// were defined for the enumCurXmlPaymentType
			final Map<String, LogicalFieldsXpath> mapPaymentTypeLogicalFieldsXpath = CacheKeys.LogicalFieldsXPathKey.getSingle(enumCurXmlPaymentType);

			final LogicalFieldsXpath fragmentLogicalFieldXpath = mapPaymentTypeLogicalFieldsXpath.get(sFragmentLogicalFieldId);
			if (fragmentLogicalFieldXpath == null)
				throw new IllegalArgumentException(String.format("%s FragmentLogical Field Id '%s' was undefined for current xml payment type '%s'",
						sExceptionMsgPrefix, sFragmentLogicalFieldId, enumCurXmlPaymentType));

			// merge the fragment input into the current root document
			final XmlObjectBase xmlmsgRoot = xmlMsgMetadata.getXml();

			final XmlObjectBase mergePointXbean = this.getOrCreateXmlNode(fragmentLogicalFieldXpath, xmlmsgRoot,
					enumCurXmlPaymentType.getSchemaNamespace(), false/* bIsMember */);

			final boolean bExistingFragmentHasChildren = mergePointXbean.getDomNode().hasChildNodes();

			// now merge the current fragement into the node
			XmlObjectBase fragmentXbean = PaymentInputSourceType.toXbean(oInput, null, enumXmlLocation, false/* bToDocumentFirstChild */);
			// if the bExtractFragmentFromDocSkelleton is true, execute the xpath to retrieve the actual fragment node
			if (bExtractFragmentFromDocSkelleton) {
				String xpath = fragmentLogicalFieldXpath.getFieldPath();
				
				if (fragmentXbean instanceof FndtMsgDocumentImpl) //ugly work around which dosen't deal with the additional path derived from the fndt msg parts
					xpath = "/"+xpath;
				
				final XmlObject[] arrXpathResults = fragmentXbean.selectPath(enumCurXmlPaymentType.getXpathlNamespaceCaluse() + xpath);
				if (arrXpathResults.length == 0)
					throw new IllegalArgumentException(String.format(
							"%s FragmentLogical Field Id '%s' with tag name '%s' and field path '%s' was not found in document skelleton %s",
							sExceptionMsgPrefix, sFragmentLogicalFieldId, fragmentLogicalFieldXpath.getTagName(),
							fragmentLogicalFieldXpath.getFieldPath(), fragmentXbean));

				// else replace the fragment (in fact the document skelleton) with the actual fragement
				fragmentXbean = (XmlObjectBase) arrXpathResults[0];

			}// EO if bExtractFragmentFromDocSkelleton
			mergePointXbean.set(fragmentXbean);

			final Map<Object, PaymentFieldInterface> mapData = pdo.getDataMap();

			// if the listGroupsToParse were not provided, use the fragment logical field as the parsing base
			if (listGroupsToParse == null)
				listGroupsToParse = Arrays.asList(fragmentLogicalFieldXpath);

			// Invoke the performXmlMapping passing a customized list of just the fragment group xpath metadata and the mergepoint as the root
			this.performXmlMapping(enumXmlLocation, enumCurXmlPaymentType, xmlmsgRoot, mapData, pdo, true/* bDeriveOrigFields */,
					true/* bConjoinedMode */, true/* bMergeContext */, listGroupsToParse);

			// Finally, if the previous mergePointXbean has children iterate over pdo's data map and remove all orphaned xml payment fields
			if (bExistingFragmentHasChildren) {

				try {
					final Iterator<PaymentFieldInterface> iterator = mapData.values().iterator();
					PaymentFieldInterface paymentField = null;

					while (iterator.hasNext()) {

						paymentField = iterator.next();
						if (!(paymentField instanceof XmlPaymentField))
							continue;

						if (!paymentField.shouldSerialize())
							iterator.remove();
					}// EO while there are more payment fields

				} catch (Throwable e) {
					ExceptionController.getInstance().handleException(e, this);
				}// EO catch block

				// now retrieve all groups

			}// EO if there are child node (i.e. need to prune the pdo payment fields first

		} finally {
			// restore the prior context
			pdo.setModeType(currentPDOModeType);

			// flag the content as dirty
			xmlMsgMetadata.setChanged();
			pdo.getXmlMetadata(ORIG_XML_MSG_KEY).setChanged();
		}// EO catch block

	}// EOM

	@Override
	public void save(final boolean bRemovePDOFromCache, PDO... pdoList) throws Throwable {

		final UserTransaction[] arrUserTransaction = new UserTransaction[1];

		Feedback feedback = BOBasic.startTransaction(arrUserTransaction);
		if (!feedback.isSuccessful())
			throw new TransactionException(feedback.toString());

		boolean bShouldCommitTx = true;
		try {
			batchSave(bRemovePDOFromCache, pdoList);
		} catch (Throwable e) {
			ExceptionController.getInstance().handleException(e, this);

			// set the bShouldCommitTx to false so that the transaction would be rolled back
			bShouldCommitTx = false;
			// must be thrown so as to provide the client code with the option to rollback
			throw e;
		} finally {

			// commit transaction
			feedback = BOBasic.endTransaction(arrUserTransaction[0], bShouldCommitTx);
			// if the tx had failed, throw an exception
			if (!feedback.isSuccessful())
				throw new TransactionException(feedback.toString());

		}// EO catch block

	}// EOM

	@Override
	public final void deletePayments(PDO... arrPDOs) throws Throwable {

		Connection conn = null;
		PreparedStatement minfPs = null;
		PreparedStatement mFamilyPs = null;

		try {
			conn = m_dao.getConnection();
			for (PDO pdo : arrPDOs) {
				String mid = pdo.getMID();
				Integer iIsHistoryValue = pdo.getIsHistory();
				minfPs = prepareMinfDeleteStatement(conn, minfPs, pdo.getMID(), iIsHistoryValue);
				if (minfPs != null)
					minfPs.addBatch();

				// The minf delete trigger deletes only the entries where mfamily.p_mid = ?, therefore,
				// added delete statement to delete entries where related_mid = ?
				// mFamilyPs = prepareMFamilyDeleteStatement(conn, mFamilyPs, mid);
				// if (mFamilyPs != null) mFamilyPs.addBatch();
			}

			minfPs.executeBatch();
			// mFamilyPs.executeBatch();
		} finally {
			// m_dao.releaseResources(conn, minfPs, mFamilyPs) ;
			m_dao.releaseResources(conn, minfPs);
		}

	}

	private PreparedStatement prepareMinfDeleteStatement(Connection conn, PreparedStatement ps, String mid, Integer partitionID) throws Exception {
		if (ps == null)
			ps = conn.prepareStatement(MINF_DELETE_STATEMENT);

		ps.setObject(1, mid);
		ps.setObject(2, partitionID);
    	return ps;
	}

    /*private PreparedStatement prepareFileSummaryUpdateStatement(Connection conn, PreparedStatement ps, PDO pdo) throws Exception
    {
    	if (pdo.getInteger("D_CHUNK_ID_LIST_SIZE")!=null){
    		int numOfChunks = pdo.getInteger("D_CHUNK_ID_LIST_SIZE");
    		String internalFileId = pdo.getString(PDOConstantFieldsInterface.P_IN_INTERNAL_FILEID);
        	if (ps == null) ps = conn.prepareStatement(FILE_SUMMARY_UPDATE_NUM_OF_COMPLETED_CHUNKS);
        	GlobalUtils.setObject(ps, 1, numOfChunks, Types.NUMERIC);
        	GlobalUtils.setObject(ps, 2, internalFileId, Types.VARCHAR);
        	ps.addBatch();
    	}
    	return ps;
    }*/

	private PreparedStatement prepareMFamilyDeleteStatement(Connection conn, PreparedStatement ps, String mid) throws Exception {
		if (ps == null)
			ps = conn.prepareStatement(MFAMILY_DELETE_STATEMENT);

		ps.setObject(1, mid);

		return ps;
	}

	@Override
	public final void batchSave(final boolean bRemovePDOFromCache, PDO... arrPDOs) throws Throwable {
		this.batchSave(bRemovePDOFromCache, (Comparator<PDO>) null/* pdoListSorter */,m_defaultPDOStateHandler,true, arrPDOs);
	}// EOM

	@Override
	public final void batchSave(final boolean bRemovePDOFromCache, final Comparator<PDO> pdoListSorter,PDOStateHandlerInterface pdoStateHandler,final boolean saveRelatedPdo, PDO... arrPDOs) throws Throwable {
		if (arrPDOs == null)
			return;
		
		final String TRACE_NUMBER_OF_PDOs = "Initial number of PDOs to save: {}, Final number of PDOs to save after adding linked PDOs: {}.";
		final String TRACE_CURRENT_SAVED_MID = "Current saved MID: {}.";

		// if the CONTEXT_ORCHESTRATION_IND flag was set in the admin's session, skip the save as the save would be
		// perform on the last step
		if (GlobalUtils.isTrue(Admin.getContextAdmin().getSessionData(Admin.CONTEXT_ORCHESTRATION_IND))) {
			logger.info("[DAS.batchSave]: save is aborted as in orchestration context. Save would be perfomed on the last orchestration step.");

			return;
		}// EO if in the context of orchstration

		Connection conn = null;
		PreparedStatement pdoInsertStatement = null;
		PreparedStatement msgErrorBatchStatement = null;
		PreparedStatement externalErrorMessagesBatchStatement = null;
		PreparedStatement msgFeesDeleteStatement = null, msgFeesBatchStatement = null;
		PreparedStatement msgRuleLogBatchStatement = null;
		PreparedStatement messageRatesDeleteStatement = null, messageRatesBatchStatement = null;
		PreparedStatement stopFlagsDeleteStatement = null, stopFlagsInsertBatchStatement = null;
		PreparedStatement pdoUpdateStatement = null;
//		PreparedStatement paymentAttachmentsInsertStatement = null, paymentAttachmentsDeleteStatement = null;
		PreparedStatement msgPartiesDeleteStatement = null, msgPartiesBatchStatement = null;
		PreparedStatement dynamicPartyLimitDeleteStatement = null, dynamicPartyLimitBatchStatement = null;
//		PreparedStatement fileSummaryUpdateStatement=null;

		PreparedStatement[] msgNotesInsertAndUpdateStArr = null, msgSpecialInstInsertAndUpdateStArr = null, mFamilyInsertAndUpdateStArr = null, batchSubsetInsertAndUpdateStArr = null, arrAuditTrailStatements = null, messageExternalInteractionStArr = null, templateUnchangedFieldsPsArr = null, cycleSettlementInsertAndUpdateArr = null;

		final ArrayList<String> dupexKeyList = new ArrayList<String>() ; 
		final List<PDO> pdoList = new ArrayList<PDO>();
		try {

			// final long lBEFORE_LINKS = System.nanoTime() ;

			// add all related PDOs to a list to iterate over
			for (PDO pdo : arrPDOs) {
				// this add linked msgs would add 'this' pdo to the list as well
				if (!pdo.isTransient()){
					if (saveRelatedPdo){
						pdo.addLinkedMsgsToList(pdoList);	
					}
					else{ //support saving only the pdo sent in the original array of PDOs
						pdoList.add(pdo);
					}
				}
					
			}// EO while there are more pdos

			// if the pdoListSorter was provided, sort the list
			// @See BoMessageHandler.submitMessageService for mid base sorting required to avoid dead locks
			if (pdoListSorter != null)
				Collections.sort(pdoList, pdoListSorter);

			// System.out.println("DAS SAVE links --> " + ((float)(System.nanoTime()-lBEFORE_LINKS)/GlobalConstants.NANOS_TO_MS_DIVIDER));

			logger.debug(TRACE_NUMBER_OF_PDOs, arrPDOs.length, pdoList.size());

			conn = m_dao.getConnection();

			if (GlobalUtils.isNullOrEmpty(m_minfInsertQuery))
				createMinfInsertQueryAndCoumnNames(conn);

			// final long lBEFORE_PREPARE_MINF_INSERT = System.nanoTime() ;

			// System.out.println("DAS SAVE pdo insert prepared statement --> " +
			// ((float)(System.nanoTime()-lBEFORE_PREPARE_MINF_INSERT)/GlobalConstants.NANOS_TO_MS_DIVIDER));

			String sMID = null, sLastSaveTimestamp = null, sOffice = null;
			int iPartitionID = 0;
			int iRowCount = 0;
			Boolean bNoModificationsDetected = null;
			// final long lBEFORE_GET_SYSTIME = System.nanoTime() ;

			// generate the update/insert timestamp as well as the miliis timestamp used later in the various batch insertions
			final String[] arrTimeStampResources = m_dao.getFormattedSysTimeAndTimeStampFromDB();
			final String sPersistenceTimestamp = arrTimeStampResources[0];
			final long lDBTimestampMillis = Long.parseLong(arrTimeStampResources[1]);

			// System.out.println("DAS SAVE pdo get db sys time --> " +
			// ((float)(System.nanoTime()-lBEFORE_GET_SYSTIME)/GlobalConstants.NANOS_TO_MS_DIVIDER));
			Newjournal userModifiedFieldsEntry = null;

			for (PDO pdo : pdoList) {

				if (pdo.isTransient())
					continue;

				sMID = pdo.getMID();
				iPartitionID = pdo.getIsHistory();
				 /**check  if the current status is appeared in NON_STP value list*/
							 boolean isInValueList = CacheKeys.listValuesKey.getSingle(pdo.getString(P_OFFICE),P_NON_STP_FLAG,pdo.getStatus()) != null;
			  	  String NonStpFlag=pdo.getString("P_NON_STP_FLAG");
			  	  //in case  non stpFlag got value 1 than this value shouldn't change.
						if (isInValueList) {
							if (NonStpFlag == null || NonStpFlag.equals("0")) {
								pdo.set("P_NON_STP_FLAG", 1);
							}

						} else {
							if (NonStpFlag == null) {
								pdo.set("P_NON_STP_FLAG", 0);
							}

						}

				// FOR DEBUG
				// if(sMID.equals("10704C2558E0312")) pdo.set("P_CLEARING_CUTOFF_TM", new Date()) ;
				// if(pdo.getMID().equals("10616C3416CF2413")) throw new RuntimeException("DEBUG EXCEPTION IN SAVE") ;
				// FOR DEBUG

				logger.info(TRACE_CURRENT_SAVED_MID, sMID);

				userModifiedFieldsEntry = pdo.getUserModifiedFieldsNEWJOURNALEntry(false/* do not create if not yet instantiated */);

				// final long lBEFORE_prepareAuditTrail = System.nanoTime() ;
				// NEWJOURNAL, (audit trail).

                arrAuditTrailStatements = this.prepareAuditTrailBatchStatement(conn, arrAuditTrailStatements, pdo, lDBTimestampMillis) ;

				// System.out.println("DAS SAVE prepareAuditTrailBatchStatement --> " +
				// ((float)(System.nanoTime()-lBEFORE_prepareAuditTrail)/GlobalConstants.NANOS_TO_MS_DIVIDER));
				// final long lBEFORE_MsgError = System.nanoTime() ;

				// MSGERR.
				msgErrorBatchStatement = this.prepareMsgErrorBatchStatement(conn, msgErrorBatchStatement, pdo, lDBTimestampMillis);
				
                //fileSummaryUpdateStatement = prepareFileSummaryUpdateStatement(conn, fileSummaryUpdateStatement, pdo);
				
				externalErrorMessagesBatchStatement=this.prepareExternalMessageBatchStatement(conn, externalErrorMessagesBatchStatement, pdo);

				// System.out.println("DAS SAVE prepareMsgErrorBatchStatement --> " +
				// ((float)(System.nanoTime()-lBEFORE_MsgError)/GlobalConstants.NANOS_TO_MS_DIVIDER));
				// final long lBEFORE_pecialInstructionsBatchStatement= System.nanoTime() ;

				// MSG_SPECIAL_INSTRUCTIONS.
				msgSpecialInstInsertAndUpdateStArr = this.prepareMsgSpecialInstructionsBatchStatement(conn, msgSpecialInstInsertAndUpdateStArr, pdo,
						sPersistenceTimestamp, lDBTimestampMillis);

				// System.out.println("DAS SAVE prepareMsgSpecialInstructionsBatchStatement --> " +
				// ((float)(System.nanoTime()-lBEFORE_pecialInstructionsBatchStatement)/GlobalConstants.NANOS_TO_MS_DIVIDER));
				// final long lBEFORE_prepareMsgRuleLogBatchStatement= System.nanoTime() ;

				// MSG_RULE_LOG.
				msgRuleLogBatchStatement = this.prepareMsgRuleLogBatchStatement(conn, msgRuleLogBatchStatement, pdo, sPersistenceTimestamp);

				// System.out.println("DAS SAVE prepareMsgRuleLogBatchStatement --> " +
				// ((float)(System.nanoTime()-lBEFORE_prepareMsgRuleLogBatchStatement)/GlobalConstants.NANOS_TO_MS_DIVIDER));
				// final long lBEFORE_fees= System.nanoTime() ;

				// MemoPost Entries store
				if(pdo.getMemoPostEntries() != null && pdo.getMemoPostEntries().size() > 0){
					//daoMemoPost.deleteMemoPostEntries(pdo.getMID()); // For case payment failed to REPAIR. Not relevant for now.
					daoMemoPost.insertMemoPostEntries(pdo.getMemoPostEntries(),pdo.getMemoPostRequests(), pdo.getIsHistory());
				}
				
				// MSG_FEES; skips if there were no table modifications.
				if ((userModifiedFieldsEntry == null && pdo.getListMSG_FEES() != null && pdo.getListMSG_FEES().size() > 0)
						|| (userModifiedFieldsEntry != null && this.isRelatedTableDirty(PDOConstantFieldsInterface.M_MSG_FEES_LINE,
								userModifiedFieldsEntry)) || pdo.getAdditionalData(PDOConstantFieldsInterface.M_MSG_FEES_LINE) != null) {

					// delete the msg fees for mid first

					if (!pdo.isNew() ) {// this is a temporary workaround where we do not want "&& !REJECTION_FLOW.equals(pdo.getString(D_FLOW_CONTEXT))"
						if (msgFeesDeleteStatement == null)
							msgFeesDeleteStatement = conn.prepareStatement(MSG_FEES_DELETE_STATEMENT);
						setObject(msgFeesDeleteStatement, 1, sMID);
						setObject(msgFeesDeleteStatement, 2, iPartitionID);
						msgFeesDeleteStatement.addBatch();
					}// EO if the pdo was not new and the msgFeesDeleteStatement was not already initialized

					msgFeesBatchStatement = this.prepareMsgFeesBatchStatement(conn, msgFeesBatchStatement, pdo);
					pdo.removeAdditionalData(PDOConstantFieldsInterface.M_MSG_FEES_LINE);

				}// EO if the message fees table was modified

				// MSG_PARTIES
				if (!pdo.isNew() && pdo.msgPartiesWasCalc()) {
					if (msgPartiesDeleteStatement == null)
						msgPartiesDeleteStatement = conn.prepareStatement(MSG_PARTIES_DELETE_STATEMENT);
					setObject(msgPartiesDeleteStatement, 1, sMID);
					setObject(msgPartiesDeleteStatement, 2, iPartitionID);
					msgPartiesDeleteStatement.addBatch();
					pdo.setMsgPartiesWasCalc(false); // For a pdo re-use 
				}// EO if the pdo was not new and the msgPartiesDeleteStatement was not already initialized

				msgPartiesBatchStatement = this.prepareMsgPartiesBatchStatement(conn, msgPartiesBatchStatement, pdo);
				// EO MSG_PARTIES update

				// DYNAMIC_PARTY_LIMIT
				if ( pdo.shouldDeletePartyLimitOutgoingByStatus() ){
					if (dynamicPartyLimitDeleteStatement == null)
						dynamicPartyLimitDeleteStatement = conn.prepareStatement(DYNAMIC_PARTY_LIMIT_DELETE_STATEMENT);

					setObject(dynamicPartyLimitDeleteStatement, 1, sMID);
					setObject(dynamicPartyLimitDeleteStatement, 2, pdo.getIsHistory());
					dynamicPartyLimitDeleteStatement.addBatch();

					// Already accumulated monitor
					String monitor = pdo.getString(PDOConstantFieldsInterface.MU_PARTY_LIMIT_ACCUMULATED);
					pdo.set(PDOConstantFieldsInterface.MU_PARTY_LIMIT_ACCUMULATED, BOPartyLimit.newMonitorValueAfterDeleteOutgoingAccumulation(monitor));
					logger.info("Party limit will not be accumulated, since P_MSG_STS is {}.", pdo.getString(PDOConstantFieldsInterface.P_MSG_STS));

				}
				// Add party limit by need. (Add only if doesn't need to delete or stoped by LIMIT_WAIT)
				else {
					dynamicPartyLimitBatchStatement = this.prepareDynamicPartyLimitBatchStatement(conn, dynamicPartyLimitBatchStatement, pdo);
				
					// Already accumulated monitor
					if (pdo.shouldAccumulatePartyLimitOutgoingByStatus()){
						String monitor = pdo.getString(PDOConstantFieldsInterface.MU_PARTY_LIMIT_ACCUMULATED);
						pdo.set(PDOConstantFieldsInterface.MU_PARTY_LIMIT_ACCUMULATED, BOPartyLimit.newMonitorValueAfterAccumulateOutgoing(monitor));
					}
					logger.info("Party Limit accumulation is saved.");
				}
				// Message is going to WAIT_LIMIT
				if (MessageConstantsInterface.MESSAGE_STATUS_WAIT_LIMIT.equals(pdo.getString(PDOConstantFieldsInterface.P_MSG_STS))){
					// Already accumulated monitor
					String monitor = pdo.getString(PDOConstantFieldsInterface.MU_PARTY_LIMIT_ACCUMULATED);
					pdo.set(PDOConstantFieldsInterface.MU_PARTY_LIMIT_ACCUMULATED, MessageConstantsInterface.MONITOR_FLAG_X);
					logger.info("Message status is WAIT_LIMIT. Existing Party Limit accumulation is removed.");
				}
			
				//  EO DYNAMIC_PARTY_LIMIT UPDATE
				
				
				// System.out.println("DAS SAVE lBEFORE_fees --> " + ((float)(System.nanoTime()-lBEFORE_fees)/GlobalConstants.NANOS_TO_MS_DIVIDER));
				// final long lBEFORE_prepareBatchSubsetInsertStatement= System.nanoTime() ;

				// BATCH_SUBSET.
				if (pdo.getBatchSubset() != null) {
					batchSubsetInsertAndUpdateStArr = this.prepareBatchSubsetInsertStatement(conn, batchSubsetInsertAndUpdateStArr, pdo,
							sPersistenceTimestamp);
				}// EO if the batch sucset was not null

				// System.out.println("DAS SAVE prepareBatchSubsetInsertStatement --> " +
				// ((float)(System.nanoTime()-lBEFORE_prepareBatchSubsetInsertStatement)/GlobalConstants.NANOS_TO_MS_DIVIDER));
				// final long lBEFORE_pouplateMsgnotesInsertBatch= System.nanoTime() ;

				// MSG NOTES

				if (!GlobalUtils.isListNullOrEmpty(pdo.getListMSGNOTES()))
					msgNotesInsertAndUpdateStArr = this.pouplateMsgnotesInsertBatch(conn, msgNotesInsertAndUpdateStArr, pdo, lDBTimestampMillis);

				// System.out.println("DAS SAVE pouplateMsgnotesInsertBatch --> " +
				// ((float)(System.nanoTime()-lBEFORE_pouplateMsgnotesInsertBatch)/GlobalConstants.NANOS_TO_MS_DIVIDER));
				// final long lBEFORE_prepareMfamilyInsertStatement= System.nanoTime() ;

				// MFAMILY.
				if (pdo.getListMFAMILY() != null ) {
					if(!isFromMP_ERRORStatus(pdo))
					{
						mFamilyInsertAndUpdateStArr = this.prepareMfamilyInsertStatement(conn, mFamilyInsertAndUpdateStArr, pdo);
					}
				}// EO if the mfamily was not null

				// System.out.println("DAS SAVE prepareMfamilyInsertStatement --> " +
				// ((float)(System.nanoTime()-lBEFORE_prepareMfamilyInsertStatement)/GlobalConstants.NANOS_TO_MS_DIVIDER));
				// final long lBEFORE_msgRates= System.nanoTime() ;

				// MESSAGERATES; skips if there were no table modifications.
				if ((userModifiedFieldsEntry == null && pdo.getListMESSAGERATES() != null && pdo.getListMESSAGERATES().size() > 0)
						|| (userModifiedFieldsEntry != null && this
								.isRelatedTableDirty(PDOConstantFieldsInterface.M_FC_LINE, userModifiedFieldsEntry))) {
					// Deletes existing records; both CR & DR records.
					if (messageRatesDeleteStatement == null)
						messageRatesDeleteStatement = conn.prepareStatement(MSG_RATES_DELETE_STATEMENT);

					setObject(messageRatesDeleteStatement, 1, sMID);
					setObject(messageRatesDeleteStatement, 2, iPartitionID);
					messageRatesDeleteStatement.addBatch();

					// In case the P_FC_INFO_IND value is different then 'R', (i.e. RTR), then sets its value to null.
					// It will be set to 'M' in the ahead 'prepareMessageRatesBatchStatement' method.
					String sP_FC_INFO_IND = pdo.getString(P_FC_INFO_IND);
					if (!BOCurrencyConversion.FC_INFO_IND_RTR.equals(sP_FC_INFO_IND))
						pdo.set(P_FC_INFO_IND, (String) null);

					// Prepares the new insert batch statement for both CR & DR records & executes it.
					messageRatesBatchStatement = this.prepareMessageRatesBatchStatement(conn, messageRatesBatchStatement, pdo);
				}// EO if the message rates table was modified

				// System.out.println("DAS SAVE msg rates --> " + ((float)(System.nanoTime()-lBEFORE_msgRates)/GlobalConstants.NANOS_TO_MS_DIVIDER));
				// final long lBEFORE_prepareMsgStopFlagsInsertBatchStatement= System.nanoTime() ;

				// MSG_STOP_FLAGS.
				if (!isListNullOrEmpty(pdo.getListMSG_STOP_FLAGS())) {
					// INSERT statement.
					stopFlagsInsertBatchStatement = this.prepareMsgStopFlagsInsertBatchStatement(conn, stopFlagsInsertBatchStatement, pdo);

					// DELETE statement.
					if (stopFlagsDeleteStatement == null) {
						stopFlagsDeleteStatement = conn.prepareStatement(MSG_STOP_FLAGS_DELETE_STATEMENT);

						setObject(stopFlagsDeleteStatement, 1, sMID);
						setObject(stopFlagsDeleteStatement, 2, iPartitionID);
						stopFlagsDeleteStatement.addBatch();
					}// EO if the stopFlagsDeleteStatement was not yet initialized
				}

				// MESSAGE_EXTERNAL_INERACTION
				if (pdo.getMapMESSAGE_EXTERNAL_INTERACTION() != null) {
					messageExternalInteractionStArr = prepareMessageExternalInteraction(conn, messageExternalInteractionStArr, sPersistenceTimestamp,
							pdo);
				}
				// Template Unchanged Fields
				templateUnchangedFieldsPsArr = prepareTemplateUnchangedFields(conn, templateUnchangedFieldsPsArr, pdo);

				cycleSettlementInsertAndUpdateArr = prepareCycleSettlementBatchStatement(conn, cycleSettlementInsertAndUpdateArr, pdo,
						sPersistenceTimestamp);

				// System.out.println("DAS SAVE prepareMsgStopFlagsInsertBatchStatement --> " +
				// ((float)(System.nanoTime()-lBEFORE_prepareMsgStopFlagsInsertBatchStatement)/GlobalConstants.NANOS_TO_MS_DIVIDER));
				bNoModificationsDetected = (Boolean) pdo.getTransient(PDOConstantFieldsInterface.D_FIELDS_WERE_NOT_MODIFIED);

				// retrieve the last timestamp from the pdo
				sLastSaveTimestamp = pdo.getString(PDOConstantFieldsInterface.P_TIME_STAMP);

				// set the timestamp into the PDO prior to the qexplorer counter recalculation
				pdo.set(PDOConstantFieldsInterface.P_TIME_STAMP, sPersistenceTimestamp);

				if (!pdo.isThinMode()) {
					// if the pdo is a new one, create an insert statement otherwise create an update
					if (pdo.isNew()) {
						// set the create date for the payment office or for the default office if not present
						sOffice = pdo.getString(P_OFFICE);
						if (sOffice == null)
							sOffice = GlobalConstants.DEFAULT_SERVER_OFFICE_NAME;

						if (pdoInsertStatement == null)
							pdoInsertStatement = conn.prepareStatement(m_minfInsertQuery);

						this.prepareNewPdoStatement(pdoInsertStatement, pdo);

						// System.out.println("DAS SAVE prepareNewPdoStatement --> " +
						// ((float)(System.nanoTime()-lBEFORE_prepareNewPdoStatement)/GlobalConstants.NANOS_TO_MS_DIVIDER));

					} else if (bNoModificationsDetected == null || !bNoModificationsDetected) {

						// final long lBEFORE_prepareUpdatePdoStatement= System.nanoTime() ;

						logger.debug("Calls 'prepareUpdatePdoStatement' for MID: " + pdo.getMID());

						pdoUpdateStatement = this.prepareUpdatePdoStatement(conn, pdo, sLastSaveTimestamp, sPersistenceTimestamp);

						iRowCount = (pdoUpdateStatement == null ? 0 : pdoUpdateStatement.executeUpdate());

						// System.out.println("DAS SAVE prepareUpdatePdoStatement --> " +
						// ((float)(System.nanoTime()-lBEFORE_prepareUpdatePdoStatement)/GlobalConstants.NANOS_TO_MS_DIVIDER));

						logger.debug("message {} update resulted in rowcount: {}", sMID, iRowCount);
						// error handling --> NYI
						// if the row count was not 1 for the pdo insert/update statement, rollback
						if (iRowCount != 1) {
							final String sErrorMsg = GlobalUtils.getEditedErrorText(ProcessErrorConstants.PersistenceConcurrencyFailure, sMID);
							logger.error(sErrorMsg);
							throw new ConcurrentModificationException(sErrorMsg);
						}// EO if the pdo update/insert row count was not 1
					}// EO else if the pdo was not new
				}// EO if the pdo was not in THIN mode
			}// EO while there are more pdos in the cache

			// final long lBEFORE_BatchExecution= System.nanoTime() ;
			if (pdoInsertStatement != null) {
				try
				{
					logger.info("Executes pdoInsertStatement...");
	
					// final long lBEFORE_pdoInsertStatement_execution= System.nanoTime() ;
					pdoInsertStatement.executeBatch();
				}
				catch (java.sql.BatchUpdateException ex)
				{
					final StringBuilder sBuilder=new StringBuilder();
					for (PDO pdo:pdoList) 
					{
						sBuilder.append(pdo.getMID());
						sBuilder.append(",");
					}
					logger.error("pdoInsertStatement.executeBatch",ex);
					logger.error("MIDs({})={}",pdoList.size(),sBuilder.toString());
					throw ex;
				}
				// System.out.println("DAS SAVE pdoInsertStatement_execution --> " +
				// ((float)(System.nanoTime()-lBEFORE_pdoInsertStatement_execution)/GlobalConstants.NANOS_TO_MS_DIVIDER));
			}// EO pdoInsertStatement != null

			if (arrAuditTrailStatements != null) {
				logger.info("Executes auditTrailBatchStatement...");

				// final long lBEFORE_auditTrailBatchStatement_execution= System.nanoTime() ;

				if (arrAuditTrailStatements[0] != null)
					arrAuditTrailStatements[0].executeBatch();
				if (arrAuditTrailStatements[1] != null)
					arrAuditTrailStatements[1].executeBatch();
				// System.out.println("DAS SAVE auditTrailBatchStatement_execution --> " +
				// ((float)(System.nanoTime()-lBEFORE_auditTrailBatchStatement_execution)/GlobalConstants.NANOS_TO_MS_DIVIDER));

			}// EO arrAuditTrailStatements != null

			if (msgErrorBatchStatement != null) {
				logger.info("Executes msgErrorBatchStatement....");
				msgErrorBatchStatement.executeBatch();
			}// EO msgErrorBatchStatement != null

            //if (fileSummaryUpdateStatement != null){
           // 	logger.info("Executes fileSummaryUpdate...");
            //    fileSummaryUpdateStatement.executeBatch();
            //}

			if (externalErrorMessagesBatchStatement != null) {
				logger.info("Executes externalErrorMessagesBatchStatement...");
				externalErrorMessagesBatchStatement.executeBatch();
			}
			
			if (msgSpecialInstInsertAndUpdateStArr != null) {
				if (msgSpecialInstInsertAndUpdateStArr[0] != null) {
					logger.info("Executes  msgSpecialInstructionsInsertBatchStatement...");
					msgSpecialInstInsertAndUpdateStArr[0].executeBatch();
				}
				if (msgSpecialInstInsertAndUpdateStArr[1] != null) {
					logger.info("Executes msgSpecialInstructionsUpdateBatchStatement...");
					msgSpecialInstInsertAndUpdateStArr[1].executeBatch();
				}
			}// EO msgSpecialInstInsertAndUpdateStArr != null

			// insert to message fees executed not as a batch statement because of DB2 problem with setNull method
			// MSG_FEES - Delete MUST always be executed before the insert.
			if (msgFeesDeleteStatement != null) {
				logger.info("Executes msgFeesDeleteStatement...");
				msgFeesDeleteStatement.executeBatch();
			}// EO msgFeesDeleteStatement != null
				//

			if (msgFeesBatchStatement != null) {
				// final long lBEFORE_msgFeesBatchStatement_execution= System.nanoTime() ;

				logger.info("Executes msgFeesBatchStatement...");
				msgFeesBatchStatement.executeBatch();

				// System.out.println("DAS SAVE msgFeesBatchStatement execution --> " +
				// ((float)(System.nanoTime()-lBEFORE_msgFeesBatchStatement_execution)/GlobalConstants.NANOS_TO_MS_DIVIDER));

			}// EO msgFeesBatchStatement != null

			// END MSG_FEES.

			// MSG_PARTIES
			if (msgPartiesDeleteStatement != null) {
				logger.info("Executes msgPartiesDeleteStatement...");
				msgPartiesDeleteStatement.executeBatch();
			}// EO msgPartiesDeleteStatement != null
			
			if (msgPartiesBatchStatement != null) {				

				logger.info("Executes msgPartiesBatchStatement...");
				msgPartiesBatchStatement.executeBatch();				

			}// EO msgPartiesBatchStatement != null

			// END MSG_PARTIES.

			// DYNAMIC_PARTY_LIMIT
			if (dynamicPartyLimitDeleteStatement != null) {
				logger.info("Executes dynamicPartyLimitDeleteStatement...");
				dynamicPartyLimitDeleteStatement.executeBatch();
			}// EO dynamicPartyLimitDeleteStatement != null
			
			if (dynamicPartyLimitBatchStatement != null) {				

				logger.info("Executes dynamicPartyLimitBatchStatement...");
				dynamicPartyLimitBatchStatement.executeBatch();

			}// EO msgPartiesBatchStatement != null

			// END DYNAMIC_PARTY_LIMIT.
			
			
			// MESSAGERATES - Delete MUST always be executed before the insert.
			if (messageRatesDeleteStatement != null) {
				logger.info("Executes messageRatesDeleteStatement...");
				messageRatesDeleteStatement.executeBatch();
			}// EO messageRatesDeleteStatement != null
				//
			if (messageRatesBatchStatement != null) {
				logger.info("Executes messageRatesBatchStatement...");
				messageRatesBatchStatement.executeBatch();
			}// EO messageRatesBatchStatement != null
				// END MESSAGERATES.

			// MSG NOTES insert only
			if (msgNotesInsertAndUpdateStArr != null && msgNotesInsertAndUpdateStArr[MSG_NOTES_BATCH_INSERT] != null) {
				logger.info("Executes msgNotesBatchInsertStatement...");
				msgNotesInsertAndUpdateStArr[MSG_NOTES_BATCH_INSERT].executeBatch();
			}// EO if there were message notes

			// MSG NOTES Update only
			if (msgNotesInsertAndUpdateStArr != null && msgNotesInsertAndUpdateStArr[MSG_NOTES_BATCH_UPDATE] != null) {
				logger.info("Executes msgNotesBatchUpdateStatement...");
				msgNotesInsertAndUpdateStArr[MSG_NOTES_BATCH_UPDATE].executeBatch();
			}// EO if there were message notes

			// MSG_STOP_FLAGS - Delete MUST always be executed before the insert.
			if (stopFlagsDeleteStatement != null) {
				logger.info("Executes stopFlagsDeleteStatement...");
				stopFlagsDeleteStatement.executeBatch();
			}// EO if stopFlagsDeleteStatement != null
				//
			if (stopFlagsInsertBatchStatement != null) {
				logger.info("Executes stopFlagsInsertBatchStatement...");
				stopFlagsInsertBatchStatement.executeBatch();
			}// EO if stopFlagsInsertBatchStatement != null
				// END MSG_STOP_FLAGS.

			if (msgRuleLogBatchStatement != null) {
				// final long lBEFORE_msgRuleLogBatchStatement_execution= System.nanoTime() ;

				logger.info("Executes msgRuleLogBatchStatement...");
				msgRuleLogBatchStatement.executeBatch();
				// System.out.println("DAS SAVE msgRuleLogBatchStatement execution --> " +
				// ((float)(System.nanoTime()-lBEFORE_msgRuleLogBatchStatement_execution)/GlobalConstants.NANOS_TO_MS_DIVIDER));

			}// EO if msgRuleLogBatchStatement != null

			if (batchSubsetInsertAndUpdateStArr != null) {
				if (batchSubsetInsertAndUpdateStArr[0] != null) {
					logger.info("Executes batchSubsetInsertStatement...");
					batchSubsetInsertAndUpdateStArr[0].executeBatch();
				}// EO if batchSubsetInsertAndUpdateStArr != null

				if (batchSubsetInsertAndUpdateStArr[1] != null) {
					logger.info("Executes batchSubsetUpdateStatement...");
					batchSubsetInsertAndUpdateStArr[1].executeBatch();
				}// EO if batchSubsetInsertAndUpdateStArr != null
			}// EO if batchSubsetInsertAndUpdateStArr != null

			if (mFamilyInsertAndUpdateStArr != null) {
				if (mFamilyInsertAndUpdateStArr[0] != null) {
					logger.info("Executes mfamilyInsertStatement...");
					mFamilyInsertAndUpdateStArr[0].executeBatch();
				}// EO if mFamilyInsertAndUpdateStArr != null

				if (mFamilyInsertAndUpdateStArr[1] != null) {
					logger.info("Executes mfamilyUpdateStatement...");
					mFamilyInsertAndUpdateStArr[1].executeBatch();
				}// EO if mFamilyInsertAndUpdateStArr != null
			}// EO if mFamilyInsertAndUpdateStArr != null

			// MESSAGE_EXTERNAL_INTERACTION insert
			if (messageExternalInteractionStArr != null && messageExternalInteractionStArr[MESSAGE_EXTERNAL_INTERACTION_INSERT] != null) {
				logger.info("Executes messageExternalInteractionInsertStatement...");
				messageExternalInteractionStArr[MESSAGE_EXTERNAL_INTERACTION_INSERT].executeBatch();
			}// EO if there were message notes

			// MESSAGE_EXTERNAL_INTERACTION update
			if (messageExternalInteractionStArr != null && messageExternalInteractionStArr[MESSAGE_EXTERNAL_INTERACTION_UPDATE] != null) {
				logger.info("Executes messageExternalInteractionUpdateStatement...");
				messageExternalInteractionStArr[MESSAGE_EXTERNAL_INTERACTION_UPDATE].executeBatch();
			}// EO if there were message notes

			if (templateUnchangedFieldsPsArr != null) {
				if (templateUnchangedFieldsPsArr[TEMPLATE_UNCHANGED_FIELDS_DELETE] != null)
					templateUnchangedFieldsPsArr[TEMPLATE_UNCHANGED_FIELDS_DELETE].executeBatch();
				if (templateUnchangedFieldsPsArr[TEMPLATE_UNCHANGED_FIELDS_INSERT] != null)
					templateUnchangedFieldsPsArr[TEMPLATE_UNCHANGED_FIELDS_INSERT].executeBatch();
			}

			if (cycleSettlementInsertAndUpdateArr != null) {
				if (cycleSettlementInsertAndUpdateArr[CYCLE_SETTLEMENT_INTERACTION_INSERT] != null)
					cycleSettlementInsertAndUpdateArr[CYCLE_SETTLEMENT_INTERACTION_INSERT].executeBatch();
				if (cycleSettlementInsertAndUpdateArr[CYCLE_SETTLEMENT_INTERACTION_UPDATE] != null)
					cycleSettlementInsertAndUpdateArr[CYCLE_SETTLEMENT_INTERACTION_UPDATE].executeBatch();
			}
			// if there were deltas (deltaCountersHolder != null) perform the delta save properation

			// System.out.println("DAS SAVE propagateSaveDeltas --> " +
			// ((float)(System.nanoTime()-lBEFORE_propagateSaveDeltas)/GlobalConstants.NANOS_TO_MS_DIVIDER));

			// In case of more then one PDO, (i.e. we have received a PDO with relations in it),
			// then makes sure that after the save the "main" PDO is the one set into the Admin object.
			if (pdoList.size() > 1)
				pdoList.get(0).promoteToPrimary();

			// reset the pdo after executions are performed
			String sDupexKey = null;
			String sRespFromHost = null;
			CallSource callSource = null;

			for (PDO pdo : pdoList) {
				if (pdo.isTransient())
					continue;

				String duplicateChecking = CacheKeys.SystParKey.getSingleParmValue(pdo.getString(PDOConstantFieldsInterface.P_OFFICE),
						SystemParametersInterface.SYST_PAR_CHECK_DUPLICATE_IN_CACHE);
				final boolean bShouldHandleDuplicates = GlobalConstants.Yes.equals(duplicateChecking);

				sDupexKey = pdo.getString(PDOConstantFieldsInterface.P_DUPLICATE_INDEX);
				sRespFromHost = pdo.getString(PDOConstantFieldsInterface.D_RESPONSE_FROM_HOST);
				logger.info("sRespFromHost {}",sRespFromHost);

				if (!GlobalUtils.isNullOrEmpty(sDupexKey) && bShouldHandleDuplicates ) dupexKeyList.add(sDupexKey);
				
				if (!GlobalUtils.isNullOrEmpty(sRespFromHost)) {
					dupexKeyList.add(sRespFromHost);
				}
				
				
				// final long lBEFORE_removeDupex = System.nanoTime() ;
				// System.out.println("DAS SAVE remove dupex --> " +
				// ((float)(System.nanoTime()-lBEFORE_removeDupex)/GlobalConstants.NANOS_TO_MS_DIVIDER));

				// the reset is required for removal as well as the remove will infact remove the pdo from local
				// cache but put it in the remote one
				callSource = Admin.getContextAdmin().getCallSource();
				logger.debug("PDO reset decision - MID: {}, P_MSG_STS: {}, P_MSG_TYPE: {}, callSource: {}, bRemovePDOFromCache: {}.", new Object[] {
						pdo.getMID(), pdo.getString(P_MSG_STS), pdo.getString(P_MSG_TYPE), callSource, bRemovePDOFromCache });

				// as this code can only be reached as a result of a successful persistence operation, it is safe to
				// assume that the pdo is now a valid represnetation of the MINF record and could be flagged as global
				pdo.setIsGlobalPDO(true);

				/*
				 * // Added just for clarity; when 'bRemovePDOFromCache' is false, then it means that we arrived from the GUI; // in that case, no
				 * need to clear the PDO's transient map, as we require a value form it prior to the // close message action that will be done in the
				 * 'BOMessageLoad.releaseLockedMessage' method; // see there the use for the D_FIELDS_WERE_NOT_MODIFIED key. boolean
				 * bClearTransientMap = bRemovePDOFromCache; pdo.reset(bClearTransientMap);
				 */

				//ensure that the given pdo is in normal/uncacacheable mode as it is now a mirror of the minf record
                pdoStateHandler.configureStateAfterSuccessfulPersistence(pdo) ;
                //pdo.setModeType(PDOModeType.Normal) ; 
                
                // MP TBD: should be remarked?! 
				// ensure that the given pdo is in normal as it is now a mirror of the minf record
				//pdo.setModeType(PDOModeType.Normal);
			}// EO while there are more pdos to reset

			//Set The list of Duplicate index to map at Admin in order to remove them from cache after transaction commit
            //(To prevent situation that Duplicate key is not in cahce but the commit to the DB was not done yet )
            if (dupexKeyList != null && dupexKeyList.size() > 0 ) {
//            	Admin.getContextAdmin().putSessionData(Admin.CONTEXT_DUPEX_KEY_LIST, dupexKeyList.toArray(new String[dupexKeyList.size()])) ;
            	Admin.getContextAdmin().putSessionData(Admin.CONTEXT_DUPEX_KEY_LIST, dupexKeyList) ;
            }
            
			// final long lBEFORE_removeFromLocalAndPropagateToRemote = System.nanoTime() ;

			// if the bRemovePDOFromCache = true, remove the pdo from the cache
			if (bRemovePDOFromCache)
				CacheKeys.ProcessPDOKey.removeFromLocalAndPropagateToRemote(pdoList);

			// System.out.println("DAS SAVE  removeFromLocalAndPropagateToRemote--> " +
			// ((float)(System.nanoTime()-lBEFORE_removeFromLocalAndPropagateToRemote)/GlobalConstants.NANOS_TO_MS_DIVIDER));

		} catch (Exception e) {
			// ExceptionController.getInstance().handleException(t, this) ;

			// Error code 77784: 'PDO save process failure; the reason is: |1'.
			final Object[] arrNonPaymentFields = { e.getMessage() };
			final ProcessError processError = new ProcessError(ProcessErrorConstants.PDOSaveFailure, arrNonPaymentFields);
			ErrorAuditUtils.setErrors(processError);

			// remove the pdos from the cache by first converting them into an array (cannot use the orig array as it might not
			// be in the correct locking order and might cause a deadlock)
			final int iLength = pdoList.size();
			final PDO[] arrPDOToRemove = new PDO[iLength];
			PDO pdoToRemove = null;
			for (int i = 0; i < iLength; i++) {
				pdoToRemove = pdoList.get(i);
				// set the pdo in thin mode so as to ensure that the pdo would be progagated to the distributed
				// map and its locks removed
				pdoToRemove.setThinMode(true/* bThinMode */);
				// set the pdo to global true so as to indicate to the removeFromLocalAndRemote()
				// to remove the pdo from the distributed map as well
				pdoToRemove.setIsGlobalPDO(true);
				arrPDOToRemove[i] = pdoToRemove;
			}// EO while there are more pdos
			if (bRemovePDOFromCache)
				CacheKeys.ProcessPDOKey.removeFromLocalAndRemote(arrPDOToRemove);

			throw e;
		} finally {
			// final long lBEFORE_releaseResources = System.nanoTime() ;

			if (msgSpecialInstInsertAndUpdateStArr != null)
				m_dao.releaseResources(msgSpecialInstInsertAndUpdateStArr[0], msgSpecialInstInsertAndUpdateStArr[1]);

			if (batchSubsetInsertAndUpdateStArr != null)
				m_dao.releaseResources(batchSubsetInsertAndUpdateStArr[0], batchSubsetInsertAndUpdateStArr[1]);

			if (mFamilyInsertAndUpdateStArr != null)
				m_dao.releaseResources(mFamilyInsertAndUpdateStArr[0], mFamilyInsertAndUpdateStArr[1]);

			if (arrAuditTrailStatements != null)
				m_dao.releaseResources(arrAuditTrailStatements[0], arrAuditTrailStatements[1]);

			if (messageExternalInteractionStArr != null)
				m_dao.releaseResources(messageExternalInteractionStArr[MESSAGE_EXTERNAL_INTERACTION_INSERT],
						messageExternalInteractionStArr[MESSAGE_EXTERNAL_INTERACTION_UPDATE], messageExternalInteractionStArr[MESSAGE_EXTERNAL_INTERACTION_IS_EXIST]); 

			if (templateUnchangedFieldsPsArr != null)
				m_dao.releaseResources(templateUnchangedFieldsPsArr[TEMPLATE_UNCHANGED_FIELDS_DELETE],
						templateUnchangedFieldsPsArr[TEMPLATE_UNCHANGED_FIELDS_INSERT]);

			if (cycleSettlementInsertAndUpdateArr != null)
				m_dao.releaseResources(cycleSettlementInsertAndUpdateArr[CYCLE_SETTLEMENT_INTERACTION_INSERT],
						cycleSettlementInsertAndUpdateArr[CYCLE_SETTLEMENT_INTERACTION_UPDATE]);

			m_dao.releaseResources(pdoInsertStatement, msgErrorBatchStatement, msgFeesDeleteStatement, msgFeesBatchStatement,
					msgPartiesDeleteStatement, msgPartiesBatchStatement, dynamicPartyLimitDeleteStatement , dynamicPartyLimitBatchStatement,
					msgRuleLogBatchStatement, messageRatesDeleteStatement, messageRatesBatchStatement, stopFlagsInsertBatchStatement,
					stopFlagsDeleteStatement, pdoUpdateStatement, conn);

		}// EO catch block

	}// EOM

	/**
     * 
     */
	private final PreparedStatement[] pouplateMsgnotesInsertBatch(final Connection conn, PreparedStatement[] msgNotesInsertAndUpdateStArr,
			final PDO pdo, long lDBTimestampMills) throws SQLException {

		PreparedStatement[] msgNotesBatchStatement = new PreparedStatement[2];
		boolean isExternalNote = isExternalNote(pdo);
		// retrieve the current db timestamp from the db and increment for each record by 1 millis as the
		// table key is mid+time_stamp
		final Date timeStampDate = new Date();
		final DateAndZone paymentOfficeDateAndZone = NewASDateTimeUtils.getCurrentDateAndZoneByOffice(pdo.getString(P_OFFICE));
		final java.sql.Timestamp paymentOfficeDate = new java.sql.Timestamp(paymentOfficeDateAndZone.getDate().getTime());

		final List<MsgNotesLineType> listMsgnotes = pdo.getListMSGNOTES();
		final String sMID = pdo.getMID();
		final Integer iPartitionID = pdo.getIsHistory();
		String sTimeStampStr = null;
		String userId = Admin.getContextAdmin().getWebSessionInfo().getUserID();
		int i;

		if (msgNotesInsertAndUpdateStArr == null)
			msgNotesInsertAndUpdateStArr = new PreparedStatement[2];
		for (MsgNotesLineType msgnote : listMsgnotes) {
			  msgnote.setFMSGNOTESUSERID(userId);
			// If this is an Update or Delete Note action, then we need to update the existing note.
			if (!ServerConstants.ACTION_ACTIVATE.equals(msgnote.getFMSGNOTESRECSTATUS()) && msgnote.getFMSGNOTESTIMESTAMP() != null) {
				if (msgNotesInsertAndUpdateStArr[MSG_NOTES_BATCH_UPDATE] == null)
					msgNotesInsertAndUpdateStArr[MSG_NOTES_BATCH_UPDATE] = conn.prepareStatement(MSG_NOTES_UPDATE_STATUS_STATEMENT);
				i = 1;
				setObject(msgNotesInsertAndUpdateStArr[MSG_NOTES_BATCH_UPDATE], i++, msgnote.getFMSGNOTESUSERID());
				setObject(msgNotesInsertAndUpdateStArr[MSG_NOTES_BATCH_UPDATE], i++, paymentOfficeDateAndZone.getDisplayZone());
				setObject(msgNotesInsertAndUpdateStArr[MSG_NOTES_BATCH_UPDATE], i++, paymentOfficeDate);
				setObject(msgNotesInsertAndUpdateStArr[MSG_NOTES_BATCH_UPDATE], i++, sMID);
				setObject(msgNotesInsertAndUpdateStArr[MSG_NOTES_BATCH_UPDATE], i++, msgnote.getFMSGNOTESTIMESTAMP());
				setObject(msgNotesInsertAndUpdateStArr[MSG_NOTES_BATCH_UPDATE], i++, iPartitionID);

				msgNotesInsertAndUpdateStArr[MSG_NOTES_BATCH_UPDATE].addBatch();

			}
			// If this is an updated record or a new one.
			if ((ServerConstants.ACTION_UPDATE.equals(msgnote.getFMSGNOTESRECSTATUS())) || msgnote.getFMSGNOTESTIMESTAMP() == null) {
				// if the msgNotesBatchInsertStatement was not yet initiailzed, do so now
				if (msgNotesInsertAndUpdateStArr[MSG_NOTES_BATCH_INSERT] == null)
					msgNotesInsertAndUpdateStArr[MSG_NOTES_BATCH_INSERT] = conn.prepareStatement(MSG_NOTES_INSERT_STATEMENT);
				i = 1;
				setObject(msgNotesInsertAndUpdateStArr[MSG_NOTES_BATCH_INSERT], i++, sMID);
				setObject(msgNotesInsertAndUpdateStArr[MSG_NOTES_BATCH_INSERT], i++, msgnote.getFMSGNOTESUSERID());
				setObject(msgNotesInsertAndUpdateStArr[MSG_NOTES_BATCH_INSERT], i++, msgnote.getFMSGNOTESTEXT());

				// increment the timestamp by 1 mills to ensure that the record is unique
				timeStampDate.setTime(lDBTimestampMills++);
				sTimeStampStr = GlobalDateTimeUtil.getFormattedDateString(timeStampDate, GlobalDateTimeUtil.STATIC_DATA_TIME_STAMP);
				setObject(msgNotesInsertAndUpdateStArr[MSG_NOTES_BATCH_INSERT], i++, sTimeStampStr);
				// se the msg notes timestamp so as to indicate that this instance is no longer new
				msgnote.setFMSGNOTESTIMESTAMP(sTimeStampStr);
				// set the
				setObject(msgNotesInsertAndUpdateStArr[MSG_NOTES_BATCH_INSERT], i++, paymentOfficeDateAndZone.getDisplayZone());
				setObject(msgNotesInsertAndUpdateStArr[MSG_NOTES_BATCH_INSERT], i++, paymentOfficeDate);
				setObject(msgNotesInsertAndUpdateStArr[MSG_NOTES_BATCH_INSERT], i++, msgnote.getFMSGNOTESEXTERNALNOTEIND());
				setObject(msgNotesInsertAndUpdateStArr[MSG_NOTES_BATCH_INSERT], i++, msgnote.getFMSGNOTESATTACHEDFILELINK() == null ? EMPTY_STRING
						: msgnote.getFMSGNOTESATTACHEDFILELINK());
				setObject(msgNotesInsertAndUpdateStArr[MSG_NOTES_BATCH_INSERT], i++, iPartitionID);

				msgNotesInsertAndUpdateStArr[MSG_NOTES_BATCH_INSERT].addBatch();

			}
		}// EO while there are more message notes

		return msgNotesInsertAndUpdateStArr;
	}// EOM

	private final PreparedStatement[] prepareMessageExternalInteraction(Connection con, PreparedStatement[] psArr, String timeStamp, PDO pdo)
			throws SQLException {

		String mid = pdo.getMID();
		Map mapMessageExternalInteraction = pdo.getMapMESSAGE_EXTERNAL_INTERACTION();

		Map<String, Boolean> isExistMap = new HashMap<String, Boolean>();

		if (psArr == null)
			psArr = new PreparedStatement[3];
		if (psArr[MESSAGE_EXTERNAL_INTERACTION_INSERT] == null)
			psArr[MESSAGE_EXTERNAL_INTERACTION_INSERT] = con.prepareStatement(MESSAGE_EXTERNAL_INTERACTION_INSERT_STATEMENT);
		if (psArr[MESSAGE_EXTERNAL_INTERACTION_UPDATE] == null)
			psArr[MESSAGE_EXTERNAL_INTERACTION_UPDATE] = con.prepareStatement(MESSAGE_EXTERNAL_INTERACTION_UPDATE_STATEMENT);
		if (psArr[MESSAGE_EXTERNAL_INTERACTION_IS_EXIST] == null)
			psArr[MESSAGE_EXTERNAL_INTERACTION_IS_EXIST] = con.prepareStatement(MESSAGE_EXTERNAL_INTERACTION_IS_EXIST_STATEMENT);

		if (mapMessageExternalInteraction != null) {

			Iterator<List<MessageExternalInteraction>> messageExternalInteractionIter = pdo.getMapMESSAGE_EXTERNAL_INTERACTION().values().iterator();

			while (messageExternalInteractionIter.hasNext()) {
				List<MessageExternalInteraction> listMessageExternalInteractions = messageExternalInteractionIter.next();

				if (listMessageExternalInteractions != null) {

					for (MessageExternalInteraction messageExternalInteraction : listMessageExternalInteractions) {
						if (messageExternalInteraction.isNew()) {
							boolean isStoreIndUpdate = messageExternalInteraction.getStoreInd() != null
									&& messageExternalInteraction.getStoreInd() == 2;
							boolean isEntryExist = isMessageExternalInteractionExist(con, psArr[MESSAGE_EXTERNAL_INTERACTION_IS_EXIST], mid,
									messageExternalInteraction.getInterfaceName(), messageExternalInteraction.getResponseRequestInd(), isExistMap);

							// if store ind = 2 and entry exist in DB
							if (isStoreIndUpdate && isEntryExist) {
								//TBD that is make sense to use the time on the messageExternalInteraction?
								updateMessageExternalInteraction(psArr[MESSAGE_EXTERNAL_INTERACTION_UPDATE]
								                              ,mid,timeStamp,messageExternalInteraction);
							} else {
								if (messageExternalInteraction.getTimeStamp() == null) {
									String sMilliseconds = timeStamp.substring(timeStamp.length() - 3, timeStamp.length());
									int iNewMilliseconds = new Integer(sMilliseconds).intValue() + 1;
									String sNewMilliseconds = Integer.toString(iNewMilliseconds);
	
									if (sNewMilliseconds.length() == 2)
										sNewMilliseconds = "0" + sNewMilliseconds;
									else if (sNewMilliseconds.length() == 1)
										sNewMilliseconds = "00" + sNewMilliseconds;
									if ("1000".equals(sNewMilliseconds))
										sNewMilliseconds = "998";
	
									timeStamp = timeStamp.substring(0, timeStamp.length() - 3) + sNewMilliseconds;
								} 
								
								insertToMessageExternalInteraction(psArr[MESSAGE_EXTERNAL_INTERACTION_INSERT]
								                             ,mid
								                             ,(messageExternalInteraction.getTimeStamp() == null ? timeStamp : messageExternalInteraction.getTimeStamp())
								                             ,messageExternalInteraction);
							}

							messageExternalInteraction.setNew(false);
							messageExternalInteraction.setUpdated(false);
						} else if (messageExternalInteraction.isUpdated()) {
							//TBD that is make sense to use the time on the messageExternalInteraction?
							updateMessageExternalInteraction(psArr[MESSAGE_EXTERNAL_INTERACTION_UPDATE], mid, timeStamp, messageExternalInteraction);
						}
					}
				}
			}
		}

		return psArr;
	}

	private void updateMessageExternalInteraction(PreparedStatement ps, String mid, String timeStamp,
			MessageExternalInteraction messageExternalInteraction) throws SQLException {

		String uid = mid + GlobalConstants.POWER_SIGN + messageExternalInteraction.getInterfaceName() + GlobalConstants.POWER_SIGN
				+ messageExternalInteraction.getResponseRequestInd() + GlobalConstants.POWER_SIGN + timeStamp;
		int indx = 1;
		GlobalUtils.setObject(ps, indx++, messageExternalInteraction.getInterfaceContent());
		GlobalUtils.setObject(ps, indx++, messageExternalInteraction.getHandleStatus());
		GlobalUtils.setObject(ps, indx++, messageExternalInteraction.getMsgType());
		GlobalUtils.setObject(ps, indx++, messageExternalInteraction.getContext());
		GlobalUtils.setObject(ps, indx++, timeStamp);
		GlobalUtils.setObject(ps, indx++, uid);
		GlobalUtils.setObject(ps, indx++, GlobalConstants.REC_STATUS_ACTIVE);
		GlobalUtils.setObject(ps, indx++, mid);
		GlobalUtils.setObject(ps, indx++, messageExternalInteraction.getInterfaceName());
		GlobalUtils.setObject(ps, indx++, messageExternalInteraction.getResponseRequestInd());
		GlobalUtils.setObject(ps, indx++, messageExternalInteraction.getResendIndicator());

		ps.addBatch();

	}

	private void insertToMessageExternalInteraction(PreparedStatement ps, String mid, String timeStamp,
			MessageExternalInteraction messageExternalInteraction) throws SQLException {

		String uid = mid + GlobalConstants.POWER_SIGN + messageExternalInteraction.getInterfaceName() + GlobalConstants.POWER_SIGN
				+ messageExternalInteraction.getResponseRequestInd() + GlobalConstants.POWER_SIGN + timeStamp;
		int indx = 1;

		GlobalUtils.setObject(ps, indx++, mid);
		GlobalUtils.setObject(ps, indx++, messageExternalInteraction.getInterfaceName());
		GlobalUtils.setObject(ps, indx++, messageExternalInteraction.getInterfaceType());
		GlobalUtils.setObject(ps, indx++, messageExternalInteraction.getInterfaceSubType());
		GlobalUtils.setObject(ps, indx++, messageExternalInteraction.getResponseRequestInd());
		GlobalUtils.setObject(ps, indx++, messageExternalInteraction.getInterfaceContent());
		GlobalUtils.setObject(ps, indx++, messageExternalInteraction.getHandleStatus());
		GlobalUtils.setObject(ps, indx++, messageExternalInteraction.getMsgType());
		GlobalUtils.setObject(ps, indx++, messageExternalInteraction.getContext());
		GlobalUtils.setObject(ps, indx++, timeStamp);
		GlobalUtils.setObject(ps, indx++, uid);
		GlobalUtils.setObject(ps, indx++, GlobalConstants.REC_STATUS_ACTIVE);
		if (messageExternalInteraction.getResendIndicator() != null) {
			GlobalUtils.setObject(ps, indx++,
					messageExternalInteraction.getResendIndicator());
		} else {
			GlobalUtils.setObject(ps, indx++, GlobalConstants.ZERO_LONG);
		}
		ps.addBatch();

	}

	private boolean isMessageExternalInteractionExist(Connection con, PreparedStatement ps, String mid, String interfaceName, String ind,
			Map<String, Boolean> isExistMap) throws SQLException {

		String key = interfaceName + GlobalConstants.POWER_SIGN + ind;

		// isExistMap is a local cache which holds is exist indicators for records in message_external_interaction table
		Boolean isExist = isExistMap.get(key);

		if (isExist == null) {

			ResultSet rs = null;
			try {
				GlobalUtils.setObject(ps, 1, mid);
				GlobalUtils.setObject(ps, 2, interfaceName);
				GlobalUtils.setObject(ps, 3, ind);

				rs = ps.executeQuery();

				isExist = rs.next();
				isExistMap.put(key, isExist);

			} finally {
				m_dao.releaseResources(rs);
			}
		}

		return isExist;
	}
	
	private boolean isFromMP_ERRORStatus(PDO pdo) {
		boolean isCancelMsgReceived = false;
		PDO pdoOriginalPayment = null;
		String origMsgPrevStatus = null;
		String initiatingMsgType = pdo.getString(P_MSG_TYPE);
		if(MESSAGE_TYPE_CAMT_056.equals(initiatingMsgType))
		{
			pdoOriginalPayment = pdo.getLinkedMsg(RELATION_TYPE_ORIGINAL_PAYMENT);
			if(null != pdoOriginalPayment)
			{
				origMsgPrevStatus = pdoOriginalPayment.getString(P_PREVIOUS_MSG_STS);
				if( MessageConstantsInterface.MESSAGE_STATUS_APPROVE_CANCEL.equals(origMsgPrevStatus)
						&& null != pdoOriginalPayment.get(PDOConstantFieldsInterface.MF_CANCELATION_RECEIVED)  
						&& pdoOriginalPayment.get(PDOConstantFieldsInterface.MF_CANCELATION_RECEIVED).equals(MessageConstantsInterface.MONITOR_FLAG_YES))
				{
					isCancelMsgReceived = true;
				}
			}
		}
		return isCancelMsgReceived;
	}

	/**
	 * @param pdo
	 * @return <code>True</code> if the system parameter EXTERNAL_NOTE is "Yes";
	 */
	private boolean isExternalNote(final PDO pdo) {
		String externalNote = CacheKeys.SystParKey.getSingleParmValue(pdo.getString(PDOConstantFieldsInterface.P_OFFICE), "EXTERNAL_NOTE");
		return (externalNote == null || externalNote.equalsIgnoreCase(NO) ? false : true);
	}

	private final boolean isRelatedTableDirty(final String sTableId, final Newjournal modifiedFieldsEntry) {
		SnapShotHolder snapShot = modifiedFieldsEntry.getSnapshot(sTableId);
		return (snapShot != null && (snapShot.getModificationType() == ModificationType.Auto || (snapShot.getValuesArr() != null
				&& snapShot.getValuesArr().length == 2 && snapShot.getValuesArr()[1] != null)));
	}// EOM

	private final PreparedStatement[] prepareAuditTrailBatchStatement(final Connection conn, PreparedStatement[] arrNewjournalStatements, final PDO pdo, long lDBTimestampMills)
			throws SQLException, IOException {

		final List<Newjournal> listAuditTrailEntries = pdo.getListNEWJOURNAL();

		if (listAuditTrailEntries != null && listAuditTrailEntries.size() > 0) {
        	if (arrNewjournalStatements == null) {
        		arrNewjournalStatements = new PreparedStatement[2];
        	}
			PreparedStatement ps = null;

			final Date date = new Date();
			final long lCurrentTime = System.currentTimeMillis();
			boolean bAlreadySetOneVerifyEntry = false;
			final String REKEY_VERIFY_FIELDS = "REKEY_VERIFY_FIELDS";
			final String SIGHT_VERIFY_FIELDS = "SIGHT_VERIFY_FIELDS";
			MtableDocument xbeanRelatedFieldsData = null;
			String sConfiguredTimestamp = null;
			String sFieldLogicalId = null, sMilliseconds = null, sNewMilliseconds = null;
			int iNewMilliseconds = -1;
			long lCurrentTimestampOfficeset = 0, lDuplicateTimestampOffset = 0;

			for (Newjournal newJournalEntry : listAuditTrailEntries) {
				// if it is not new entry, then skip it.
				if (!newJournalEntry.getIsNew())
					continue;

				int iCounter = 1;

				xbeanRelatedFieldsData = newJournalEntry.getRelatedFieldsDataXml();

				if (xbeanRelatedFieldsData == null) {
					if (arrNewjournalStatements[0] == null)
						arrNewjournalStatements[0] = conn.prepareStatement(NEW_JOURNAL_INSERT_STATEMENT_WITHOUT_XML);
					ps = arrNewjournalStatements[0];
				} else {
					if (arrNewjournalStatements[1] == null)
						arrNewjournalStatements[1] = conn.prepareStatement(NEW_JOURNAL_INSERT_STATEMENT_WITH_XML);
					m_dao.ms_DBType.getXmlDao().bindXmlColumn(iCounter++, xbeanRelatedFieldsData, arrNewjournalStatements[1]);
					ps = arrNewjournalStatements[1];
				}// EO else if the xml bean was not null
				String office = (String) pdo.get(PDOConstantFieldsInterface.P_OFFICE);
				if (newJournalEntry.getOffice() == null || "".equals(newJournalEntry.getOffice())) {
					setObject(ps, iCounter++, office, Types.VARCHAR);
				} else {
					setObject(ps, iCounter++, newJournalEntry.getOffice(), Types.VARCHAR);
				}
				java.sql.Timestamp tms = null;
				if (newJournalEntry.getUpdateDate() == null) {
					tms = new java.sql.Timestamp(System.currentTimeMillis());
				} else {
					tms = new java.sql.Timestamp(newJournalEntry.getUpdateDate().getTime());
				}
				setObject(ps, iCounter++, tms, Types.TIMESTAMP);
				if (newJournalEntry.getEnddate() == null) {
					tms = new java.sql.Timestamp(System.currentTimeMillis());
				} else {
					tms = new java.sql.Timestamp(newJournalEntry.getEnddate().getTime());
				}
				logger.debug("newJournalEntry TimeStamp: {}",tms.toString());
				setObject(ps, iCounter++, tms, Types.TIMESTAMP);
				setObject(ps, iCounter++, newJournalEntry.getUsername(), Types.VARCHAR);
				setObject(ps, iCounter++, newJournalEntry.getModuleId(), Types.VARCHAR);
				setObject(ps, iCounter++, newJournalEntry.getErrorParams(), Types.VARCHAR);
				setObject(ps, iCounter++, pdo.getMID(), Types.VARCHAR);
				setObject(ps, iCounter++, newJournalEntry.getStatus(), Types.VARCHAR);
				setObject(ps, iCounter++, newJournalEntry.getActionid1(), Types.NUMERIC);
				setObject(ps, iCounter++, newJournalEntry.getActionid2(), Types.NUMERIC);

				// Setting the time stamp DB time but calcuating difference between now and actual error time
				// DB current time - (Server current time - Server time when the error was set)
				// the following code is to be replicated for performance reasons
				// lCurrentTimestampOfficeset = (lCurrentTime - newJournalEntry.getNewEntryTimeStamp()) ;
				// if(lCurrentTimestampOfficeset <= lDuplicateTimestampOffset) lCurrentTimestampOfficeset = ++lDuplicateTimestampOffset ;
				// else if(lCurrentTimestampOfficeset == lDuplicateTimestampOffset) lCurrentTimestampOfficeset = ++lDuplicateTimestampOffset ;
				// else if(lCurrentTimestampOfficeset > lDuplicateTimestampOffset) lDuplicateTimestampOffset = lCurrentTimestampOfficeset ;

				date.setTime(lDBTimestampMills++);
				sConfiguredTimestamp = GlobalDateTimeUtil.getFormattedDateString(date, GlobalDateTimeUtil.STATIC_DATA_TIME_STAMP);

				// Temp solution for 'REKEY_VERIFY_FIELDS' and 'SIGHT_VERIFY_FIELDS' records so they won't
				// have the same time stamp and that way, the zoom in the GUI will work fine, and won't bring the same
				// record for both entries, (the selection is based on the time stamp).
				sFieldLogicalId = newJournalEntry.getFieldLogicalId();
				if (REKEY_VERIFY_FIELDS.equals(sFieldLogicalId) || SIGHT_VERIFY_FIELDS.equals(sFieldLogicalId)) {
					if (!bAlreadySetOneVerifyEntry) {
						bAlreadySetOneVerifyEntry = true;
					}

					// Either the 'REKEY_VERIFY_FIELDS' record or the 'SIGHT_VERIFY_FIELDS' was already set;
					// Updates the current dealt record with a different time stamp.
					else {
						sMilliseconds = sConfiguredTimestamp.substring(sConfiguredTimestamp.length() - 3, sConfiguredTimestamp.length());
						iNewMilliseconds = new Integer(sMilliseconds).intValue() + 1;
						sNewMilliseconds = Integer.toString(iNewMilliseconds);

						if (sNewMilliseconds.length() == 2)
							sNewMilliseconds = "0" + sNewMilliseconds;
						else if (sNewMilliseconds.length() == 1)
							sNewMilliseconds = "00" + sNewMilliseconds;
						if ("1000".equals(sNewMilliseconds))
							sNewMilliseconds = "998";

						sConfiguredTimestamp = sConfiguredTimestamp.substring(0, sConfiguredTimestamp.length() - 3) + sNewMilliseconds;
					}
				}
				// END temp soultion.
				logger.debug("Audit Configured TimeStamp: {}",sConfiguredTimestamp);
				setObject(ps, iCounter++, sConfiguredTimestamp, Types.CHAR);
				setObject(ps, iCounter++, newJournalEntry.getClass_(), Types.CHAR);
				setObject(ps, iCounter++, newJournalEntry.getPricingWeight(), Types.NUMERIC);
				setObject(ps, iCounter++, newJournalEntry.getFieldLogicalId(), Types.VARCHAR);
				setObject(ps, iCounter++, newJournalEntry.getFault(), Types.VARCHAR);
				setObject(ps, iCounter++, newJournalEntry.getAuditSubtype(), Types.VARCHAR);
				setObject(ps, iCounter++, newJournalEntry.getErrorSeverity(), Types.NUMERIC);
				setObject(ps, iCounter++, newJournalEntry.getHitInfo(), Types.VARCHAR);
				if (newJournalEntry.getZoneCode() == null || "".equals(newJournalEntry.getZoneCode())) {

					String cacheOffice = CacheKeys.banksKey.getSingle(office).getOffice();
					DateAndZone dateAndZone = NewASDateTimeUtils.getCurrentDateAndZoneByOffice(cacheOffice);
					String zoneCode = dateAndZone.getZone();
					setObject(ps, iCounter++, zoneCode, Types.VARCHAR);
				} else {
					setObject(ps, iCounter++, newJournalEntry.getZoneCode(), Types.VARCHAR);
				}
				newJournalEntry.setNew(false);
				setObject(ps, iCounter++, newJournalEntry.getIpAddress(), Types.VARCHAR);
				setObject(ps, iCounter++, newJournalEntry.getErrorCode(), Types.NUMERIC);
				setObject(ps, iCounter++, newJournalEntry.getFlowId(), Types.VARCHAR);
				setObject(ps, iCounter++, newJournalEntry.getMultiple(), Types.NUMERIC);
				setObject(ps, iCounter++, newJournalEntry.getTypeFieldsChangeVerify(), Types.NUMERIC);
				setObject(ps, iCounter++, pdo.getIsHistory(), Types.INTEGER);
				ps.addBatch();
			}// EO while there are more audit trail entries

		}

		return arrNewjournalStatements;
	}// EOM

	private final PreparedStatement[] prepareMsgSpecialInstructionsBatchStatement(final Connection conn, PreparedStatement[] psArr, final PDO pdo,
			final String currentTimeStamp, final long lDBTimestampMills) throws SQLException {

		final List<MsgSpecialInstructions> listMsgSpecialInstructions = pdo.getListMSG_SPECIAL_INSTRUCTIONS();

		if (listMsgSpecialInstructions != null && listMsgSpecialInstructions.size() > 0) {
			if (psArr == null)
				psArr = new PreparedStatement[2];

			final Date date = new Date();
			int iCounter = -1;
			final long lCurrentTime = System.currentTimeMillis();
			long lCurrentTimestampOfficeset = 0, lDuplicateTimestampOffset = 0;
			String sConfiguredTimestamp = null;

			for (MsgSpecialInstructions specialInstructionEntry : listMsgSpecialInstructions) {
				iCounter = 1;

				if (specialInstructionEntry.getIsNew()) {
					if (psArr[0] == null)
						psArr[0] = conn.prepareStatement(MSG_SPECIAL_INSTRUCITON_INSERT_STATEMENT);

					setObject(psArr[0], iCounter++, specialInstructionEntry.getMid());
					setObject(psArr[0], iCounter++, specialInstructionEntry.getErrorCode());
					setObject(psArr[0], iCounter++, specialInstructionEntry.getErrorParams());
					setObject(psArr[0], iCounter++, specialInstructionEntry.getSiStatus());
					setObject(psArr[0], iCounter++, specialInstructionEntry.getPreventStpUid());
					setObject(psArr[0], iCounter++, specialInstructionEntry.getPartyType());
					;
					setObject(psArr[0], iCounter++, specialInstructionEntry.getObjectId());
					setObject(psArr[0], iCounter++, new java.sql.Date(specialInstructionEntry.getCreateDate().getTime()));
					setObject(psArr[0], iCounter++, specialInstructionEntry.getZoneCode());

					// Setting the time stamp DB time but calcuating difference between now and actual error time
					// DB current time - (Server current time - Server time when the error was set)
					lCurrentTimestampOfficeset = (lCurrentTime - specialInstructionEntry.getNewEntryTimeStamp());
					if (lCurrentTimestampOfficeset <= lDuplicateTimestampOffset)
						lCurrentTimestampOfficeset = ++lDuplicateTimestampOffset;
					else if (lCurrentTimestampOfficeset == lDuplicateTimestampOffset)
						lCurrentTimestampOfficeset = ++lDuplicateTimestampOffset;
					else if (lCurrentTimestampOfficeset > lDuplicateTimestampOffset)
						lDuplicateTimestampOffset = lCurrentTimestampOfficeset;

					date.setTime(lDBTimestampMills - lCurrentTimestampOfficeset);
					sConfiguredTimestamp = GlobalDateTimeUtil.getFormattedDateString(date, GlobalDateTimeUtil.STATIC_DATA_TIME_STAMP);

					setObject(psArr[0], iCounter++, sConfiguredTimestamp);
					setObject(psArr[0], iCounter++, specialInstructionEntry.getUserId());
					setObject(psArr[0], iCounter++, specialInstructionEntry.getPartitionID());
					psArr[0].addBatch();

				} else if (specialInstructionEntry.getIsUpdated()) {

					if (psArr[1] == null)
						psArr[1] = conn.prepareStatement(MSG_SPECIAL_INSTRUCTION_UPDATE_STATEMENT);

					setObject(psArr[1], iCounter++, currentTimeStamp);

					setObject(psArr[1], iCounter++, specialInstructionEntry.getSiStatus());
					setObject(psArr[1], iCounter++, specialInstructionEntry.getUserId());
					setObject(psArr[1], iCounter++, specialInstructionEntry.getMid());
					setObject(psArr[1], iCounter++, specialInstructionEntry.getPartyType());
					;
					setObject(psArr[1], iCounter++, specialInstructionEntry.getObjectId());
					setObject(psArr[1], iCounter++, specialInstructionEntry.getPreventStpUid());
					setObject(psArr[1], iCounter++, specialInstructionEntry.getPartitionID());

					psArr[1].addBatch();

					// Setting the time stamp DB time but calcuating difference between now and actual error time
					// DB current time - (Server current time - Server time when the error was set)

				}// EO if update statement

				specialInstructionEntry.setIsNew(false);
				specialInstructionEntry.setIsUpdated(false);

			}// EO while there are more audit trail entries
		}

		return psArr;
	}// EOM

	private final PreparedStatement prepareMsgRuleLogBatchStatement(final Connection conn, PreparedStatement ps, final PDO pdo,
			final String sPersistenceTimestamp) throws SQLException {

		// if the pdo does not have any modified fields return null
		final List<MsgRuleLog> listMsgRuleLog = pdo.getListMSG_RULE_LOG();

		if (listMsgRuleLog != null && !listMsgRuleLog.isEmpty()) {

			String mid = null;
			Integer partitionID = null;
			String zoneCode = null;
			String flowId = null;
			boolean newEntriesExist = false;
			int iCounter = -1;

			if (ps == null)
				ps = conn.prepareStatement(MSG_RULE_LOG_INSERT_STATEMENT);

			final StringBuilder descriptionSb = new StringBuilder();

			for (MsgRuleLog msgRuleLogEntry : listMsgRuleLog) {
				if (msgRuleLogEntry.getIsNew()) {
					newEntriesExist = true;

					mid = msgRuleLogEntry.getMid();
					zoneCode = msgRuleLogEntry.getZoneCode();
					flowId = msgRuleLogEntry.getFlowId();
					partitionID = pdo.getIsHistory();
					
					
					

					descriptionSb.append(msgRuleLogEntry.getUidPrules()).append(',').append(msgRuleLogEntry.getExecutionTime()).append(';');

					msgRuleLogEntry.setIsNew(false);
				}

			}// EO while there are more audit trail entries

			if (newEntriesExist) {
				iCounter = 1;
				setObject(ps, iCounter++, sPersistenceTimestamp);
				setObject(ps, iCounter++, zoneCode);
				setObject(ps, iCounter++, flowId);
				setObject(ps, iCounter++, descriptionSb.toString());
				setObject(ps, iCounter++, mid);
				setObject(ps, iCounter++, partitionID);

				ps.addBatch();
			}
		}

		return ps;
	}// EOM
	
	
	private final PreparedStatement prepareExternalMessageBatchStatement(final Connection conn, PreparedStatement ps, final PDO pdo) throws SQLException {

		// if the pdo does not have any msg parties return null
		final List<ExternalErrorMessage> extErrMsgs = pdo.getExternalErrorMessages();

		if (extErrMsgs != null && !extErrMsgs.isEmpty()) {

			if (ps == null)
				ps = conn.prepareStatement(EXTERNAL_MESSAGE_INSERT_STATEMENT);

			for (com.fundtech.cache.entities.ExternalErrorMessage msg : extErrMsgs) {
				int iCounter = 1;
				setObject(ps, iCounter++, msg.getInterfaceId(), Types.VARCHAR);
				setObject(ps, iCounter++, msg.getErrorCode(), Types.VARCHAR);
				setObject(ps, iCounter++, msg.getErrorDescription(), Types.VARCHAR);
				setObject(ps, iCounter++, pdo.getMID(), Types.VARCHAR);
				setObject(ps, iCounter++, msg.getTimeStamp(), Types.VARCHAR);
				setObject(ps, iCounter++, pdo.getIsHistory(), Types.INTEGER);
				ps.addBatch();
			}// EO while there are more messasge parties
		}

		return ps;
	}// EOM


	private final PreparedStatement prepareMsgErrorBatchStatement(final Connection conn, PreparedStatement ps, final PDO pdo, long lDBTimestampMills)
			throws SQLException {

		final List<Msgerr> listMsgErrors = pdo.getListMSGERR();

		if (listMsgErrors != null && listMsgErrors.size() > 0) {
			if (ps == null)
				ps = conn.prepareStatement(MSGERR_INSERT_STATEMENT);

			final Date date = new Date();
			int iCounter = -1;
			final long lCurrentTime = System.currentTimeMillis();
			long lCurrentTimestampOfficeset = 0, lDuplicateTimestampOffset = 0;
			String sConfiguredTimestamp = null;

			for (Msgerr msgErrorEntry : listMsgErrors) {
				if (msgErrorEntry.getIsNew()) {
					iCounter = 1;
					setObject(ps, iCounter++, pdo.getMID());
					setObject(ps, iCounter++, msgErrorEntry.getFlowId());
					setObject(ps, iCounter++, msgErrorEntry.getErrorParams());
					setObject(ps, iCounter++, msgErrorEntry.getDisplay());

					// Setting the time stamp DB time but calcuating difference between now and actual error time
					// DB current time - (Server current time - Server time when the error was set)
					// lCurrentTimestampOfficeset = (lCurrentTime - msgErrorEntry.getNewEntryTimeStamp()) ;
					// if(lCurrentTimestampOfficeset <= lDuplicateTimestampOffset) lCurrentTimestampOfficeset = ++lDuplicateTimestampOffset ;
					// else if(lCurrentTimestampOfficeset == lDuplicateTimestampOffset) lCurrentTimestampOfficeset = ++lDuplicateTimestampOffset ;
					// else if(lCurrentTimestampOfficeset > lDuplicateTimestampOffset) lDuplicateTimestampOffset = lCurrentTimestampOfficeset ;

					date.setTime(lDBTimestampMills++);

					sConfiguredTimestamp = GlobalDateTimeUtil.getFormattedDateString(date, GlobalDateTimeUtil.STATIC_DATA_TIME_STAMP);

					setObject(ps, iCounter++, sConfiguredTimestamp);
					setObject(ps, iCounter++, msgErrorEntry.getFieldLogicalId());
					setObject(ps, iCounter++, msgErrorEntry.getPricingWeight());
					setObject(ps, iCounter++, msgErrorEntry.getErrorSeverity());
					setObject(ps, iCounter++, msgErrorEntry.getFault());
					setObject(ps, iCounter++, msgErrorEntry.getErrorCode());
					setObject(ps, iCounter++, msgErrorEntry.getZoneCode());
					setObject(ps, iCounter++, new java.sql.Timestamp(msgErrorEntry.getCreateDate().getTime()));
					setObject(ps, iCounter++, msgErrorEntry.getModuleId());
					setObject(ps, iCounter++, pdo.getIsHistory());

					ps.addBatch();
				}
			}// EO while there are more messasge errors
		}

		return ps;
	}// EOM

	private final PreparedStatement prepareMsgFeesBatchStatement(final Connection conn, PreparedStatement ps, final PDO pdo) throws SQLException {

		// if the pdo does not have any msg fees return null
		final List<MsgFees> listMsgFees = pdo.getListMSG_FEES();

		if (listMsgFees != null && !listMsgFees.isEmpty()) {

			if (ps == null)
				ps = conn.prepareStatement(MSG_FEES_INSERT_STATMENT);

			for (MsgFees msgFeesEntry : listMsgFees) {
				int iCounter = 1;
				setObject(ps, iCounter++, pdo.getMID(), Types.VARCHAR);
				setObject(ps, iCounter++, msgFeesEntry.getId().getApply(), Types.VARCHAR);
				setObject(ps, iCounter++, msgFeesEntry.getFeeCurrency(), Types.CHAR);
				setObject(ps, iCounter++, msgFeesEntry.getFeeAmount(), Types.DECIMAL);
				setObject(ps, iCounter++, msgFeesEntry.getFeeBaseAmount(), Types.DECIMAL);
				setObject(ps, iCounter++, msgFeesEntry.getFeePnlAccOffice(), Types.VARCHAR);
				setObject(ps, iCounter++, msgFeesEntry.getFeePnlAccNo(), Types.VARCHAR);
				setObject(ps, iCounter++, msgFeesEntry.getFeePnlAccountCurrency(), Types.VARCHAR);
				setObject(ps, iCounter++, msgFeesEntry.getFeePnlAmount(), Types.DECIMAL);
				setObject(ps, iCounter++, msgFeesEntry.getFeeMonitor(), Types.VARCHAR);
				setObject(ps, iCounter++, msgFeesEntry.getDeductFrom(), Types.CHAR);
				setObject(ps, iCounter++, msgFeesEntry.getManualFee(), Types.DECIMAL);
				setObject(ps, iCounter++, msgFeesEntry.getFeeAccAmount(), Types.VARCHAR);
				setObject(ps, iCounter++, msgFeesEntry.getId().getPayingParty(), Types.CHAR);
				setObject(ps, iCounter++, msgFeesEntry.getId().getFeeFormulaUid(), Types.VARCHAR);
				setObject(ps, iCounter++, msgFeesEntry.getId().getFeeTypeUid(), Types.VARCHAR);
				setObject(ps, iCounter++, msgFeesEntry.getOrigFeeAmount(), Types.DECIMAL);
				setObject(ps, iCounter++, msgFeesEntry.getUnwindFee() != null ? msgFeesEntry.getUnwindFee() : 0, Types.DECIMAL);
				setObject(ps, iCounter++, msgFeesEntry.getVersionId(), Types.DECIMAL);
				setObject(ps, iCounter++, msgFeesEntry.getPnlPostingSts(), Types.VARCHAR);
				setObject(ps, iCounter++, msgFeesEntry.getFeeAmountInPmtCcy(), Types.DECIMAL);
				setObject(ps, iCounter++, msgFeesEntry.getFeeAmountPmtCcyPreInAf(), Types.DECIMAL);
				setObject(ps, iCounter++, msgFeesEntry.getFeePostingEntryId(), Types.VARCHAR);
				setObject(ps, iCounter++, msgFeesEntry.getPnlPostingEntryId(), Types.VARCHAR);
				Integer partitionID = msgFeesEntry.getPartitionID() != null ? msgFeesEntry.getPartitionID() : pdo.getIsHistory();
				setObject(ps, iCounter++, partitionID, Types.NUMERIC);

				// insert to message fees executed not as a batch statement because of DB2 problem with setNull method
				ps.addBatch();
			}// EO while there are more messasge errors
		}

		return ps;
	}// EOM

	private final PreparedStatement prepareMsgPartiesBatchStatement(final Connection conn, PreparedStatement ps, final PDO pdo) throws SQLException {

		// if the pdo does not have any msg parties return null
		final List<MsgParties> listMsgParties = pdo.getListMSG_PARTIES();

		if (listMsgParties != null && !listMsgParties.isEmpty()) {

			if (ps == null)
				ps = conn.prepareStatement(MSG_PARTIES_INSERT_STATEMENT);

			for (MsgParties msgPartyEntry : listMsgParties) {
				int iCounter = 1;
				setObject(ps, iCounter++, pdo.getMID(), Types.VARCHAR);
				setObject(ps, iCounter++, msgPartyEntry.getOffice(), Types.CHAR);
				setObject(ps, iCounter++, msgPartyEntry.getPartyRole(), Types.VARCHAR);
				setObject(ps, iCounter++, msgPartyEntry.getPartyIdBIC(), Types.VARCHAR);
				setObject(ps, iCounter++, msgPartyEntry.getPartyIdCustCode(), Types.VARCHAR);
				setObject(ps, iCounter++, msgPartyEntry.getPartyIdABA(), Types.VARCHAR);
				setObject(ps, iCounter++, pdo.getIsHistory(), Types.NUMERIC);

				ps.addBatch();
			}// EO while there are more messasge parties
			pdo.setMsgPartiesWasCalc(true);
		}

		return ps;
	}// EOM

	
	private final PreparedStatement prepareDynamicPartyLimitBatchStatement(final Connection conn, PreparedStatement ps, final PDO pdo) throws SQLException {

		// if the pdo does not have any msg parties return null
		boolean incoming = true;
		final List<DynamicPartyLimit> listDynamicPartyLimitIncoming = pdo.getListDYNAMIC_PARTY_LIMIT(incoming);

		if (listDynamicPartyLimitIncoming != null && !listDynamicPartyLimitIncoming.isEmpty()) {
			if (ps == null)
				ps = conn.prepareStatement(DYNAMIC_PARTY_LIMIT_INSERT_STATEMENT);
			
			ps = loopDynamicPartyLimitForBachStatement(ps, listDynamicPartyLimitIncoming);
		}

		// NOTE: The outgoing acumulation is acording to status condition: 
		// 		 pdo.shouldAccumulatePartyLimitOutgoingByStatus()
		boolean outgoing = !incoming;
		final List<DynamicPartyLimit> listDynamicPartyLimitOutgoing = pdo.getListDYNAMIC_PARTY_LIMIT(outgoing);
		if (listDynamicPartyLimitOutgoing != null && !listDynamicPartyLimitOutgoing.isEmpty() &&
			pdo.shouldAccumulatePartyLimitOutgoingByStatus()) 
		{
			if (ps == null)
				ps = conn.prepareStatement(DYNAMIC_PARTY_LIMIT_INSERT_STATEMENT);
			
			ps = loopDynamicPartyLimitForBachStatement(ps, listDynamicPartyLimitOutgoing);
		}
		
		return ps;
	}// EOM

	private final PreparedStatement loopDynamicPartyLimitForBachStatement(PreparedStatement ps, List<DynamicPartyLimit> listDynamicPartyLimit) throws SQLException{
		for (DynamicPartyLimit dynamicPartyLimit : listDynamicPartyLimit) {
			int iCounter = 1;
			setObject(ps, iCounter++, dynamicPartyLimit.getMid(),Types.VARCHAR);
			setObject(ps, iCounter++, new java.sql.Date(dynamicPartyLimit.getBusinessDate().getTime()));
			setObject(ps, iCounter++, dynamicPartyLimit.getRole(),Types.VARCHAR);
			setObject(ps, iCounter++, dynamicPartyLimit.getPartyIdBIC(),Types.VARCHAR);
			setObject(ps, iCounter++, dynamicPartyLimit.getPartyIdCustCode(),Types.VARCHAR);
			setObject(ps, iCounter++, dynamicPartyLimit.getPartyIdABA(),Types.VARCHAR);
			setObject(ps, iCounter++, dynamicPartyLimit.getUidPartyLimits(),Types.VARCHAR);
			setObject(ps, iCounter++, dynamicPartyLimit.getAmount(),Types.VARCHAR);
			setObject(ps, iCounter++, dynamicPartyLimit.getPartitionID(),Types.NUMERIC);
			ps.addBatch();
			
		}// EO while there are more dynamic party limit
		return ps;

	}
	
	
	
	private final PreparedStatement[] prepareCycleSettlementBatchStatement(final Connection conn, PreparedStatement[] psArr, final PDO pdo,
			String timeStamp) throws SQLException, Exception {

		PreparedStatement ps;

		CycleSttlmLineType cycle = pdo.getCYCLE_SETTLEMENT();

		if (cycle != null && ((cycle.getFCYCLESTTLMISNEW()) || cycle.getFCYCLESTTLMISUPDATED())) {
			if (psArr == null) {
				psArr = new PreparedStatement[] { conn.prepareStatement(CYCLE_SETTLLEMENT_INSERT_STATEMENT),
						conn.prepareStatement(CYCLE_SETTLLEMENT_UPDATE_STATEMENT) };
			}

			ps = cycle.getFCYCLESTTLMISNEW() ? psArr[CYCLE_SETTLEMENT_INTERACTION_INSERT] : psArr[CYCLE_SETTLEMENT_INTERACTION_UPDATE];

			int index = 1;

			setObject(ps, index++, cycle.getFCYCLESTTLMDEPARTMENT());
			setObject(ps, index++, cycle.getFCYCLESTTLMOFFICE());
			setObject(ps, index++, cycle.getFCYCLESTTLMCLEARINGSYSTEM());

			setObject(ps, index++, cycle.getFCYCLESTTLMTRANSACTIONDT() != null ? new java.sql.Date(cycle.getFCYCLESTTLMTRANSACTIONDT()
					.getTimeInMillis()) : null);
			setObject(ps, index++, cycle.getFCYCLESTTLMBATCHTM());

			setObject(ps, index++, cycle.getFCYCLESTTLMOUTWRDDBTCNT());
			setObject(ps, index++, cycle.getFCYCLESTTLMOUTWRDDBTAMT() != null ? cycle.getFCYCLESTTLMOUTWRDDBTAMT().doubleValue() : null);

			setObject(ps, index++, cycle.getFCYCLESTTLMOUTWRDDBTACCNT());
			setObject(ps, index++, cycle.getFCYCLESTTLMOUTWRDDBTACAMT() != null ? cycle.getFCYCLESTTLMOUTWRDDBTACAMT().doubleValue() : null);

			setObject(ps, index++, cycle.getFCYCLESTTLMOUTWRDDBTRJCNT());
			setObject(ps, index++, cycle.getFCYCLESTTLMOUTWRDDBTRJAMT() != null ? cycle.getFCYCLESTTLMOUTWRDDBTRJAMT().doubleValue() : null);

			setObject(ps, index++, cycle.getFCYCLESTTLMINWARDCDTCOUNT());
			setObject(ps, index++, cycle.getFCYCLESTTLMINWARDCRDTAMT() != null ? cycle.getFCYCLESTTLMINWARDCRDTAMT().doubleValue() : null);

			setObject(ps, index++, cycle.getFCYCLESTTLMOUTWARDRETUCNT());
			setObject(ps, index++, cycle.getFCYCLESTTLMOUTWARDRETUAMT() != null ? cycle.getFCYCLESTTLMOUTWARDRETUAMT().doubleValue() : null);

			setObject(ps, index++, cycle.getFCYCLESTTLMCALCNETSETAMT() != null ? cycle.getFCYCLESTTLMCALCNETSETAMT().doubleValue() : null);

			setObject(ps, index++, cycle.getFCYCLESTTLMSETTLPOSTINGTP());
			setObject(ps, index++, cycle.getFCYCLESTTLMMSGUSERREFEREN());

			setObject(ps, index++, cycle.getFCYCLESTTLMPOSTINGMSGID()); // For the UID_CYCLE_SETTLEMENT column.

			final XmlObjectBase xbeanInput = PaymentInputSourceType.toXbean(cycle.getFCYCLESTTLMXMLMSG());
			m_dao.ms_DBType.getXmlDao().bindXmlColumn(index++, xbeanInput, ps);

			setObject(ps, index++, GlobalConstants.REC_STATUS_ACTIVE);
			setObject(ps, index++, timeStamp);

			setObject(ps, index++, cycle.getFCYCLESTTLMPOSTINGMSGID());

			ps.addBatch();
		}

		return psArr;
	}// EOM

	private final PreparedStatement prepareMessageRatesBatchStatement(final Connection conn, PreparedStatement ps, final PDO pdo) throws SQLException {

		// The PDO includes 2 lists of related MESSAGERATES data; CR & DR.
		// If both are empty return null.
		final List<ForwardContractLineType> listCR_MESSAGERATES = pdo.getListMESSAGERATES_CR();
		final List<ForwardContractLineType> listDR_MESSAGERATES = pdo.getListMESSAGERATES_DR();

		if ((listCR_MESSAGERATES != null && !listCR_MESSAGERATES.isEmpty()) || (listDR_MESSAGERATES != null && listDR_MESSAGERATES.isEmpty())) {
			// Sets this falg to 'M' for use in the 'BOCurrencyConversion.shouldPerformForwardContract' method.
			pdo.set(P_FC_INFO_IND, BOCurrencyConversion.FC_INFO_IND_MANUAL);

			final List<List<ForwardContractLineType>> listMESSAGERATES_Lists = new ArrayList<List<ForwardContractLineType>>();
			listMESSAGERATES_Lists.add(listCR_MESSAGERATES);
			listMESSAGERATES_Lists.add(listDR_MESSAGERATES);

			if (ps == null)
				ps = conn.prepareStatement(MSG_RATES_INSERT_STATEMENT);

			List<ForwardContractLineType> listCurrent_MESSAGERATES = null;
			int iCounter = -1;
			String sCustomerID = null;
			BigDecimal bdManualSpread = null;

			for (int i = 0; i < 2; i++) {
				listCurrent_MESSAGERATES = listMESSAGERATES_Lists.get(i);

				// One of the lists might be empty.
				if (listCurrent_MESSAGERATES != null && !listCurrent_MESSAGERATES.isEmpty()) {

					for (ForwardContractLineType fcLine : listCurrent_MESSAGERATES) {
						iCounter = 1;
						setObject(ps, iCounter++, pdo.getMID());
						setObject(ps, iCounter++, fcLine.getFFCCONVERSIONTYPE().toString());
						setObject(ps, iCounter++, fcLine.getFFCCONTRACT());
						setObject(ps, iCounter++, fcLine.getFFCAMOUNT());
						setObject(ps, iCounter++, fcLine.getFFCRATE());
						setObject(ps, iCounter++, fcLine.getFFCFORWARDCONTRACT());

						sCustomerID = fcLine.getFFCCUSTOMERID();
						setObject(ps, iCounter++, sCustomerID != null ? sCustomerID : ServerConstants.ONE_VALUE);

						setObject(ps, iCounter++, fcLine.getFFCSPREAD());

						bdManualSpread = fcLine.getFFCMANUALSPREAD();
						setObject(ps, iCounter++, bdManualSpread != null ? bdManualSpread.toString() : ServerConstants.ZERO_VALUE);

						setObject(ps, iCounter++, fcLine.getFFCCURRENCY1());
						setObject(ps, iCounter++, fcLine.getFFCCURRENCY2());
						setObject(ps, iCounter++, pdo.getIsHistory());

						ps.addBatch();
					}
				}
			}
		}

		return ps;
	}// EOM

	private final PreparedStatement[] prepareBatchSubsetInsertStatement(final Connection conn, PreparedStatement[] batchSubsetInsertAndUpdateStArr,
			final PDO pdo, final String sPersistenceTimeStamp) throws SQLException {
		final String TRACE_BATCH_SUBSET_NEW_UPDATED_STATUS = "BatchSubset with MID {}: New: {}, Updated: {}.";

		final BatchSubset batchSubset = pdo.getBatchSubset();

		logger.info(TRACE_BATCH_SUBSET_NEW_UPDATED_STATUS, new Object[] { batchSubset.getMid(), batchSubset.getIsNew(), batchSubset.getIsUpdated() });

		if (batchSubsetInsertAndUpdateStArr == null)
			batchSubsetInsertAndUpdateStArr = new PreparedStatement[2];

		int iCounter = 1;

		if (batchSubset.getIsNew()) {
			if (batchSubsetInsertAndUpdateStArr[0] == null)
				batchSubsetInsertAndUpdateStArr[0] = conn.prepareStatement(BATCH_SUBSET_INSERT_STATEMENT);

			setObject(batchSubsetInsertAndUpdateStArr[0], iCounter++, pdo.getMID());
			setObject(batchSubsetInsertAndUpdateStArr[0], iCounter++, batchSubset.getCreditCurrency());
			setObject(batchSubsetInsertAndUpdateStArr[0], iCounter++, batchSubset.getDebitCurrency());
			setObject(batchSubsetInsertAndUpdateStArr[0], iCounter++, batchSubset.getTotalDebitAm());
			setObject(batchSubsetInsertAndUpdateStArr[0], iCounter++, batchSubset.getTotalMsgCountNb());
			setObject(batchSubsetInsertAndUpdateStArr[0], iCounter++, batchSubset.getStatus());
			setObject(batchSubsetInsertAndUpdateStArr[0], iCounter++, batchSubset.getOffice());
			setObject(batchSubsetInsertAndUpdateStArr[0], iCounter++, batchSubset.getDbAccNo());
			setObject(batchSubsetInsertAndUpdateStArr[0], iCounter++, batchSubset.getSuspenseAccNo());
			setObject(batchSubsetInsertAndUpdateStArr[0], iCounter++, new java.sql.Date(batchSubset.getValueDate().getTime()));
			setObject(batchSubsetInsertAndUpdateStArr[0], iCounter++, batchSubset.getInternalFileId());
			setObject(batchSubsetInsertAndUpdateStArr[0], iCounter++, batchSubset.getUniqueGroupingId());
			setObject(batchSubsetInsertAndUpdateStArr[0], iCounter++, batchSubset.getIndividualMid());
			setObject(batchSubsetInsertAndUpdateStArr[0], iCounter++, batchSubset.getUidBatchSubset());
			setObject(batchSubsetInsertAndUpdateStArr[0], iCounter++, batchSubset.getRecStatus());
			setObject(batchSubsetInsertAndUpdateStArr[0], iCounter++, batchSubset.getProfileChangeStatus());
			setObject(batchSubsetInsertAndUpdateStArr[0], iCounter++, batchSubset.getPendingAction());
			setObject(batchSubsetInsertAndUpdateStArr[0], iCounter++, new java.sql.Date(batchSubset.getEffectiveDate().getTime()));
			setObject(batchSubsetInsertAndUpdateStArr[0], iCounter++, sPersistenceTimeStamp);
			batchSubsetInsertAndUpdateStArr[0].addBatch();
			batchSubset.setIsNew(false);
		} else if (batchSubset.getIsUpdated()) {
			if (batchSubsetInsertAndUpdateStArr[1] == null)
				batchSubsetInsertAndUpdateStArr[1] = conn.prepareStatement(BATCH_SUBSET_UPDATE_STATEMENT);

			setObject(batchSubsetInsertAndUpdateStArr[1], iCounter++, batchSubset.getStatus());
			setObject(batchSubsetInsertAndUpdateStArr[1], iCounter++, pdo.getMID());
			batchSubsetInsertAndUpdateStArr[1].addBatch();
		}// EO else if update

		return batchSubsetInsertAndUpdateStArr;
	}// EOM

	private final PreparedStatement[] prepareMfamilyInsertStatement(Connection conn, PreparedStatement[] mFamilyInsertAndUpdateStArr, final PDO pdo)
			throws SQLException {

		if (mFamilyInsertAndUpdateStArr == null)
			mFamilyInsertAndUpdateStArr = new PreparedStatement[2];

		final List<MFamilyLineType> listMFAMILY = pdo.getListMFAMILY();

		String sSelfMID = null, sSelfType = null, sRelatedMID = null, sRelatedType = null, sTimeStamp = null;
		int iCounter = -1;

		for (MFamilyLineType mfamilyEntry : listMFAMILY) {
			sSelfMID = mfamilyEntry.getFMFAMILYPMID();
			sSelfType = mfamilyEntry.getFMFAMILYSELFRELATEDTYPE();
			sRelatedMID = mfamilyEntry.getFMFAMILYRELATEDMID();
			sRelatedType = mfamilyEntry.getFMFAMILYRELATEDTYPE();
			sTimeStamp = mfamilyEntry.getFMFAMILYTIMESTAMP();

			// A new record.
			if (mfamilyEntry.getFMFAMILYISNEW()) {
				if (mFamilyInsertAndUpdateStArr[0] == null)
					mFamilyInsertAndUpdateStArr[0] = conn.prepareStatement(MFAMILY_INSERT_STATEMENT);
				iCounter = 1;

				// once in the self direction
				setObject(mFamilyInsertAndUpdateStArr[0], iCounter++, sSelfMID);
				setObject(mFamilyInsertAndUpdateStArr[0], iCounter++, sSelfType);
				setObject(mFamilyInsertAndUpdateStArr[0], iCounter++, sRelatedMID);
				setObject(mFamilyInsertAndUpdateStArr[0], iCounter++, sRelatedType);
				setObject(mFamilyInsertAndUpdateStArr[0], iCounter++, sTimeStamp);
				setObject(mFamilyInsertAndUpdateStArr[0], iCounter++, pdo.getIsHistory());

				mFamilyInsertAndUpdateStArr[0].addBatch();

				// then again in the related msg direction
				iCounter = 1;
				setObject(mFamilyInsertAndUpdateStArr[0], iCounter++, sRelatedMID);
				setObject(mFamilyInsertAndUpdateStArr[0], iCounter++, sRelatedType);
				setObject(mFamilyInsertAndUpdateStArr[0], iCounter++, sSelfMID);
				setObject(mFamilyInsertAndUpdateStArr[0], iCounter++, sSelfType);
				setObject(mFamilyInsertAndUpdateStArr[0], iCounter++, sTimeStamp);
				setObject(mFamilyInsertAndUpdateStArr[0], iCounter++, pdo.getIsHistory());

				mFamilyInsertAndUpdateStArr[0].addBatch();

				mfamilyEntry.setFMFAMILYISNEW(false);
			}

			// An updated record, (e.g. after refusal of cancellation request).
			else if (mfamilyEntry.getFMFAMILYISUPDATED()) {
				if (mFamilyInsertAndUpdateStArr[1] == null)
					mFamilyInsertAndUpdateStArr[1] = conn.prepareStatement(MFAMILY_UPDATE_STATEMENT);
				iCounter = 1;

				setObject(mFamilyInsertAndUpdateStArr[1], iCounter++, sSelfType);
				setObject(mFamilyInsertAndUpdateStArr[1], iCounter++, sRelatedType);
				setObject(mFamilyInsertAndUpdateStArr[1], iCounter++, sSelfMID);
				setObject(mFamilyInsertAndUpdateStArr[1], iCounter++, sRelatedMID);
				setObject(mFamilyInsertAndUpdateStArr[1], iCounter++, pdo.getIsHistory());
				mFamilyInsertAndUpdateStArr[1].addBatch();

				mfamilyEntry.setFMFAMILYISUPDATED(false);
			}
		}

		return mFamilyInsertAndUpdateStArr;
	}// EOM

	private final PreparedStatement prepareMsgStopFlagsInsertBatchStatement(final Connection conn, PreparedStatement psInsertBatch, final PDO pdo)
			throws SQLException {

		final List<MsgStopFlags> listMsgStopFlags = pdo.getListMSG_STOP_FLAGS();

		if (!isListNullOrEmpty(listMsgStopFlags)) {
			if (psInsertBatch == null)
				psInsertBatch = conn.prepareStatement(MSG_STOP_FLAGS_INSERT_STATEMENT);

			int iCounter = -1;

			for (MsgStopFlags msgStopFlags : listMsgStopFlags) {
				iCounter = 1;

				setObject(psInsertBatch, iCounter++, pdo.getMID());
				setObject(psInsertBatch, iCounter++, msgStopFlags.getStopFlagUid());
				setObject(psInsertBatch, iCounter++, msgStopFlags.getSfStatus());
				setObject(psInsertBatch, iCounter++, msgStopFlags.getObjectType());
				setObject(psInsertBatch, iCounter++, msgStopFlags.getObjectDir());
				setObject(psInsertBatch, iCounter++, msgStopFlags.getObjectUid());
				setObject(psInsertBatch, iCounter++, msgStopFlags.getPartitionID());

				psInsertBatch.addBatch();

				if (msgStopFlags.getIsNew())
					msgStopFlags.setIsNew(false);
				else if (msgStopFlags.getIsUpdated())
					msgStopFlags.setIsUpdated(false);
			}
		}

		return psInsertBatch;
	}// EOM

	private final static void createMinfInsertQueryAndCoumnNames(Connection conn) throws Exception {

		Map<String, ColumnMetaData> minfColumnMetaData = m_dao.getColumnsMetaDataHM("MINF");

		int length = minfColumnMetaData.size();
		m_minfColumnNames = new ColumnMetaData[length - 2]; // withot 2 xml columns
		m_minfDefaultValuesMap = new HashMap<String, Object>();
		StringBuilder columnNames = new StringBuilder();
		StringBuilder questionMarks = new StringBuilder();

		int i = 0;
		String columnName;
		for (Entry<String, ColumnMetaData> entry : minfColumnMetaData.entrySet()) {

			columnName = entry.getKey();
			if (!columnName.equals(CURRENT_XML_KEY) && !columnName.equals(CURRENT_XML_ORIG_KEY)) {
				columnNames.append(columnName).append(",");
				questionMarks.append("?").append(",");
				m_minfColumnNames[i++] = entry.getValue();
				m_minfDefaultValuesMap.put(columnName, DAOBasic.getColumnDefaultValue(conn, "MINF", columnName));

			}
		}

		columnNames.append(CURRENT_XML_KEY).append(",").append(CURRENT_XML_ORIG_KEY);
		questionMarks.append("?,?");

		m_minfInsertQuery = String.format("INSERT INTO MINF (%s) VALUES (%s) ", columnNames.toString(), questionMarks.toString());

	}

	private final void prepareNewPdoStatement(final PreparedStatement ps, final PDO pdo) throws Exception {

		final Map<Object, PaymentFieldInterface> mapAllPaymentFields = pdo.getDataMap();
		if (mapAllPaymentFields == null || mapAllPaymentFields.isEmpty())
			throw new IllegalArgumentException("PDO was empty");

		int length = m_minfColumnNames.length;
		int i = 0;
		Object oValue;
		ColumnMetaData columnMetaData = null;
		String sColumnName = null;
		PaymentFieldInterface paymentField = null;
		int columnType = -1;

		for (i = 0; i < length; i++) {

			columnMetaData = m_minfColumnNames[i];
			sColumnName = columnMetaData.getColumnName();

			paymentField = mapAllPaymentFields.get(sColumnName);

			oValue = paymentField != null ? paymentField.get() : null;

			if ((oValue instanceof java.util.Date) && !(oValue instanceof Time)) {

				oValue = new java.sql.Timestamp(((java.util.Date) oValue).getTime());

			} else if (oValue == null)
				oValue = m_minfDefaultValuesMap.get(sColumnName);

			// This was made to avoid exception in db2. CHAR cannot be null on one batch and have a value on another. CR#94403
			columnType = columnMetaData.getColumnType() == CHAR ? VARCHAR : columnMetaData.getColumnType();

			setObject(ps, i + 1, oValue, columnType);

			// UNCOMMENT FOR DEBUG
			/*if (false)
			{
				System.out.println("ps.set (" + (i + 1) + "," + columnType + ");" + " Column name " + sColumnName + " Value " + oValue);
			}*/
		}// EO while there are more fields to insert

		this.bindXmlColumn(++i, pdo, XmlLocationType.XML_MSG, ps);
		this.bindXmlColumn(++i, pdo, XmlLocationType.XML_ORIG_MSG, ps);

		ps.addBatch();

	}// EOM

	private final XmlObjectBase configureFndtMsg(final PDO pdo, final boolean bOrig) {

		XmlObjectBase pmntSectionXbean = null, extnSectionXbean = null;
		if (bOrig) {
			pmntSectionXbean = pdo.getXml(ORIG_XML_MSG_KEY);
			extnSectionXbean = pdo.getXml(XmlLocationType.XML_ORIG_MSG_EXTN.name());
		} else {
			pmntSectionXbean = pdo.getXml(CURRENT_XML_MSG_KEY);
			extnSectionXbean = pdo.getXml(XmlLocationType.XML_MSG_EXTN.name());
		}// EO else if current

		XmlObjectBase fndtMsgRoot = FndtMsgPaymentType.newFndtMsg(pmntSectionXbean, true/* inspect root */, true/* extract as is */, false/*
																																		 * return
																																		 * payment
																																		 */);
		FndtMsgPaymentType.setExtension(fndtMsgRoot, extnSectionXbean);

		final XmlCursor xmlcur = fndtMsgRoot.newCursor();
		xmlcur.toStartDoc();
		fndtMsgRoot = (XmlObjectBase) xmlcur.getObject();
		xmlcur.dispose();

		return fndtMsgRoot;
	}// EOM

	private final PreparedStatement prepareUpdatePdoStatement(final Connection conn, final PDO pdo, final String sLastSaveTimestamp,
			final String sPersistenceTimestamp) throws SQLException, IOException {

		// if the pdo does not have any modified fields return null
		final Collection<PaymentFieldInterface> setModifiedFields = pdo.getModifiedFields();
		if (setModifiedFields == null || setModifiedFields.isEmpty())
			return null;
		// else
		final List listNewValues = new ArrayList();

		final StringBuilder builder = new StringBuilder();

		// if the xml message was changed add the update clasue
		boolean bCurrentXmlMsgModified = false, bOrigXmlMsgModified = (pdo.hadXmlChanged(DASInterface.ORIG_XML_MSG_KEY)
				|| pdo.hadXmlChanged(XmlLocationType.XML_ORIG_MSG_EXTN.name()) || pdo.isConjoined());

		if (bOrigXmlMsgModified)
			builder.append(" XML_ORIG_MSG = ?,");
		if (bCurrentXmlMsgModified = (pdo.hadXmlChanged(DASInterface.CURRENT_XML_MSG_KEY) || pdo.hadXmlChanged(XmlLocationType.XML_MSG_EXTN.name())))
			builder.append(" XML_MSG = ?,");

		// retreive the pdo's list of modified fields, iterate over them and construct the insert statement
		String sFieldId = null;

		for (PaymentFieldInterface paymentField : setModifiedFields) {

			sFieldId = this.getPaymentFieldId(paymentField);

			// if the field id is null (xml field with no copy to relational field entry skip
			if (sFieldId == null)
				continue;

			builder.append(paymentField.getFieldId()).append(" = ?,");

			listNewValues.add(paymentField.get());
		}// EO while there are more modified fields to add to the pdo

		// delete the tailing comma
		builder.deleteCharAt(builder.length() - 1);

		final String sStatement = "UPDATE MINF SET " + builder.append(" WHERE P_MID = ? AND P_TIME_STAMP = ?").toString();

		final PreparedStatement pdoUpdateStatement = conn.prepareStatement(sStatement);

		logger.info("message {} update query is {}", pdo.getMID(), sStatement);

		int iCounter = 1;

		// Note: no need to set the timestamp explicitly as it was set into the pdo prior to this method's invocation
		// pdoUpdateStatement.setObject(iCounter++, sPersistenceTimestamp) ;

		// set the xml columns in the statement
		if (bOrigXmlMsgModified)
			this.bindXmlColumn(iCounter++, pdo, XmlLocationType.XML_ORIG_MSG, pdoUpdateStatement);
		if (bCurrentXmlMsgModified)
			this.bindXmlColumn(iCounter++, pdo, XmlLocationType.XML_MSG, pdoUpdateStatement);

		// iterate over the list again, this time to set the values
		for (Object oValue : listNewValues) {
			if ((oValue instanceof java.util.Date) && !(oValue instanceof Time))
				oValue = new java.sql.Timestamp(((java.util.Date) oValue).getTime());
			setObject(pdoUpdateStatement, iCounter++, oValue);
		}// EO while there are more modified fields to add to the pdo

		// add the mid and time stamp where clause binding values
		setObject(pdoUpdateStatement, iCounter++, pdo.getMID());
		setObject(pdoUpdateStatement, iCounter++, sLastSaveTimestamp);

		return pdoUpdateStatement;
	}// EOM

	private PreparedStatement[] prepareTemplateUnchangedFields(Connection conn, PreparedStatement[] templateUnchangedFieldsArr, final PDO pdo)
			throws SQLException {

		Feedback feedback;

		String mid = pdo.getMID();
		Integer partitionID = pdo.getIsHistory();
		String templateUnchangedFields = pdo.getTemplateUnchangedFields();
		if (templateUnchangedFields != null) {
			if (templateUnchangedFieldsArr == null) {
				templateUnchangedFieldsArr = new PreparedStatement[2];
				templateUnchangedFieldsArr[TEMPLATE_UNCHANGED_FIELDS_DELETE] = conn.prepareStatement(TEMPLATE_UNCHANGED_FIELDS_DELETE_STATEMENT);
				templateUnchangedFieldsArr[TEMPLATE_UNCHANGED_FIELDS_INSERT] = conn.prepareStatement(TEMPLATE_UNCHANGED_FIELDS_INSERT_STATEMENT);
			}

			GlobalUtils.setObject(templateUnchangedFieldsArr[TEMPLATE_UNCHANGED_FIELDS_DELETE], 1, mid);
			GlobalUtils.setObject(templateUnchangedFieldsArr[TEMPLATE_UNCHANGED_FIELDS_DELETE], 2, partitionID);
			templateUnchangedFieldsArr[TEMPLATE_UNCHANGED_FIELDS_DELETE].addBatch();

			if (templateUnchangedFields.length() > 1) {
				GlobalUtils.setObject(templateUnchangedFieldsArr[TEMPLATE_UNCHANGED_FIELDS_INSERT], 1, mid);
				GlobalUtils.setObject(templateUnchangedFieldsArr[TEMPLATE_UNCHANGED_FIELDS_INSERT], 2, templateUnchangedFields);
				GlobalUtils.setObject(templateUnchangedFieldsArr[TEMPLATE_UNCHANGED_FIELDS_INSERT], 3, partitionID);
				templateUnchangedFieldsArr[TEMPLATE_UNCHANGED_FIELDS_INSERT].addBatch();
			}
		}

		return templateUnchangedFieldsArr;
	}

	private final String getPaymentFieldId(final PaymentFieldInterface paymentField) {
		//

		String sFieldId = paymentField.getFieldId();

		if (FieldType.isXmlType(paymentField.getFieldType())) {
			final String sCopyToFieldId = paymentField.getCopyToLocation();
			sFieldId = (sCopyToFieldId != null ? sCopyToFieldId : null);
		}// EO if the field is an xml field
		else if (FieldType.RELATIONAL == paymentField.getFieldType() || FieldType.RELATIONAL_MONITOR == paymentField.getFieldType()) {
			sFieldId = paymentField.getFieldId();
		} else
			sFieldId = null;

		//

		return sFieldId;
	}// EOM

	/**
	 * 
	 * Sep 8, 2009 Guys
	 * 
	 * @param iColIndex
	 * @param pdo
	 * @param sXmlType
	 * @param ps
	 * @param sPossibleLinkXmlType
	 *            document id whose xml might be the same as the sXmlType's in which case, the latter's should not be stored<br>
	 *            For instance, of the current and orig xml document reference point to the same heap instance the current xml should not be stored
	 * @throws SQLException
	 * @throws IOException
	 */
	private final void bindXmlColumn(final int iColIndex, final PDO pdo, final XmlLocationType enumXmlLocation, final PreparedStatement ps)
			throws SQLException, IOException {

		final XmlObjectBase root = enumXmlLocation.getXmlDocument(pdo);

		// if the root is null explicitly set a null value
		if (root == null) {
			setObject(ps, iColIndex, root);
		} else {

			final XmlObject xbeanRoot = this.configureFndtMsg(pdo, enumXmlLocation == XmlLocationType.XML_ORIG_MSG);

			m_dao.ms_DBType.getXmlDao().bindXmlColumn(iColIndex, xbeanRoot, ps);

		}// EO if there was an xml root

	}// EOM

	@Override
	public String getPDOOwner(final PDO pdo) {
		final WebSessionInfo webSessionInfo = CacheKeys.WebSessionInfoKey.getSingle(pdo.getOwnerContextId());
		return (webSessionInfo == null ? "User Id Was Not Found" : webSessionInfo.getUserID());
	}// EOM

	/*
	 * public final XmlObjectBase transformPDO(final String sMID, final PaymentType enumOutputPaymentType, final XmlLocationType enumXmlLocationType,
	 * final boolean bConstructExtension) throws Throwable{
	 * 
	 * 
	 * 
	 * final String sXmlLocationType = enumOutputPaymentType.name() ;
	 * 
	 * final PDO pdo = PaymentDataFactory.load(sMID);
	 * 
	 * //if the pdo does not exist, throw an exception if(pdo == null) ErrorAuditUtils.onError(ProcessErrorConstants.PDONoMinfRecord,
	 * IllegalArgumentException.class, sMID) ;
	 * 
	 * //rertieve the payment and extension groups from the map and set elements //in the response
	 * 
	 * final XmlMetadata paymentXmlmetadata = pdo.getXmlMetadata(sXmlLocationType) ;
	 * 
	 * //create the payment field final XmlObjectBase rootDcoument = (XmlObjectBase) enumOutputPaymentType.newInstance() ; final String
	 * sResponseNamespace = enumOutputPaymentType.getSchemaNamespace() ;
	 * 
	 * XmlObjectBase currentPathElement = null, extensionGroupElement = null ; //extensionElement = null
	 * 
	 * //create the payment element currentPathElement = this.getOrCreateImmidiateChild(rootDcoument, "payment", 0, sResponseNamespace, null) ;
	 * //create the document element final PaymentType enumPaymentType = paymentXmlmetadata.getPaymentType() ; currentPathElement =
	 * this.getOrCreateImmidiateChild(currentPathElement, enumPaymentType.getLocalPart(), 0, enumPaymentType.getSchemaNamespace(),null) ; //set the
	 * xml in the document element currentPathElement.set(paymentXmlmetadata.getXml()) ;
	 * 
	 * //if the bConstructExtension is true consturct the extension element if(bConstructExtension) {
	 * 
	 * //create the extension element
	 * 
	 * final List<LogicalFieldsXpath> listXmlGroups = new ArrayList<LogicalFieldsXpath>() ; final List<LogicalFieldsXpath> listGroupChildren = new
	 * ArrayList<LogicalFieldsXpath>() ; String sLogicalFieldGroupId, sLogicalFieldsChildId = null ; Object oChildValue = null ;
	 * 
	 * final PaymentType EXTNPaymentType = PaymentType.valueOf(PaymentType.PT_EXTN) ; final String sExtensionSchemaNs =
	 * EXTNPaymentType.getSchemaNamespace() ;
	 * 
	 * //retreive all groups for the extension xml CacheKeys.LogicalFieldsXPathGroupsKey.get(listXmlGroups, EXTNPaymentType, sXmlLocationType) ;
	 * 
	 * //iterate over the the groups and for each group, retrieve all the children, //and construct the path to each children of the pdo's
	 * corresponding value was not null for(LogicalFieldsXpath groupParentXmlMetadata : listXmlGroups) {
	 * 
	 * sLogicalFieldGroupId = groupParentXmlMetadata.getFieldLogicalId() ;
	 * 
	 * //create the path to the group extensionGroupElement = this.getOrCreateXmlNode(groupParentXmlMetadata, rootDcoument, sExtensionSchemaNs, false)
	 * ;
	 * 
	 * //retrieve the children CacheKeys.LocicalFieldsXpathChildrenKey.get(listGroupChildren, sLogicalFieldGroupId, EXTNPaymentType, sXmlLocationType)
	 * ;
	 * 
	 * //iterate over the children and construct the xml hierarchy for each which contains pdo value for(LogicalFieldsXpath childXmlMetadata :
	 * listGroupChildren) {
	 * 
	 * sLogicalFieldsChildId = childXmlMetadata.getFieldLogicalId() ;
	 * 
	 * oChildValue = pdo.get(sLogicalFieldsChildId) ;
	 * 
	 * // In case the value is null, check if the child's type is MEMBER; // If not, continue. if(oChildValue == null) { LogicalFields
	 * logicalFieldsChild = LogicalFieldsIdKey.getSingle(sLogicalFieldsChildId) ;
	 * 
	 * // This child is from field type MEMBER, which means that its value // should be taken from a class member in the PDO which is either // a list
	 * or some object. // e.g. M_FC_LINE stands for either 'm_listMESSAGERATES_DR' // or 'm_listMESSAGERATES_CR' from the PDO, where each one // of
	 * them stands for a list of message rates, (MESSAGERATES table). if(logicalFieldsChild != null && logicalFieldsChild.getFieldType() ==
	 * FieldType.MEMBER) { oChildValue = this.getTransformedValueForMEMBERTypeField(logicalFieldsChild.getLocation(), childXmlMetadata.getFieldType(),
	 * pdo); if(oChildValue == null) continue ; }
	 * 
	 * else { continue; } }
	 * 
	 * LogicalFields logicalFieldsChild = LogicalFieldsIdKey.getSingle(sLogicalFieldsChildId);
	 * 
	 * // This is a list member field in the PDO. if( logicalFieldsChild.getFieldType() == FieldType.MEMBER && childXmlMetadata.getFieldType() ==
	 * FieldType.XML_MULTI) { currentPathElement = getOrCreateXmlNode(childXmlMetadata, extensionGroupElement, sExtensionSchemaNs, true) ; String
	 * sTagName = childXmlMetadata.getTagName(); QName qName = new QName(sResponseNamespace, sTagName);
	 * 
	 * if(oChildValue != null) { List list = (List)oChildValue;
	 * 
	 * for(int i=0; i<list.size(); i++) { XmlObjectBase xmlObjectBase = (XmlObjectBase)currentPathElement.get_store().add_element_user(qName) ;
	 * xmlObjectBase.setObjectValue(list.get(i)); } } }
	 * 
	 * else { //else if there was a value, constsruct the xml hierarchy currentPathElement = this.getOrCreateXmlNode(childXmlMetadata,
	 * extensionGroupElement, sExtensionSchemaNs, false) ;
	 * 
	 * //if the current path element was valid (not null) set the value if(currentPathElement == null) {
	 * logger.warn("xpath [{}] to field {} is not valid", childXmlMetadata.getFieldPath(), sLogicalFieldsChildId); continue; }//EO if the path was not
	 * valid
	 * 
	 * //else if the path was valid set the value in the node logger.debug("Output Mapping of field {} with value {}", sLogicalFieldsChildId,
	 * oChildValue); //the toString() is a tempoarary workaround for bigdecimal initialisation issue
	 * 
	 * logicalFieldsChild.getDataType().setXbeanValue(currentPathElement, oChildValue) ;
	 * 
	 * } }//EO while there are more children for the given extension }//EO while there are more extension groups }//EO if the context
	 * bConstructExtension was true
	 * 
	 * //trace the output xml if( { logger.trace("final output xml is:n{}", rootDcoument); }
	 * 
	 * 
	 * 
	 * return rootDcoument ; }//EOM
	 */

	private final XmlObjectBase getOrCreateXmlNode(final LogicalFieldsXpath logicalFieldXmlMetadata, final XmlObjectBase rootElement,
			final String sNamespace, boolean bIsMemberAndMultiChild, final PaymentType enumTargetPaymentType) {
		return getOrCreateXmlNode(logicalFieldXmlMetadata.getFieldPath(), logicalFieldXmlMetadata.getTagName(), rootElement, sNamespace,
				bIsMemberAndMultiChild, enumTargetPaymentType);
	}

	private final XmlObjectBase getOrCreateXmlNode(final LogicalFieldsXpath logicalFieldXmlMetadata, final XmlObjectBase rootElement,
			final String sNamespace, boolean bIsMemberAndMultiChild) {
		return getOrCreateXmlNode(logicalFieldXmlMetadata.getFieldPath(), logicalFieldXmlMetadata.getTagName(), rootElement, sNamespace,
				bIsMemberAndMultiChild, null /* targetPaymentType */);
	}

	@Override
	public final XmlObjectBase getOrCreateXmlNode(String sPathToTargetNode, final String sTagName, final XmlObjectBase rootElement,
			final String sNamespace, boolean bIsMemberAndMultiChild) {
		return getOrCreateXmlNode(sPathToTargetNode, sTagName, rootElement, sNamespace, bIsMemberAndMultiChild, null /* targetPaymentType */);
	}// EOM

	/**
     * 
     */
	public final XmlObjectBase getOrCreateXmlNode(String sPathToTargetNode, final String sTagName, final XmlObjectBase rootElement,
			final String sNamespace, boolean bIsMemberAndMultiChild, final PaymentType enumTargetPaymentType) {
		//

		// final String ANY_ATTRIBUTE_PATH = "@*" ;
		// remove any leading '/'s
		int iSubStringStartIndex = 0;
		if (sPathToTargetNode.equals(ServerConstants.EMPTY_STRING))
			return rootElement;
		else if (sPathToTargetNode.length() > 1 && sPathToTargetNode.charAt(1) == '/')
			iSubStringStartIndex = 2;
		else if (sPathToTargetNode.charAt(0) == '/')
			iSubStringStartIndex = 1;

		if (bIsMemberAndMultiChild) {
			sPathToTargetNode = sPathToTargetNode.replaceAll("//", "/");
			if (sPathToTargetNode.endsWith(sTagName)) {
				sPathToTargetNode = sPathToTargetNode.substring(0, (sPathToTargetNode.length() - sTagName.length() - 1));
			}// EO if sPathToTargetNode.endsWith(sTagName)
		}// EO if member or multi

		final String[] arrFullPathToChildNode = sPathToTargetNode.substring(iSubStringStartIndex).split("/");
		final int iLength = arrFullPathToChildNode.length;
		String sCurrentNodeName = null;
		XmlObjectBase currentPathElement = rootElement;

		String sLastNodeName = null;
		for (int i = 0; i < iLength; i++) {
			sCurrentNodeName = arrFullPathToChildNode[i];
			// System.out.println("*************** current node="+sCurrentNodeName);
			// if(sCurrentNodeName.equals(ANY_ATTRIBUTE_PATH)) sCurrentNodeName = sTagName ;
			// if the element is '.' then continue
			// else if the node name is '*' and it is the last element in the array continue
			if (sCurrentNodeName.charAt(0) == '.' || (sCurrentNodeName.charAt(0) == '*' && i == iLength - 1))
				continue;

			currentPathElement = getOrCreateImmidiateChild(currentPathElement, sCurrentNodeName, 0, sNamespace, sTagName, enumTargetPaymentType,
					(sCurrentNodeName.equals(sLastNodeName)));
			sLastNodeName = sCurrentNodeName;
		}// EO while there are more path items

		//
		return currentPathElement;
	}// EOM

	@Override
	public final void removePaymentField(final PDO pdo, final boolean removeFromDataMap, final String... arrLogicalIds) {

		//

		LogicalFields logicalFieldsEntry = null;
		LogicalFieldsXpath logicalFieldsXpath = null, parentLogicalFieldXpath = null;
		PaymentFieldInterface paymentField = null;
		FieldType enumFieldType = null;
		HashMap mapLogicalFieldsXPathCache = null;

		String sXPath = null, sXqueryTemplate = null;
		boolean bIsXmlGroup = false, bIsXmlType = false;
		XmlMetadata xmlMetadata = null;
		final String sDefaultXmlLocationType = CURRENT_XML_KEY;
		PaymentType enumPaymentType = null, enumLastPaymentType = null, enumPmntSectionPaymentType = pdo.getPaymentType(sDefaultXmlLocationType);
		XmlCursor xmlcur = null, rootDocumentXmlcur = null;

		final Map<Object, PaymentFieldInterface> mapData = pdo.getDataMap();

		for (String sLogicalFieldId : arrLogicalIds) {

			logicalFieldsEntry = (sLogicalFieldId.indexOf('^') != -1 ? CacheKeys.UserDefinedFieldsIdKey.getSingle(sLogicalFieldId)
					: CacheKeys.LogicalFieldsIdKey.getSingle(sLogicalFieldId));

			if (removeFromDataMap)
				paymentField = pdo.removePaymentField(sLogicalFieldId);
			else
				paymentField = mapData.get(sLogicalFieldId);

			if (logicalFieldsEntry == null) {
				final String sErrorMsg = ErrorAuditUtils.getErrorText(ProcessErrorConstants.PDOLogicalFieldNotFound, pdo.getMID(), sLogicalFieldId);
				logger.error(sErrorMsg);
				return;
			}// EOM

			enumFieldType = logicalFieldsEntry.getFieldType();

			bIsXmlGroup = enumFieldType == FieldType.XML_GROUP;

			// if the field was xml and the payment field was null
			// rertieve the field from logical fields xpath cache
			// moreover, if the field metadata indicated that it was of xml type but the actual field type in the payment field was
			// not xml then there was no logical fields xpath which means that the field was created as derived and therefore the loop should skip
			if ((!(bIsXmlType = FieldType.isXmlType(enumFieldType)) || (bIsXmlType && paymentField != null && !FieldType.isXmlType(paymentField
					.getFieldType()))) && !bIsXmlGroup)
				continue;
			// else

			// if the location of the location field is not the same as the defualt location, retrieve the value of the payment type
			// from the pdo's location's xmlmetadata (e.g. extension xml fields which are not stored in the pdo as payment fields)
			// if the payment field was found use its payment type as it might be dissimilar to that of the payment (e.g. extension)
			if (paymentField != null)
				enumPaymentType = ((XmlPaymentField) paymentField).getPaymentType();
			else {
				if (!logicalFieldsEntry.getLocation().equals(sDefaultXmlLocationType))
					enumPaymentType = pdo.getPaymentType(logicalFieldsEntry.getLocation());
				else
					enumPaymentType = enumPmntSectionPaymentType;
			}// EO if the payment field was not found

			if (enumLastPaymentType == null || enumLastPaymentType != enumPaymentType) {

				// if the enumLastPaymentType is not null (there was a previous payment type,
				// dispose of the xmlcursor prior to creating a new one
				if (enumLastPaymentType != null && xmlcur != null)
					xmlcur.dispose();
				if (enumLastPaymentType != null && rootDocumentXmlcur != null)
					rootDocumentXmlcur.dispose();

				// cache the current payment type as the last payment type
				enumLastPaymentType = enumPaymentType;

				xmlMetadata = pdo.getXmlMetadata(logicalFieldsEntry.getLocation());
				mapLogicalFieldsXPathCache = CacheKeys.LogicalFieldsXPathKey.getSingle(enumPaymentType);

				sXqueryTemplate = "declare default element namespace '" + enumPaymentType.getSchemaNamespace() + "'; $this";

				xmlcur = xmlMetadata.getXml().newCursor();
				rootDocumentXmlcur = xmlMetadata.getXml().newCursor();

				// navigate to immediate parent so as to support full path from parent xpath setup for DB queries
				xmlcur.toParent();
			}// EO if the logical fields xpath map for the given payment type was not yet initialized

			if (paymentField != null) {

				// remove the linked field if any
				paymentField.removeLinkedPaymentField();

				logicalFieldsXpath = ((XmlPaymentField) paymentField).getLogicalFieldsXPath();

				// retreive the parent xpath							
				parentLogicalFieldXpath = (LogicalFieldsXpath) mapLogicalFieldsXPathCache.get(logicalFieldsXpath.getPathParentId());
			} else if (enumFieldType == FieldType.XML_GROUP) {
				if (mapLogicalFieldsXPathCache == null)
					mapLogicalFieldsXPathCache = CacheKeys.LogicalFieldsXPathKey.getSingle(enumPaymentType);

				// get the logical field
				logicalFieldsXpath = (LogicalFieldsXpath) mapLogicalFieldsXPathCache.get(sLogicalFieldId);
			} else
				continue;

			if (logicalFieldsXpath == null) {
				logger.error("No xpath for logcal field - " + sLogicalFieldId);
				continue;
			}// EO if no logical fields xpath defintion was found

			// bookmark
			xmlcur.push();
			xmlcur.getObject();
			sXPath = (parentLogicalFieldXpath == null ? "" : parentLogicalFieldXpath.getFieldPath()) + logicalFieldsXpath.getFieldPath();

			// if the element is XML_MULTI then the xpath would point to the parent of the actual element
			// thus the tag name shall have to be appended to the path
			if (FieldType.XML_MULTI == logicalFieldsXpath.getFieldType())
				sXPath = sXPath + '/' + logicalFieldsXpath.getTagName();

			// get the xpath and execute it on the current document to get the document
			xmlcur.selectPath(sXqueryTemplate + sXPath);

			while (xmlcur.toNextSelection()) {
            	//  xmlcur.removeXml() ;
            	boolean forceRemove = false;
            	// For multi fields that are parents force remove the parent with it's children
            	if(enumFieldType == FieldType.XML_MULTI && logicalFieldsXpath.getPathParentInd()) {
            		forceRemove = true;
            	}

            	this.pruneXml(xmlcur, rootDocumentXmlcur, true /*bRemoveFromXml*/, forceRemove) ;
            }//EO while more elements are available from the xpath selection
			// this part should remove the empty groups after all the elements were removed.
			// boolean shouldRemove =xmlcur.toParent() && (xmlcur.getName() == null || !xmlcur.getName().getLocalPart().equals("Document")) &&
			// !xmlcur.toChild(0);
			// while (shouldRemove)
			// {
			// xmlcur.removeXml();
			// xmlcur.toParent();
			// shouldRemove =xmlcur.toParent() && (xmlcur.getName() == null || !xmlcur.getName().getLocalPart().equals("Document")) &&
			// !xmlcur.toChild(0);
			// }

            //this.pruneXml(xmlcur, rootDocumentXmlcur, true /*bRemoveFromXml*/, false /*bForceRemove*/) ; 
			// navigate to the parent and remove the object
			// if(!xmlcur.toParent()) continue ;

			// pop to the bookmark
			xmlcur.pop();

			List<LogicalFieldsXpath> listGroupChildren = CacheKeys.LocicalFieldsXpathChildrenKey.get(null, sLogicalFieldId, enumPaymentType,
					CURRENT_XML_MSG_KEY);

			if (listGroupChildren != null) {
				for (LogicalFieldsXpath logicalFieldsXpathChild : listGroupChildren) {
					mapData.remove(logicalFieldsXpathChild.getFieldLogicalId());
				}
			}
		}// EO while there are more fields to remove

		if (xmlcur != null)
			xmlcur.dispose();
		//
	}// EOM

	@Override
	public final void severConjoinedLinks(final PDO pdo) {
		this.severConjoinedLinks(pdo, true/* bReconfigurePaymentFields */);
	}// EOM

	public final void severConjoinedLinks(final PDO pdo, final boolean bReconfigurePaymentFields) {

		try {
			// the links removal shall be performed on the current xml fields only as the removeLinkedPaymentField() shall clear the links from
			// the linked payment field as well as from the actual one the method was invoked ons
			final String sDocumentID = CURRENT_XML_MSG_KEY;

			// if the bReconfigurePaymentFields is true, iterate over the pdo's payment fields and removed
			// the links
			if (bReconfigurePaymentFields) {

				// Creates new Map which is composed from the PDO data map, in order to prevent ConcurrentModificationException
				// while irterating on it and remove data from it.
				final Map<Object, PaymentFieldInterface> tempCurrentMapData = new HashMap<Object, PaymentFieldInterface>(pdo.getDataMap());

				PaymentFieldInterface<?> paymentField = null;

				// Iterates on the TEMP pdo data map, while removing entries from the the ORIGINAL map in the PDO.
				for (Map.Entry<Object, PaymentFieldInterface> entry : tempCurrentMapData.entrySet()) {

					paymentField = entry.getValue();

					try {
                        if(paymentField != PaymentField.PLACE_HOLDER && FieldType.isXmlType(paymentField.getFieldType())
                        		&& ((XmlPaymentField)paymentField).getDocumentId().equals(sDocumentID)) {
                              //remove the paymentField's link 
                              paymentField.removeLinkedPaymentField(); 
                        }//EO if the field was an xml field realted to the transformation document
                    } catch(Throwable t) {
                         logger.error("severConjoinedLinks RL payment field : " + ((null == paymentField) ? "" : paymentField.getFieldId()));
                         paymentField.removeLinkedPaymentField();
                    }					
				}// EO while there are more payment fields in the pdo
			}// EO if the bReconfigurePaymentFields was true

			// override the current orig xml metadata with a deep copy of the xml document as currently the xmlmsg and the orig are sharing the same
			// document
			final XmlMetadata origMsgXmlMetadata = pdo.getXmlMetadata(ORIG_XML_MSG_KEY);
			XmlCursor xmlcur = origMsgXmlMetadata.getXml().newCursor();
			XmlObjectBase pmntXBean = (XmlObjectBase) PaymentType.m_contextXchemaTypeLoader.parse(xmlcur.getDomNode(), null, null);
			xmlcur.dispose();
			xmlcur = pmntXBean.newCursor();
			xmlcur.toFirstChild();
			pmntXBean = (XmlObjectBase) xmlcur.getObject();
			xmlcur.dispose();

			origMsgXmlMetadata.setXml(pmntXBean);

			// retrieve the orig extension section and configure this as well
			final XmlMetadata origMsgExtnMetadta = pdo.getXmlMetadata(XmlLocationType.XML_ORIG_MSG_EXTN.name());
			xmlcur = origMsgExtnMetadta.getXml().newCursor();
			XmlObjectBase extnXBean = (XmlObjectBase) PaymentType.m_contextXchemaTypeLoader.parse(xmlcur.getDomNode(), null, null);
			xmlcur.dispose();
			xmlcur = extnXBean.newCursor();
			xmlcur.toFirstChild();
			extnXBean = (XmlObjectBase) xmlcur.getObject();
			xmlcur.dispose();

			origMsgExtnMetadta.setXml(extnXBean);

			// finally, clear the INITIAL_CREATE_STATE monitor flag so as to indicate that the pdo is no longer in conjoined mode
			// as well as to indicate that subsequent pdo loads would not share the xml document
			pdo.set(MF_INITIAL_CREATE, EPMTY_FLAG);
		} catch (Exception e) {
			ExceptionController.getInstance().handleException(e, this);
		}// EO catch block

	}// EOM

	@Override
	public final XmlObjectBase transformToXml(final String sMID, final PaymentType enumOutputPaymentType, final XmlLocationType enumXmlLocationType,
			final Map mapCustomisations, final Object oSkelletonRootXml) throws Throwable {

		final TreeCursorInterface<LogicalFieldsXpath> fieldsCursor = new LogicalFieldsXPathCursor<LogicalFieldsXpath>(enumOutputPaymentType,
				enumXmlLocationType, mapCustomisations);
		return this.transformToXml(sMID, mapCustomisations, fieldsCursor, oSkelletonRootXml);
	}// EOM

	public final XmlObjectBase deprecatedTransformToXml(final String sMID, final PaymentType enumOutputPaymentType,
			final XmlLocationType enumXmlLocationType, final Map mapCustomisations, final Object oSkelletonRootXml) throws Throwable {

		// first load the pdo and it does not exist, an error log and throw an exception
		final PDO pdo = PaymentDataFactory.load(sMID);
		// if the pdo does not exist, throw an exception
		if (pdo == null || pdo.isEmpty()) {
			ErrorAuditUtils.onError(ProcessErrorConstants.PDONoMinfRecord, sMID, IllegalArgumentException.class);
		}// EO if the load had failed
			// else

		// /if the skelletonRootXml is null, create a new instance of the root element using the target payment type
		XmlObjectBase xmlDocRoot = null;
		if (oSkelletonRootXml == null)
			xmlDocRoot = enumOutputPaymentType.newInstance();
		else {
			xmlDocRoot = PaymentInputSourceType.reverseValueOf(xmlDocRoot).parse(enumXmlLocationType, oSkelletonRootXml, pdo);
		}// EO if a root skelleton was provided

		// retrieve the output payment type's groups and construct the new xml document using the groups' children
		final List<LogicalFieldsXpath> listXmlGroups = new ArrayList<LogicalFieldsXpath>();
		CacheKeys.LogicalFieldsXPathGroupsKey.get(listXmlGroups, enumOutputPaymentType, enumXmlLocationType.name());
		this.deprecatedTransformToXmlInner(pdo, xmlDocRoot, enumOutputPaymentType, enumOutputPaymentType, enumXmlLocationType, mapCustomisations,
				listXmlGroups);

		// navigate to the parent (document start)
		final XmlCursor xmlcur = xmlDocRoot.newCursor();
		xmlcur.toParent();
		xmlDocRoot = (XmlObjectBase) xmlcur.getObject();
		xmlcur.dispose();

		return xmlDocRoot;

	}// EOM*/

	@Override
	public final XmlObjectBase transformToXml(final String sMID, final Map mapCustomisations,
			final TreeCursorInterface<LogicalFieldsXpath> fieldsCursor, final Object oSkelletonRootXml) throws Throwable {

		// first load the pdo and it does not exist, an error log and throw an exception
		final PDO pdo = PaymentDataFactory.load(sMID);
		// if the pdo does not exist, throw an exception
		if (pdo == null || pdo.isEmpty()) {
			ErrorAuditUtils.onError(ProcessErrorConstants.PDONoMinfRecord, sMID, IllegalArgumentException.class);
		}// EO if the load had failed
			// else

		final PaymentType enumOutputPaymentType = fieldsCursor.getTargetPaymentType();
		final XmlLocationType enumXmlLocationType = fieldsCursor.getInitialXmlLocationType();

		// /if the skelletonRootXml is null, create a new instance of the root element using the target payment type
		XmlObjectBase xmlDocRoot = null;
		if (oSkelletonRootXml == null)
			xmlDocRoot = enumOutputPaymentType.newInstance();
		else {
			xmlDocRoot = PaymentInputSourceType.reverseValueOf(oSkelletonRootXml).parse(enumXmlLocationType, oSkelletonRootXml, pdo);
		}// EO if a root skelleton was provided

		this.transformToXmlInner(pdo, xmlDocRoot, mapCustomisations, fieldsCursor);

		// navigate to the parent (document start)
		final XmlCursor xmlcur = xmlDocRoot.newCursor();
		xmlcur.toParent();
		xmlDocRoot = (XmlObjectBase) xmlcur.getObject();
		xmlcur.dispose();

		return xmlDocRoot;

	}// EOM

	/**
	 * TODO: if the target payment type is the same as the xml residing in the locationType formal argument, return the pdo xml document --> dont
	 * remember what this means TODO: multi groups --> DONE TODO: ORIG section --> DONE TODO: merge : if the xml document already exists within the
	 * pdo do not store the current one !!!! --> DONE TODO: msgNotes getNSet error (only to compile schema) --> DONE TODO: add the new interfaces as a
	 * msg type with the same charateristics of their XML_TYPE super type (unless they are already defined in the msg types table) --> this should be
	 * done in the msg types query --> DONE TODO: support xml skelleton as an base document instead of using the paymentType.newInstance() --> DONE
	 * TODO: change the document handling code to: --> DONE
	 * 
	 * if group xml type is empty use the pdo location as is else if group xml type is not empty then if group has children which are infact nested
	 * groups then use children as groups using the pdo location as the xml location else if group does not have children use group xml types as
	 * groups using the pdo location as the xml location
	 * 
	 * TODO: Question: in PDO list members merge what should I do? clear and recreate? actual merge? TODO: convert msgFees to XMLBEANS TODO: JPA
	 * member TODO: delete msgFees & msgNotes jpas
	 * 
	 * Jan 27, 2010 guys
	 * 
	 * @param pdo
	 * @param xmlDocRoot
	 * @param enumTargetPaymentType
	 * @param enumCurrentDocumentType
	 * @param enumXmlLocationType
	 * @param listXmlGroups
	 * @return
	 * @throws Throwable
	 */
	private final XmlObjectBase transformToXmlInner(final PDO pdo, final XmlObjectBase xmlDocRoot, /* PaymentType enumTargetPaymentType, */
	/* PaymentType enumCurrentDocumentType, XmlLocationType enumXmlLocationType, */final Map mapCustomisations,
			final TreeCursorInterface<LogicalFieldsXpath> fieldsCursor) throws Throwable {

		XmlObjectBase newGroupPathElement = null, newChildPathElement = null, existingChildPathElement = null, newXmlDocument = null, multiOccurrencePathElement = null;
		PaymentType enumDocumentChildPaymentType = null, enumDocumentChildTargetPaymentType = null;
		XmlLocationType childDocumentLocationType = null;

		LogicalFields logicalFieldsGroup = null, logicalFieldsChild = null;

		String sPDOXmlLocation = null, sGroupXmlType = null, sGroupLogicalFieldId = null, sChildLogicalFieldId = null, sChildNodeName = null;

		// as in nested documents the namespace can differ from the target namespace which is the complete document
		// namespace, use the payemnt type's namespace for the construction of the node but the target namesapce for the
		// cache metadata rertievals
		final PaymentType enumCurrentDocumentType = fieldsCursor.getCurrPaymentType();
		final String sCurrentDocumentNamespace = enumCurrentDocumentType.getSchemaNamespace();

		final PaymentType enumTargetPaymentType = fieldsCursor.getTargetPaymentType();
		final String sXmlLocationType = fieldsCursor.getCurrXmlLocationType().name();

		boolean isMultiOccurreneElement = false, bIsGroupMultiOccurreneElement = false, bIsMember = false;
		Object oNodeValue = null, oPDOListMemberValue = null;
		QName multiOccurrenceChildName = null;
		XmlObject[] arrNodes = null;
		XmlMultiOccurencePaymentField multiPaymentField = null;
		DataType enumChildDataType = null;
		XmlCursor tidyingCursor = null;
		LogicalFieldsXpath groupLogicalFieldsXpath = null, childLogicalFieldsXpath = null;
		Node currGroupNode = null;
		final String sXqueryTemplate = "declare default element namespace '" + enumCurrentDocumentType.getSchemaNamespace() + "'; .";
		XmlObject pdoCorrespondingDocument = pdo.getXml(sXmlLocationType);

		// create a tidying comparison cursor for the root element
		final XmlCursor newRootXmlCur = xmlDocRoot.newCursor();

		while (fieldsCursor.hasNext()) {

			groupLogicalFieldsXpath = fieldsCursor.next();
			if (groupLogicalFieldsXpath == null)
				continue;

			sGroupLogicalFieldId = groupLogicalFieldsXpath.getFieldLogicalId();

			logicalFieldsGroup = CacheKeys.LogicalFieldsIdKey.getSingle(sGroupLogicalFieldId);

			// store the member indication found in the logical fields jpa rather than the xpath meta data which could be overwritten with logical
			// fields xpath
			// definitions
			bIsMember = logicalFieldsGroup.getFieldType() == FieldType.MEMBER;
			bIsGroupMultiOccurreneElement = FieldType.isXmlMulti(groupLogicalFieldsXpath.getFieldType());

			// create the group element
			newGroupPathElement = this.getOrCreateXmlNode(groupLogicalFieldsXpath, xmlDocRoot, sCurrentDocumentNamespace,
					bIsGroupMultiOccurreneElement/* member nor multi */, enumCurrentDocumentType);

			// if the field is member, branch to member transformation
			if (bIsMember && bIsGroupMultiOccurreneElement) {

				oPDOListMemberValue = this.processPDOMember(logicalFieldsGroup.getLocation(), true /* bIsMulti */, pdo, true/* bMarshall */,
						newGroupPathElement, groupLogicalFieldsXpath, enumCurrentDocumentType,
						(PDOListMemberHandlerInterface) (mapCustomisations == null ? null : mapCustomisations.get(logicalFieldsGroup.getLocation())));

				if (oPDOListMemberValue == null || !newGroupPathElement.getDomNode().hasChildNodes()) {
					tidyingCursor = newGroupPathElement.newCursor();
					tidyingCursor.removeXml();
					tidyingCursor.dispose();
				}// EO if there were no reecords
				continue;
			}// if the field was a member ;

			// if the group element is a document then
			// if group xml type is empty
			// use the pdo location as is
			// else if group xml type is not empty then
			// if group has children which are infact nested groups then
			// use children as groups using the pdo location as the xml location
			// else if group does not have children
			// use group xml types as groups using the pdo location as the xml location
			if (groupLogicalFieldsXpath.getDocumentInd()) {

				sPDOXmlLocation = groupLogicalFieldsXpath.getPdoXmlLocation();
				childDocumentLocationType = XmlLocationType.reverseMapping(sPDOXmlLocation);

				if (mapCustomisations != null)
					sGroupXmlType = (String) mapCustomisations.get(sPDOXmlLocation);
				if (sGroupXmlType == null)
					sGroupXmlType = groupLogicalFieldsXpath.getGroupXmlType();

				enumDocumentChildPaymentType = PaymentType.valueOf(sGroupXmlType);

				// if the group xml type (i.e. payment type) was not defined, rertieve the xml document
				// from the pdo, stored against the value of the PDO_XML_LOCATION column
				if (enumDocumentChildPaymentType == null) {

					newXmlDocument = pdo.getXml(sPDOXmlLocation);

					if (newXmlDocument != null) {

						if (!groupLogicalFieldsXpath.getTagName().equals(newXmlDocument.getDomNode().getLocalName())) {
							// navigate to the first parent (document)
							tidyingCursor = newXmlDocument.newCursor();
							tidyingCursor.toParent();
							newXmlDocument = (XmlObjectBase) tidyingCursor.getObject();
							tidyingCursor.dispose();
						}// EO if the element is

						newGroupPathElement.setObjectValue(newXmlDocument);
					}// EO if the pdo contained the xml document

				}// EO if the group xml type was not defined in xml format relation types table
				else {

					// navigate the cursor to just before the first child of the document
					fieldsCursor.toBeforeFirstChild();
					enumDocumentChildTargetPaymentType = fieldsCursor.getCurrPaymentType();

					// use the group xml type to create a new document instance (required for scenarios such as SWIFT
					// where the newnistance is enriched with default values an attributes
					// set the new document in the current gruop and pass the new document to the recursion
					// Note: it is possible that the newGroupPathElement node creation had already created the root element
					// in which case, skip the new instance creation and use the new group
					if (enumDocumentChildPaymentType.getLocalPart().equals(groupLogicalFieldsXpath.getTagName())) {
						newXmlDocument = newGroupPathElement;
					} else {
						newXmlDocument = enumDocumentChildPaymentType.newInstance(false/* return first child */);
						newGroupPathElement.setObjectValue(newXmlDocument);
						// navigate to the first child
						tidyingCursor = newGroupPathElement.newCursor();
						tidyingCursor.toFirstChild();
						newXmlDocument = (XmlObjectBase) tidyingCursor.getObject();
						tidyingCursor.dispose();
					}// EO else if the group had not already created the root document

					// branch to a recursion of this method using the new xml type and its groups
					this.transformToXmlInner(pdo, newXmlDocument /* xmlDocRoot */, mapCustomisations, fieldsCursor);
					fieldsCursor.toParent();
					// clear the sGroupXmlType
					sGroupXmlType = null;
					continue;
				}// EO else if the group xml type was defined in xml format relation types table

				// continue with the immediate groups if any defined to the given document field

			}// EO if the group is a document
			else if (FieldType.isXmlMulti(groupLogicalFieldsXpath.getFieldType())) {
				// retrieve the multi payment field from the pdo if the field does not exist,
				// skip
				XmlMultiOccurencePaymentField currMultiGroupPaymentField = null, txMultiOccurrenceHandler = null;
				currMultiGroupPaymentField = (XmlMultiOccurencePaymentField) pdo.getField(sGroupLogicalFieldId);
				if (currMultiGroupPaymentField == null) {
					this.pruneXml(newGroupPathElement, newRootXmlCur, /* bRemoveFromXml */true, false /* bForceRemove */);
					continue;
				}// EO if there was no xml content
					// else
					// rerieve the xml and construct a new bogus xml multi occurrence payment field and set the value from
					// currMultiGroupPaymentField the action shall transform the xml to the target message type
				if (txMultiOccurrenceHandler == null)
					txMultiOccurrenceHandler = (XmlMultiOccurencePaymentField) FieldType.XML_MULTI.newPaymentField(sGroupLogicalFieldId,
							logicalFieldsGroup,pdo);

				tidyingCursor = currMultiGroupPaymentField.getXml().newCursor();

				txMultiOccurrenceHandler.setFromXml(tidyingCursor /* srcXmlcur */, newGroupPathElement, true/* useInstanceDocumentAsNodeRef */,
						currMultiGroupPaymentField.getLogicalFieldsXPath(), groupLogicalFieldsXpath, currMultiGroupPaymentField.getPaymentType(),
						enumCurrentDocumentType, this);

				tidyingCursor.dispose();
			}// EO else if group multi
			else if (groupLogicalFieldsXpath.getFieldType() == FieldType.XML_SLF_EXT_GROUP && pdoCorrespondingDocument != null) {

				// rertieve the group from the xml of the curent document type.
				// Note: uses the 'self' axis as the root document elememt might be the same as the group's path's first path element
				arrNodes = pdoCorrespondingDocument.selectPath(sXqueryTemplate + "/self::" + groupLogicalFieldsXpath.getFieldPath().substring(1));

				// set the xml in the newGroupPathElement if such group exists in the current given xml document
				if (arrNodes.length > 0)
					newGroupPathElement.set(arrNodes[0]);
			}// EO if the gruop is a self extracting one

			// else if the group is not a document, retrieve its children, iterate over then and construct the xml nodes for each
			// using the xpath definition and the vlaue retrieved from the pdo
			if (fieldsCursor.toBeforeFirstChild()) {

				// for(LogicalFieldsXpath childLogicalFieldsXpath : listGroupXmlChildren) {
				while (fieldsCursor.hasNext()) {

					childLogicalFieldsXpath = fieldsCursor.next();
					if (childLogicalFieldsXpath == null)
						continue;

					sChildLogicalFieldId = childLogicalFieldsXpath.getFieldLogicalId();

					// if the logical field is a group (removal groups scenario skip
					if (childLogicalFieldsXpath.getFieldType() == FieldType.XML_GROUP)
						continue;

					// determine whether the element is a multi occurrence one
					isMultiOccurreneElement = FieldType.isXmlMulti(childLogicalFieldsXpath.getFieldType());

					logicalFieldsChild = CacheKeys.LogicalFieldsIdKey.getSingle(sChildLogicalFieldId);
					enumChildDataType = logicalFieldsChild.getDataType();

					// if the field is a multi occurrence one, retrieve the node from the payment field
					// iterate over the children and create a new node for each in the new xml
					if (isMultiOccurreneElement) {

						multiPaymentField = (XmlMultiOccurencePaymentField) pdo.getField(sChildLogicalFieldId);
						if (multiPaymentField == null)
							continue;

						existingChildPathElement = multiPaymentField.getXml();
						sChildNodeName = multiPaymentField.getLogicalFieldsXPath().getTagName();

						// select the immediate children of the current element with the given new child xml tag names
						multiOccurrenceChildName = PaymentType.qname(sChildNodeName, multiPaymentField.getPaymentType().getSchemaNamespace());
						arrNodes = existingChildPathElement.selectChildren(multiOccurrenceChildName);

						// iterate over the children and add them to the new xml through the payment field
						final int iLength = arrNodes.length;

						if (iLength == 0)
							continue;
						// else create the path element
						newChildPathElement = this.getOrCreateXmlNode(childLogicalFieldsXpath, newGroupPathElement, sCurrentDocumentNamespace,
								false /* bIsMemberAndMultiChild */, enumCurrentDocumentType);

						// if the current path element was valid (not null) set the value
						if (newChildPathElement == null) {
							logger.warn("xpath [{}] to field {} is not valid", childLogicalFieldsXpath.getFieldPath(), sChildLogicalFieldId);
							continue;
						}// EO if the path was not valid

						for (int i = 0; i < iLength; i++) {
							multiOccurrencePathElement = this
									.getOrCreateImmidiateChild(newChildPathElement, sChildNodeName, i /* iOccurrenceIndex */,
											sCurrentDocumentNamespace, null/* tag name */, enumCurrentDocumentType, false/* forceCreate */);
							// set the value for the new occurrence from the existing one
							enumChildDataType.setXbeanValue(multiOccurrencePathElement, ((XmlObjectBase) arrNodes[i]).getStringValue());

						}// EO while there are more multi occurrence nodes

					}// EO if the child was a multi occurrence
					else {

						// attempt to retrieve the node value from the pdo and only it is exists, construct the
						// xml node
						oNodeValue = this.getLogicalFieldValForTx(pdo, childLogicalFieldsXpath, mapCustomisations);

						// if there was no value and no default value configure in the database , continue
						if (oNodeValue == null)
							continue;

						newChildPathElement = this.getOrCreateXmlNode(childLogicalFieldsXpath, newGroupPathElement, sCurrentDocumentNamespace,
								false /* bIsMemberAndMultiChild */, enumCurrentDocumentType);

						// if the current path element was valid (not null) set the value
						if (newChildPathElement == null) {
							logger.warn("xpath [{}] to field {} is not valid", childLogicalFieldsXpath.getFieldPath(), sChildLogicalFieldId);
							continue;
						}// EO if the path was not valid

						enumChildDataType.setXbeanValue(newChildPathElement, oNodeValue);

					}// EO else if the child was not a multi occurrence

				}// EO while there are more children

				fieldsCursor.toParent();

			}// EO if there are children

			// clear the oChildValue for next iteration
			oNodeValue = null;

			if ((currGroupNode = newGroupPathElement.getDomNode()).getChildNodes().getLength() > 0 || currGroupNode.getAttributes().getLength() > 0)
				continue;
			// else if the group did not have chld elements, prune
			tidyingCursor = newGroupPathElement.newCursor();
			tidyingCursor.removeXml();
			tidyingCursor.toParent();

			while (!tidyingCursor.toFirstChild() && !tidyingCursor.isAtSamePositionAs(newRootXmlCur)) {
				tidyingCursor.removeXml();
				tidyingCursor.toParent();
			}// EO while there are more empty parents

			// dispose of the tidyingCursor cursor
			tidyingCursor.dispose();

		}// EO while there are more groups for the given target payment type

		// dispose of the root cursor
		newRootXmlCur.dispose();
		currGroupNode = null;

		return xmlDocRoot;
	}// EOM

	/**
	 * TODO: if the target payment type is the same as the xml residing in the locationType formal argument, return the pdo xml document --> dont
	 * remember what this means TODO: multi groups --> DONE TODO: ORIG section --> DONE TODO: merge : if the xml document already exists within the
	 * pdo do not store the current one !!!! --> DONE TODO: msgNotes getNSet error (only to compile schema) --> DONE TODO: add the new interfaces as a
	 * msg type with the same charateristics of their XML_TYPE super type (unless they are already defined in the msg types table) --> this should be
	 * done in the msg types query --> DONE TODO: support xml skelleton as an base document instead of using the paymentType.newInstance() --> DONE
	 * TODO: change the document handling code to: --> DONE
	 * 
	 * if group xml type is empty use the pdo location as is else if group xml type is not empty then if group has children which are infact nested
	 * groups then use children as groups using the pdo location as the xml location else if group does not have children use group xml types as
	 * groups using the pdo location as the xml location
	 * 
	 * TODO: Question: in PDO list members merge what should I do? clear and recreate? actual merge? TODO: convert msgFees to XMLBEANS TODO: JPA
	 * member TODO: delete msgFees & msgNotes jpas
	 * 
	 * Jan 27, 2010 guys
	 * 
	 * @param pdo
	 * @param xmlDocRoot
	 * @param enumTargetPaymentType
	 * @param enumCurrentDocumentType
	 * @param enumXmlLocationType
	 * @param listXmlGroups
	 * @return
	 * @throws Throwable
	 */
	private final XmlObjectBase deprecatedTransformToXmlInner(final PDO pdo, final XmlObjectBase xmlDocRoot, PaymentType enumTargetPaymentType,
			PaymentType enumCurrentDocumentType, XmlLocationType enumXmlLocationType, final Map mapCustomisations,
			final List<LogicalFieldsXpath> listXmlGroups) throws Throwable {

		XmlObjectBase newGroupPathElement = null, newChildPathElement = null, existingChildPathElement = null, newXmlDocument = null, multiOccurrencePathElement = null;
		PaymentType enumDocumentChildPaymentType = null, enumDocumentChildTargetPaymentType = null;
		XmlLocationType childDocumentLocationType = null;

		List<LogicalFieldsXpath> listDocumentChildXmlGroups = null, listGroupXmlChildren = new ArrayList<LogicalFieldsXpath>();

		LogicalFields logicalFieldsGroup = null, logicalFieldsChild = null;

		String sPDOXmlLocation = null, sGroupXmlType = null, sGroupLogicalFieldId = null, sChildLogicalFieldId = null, sChildNodeName = null;

		// as in nested documents the namespace can differ from the target namespace which is the complete document
		// namespace, use the payemnt type's namespace for the construction of the node but the target namesapce for the
		// cache metadata rertievals
		final String sCurrentDocumentNamespace = enumCurrentDocumentType.getSchemaNamespace();
		final String sXmlLocationType = enumXmlLocationType.name();
		boolean isMultiOccurreneElement = false, bIsGroupMultiOccurreneElement = false, bIsMember = false;
		Object oNodeValue = null, oPDOListMemberValue = null;
		QName multiOccurrenceChildName = null;
		XmlObject[] arrNodes = null;
		XmlMultiOccurencePaymentField multiPaymentField = null;
		DataType enumChildDataType = null;
		XmlCursor tidyingCursor = null;
		XmlObject pdoCorrespondingDocument = pdo.getXml(sXmlLocationType);

		final String sXqueryTemplate = "declare default element namespace '" + enumCurrentDocumentType.getSchemaNamespace() + "'; .";

		// create a tidying comparison cursor for the root element
		final XmlCursor newRootXmlCur = xmlDocRoot.newCursor();

		for (LogicalFieldsXpath groupLogicalFieldsXpath : listXmlGroups) {

			sGroupLogicalFieldId = groupLogicalFieldsXpath.getFieldLogicalId();

			logicalFieldsGroup = CacheKeys.LogicalFieldsIdKey.getSingle(sGroupLogicalFieldId);

			// store the member indication found in the logical fields jpa rather than the xpath meta data which could be overwritten with logical
			// fields xpath
			// definitions
			bIsMember = logicalFieldsGroup.getFieldType() == FieldType.MEMBER;
			bIsGroupMultiOccurreneElement = FieldType.isXmlMulti(groupLogicalFieldsXpath.getFieldType());

			// create the group element
			newGroupPathElement = this.getOrCreateXmlNode(groupLogicalFieldsXpath, xmlDocRoot, sCurrentDocumentNamespace,
					bIsGroupMultiOccurreneElement/* member nor multi */);

			// if the field is member, branch to member transformation
			if (bIsMember && bIsGroupMultiOccurreneElement) {

				oPDOListMemberValue = this.processPDOMember(logicalFieldsGroup.getLocation(), true /* bIsMulti */, pdo, true/* bMarshall */,
						newGroupPathElement, groupLogicalFieldsXpath, enumCurrentDocumentType,
						(PDOListMemberHandlerInterface) (mapCustomisations == null ? null : mapCustomisations.get(logicalFieldsGroup.getLocation())));

				if (oPDOListMemberValue == null || !newGroupPathElement.getDomNode().hasChildNodes()) {
					tidyingCursor = newGroupPathElement.newCursor();
					tidyingCursor.removeXml();
					tidyingCursor.dispose();
				}// EO if there were no reecords
				continue;
			}// if the field was a member ;

			// if the group element is a document then
			// if group xml type is empty
			// use the pdo location as is
			// else if group xml type is not empty then
			// if group has children which are infact nested groups then
			// use children as groups using the pdo location as the xml location
			// else if group does not have children
			// use group xml types as groups using the pdo location as the xml location
			if (groupLogicalFieldsXpath.getDocumentInd()) {

				sPDOXmlLocation = groupLogicalFieldsXpath.getPdoXmlLocation();
				childDocumentLocationType = XmlLocationType.reverseMapping(sPDOXmlLocation);

				// if the group xml type (i.e. payment type) was not defined, rertieve the xml document
				// from the pdo, stored against the value of the PDO_XML_LOCATION column
				if ((sGroupXmlType = groupLogicalFieldsXpath.getGroupXmlType()) == null) {

					newXmlDocument = pdo.getXml(sPDOXmlLocation);

					if (newXmlDocument != null) {

						if (!groupLogicalFieldsXpath.getTagName().equals(newXmlDocument.getDomNode().getLocalName())) {
							// navigate to the first parent (document)
							tidyingCursor = newXmlDocument.newCursor();
							tidyingCursor.toParent();
							newXmlDocument = (XmlObjectBase) tidyingCursor.getObject();
							tidyingCursor.dispose();
						}// EO if the element is

						newGroupPathElement.setObjectValue(newXmlDocument);
					}// EO if the pdo contained the xml document

				}// EO if the group xml type was not defined in xml format relation types table
				else {

					// configure the current document child payment using the group xml type
					enumDocumentChildPaymentType = PaymentType.valueOf(sGroupXmlType);

					// attempt to retrieve the group's children from the logical fields children cache
					// if the group has children, the document creation is in the context of a new payment type
					// subset defined against the current document id in the very same table
					// else if there are no children, create a new document using the groups of the
					// provided group xml type and the pdo location
					if (listDocumentChildXmlGroups == null)
						listDocumentChildXmlGroups = new ArrayList<LogicalFieldsXpath>();
					listDocumentChildXmlGroups.clear();

					// retrieve the children (groups) for the given document id using the formal arg xml type key and the current document's pdo
					// location
					CacheKeys.LocicalFieldsXpathChildrenKey.get(listDocumentChildXmlGroups, sGroupLogicalFieldId, enumTargetPaymentType,
							childDocumentLocationType.name());

					if (listDocumentChildXmlGroups.isEmpty()) {
						// configure the nested target payment type to be the same as the group's document payment type
						// (e.g. SWIFT_103)
						enumDocumentChildTargetPaymentType = enumDocumentChildPaymentType;
						// retrieve the groups for the given xml type using the pdo location defined same record
						CacheKeys.LogicalFieldsXPathGroupsKey.get(listDocumentChildXmlGroups, enumDocumentChildPaymentType, sPDOXmlLocation);
					}// EO if there are no new payment type subset children defined in xml format relations table
					else {
						// define the nested target payment type to the overall target payment type as the groups
						// would be stored in the cache against this key part
						enumDocumentChildTargetPaymentType = enumTargetPaymentType;
					}// EO else if the given document had payment type group subset recrods defined

					// use the group xml type to create a new document instance (required for scenarios such as SWIFT
					// where the newnistance is enriched with default values an attributes
					// set the new document in the current gruop and pass the new document to the recursion
					// Note: it is possible that the newGroupPathElement node creation had already created the root element
					// in which case, skip the new instance creation and use the new group
					if (enumDocumentChildPaymentType.getLocalPart().equals(groupLogicalFieldsXpath.getTagName())) {
						newXmlDocument = newGroupPathElement;
					} else {
						newXmlDocument = enumDocumentChildPaymentType.newInstance(false/* return first child */);
						newGroupPathElement.setObjectValue(newXmlDocument);
						// navigate to the first child
						tidyingCursor = newGroupPathElement.newCursor();
						tidyingCursor.toFirstChild();
						newXmlDocument = (XmlObjectBase) tidyingCursor.getObject();
						tidyingCursor.dispose();
					}// EO else if the group had not already created the root document

					// branch to a recursion of this method using the new xml type and its groups
					this.deprecatedTransformToXmlInner(pdo, newXmlDocument /* xmlDocRoot */,
							enumDocumentChildTargetPaymentType /* enumTargetPaymentType */, enumDocumentChildPaymentType, childDocumentLocationType,
							mapCustomisations, listDocumentChildXmlGroups);

				}// EO else if the group xml type was defined in xml format relation types table

				// continue with the immediate groups if any defined to the given document field

			}// EO if the group is a document
			else if (FieldType.isXmlMulti(groupLogicalFieldsXpath.getFieldType())) {
				// retrieve the multi payment field from the pdo if the field does not exist,
				// skip
				XmlMultiOccurencePaymentField currMultiGroupPaymentField = null, txMultiOccurrenceHandler = null;
				currMultiGroupPaymentField = (XmlMultiOccurencePaymentField) pdo.getField(sGroupLogicalFieldId);
				if (currMultiGroupPaymentField == null) {
					this.pruneXml(newGroupPathElement, newRootXmlCur, /* bRemoveFromXml */true, false /* bForceRemove */);
					continue;
				}// EO else if currMultiGroupPaymentField was not provided
					// else
					// rerieve the xml and construct a new bogus xml multi occurrence payment field and set the value from
					// currMultiGroupPaymentField the action shall transform the xml to the target message type
				if (txMultiOccurrenceHandler == null)
					txMultiOccurrenceHandler = (XmlMultiOccurencePaymentField) FieldType.XML_MULTI.newPaymentField(sGroupLogicalFieldId,
							logicalFieldsGroup,pdo);

				tidyingCursor = currMultiGroupPaymentField.getXml().newCursor();

				txMultiOccurrenceHandler.setFromXml(tidyingCursor /* srcXmlcur */, newGroupPathElement, true/* useInstanceDocumentAsNodeRef */,
						currMultiGroupPaymentField.getLogicalFieldsXPath(), groupLogicalFieldsXpath, currMultiGroupPaymentField.getPaymentType(),
						enumTargetPaymentType, this);

				tidyingCursor.dispose();
			}// EO else if group multi
			else if (groupLogicalFieldsXpath.getFieldType() == FieldType.XML_SLF_EXT_GROUP && pdoCorrespondingDocument != null) {

				// rertieve the group from the xml of the curent document type.
				// Note: uses the 'self' axis as the root document elememt might be the same as the group's path's first path element
				arrNodes = pdoCorrespondingDocument.selectPath(sXqueryTemplate + "/self::" + groupLogicalFieldsXpath.getFieldPath().substring(1));

				// set the xml in the newGroupPathElement if such group exists in the current given xml document
				if (arrNodes.length > 0)
					newGroupPathElement.set(arrNodes[0]);
			}// EO if the gruop is a self extracting one

			// else if the group is not a document, retrieve its children, iterate over then and construct the xml nodes for each
			// using the xpath definition and the vlaue retrieved from the pdo
			listGroupXmlChildren.clear();
			CacheKeys.LocicalFieldsXpathChildrenKey.get(listGroupXmlChildren, sGroupLogicalFieldId, enumTargetPaymentType, sXmlLocationType);

			for (LogicalFieldsXpath childLogicalFieldsXpath : listGroupXmlChildren) {

				sChildLogicalFieldId = childLogicalFieldsXpath.getFieldLogicalId();

				// if the logical field is a group (removal groups scenario skip
				if (childLogicalFieldsXpath.getFieldType() == FieldType.XML_GROUP)
					continue;

				// determine whether the element is a multi occurrence one
				isMultiOccurreneElement = FieldType.isXmlMulti(childLogicalFieldsXpath.getFieldType());

				logicalFieldsChild = CacheKeys.LogicalFieldsIdKey.getSingle(sChildLogicalFieldId);
				enumChildDataType = logicalFieldsChild.getDataType();

				// if the field is a multi occurrence one, retrieve the node from the payment field
				// iterate over the children and create a new node for each in the new xml
				if (isMultiOccurreneElement) {

					multiPaymentField = (XmlMultiOccurencePaymentField) pdo.getField(sChildLogicalFieldId);
					if (multiPaymentField == null)
						continue;

					existingChildPathElement = multiPaymentField.getXml();
					sChildNodeName = childLogicalFieldsXpath.getTagName();
					// select the immediate children of the current element with the given new child xml tag names
					multiOccurrenceChildName = PaymentType.qname(sChildNodeName, multiPaymentField.getPaymentType().getSchemaNamespace());
					arrNodes = existingChildPathElement.selectChildren(multiOccurrenceChildName);

					// iterate over the children and add them to the new xml through the payment field
					final int iLength = arrNodes.length;

					if (iLength == 0)
						continue;
					// else create the path element
					newChildPathElement = this
							.getOrCreateXmlNode(childLogicalFieldsXpath, newGroupPathElement, sCurrentDocumentNamespace, false /* bIsMemberAndMultiChild */);

					// if the current path element was valid (not null) set the value
					if (newChildPathElement == null) {
						logger.warn("xpath [{}] to field {} is not valid", childLogicalFieldsXpath.getFieldPath(), sChildLogicalFieldId);
						continue;
					}// EO if the path was not valid

					for (int i = 0; i < iLength; i++) {
						multiOccurrencePathElement = this.getOrCreateImmidiateChild(newChildPathElement, sChildNodeName, i /* iOccurrenceIndex */,
								sCurrentDocumentNamespace, null/* tag name */);
						// set the value for the new occurrence from the existing one
						enumChildDataType.setXbeanValue(multiOccurrencePathElement, ((XmlObjectBase) arrNodes[i]).getStringValue());

					}// EO while there are more multi occurrence nodes

				}// EO if the child was a multi occurrence
				else {

					// attempt to retrieve the node value from the pdo and only it is exists, construct the
					// xml node
					oNodeValue = this.getLogicalFieldValForTx(pdo, childLogicalFieldsXpath, mapCustomisations);

					// if there was no value and no default value configure in the database , continue
					if (oNodeValue == null)
						continue;

					newChildPathElement = this
							.getOrCreateXmlNode(childLogicalFieldsXpath, newGroupPathElement, sCurrentDocumentNamespace, false /* bIsMemberAndMultiChild */);

					// if the current path element was valid (not null) set the value
					if (newChildPathElement == null) {
						logger.warn("xpath [{}] to field {} is not valid", childLogicalFieldsXpath.getFieldPath(), sChildLogicalFieldId);
						continue;
					}// EO if the path was not valid

					enumChildDataType.setXbeanValue(newChildPathElement, oNodeValue);

				}// EO else if the child was not a multi occurrence

			}// EO while there are more children

			// clear the oChildValue for next iteration
			oNodeValue = null;

			if (newGroupPathElement.getDomNode().getChildNodes().getLength() > 0)
				continue;
			// else if the group did not have chld elements, prune
			tidyingCursor = newGroupPathElement.newCursor();
			tidyingCursor.removeXml();
			tidyingCursor.toParent();

			while (!tidyingCursor.toFirstChild() && !tidyingCursor.isAtSamePositionAs(newRootXmlCur)) {
				tidyingCursor.removeXml();
				tidyingCursor.toParent();
			}// EO while there are more empty parents

			// dispose of the tidyingCursor cursor
			tidyingCursor.dispose();

		}// EO while there are more groups for the given target payment type

		// dispose of the root cursor
		newRootXmlCur.dispose();

		return xmlDocRoot;
	}// EOM

	private final Object getLogicalFieldValForTx(final PDO pdo, final LogicalFieldsXpath logicalFieldMetadata, final Map mapCustomisations) {
		//

		String sLFId = logicalFieldMetadata.getFieldLogicalId();
		Object oNodeValue = mapCustomisations != null ? mapCustomisations.get(sLFId) : null;
		if (oNodeValue == null) {
			oNodeValue = pdo.get(sLFId);
		}
		String sChildValue = null;
		final String LOGICAL_FIELD_ENCLOSER = "@@";
		final int LOGICAL_FIELD_ENCLOSER_LENGTH = LOGICAL_FIELD_ENCLOSER.length();

		if (oNodeValue == null && (sChildValue = logicalFieldMetadata.getDefaultVal()) != null) {
			// Note: the default value would not override existing one
			// only ensure that the payment is enriched with the element
			// along with its default value
			// The 'EMPTY' would be replaced with ''
			if (sChildValue.equals("EMPTY"))
				oNodeValue = "";
			else if (sChildValue.startsWith(GlobalConstants.LOGICAL_FIELD_ENCLOSER)) {
				oNodeValue = pdo.get(sChildValue.substring(GlobalConstants.LOGICAL_FIELD_ENCLOSER_LENGTH, sChildValue.length()
						- GlobalConstants.LOGICAL_FIELD_ENCLOSER_LENGTH));
			}// EO if the value was a logical field value
			else
				oNodeValue = sChildValue;
		}// EO if there was a default value for the given element

		//

		return oNodeValue;
	}// EOM

	@Override
	public final PDO transformPDOPmntSection(final String sMID, final PaymentType enumNewPaymentType) throws Exception {

		final PDO pdo = PaymentDataFactory.load(sMID);
		// if the pdo does not exist, throw an exception
		if (pdo == null || pdo.isEmpty()) {
			ErrorAuditUtils.onError(ProcessErrorConstants.PDONoMinfRecord, sMID, IllegalArgumentException.class);
			return pdo;
		}// EO if the load had failed
			// else

		return transformPDOPmntSection(pdo, enumNewPaymentType);
	}// EOM

	@Override
	public final PDO transformPDOPmntSection(final PDO pdo, final PaymentType enumNewPaymentType) throws Exception {
		logger.debug("transformPDOPmntSection to {}",enumNewPaymentType);
		
		// for now only the current xml document is transformable
		final XmlLocationType enumDocumentID = XmlLocationType.XML_MSG;
		final String sDocumentID = enumDocumentID.name();

		final String LOGICAL_FIELD_ENCLOSER = "@@";
		final int LOGICAL_FIELD_ENCLOSER_LENGTH = LOGICAL_FIELD_ENCLOSER.length();

		// rertieve the pdo's current current xml as well as the data map
		final XmlMetadata currentPaymentXmlMetadata = pdo.getXmlMetadata(sDocumentID);
		final PaymentType currPaymentType = currentPaymentXmlMetadata.getPaymentType();
		final Map<Object, PaymentFieldInterface> currentMapData = pdo.getDataMap();
		final Map<Object, PaymentFieldInterface> currentStaleXmlFieldsMapData = new HashMap<Object, PaymentFieldInterface>();

		// retrieve the current payment data's root document to be used to extract those
		// node values which were not initialized for the current payment data directly from the pdo
		XmlObjectBase currentPaymentRootDoc = currentPaymentXmlMetadata.getXml();

		// final String sXqueryTemplate = "declare default element namespace '" +
		// currentPaymentXmlMetadata.getPaymentType().getSchemaNamespace() + "'; ." ;

		final String sXqueryTemplate = currentPaymentXmlMetadata.getPaymentType().getXpathlNamespaceCaluse() + ".";

		// if the payment is in conjoined mode, copy the current fndt msg for the orig xml document
		// so that it would not be disconnected from the parent
		if (pdo.isConjoined())
			this.severConjoinedLinks(pdo, false/* reconfigure payment fields */);

		// iterate over the currentMapData and remove all xmlpayment fields and store in the
		// currentStaleXmlFieldsMapData
		PaymentFieldInterface<?> paymentField = null;
		String sLogicalFID = null;

		// Creates new Map which is composed from the PDO data map, in order to prevent ConcurrentModificationException
		// while irterating on it and remove data from it.
		final Map<Object, PaymentFieldInterface> tempCurrentMapData = new HashMap<Object, PaymentFieldInterface>(pdo.getDataMap());

		// Iterates on the TEMP pdo data map, while removing entries from the the ORIGINAL map in the PDO.
		for (Map.Entry<Object, PaymentFieldInterface> entry : tempCurrentMapData.entrySet()) {

			sLogicalFID = (String) entry.getKey();
			paymentField = entry.getValue();

			// if the field is an XML payment field and its document id is the same as the sDocumentID,
			// remove the entry from the pdo, mapData but not from the modified fields
			if (paymentField != PaymentField.PLACE_HOLDER && paymentField.getFieldType() != null && FieldType.isXmlType(paymentField.getFieldType())
					&& ((XmlPaymentField) paymentField).getDocumentId().equals(sDocumentID)) {

				currentStaleXmlFieldsMapData.put(sLogicalFID, currentMapData.remove(sLogicalFID));

				// remove the paymentField's link
				paymentField.removeLinkedPaymentField();
			}// EO if the field was an xml field realted to the transformation document

		}// EO while there are more fields in the current map

		final Map<String, LogicalFieldsXpath> mapCurrPaymentFieldsXPaths = CacheKeys.LogicalFieldsXPathKey.getSingle(currPaymentType);

		// if the mapCurrPaymentFieldsXPaths is null throw an exception as the current payment type cannot be transformed
		if (mapCurrPaymentFieldsXPaths == null)
			throw new PDOException(String.format("Could not transform message '%s' as its payment type '%s' does not define any xml fields",
					pdo.getMID(), currPaymentType));

		// create the new Xml's Root Document & retrieve its namespace
		XmlObjectBase newPaymentRootDcoument = enumNewPaymentType.newInstance();

		final String sNewPaymentNs = enumNewPaymentType.getSchemaNamespace();

		// create a tidying comparison cursor for the root element
		final XmlCursor newRootXmlCur = newPaymentRootDcoument.newCursor();

		// rerieve the logical fields xpath groups list of the new payment type to be iterated over
		final List<LogicalFieldsXpath> listXmlGroups = new ArrayList<LogicalFieldsXpath>();
		CacheKeys.LogicalFieldsXPathGroupsKey.get(listXmlGroups, enumNewPaymentType, CURRENT_XML_KEY);

		final List<LogicalFieldsXpath> listGroupChildren = new ArrayList<LogicalFieldsXpath>();
		LogicalFieldsXpath currentPaymentChildXmlMetadata = null, currentPaymentGroupXmlMetadata = null;
		String sLogicalFieldGroupId, sLogicalFieldsChildId = null;
		boolean isMultiOccurreneElement = false;
		XmlObjectBase groupElement = null, newChildElement = null, currentChildElement = null;
		Object oChildValue = null;
		String sXPathToNewNode = null;
		XmlObject[] arrNodes = null;
		XmlPaymentField xmlPaymentField = null;
		PaymentFieldInterface tempPaymentField = null, tempGroupPaymentField = null;
		LogicalFields logicalFieldsChild = null;
		QName multiOccurrenceChildName = null;
		XmlCursor tidyingCursor = null;
		String sChildValue = null;

		for (LogicalFieldsXpath newPaymentGroupParentXmlMetadata : listXmlGroups) {

			sLogicalFieldGroupId = newPaymentGroupParentXmlMetadata.getFieldLogicalId();
			groupElement = null;

			// determine whether the element is a multi occurrence one
			// (required for additional xpath configurations)
			isMultiOccurreneElement = newPaymentGroupParentXmlMetadata.getFieldType() == FieldType.XML_MULTI;

			if (isMultiOccurreneElement) {

				tempGroupPaymentField = currentStaleXmlFieldsMapData.remove(sLogicalFieldGroupId);
				if (tempGroupPaymentField == null || !(tempGroupPaymentField instanceof XmlMultiOccurencePaymentField))
					continue;
				// else
				LogicalFields logicalFieldsGroup = LogicalFieldsIdKey.getSingle(sLogicalFieldGroupId);

				XmlMultiOccurencePaymentField newMultiGroupPaymentField = (XmlMultiOccurencePaymentField) newPaymentGroupParentXmlMetadata
						.getFieldType().newPaymentField(sLogicalFieldGroupId, logicalFieldsGroup,pdo);

				XmlMultiOccurencePaymentField currentMultiGroupPaymentField = (XmlMultiOccurencePaymentField) tempGroupPaymentField;
				XmlCursor srcCursor = currentMultiGroupPaymentField.getXml().newCursor();

				// groupElement = this.getOrCreateXmlNode(newPaymentGroupParentXmlMetadata, newPaymentRootDcoument, sNewPaymentNs, false) ;

				newMultiGroupPaymentField.setFromXml(srcCursor /* srcXmlcur */, newPaymentRootDcoument /* newGroupPathElement */,
						false/* useInstanceDocumentAsNodeRef */, currentMultiGroupPaymentField.getLogicalFieldsXPath(),
						newPaymentGroupParentXmlMetadata, currentMultiGroupPaymentField.getPaymentType(), enumNewPaymentType, this);

				srcCursor.dispose();

				currentMapData.put(sLogicalFieldGroupId, newMultiGroupPaymentField);

				srcCursor = null;
				currentMultiGroupPaymentField = null;
				newMultiGroupPaymentField = null;
				logicalFieldsGroup = null;
				tempGroupPaymentField = null;

				continue;

			}// EO if multi Occurrence group

			// retrieve the children
			CacheKeys.LocicalFieldsXpathChildrenKey.get(listGroupChildren, sLogicalFieldGroupId, enumNewPaymentType, CURRENT_XML_KEY);

			// if there are no children, skip to the next group
			if (listGroupChildren.isEmpty())
				continue;

			// /iterate over the children and populate from either the map of the current
			// payment xml document
			for (LogicalFieldsXpath newChildXmlMetadata : listGroupChildren) {

				sLogicalFieldsChildId = newChildXmlMetadata.getFieldLogicalId();

				// if the logical field is a group (removal groups scenario skip
				if (newChildXmlMetadata.getFieldType() == FieldType.XML_GROUP)
					continue;

				// TODO: for debug
				// if(sLogicalFieldsChildId.equals("X_CDTR_ADRLINE")) continue ;

				logicalFieldsChild = LogicalFieldsIdKey.getSingle(sLogicalFieldsChildId);

				tempPaymentField = currentStaleXmlFieldsMapData.remove(sLogicalFieldsChildId);
				xmlPaymentField = (XmlPaymentField) (tempPaymentField instanceof XmlPaymentField ? tempPaymentField : null);

				// if the value is null, and the temp field was not a place holder
				// which would mean that there was no xml value at the time of its
				// creation - attempt to retrieve the value directly from the
				// current xml payment field
				if (xmlPaymentField == null && tempPaymentField != PaymentField.PLACE_HOLDER) {

					currentPaymentGroupXmlMetadata = mapCurrPaymentFieldsXPaths.get(sLogicalFieldGroupId);
					currentPaymentChildXmlMetadata = mapCurrPaymentFieldsXPaths.get(sLogicalFieldsChildId);

					// if the currentPaymentChildXmlMetadata is null for the given payment type,
					// then it is safe to assume that there are no relevant xml data to retrieve from the current xml document
					if (currentPaymentChildXmlMetadata != null) {

						sXPathToNewNode = sXqueryTemplate + currentPaymentGroupXmlMetadata.getFieldPath()
								+ currentPaymentChildXmlMetadata.getFieldPath();

						arrNodes = currentPaymentRootDoc.selectPath(sXPathToNewNode);

						if (arrNodes != null && arrNodes.length > 0) {
							currentChildElement = (XmlObjectBase) arrNodes[0];

							oChildValue = currentChildElement.getObjectValue();

							// create a new xml payment field payment field
							xmlPaymentField = (XmlPaymentField) newChildXmlMetadata.getFieldType().newPaymentField(sLogicalFieldsChildId,
									logicalFieldsChild,pdo);

						}// EO if there was a value

					}// EO if there was an path metadata for the child field for the current xml payment type

				}// EO if the child field was not in the pdo's map
				else if (xmlPaymentField != null) {
					currentChildElement = xmlPaymentField.getXml();
					oChildValue = ((PaymentFieldInterface<?>) xmlPaymentField).get();

					currentPaymentChildXmlMetadata = mapCurrPaymentFieldsXPaths.get(sLogicalFieldsChildId);
				}// EO else if the child field was present in the map

				if (oChildValue == null && (sChildValue = newChildXmlMetadata.getDefaultVal()) != null) {
					// Note: the default value would not override existing one
					// only ensure that the payment is enriched with the element
					// along with its default value
					// The 'EMPTY' would be replaced with ''
					if (sChildValue.equals("EMPTY"))
						oChildValue = "";
					else if (sChildValue.startsWith(LOGICAL_FIELD_ENCLOSER)) {
						oChildValue = pdo.get(sChildValue.substring(LOGICAL_FIELD_ENCLOSER_LENGTH, sChildValue.length()
								- LOGICAL_FIELD_ENCLOSER_LENGTH));
					}// EO if the value was a logical field value
					else
						oChildValue = sChildValue;

				}// EO if there was a default value for the given element
				else if (oChildValue == null) {
					oChildValue = pdo.get(sLogicalFieldsChildId);
				}// EO else attempt to retrieve the value from the pdo (might be a derived field as a last resort

				// if there was no value and no default value configure in the database , continue
				if (oChildValue == null)
					continue;
				// else if there was a value, constsruct the new xml hierarchy
				// if the payment field was not created yet (and there was a value) create one now
				if (xmlPaymentField == null)
					xmlPaymentField = (XmlPaymentField) newChildXmlMetadata.getFieldType().newPaymentField(sLogicalFieldsChildId, logicalFieldsChild,pdo);

				// only create the path to the group + the actual group node if there is at least one child value
				// if(groupElement == null) groupElement = this.getOrCreateXmlNode(newPaymentGroupParentXmlMetadata, newPaymentRootDcoument,
				// sNewPaymentNs, false) ;
				if (groupElement == null)
					groupElement = this.getOrCreateXmlNode(newPaymentGroupParentXmlMetadata.getFieldPath(),
							newPaymentGroupParentXmlMetadata.getTagName(), newPaymentRootDcoument, sNewPaymentNs, false, enumNewPaymentType);

				// determine whether the element is a multi occurrence one
				// (required for additional xpath configurations)
				isMultiOccurreneElement = newChildXmlMetadata.getFieldType() == FieldType.XML_MULTI;

				logger.info("parent node name : " + sLogicalFieldGroupId + " ;Child node name: " + sLogicalFieldsChildId);

				// if the child element is a multi occurrence one, it immediate parent would be created here
				// newChildElement = this.getOrCreateXmlNode(newChildXmlMetadata, groupElement, sNewPaymentNs, false) ;
				newChildElement = this.getOrCreateXmlNode(newChildXmlMetadata.getFieldPath(), newChildXmlMetadata.getTagName(), groupElement,
						sNewPaymentNs, false, enumNewPaymentType);

				// if the current path element was valid (not null) set the value
				if (newChildElement == null) {
					logger.warn("xpath [{}] to field {} is not valid", currentPaymentChildXmlMetadata.getFieldPath(), sLogicalFieldsChildId);
					continue;
				}// EO if the path was not valid
					// else else if the path was valid

				// if the child element was not a multi occurence, set the value in the xml node and
				// set the xml node in the payment field
				// if it was, iterate over the current xml bean element (if present)
				// and populate the new xmlbean through the payment field mechanism

				if (!isMultiOccurreneElement) {
					logicalFieldsChild.getDataType().setXbeanValue(newChildElement, oChildValue);
					// set the xml node in it
					xmlPaymentField.setFromXml(newChildElement, newChildXmlMetadata, enumNewPaymentType, false/* bUpdateOrigVal */);
				}// EO if not multi occurrence
				else if (currentChildElement != null) {
					// set the xml node in it
					xmlPaymentField.setFromXml(newChildElement, newChildXmlMetadata, enumNewPaymentType, false/* bUpdateOrigVal */);

					// select the immediate children of the current element with the given new child xml tag names
					multiOccurrenceChildName = new QName(currPaymentType.getSchemaNamespace(), currentPaymentChildXmlMetadata.getTagName());
					arrNodes = currentChildElement.selectChildren(multiOccurrenceChildName);

					// iterate over the children and add them to the new xml through the payment field
					final int iLength = arrNodes.length;
					for (int i = 0; i < iLength; i++) {
						xmlPaymentField.set(((XmlObjectBase) arrNodes[i]).getObjectValue(), true, sLogicalFieldsChildId, -1);
					}// EO while there are more multi occurrence nodes

				}// EO if multi occurrence and the current data exists (immediate parent of the multi occurrence that is)

				// finally, set the payment field in the map
				currentMapData.put(sLogicalFieldsChildId, xmlPaymentField);

				// clear the oChildValue for the next iteration
				oChildValue = null;
			}// EO while there are more child elements to the group
				// ((XmlObjectBase)groupElement).get_store().get_schema_field().getMinOccurs()

			// if the group did not end up having any children, remove it from the xml
			if (groupElement != null && groupElement.getDomNode().getChildNodes().getLength() == 0
					&& groupElement.schemaType().getContentModel().getIntMinOccurs() == 0) {

				tidyingCursor = groupElement.newCursor();
				tidyingCursor.removeXml();
				tidyingCursor.toParent();

				while (!tidyingCursor.toFirstChild() &&
				// (groupElement.get_store().get_schema_field().getMinOccurs().intValue()
						tidyingCursor.getObject().schemaType().getContentModel().getIntMinOccurs() == 0) {
					// !tidyingCursor.isAtSamePositionAs(newRootXmlCur)*/) ) {
					tidyingCursor.removeXml();
					tidyingCursor.toParent();
				}// EO while there are more empty parents

				// dispose of the tidyingCursor cursor
				tidyingCursor.dispose();

			}// EO if the group was emtpy

			// /clear the children list for next iteration
			listGroupChildren.clear();

		}// EO while there are more groups in the new payment type

		// to ensure that the modified fields list does not contain a reference to xml payment fields
		// which are defined in the source xml but not the destination and are modified, a scenrio
		// which would prevent the garbage collector from disposing of the source xml document,
		// iterate over the currentStaleXmlFieldsMapData and remove the xml node reference from
		// the remaining elements
		for (PaymentFieldInterface orphanedPaymentField : currentStaleXmlFieldsMapData.values()) {
			((XmlPaymentField) orphanedPaymentField).resetNodeReference();
		}// EO while there are more oraphned payment fields

		// dispose of the newRootXmlCur
		newRootXmlCur.dispose();

		// finally, replace the pdo's xml metadata with the new payment xml metadata
		// Note: as the metadatas are stored in a map, the addXmlMetadata will perform the
		// replacement
		// newPaymentRootDcoument = FndtMsgPaymentType.configurePmnt(currentPaymentRootDoc, newPaymentRootDcoument) ;
		pdo.addXmlDocument(XmlLocationType.XML_MSG, enumNewPaymentType, newPaymentRootDcoument).setChanged();

		//UNCOMMENT FOR DEBUG
		/*
		if (false) {
			final List<String> list = new ArrayList<String>();
			pdo.getXml("XML_MSG").validate(new XmlOptions().setErrorListener(list));
			System.out.println(list);
		}// EO if false
		*/

		return pdo;
	}// EOM

	@Override
	public final String formatPDO(final PDO pdo) throws BusinessException {

		final XmlLocationType enumXmlLocationType = XmlLocationType.XML_MSG;

		String msgType = pdo.getString(P_MSG_TYPE);
		
		PaymentFormattingInterface formattingDelegate;
		if ("FED_10".equals(msgType)){
			formattingDelegate = (PaymentFormattingInterface) SpringApplicationContext.getBean("FedParser");
		}else if ("CHIPS_31".equals(msgType)){
			formattingDelegate = (PaymentFormattingInterface) SpringApplicationContext.getBean("ChipsParser");
		}else{
			formattingDelegate = (PaymentFormattingInterface) SpringApplicationContext.getBean("SwiftParser");
		}
		
		String sFromattedMsg = null;

		// if no formatting delegate was configured warn and abort
		if (formattingDelegate == null) {
			logger.warn("Payment Formatting Delegate was not set");

			final XmlObjectBase xmlDoc = pdo.getXml(enumXmlLocationType.name());
			sFromattedMsg = xmlDoc.xmlText(GlobalConstants.m_outputXmlbeansOptions);

			return sFromattedMsg;
		}// EO if no formatting delegate was configure
			// else

		// format the payment using the message type as the format type
		// formatOutgoingPayment(final PDO pdo, final XmlLocationType enumXmlLocationType, final Map<String, Object> ctx) throws BusinessException ;
		sFromattedMsg = formattingDelegate.formatOutgoingPayment(pdo, enumXmlLocationType, null/* ctxMap */);

		return sFromattedMsg;
	}// EOM

	private static final class PDOListMemberResources {
		private QName pkQname;
		private UnMarshallingInfo anMarshallingInfo;
		private Field pdoListField;
		private Class clsListMemberInstance;
		private PdoListMemberType eunmListMemberType;
		private Method newInstanceMethod;

		public PDOListMemberResources(final UnMarshallingInfo anMarshallingInfo, final Field pdoListField, final String sNamespace) {

			this.anMarshallingInfo = anMarshallingInfo;
			this.pdoListField = pdoListField;
			final String sPkElementName = anMarshallingInfo.uidElementName();
			if (sPkElementName != null)
				this.pkQname = PaymentType.qname(sPkElementName, sNamespace);
		}// EOM
	}// EO inner class PDO List Member resources

	
	//mass payment retrofit
	
    @Override
    public final void batchSave(final boolean bRemovePDOFromCache, final Comparator<PDO> pdoListSorter, PDO...arrPDOs) throws Throwable{
    	this.batchSave(bRemovePDOFromCache, pdoListSorter, m_defaultPDOStateHandler, true,arrPDOs);
    }//EOM 

    @Override
    public final void batchSave(final boolean bRemovePDOFromCache,final boolean saveRelated , PDO...arrPDOs) throws Throwable {
		this.batchSave(bRemovePDOFromCache, (Comparator<PDO>) null/* pdoListSorter */,m_defaultPDOStateHandler, saveRelated, arrPDOs);
	}// EOM
    /**
	 * Method for retrieving pdo's by a pre-built in clause of MID's
	 * the clause should be in this format : "MID1, MID2, MID3"
	 * @param midsInClause
	 * @return list of pdo's of the given MIDs
	 */
	@Override
	public final List<PDO> performLoadFromPersistenceByMIDs(
	final String[] inClause,String orgnlGroupMsgId, final Connection connection) {
		
	  List<PDO> listPDO = new ArrayList<PDO>();
      String MID ;
      
      PDO pdo = null ; 
      
   	  for (int i = 0; i < inClause.length; i++) {
	    	MID =inClause[i];
	    	pdo = PaymentDataFactory.load(MID);
	    	//Retrieve the accounting MID that related to the payment
	    	Date sttlmDate = pdo.getDate(PDOConstantFieldsInterface.X_STTLM_DT_1B);
	        String formattedDate = GlobalDateTimeUtil.getFormattedDateString(sttlmDate,GlobalDateTimeUtil.STATIC_DATA_DATE);
	        APaymentPerGroupMsgID pmntGroup = CacheKeys.APaymentPerGroupMsgIDKey.getSingle(orgnlGroupMsgId,pdo.getString(PDOConstantFieldsInterface.P_SUSPENSE_ACCT_UID),formattedDate);
	        if(pmntGroup != null){
				pdo.set(PDOConstantFieldsInterface.ACCOUNTING_MID,pmntGroup.getAccountingMid());
	        }
	    	listPDO.add(pdo);
   	  }
      
      
      return listPDO;
	}
    
     /**
     * 
     */
  
	@Override
	public final List<PDO> performLoadFromPersistenceByChunkId(final String sChunkID, String orgnlMsgId , Integer partitionID, final Connection connection)
    {
      final String SELECT_STATEMENT = "SELECT P_MID FROM MINF WHERE P_OUT_CHUNK_ID = ? AND P_IS_HISTORY = ?";
      
      List<PDO> listPDO = new ArrayList<PDO>();
      
      Connection internalConnection = null;
      PreparedStatement ps = null;
      ResultSet rs = null;
      PreparedStatement psAccountigMID = null;
     
      
      try
      { 
        internalConnection = (connection == null ? this.m_dao.getConnection() : connection) ;  
        
        String sSelectStatement = SELECT_STATEMENT;
        String accountingMID = null;
        
        ps = internalConnection.prepareStatement(sSelectStatement) ;
        GlobalUtils.setObject(ps, 1, sChunkID);
        GlobalUtils.setObject(ps, 2, partitionID);
 
        //Retrieve the accounting MID that related to the chunk
        rs = ps.executeQuery();
        
        // Loops the ResultSet, gets from each row the MID value, and calls the 'performRelationalMapping'
        // for creating a PDO object that will be added to the returned list
        String sMID = null ; 
        PDO pdo = null ; 
        boolean alereadyGetDataFromCahce = false;
        
        while(rs.next()){
        	
        	sMID = rs.getString(PDOConstantFieldsInterface.P_MID);
        	pdo = PaymentDataFactory.load(sMID);
        	if (!alereadyGetDataFromCahce) {
        		Date sttlmDate = pdo.getDate(PDOConstantFieldsInterface.X_STTLM_DT_1B);
        		String formattedDate = GlobalDateTimeUtil.getFormattedDateString(sttlmDate,GlobalDateTimeUtil.STATIC_DATA_DATE);
        		APaymentPerGroupMsgID paymntGroup = CacheKeys.APaymentPerGroupMsgIDKey.getSingle(orgnlMsgId,pdo.getString(PDOConstantFieldsInterface.P_SUSPENSE_ACCT_UID),formattedDate);
        		if(paymntGroup !=null)
        			accountingMID = paymntGroup.getAccountingMid();
        		alereadyGetDataFromCahce = true;
        	}
			pdo.set(PDOConstantFieldsInterface.ACCOUNTING_MID,accountingMID);
        	listPDO.add(pdo);
        }
      }
      catch(Exception e)
      {
        ExceptionController.getInstance().handleException(e, this);
      }
      finally
      {
        this.m_dao.releaseResources(rs, ps, (connection == null ? internalConnection : null) ) ;
      } 
      
      return listPDO;
    } 
	//mass payment retrofit

	@Override
	public final PaymentFieldInterface createNSet(LogicalFields fieldMetadata, Object oValue, final PDO pdo, final boolean bIsLazyLoad) {
    	//System.out.println(fieldMetadata.fieldLogicalId + " --> " + bIsLazyLoad) ;
    	
    	final CacheServiceInterface cache = CacheServiceInterface.eINSTANCE ;
        final String ANY_ATTRIBUTE_PATH = "@*" ;                
        
        PaymentFieldInterface paymentField  = null ;
        
        String sLogicalFID = fieldMetadata.fieldLogicalId ;
        FieldType enumFieldType = fieldMetadata.enumFieldType;
        final boolean bXmlField = FieldType.isXmlType(enumFieldType) ; 
        //final boolean bXmlOrigField = !bXmlField && (XmlLocationType.reverseMapping(fieldMetadata.getLocation()) != null) ;
        final boolean bXmlOrigField = (enumFieldType == FieldType.ORIG_XML) ; 
        
        final Map<Object, PaymentFieldInterface> mapPdoDataMap = pdo.getDataMap() ;
        //if the element does not exist or is not of xml type, trace and create a derived field using 
        //the oValue as the data type indicator and subsequently the payment field indicator
        if(!bXmlField && !bXmlOrigField) { 
            	
        	//if the field type is of type reference, then a load of the cached member is required
            //the value would not be used in this case as it would have been extracted from the loaded 
            //cache member 
            if(enumFieldType == FieldType.REFERENCE) { 
                this.loadCachedMember(pdo, fieldMetadata.getObjRefDataId()) ; 
                
                //rertieve the payment field from the pdo's map as it had already been created 
                paymentField = mapPdoDataMap.get(sLogicalFID) ;
                //if the payment field does not exist, after the cached member load, put a place holder in the map 
                if (paymentField != null) oValue = paymentField.get();
                
                //if the payment field does not exist, after the cached member load, put a place holder in the map 
                else if(oValue == null) 
                {
                	if (fieldMetadata == null)
                	{
	                    paymentField = PaymentField.PLACE_HOLDER ; 
	                    mapPdoDataMap.put(sLogicalFID, paymentField) ;
                	}else
                	{
	                	paymentField = enumFieldType.newPaymentField(sLogicalFID, fieldMetadata, pdo) ;
	                	paymentField.set(oValue, pdo.isNew());
                	}
                }//EO if there was no payment field 
            }else if(!bIsLazyLoad && enumFieldType != FieldType.MEMBER || enumFieldType == FieldType.MONITOR_CHILD) { //only initilize if the context is not that of a lazy load 
                paymentField = enumFieldType.newPaymentField(sLogicalFID, fieldMetadata, pdo) ;
                //invoke the extra init hook method  
                paymentField.extraInit(pdo) ; 
                if (!bIsLazyLoad) paymentField.set(oValue, pdo.isNew()) ;
            }//EO else if the field type was not reference
            
            //if lazy load (i.e. get) set the payment field in the map,
            //if the latter was null set a place holder 
            if(bIsLazyLoad) { 
            	mapPdoDataMap.put(sLogicalFID, (paymentField == null ? PaymentField.PLACE_HOLDER : paymentField) ) ; 
            }//EO if lazyloasd 
            
            return paymentField; 
        }//EO if not xml type  
        
        //lazy load is prohibited for xml types. return null and not a
        //place holder as this method was invoked from the get() and not from the set()
        if(bIsLazyLoad) { 
        	mapPdoDataMap.put(sLogicalFID, PaymentField.PLACE_HOLDER) ; 
        	return null ;
        }//EO if lazy load & xml 
        
        //if the field is an orig field in a split mode simply create a derive field and return it 
        final boolean bConjoinedMode = pdo.isConjoined()  ;
        if(bXmlOrigField) { 
        	
        	if(!bConjoinedMode) { 
        		paymentField = enumFieldType.newPaymentField(sLogicalFID, fieldMetadata, pdo) ;
                //invoke the extra init hook method  
                paymentField.set(oValue, pdo.isNew()) ;
                paymentField.extraInit(pdo) ; 
                return paymentField ;  
        	}else { 
        		//create the current xml payment field by switching the id and the metadata with that of the orig_field id 
        		//this process would eventually create the orig field         		
        		sLogicalFID = fieldMetadata.getOrigFieldId() ; 
        		fieldMetadata = LogicalFieldsIdKey.getSingle(sLogicalFID) ; 
        		enumFieldType = fieldMetadata.enumFieldType ;
        	}//EO else if conjoined mode 
        	
        }//EO if orig field 
        
        //retreive the xml document metadata from the pdo associated with the fieldmetadata's location value 
        final PDO.XmlMetadata xmlMetadata = pdo.getXmlMetadata(fieldMetadata.location) ;        
     
        //get the xpath metadata per namespace map from the cache 
        Map<String, LogicalFieldsXpath> mapFieldsXPaths = CacheKeys.LogicalFieldsXPathKey.getSingle(xmlMetadata.getPaymentType()) ; 
        
        if(mapFieldsXPaths == null) { 
        	logger.error("Could not locate any xpath definitions for field %s in message type '%s', creating a derived field instead.",sLogicalFID, xmlMetadata.getPaymentType());
        	return FieldType.DERIVED.newPaymentField(sLogicalFID, oValue, pdo) ; 
        }//EO if the mapFieldsXPaths is null tarce the error and return null
        
        
        LogicalFieldsXpath targetElementXmlMetadata = mapFieldsXPaths.get(sLogicalFID) ;
        
        //if the field does was not defined for the given message type, create the field as derived and warn
        if(targetElementXmlMetadata == null) {
        	 
        	//if the field is a user defined field, create a new bogus logicalfieldsXpath and store in the map for future uses 
        	 boolean bUserDefinedField = false ; 
             //if( (bUserDefinedField = sLogicalFID.indexOf('^') != -1)) {
        	 if( (bUserDefinedField = fieldMetadata.isUDF())) {
             	final String[] arrUDFFieldParts = GlobalConstants.m_PowerSignSplitPattern.split(sLogicalFID, 0) ;  
        		
             	targetElementXmlMetadata = new LogicalFieldsXpath(sLogicalFID, arrUDFFieldParts[1]/*field id is the tagname*/, '/'+arrUDFFieldParts[1]/*field path*/, 
        				enumFieldType, fieldMetadata.getFieldXmlType(), fieldMetadata.getPathParentId(), fieldMetadata.location) ;
        		mapFieldsXPaths.put(sLogicalFID, targetElementXmlMetadata) ;
        	}//EO if user defined field 
        	else { 
        		logger.warn("Could not locate xml logical field '%s' definition for message type '%s', creating a derived field instead",sLogicalFID, xmlMetadata.getPaymentType());  
        		return FieldType.DERIVED.newPaymentField(sLogicalFID, oValue, pdo) ;
        	}//EO if not user defined field  
        }//EO if the target logical fields xpath was null
        

        final PaymentType enumPaymentType = xmlMetadata.getPaymentType() ; 
        String sTagName = targetElementXmlMetadata.tagName;                
        //get the group parent data 
        final LogicalFieldsXpath groupParentXmlMetadata = mapFieldsXPaths.get(fieldMetadata.getPathParentId()) ; 
        
        //construct the full path to the child
        String sPathToTargerNode = groupParentXmlMetadata.fieldPath + targetElementXmlMetadata.fieldPath  ;
        
        //remove any leading '/'s 
        int iSubStringStartIndex = 0 ; 
        if(sPathToTargerNode.charAt(1) == '/') iSubStringStartIndex = 2 ; 
        else if(sPathToTargerNode.charAt(0) == '/') iSubStringStartIndex = 1 ;
                    
        String arrFullPathToChildNode[] = GlobalConstants.m_forwardSlashSplitPattern.split(sPathToTargerNode.substring(iSubStringStartIndex)) ; 
        
        //prepare metadata required for the loop 
        final String sNamespace = enumPaymentType.getSchemaNamespace() ;
        
        //iterate over the path items, locate and if not present create         
        int iLength = arrFullPathToChildNode.length ; 
        String sCurrentNodeName = null ; 
        //start from the root 
        XmlObjectBase currentPathElement = xmlMetadata.getXml() ;  
        
        for(int i=0; i < iLength; i++) {
            
            sCurrentNodeName = arrFullPathToChildNode[i] ;
//            if(sCurrentNodeName.equals(ANY_ATTRIBUTE_PATH)) sCurrentNodeName = sTagName ;             
            currentPathElement = this.getOrCreateImmidiateChild(currentPathElement, sCurrentNodeName, 0, sNamespace, sTagName) ; 
            
        }//EO while there are more path items 
        
        //if the element was not present return a place holder 
        if(currentPathElement == null) return PaymentField.PLACE_HOLDER ; 
         
        //set the value in the object 
        fieldMetadata.enumDataType.setXbeanValue(currentPathElement, oValue) ; 
        
        //create a payment field for the object and return it.
        paymentField = enumFieldType.newPaymentField(sLogicalFID, fieldMetadata, pdo) ; 
        ((XmlPaymentField)paymentField).setFromXml(currentPathElement, targetElementXmlMetadata, enumPaymentType, false/*bUpdateOrigVal*/) ;
        
        //if the payment is in initial create mode (user create) and the field has an orig field id value 
        //create an additional payment field for the orig field, set the value in it, set the first instance in the second
        //and the second in the first 
        
        //[0] - should derive orig fields from given xml 
        //[1] - should perform xml mapping 
        final boolean[] arrShouldParseAndDeriveOrigFields = 
        	XmlLocationType.reverseMapping(fieldMetadata.location).shouldPerformXmlMapping(pdo, bConjoinedMode) ; 
        
        this.handleOrigPaymentField(pdo, mapFieldsXPaths, currentPathElement, paymentField, fieldMetadata, enumPaymentType, 
        		arrShouldParseAndDeriveOrigFields[0], bConjoinedMode, false/*bUpdateOrigVal*/) ;
		
        //if the orig field id flag is true, then the actual payment field is the current one. 
        //but the returned result is the orig. therefore, cache the current in the map 
        if(bXmlOrigField) { 
        	 mapPdoDataMap.put(sLogicalFID, paymentField)  ;
        	 paymentField = paymentField.getLinkedPaymentField() ; 
        }//EO if xml orig field 
        
		//return the requestsed payment field (might be the linked field is the bOrigXmlField is  true 
		return paymentField ; 
    }//EOM

}// EOC
