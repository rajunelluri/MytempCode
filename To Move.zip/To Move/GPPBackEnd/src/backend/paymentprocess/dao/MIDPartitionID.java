package backend.paymentprocess.dao;

public class MIDPartitionID {

	private String mid;
	private String partitionID;
	
	public MIDPartitionID(String mid, String partitionID) {
		super();
		this.mid = mid;
		this.partitionID = partitionID;
	}
	public String getMid() {
		return mid;
	}
	public void setMid(String mid) {
		this.mid = mid;
	}
	public String getPartitionID() {
		return partitionID;
	}
	public void setPartitionID(String partitionID) {
		this.partitionID = partitionID;
	}
	
	
	
}
