package backend.paymentprocess.fileapproval.businessobjects;



import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.List;

import com.fundtech.annotations.Expose;
import com.fundtech.annotations.Wrap;
import com.fundtech.annotations.Expose.ExposureType;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.general.flows.FlowException;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.util.ExceptionController;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalUtils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import backend.core.module.BOCoreServices;
import backend.core.module.MessageConstantsInterface;
import backend.paymentprocess.SubBatchProcessInterface;
import backend.paymentprocess.debulkingprocess.dao.DAODebulkingProcess;
import backend.paymentprocess.enrichment.commons.InterfaceSubTypeFlow;
import backend.paymentprocess.highvalueprocess.businessobjects.BOHighValueProcess;


@Wrap

public class BOFileApproval extends BOCoreServices 
{

	private static final Logger logger = LoggerFactory.getLogger(BOFileApproval.class);
	private static final DAODebulkingProcess m_daoDebulking = DAODebulkingProcess.getInstance();
	
	private static String MESSAGE_STATUS_EQUALS_PENDING_FILE_APPROVAL = " "+PDOConstantFieldsInterface.P_MSG_STS+" = '"+MessageConstantsInterface.MESSAGE_STATUS_PENDING_FILE_APPROVAL+ "'";
	private static Method m_processFileApprovalInner = null;

	  
//	static
//	{
//		try
//		{
//			m_processFileApprovalInner = BODebulkingProcess.class.getDeclaredMethod("processFileApprovalInner", String.class);
//		}catch(Exception e)
//		{
//			logger.error(e.getMessage());
//		}
//	}
	@Expose(type=ExposureType.InternalInterface) 
	public Feedback processFileApproval(String input) throws FlowException
	{
		return(Feedback) this.processFileApprovalInner(input);
	}
	
	private Feedback processFileApprovalInner(String input) throws FlowException
	{
		
		logger.info("File Approval: input = {}", input);
		Feedback feedback = new Feedback();
		String[] inputArr =input.split(",");
		String internalFileId = inputArr[0];
		String chunkId = inputArr[1];
		Admin admin = Admin.getContextAdmin();
		
		PDO dummyPdo = PaymentDataFactory.newPDO();
		dummyPdo.set(PDOConstantFieldsInterface.P_IN_INTERNAL_FILEID, internalFileId);
		
		String flowType = InterfaceSubTypeFlow.getFlowType(dummyPdo.getNSetIncomingFileSummary().getPlFileType());
		
		int isHistoryValue = dummyPdo.getNSetIncomingFileSummary() != null && SubBatchProcessInterface.WORKFLOW_TEMPLATE.equals(dummyPdo.getNSetIncomingFileSummary().getWorkflow()) ? 2 : 
								GlobalConstants.BP.equals(flowType) ? GlobalUtils.getPartitionIDByMID(internalFileId) : 0; 
		List<PDO> pdoList = PaymentDataFactory.load(internalFileId, chunkId, null, isHistoryValue,MESSAGE_STATUS_EQUALS_PENDING_FILE_APPROVAL);
		
		try
		{
		
			if (pdoList != null && pdoList.size() > 0)
			{
				PDO pdo = null;
				int size = pdoList.size();
				for (int i =0; i < size && feedback.isSuccessful(); i++) 
				{
					pdo = pdoList.get(i);
					pdo.promoteToPrimary();
					logger.info("File Approval: approve payment {}", pdo.getMID());
//					pdo.set(PDOConstantFieldsInterface.D_IS_CONT_FLOW_UNTIL_HANDOFF, true);
					CacheKeys.ProcessSessionsKey.propagate(false, true);
	
					// Executes the business flow selection, where if no business flow definition rule is defined for this
					// message properties, process will be stopped.
//					feedback = BOBusinessFlowSelector.m_businessFlowSelectorLogging.executeFlow(admin, pdo.getMID(), false, ServerConstants.EMPTY_OBJECT_ARRAY);
					
//			    	String[] arrObjectIDs = new String[] { pdo.getString(PDOConstantFieldsInterface.P_OFFICE) };
//			    	List<RuleResult> listRuleResults = BORuleExecution.m_internalRuleExecutionLogging.executeRule(Admin.getContextAdmin(),
//								MessageConstantsInterface.RULE_TYPE_ID_GUI_WORKFLOW_STATUS_SELECTION, null, pdo.getMID(), arrObjectIDs).getResults();
//
//
//					String sStatusSelectionResult = null;
//					
//					if (!listRuleResults.isEmpty())
//					{
//						sStatusSelectionResult = listRuleResults.get(0).getAction();
////							if rule returned a valid status, update P_MSG_STS, o/w continue flow.
//						if (CacheKeys.statusesKey.getSingle(sStatusSelectionResult) != null)
//						{
//							pdo.set(PDOConstantFieldsInterface.P_MSG_STS, sStatusSelectionResult);
//						}else
//							ErrorAuditUtils.setError(ProcessErrorConstants.MessageStatusUpdateFaulire, pdo.getMID(), feedback);
//					}else
//						ErrorAuditUtils.setError(ProcessErrorConstants.MessageStatusUpdateFaulire, pdo.getMID(), feedback);
					
					pdo.set(PDOConstantFieldsInterface.P_PREVIOUS_MSG_STS, pdo.getString(PDOConstantFieldsInterface.P_MSG_STS));
					pdo.set(PDOConstantFieldsInterface.P_MSG_STS, MessageConstantsInterface.MESSAGE_STATUS_PEND_APPROV);


					
					
					BOHighValueProcess.performNotificationFlow(pdo);
	
					CacheKeys.ProcessSessionsKey.apply();
				}
				
			}else
			{
				logger.info("File Approval: no payments for internal file id = {}, chunk id = {} and msg status = 'PENDING_FILE_APPROVAL'", internalFileId, chunkId);
			}
			
			if (feedback.isSuccessful())
			{
				logger.info("File Approval: save all payments");
				PaymentDataFactory.batchSave(true, pdoList.toArray(new PDO[pdoList.size()]));
				logger.info("File Approval: update file_process_distribution status = 'Completed'");
				updateFileProcessDistributionStatus(SubBatchProcessInterface.STATUS_COMPLETED, internalFileId, chunkId);
				
			}
		}catch(Throwable t)
		{
			ExceptionController.getInstance().handleException(t, this);
			feedback.setFailure();
	        feedback.setErrorCode(1);
	        
	        throw new FlowException(t);
		}
		
		return feedback;
	}
	
	
	private void updateFileProcessDistributionStatus(String status, String internalFileId, String chunkId) throws Exception
	{
		Connection conn = null;
		PreparedStatement ps = null;
		try
		{
			conn = m_daoDebulking.getConnection();
			ps = m_daoDebulking.updateFileProcessDistributionStatus(conn, status, internalFileId, chunkId);
			ps.executeUpdate();
		}finally
		{
			m_daoDebulking.releaseResources(conn, ps);
		}

	}
}
