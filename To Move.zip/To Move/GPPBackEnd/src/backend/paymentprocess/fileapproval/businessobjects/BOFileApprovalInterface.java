package backend.paymentprocess.fileapproval.businessobjects;

import com.fundtech.core.general.flows.FlowException;
import com.fundtech.core.security.Admin;

/**
 * internal interface for BOFileApproval.
 */
public interface BOFileApprovalInterface{

	
	
	public com.fundtech.datacomponent.response.Feedback processFileApproval(final Admin admin, java.lang.String input ) throws FlowException;

}//EOI  