package backend.paymentprocess.debitauthorization.businessobjects;



import java.util.List;

import com.fundtech.annotations.DataSource;
import com.fundtech.annotations.Expose;
import com.fundtech.annotations.Wrap;
import com.fundtech.cache.entities.Customrs;
import com.fundtech.cache.entities.DebitAuthorization;
import com.fundtech.cache.entities.FileSummary;
import com.fundtech.cache.entities.RuleResult;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.core.paymentprocess.errorhandling.ProcessError;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.errors.ProcessErrorConstants;
import com.fundtech.util.GlobalUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import backend.businessobject.BOBasic;
import backend.businessobject.BOProxies;
import backend.businessobject.proxies.LoadPDO;
import backend.core.module.MessageConstantsInterface;
import backend.paymentprocess.debitauthorization.exception.DebitAuthorizationException;
import backend.paymentprocess.paymentservices.businessobjects.BOPaymentServices;


@Wrap(datasources={@DataSource(datasourceJndiKey="active")})

public class BODebitAuthorization extends BOBasic implements PDOConstantFieldsInterface
{

	private static final Logger logger = LoggerFactory.getLogger(BODebitAuthorization.class);
    private static String SKIP = "SKIP";
    private static String SUCCESS = "SUCCESS";
    private static String FAIL = "FAIL";

    public BODebitAuthorization()
    {
        super();
    }
    
    /**
     * The Debit Authorization service validates that the sender of the funds is authorized to debit an account which is not owned by him
     * 
     * @param mid
     * @throws DebitAuthorizationException 
     * 
     *
     */
    @Expose
    @LoadPDO
    public Feedback performDebitAuthorization(String mid) throws DebitAuthorizationException
    {
    	
    	
    	PDO pdo = PaymentDataFactory.load(mid);
      Feedback feedback = new Feedback();
      logger.info("Debit Auth. - Start Perform Debit Authorization MID="+pdo.getMID());
      String batchMsgType = pdo.getString(PDOConstantFieldsInterface.P_BATCH_MSG_TP); 
      String debitCustCode = pdo.getString(PDOConstantFieldsInterface.P_DBT_CUST_CD);
      Customrs senderCustomer = CacheKeys.customrsBICandOfficeKey.getSingle(pdo.getString(PDOConstantFieldsInterface.X_INSTG_AGT_BIC_2AND), pdo.getString(PDOConstantFieldsInterface.P_OFFICE));
      String initgPtyCustCode = null;
      String office=null;
      if (batchMsgType != null && batchMsgType.equals("S"))
      {
      	FileSummary fileSummary = pdo.getNSetIncomingFileSummary();
          logger.info("Debit Auth. - Batch message type equals 'S' -> initgPtyCustCode = fileSummary.getInitgPtyCustCode()");
          initgPtyCustCode = fileSummary.getInitgPtyCustCode();
          office = fileSummary.getOffice();
      }else if (pdo.getString(PDOConstantFieldsInterface.P_ORG_INITG_PTY_CUST_CD) != null && pdo.getString(PDOConstantFieldsInterface.P_ORIG_MSG_TYPE).toUpperCase().indexOf("PAIN")>-1)
      {
          logger.info("Debit Auth. - P_ORG_INITG_PTY_CUST_CD logical field like 'PAIN' -> initgPtyCustCode = P_ORG_INITG_PTY_CUST_CD");
          initgPtyCustCode = pdo.getString(PDOConstantFieldsInterface.P_ORG_INITG_PTY_CUST_CD);
          office=pdo.getString(PDOConstantFieldsInterface.P_OFFICE);
      }
      if (initgPtyCustCode != null )    
      {
      	Customrs cust = CacheKeys.customrsKey.getSingle(initgPtyCustCode, office);
      	String sDebitAccountUID = pdo.getNSetDEBIT_ACCOUNT().getUidAccounts();
      	String[] arrDebitAccountUID = sDebitAccountUID.split("\\^");
      	
        if (   debitCustCode != null && !debitCustCode.equals(initgPtyCustCode) 
        		&& !BOPaymentServices.isCustCodeAdditionalOwnerOfAccount(arrDebitAccountUID[0], arrDebitAccountUID[1], arrDebitAccountUID[2], initgPtyCustCode))
        {
        	pdo.set(PDOConstantFieldsInterface.D_DEBIT_AUTHORIZATION, FAIL);
        	
        	final String TRACE_NULL_CUSTOMER = "Null customer for initiating party cust code {} and office {}; will use NO_CUST_NAME for related process error.";
        	final String NO_CUST_NAME = "NO_CUST_NAME";
        	
        	String sCustName = null;
        	if(cust == null)
        	{
        		logger.info(TRACE_NULL_CUSTOMER, initgPtyCustCode, office);
        		sCustName = NO_CUST_NAME;
        	}
        	else
        	{
        		sCustName = cust.getCustName();
        	}
        		
          ProcessError pError = ProcessError.getError(ProcessErrorConstants.DebitAuthorizationSubBatchFail, new String[]{sCustName, pdo.getString(PDOConstantFieldsInterface.P_DBT_ACCT_NB)}, null);
        	
          pdo.setTransient(PDOConstantFieldsInterface.D_DEBIT_AUTHORIZATION_PROCESS_ERROR, pError);
          pdo.set(PDOConstantFieldsInterface.P_MSG_STS, MessageConstantsInterface.MESSAGE_STATUS_REPAIR);
        }
        else
        {
        	pdo.set(PDOConstantFieldsInterface.D_DEBIT_AUTHORIZATION, SUCCESS);
        }
          
      }else if (debitCustCode != null && (senderCustomer == null || (!debitCustCode.equals(senderCustomer.getCustCode()))))
      {//The debit authorization service is invoked whenever the original sender of the transaction is different than the debit account owner.
          List<RuleResult> list = null;
          try
          {
              logger.info("Debit Auth. - Execute skip debit authorization rule ");
              list=BOProxies.m_internalRuleExecutionLogging.executeRule(Admin.getContextAdmin(), MessageConstantsInterface.RULE_TYPE_ID_SKIP_DEBIT_AUTHORIZATION,null
                              ,pdo.getString(PDOConstantFieldsInterface.P_MID),new String[]{pdo.getString(PDOConstantFieldsInterface.P_OFFICE)})
                              .getResults() ;
          }
          catch(Exception e)
          {
        	  logger.error(e.getMessage());
              
              throw new DebitAuthorizationException("Exception during rule execution: ", e);
          } 
          
          if (list.size() > 0)
          {
              if (list.get(0).getAction().equals(SKIP))
              {
                  logger.info(String.format("Debit Auth. - Rule {} returned SKIP action",list.get(0).getRuleUID()));
                  pdo.set(PDOConstantFieldsInterface.D_DEBIT_AUTHORIZATION, SKIP);
                  
//                    Skip debit authorization is written to rule log, therefore, no need to add it to audit trail.
//                    final Prules prule = CacheKeys.PRulesUIDKey.getSingle(list.get(0).getRuleUID()) ;
//                    ProcessError pError = ProcessError.getError(ProcessErrorConstants.DebitAuthorizationBypass, new String[]{prule.getRuleName()}, null);
//                    ErrorAuditUtils.setErrors(pError);
                  
              }
              else
              {
                  logger.info("Debit Auth. - Wrong action for Skip Debit Authorization rule");
                  throw new DebitAuthorizationException("Wrong action for Skip Debit Authorization rule");
              }
          }else
              validateDebitAuthorization(pdo, feedback);
          
      } else if (debitCustCode == null){
    	  logger.debug("Debit Auth. - P_DBT_CUST_CD is empty.");
      }
      
      return feedback;
    }
    
    /**
     * 
     */
    private void validateDebitAuthorization(PDO pdo, Feedback feedback)
    {
      if (pdo.getNSetDEBIT_CUSTOMER() == null) {
    	  logger.debug("missing debit customer, do nothing");
    	  return;
      }
    	
      logger.info("Debit Auth. - No skip debit authorization rules was found, start validation");
      String senderBIC = pdo.getString(PDOConstantFieldsInterface.X_INSTG_AGT_BIC_2AND);
      String ownerBIC = pdo.getNSetDEBIT_CUSTOMER().getSwiftId();
      String accNum = pdo.getString(PDOConstantFieldsInterface.P_DBT_ACCT_NB);
      String accCcy = pdo.getString(PDOConstantFieldsInterface.P_DBT_ACCT_CCY);
      
      logger.info("Debit Auth. - sender id= {}, debit acc. owner id= {}, debit acc.= {}",new Object[]{ senderBIC,ownerBIC,accNum});
      List<DebitAuthorization> list = CacheKeys.debitAuthorizationKey.get(senderBIC,ownerBIC,accNum,accCcy);
      
      if (list!=null && list.size() > 0)
          logger.info("Debit Auth. - Entries found {}", 
                  GlobalUtils.getArrayValuesAsString(list.toArray(new Object[list.size()])));
      else
          logger.info("Debit Auth. - No entries found");
        
      //If the cache result is empty, the there is no authorization
      //If the cache result size more then one, then the cache returned authorization and exclusion which fits 
      //sender and owner BICs.
      if (list != null && list.size() == 1)
      {
          pdo.set(PDOConstantFieldsInterface.D_DEBIT_AUTHORIZATION, SUCCESS);
//            ProcessError pError = ProcessError.getError(ProcessErrorConstants.DebitAuthorizationSuccess, new String[]{senderBIC,accNum}, null);
//            ErrorAuditUtils.setErrors(pError);
      }
      else
      {
          pdo.set(PDOConstantFieldsInterface.D_DEBIT_AUTHORIZATION, FAIL);
          ProcessError pError = ProcessError.getError(ProcessErrorConstants.DebitAuthorizationFail, new String[]{senderBIC,accNum,ownerBIC}, null);
//            configureErrorFeedback(ProcessErrorConstants.DebitAuthorizationFail,pError.getDescription(),feedback);
          
          pdo.setTransient(PDOConstantFieldsInterface.D_DEBIT_AUTHORIZATION_PROCESS_ERROR, pError);

//            ErrorAuditUtils.setErrors(pError);
      }
      
      
    }
}
