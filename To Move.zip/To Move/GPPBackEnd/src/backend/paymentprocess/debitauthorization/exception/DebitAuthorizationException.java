package backend.paymentprocess.debitauthorization.exception;

import com.fundtech.core.paymentprocess.errorhandling.BusinessException;

public class DebitAuthorizationException extends BusinessException
{
    public DebitAuthorizationException(int iErrorCode)
    {
        super(iErrorCode);
    }

    public DebitAuthorizationException(String string, Throwable e)
    {
        super(string, e);
    }

    public DebitAuthorizationException()
    {
        super();
    }

    public DebitAuthorizationException(String sErrorDescription)
    {
        super(sErrorDescription);
    }
}

