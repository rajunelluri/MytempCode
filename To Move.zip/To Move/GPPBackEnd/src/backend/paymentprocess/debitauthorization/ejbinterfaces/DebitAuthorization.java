package backend.paymentprocess.debitauthorization.ejbinterfaces;

import javax.ejb.Remote;
import com.fundtech.core.security.Admin;

/**
 * Remote interface for DebitAuthorization.
 */
@Remote
public interface DebitAuthorization{

	public static final String REMOTE_JNDI_NAME="ejb/DebitAuthorizationBean";
	
	
	/** 
	 * The Debit Authorization service validates that the sender of the funds is authorized to debit an account which is not owned by him
	 * @param mid
	 * @throws DebitAuthorizationException 
	 */
	public com.fundtech.datacomponent.response.Feedback performDebitAuthorization(final Admin admin, java.lang.String mid ) throws backend.paymentprocess.debitauthorization.exception.DebitAuthorizationException ;

}//EOI  