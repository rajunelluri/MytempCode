package backend.paymentprocess.debitauthorization.ejbinterfaces;

import javax.ejb.Local;

/**
 * Local interface for DebitAuthorization.
 */
@Local
public interface DebitAuthorizationLocal extends DebitAuthorization{} ; 