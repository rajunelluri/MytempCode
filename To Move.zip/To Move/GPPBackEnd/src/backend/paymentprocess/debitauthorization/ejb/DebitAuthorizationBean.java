package backend.paymentprocess.debitauthorization.ejb;

import javax.ejb.Stateless;
import backend.core.SuperSLSB;
import com.fundtech.core.security.Admin;
import backend.businessobject.proxies.interceptors.InterceptorSetType;
import backend.paymentprocess.debitauthorization.businessobjects.BODebitAuthorization;
import backend.paymentprocess.debitauthorization.ejbinterfaces.DebitAuthorizationLocal;
import backend.paymentprocess.debitauthorization.ejbinterfaces.DebitAuthorization;

@Stateless
public class DebitAuthorizationBean extends SuperSLSB<DebitAuthorization> implements DebitAuthorizationLocal, DebitAuthorization{
	
	public DebitAuthorizationBean() { super(backend.paymentprocess.debitauthorization.businessobjects.BODebitAuthorization.class, InterceptorSetType.Complete) ; }//EOM
	
	
	/** 
	 * The Debit Authorization service validates that the sender of the funds is authorized to debit an account which is not owned by him
	 * @param mid
	 * @throws DebitAuthorizationException 
	 */
	public com.fundtech.datacomponent.response.Feedback performDebitAuthorization(final Admin admin, java.lang.String mid ) throws backend.paymentprocess.debitauthorization.exception.DebitAuthorizationException {
		return this.m_bo.performDebitAuthorization(admin, mid ) ;
	}//EOM

}//EOC