package backend.paymentprocess.creditdailylimit.businessobjects;

import com.fundtech.core.security.Admin;

/**
 * internal interface for BOCreditDailyLimit.
 */
public interface BOCreditDailyLimitInterface{

	
	
	/** 
	 * Handles credit daily transfer.
	 * @param pdo PDO object.
	 * @param sInternalFileID MUST hold a value when this method is called for a BATCH payment.
	 * for SINGLE payment, send this avlue as null.
	 * @param arrDailyTransferTotalBaseAmount String[1] which will be set with the total base amount. 
	 * @param arrDailyTransferUpdated boolean[1] initialized with 'false' value which will be set with whether the CDT_DAILY_TRANSFER
	 * table was updated or not, for case of rollback. 
	 * @param arrCreditLimitExists boolean[1] initialized with 'false' value which will be set to 'true' in case there is a limit for 
	 * the dealt customer. 
	 */
	public com.fundtech.datacomponent.response.Feedback handleCreditDailyTransfer(final Admin admin, com.fundtech.core.paymentprocess.data.PDO pdo, java.lang.String sInternalFileID, java.lang.String[] arrDailyTransferTotalBaseAmount, java.lang.Boolean[] arrDailyTransferUpdated, java.lang.Boolean[] arrCreditLimitExists ) ;
	
	/** 
	 */
	public void rollbackDailyTransferChanges(final Admin admin, java.lang.String sDailyTransferTotalBaseAmount, com.fundtech.core.paymentprocess.data.PDO pdo ) ;

}//EOI  