package backend.paymentprocess.creditdailylimit.businessobjects;



import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.businessobject.proxies.SkipInputValidation;
import backend.core.module.BOCoreServices;
import backend.core.module.MessageConstantsInterface;
import backend.core.module.ejbinterfaces.TxIsolation;
import backend.dataaccess.dto.DTOSingleValue;
import backend.paymentprocess.SubBatchProcessInterface;
import backend.paymentprocess.creditdailylimit.dao.DAOCreditDailyLimit;
import backend.paymentprocess.erroraudit.ErrorAuditUtils;
import backend.paymentprocess.subbatchgeneration.dao.DAOSubBatchGeneration;
import backend.util.ServerConstants;

import com.fundtech.annotations.Expose;
import com.fundtech.annotations.Expose.ExposureType;
import com.fundtech.annotations.Wrap;
import com.fundtech.cache.entities.Customrs;
import com.fundtech.cache.entities.FileSummary;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.errorhandling.ProcessError;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.errors.ProcessErrorConstants;
import com.fundtech.jndi.ServiceLocator;
import com.fundtech.util.ExceptionController;
import com.fundtech.util.GlobalDateTimeUtil;


/**
 * Title:       BOCreditDailyLimit
 * Description: Business object for credit daily limit
 * Company:     Fundtech Israel
 * Author:      Asaf Levy
 * Date:        06/04/2009
 * @version     1.0
 */
@Wrap

public class BOCreditDailyLimit extends BOCoreServices implements SubBatchProcessInterface, PDOConstantFieldsInterface, MessageConstantsInterface
{

  private static final Logger logger = LoggerFactory.getLogger(BOCreditDailyLimit.class);
  private static DAOCreditDailyLimit m_daoCreditDailyLimit =  DAOCreditDailyLimit.getInstance();
  private static DAOSubBatchGeneration m_daoSubBatchGeneration =  DAOSubBatchGeneration.getInstance();

  //private static BackendTracer GlobalTracer = GlobalTracer;
  
  /**
   * Handles credit daily transfer.
   * @param pdo PDO object.
   * @param sInternalFileID MUST hold a value when this method is called for a BATCH payment.
   *        for SINGLE payment, send this avlue as null.
   * @param arrDailyTransferTotalBaseAmount String[1] which will be set with the total base amount. 
   * @param arrDailyTransferUpdated boolean[1] initialized with 'false' value which will be set with whether the CDT_DAILY_TRANSFER
   *                                table was updated or not, for case of rollback. 
   * @param arrCreditLimitExists boolean[1] initialized with 'false' value which will be set to 'true' in case there is a limit for 
   *                             the dealt customer. 
   */
  @SkipInputValidation
  @Expose(type = ExposureType.InternalInterface)
  public Feedback handleCreditDailyTransfer(PDO pdo, String sInternalFileID, String[] arrDailyTransferTotalBaseAmount,
                                            Boolean[] arrDailyTransferUpdated, Boolean[] arrCreditLimitExists)
  {
  	final String TRACE = "Internal file ID: %s, ";
    final String NUM_OF_UPDATED_RECORDS = "BOCreditDailyTransfer.handleCreditDailyTransfer - number of updated records: ";
    
    String sTracePrefix = String.format("'handleCreditDailyTransfer', (Internal file ID: %s); ", sInternalFileID);
    
    
    Feedback feedback = new Feedback();
    Admin admin = Admin.getContextAdmin();
    boolean bSinglePayment = sInternalFileID == null;
    
    try
    {
      String sInitiatingPartyCustCode = pdo.getString(P_ORG_INITG_PTY_CUST_CD);
      
      // Continues if:
      //    1) Batch payment, (don't assumes that in that case the initiaiting party cust code always exists).
      // OR 2) Single PAIN payment with a valid initiaiting party cust code. 
      if(   !bSinglePayment && sInitiatingPartyCustCode != null
         || (bSinglePayment && sInitiatingPartyCustCode != null && pdo.getString(P_ORIG_MSG_TYPE).toUpperCase().indexOf(MESSAGE_TYPE_PAIN) > -1) ) {    
    	logger.info(sTracePrefix);
    	
        Customrs customrs = CacheKeys.customrsCCKey.getSingle(sInitiatingPartyCustCode/*, pdo.getString(P_OFFICE)*/);
        
        
        Long lDailyCdtXferLimit = customrs.getDailyCdtXferLimit();
        logger.info(sTracePrefix + "lDailyCdtXferLimit: " + lDailyCdtXferLimit);
        
        if(lDailyCdtXferLimit != null)
        {
          // For the caller method.
          arrCreditLimitExists[0] = ServerConstants.BOOL_TRUE;
          
          String sTotalBaseAmount = null;
          boolean bOverrideLimitCheck = false;
          FileSummary fileSummary = pdo.getNSetIncomingFileSummary();
          // Single payment.
          if(bSinglePayment)
          {
            bOverrideLimitCheck = pdo.getString(D_FORCE_CDTRANSFERLIMIT) != null?
                                  pdo.getString(D_FORCE_CDTRANSFERLIMIT).equals(MONITOR_FLAG_FORCE) : false;
            sTotalBaseAmount = pdo.getString(P_CUST_BASE_AMT);
          }
          
          // Batch.
          else
          {
            DTOSingleValue dto = m_daoCreditDailyLimit.getTotalBaseAmountForCreditDailyTransfer(sInternalFileID);
            
            feedback = dto.getFeedBack();
            
            if(feedback.isSuccessful())
            {
              sTotalBaseAmount = dto.getValue();
              bOverrideLimitCheck = fileSummary.getOverrideLimitCheck();
            }
          }
          
          if(feedback.isSuccessful())
          {
            arrDailyTransferTotalBaseAmount[0] = sTotalBaseAmount;
               
            Date dateBusinessDate = CacheKeys.banksKey.getSingle(customrs.getOffice()).getBsnessdate();
            String sBusinessDate = GlobalDateTimeUtil.getFormattedDateString(dateBusinessDate, GlobalDateTimeUtil.STATIC_DATA_DATE);
            
            int[] arrAffectedRows = new int[1];
            feedback = ServiceLocator.getInstance().SLSBlookup(TxIsolation.class).updateCDT_DAILY_TRANSFER_Table(admin, sTotalBaseAmount, sInitiatingPartyCustCode, sBusinessDate, lDailyCdtXferLimit, bOverrideLimitCheck, arrAffectedRows);
            
            logger.info(NUM_OF_UPDATED_RECORDS + arrAffectedRows[0]);
            
            Boolean boolDailyTransferUpdated = Boolean.valueOf(arrAffectedRows[0] > 0);
            
            // For the caller method.
            arrDailyTransferUpdated[0] = boolDailyTransferUpdated;
            
            // No records were updated.
            if(!boolDailyTransferUpdated.booleanValue())
            {
              // Batch.
              if(!bSinglePayment)
              {
                feedback = m_daoSubBatchGeneration.updateFILE_SUMMARY_Table(sInternalFileID, STATUS_FILE_EXHAUST_LIMIT, fileSummary.getStatus(), 0);
              }
              
              // Single payment.
              else
              {
                pdo.set(P_MSG_STS, MessageConstantsInterface.MESSAGE_STATUS_CDTRANSFERLIMIT); 

                Object[] arrNonPaymentFields = new Object[]{sInitiatingPartyCustCode, lDailyCdtXferLimit};

                // Error code 40089: 'Initiating party |1 has exhausted daily Limit |2 - payment was routed to CDTRANSFERLIMIT'.
                ProcessError processError = new ProcessError(ProcessErrorConstants.CreditDailyLimitExhaustedLimit, arrNonPaymentFields);
                ErrorAuditUtils.setErrors(processError,pdo.getIsHistory());
              }
            }
          }
        }
      } else {
    	  logger.debug("avoid handling Credit Daily Transfer, conditions are not meet");
      }
    }
    
    catch(Exception e)
    {
      ExceptionController.getInstance().handleException(e, this);
      feedback.setFailure();
      feedback.setErrorCode(1);
      feedback.setException(e);
    }

     
    
    return feedback;
  }
  
  /**
   * 
   */
  @SkipInputValidation
  @Expose(type = ExposureType.InternalInterface)
  public void rollbackDailyTransferChanges(String sDailyTransferTotalBaseAmount, PDO pdo)
  {
    
    
    Admin admin = Admin.getContextAdmin();
    
    final String NUM_OF_ROLLED_BACK_RECORDS = "BOCreditDailyTransfer.rollbackDailyTransferChanges - number of rolled-back records: ";
    
    try
    {
      FileSummary fileSummary = pdo.getNSetIncomingFileSummary();
      String sFileSummaryCustCode = fileSummary.getInitgPtyCustCode();
      Customrs customrs = CacheKeys.customrsCCKey.getSingle(sFileSummaryCustCode/*, fileSummary.getOffice()*/);
      
      Date dateBusinessDate = CacheKeys.banksKey.getSingle(customrs.getOffice()).getBsnessdate();
      String sBusinessDate = GlobalDateTimeUtil.getFormattedDateString(dateBusinessDate, GlobalDateTimeUtil.STATIC_DATA_DATE);
      
      int[] arrAffectedRows = new int[1];
            
      Feedback feedback = ServiceLocator.getInstance().SLSBlookup(TxIsolation.class).rollbackCDT_DAILY_TRANSFER_Changes(admin, sDailyTransferTotalBaseAmount, sFileSummaryCustCode, sBusinessDate, arrAffectedRows);
      logger.info(NUM_OF_ROLLED_BACK_RECORDS + arrAffectedRows[0]);
    }
    
    catch(Exception e)
    {
      ExceptionController.getInstance().handleException(e, this);
    }
    
    
  }
}
