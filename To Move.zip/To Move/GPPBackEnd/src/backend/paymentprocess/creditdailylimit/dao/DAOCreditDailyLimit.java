package backend.paymentprocess.creditdailylimit.dao;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Date;

import com.fundtech.core.general.StatementParameter;
import com.fundtech.datacomponent.response.Feedback;

import backend.dataaccess.dao.DAOBasic;
import backend.dataaccess.dto.DTOSingleValue;
import backend.paymentprocess.SubBatchProcessInterface;
import backend.util.ServerConstants;

/**
 * Title:       DAOCreditDailyLimit
 * Description: DAO object for credit daily limit
 * Company:     Fundtech Israel
 * Author:      Asaf Levy
 * Date:        17/03/2009
 * @version     1.0
 */
public class DAOCreditDailyLimit extends DAOBasic implements SubBatchProcessInterface
{
  private static DAOCreditDailyLimit m_daoCreditDailyLimit = new DAOCreditDailyLimit();
  
  /**
   * Private constructor. 
   */
  private DAOCreditDailyLimit()
  {
  }
  
  public static DAOCreditDailyLimit getInstance()
  {
  	return m_daoCreditDailyLimit;
  }
  
  /**
   * 
   */
  public DTOSingleValue getTotalBaseAmountForCreditDailyTransfer(String sInternalFileID)
  {
    final String SELECT_STATEMENT = "SELECT SUM(TOTAL_BASE_AM) TOTAL_BASE_AM FROM FILE_SUBSET_CHUNKS WHERE INTERNAL_FILE_ID = ?";
    
    StatementParameter[] arrStatementParameters = new StatementParameter[]{new StatementParameter(sInternalFileID, Types.VARCHAR)};

    return getSingleValue(SELECT_STATEMENT, arrStatementParameters, null);
  }
  
  /**
   * 
   */
  public int updateCDT_DAILY_TRANSFER_Table(String sBaseAmount, String sCustCode, Date dateBusinessDate) throws SQLException
  {
    final String UPDATE_STATEMENT = "UPDATE CDT_DAILY_TRANSFER " +
                                    "SET TRANSFERED_AMOUNT = (TRANSFERED_AMOUNT - ?) " +
                                    "WHERE CUST_CODE  = ? AND BSNESSDATE  = ?";
    
    PreparedStatement ps = getConnection().prepareStatement(UPDATE_STATEMENT);

    int iCounter = 1;
    
    com.fundtech.util.GlobalUtils.setObject(ps, iCounter++, sBaseAmount);
    com.fundtech.util.GlobalUtils.setObject(ps, iCounter++, sCustCode);
    com.fundtech.util.GlobalUtils.setObject(ps, iCounter++, new java.sql.Date(dateBusinessDate.getTime()));
    
    return ps.executeUpdate();
  }  
  
  /**
   * 
   */
  public Feedback updateCDT_DAILY_TRANSFER_Table(String sTotalDebitAmount, String sFileSummaryCustCode, 
                                                 String sBusinessDate, Long lDailyCdtXferLimit, boolean bFileSummaryOverrideLimitCheck,
                                                 int[] arrAffectedRows)
  {
    final String UPDATE_STATEMENT = "UPDATE CDT_DAILY_TRANSFER " +
                                    "SET TRANSFERED_AMOUNT = (TRANSFERED_AMOUNT + ?) " +
                                    "WHERE CUST_CODE = ? " +
                                    "AND BSNESSDATE = TO_DATE(?, 'yyyy-MM-dd') " +
                                    "AND ( ((TRANSFERED_AMOUNT + ?) <= ?) OR (0 <> ?) )";
    
    StatementParameter[] arrStatementParameters = new StatementParameter[]{new StatementParameter(sTotalDebitAmount, Types.NUMERIC),
                                                                           new StatementParameter(sFileSummaryCustCode, Types.VARCHAR),
                                                                           new StatementParameter(sBusinessDate, Types.VARCHAR),
                                                                           new StatementParameter(sTotalDebitAmount, Types.NUMERIC),
                                                                           new StatementParameter(lDailyCdtXferLimit, Types.NUMERIC),
                                                                           new StatementParameter(bFileSummaryOverrideLimitCheck ? ServerConstants.ONE_VALUE : ServerConstants.ZERO_VALUE, Types.VARCHAR)};

    return update(UPDATE_STATEMENT, arrStatementParameters, arrAffectedRows, null, false, false, null);
  }
  
  /**
   * 
   */
  public Feedback rollbackCDT_DAILY_TRANSFER_Changes(String sTotalBaseAmount, String sFileSummaryCustCode, String sBusinessDate, int[] arrAffectedRows)
  {
    final String UPDATE_STATEMENT = "UPDATE CDT_DAILY_TRANSFER " +
                                    "SET TRANSFERED_AMOUNT = (TRANSFERED_AMOUNT - ?) " +
                                    "WHERE CUST_CODE = ? " +
                                    "AND BSNESSDATE = TO_DATE(?, 'yyyy-MM-dd')";
    
    StatementParameter[] arrStatementParameters = new StatementParameter[]{new StatementParameter(sTotalBaseAmount, Types.NUMERIC),
                                                                           new StatementParameter(sFileSummaryCustCode, Types.VARCHAR),
                                                                           new StatementParameter(sBusinessDate, Types.VARCHAR)};
    
    return update(UPDATE_STATEMENT, arrStatementParameters, arrAffectedRows, null, false, false, null);
  }  
}