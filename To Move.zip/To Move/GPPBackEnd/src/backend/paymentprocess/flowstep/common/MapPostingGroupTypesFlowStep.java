package backend.paymentprocess.flowstep.common;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.businessobject.BOProxies;
import backend.core.module.MessageConstantsInterface;
import backend.paymentprocess.flowstep.AbstractFlowStep;
import backend.paymentprocess.memopost.common.PostingAccType;
import backend.paymentprocess.memopost.common.PostingGroup;

import com.fundtech.cache.entities.RuleResult;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.util.GlobalConstants;

public class MapPostingGroupTypesFlowStep extends AbstractFlowStep {

	final static Logger logger = LoggerFactory.getLogger(MapPostingGroupTypesFlowStep.class);
	private final static String Original="Original";
	private final static String Reverse="Reverse";
	private final static String Original_posting="Original posting";
	private final static String Reverse_posting="Reverse posting";
	
	@Override
	public Feedback performMainAction(PDO pdo) throws Exception {
		Feedback feedback = new Feedback();
		
		List<RuleResult> listRuleResults;
		String postingType;
		String postingGroupName;
		Map<String, PostingGroup> groupPostings = new HashMap<String, PostingGroup>();
		
		try {
			listRuleResults = BOProxies.m_internalRuleExecutionLogging.executeRule(Admin.getContextAdmin(), 
					MessageConstantsInterface.RULE_TYPE_ID_POSTING_TYPE_SELECTION,Original_posting ,pdo.getMID(), 
					new String[] {pdo.getString(PDOConstantFieldsInterface.P_OFFICE), GlobalConstants.DEFAULT_SERVER_OFFICE_NAME}).getResults();
		
			for (RuleResult postingRuleType : listRuleResults){
				
				postingGroupName = postingRuleType.getSecAction();
				postingType = postingRuleType.getAction();
				
				PostingGroup postingGroupTypeEntry = groupPostings.get(postingGroupName);
				
				if (postingGroupTypeEntry == null) {
					
					PostingGroup groupEntry = new PostingGroup(postingGroupName);
					
					groupEntry.addPostingTypeEntryToPostingMap(PostingAccType.valueOf(postingType),Original);
					
					groupPostings.put(postingGroupName, groupEntry);
					logger.debug("Add new entry {},  with value: {}", postingGroupName ,postingType);
					
				}else{
					postingGroupTypeEntry.addPostingTypeEntryToPostingMap(PostingAccType.valueOf(postingType),Original);
					logger.debug("{} updated with value: {}", postingGroupTypeEntry.getPostingGroupName() ,postingType);
			
				}
	    	}
			
			listRuleResults.clear();
			
			listRuleResults = BOProxies.m_internalRuleExecutionLogging.executeRule(Admin.getContextAdmin(), 
					MessageConstantsInterface.RULE_TYPE_ID_POSTING_TYPE_SELECTION,Reverse_posting ,pdo.getMID(), 
					new String[] {pdo.getString(PDOConstantFieldsInterface.P_OFFICE), GlobalConstants.DEFAULT_SERVER_OFFICE_NAME}).getResults();
		
			for (RuleResult postingRuleType : listRuleResults){
				
				postingGroupName = postingRuleType.getSecAction();
				postingType = postingRuleType.getAction();
				
				PostingGroup postingGroupTypeEntry = groupPostings.get(postingGroupName);
				
				if (postingGroupTypeEntry == null) {
					
					PostingGroup groupEntry = new PostingGroup(postingGroupName);
					
					groupEntry.addPostingTypeEntryToPostingMap(PostingAccType.valueOf(postingType),Reverse);
					
					groupPostings.put(postingGroupName, groupEntry);
					logger.debug("Add new entry {},  with value: {}", postingGroupName ,postingType);
					
				}else{
					postingGroupTypeEntry.addPostingTypeEntryToPostingMap(PostingAccType.valueOf(postingType),Reverse);
					logger.debug("{} updated with value: {}", postingGroupTypeEntry.getPostingGroupName() ,postingType);
			
				}
	    	}
			
			
			pdo.set(PDOConstantFieldsInterface.D_POSTING_TYPES, groupPostings);
		} catch (Exception e) {
			logger.error("Error while invoking posting type selection rule", e);
		} 
		
		return feedback;
	}
	
}
