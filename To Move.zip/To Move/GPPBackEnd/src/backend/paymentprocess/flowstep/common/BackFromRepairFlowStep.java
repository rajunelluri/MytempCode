package backend.paymentprocess.flowstep.common;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;

import javax.transaction.HeuristicMixedException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.core.module.MessageConstantsInterface;
import backend.paymentprocess.SubBatchProcessInterface;
import backend.paymentprocess.debulkingprocess.businessobjects.BODebulkingProcess.AmountHolder;
import backend.paymentprocess.debulkingprocess.dao.DAODebulkingProcess;
import backend.paymentprocess.flowstep.AbstractFlowStep;
import backend.paymentprocess.highvalueprocess.businessobjects.BOHighValueProcess;
import backend.paymentprocess.nsf.dao.DAONsf;
import backend.paymentprocess.subbatchgeneration.dao.DAOSubBatchGeneration;
import backend.services.events.handlers.PaymentDistributerEventHandler;

import com.fundtech.cache.entities.BatchSubset;
import com.fundtech.cache.entities.FileSummary;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.cache.infrastructure.regions.CacheKeys.ProcessPdoPerUniqueGroupIdKey.ProcessPdoPerGroupIdEntry;
import com.fundtech.core.general.flows.FlowException;
import com.fundtech.core.general.tx.LastResourceInterface;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.util.ExceptionController;

public class BackFromRepairFlowStep extends AbstractFlowStep 
{
    final static Logger logger = LoggerFactory.getLogger(BackFromRepairFlowStep.class);
    private static DAODebulkingProcess m_dao = DAODebulkingProcess.getInstance();
    private static DAOSubBatchGeneration m_daoSubBatchGeneration =  DAOSubBatchGeneration.getInstance();;;
    private static DAONsf m_daoNsf = DAONsf.getInstance();

    @Override
    public Feedback performMainAction(PDO pdo) {
         Feedback feedback=new Feedback();
         boolean bAlwaysSendTheS=false;
         String previousMsgStatus=pdo.getString(PDOConstantFieldsInterface.P_PREVIOUS_MSG_STS);;
         String msgStatus=pdo.getString(PDOConstantFieldsInterface.P_MSG_STS);
         logger.info("BackFromRepairFlowStep - previousMsgStatus={},msgStatus={}", new Object[]{previousMsgStatus, msgStatus});
         if((null!=previousMsgStatus && previousMsgStatus.equalsIgnoreCase(MessageConstantsInterface.MESSAGE_STATUS_REPAIR)
        		 && !msgStatus.equalsIgnoreCase(MessageConstantsInterface.MESSAGE_STATUS_REPAIR)) || bAlwaysSendTheS)
         {
             PreparedStatement updateFileProcessDistributionPs=null;
             String fileProcessDistStatus = SubBatchProcessInterface.STATUS_PRE_PROCESSED;
             String internalFileId = pdo.getString(PDOConstantFieldsInterface.P_IN_INTERNAL_FILEID);
             String sUniqueGroupingID = pdo.getString(PDOConstantFieldsInterface.P_UNIQUE_GROUPING_ID) ; 
             String chunkId = pdo.getString(PDOConstantFieldsInterface.P_CHUNK_ID);
             String bulkID = pdo.getString(PDOConstantFieldsInterface.D_BULK_ID);
             FileSummary fileSummary=pdo.getNSetIncomingFileSummary();
             AmountHolder amountHolder = new AmountHolder();
             double amount = pdo.getDecimal(PDOConstantFieldsInterface.OX_STTLM_AMT) != null ? pdo.getDecimal(PDOConstantFieldsInterface.OX_STTLM_AMT).doubleValue() : 0;
             amountHolder.addRepairCount(-1);
             amountHolder.addStlmAmtRepair(-amount);
             logger.info("BackFromRepairFlowStep: internalFileId={},chunkId={},sUniqueGroupingID={},amountHolder={},fileSummary.getNumRepair={}",new Object[]{internalFileId,chunkId,sUniqueGroupingID,amountHolder,fileSummary.getNumRepair()});
             Connection conn=null;
             try
             {
                 conn = m_dao.getConnection();
                 updateFileProcessDistributionPs = m_dao.updateFileProcessDistributionStatusAndAmounts(conn, fileProcessDistStatus, internalFileId,chunkId,amountHolder);
                 updateFileProcessDistributionPs.executeUpdate();
             }
             catch (Exception e) 
             {
                ExceptionController.getInstance().handleException(e, this);
             }
             finally
             {
                 m_dao.releaseResources(null, updateFileProcessDistributionPs, conn);
             }
             feedback = m_daoSubBatchGeneration.updateFILE_SUMMARY_Table(internalFileId, 1 /*numOfBackFromRepair*/);
             if (!msgStatus.equalsIgnoreCase(MessageConstantsInterface.MESSAGE_STATUS_CANCELED))
             {
                 ProcessPdoPerGroupIdEntry processPdoPerGroup = CacheKeys.processPdoPerUniqueGroupIdKey.getSingle(internalFileId, chunkId, sUniqueGroupingID);
                 Admin.getContextAdmin().registerLastResource(new AddPDOToMassPayCacheLastResourceHandler(pdo,processPdoPerGroup));
             }
             if (null!=fileSummary.getNumRepair() && 1==fileSummary.getNumRepair().intValue())
             {
            	 BatchSubset batchSubset=pdo.getNSetBatchSubset();
                if (null!=batchSubset || bAlwaysSendTheS)
                {
                    String sSubBatchMID=batchSubset.getMid();
                    logger.info("BackFromRepairFlowStep: going to send S msg MID={} to EVENT_SUBMIT_BY_MIDS",new Object[]{sSubBatchMID});
                    PaymentDistributerEventHandler.addOneTimeEvent(MessageConstantsInterface.EVENT_SUBMIT_BY_MIDS, sSubBatchMID, null);
                }
                else
                {
                	          
                	try
                	{
                          PDO subbatchPDO=PaymentDataFactory.newPDO();
                          subbatchPDO.set(PDOConstantFieldsInterface.P_OFFICE, pdo.getString(PDOConstantFieldsInterface.P_OFFICE));
                          subbatchPDO.set(PDOConstantFieldsInterface.P_BATCH_MSG_TP, SubBatchProcessInterface.BATCH_MESSAGE_TYPE_SUB);
                          subbatchPDO.setIncomingFileSummary(pdo.getNSetIncomingFileSummary()) ;
                          subbatchPDO.set(PDOConstantFieldsInterface.P_MSG_STS, MessageConstantsInterface.MESSAGE_STATUS_COMPLETE);
                          subbatchPDO.set(PDOConstantFieldsInterface.D_CHUNK_ID_LIST, m_daoNsf.getFILE_SUBSET_CHUNKS_CHUNK_ID(internalFileId, sUniqueGroupingID, bulkID));
                          subbatchPDO.set(PDOConstantFieldsInterface.P_IN_INTERNAL_FILEID,internalFileId);
                          subbatchPDO.set(PDOConstantFieldsInterface.P_UNIQUE_GROUPING_ID,sUniqueGroupingID);
                          
                          BOHighValueProcess.performNotificationFlow(subbatchPDO);
                          m_daoNsf.updateFILE_SUBSET_CHUNKS_Table(SubBatchProcessInterface.STATUS_SUB_BATCH_COMPLETED, internalFileId, internalFileId, bulkID);
                    }
                    catch(Throwable t)
                    {
                          ExceptionController.getInstance().handleException(t, this);
                          feedback.setFailure();
                          feedback.setErrorCode(1);
                          feedback.setErrorText(t.getMessage());
                          throw new FlowException(t);
                    }
                	
                }
             }
	     }
	     return feedback;
	}

	public class AddPDOToMassPayCacheLastResourceHandler implements LastResourceInterface {
		PDO pdo;
		ProcessPdoPerGroupIdEntry processPdoPerGroup;
		public AddPDOToMassPayCacheLastResourceHandler(PDO pdo,ProcessPdoPerGroupIdEntry processPdoPerGroup)
		{
			this.pdo=pdo;
			this.processPdoPerGroup=processPdoPerGroup;
		}
		@Override
		public void afterCommit() throws HeuristicMixedException 
		{
		}
		@Override public void commitLastResource() throws HeuristicMixedException 
		{
            //add the pdo back to ProcessPdoPerGroupIdEntry, so it will be picked again in SubBatchCompletion/Cancellation.
			//We need to do this after pdo time stamp was updated but before the commit (or else the MQ message to subbatch completion might be processed before we update the cache)
            List<PDO> listPDO=((null==processPdoPerGroup)?(new ArrayList<PDO>()):processPdoPerGroup.getEntry());
            listPDO.add(pdo);
            processPdoPerGroup.setEntry(listPDO);
            CacheKeys.processPdoPerUniqueGroupIdKey.putSingle(processPdoPerGroup);	
            logger.info("after processPdoPerUniqueGroupIdKey.putSingle: processPdoPerGroup.listPDO.size={}",new Object[]{listPDO.size()});
		}
		@Override public void compensate() throws HeuristicMixedException {}				
		@Override public String getID() { return null; }
	}

}
