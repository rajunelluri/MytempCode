package backend.paymentprocess.flowstep.common;

import static backend.core.module.MessageConstantsInterface.RULE_TYPE_ID_GUI_WORKFLOW_STATUS_SELECTION;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_OFFICE;
import static com.fundtech.util.GlobalConstants.DEFAULT_SERVER_OFFICE_NAME;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.businessobject.BOProxies;
import backend.paymentprocess.flowstep.AbstractFlowStep;

import com.fundtech.cache.entities.RuleResult;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;

public class DetermineNextStatus extends AbstractFlowStep {
	final static Logger logger = LoggerFactory.getLogger(DetermineNextStatus.class);
	@Override
	public Feedback performMainAction(PDO pdo) throws Exception {
		Feedback feedback = new Feedback();
		
		List<RuleResult> listRuleResults;
		pdo.set(PDOConstantFieldsInterface.D_IS_CONT_FLOW_UNTIL_HANDOFF, true);
		listRuleResults = BOProxies.m_internalRuleExecutionLogging.executeRule(
						Admin.getContextAdmin(), 
						RULE_TYPE_ID_GUI_WORKFLOW_STATUS_SELECTION,"0" ,pdo.getMID(), 
						new String[] {pdo.getString(P_OFFICE), DEFAULT_SERVER_OFFICE_NAME}
						).getResults();
		
		if (listRuleResults.size() >0)
		{
		String nextStatus = listRuleResults.get(0).getAction();
		logger.info("Set next status to {}",nextStatus);
		pdo.set(PDOConstantFieldsInterface.P_MSG_STS, nextStatus);
		}
		else
		{
			
			//feedback.setFailure();
			logger.info("GUI workflow status rule could not determine next status. Message ststus not changed.");
			
			//feedback.setErrorText("Failed Determine next status");
		}
		return feedback;
	}
}
	
