package backend.paymentprocess.flowstep.common;

import org.apache.commons.lang.StringUtils;

import backend.paymentprocess.flowstep.AbstractFlowStep;
import backend.paymentprocess.g3utils.InstructionIdGenerator;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.spring.SpringApplicationContext;

public class InstructionIdReGenerationFlowStep extends AbstractFlowStep {

    @Override
	public Feedback performMainAction(PDO pdo) throws Exception 
	{
	     InstructionIdGenerator instructionIdGenerator = (InstructionIdGenerator) SpringApplicationContext.getBean("g3InstructionIdGenerator");
	     String instrcutionId = instructionIdGenerator.generateInstructionId(pdo.getDate(PDOConstantFieldsInterface.X_STTLM_DT_1B), true, false, "BP".equals(pdo.getString(PDOConstantFieldsInterface.P_BUSINESS_FLOW_TP)),pdo.getString(PDOConstantFieldsInterface.P_OFFICE));
	     String oXInsructionId=pdo.getString(PDOConstantFieldsInterface.OX_INSTR_ID);
	     String xInsructionId=pdo.getString(PDOConstantFieldsInterface.X_INSTR_ID);
	     pdo.severConjoinedLinks();
	     pdo.set(PDOConstantFieldsInterface.X_INSTR_ID, instrcutionId);
	     
	     if(StringUtils.isEmpty(oXInsructionId) && !StringUtils.isEmpty(xInsructionId) ){
	           pdo.set(PDOConstantFieldsInterface.OX_INSTR_ID, xInsructionId);
	     }else if(StringUtils.isEmpty(oXInsructionId)){
	           pdo.set(PDOConstantFieldsInterface.OX_INSTR_ID, instrcutionId);
	     }
        return new Feedback();
   }


}
