package backend.paymentprocess.flowstep;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.datacomponent.response.Feedback;

/**
 * 
 * @author Ronen Malka
 * @version 1.0
 * 
 * </br>FlowStep contains the implementation of a single step in a message flow.
 *
 */
public interface FlowStep {

		
	public Feedback execute(PDO pdo) throws Throwable;
	
	/**
	 * indicator to stop the flow if the PDO status had changed during step execution
	 */
	boolean stopOnStatusChange();
	
	
}
