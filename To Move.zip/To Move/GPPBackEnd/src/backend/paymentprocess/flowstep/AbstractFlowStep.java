package backend.paymentprocess.flowstep;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.paymentprocess.memopost.common.PostingAccType;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.datacomponent.response.Feedback;



/**
 * 
 * @author Ronen Malka
 * @version 1.0
 *
 */
public abstract class AbstractFlowStep implements FlowStep {
	
	protected static PostingAccType[] rejectionContext = new PostingAccType[] { PostingAccType.MAIN_CR_R, PostingAccType.MAIN_DR_R };
	protected static PostingAccType[] reversalContext = new PostingAccType[] { PostingAccType.MAIN_CR_R, PostingAccType.MAIN_DR_R };
	protected static PostingAccType[] mainContext = new PostingAccType[] { PostingAccType.MAIN_CR, PostingAccType.MAIN_DR };
	protected static PostingAccType[] bulkSubBatchContext = new PostingAccType[] { PostingAccType.BSA_CR, PostingAccType.MAIN_DR };
	protected static PostingAccType[] bulkIndividualContext = new PostingAccType[] { PostingAccType.MAIN_CR, PostingAccType.BSA_DR };
	protected static PostingAccType[] bulkIndividualReversalContext = new PostingAccType[] { PostingAccType.MAIN_CR_R, PostingAccType.MAIN_DR_R };
	protected static PostingAccType[] bulkIndividualBookReversalContext = new PostingAccType[] { PostingAccType.BSA_CR_R, PostingAccType.MAIN_DR_R };
	
	@Override
	public boolean stopOnStatusChange() {
		return true;
	}

	protected abstract Feedback performMainAction(PDO pdo) throws Throwable ;

	protected void performPreAction(PDO pdo) {};
			
	protected Feedback performPostAction(PDO pdo, Feedback feedback) {
		return feedback;
	}
	

	@Override
	public Feedback execute(PDO pdo) throws Throwable {

		
		Feedback feedback;
		
		performPreAction(pdo);		
		feedback = performMainAction(pdo);
		feedback = performPostAction(pdo,feedback);
		return feedback;				
		
	}

	protected final static Logger logger = LoggerFactory.getLogger(FlowStep.class);
}
