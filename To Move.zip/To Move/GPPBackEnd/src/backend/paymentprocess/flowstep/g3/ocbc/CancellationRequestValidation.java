package backend.paymentprocess.flowstep.g3.ocbc;

import static backend.core.module.MessageConstantsInterface.MONITOR_FLAG_FAILURE;
import static backend.core.module.MessageConstantsInterface.MONITOR_FLAG_MATCH;
import static backend.core.module.MessageConstantsInterface.RELATION_TYPE_INCOMING_CANCELLATION_REQUEST_REFUSED;
import static backend.core.module.MessageConstantsInterface.RELATION_TYPE_ORIGINAL_PAYMENT;
import static backend.core.module.MessageConstantsInterface.RULE_TYPE_ID_CANCELLATION_REQUEST_VALIDATION;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.MF_CANCEL_MATCH_STS;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.MF_CANCEL_REQUEST_VALID_STS;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.MF_RECALL_STS;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.paymentprocess.baseprocess.businessobjects.BOBaseProcess;
import backend.paymentprocess.flowstep.AbstractFlowStep;
import backend.staticdata.dataaccess.dao.DAOStaticData;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.scl.commonTypes.MFamilyLineType;

public class CancellationRequestValidation extends AbstractFlowStep {
	final static Logger logger = LoggerFactory.getLogger(CancellationRequestValidation.class);
	private final String TRACE_EXECUTES_CANCELLATION_REQUEST_VALIDATION = "Executes cancellation request validation...";
	private final String TRACE_CANCELLATION_REQUEST_VALIDATION_FAILED = "Cancellation request validation failed !";
	private final String TRACE_CANCELLATION_REQUEST_INVALID_STATUS = "Cancellation request invalid status !";
	
	// Handles the cancellation request
	@Override
	protected Feedback performMainAction(PDO pdo) throws Throwable {
		Feedback feedback = new Feedback();
		logger.info(TRACE_EXECUTES_CANCELLATION_REQUEST_VALIDATION);

		try {
			// Executes the cancellation request validation rule type, (rule type ID 157).
			feedback = BOBaseProcess.executeMapPaymentInfoUsingRules(pdo.getMID(), RULE_TYPE_ID_CANCELLATION_REQUEST_VALIDATION, null);
		} catch (Exception e) {
			logger.error(TRACE_CANCELLATION_REQUEST_VALIDATION_FAILED, e);
		}

		//Sets back the 'Cancellation Request' PDO to be the primary PDO for rest of the process
		pdo.promoteToPrimary();
		
		return feedback;
	}
	
	@Override
	public Feedback performPostAction(PDO pdo,Feedback feedback) {
		if (MONITOR_FLAG_MATCH.equals(pdo.getString(MF_CANCEL_MATCH_STS))) {
			PDO pdoOriginalPayment = pdo.getLinkedMsg(RELATION_TYPE_ORIGINAL_PAYMENT);
			if (MONITOR_FLAG_FAILURE.equals(pdo.getString(MF_CANCEL_REQUEST_VALID_STS)))
			{
				// 1. Set MF_RECALL_STS to failure (F)
				// 2. Update relation type between the Recall and the Original Payment to Rejected Recall ^ Original Payment in order to be able to receive Recall (CAMT_056) again.
				pdoOriginalPayment.set(MF_RECALL_STS,MONITOR_FLAG_FAILURE);
				MFamilyLineType mFamily = (pdo.getListMFAMILY().get(0));
				mFamily.setFMFAMILYSELFRELATEDTYPE(RELATION_TYPE_INCOMING_CANCELLATION_REQUEST_REFUSED);
				// get current time and set at mFamily in order to prevent duplication
				String sTimeStamp = (new DAOStaticData()).getSystemDateAndTimeFromDatabase();
				mFamily.setFMFAMILYTIMESTAMP(sTimeStamp);
				feedback.addErrorText(TRACE_CANCELLATION_REQUEST_INVALID_STATUS);
				feedback.setFailure();
			}
		}
		return feedback;
	}
}
