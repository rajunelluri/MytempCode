package backend.paymentprocess.flowstep.g3.ocbc;

import static backend.core.module.MessageConstantsInterface.RULE_TYPE_ID_DEPARTMENT;
import backend.paymentprocess.baseprocess.businessobjects.BOBaseProcess;
import backend.paymentprocess.flowstep.AbstractFlowStep;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.datacomponent.response.Feedback;

public class DepartmentSelectionFlowStep extends AbstractFlowStep {
	@Override
	public Feedback performMainAction(PDO pdo) throws Exception {
		Feedback feedback = BOBaseProcess.executeMapPaymentInfoUsingRules(pdo.getMID(), RULE_TYPE_ID_DEPARTMENT, null);
		return feedback;
	}
}
