package backend.paymentprocess.flowstep.g3.ocbc.feecalculation;

import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.D_CDT_FEE_ACCT_AMT_NOW;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.D_FEE_CALCULATION_TYPE;
import backend.paymentprocess.feescalculation.common.FeesCalculationType;
import backend.paymentprocess.flow.g3.G3Util;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.datacomponent.response.Feedback;

public class CreditFeeCalculationFlowStep extends FeeCalculationBaseFlowStep {
	
	public CreditFeeCalculationFlowStep() {
		super(false);
	}

	@Override
	public void performPreAction(PDO pdo) {
		pdo.set(D_FEE_CALCULATION_TYPE, FeesCalculationType.CREDIT.name());
		pdo.set(D_CDT_FEE_ACCT_AMT_NOW, (String) null);
		G3Util.populateCreditAccount(pdo, new Feedback());
	}
}
