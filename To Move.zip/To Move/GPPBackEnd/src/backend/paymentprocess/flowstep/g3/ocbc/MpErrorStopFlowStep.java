package backend.paymentprocess.flowstep.g3.ocbc;

import static backend.core.module.MessageConstantsInterface.MESSAGE_STATUS_SERVICE_COMPLETE;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_MSG_STS;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.X_ORGNL_INSTR_ID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.core.module.MessageConstantsInterface;
import backend.dataaccess.dao.DAOBasic;
import backend.paymentprocess.erroraudit.ErrorAuditUtils;
import backend.paymentprocess.flowstep.AbstractFlowStep;
import backend.paymentprocess.highvalueprocess.businessobjects.BOHighValueProcess;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.core.paymentprocess.errorhandling.ProcessError;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.errors.ProcessErrorConstants;
import com.fundtech.util.GlobalUtils;

public class MpErrorStopFlowStep extends AbstractFlowStep {
	final static Logger logger = LoggerFactory.getLogger(MpErrorStopFlowStep.class);
	private final String TRACE_GRACEFUL_TERMINATION_STATUS = "Final graceful termination status for MID {}: {}. ";
	private final String TRACE_INITIATED_REQUEST_HAS_NO_MATCHED_PAYMENT = "The Initiated request has no matched payment in MP_ERROR status !";
	private String sCancellationMatchStatus;
	private String origMsgTerminationStatus;
	
	
	@Override
	public Feedback performMainAction(PDO pdo) throws Throwable {
		PDO pdoOriginalPayment = null;
		String sMsgSts = null;
		Feedback feedback = new Feedback();
		DAOBasic dao = new DAOBasic();
		String initiatingMsgOldStatus = pdo.getString(P_MSG_STS);		
		
		String sOriginalInsrId = pdo.getString(X_ORGNL_INSTR_ID);
		logger.info("Oigi instruction id {}", sOriginalInsrId);
		if(!GlobalUtils.isNullOrEmpty(sOriginalInsrId))
		{
			String sMID = dao.getMIDAccordingToInstrId(sOriginalInsrId);
			logger.info("Oiginal payment Mid {}", sMID);
			if(null != sMID)
			{
				pdoOriginalPayment = PaymentDataFactory.load(sMID) ;
				if (null != pdoOriginalPayment) 
				 {
						sMsgSts = pdoOriginalPayment.getString(P_MSG_STS);
						//if Original payment message status is in MP_ERROR, set MF_CANCELATION_RECEIVED to Y.
						//when open the message CTI or DDI in GUI, user can cancel the payment.
						if( MessageConstantsInterface.MESSAGE_STATUS_MP_ERROR.equals(sMsgSts))
						{
							logger.info("Camt.056 recived and orig message in MP_ERROR,  setting MF_CANCELATION_RECEIVED  to Y to enable Cancel button.");
							pdoOriginalPayment.set(PDOConstantFieldsInterface.MF_CANCELATION_RECEIVED, MessageConstantsInterface.MONITOR_FLAG_YES);
							PaymentDataFactory.batchSave(true, pdoOriginalPayment);
							String sOrigMsgTerminationStatus = pdo.getString(P_MSG_STS);
							//Orig msg status was changed, then we need to set the Cancellation\Reversal msg status,
							//Cancellation\Reversal request (Camt_056\Pacs_007) has found a matched payment - then it goes to SERVICE_COMPLETE
							pdo.set(P_MSG_STS,MESSAGE_STATUS_SERVICE_COMPLETE);
							pdo.getField(P_MSG_STS).setOriginalValue(MESSAGE_STATUS_SERVICE_COMPLETE);
							logger.info(TRACE_GRACEFUL_TERMINATION_STATUS, pdo.getMID(),MESSAGE_STATUS_SERVICE_COMPLETE);
							ErrorAuditUtils.setErrors(new ProcessError(ProcessErrorConstants.MessageStatusChanged, new Object[] { initiatingMsgOldStatus, MESSAGE_STATUS_SERVICE_COMPLETE }),pdo);
							
							try {
								feedback = BOHighValueProcess.performTerminationSubFlow(pdoOriginalPayment, sOrigMsgTerminationStatus);
							} catch (Throwable e) {
								feedback.setException(e);
							}
						}
				 }
			}
			
		}else{//Cancellation/Reversal request (Camt_056/Pacs_007) has no matched payment 
			logger.info(TRACE_INITIATED_REQUEST_HAS_NO_MATCHED_PAYMENT);
			feedback.setErrorText(TRACE_INITIATED_REQUEST_HAS_NO_MATCHED_PAYMENT);
			feedback.setFailure();
		}
		
		return feedback;
	}
}
