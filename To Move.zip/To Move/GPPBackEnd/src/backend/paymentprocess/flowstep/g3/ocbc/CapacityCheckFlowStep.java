package backend.paymentprocess.flowstep.g3.ocbc;

import static backend.businessobject.BOProxies.m_capsManagementLogging;
import backend.paymentprocess.flowstep.AbstractFlowStep;
import backend.paymentprocess.glm.capsmanagement.businessobjects.CapsManagementOptions;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;

public class CapacityCheckFlowStep extends AbstractFlowStep {

	
	@Override
	public Feedback performMainAction(PDO pdo) {
		pdo.getOptions().set(CapsManagementOptions.AvoidAccountLocking.name(), true);
		Feedback feedback = m_capsManagementLogging.applyPaymentCaps(Admin.getContextAdmin(), pdo.getMID(), true);
		return feedback;
	}
	
	
}
