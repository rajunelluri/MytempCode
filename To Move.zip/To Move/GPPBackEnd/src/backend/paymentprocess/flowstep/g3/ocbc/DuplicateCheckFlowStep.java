package backend.paymentprocess.flowstep.g3.ocbc;

import static backend.businessobject.BOProxies.m_matchingCheckLogging;
import backend.paymentprocess.flowstep.AbstractFlowStep;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.datacomponent.response.GlobalAbstractResponseDataComponent;

public class DuplicateCheckFlowStep extends AbstractFlowStep {
	@Override
	public Feedback performMainAction(PDO pdo) {
		GlobalAbstractResponseDataComponent response = m_matchingCheckLogging.performDuplicateCheck(Admin.getContextAdmin(), pdo.getMID());
		Feedback feedback = response.getFeedback();
		return feedback;
	}
}
