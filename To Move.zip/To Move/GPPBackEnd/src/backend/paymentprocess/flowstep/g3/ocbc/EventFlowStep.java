package backend.paymentprocess.flowstep.g3.ocbc;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.businessobject.tx.SplitCounterDecrement;
import backend.core.module.MessageConstantsInterface;
import backend.paymentprocess.flowstep.AbstractFlowStep;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.scl.commonTypes.MFamilyLineType;

public class EventFlowStep extends AbstractFlowStep {
	final static Logger logger = LoggerFactory.getLogger(SetCompleteFlowStep.class);
	/**
	 * do not skip the event adding if the payment is a split child for G3 
	 */
	@Override
	public void performPreAction(PDO pdo) {
		
		SkipEvent = true;
		isRfPayment=false;
		
		//for split children payemnts
		if (pdo.get(PDOConstantFieldsInterface.MF_SPLIT_STATUS) != null && pdo.get(PDOConstantFieldsInterface.MF_SPLIT_STATUS).equals(MessageConstantsInterface.MONITOR_FLAG_CHILD)){
			SkipEvent = false;	
			sPaymentType = MessageConstantsInterface.MONITOR_FLAG_CHILD;
		}
		//for RF payments to completion
		if (pdo.get(PDOConstantFieldsInterface.MF_SPLIT_STATUS) != null && pdo.get(PDOConstantFieldsInterface.MF_SPLIT_STATUS).equals(MessageConstantsInterface.MONITOR_FLAG_SPLIT_RF)){
			SkipEvent = false;
			sPaymentType = MessageConstantsInterface.MONITOR_FLAG_SPLIT_RF;
			isRfPayment = true;
		}
		
	}
	@Override
	public Feedback performMainAction(PDO pdo) throws Exception {
		if(!SkipEvent)
		{
			
			//decrement from cache the number of the payments completed.
			List <MFamilyLineType> MFtypeList = new ArrayList<MFamilyLineType>();
			pdo.setListMFAMILY(null);
			MFtypeList = pdo.getNSetMfamilyList();
			String parentMID ="";
			String sRealtion,sOneofTheChildMids = "" ;
			if (sPaymentType.equals(MessageConstantsInterface.MONITOR_FLAG_CHILD)){
				sRealtion = MessageConstantsInterface.RELATION_TYPE_CHILD_PAYMENT;
			}
			else{
				sRealtion = MessageConstantsInterface.RELATION_TYPE_RETURN_FUNDS;
			}
			for (MFamilyLineType MFtypeLocal : MFtypeList ){
				if(MFtypeLocal.getFMFAMILYSELFRELATEDTYPE().equals(sRealtion)){
					parentMID = MFtypeLocal.getFMFAMILYRELATEDMID();
					break;
				}
			}
			//need to send to the event one of the children MIDs of the parent 
			if(isRfPayment){
				PDO parentPDO = PaymentDataFactory.load(parentMID);
			//	pdo.setListMFAMILY(null);
				MFtypeList = parentPDO.getNSetMfamilyList();
				for (MFamilyLineType MFtypeLocal : MFtypeList ){
					if(MFtypeLocal.getFMFAMILYRELATEDTYPE().equals(MessageConstantsInterface.RELATION_TYPE_CHILD_PAYMENT)){
						sOneofTheChildMids = MFtypeLocal.getFMFAMILYRELATEDMID();
						break;
					}
				}
			}
			logger.debug(" the payment type is : "+ sPaymentType + " the relation is :"+ sRealtion +" the parent mid is  :"+parentMID);
			//getting a hunch if how many  payments is the parent  waiting .
			
		/*	List<SplitChildrenCounterEntry> returnListCacheEntriesLocal = new ArrayList<CacheKeys.SplitChildrenCounterKey.SplitChildrenCounterEntry>();
			returnListCacheEntriesLocal =  CacheKeys.SplitChildrenCounterKey.get(returnListCacheEntriesLocal, parentMID) ;*/
			/*if (returnListCacheEntriesLocal.get(0) != null){
				 int LeftChildrenNotInFinalStatus = returnListCacheEntriesLocal.get(0).getSplitCounter();
				if (LeftChildrenNotInFinalStatus > 0){
					LeftChildrenNotInFinalStatus--;
				
					logger.debug(" if no concurrent payments are decrementing now - decrementing the counter cache for split payments to :" +LeftChildrenNotInFinalStatus );
					
					logger.info("set for acked/nacked MID={} an EVENT_WAKE_PARENT_SPLIT to check if all children of split payment are in final statuses",new Object[]{ pdo.getMID()});
					if (LeftChildrenNotInFinalStatus == 0){
						PaymentDistributerEventHandler.addOneTimeEvent(MessageConstantsInterface.EVENT_WAKE_PARENT_SPLIT, pdo.getMID(), null);
					}
					else{
						logger.debug("don't yet get back to parent as not all the cidren were processed");
					}
				}
				else{
					logger.debug("something is wrong here the the number of split children counter is less the 0!! {}",LeftChildrenNotInFinalStatus);
				}
			}*/
			
			 
		
			
			final Admin admin =  Admin.getContextAdmin() ;
			SplitCounterDecrement splitCounterDecrement = new SplitCounterDecrement(parentMID,isRfPayment ? sOneofTheChildMids : pdo.getMID(),isRfPayment); //on last parameter force the waking parent event .but send it with one of the children mid
			admin.registerLastResource(splitCounterDecrement);
			
		}
         
         
		return new Feedback();
	}
	//local varibales
	private boolean SkipEvent = true ;
	private String sPaymentType ;
	private boolean isRfPayment;
}

