package backend.paymentprocess.flowstep.g3.ocbc;

import backend.core.module.MessageConstantsInterface;
import backend.paymentprocess.flowstep.AbstractFlowStep;
import backend.paymentprocess.highvalueprocess.businessobjects.BOHighValueProcess;
import backend.services.events.handlers.PaymentDistributerEventHandler;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.datacomponent.response.Feedback;

public class CheckIfReleaseFromTimeHoldFlowStep extends AbstractFlowStep {

	@Override
	public Feedback performMainAction(PDO pdo) throws Throwable {
		
		//check if we need to execute the event that check if all the Individuals was release from the time hold status than update the filesummary status
		if (pdo.getString(PDOConstantFieldsInterface.P_MSG_STS).equals(MessageConstantsInterface.MESSAGE_STATUS_TIME_HOLD)){
			StringBuilder parameters = new StringBuilder(pdo.getString(PDOConstantFieldsInterface.P_IN_INTERNAL_FILEID));
		  	  parameters.append("@@@").append(pdo.getMID());
			PaymentDistributerEventHandler.addOneTimeEvent(MessageConstantsInterface.EVENT_UPDATE_FILE_SUMMARY, parameters.toString(),null,new java.sql.Timestamp( System.currentTimeMillis() + ( 60 * 1000 )));
		}
		return new Feedback();
	}	
}
