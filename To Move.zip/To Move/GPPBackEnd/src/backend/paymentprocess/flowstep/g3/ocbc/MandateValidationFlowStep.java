package backend.paymentprocess.flowstep.g3.ocbc;

import static backend.businessobject.BOProxies.m_internalRuleExecutionLogging;
import static backend.core.module.MessageConstantsInterface.MESSAGE_STATUS_REJECTED;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.F_CREDITOR_ID;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.F_UMR;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_MSG_STS;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.X_TX_ID;
import static com.fundtech.errors.ProcessErrorConstants.MANDATE_CHECK_FAILED;
import backend.businessobject.BOBasic;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.core.module.MessageConstantsInterface;
import backend.paymentprocess.erroraudit.ErrorAuditUtils;
import backend.paymentprocess.flowstep.AbstractFlowStep;
import backend.staticdata.dataaccess.dao.MandateDAO;
import backend.staticdata.dataaccess.dto.DTOModifiedField;

import com.fundtech.cache.entities.Mandate;
import com.fundtech.cache.entities.PreventStp;
import com.fundtech.cache.entities.PruleTypes;
import com.fundtech.cache.entities.Prules;
import com.fundtech.cache.entities.RuleResults;
import com.fundtech.cache.entities.RuleResults.CompletionCode;
import com.fundtech.cache.infrastructure.CacheServiceInterface;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.errorhandling.ProcessError;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.datacomponent.response.layout.LayoutConstants;
import com.fundtech.errors.ProcessErrorConstants;
import com.fundtech.spring.SpringApplicationContext;
import com.fundtech.util.GlobalConstants;

/**
 * @author Victor Katsovsky
 *
 */
public class MandateValidationFlowStep extends AbstractFlowStep {
	final static Logger logger = LoggerFactory.getLogger(MandateValidationFlowStep.class);
	
	@Override
	public Feedback performMainAction(PDO pdo) throws Exception {
		Feedback feedback = new Feedback();
		
		Mandate mandate = pdo.getNSetMANDATE();
		
		// if mandate was not found - reject the message
		Boolean goToRules = isValidMandate(mandate, pdo);
		
		// run mandate validation rules
		if(goToRules.equals(Boolean.TRUE)){
			// set field for mandate cancellation rule check
			pdo.set("F_MANDATE_CANCEL_MANDATE_IND", mandate.getCancelMandateInd());
			runMandateValidationRules(mandate, pdo);
		}else{
			feedback = setMandateValidationFailure(pdo);
		}
		return feedback;
	}
	
	/**
	 * validate if mandate exists, not cancelled and not one time rejected
	 * @param mandate
	 * @param pdo
	 * @return TRUE if mandate exists, not cancelled and not one time rejected
	 */
	private Boolean isValidMandate(Mandate mandate, PDO pdo){
		if(isNotExistingMandate(mandate, pdo) || isOneTimeRejectedMandate(mandate, pdo)){
			return Boolean.FALSE;
		}
		
		return Boolean.TRUE;
	}
	
	private Boolean isNotExistingMandate(Mandate mandate, PDO pdo){
		if(null == mandate){
			// set error code
			String[] arrMandateErrorParams = new String[]{pdo.getString(PDOConstantFieldsInterface.X_MNDT_ID)};
			ProcessError processMandateError = ProcessError.getError(ProcessErrorConstants.MANDATE_CHECK_NOT_FOUND, arrMandateErrorParams, null);
			ErrorAuditUtils.setErrors(processMandateError,pdo.getIsHistory());
			
			return Boolean.TRUE;
		}

		return Boolean.FALSE;
	}
	
	/**
	 * Set message status to rejected if "Reject next collection" check box is checked,
	 * then clear the "Reject next collection" check box
	 * @param mandate
	 * @param pdo
	 * @return TRUE if "Reject next collection" check box is checked
	 */
	private Boolean isOneTimeRejectedMandate(Mandate mandate, PDO pdo){
		// if one time reject next collection flag is set - reject the message and clear the flag
		if(mandate.getRejectNextCollection()){
			// set error code
			String[] arrMandateErrorParams = new String[]{pdo.getString(PDOConstantFieldsInterface.X_TX_ID), pdo.getString(PDOConstantFieldsInterface.F_UMR), pdo.getString(PDOConstantFieldsInterface.F_CREDITOR_ID)};
			ProcessError processMandateError = ProcessError.getError(ProcessErrorConstants.MANDATE_CHECK_NEXT_COLL_REJECTED, arrMandateErrorParams, null);
			ErrorAuditUtils.setErrors(processMandateError,pdo.getIsHistory());
			
			// clear one time reject next collection flag
			mandate.setRejectNextCollection(Boolean.FALSE);
			// refresh mandate cache
			// update profile in DB
			MandateDAO mandateDAO = (MandateDAO) SpringApplicationContext.getBean("MandateDAO");
			if(mandateDAO.updateRejectNextCollection(mandate.getUidMandate(), false)){
				DTOModifiedField ModifiedFields = new DTOModifiedField("REJECT_NEXT_COLLECTION", "1", "0");
				BOBasic.profileAudit(LayoutConstants.PROFILE_ID_MANDATE, pdo.getNSetOffice().getOffice(), new DTOModifiedField[]{ModifiedFields}, pdo.getMID(), mandate.getDepartment(), pdo.getString(PDOConstantFieldsInterface.P_MSG_TYPE), mandate.getUidMandate());
				// reload cache after change in DB
				try{
					CacheServiceInterface.eINSTANCE.applyChanges(new String[] { CacheKeys.mandateKey.name()}, null);
				}catch(Exception ex){
					logger.info("Failed to refresh mandate cache");
				}
			}
			
			return Boolean.TRUE;
		}
		
		return Boolean.FALSE;

	}
	
	/**
	 * run mandate validation rules, if rule is caught - then set
	 * message status to the one defined in "Override STP" profile (rule action)
	 * @param mandate
	 * @param pdo
	 * @throws Exception
	 */
	private void runMandateValidationRules(Mandate mandate, PDO pdo) throws Exception {
		RuleResults ruleResults=m_internalRuleExecutionLogging.executeRule(Admin.getContextAdmin(), MessageConstantsInterface.RULE_TYPE_ID_MANDATE_VALIDATION,
				null, pdo.getMID(), new String[]{GlobalConstants.DEFAULT_SERVER_OFFICE_NAME});

		if (!ruleResults.getResults().isEmpty() && !ruleResults.getCompletionCode().equals(CompletionCode.STOP))
		{
			//load override STP from cache
			PreventStp preventStp = CacheKeys.preventStpKey.getSingle(ruleResults.getResults().get(0).getAction());
			if(preventStp != null)
			{
				// update PDO status
				String messageStatus = preventStp.getMsgStatus();
				pdo.set(P_MSG_STS, messageStatus);

				// audit message status change by rule
				PruleTypes pruleType = CacheKeys.PRulesTypeKey.getSingle(MessageConstantsInterface.RULE_TYPE_ID_VALIDATION);
				Prules prule = CacheKeys.PRulesUIDKey.getSingle(ruleResults.getResults().get(0).getRuleUID());
				String[] arrRulesErrorParams = new String[]{messageStatus, pruleType.getRuleTypeName(), prule.getRuleName(),ruleResults.getResults().get(0).getObjectUid()};
				ProcessError processRulesError = ProcessError.getError(ProcessErrorConstants.MessageStatusWasChanged, arrRulesErrorParams, null);
				ErrorAuditUtils.setErrors(processRulesError,pdo.getIsHistory());

				// audit mandate validation failure
				Long errorCode = preventStp.getErrorCode();
				Object[] arrNonPaymentFields = null;
				if (errorCode!=null) {
					arrNonPaymentFields = new String[] { pdo.getString(X_TX_ID),pdo.getString(F_UMR),pdo.getString(F_CREDITOR_ID),mandate.getCancellationReasonCd()};
					processRulesError = ProcessError.getError(errorCode.intValue(),arrNonPaymentFields, null);
				}else{
					arrNonPaymentFields = new String[] { preventStp.getDescription() };
					processRulesError = ProcessError.getError(MANDATE_CHECK_FAILED,arrNonPaymentFields, null);
				}

				ErrorAuditUtils.setErrors(processRulesError,pdo.getIsHistory());

				logger.info("Mandate validation failed - " + processRulesError.getDescription());
			}else{
				logger.info(String.format("Override STP validation profile %s not found in cache", ruleResults.getResults().get(0).getAction()));
			}
		}
	}
	
	private Feedback setMandateValidationFailure(PDO pdo){
		pdo.set(P_MSG_STS, MESSAGE_STATUS_REJECTED);
		logger.info("Mandate validation failed, message status is set to {}", MESSAGE_STATUS_REJECTED);
		
		return new Feedback("Mandate validation failed");
	}
}
