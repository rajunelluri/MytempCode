package backend.paymentprocess.flowstep.g3.ocbc;

import backend.core.module.MessageConstantsInterface;
import backend.paymentprocess.flowstep.AbstractFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.feecalculation.DebitFeeCalculationFlowStep;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.util.GlobalUtils;

public class BulkSubBatchPostingAndFeesLogicFlowStep extends AbstractFlowStep {
	private BulkSubBatchPrincipalPostingFlowStep bulkSubBatchPrincipalPosting = new BulkSubBatchPrincipalPostingFlowStep(); // CT - MAIN_DR & BSA_CR
	private DebitFeeCalculationFlowStep debitFeeCalculation = new DebitFeeCalculationFlowStep();
	private FeePostingFlowStep feePostingFlow = new FeePostingFlowStep();


	@Override
	public Feedback performMainAction(PDO pdo) throws Throwable {
		Feedback principlePostingAndFeelogicFeedback =  bulkSubBatchPrincipalPosting.execute(pdo);
		if(GlobalUtils.isErrorCorrectionFlow(pdo))
		{
			pdo.set(PDOConstantFieldsInterface.P_MSG_STS,MessageConstantsInterface.MESSAGE_STATUS_REJECTED);
			return principlePostingAndFeelogicFeedback;
		}
		debitFeeCalculation.execute(pdo);
		feePostingFlow.execute(pdo);
		
		return principlePostingAndFeelogicFeedback;
	}
}
