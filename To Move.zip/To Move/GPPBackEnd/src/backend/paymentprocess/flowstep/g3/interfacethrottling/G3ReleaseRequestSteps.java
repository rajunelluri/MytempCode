
package backend.paymentprocess.flowstep.g3.interfacethrottling;

import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.X_EXTN_INTRF_TIMEOUT_INTR_NAME;

import org.apache.cxf.common.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.paymentprocess.flowstep.g3.responsetimeout.G3OnTimeoutSteps;
import backend.paymentprocess.flowstep.interfacethrottling.ReleaseRequestSteps;
import backend.paymentprocess.interfaces.common.InterfaceUtils;

import com.fundtech.cache.entities.InterfaceTypes;
import com.fundtech.cache.entities.PendingOutgoingRequest;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.datacomponent.response.Feedback;

public class G3ReleaseRequestSteps {
	final static Logger logger = LoggerFactory.getLogger(G3ReleaseRequestSteps.class);

	public static class G3BulkSendRequestStep extends ReleaseRequestSteps.SendRequestStep {
		@Override
		public Feedback performMainAction(PDO pdo) throws Throwable {		
			String releaseDestination = getReleaseDestination(pdo);
			
			PendingOutgoingRequest releasedRequest = getPendingRequest(pdo);
			releasedRequest.setOverriddenInterface(releaseDestination);
			
			return super.performMainAction(pdo);
		}

		private String getReleaseDestination(PDO pdo) {
			String destination = getTimeoutInterface(pdo);
			
			if (!StringUtils.isEmpty(destination)) {
				logger.debug("as release destination use the original interface as before the timeout");
				return destination;
			}
			
			try {
				logger.debug("about to select the destination interface for release");
				PendingOutgoingRequest releasedRequest = getPendingRequest(pdo);
				InterfaceTypes originalDestination = CacheKeys.interfaceTypesNameKey.getSingle(releasedRequest.getInterfaceName());
				InterfaceTypes interfaceTypeRec = InterfaceUtils.selectInterface(originalDestination.getInterfaceType(),pdo);
				pdo.set(X_EXTN_INTRF_TIMEOUT_INTR_NAME,interfaceTypeRec.getInterfaceName());
				return interfaceTypeRec.getInterfaceName();
			} catch (Exception e) {
				logger.error("interface selection failed, attempt release on original interface",e);			
			}
			
			return null;
		}

		private String getTimeoutInterface(PDO pdo) {
			return pdo.getString(X_EXTN_INTRF_TIMEOUT_INTR_NAME);		
		}
	}
}
