package backend.paymentprocess.flowstep.g3.ocbc;
import static backend.core.module.MessageConstantsInterface.MESSAGE_STATUS_COMPLETE;
import static backend.core.module.MessageConstantsInterface.MESSAGE_STATUS_SERVICE_RELEASE;
import static backend.core.module.MessageConstantsInterface.MESSAGE_TYPE_CAMT_029;
import static backend.core.module.MessageConstantsInterface.MOP_BOOK;
import static backend.core.module.MessageConstantsInterface.MSG_CLASS_ORR;
import static backend.core.module.MessageConstantsInterface.RELATION_TYPE_ANSWER;
import static backend.core.module.MessageConstantsInterface.RELATION_TYPE_INCOMING_CANCELLATION_REQUEST;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_CDT_MOP;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_CREATE_DT;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_DBT_MOP;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_MSG_CLASS;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_MSG_STS;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_MSG_TYPE;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_OFFICE;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_PREVIOUS_MSG_STS;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.X_CRE_DT_TM;
import static com.fundtech.errors.ProcessErrorConstants.MessageStatusChanged;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.businessobject.BOProxies;
import backend.paymentprocess.commons.MessageUtils;
import backend.paymentprocess.erroraudit.ErrorAuditUtils;
import backend.paymentprocess.flowstep.AbstractFlowStep;
import backend.paymentprocess.highvalueprocess.businessobjects.BOHighValueProcess;
import backend.util.ServerUtils;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.errorhandling.ProcessError;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.datacomponent.response.SimpleResponseDataComponent;
import com.fundtech.util.GlobalUtils;
import com.fundtech.util.datetime.NewASDateTimeUtils;

public class AnswerGenerationFlowStep extends AbstractFlowStep {
	final String TRACE_FAILURE_IN_GENERATING_ANSWER_NO_ANSWER_MID = "Failure in generating answer PDO process; no 'Answer' MID was generated";
	final String TRACE_FAILURE_PROCESSING_ANSWER_MID_HAS_FAILED = "Failure: generationAndTransmissionFlowStep MID {} was generated and its process failed: {}.";
	final String TRACE_SETTING_MSG_CLASS_MESSAGE = "Generated 'Answer' had empty/null P_MSG_CLASS; set it to 'NAC'.";
	final String TRACE_EXECUTES_FORMATTING_AND_TRANSMISSION = "Executes formatting & transmission for Answer generated response";
	final String METHOD_OUTPUT = "Graceful termination status: {}";
	final String TRACE_SUCCESS_IN_GENERATING_ANSWER = "Success in generating 'Answer' PDO process; generated MID: {}.";
	final static Logger logger = LoggerFactory.getLogger(AnswerGenerationFlowStep.class);
	
	@Override
	public void performPreAction(PDO pdo) {
		pdo.set(P_PREVIOUS_MSG_STS, pdo.getString(P_MSG_STS));
		if (MessageUtils.isDirectDebit(pdo)) {
			pdo.set(P_DBT_MOP, MOP_BOOK);
		} else {
			pdo.set(P_CDT_MOP, MOP_BOOK);
		}
	}
	
	@Override
	public Feedback performMainAction(PDO pdo) throws Throwable {
		Feedback feedback;
		String sAnswerGeneratedMID = null;
		SimpleResponseDataComponent generateTransactionResponse = BOProxies.m_generateTransactionLogging.generateRelatedTransaction(Admin.getContextAdmin(), pdo.getMID(), RELATION_TYPE_INCOMING_CANCELLATION_REQUEST, RELATION_TYPE_ANSWER);
		feedback = generateTransactionResponse.getFeedback();
		Object[] arrData = generateTransactionResponse.getDataArray();
		boolean bValidGeneratedMID = ServerUtils.isArrayNotNullAndNotEmpty(arrData);
		boolean bValidGeneratedResponsePDO = true;
		PDO pdoAnswer = pdo.getLinkedMsg(RELATION_TYPE_ANSWER);
		
		
		// Valid 'Answer' message MID; executes formatting and transmission for that MID.
		if(feedback.isSuccessful() && bValidGeneratedMID){
			sAnswerGeneratedMID = arrData[0].toString();
			logger.info(TRACE_SUCCESS_IN_GENERATING_ANSWER, sAnswerGeneratedMID);
			// Success in creating the 'Answer' message for the 'Cancellation Request' payment;
			if(MESSAGE_TYPE_CAMT_029.equals(pdoAnswer.getString(P_MSG_TYPE))){
				if(GlobalUtils.isNullOrEmpty(pdoAnswer.getString(P_MSG_CLASS))){
					// Assuring that P_MSG_CLASS has an actual value, if not then assign ORR.
					logger.info(TRACE_SETTING_MSG_CLASS_MESSAGE, MSG_CLASS_ORR);
					pdoAnswer.set(P_MSG_CLASS, MSG_CLASS_ORR);
					bValidGeneratedResponsePDO = false;
				}
				//Need to set P_CREATE_DT
				if((pdoAnswer.isNew() || GlobalUtils.isNullOrEmpty(pdoAnswer.getString(P_CREATE_DT))))
				{
					pdoAnswer.set(P_CREATE_DT, 
							NewASDateTimeUtils.getCurrentDateAndZoneByOffice(pdoAnswer.getString(P_OFFICE)).getDate()) ;
				} 
				
				if(pdoAnswer.get(X_CRE_DT_TM)== null) pdoAnswer.set(X_CRE_DT_TM, pdoAnswer.get(P_CREATE_DT)) ;	
				
				//set message status to complete
				pdoAnswer.set(P_MSG_STS,MESSAGE_STATUS_COMPLETE);
				
				//for the next two process to be assigned with the new created ANSWER pdo
				//pdoAnswer.promoteToPrimary();
				
				//perform FormatOutAndTransmission
				logger.info(TRACE_EXECUTES_FORMATTING_AND_TRANSMISSION);
				feedback = BOHighValueProcess.performFormatOutAndTransmission(pdoAnswer, feedback);
				
				if(feedback.isSuccessful()){
					//perform TerminationSubFlow
					feedback = BOHighValueProcess.performTerminationSubFlow(pdoAnswer, null);
				}
			}
		}
		
		// Sets back the Cancellation Request (Camt_056) PDO to be the primary PDO for rest of the process.
		pdo.promoteToPrimary();
		
		if(!feedback.isSuccessful() || !bValidGeneratedMID || !bValidGeneratedResponsePDO){
			// Determines right failure trace line.
			if(GlobalUtils.isNullOrEmpty(sAnswerGeneratedMID)) logger.info(TRACE_FAILURE_IN_GENERATING_ANSWER_NO_ANSWER_MID);
			else logger.info(TRACE_FAILURE_PROCESSING_ANSWER_MID_HAS_FAILED, sAnswerGeneratedMID, ServerUtils.getFeedbackString(feedback));

			// setting process feedback to failure , if not set already
			feedback.setFailure();
			
			// In case the failure was after the transaction generation, then removes the created 'Answer' PDO from the Cancellation Request (Camt_056) PDO.
			if(pdoAnswer != null){
				String prevMessageStatus = pdoAnswer.getString(P_MSG_STS);
				pdoAnswer.set(P_MSG_STS, MESSAGE_STATUS_SERVICE_RELEASE);
				ErrorAuditUtils.setErrors(new ProcessError(MessageStatusChanged, new Object[] 
						{ prevMessageStatus, MESSAGE_STATUS_SERVICE_RELEASE }),pdoAnswer);
				pdo.clearLinkedMsg(RELATION_TYPE_ANSWER);
			}
		}
		
		return feedback;
	}

}

