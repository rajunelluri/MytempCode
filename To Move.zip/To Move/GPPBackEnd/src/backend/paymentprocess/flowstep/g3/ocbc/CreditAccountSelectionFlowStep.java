package backend.paymentprocess.flowstep.g3.ocbc;

import static backend.businessobject.BOProxies.m_accountDerivationLogging;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.D_ACCOUNT_DERIVATION_TYPE;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_CDT_ACCT_CCY;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.paymentprocess.accountderivation.common.AccountDerivationConstants.AccountDerivationType;
import backend.paymentprocess.flow.g3.G3Util;
import backend.paymentprocess.flowstep.AbstractFlowStep;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;

public class CreditAccountSelectionFlowStep extends AbstractFlowStep {
	
	final static Logger logger = LoggerFactory.getLogger(CreditAccountSelectionFlowStep.class);
	private final String CRD = "CRD";
	

	@Override
	public void performPreAction(PDO pdo) {
		pdo.set(D_ACCOUNT_DERIVATION_TYPE, AccountDerivationType.Credit.toString());
	}

	@Override
	public Feedback performMainAction(PDO pdo) throws Exception {
		
		Feedback feedback = new Feedback();
		String msgSubType = pdo.getString(PDOConstantFieldsInterface.P_MSG_SUB_TYPE);
		
		//In case msgSubType = CRED, skip account inq.
		if (msgSubType!= null && msgSubType.equals(CRD)){
			return feedback;
		}
		
		feedback = m_accountDerivationLogging.performAccountInquiry(Admin.getContextAdmin(), pdo.getMID());
		
		//Prints G3 Cards UDF values
		if (msgSubType!= null){
			String casaNumber = pdo.getString(PDOConstantFieldsInterface.U_CASA_ACCT_NUM);
			String acctName = pdo.getString(PDOConstantFieldsInterface.U_CDT_ACCT_NAME);
			String acctShortName = pdo.getString(PDOConstantFieldsInterface.U_EBS_SHORT_NM);
			String acctEmbossNm = pdo.getString(PDOConstantFieldsInterface.U_EBS_EMBOSS_NM);
			
			logger.info("G3 Cards UDF returned values: U_EBSCASA_ACCT_NUM=[{}], U_CDT_ACCT_NAME=[{}], U_EBS_SHORT_NM=[{}], U_EBS_EMBOSS_NM=[{}]",
					new Object []{casaNumber,acctName,acctShortName,acctEmbossNm});
			
		}
		
		return feedback;
	}
	
	@Override
	public Feedback performPostAction(PDO pdo,Feedback feedback) {
		if(!feedback.isSuccessful()) return feedback;
		
		return G3Util.populateCreditAccount(pdo, feedback);
	}
}
