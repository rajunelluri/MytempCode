package backend.paymentprocess.flowstep.g3.ocbc;

import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.D_CUSTOMER_BIC;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.D_DERIVED_DEBIT_CREDIT_CUSTOMER;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_OFFICE;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.X_DBTR_AGT_BIC_2AND;
import static com.fundtech.errors.ProcessErrorConstants.UnableToIdentifyFirstInCreditChain;
import static com.fundtech.util.GlobalConstants.DEFAULT_SERVER_OFFICE_NAME;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.businessobject.BOBasic;
import backend.paymentprocess.commons.MessageUtils;
import backend.paymentprocess.erroraudit.ErrorAuditUtils;
import backend.paymentprocess.flowstep.AbstractFlowStep;

import com.fundtech.cache.entities.Customrs;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.errorhandling.ProcessError;
import com.fundtech.datacomponent.response.Feedback;

public class DebitPartyDerivationFlowStep extends AbstractFlowStep {
	final static Logger logger = LoggerFactory.getLogger(DebitPartyDerivationFlowStep.class);

	@Override
	public void performPreAction(PDO pdo) {
		String debitCustomerBic = pdo.getString(X_DBTR_AGT_BIC_2AND);
		pdo.set(D_CUSTOMER_BIC, debitCustomerBic);
	}

	@Override
	// thin party processing. the assumption is that the bic is coming from payment and is mapped to
	// X_CDTR_AGT_BIC_2AND by mapping rules (per Liat M. 19/7/2012)
	public Feedback performMainAction(PDO pdo) {
		Feedback feedback = new Feedback();
		String customerBic = pdo.getString(D_CUSTOMER_BIC);
		if(customerBic==null){
			customerBic=MessageUtils.getBic(pdo);
			pdo.set(X_DBTR_AGT_BIC_2AND,customerBic);
		}
		logger.debug("customer lookup attempt: bic {}, office {}",customerBic,pdo.getString(P_OFFICE));
		Customrs derivedCustomer = CacheKeys.customrsBICandOfficeKey.getSingle(customerBic, pdo.getString(P_OFFICE));//bank should be found in GPP
		if (derivedCustomer == null) {
			logger.debug("customer lookup attempt: bic {}, office {}",customerBic,pdo.getString(P_OFFICE));
			derivedCustomer = CacheKeys.customrsBICandOfficeKey.getSingle(customerBic, DEFAULT_SERVER_OFFICE_NAME);			
		}
		if (derivedCustomer == null) {// failure
			ProcessError error = new ProcessError(UnableToIdentifyFirstInCreditChain);
			feedback = BOBasic.configureErrorFeedback(error, feedback);
			ErrorAuditUtils.setErrors(error);
		} else {				
			pdo.set(D_DERIVED_DEBIT_CREDIT_CUSTOMER, derivedCustomer);
		}
		return feedback;
	}
	
	@Override
	public Feedback performPostAction(PDO pdo,Feedback feedback) {
		if(!feedback.isSuccessful()) return feedback;
		
		Customrs debitCustomer = (Customrs) pdo.get(D_DERIVED_DEBIT_CREDIT_CUSTOMER);
		pdo.setDEBIT_CUSTOMER(debitCustomer);
		pdo.set(PDOConstantFieldsInterface.P_DBT_CUST_CD, debitCustomer.getCustCode());
		return feedback;
	}
}
