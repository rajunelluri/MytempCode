package backend.paymentprocess.flowstep.g3.ocbc;

import org.apache.commons.lang.StringUtils;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.datacomponent.response.Feedback;

import backend.paymentprocess.flowstep.AbstractFlowStep;

public class BulkSubBatchDebitAccountInquiryFlowStep extends AbstractFlowStep {
	
	private DebitAccountSelectionFlowStep debitAccountSelection = new DebitAccountSelectionFlowStep();

	@Override
	public void performPreAction(PDO pdo) {
		debitAccountSelection.performPreAction(pdo);
	}

	@Override
	public Feedback performMainAction(PDO pdo) throws Throwable {
		return debitAccountSelection.performMainAction(pdo);
	}
	
	@Override
	public Feedback performPostAction(PDO pdo,Feedback feedback) {
		feedback = debitAccountSelection.performPostAction(pdo,feedback);
		
		if (!feedback.isSuccessful()) {	
			//debt currency column is mandatory, avoid persistence error
			if (StringUtils.isEmpty(pdo.getNSetBatchSubset().getDebitCurrency()))
					pdo.getNSetBatchSubset().setDebitCurrency("?");  
			
			//delegate post to BulkRejectSubBatch
			feedback = new BulkRejectSubBatchFlowStep().performPostAction(pdo,feedback); 
		}
			
		return feedback;
	}
}
