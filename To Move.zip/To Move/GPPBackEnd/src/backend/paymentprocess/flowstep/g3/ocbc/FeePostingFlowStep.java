package backend.paymentprocess.flowstep.g3.ocbc;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;



import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.datacomponent.response.Feedback;

public class FeePostingFlowStep extends PostingFlowStep{
	final static Logger logger = LoggerFactory.getLogger(FeePostingFlowStep.class);
	
	public Feedback performPostAction(PDO pdo,Feedback feedback) {
			if(!feedback.isSuccessful()){	//QC# 42415
				feedback = new Feedback();
			}
		return feedback;
	}
}
