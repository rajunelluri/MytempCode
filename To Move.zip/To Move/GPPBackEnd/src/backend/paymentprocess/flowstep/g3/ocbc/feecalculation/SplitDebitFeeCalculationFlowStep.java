package backend.paymentprocess.flowstep.g3.ocbc.feecalculation;

import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.D_FEE_CALCULATION_TYPE;
import backend.paymentprocess.feescalculation.common.FeesCalculationType;
import backend.paymentprocess.flow.g3.G3Util;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.datacomponent.response.Feedback;
/**
 * this class immitates DebitFeeCalculationFlowSte , but never changes the message status and sends successful feedback
 * @author eyalr
 *
 */
public class SplitDebitFeeCalculationFlowStep extends FeeCalculationBaseFlowStep {
	String sMsgStatus = "";
	public SplitDebitFeeCalculationFlowStep() {
		super(false);
	}

	@Override
	public void performPreAction(PDO pdo) {
		pdo.set(D_FEE_CALCULATION_TYPE,FeesCalculationType.DEBIT.name() );
		pdo.set(PDOConstantFieldsInterface.D_DBT_FEE_POST_AMT, (String) null);
		G3Util.populateDebitAccount(pdo, new Feedback());
		
		sMsgStatus = pdo.getString(PDOConstantFieldsInterface.P_MSG_STS);
	}
	protected Feedback performPostAction(PDO pdo, Feedback feedback) {
		pdo.set(PDOConstantFieldsInterface.P_MSG_STS, sMsgStatus);
		if(!feedback.isSuccessful()){	//QC# 42415
			feedback = new Feedback();
		}
		return feedback;
	}
}