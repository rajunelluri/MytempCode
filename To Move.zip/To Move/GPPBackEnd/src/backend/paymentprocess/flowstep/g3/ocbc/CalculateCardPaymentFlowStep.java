package backend.paymentprocess.flowstep.g3.ocbc;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.cache.entities.SicsBin;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.errorhandling.ProcessError;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.errors.ProcessErrorConstants;

import backend.paymentprocess.erroraudit.ErrorAuditUtils;
import backend.paymentprocess.flowstep.AbstractFlowStep;
import backend.paymentprocess.memopost.businessobjects.BOMemoPost;

public class CalculateCardPaymentFlowStep extends AbstractFlowStep {

	private final String CRD = "CRD";
	private final String DBT = "DBT";
	
	final static Logger logger = LoggerFactory.getLogger(CalculateCardPaymentFlowStep.class);
	
	@Override
	protected Feedback performMainAction(PDO pdo) throws Throwable {
		Feedback feedback = new Feedback();
		String acctNumber = pdo.getString(PDOConstantFieldsInterface.X_CDTR_ACCT_ID);
		
		int acctNumberLength=0;
		if (acctNumber!=null){
			acctNumberLength = acctNumber.length();
			logger.info("CalculateCardPaymentFlowStep account: [{}] length: [{}]", acctNumber, acctNumberLength);
		}else{
			logger.info("CalculateCardPaymentFlowStep Creditor account number is missing rejecting payment");
			feedback.setErrorCode(ProcessErrorConstants.InvalidReceivingAccountNo);
			ProcessError pError=ProcessError.getError(ProcessErrorConstants.InvalidReceivingAccountNo,null,null);
			ErrorAuditUtils.setErrors(pError,pdo.getIsHistory());
			pdo.set(PDOConstantFieldsInterface.P_TX_CTGY, "CTI");
			feedback.setFailure();
		}
		
		//account length can not be less than 9 chars
		if (acctNumberLength < 9){
			feedback.setErrorCode(ProcessErrorConstants.cdtrAcctIdLengthIsInvalid);
			ProcessError pError=ProcessError.getError(ProcessErrorConstants.cdtrAcctIdLengthIsInvalid,null,null);
			ErrorAuditUtils.setErrors(pError,pdo.getIsHistory());
			pdo.set(PDOConstantFieldsInterface.P_TX_CTGY, "CTI");
			feedback.setFailure();
			return feedback;
		}
		
		
		//if account num length is 10 or 12 continue BAU
		if(acctNumberLength==10 || acctNumberLength==12){
			return feedback;
		}
		
		//If account num length is 9, it is always CRED account.
		if(acctNumberLength==9){
			pdo.set(PDOConstantFieldsInterface.P_MSG_SUB_TYPE,CRD);
		}else{
			
			//acctNumber length is not equal to 9,10 or 12
			String productType;
			String binNum = "";
			int sicsBinEntryLength;
			boolean foundMatch = false;
			String cardNumLen = "0" + String.valueOf(acctNumberLength);
			
			logger.info("CalculateCardPaymentFlowStep Card length in SICS_TABLE = [{}]",cardNumLen);
			List<SicsBin> sicsBinList = CacheKeys.sicsBinKey.get(null, cardNumLen);
			
			if (sicsBinList == null){
				feedback.setErrorCode(ProcessErrorConstants.InvalidReceivingAccountNo);
				ProcessError pError=ProcessError.getError(ProcessErrorConstants.InvalidReceivingAccountNo,null,null);
				ErrorAuditUtils.setErrors(pError,pdo.getIsHistory());
				pdo.set(PDOConstantFieldsInterface.P_TX_CTGY, "CTI");
				feedback.setFailure();
				return feedback;
			}
			
			Map<Integer,List<SicsBin>> sicsBinGroupList = divideSicsBinEntryIntoGroups(sicsBinList);
			Integer maxVal = acctNumberLength-1;
			while (maxVal>=0){
				
				sicsBinList = sicsBinGroupList.get(maxVal);
				logger.info("Getting entries for BIN_LEN: [{}]", maxVal);
				if (sicsBinList!=null){
					for (SicsBin sicsBinEntry : sicsBinList){
						binNum = sicsBinEntry.getBinNum();
						sicsBinEntryLength =  sicsBinEntry.getBinLen();
						if (binNum.equals(acctNumber.substring(0,sicsBinEntryLength))){
							
							productType = sicsBinEntry.getProductType();
							logger.info("Found matching entry for BIN_NUM: [{}], product type = [{}]", binNum, productType);
							if (productType.equals("1")){
								pdo.set(PDOConstantFieldsInterface.P_MSG_SUB_TYPE,CRD);
							}else{
								pdo.set(PDOConstantFieldsInterface.P_MSG_SUB_TYPE,DBT);
							}
							foundMatch = true;
							break;
						}
					}
					if (foundMatch)
						break;
				}else{
					logger.info("BIN_LEN [{}] does not appear in SICS_BIN table continuing to next length", maxVal);
				}
				maxVal--;
			}
			
			if (!foundMatch){
				feedback.setErrorCode(ProcessErrorConstants.InvalidReceivingAccountNo);
				ProcessError pError=ProcessError.getError(ProcessErrorConstants.InvalidReceivingAccountNo,null,null);
				ErrorAuditUtils.setErrors(pError,pdo.getIsHistory());
				pdo.set(PDOConstantFieldsInterface.P_TX_CTGY, "CTI");
				feedback.setFailure();
			}
		}
		
		return feedback;
	}
	
	private Map<Integer,List<SicsBin>> divideSicsBinEntryIntoGroups(List<SicsBin> sicsBinList){
		Map<Integer,List<SicsBin>> sicsBinGroupMap = new HashMap<Integer,List<SicsBin>>();
		
		Integer binLen;
		List<SicsBin> binList;
		for (SicsBin sicsBinEntry : sicsBinList){
			binLen = sicsBinEntry.getBinLen();
			binList = sicsBinGroupMap.get(binLen);
			if (binList == null){
				binList = new ArrayList<SicsBin>();
				binList.add(sicsBinEntry);
				sicsBinGroupMap.put(binLen, binList);
			}else{
				binList.add(sicsBinEntry);
			}
		}
		return sicsBinGroupMap;
		
	}

}