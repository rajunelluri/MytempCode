package backend.paymentprocess.flowstep.g3.ocbc;

import backend.businessobject.BOProxies;
import backend.paymentprocess.commons.MessageUtils;
import backend.paymentprocess.commons.MsgClassType;
import backend.paymentprocess.flowstep.AbstractFlowStep;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;

public class MOPValidationFlowStep extends AbstractFlowStep {
	@Override
	public void performPreAction(PDO pdo) {
		if (MessageUtils.isDirectDebit(pdo)){
			pdo.set(PDOConstantFieldsInterface.D_MSG_CLASS_TYPE, MsgClassType.DD);
		}
	}
	
	@Override
	public Feedback performMainAction(PDO pdo) throws Exception {
		Feedback feedback = BOProxies.m_mopSelectionLogging.performValidationAndValueDateCalculation(Admin.getContextAdmin(), pdo.getMID());//performMopValidation(Admin.getContextAdmin(), pdo.getMID());
		return feedback;
	}
	
	@Override
	public Feedback performPostAction(PDO pdo,Feedback feedback) {
	
		return feedback;
	}
}
