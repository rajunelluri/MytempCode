package backend.paymentprocess.flowstep.g3.ocbc;

import static backend.businessobject.BOProxies.m_enrichmentLogging;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;

import backend.core.module.MessageConstantsInterface;
import backend.paymentprocess.flowstep.AbstractFlowStep;

public class BulkRepairAndEnrichmentFlowStep extends AbstractFlowStep {

	@Override		
	public Feedback performMainAction(PDO pdo) throws Exception {
		pdo.set(PDOConstantFieldsInterface.D_RULE_TYPE_ID, MessageConstantsInterface.RULE_TYPE_ID_REPAIR_AND_ENRICHMENT_SELECTION);
		Feedback feedback = m_enrichmentLogging.repairAndEnrich(Admin.getContextAdmin());				
		return feedback;
	}
}
