package backend.paymentprocess.flowstep.g3.ocbc;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.datacomponent.response.Feedback;

import backend.paymentprocess.flowstep.AbstractFlowStep;

public class BulkSubBatchPrincipalPostingFlowStep extends AbstractFlowStep {
	private PostingFlowStep principlePosting = new PrinciplePostingFlowStep(); // CT - MAIN_DR & BSA_CR


	@Override
	public Feedback performMainAction(PDO pdo) throws Throwable {
		return principlePosting.performMainAction(pdo);
	}
	
	@Override
	public Feedback performPostAction(PDO pdo,Feedback feedback) {
		if (!feedback.isSuccessful())
			//delegate post to BulkRejectSubBatch
			feedback = new BulkRejectSubBatchFlowStep().performPostAction(pdo,feedback); 
			
		return feedback;
	}
}
