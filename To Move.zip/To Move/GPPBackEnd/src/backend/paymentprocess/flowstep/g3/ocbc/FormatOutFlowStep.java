package backend.paymentprocess.flowstep.g3.ocbc;

import static backend.businessobject.BOProxies.m_messageHandleLogging;
import backend.paymentprocess.flowstep.AbstractFlowStep;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;

public class FormatOutFlowStep extends AbstractFlowStep {
	@Override
	public Feedback performMainAction(PDO pdo) throws Throwable {
		Feedback feedback;
		feedback = m_messageHandleLogging.formatOutMessage(Admin.getContextAdmin(), pdo.getMID());
		return feedback;
	}
}
