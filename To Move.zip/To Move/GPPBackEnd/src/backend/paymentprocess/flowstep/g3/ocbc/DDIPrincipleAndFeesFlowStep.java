package backend.paymentprocess.flowstep.g3.ocbc;

import static backend.paymentprocess.memopost.businessobjects.BOMemoPost.POSTING;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.core.module.MessageConstantsInterface;
import backend.paymentprocess.flowstep.AbstractFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.feecalculation.DebitFeeCalculationFlowStep;

import com.fundtech.cache.entities.InterfaceTypes;
import com.fundtech.cache.entities.MsgFees;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.interfaces.InterfaceTypeConstants;
import com.fundtech.util.GlobalUtils;

public class DDIPrincipleAndFeesFlowStep extends AbstractFlowStep 
{
    private static final Logger logger = LoggerFactory.getLogger(DDIPrincipleAndFeesFlowStep.class);

    @Override
    public Feedback performMainAction(PDO pdo) throws Throwable 
    {
        Feedback principlePostingFeedback = new Feedback();
        InterfaceTypes interfaceTypeRec = CacheKeys.interfaceTypesNameKey.getSingle(POSTING);

        PostingFlowStep principlePosting = new PrinciplePostingFlowStep(); //MAIN_CR & MAIN_DR
        principlePostingFeedback = principlePosting.execute(pdo);
        
        if(GlobalUtils.isErrorCorrectionFlow(pdo))
		{
			pdo.set(PDOConstantFieldsInterface.P_MSG_STS,MessageConstantsInterface.MESSAGE_STATUS_REJECTED);
			return principlePostingFeedback;
		}

        //QC# 77873: Refined QC# 75915 fix to only restrict posting calculation if interface is inactive.
        if (!InterfaceTypeConstants.INTERFACE_INACTIVE_STATUS.equalsIgnoreCase(interfaceTypeRec.getInterfaceStatus()))
        {
            DebitFeeCalculationFlowStep debitFeeCalculation = new DebitFeeCalculationFlowStep();
            Feedback feeFeedback = debitFeeCalculation.execute(pdo);
            
            boolean isFeeAccountPrtryMapped = false;
    		String originalValue = pdo.getString(PDOConstantFieldsInterface.X_DBTR_ACCT_PRTRY);
    		if (feeFeedback.isSuccessful())
    			isFeeAccountPrtryMapped = calculateFeePrtry(pdo, feeFeedback);
            
    		//In case fee account is not 10 or 12 digits return failure error
    		if (!feeFeedback.isSuccessful()){
    			 return feeFeedback;
    		}

            PostingFlowStep debitFeePosting = new PostingFlowStep(); // FEE_DR && PNL_DR
            feeFeedback = debitFeePosting.execute(pdo);
            
          //Return the original X_DBTR_ACCT_PRTRY value after Fee mapping
    		if (isFeeAccountPrtryMapped){
    			pdo.set(PDOConstantFieldsInterface.X_DBTR_ACCT_PRTRY, originalValue);
    		}

            if (!principlePostingFeedback.isSuccessful())
            {
                return principlePostingFeedback;
            }
            else
            {
                return feeFeedback;
            }
        }
        else
        {
            logger.warn("Principal posting failed, therefore debit fee calculation was not executed and was not posted");
            return principlePostingFeedback;
        }
    }
    
    public boolean calculateFeePrtry(PDO pdo, Feedback feedback){
		
		List<MsgFees> listMsgFees = pdo.getNSetListMSG_FEES();
		String sAccountNo = null;
		if (listMsgFees!= null){
			for(MsgFees msgFee : listMsgFees){
				if (msgFee.getDeductFrom().equals("A")){
					sAccountNo = pdo.getString(PDOConstantFieldsInterface.P_DBT_FEE_ACCT_NB);
					break;
				}
			}
		}
		
		if (sAccountNo==null)
			return false;
		
		
		int iAccountLength=sAccountNo.length();
		logger.debug("The account length is: {}",iAccountLength);	    
		if (10==iAccountLength)
		{
			pdo.set(PDOConstantFieldsInterface.X_DBTR_ACCT_PRTRY ,"S");
		}
		else 
		{
			if (12==iAccountLength)
			{
				pdo.set(PDOConstantFieldsInterface.X_DBTR_ACCT_PRTRY,"D");
		    }
			else 
			{
				 logger.debug("The account length is neither 10 nor 12 therefore the transaction will reject");
				 pdo.set(PDOConstantFieldsInterface.P_MSG_STS, MessageConstantsInterface.MESSAGE_STATUS_REJECTED);
				 feedback.setFailure();
				 return false;
			}	
		}
		return true;
	}
}
