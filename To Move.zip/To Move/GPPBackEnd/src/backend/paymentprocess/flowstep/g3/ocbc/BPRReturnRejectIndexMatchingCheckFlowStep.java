package backend.paymentprocess.flowstep.g3.ocbc;

import static backend.businessobject.BOProxies.m_matchingCheckLogging;
import static com.fundtech.util.GlobalUtils.isNullOrEmpty;
import backend.core.module.MessageConstantsInterface;
import backend.paymentprocess.erroraudit.ErrorAuditUtils;
import backend.paymentprocess.flowstep.AbstractFlowStep;
import backend.paymentprocess.matchingcheck.output.MatchingCheckOutputData;
import backend.paymentprocess.paymentservices.businessobjects.BOPaymentServices;
import backend.staticdata.dataaccess.dao.DAOStaticData;

import com.fundtech.cache.entities.Errcodes;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.core.paymentprocess.errorhandling.ProcessError;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.errors.ProcessErrorConstants;
import com.fundtech.util.GlobalUtils;

/**
 * Created for Business Layer IRD/ORD matching and will only be assign at sub batch completion flow
 * Which will support the Bulk validation rule results effectively
 * @author shay.asael
 *
 */
public class BPRReturnRejectIndexMatchingCheckFlowStep extends AbstractFlowStep implements PDOConstantFieldsInterface, MessageConstantsInterface {
    protected static DAOStaticData m_daoStaticData = new DAOStaticData() ;
    private String ORIGINAL_PAYMENT_UNAVAILABLE = "Unable to retrieve the original payment";
    
	@Override
	public Feedback performMainAction(PDO pdo) {
		Feedback feedback = new Feedback();
		String sMU_ROFI_MATCH_FORCE_STS = pdo.getString(MU_ROFI_MATCH_FORCE_STS); // manually matched (by force)
		String sMF_ROFI_MATCH_STS = pdo.getString(MF_ROFI_MATCH_STS);

		if (!MONITOR_FLAG_MATCH.equals(sMF_ROFI_MATCH_STS) || !MONITOR_FLAG_FORCE.equals(sMU_ROFI_MATCH_FORCE_STS))
		{
			MatchingCheckOutputData matchingCheckOutputData = m_matchingCheckLogging.performMatchingCheck(Admin.getContextAdmin(), pdo.getMID(),
					RELATION_TYPE_INCOMING_REJECT_RETURN, RELATION_TYPE_ORIGINAL_PAYMENT, false, null);
			feedback = matchingCheckOutputData.getFeedback();
		}
		return feedback;
	}

	@Override
	public Feedback performPostAction(PDO pdo,Feedback feedback) {
		
		String sMF_ROFI_MATCH_STS = pdo.getString(MF_ROFI_MATCH_STS);
		logger.debug("MF_ROFI_MATCH_STS status is [{}]",sMF_ROFI_MATCH_STS);
		String sInitial_P_MSG_STS = pdo.getString(P_MSG_STS);
		String sNewMessageStatus = null;
		
		// MF_ROFI_MATCH_STS = 'M'
		if(MONITOR_FLAG_MATCH.equals(sMF_ROFI_MATCH_STS))
		{
			PDO pdoOriginalPayment = pdo.getLinkedMsg(RELATION_TYPE_ORIGINAL_PAYMENT);
			
			if(pdoOriginalPayment == null)
			{
				logger.error(ORIGINAL_PAYMENT_UNAVAILABLE);
				feedback.setFailure();
				return feedback;
			}
			
			//This is for the case were we receive 2nd pacs_004 in BP flow.
			//In this case pacs_004 should go directly to ROFI
			if (pdoOriginalPayment.getString(MF_ROFI_MATCH_STS).equals(MONITOR_FLAG_MATCH)
					&&	pdoOriginalPayment.getString(P_MSG_TYPE).equals("Pacs_004"))
			{
				sNewMessageStatus = MESSAGE_STATUS_ROFI;
			}
			else
			{
				String sOriginalOldMessageStatus = pdoOriginalPayment.getString(P_MSG_STS);
				
				//update of the return pdo with the matched orig payment fields
				updatingReturnPDOWithOrigPaymentFields(pdo,pdoOriginalPayment);
				
				// Needed for updating the MFamily relation entry
				// Will be used in the Sub Batch Completion flow (BPRReturnRejectIndexMatchingCompletionFlowStep)
				pdoOriginalPayment.setListMFAMILY(pdo.getListMFAMILY());
				
				//In case match is found, the original payment which is not part of the bulk should change status to RETURNED and saved in MINF
				pdoOriginalPayment.set(P_MSG_STS, MESSAGE_STATUS_RETURNED);
					
				ProcessError processError = new ProcessError(ProcessErrorConstants.MessageStatusChanged,
												new Object[] { sOriginalOldMessageStatus,MESSAGE_STATUS_RETURNED });
				ErrorAuditUtils.setErrors(processError, pdoOriginalPayment);
					
				pdoOriginalPayment.getField(P_MSG_STS).setOriginalValue(sOriginalOldMessageStatus);	//this is needed to support future status changes
					
				//insert a message error for the rejection with the return reason error and its description from errcodes table
				String sReason = pdo.getString(X_RTN_RSN_PRTRY);
				Errcodes errorcodes=CacheKeys.errcodesKey.getSingle("***", MOP_G3_BULK,"",sReason);
				String errDesc = null;
		    	if (null!=errorcodes)
		    	{
		    		errDesc = errorcodes.getContents();
		    	}
				processError = new ProcessError(ProcessErrorConstants.BulkTransactionReturn, new Object[] { sReason, errDesc });
				ErrorAuditUtils.setErrors(processError, pdoOriginalPayment);
					
				logger.debug("setting original pdo, with mid [{}] to RETURNED",pdoOriginalPayment.getMID());
				
				Admin.setContextPDO(pdoOriginalPayment);
				try 
				{
					PaymentDataFactory.batchSave(true, pdoOriginalPayment);
				} 
				catch (Throwable e) 
				{
					logger.error(e.getMessage());
				}finally
				{
					CacheKeys.ProcessPDOKey.removeFromLocalAndRemote(pdoOriginalPayment);
					Admin.setContextPDO(pdo);
				}
			}
		}
		
		// MF_ROFI_MATCH_STS is 'W' or 'D'
		else if(   MONITOR_FLAG_WAITING.equals(sMF_ROFI_MATCH_STS) 
				|| MONITOR_FLAG_DUPLICATE.equals(sMF_ROFI_MATCH_STS))
		{
			// Sets incoming message status to ROFI for future manual matching.
			sNewMessageStatus = MESSAGE_STATUS_ROFI;
		}

		// MF_ROFI_MATCH_STS = 'N'.
		// Illegal setup; sets incoming message status to REJECTED. 
		else if(MONITOR_FLAG_NONE.equals(sMF_ROFI_MATCH_STS))
		{
			sNewMessageStatus = MESSAGE_STATUS_REJECTED;
		}
		
		if(!GlobalUtils.isNullOrEmpty(sNewMessageStatus))
		{
			pdo.set(P_MSG_STS ,sNewMessageStatus);
			
			ProcessError processError = new ProcessError(ProcessErrorConstants.MessageStatusChanged, new Object[] {sInitial_P_MSG_STS, sNewMessageStatus });
			ErrorAuditUtils.setErrors(processError,pdo);
			
			try {
				PaymentDataFactory.batchSave(true, pdo);
			} catch (Throwable e) {
				logger.error(e.getMessage());
			}
		}
		
		return feedback;
	}

	/**
	 * updating the pdo with the matched original payment fields
	 * @param pdo
	 * @param pdoOriginalPayment
	 */
	private void updatingReturnPDOWithOrigPaymentFields(PDO pdo, PDO pdoOriginalPayment) 
	{
		// Sets incoming CREDIT account & CREDIT customer to be taken from the original payment's DEBIT account & DEBIT customer.
		pdo.set(P_CDT_ACCT_NB, pdoOriginalPayment.getString(P_DBT_ACCT_NB));
		pdo.set(P_CDT_ACCT_CCY, pdoOriginalPayment.getString(P_DBT_ACCT_CCY));
		pdo.set(P_CDT_ACCT_OFFICE, pdoOriginalPayment.getString(P_DBT_ACCT_OFFICE));
		pdo.set(P_CDT_AMT, pdo.getDecimal(X_STTLM_AMT));
		pdo.set(P_CDT_CUST_CD, pdoOriginalPayment.getString(P_DBT_CUST_CD));
		//
		// Sets incoming DEBIT account & DEBIT customer to be taken from the original payment's CREDIT account & CREDIT customer.
		pdo.set(P_DBT_ACCT_NB, pdoOriginalPayment.getString(P_CDT_ACCT_NB));
		pdo.set(P_DBT_ACCT_CCY, pdoOriginalPayment.getString(P_CDT_ACCT_CCY));
		pdo.set(P_DBT_ACCT_OFFICE, pdoOriginalPayment.getString(P_CDT_ACCT_OFFICE));
		pdo.set(P_DBT_AMT, pdo.getDecimal(X_STTLM_AMT));
		pdo.set(P_DBT_CUST_CD, pdoOriginalPayment.getString(P_CDT_CUST_CD));

		// Sets the original transaction ID to be taken from the transcation ID of the original payment.
		pdo.set(X_ORGNL_TX_ID, pdoOriginalPayment.getString(X_TX_ID));

		// Copy fields vice versa
		// Debtor fields.
		//
		// X_CDTR_ACCT_ID.
		String sOriginal_X_DBTR_ACCT_ID = pdoOriginalPayment.getString(X_DBTR_ACCT_ID);
		if(!isNullOrEmpty(sOriginal_X_DBTR_ACCT_ID)) pdo.set(X_CDTR_ACCT_ID, sOriginal_X_DBTR_ACCT_ID);
		//
		// X_CDTR_NM.
		String sOriginal_X_DBTR_NM = pdoOriginalPayment.getString(X_DBTR_NM);
		if(!isNullOrEmpty(sOriginal_X_DBTR_NM)) pdo.set(X_CDTR_NM, sOriginal_X_DBTR_NM);
		//
		// X_CDTR_CTRY.
		String sOriginal_X_DBTR_CTRY = pdoOriginalPayment.getString(X_DBTR_CTRY);
		if(!isNullOrEmpty(sOriginal_X_DBTR_CTRY)) pdo.set(X_CDTR_CTRY, sOriginal_X_DBTR_CTRY);
		//
		// Address lines.
		BOPaymentServices.copyMultiField(X_DBTR_ADRLINE, X_CDTR_ADRLINE, RELATION_TYPE_ORIGINAL_PAYMENT, RELATION_TYPE_INCOMING_REJECT_RETURN);

		// Creditor fields.
		//
		// X_DBTR_ACCT_ID.
		String sOriginal_X_CDTR_ACCT_ID = pdoOriginalPayment.getString(X_CDTR_ACCT_ID);
		if(!isNullOrEmpty(sOriginal_X_CDTR_ACCT_ID)) pdo.set(X_DBTR_ACCT_ID, sOriginal_X_CDTR_ACCT_ID);
		//
		// X_DBTR_NM.
		String sOriginal_X_CDTR_NM = pdoOriginalPayment.getString(X_CDTR_NM);
		if(!isNullOrEmpty(sOriginal_X_CDTR_NM)) pdo.set(X_DBTR_NM, sOriginal_X_CDTR_NM);
		//
		// X_DBTR_CTRY.
		String sOriginal_X_CDTR_CTRY = pdoOriginalPayment.getString(X_CDTR_CTRY);
		if(!isNullOrEmpty(sOriginal_X_CDTR_CTRY)) pdo.set(X_DBTR_CTRY, sOriginal_X_CDTR_CTRY);
		//
		// Address lines.
		BOPaymentServices.copyMultiField(X_CDTR_ADRLINE, X_DBTR_ADRLINE, RELATION_TYPE_ORIGINAL_PAYMENT, RELATION_TYPE_INCOMING_REJECT_RETURN);
	}

}