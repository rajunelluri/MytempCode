package backend.paymentprocess.flowstep.g3.ocbc;

import static backend.core.module.MessageConstantsInterface.MESSAGE_TYPE_PACS_003;
import backend.businessobject.BOProxies;
import backend.core.module.MessageConstantsInterface;
import backend.paymentprocess.erroraudit.ErrorAuditUtils;
import backend.paymentprocess.flowstep.AbstractFlowStep;
import backend.staticdata.profilehandler.DAOBasicProfileHandler;

import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.errorhandling.ProcessError;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.datacomponent.response.SimpleResponseDataComponent;
import com.fundtech.errors.ProcessErrorConstants;
import com.fundtech.util.GlobalUtils;

public class MandateInquiryFlowStep extends AbstractFlowStep 
{
	private static final DAOBasicProfileHandler m_daoBasicProfileHandle = new DAOBasicProfileHandler();
	Feedback feedback=new Feedback();	
	@Override
	public void performPreAction(PDO pdo) 
	{	
		String sAccountNo;
	    boolean bisDebit=MESSAGE_TYPE_PACS_003.equals(pdo.getString(PDOConstantFieldsInterface.P_MSG_TYPE)) ? true: false;
	    sAccountNo = pdo.getString(PDOConstantFieldsInterface.X_DBTR_ACCT_ID);

		if (!bisDebit)
		{					
			sAccountNo = pdo.getString(PDOConstantFieldsInterface.X_DBTR_ACCT_ID);
			String sMandateId=pdo.getString(PDOConstantFieldsInterface.X_MNDT_ID);
			if (null == sMandateId)
			{
				logger.debug("Mandate id is null therefor the process will stop");
				//TOADD RULE 175    		   		
		    }		  
		}
		
		int iAccountLength=sAccountNo.length();
		logger.debug("The account length is: {}",iAccountLength);	    
		if (10==iAccountLength)
		{
			pdo.set(PDOConstantFieldsInterface.X_DBTR_ACCT_PRTRY ,"S");
		}
		else 
		{
			if (12==iAccountLength)
			{
				pdo.set(PDOConstantFieldsInterface.X_DBTR_ACCT_PRTRY,"D");
		    }
			else 
			{
				 logger.debug("The account length is neither 10 nor 12 therefore the transaction will reject");
				 pdo.set(PDOConstantFieldsInterface.P_MSG_STS, MessageConstantsInterface.MESSAGE_STATUS_REJECTED);
				 feedback.setFailure();
			}	
		}
	}
   
	@Override
	public Feedback performMainAction(PDO pdo) throws Throwable {
	    //Run rule RULE_TYPE_ID_INTERFACE_TYPE_SELECTION
		
		try {
			
			com.fundtech.cache.entities.InterfaceTypes interfaceType = CacheKeys.interfaceTypesNameKey.getSingle("MANDATE_INQUIRY");
			String sInterfaceStatus= interfaceType.getInterfaceStatus();
			if (sInterfaceStatus.equals("NOT_ACTIVE")) {
				String sInterfaceName =interfaceType.getInterfaceName();
				logger.debug("interface {} is not ACTIVE, skipping..", sInterfaceName);
				pdo.set(PDOConstantFieldsInterface.P_MSG_STS,MessageConstantsInterface.MESSAGE_STATUS_REJECTED);
				ProcessError processError = new ProcessError(ProcessErrorConstants.InterfaceSetToInactive,new Object[]{sInterfaceName});
				ErrorAuditUtils.setErrors(processError);
				int iSessionId= m_daoBasicProfileHandle.getSessionId();
                m_daoBasicProfileHandle.addInterfaceErrorLog("SYSTEM", iSessionId, sInterfaceName, "ERROR",processError.getDescription() );
				feedback.setFailure();
			}
			else {
			SimpleResponseDataComponent response = BOProxies.m_internalInterfacesLogging.performOutgoingRequestHandler(Admin.getContextAdmin(), pdo.getMID(),
					"MNDT_INQ", (String) null);
	    			 Object [] resp = response.getDataArray();
	    			 
	    			 if (resp != null && resp[0] == null){
	    				 logger.debug("Response for interface {}, recieved an exception moving to REJECT status ", interfaceType.getInterfaceName());
	    				 pdo.set(PDOConstantFieldsInterface.P_MSG_STS,MessageConstantsInterface.MESSAGE_STATUS_REJECTED);
	    				 
	    				 ProcessError processError = new ProcessError(ProcessErrorConstants.InterfaceLevelError,new Object[]{"MANDATE_INQUIRY"});
	    				 ErrorAuditUtils.setErrors(processError);
	    				 feedback.setFailure();
	    			 }else{
	    				 logger.debug("MandateInquiryFlowStep will send the request through  interface:{}","MANDATE_INQUIRY");
	    			 }
					 feedback=response.getFeedback();
				}
		     }
			catch (Exception e) {
				if (e.getCause() !=null && (e.getCause().toString().contains("Could not read request")))
				{//If there is an exception while reading of the Response.the string "Could not read request" will always be displayed in the Exception cause
					String InterfaceErrorLogError = GlobalUtils.getEditedErrorText(ProcessErrorConstants.InterfaceLevelError,"Could not read response,Response Validation failed");
					m_daoBasicProfileHandle.addInterfaceErrorLog("SYSTEM", m_daoBasicProfileHandle.getSessionId(), "MANDATE_INQUIRY", "ERROR",InterfaceErrorLogError);
					ProcessError processError = new ProcessError(ProcessErrorConstants.InterfaceLevelError,new Object[]{"MANDATE_INQUIRY"});
					ErrorAuditUtils.setErrors(processError);
				}
				logger.error("Error while invoking interface type selection rule", e);
				feedback.setFailure();
				
			}
			
		return feedback;
	}
}

	