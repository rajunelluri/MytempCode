package backend.paymentprocess.flowstep.g3.ocbc;

import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.D_G3_IMMEDIATE_FLOW_NAME;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.D_GENERATED_MESSAGE_ID;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_CDT_ACCT_CYCLE;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_CREATE_DT;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_DBT_ACCT_CYCLE;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_MSG_STS;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_OFFICE;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_PREVIOUS_MSG_STS;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_PROC_DT;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.X_CRE_DT_TM;
import static com.fundtech.util.datetime.NewASDateTimeUtils.getCurrentDateAndZoneByOffice;
import backend.paymentprocess.flow.base.FlowName;
import backend.paymentprocess.flowstep.AbstractFlowStep;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.datacomponent.response.Feedback;

public class GenerationAndTransmissionFlowStep extends AbstractFlowStep {
	@Override
	public Feedback performMainAction(PDO pdo) throws Throwable {
		Feedback feedback;
		
		TransactionGenerationFlowStep transactionGeneration = new TransactionGenerationFlowStep();
		feedback = transactionGeneration.execute(pdo);
		if (feedback.isSuccessful()){
			String generatedMessageId = pdo.getString(D_GENERATED_MESSAGE_ID);
			PDO generatedPDO = PaymentDataFactory.load(generatedMessageId);
			generatedPDO.set(D_G3_IMMEDIATE_FLOW_NAME, FlowName.G3ReversalOutgoing);
			generatedPDO.set(X_CRE_DT_TM,getCurrentDateAndZoneByOffice(generatedPDO.getString(P_OFFICE)).getDate());
			generatedPDO.set(P_CREATE_DT,getCurrentDateAndZoneByOffice(generatedPDO.getString(P_OFFICE)).getDate()); 
			generatedPDO.set(P_PROC_DT, pdo.get(P_PROC_DT));
			generatedPDO.set(P_PREVIOUS_MSG_STS, pdo.get(P_MSG_STS));
			generatedPDO.set(P_CDT_ACCT_CYCLE, pdo.get(P_DBT_ACCT_CYCLE));
			
			FormatOutAndTransmissionFlowStep formatOutAndTransmission = new FormatOutAndTransmissionFlowStep();
			feedback = formatOutAndTransmission.execute(generatedPDO);
			generatedPDO.resetRelationsMap();
			PaymentDataFactory.save(true, generatedPDO);
			pdo.promoteToPrimary();
		}
		return feedback;
	}
}
