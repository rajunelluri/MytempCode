package backend.paymentprocess.flowstep.g3.ocbc;

import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_BULKING_PROFILE;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.paymentprocess.commons.MessageUtils;
import backend.paymentprocess.commons.MsgClassType;
import backend.paymentprocess.flowstep.AbstractFlowStep;

import com.fundtech.cache.entities.Mop;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.datacomponent.response.ServiceFeedback;

public class BulkingProfileFlowStep extends AbstractFlowStep {
	final static Logger logger = LoggerFactory.getLogger(BulkingProfileFlowStep.class);

	@Override
	public Feedback performMainAction(PDO pdo) throws Throwable {
		ServiceFeedback feedback=new ServiceFeedback();
		MsgClassType msgClass = MessageUtils.getMsgClassType(pdo);
        Mop mop = msgClass.getDestMop(pdo);
        String bulkingProfile = mop.getBulkingProfileUid();
        logger.info("The selected Bulking Profile is ({})",bulkingProfile);
		pdo.set(P_BULKING_PROFILE,bulkingProfile);
		return feedback;
	}

}
