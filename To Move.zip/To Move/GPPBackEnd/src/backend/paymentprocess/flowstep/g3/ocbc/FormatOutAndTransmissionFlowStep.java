package backend.paymentprocess.flowstep.g3.ocbc;

import static backend.businessobject.BOProxies.m_messageHandleLogging;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.xmlbeans.impl.values.XmlObjectBase;

import backend.core.module.MessageConstantsInterface;
import backend.paymentprocess.erroraudit.ErrorAuditUtils;
import backend.paymentprocess.flow.g3.G3Util;
import backend.paymentprocess.flowstep.AbstractFlowStep;
import backend.paymentprocess.flowstep.common.InstructionIdGenerationFlowStep;
import backend.paymentprocess.highvalueprocess.businessobjects.BOHighValueProcess;
import backend.staticdata.dataaccess.dao.DAOStaticData;

import com.fundtech.cache.entities.Mop;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDO.XmlMetadata;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.core.paymentprocess.data.das.DASInterface.XmlLocationType;
import com.fundtech.core.paymentprocess.data.paymenttypes.PaymentType;
import com.fundtech.core.paymentprocess.errorhandling.ProcessError;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.errors.ProcessErrorConstants;
import com.fundtech.scl.commonTypes.MFamilyLineType;


public class FormatOutAndTransmissionFlowStep extends AbstractFlowStep implements PDOConstantFieldsInterface,MessageConstantsInterface{
	
	final double EPSILON = 0.00000001;
	private boolean bshortfallexists = true;
	private boolean dosplitpayments;
	private BigDecimal creditamount_BD;
	private  BigDecimal maxamount_BD  ;//= creditMop.getMaxamount();
	private BigDecimal shortfall_BD;
	private int numberOfPayments;
	
	@Override
	public void performPreAction(PDO pdo) {
		setSplitPayment(DoSplitPayments(pdo)) ;
	}
	/***
	 * 
	 * @param pdo
	 * @return
	 */
	private boolean DoSplitPayments(PDO pdo) {
		Mop creditMop = CacheKeys.mopKey.getSingle(pdo.getString(P_OFFICE),pdo.getString(P_CDT_MOP));
		final String MopSource = creditMop.getPmntSrc();

		creditamount_BD=  ((pdo.getDecimal(P_CDT_AMT) != null ) ? pdo.getDecimal(P_CDT_AMT) : new BigDecimal(0)) ;		
		
		maxamount_BD = ((creditMop.getMaxamount() != null) ? new BigDecimal(creditMop.getMaxamount()).divide(new BigDecimal(1), 2, RoundingMode.HALF_UP) : new BigDecimal(999999999)) ;
		
		setNumberOfPayments((int)((creditamount_BD.divide(maxamount_BD,5,RoundingMode.HALF_UP)).doubleValue() + 1));
				
		shortfall_BD = creditamount_BD.subtract(maxamount_BD.multiply(new BigDecimal(numberOfPayments-1)));
		
		//when the amount of the parent payment is divided without shortfall to avoid send payment with amount 0
		
		if (shortfall_BD.add(new BigDecimal(EPSILON)).doubleValue() + EPSILON > 0 &&
				shortfall_BD.subtract(new BigDecimal(EPSILON)).doubleValue() < 0 && 
				getNumberOfPayments() > 1){
			numberOfPayments--;
			setShortfallexists(false);

		}
		
		
		return (pdo.getString(P_PMNT_SRC).equals(MopSource) && (maxamount_BD.doubleValue() > 0.0001)  && (creditamount_BD.doubleValue()  > maxamount_BD.doubleValue()) && getNumberOfPayments() < 51/*hard coding saver to avoid performance issues*/);
	}
	
	private void setShortfallexists(boolean sfexists) {
		bshortfallexists = sfexists;
		
	}
	@Override
	public Feedback performMainAction(PDO pdo) throws Throwable {
		Feedback feedback = new Feedback();
	
		if(getSplitPaymet())
		{
			feedback = performMainActionSupportMulti(pdo);
		}
		else{
			feedback = performFormatOutAndTransmissionFlowStep(pdo);
		}
	
		return feedback;
	}
	
	 private void savePDOs(List<PDO> pdos)throws Throwable{
		  logger.debug("saving {} PDOs",pdos.size());
		  List <PDO> linkedPdoList = new ArrayList<PDO>(); 
		  Map<String,Object> relationMap= new HashMap<String,Object>();
		  int iSize = pdos.size();
	      PDO[] arrPDO = pdos.toArray(new PDO[iSize]);
	      PaymentDataFactory.batchSave(false, arrPDO);
	      int size = pdos.size();
	      for(int i=0;i<size;i++){
	    	  pdos.get(i).makeNew();
	    	  relationMap = pdos.get(i).getRelationsMap();
	    	  
	    	  if (relationMap != null && relationMap.size() > 0 ) {
		    	  for (Iterator<Object> it = relationMap.values().iterator(); it.hasNext();) {
				   Object value = it.next();
				   if (value instanceof PDO) {
					   linkedPdoList.add((PDO)value);
				   }
		    	  }
	    	  }
	      }
	      if (linkedPdoList.size() > 0 ) {
	      	CacheKeys.ProcessPDOKey.removeFromLocalAndRemote(linkedPdoList);
	      }
	  }
	/**
	 * 
	 * @param pdo
	 * @return
	 * @throws Throwable
	 */
	 private  Feedback performMainActionSupportMulti(PDO pdo) throws Throwable{
		 Feedback feedback = new Feedback();
		 
		 
		 	List<PDO> pdoList = new ArrayList<PDO>();
		 	String sMidList = "" ;
			if(CreatePdoListForSplit(pdo,pdoList)){
				int i = 0 ;
				//set for the parent which is going to be split
				pdo.set(PDOConstantFieldsInterface.MF_SPLIT_STATUS, MessageConstantsInterface.MONITOR_FLAG_PARENT_SPLIT);
				for (PDO currentpdo : pdoList) {
				 Admin.setContextPDO(currentpdo); 
				 String mdctraceprefix = "SPLIT(" + String.valueOf(i++) + ")";
				 Admin.enrichMDC(mdctraceprefix); //enriching the trace logback
				 performFormatOutAndTransmissionFlowStep(currentpdo); //main core flowstep logic
				 
				 AuditChildCreation(String.valueOf(i),pdoList.size(),currentpdo.getString(PDOConstantFieldsInterface.P_CDT_AMT));
				 
				 addMfamilyRelation(pdo,currentpdo,RELATION_TYPE_PARENT_PAYMENT,RELATION_TYPE_CHILD_PAYMENT);
				 
				 if(sMidList.isEmpty()){
					 sMidList += currentpdo.getMID();
				 }
				 else{
					 sMidList += "," + currentpdo.getMID();
				 }
				 Admin.clearMDC();
				}
			}
			else
			{
				logger.debug("could not split payments to more than 1");
				//then what do i do ???
			}
			
			savePDOs(pdoList);//do i need to worry about caching
			
			
			Admin.setContextPDO(pdo);
			
			AuditSplittingForParent(pdoList.size(),sMidList);
			//need to set the message status to WAIT_CHILD
			pdo.set(P_MSG_STS,MESSAGE_STATUS_WAIT_CHILD);
	    	pdo.set(P_CDT_MOP,MOP_BOOK);
	    	pdo.set(P_DBT_MOP,MOP_BOOK); 
	    	
	//    	logger.debug("X_LCL_INSTRM_CD is " + pdo.getString(X_LCL_INSTRM_CD));
			
			
		 return feedback;
	 }
	private void AuditChildCreation(String nSerialNumber, int size, String sChildAmount) {
		 ProcessError processError = new ProcessError(ProcessErrorConstants.SplitPaymentChild, new Object[] { String.valueOf(nSerialNumber),  String.valueOf(size), sChildAmount });
		 ErrorAuditUtils.setErrors(processError);
	}
	/**
	  * 
	  * @param pdo
	  * @param size
	  * @param sMidList
	  */
	 private void AuditSplittingForParent(int size, String sMidList) {
		 ProcessError processError = new ProcessError(ProcessErrorConstants.SplitPaymentParent, new Object[] { String.valueOf(size), sMidList });
		 ErrorAuditUtils.setErrors(processError);
	}
	/**
	 * @throws Throwable 
	  * 
	  */
	 private boolean CreatePdoListForSplit(PDO pdo,List<PDO> pdolist) throws Throwable{
		 
		   boolean SplitOK = false;
			
			//save in the cache the number of the split payments number 
			
			CacheKeys.SplitChildrenCounterKey.putSingle(new  CacheKeys.SplitChildrenCounterKey.SplitChildrenCounterEntry(getNumberOfPayments(),pdo.getMID()));
			
			
			logger.debug("currently number of children counter is  initilized to be : " + getNumberOfPayments());
			
			for (int i = 0 ; i < getNumberOfPayments()  ; i++)
			{				
				PDO currentPDO = pdo.cloneCurrent();
				
				if (i==0 && isShortfallExists()){
					currentPDO.set(PDOConstantFieldsInterface.P_CDT_AMT,shortfall_BD); 
					currentPDO.set(PDOConstantFieldsInterface.P_DBT_AMT,shortfall_BD); 
					currentPDO.set(PDOConstantFieldsInterface.X_STTLM_AMT,shortfall_BD);
				}
				else{
					currentPDO.set(PDOConstantFieldsInterface.P_CDT_AMT,maxamount_BD); //is it ok ? how can we treat the data loss due to different tpyes ?
					currentPDO.set(PDOConstantFieldsInterface.P_DBT_AMT,maxamount_BD); //is it ok ? how can we treat the data loss due to different tpyes ?
					currentPDO.set(PDOConstantFieldsInterface.X_STTLM_AMT,maxamount_BD);
				}

		   	    currentPDO.set(PDOConstantFieldsInterface.P_TX_CTGY,pdo.getString(PDOConstantFieldsInterface.P_TX_CTGY));//copy transaction category
		   	    currentPDO.set(PDOConstantFieldsInterface.P_BUSINESS_FLOW_TP,pdo.get(PDOConstantFieldsInterface.P_BUSINESS_FLOW_TP)) ;
		   	   
		   	    
		   	   //copy the original pain 001 from the parent to the children to hold the local instrument recieved with the pain 001
		   	    currentPDO.set(PDOConstantFieldsInterface.P_ORIG_MSG_TYPE,pdo.get(PDOConstantFieldsInterface.P_ORIG_MSG_TYPE)) ;
		   	    final XmlObjectBase root = XmlLocationType.XML_ORIG_MSG.getXmlDocument(pdo);
		   	    XmlMetadata data = new XmlMetadata(XmlLocationType.XML_ORIG_MSG, PaymentType.valueOf(PaymentType.PT_PAIN_001),root);
				currentPDO.setXmlMetaData(XmlLocationType.XML_ORIG_MSG.name(), data ) ;
		   
		   	    
		   	    //set a monitor to know that the payment was split 
		   	    currentPDO.set(PDOConstantFieldsInterface.MF_SPLIT_STATUS, MessageConstantsInterface.MONITOR_FLAG_CHILD);
				  
			    currentPDO.set(PDOConstantFieldsInterface.OX_INSTR_ID, pdo.get(PDOConstantFieldsInterface.OX_INSTR_ID));
			    (new InstructionIdGenerationFlowStep()).execute(currentPDO);
			    currentPDO.set(PDOConstantFieldsInterface.X_END_TO_END_ID, pdo.get(PDOConstantFieldsInterface.X_END_TO_END_ID));
			    currentPDO.set(PDOConstantFieldsInterface.P_CREATE_DT, new java.util.Date());
				pdolist.add(currentPDO);
				
				currentPDO.set(D_G3_IMMEDIATE_FLOW_NAME, pdo.get(D_G3_IMMEDIATE_FLOW_NAME));
			}
			if (pdolist.size()> 1 ){
				SplitOK = true;
			}
			return SplitOK;
	 }

/**
 * 
 * @param pdo
 * @return
 * @throws Throwable
 */
	 private Feedback performFormatOutAndTransmissionFlowStep(PDO pdo) throws Throwable{
		 
		 Feedback feedback = new Feedback();
		 
		 feedback = m_messageHandleLogging.formatOutMessage(Admin.getContextAdmin(), pdo.getMID());
			if (feedback.isSuccessful() && G3Util.isOutgoing(pdo)) 
				feedback = BOHighValueProcess.executeTransmission(pdo);
				
		 return feedback;
		}

private void addMfamilyRelation(PDO pdo,PDO relatedPdo,String selfRelatedType, String relatedType){
	        DAOStaticData m_daoStaticData = new DAOStaticData() ;
			MFamilyLineType mFamily = MFamilyLineType.Factory.newInstance();
			mFamily.setFMFAMILYPMID(pdo.getMID());
			mFamily.setFMFAMILYSELFRELATEDTYPE(selfRelatedType);
			mFamily.setFMFAMILYRELATEDMID(relatedPdo.getMID());
			mFamily.setFMFAMILYRELATEDTYPE(relatedType);
			mFamily.setFMFAMILYTIMESTAMP(m_daoStaticData.getFormatedUniqueSysTimeFromDB().getValue());
			mFamily.setFMFAMILYISNEW(true);

			pdo.addMfamily(mFamily);
		}
	 	
		private boolean getSplitPaymet(){
			return dosplitpayments;
		}
		private void setSplitPayment(boolean setSplit){
			dosplitpayments = setSplit;
		}
		
		private int getNumberOfPayments(){
			return numberOfPayments;
		}
		private void setNumberOfPayments(int number){
			this.numberOfPayments = number;
		}
		private boolean isShortfallExists() {
			return bshortfallexists;
		}
}

