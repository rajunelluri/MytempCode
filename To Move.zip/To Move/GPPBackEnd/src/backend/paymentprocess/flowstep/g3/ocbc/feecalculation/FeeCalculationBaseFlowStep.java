package backend.paymentprocess.flowstep.g3.ocbc.feecalculation;

import static backend.businessobject.BOProxies.m_feeCalculationLogging;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;

import backend.paymentprocess.feescalculation.output.FeesCalculationOutputData;
import backend.paymentprocess.flowstep.AbstractFlowStep;

class FeeCalculationBaseFlowStep extends AbstractFlowStep {
	
	private boolean isDummy;

	protected FeeCalculationBaseFlowStep(boolean isDummy){
		this.isDummy = isDummy;
	}

	@Override
	public Feedback performMainAction(PDO pdo) throws Throwable {
		FeesCalculationOutputData feesSelectionOutputData = m_feeCalculationLogging.performFeesCalculation(Admin.getContextAdmin(), pdo.getMID(), isDummy);
		Feedback feedback = feesSelectionOutputData.getFeedback();
		return feedback;
	}

}
