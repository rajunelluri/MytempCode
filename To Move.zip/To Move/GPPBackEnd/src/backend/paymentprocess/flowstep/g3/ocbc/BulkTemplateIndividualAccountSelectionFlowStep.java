package backend.paymentprocess.flowstep.g3.ocbc;

import static backend.businessobject.BOProxies.m_accountDerivationLogging;

import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;

import backend.paymentprocess.commons.MessageUtils;
import backend.paymentprocess.flowstep.AbstractFlowStep;

public class BulkTemplateIndividualAccountSelectionFlowStep extends AbstractFlowStep {

	@Override
	public void performPreAction(PDO pdo) {
		pdo.set(PDOConstantFieldsInterface.D_BULK_TEMP_IND_ACC_INQ_ACK_STS, "FALSE");
		if (MessageUtils.isDirectDebit(pdo))
			new CreditAccountSelectionFlowStep().performPreAction(pdo);
		else 
			new DebitAccountSelectionFlowStep().performPreAction(pdo);
	}

	@Override
	public Feedback performMainAction(PDO pdo) throws Exception {
		Feedback feedback=new Feedback();
		
		feedback = m_accountDerivationLogging.performAccountInquiry(Admin.getContextAdmin(), pdo.getMID());
		
		return feedback;
	}
	
	@Override
	public Feedback performPostAction(PDO pdo,Feedback feedback) {
		if(!feedback.isSuccessful())
		{
			pdo.set(PDOConstantFieldsInterface.D_BULK_TEMP_IND_ACC_INQ_ACK_STS, "TRUE");
			return feedback;
		}
		
		if (MessageUtils.isDirectDebit(pdo))
			return new CreditAccountSelectionFlowStep().performPostAction(pdo,feedback);
		else 
			return new DebitAccountSelectionFlowStep().performPostAction(pdo,feedback);
	}
}
