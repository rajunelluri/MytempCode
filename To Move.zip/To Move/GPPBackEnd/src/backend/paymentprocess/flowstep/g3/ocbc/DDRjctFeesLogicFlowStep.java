package backend.paymentprocess.flowstep.g3.ocbc;

import backend.paymentprocess.flowstep.AbstractFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.feecalculation.CreditFeeCalculationFlowStep;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.datacomponent.response.Feedback;

public class DDRjctFeesLogicFlowStep extends AbstractFlowStep {
	@Override
	public Feedback performMainAction(PDO pdo) throws Throwable {
		Feedback feedback = new Feedback();

		
		CreditFeeCalculationFlowStep creditFeeCalculation = new CreditFeeCalculationFlowStep(); 
		feedback = creditFeeCalculation.execute(pdo);
		
		PostingFlowStep creditFeePosting = new PostingFlowStep(); // FEE_CR & PNL_CR
		feedback = creditFeePosting.execute(pdo);

		return feedback;
	}


}
