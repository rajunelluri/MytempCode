package backend.paymentprocess.flowstep.g3.ocbc;

import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.OX_STTLM_AMT;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_CDT_AMT;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_DBT_AMT;
import backend.businessobject.BOProxies;
import backend.paymentprocess.commons.MessageUtils;
import backend.paymentprocess.commons.MsgClassType;
import backend.paymentprocess.flow.g3.G3Util;
import backend.paymentprocess.flowstep.AbstractFlowStep;
import backend.paymentprocess.mopselection.output.MopSelectionOutputData;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;

public class MOPSelectionFlowStep extends AbstractFlowStep {
	@Override
	public void performPreAction(PDO pdo) {
		if (MessageUtils.isDirectDebit(pdo)){
			pdo.set(PDOConstantFieldsInterface.D_MSG_CLASS_TYPE, MsgClassType.DD);
		}
	}
	
	@Override
	public Feedback performMainAction(PDO pdo) throws Exception {
		MopSelectionOutputData mopSelectionOutputData = BOProxies.m_mopSelectionLogging.performMopSelection(Admin.getContextAdmin(), pdo.getMID());
		Feedback feedback = mopSelectionOutputData.getFeedback();
		return feedback;
	}
	
	@Override
	public Feedback performPostAction(PDO pdo,Feedback feedback) {
		
		if(!feedback.isSuccessful()) return feedback;

		if (G3Util.isCTOutgoing(pdo) && pdo.getCREDIT_ACCOUNT() != null) {
			pdo.set(P_CDT_AMT, pdo.getDecimal(OX_STTLM_AMT));
		}			
		if (G3Util.isDDOutgoing(pdo) && pdo.getDEBIT_ACCOUNT() != null) {
			pdo.set(P_DBT_AMT, pdo.getDecimal(OX_STTLM_AMT));
		}			
		return feedback;
	}
}
