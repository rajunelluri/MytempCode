package backend.paymentprocess.flowstep.g3.ocbc;

import static backend.core.module.MessageConstantsInterface.MESSAGE_STATUS_REJECTED;
import static backend.paymentprocess.SubBatchProcessInterface.STATUS_FILE_REJECTED;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_IN_INTERNAL_FILEID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.paymentprocess.flowstep.AbstractFlowStep;
import backend.paymentprocess.subbatchgeneration.dao.DAOSubBatchGeneration;

import com.fundtech.cache.entities.FileSummary;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.datacomponent.response.Feedback;

public class BulkRejectSubBatchFlowStep extends AbstractFlowStep {
	final static Logger logger = LoggerFactory.getLogger(BulkRejectSubBatchFlowStep.class);
	
	@Override
	public Feedback performMainAction(PDO pdo) throws Throwable {
		return new Feedback();			
	}	
	
	public Feedback performPostAction(PDO pdo,Feedback feedback) {
		logger.info("Due to {}, reject the sub batch and the file",feedback);
		
		pdo.set("D_FILE_ACK_ADDTL_INF","Sub batch failue: "+feedback.getErrorText());
		
		try {
			Feedback postActionFeedback = rejectSubBatchAndFile(pdo);
			
			if (!postActionFeedback.isSuccessful())
				feedback.addErrorText(", additional error on BulkRejectSubBatch is:"+postActionFeedback.getErrorText());
		} catch (Throwable e) {	
			feedback.addErrorText(", additional error on BulkRejectSubBatch is:"+e.getMessage());
		}		
		
		return feedback;
	}
	
	public static Feedback rejectSubBatchAndFile(PDO pdo) {			
		//message status is translated to sub batch specific status by BOHighValueProcess.handleBatchSubsetStatus
		pdo.setStatus(MESSAGE_STATUS_REJECTED); 
		
		//TBD why pdo.getNSetIncomingFileSummary.setStatus doesn't work   
		FileSummary fileSummary = pdo.getNSetIncomingFileSummary();
		String oldStatus = fileSummary.getStatus();
		fileSummary.setStatus(STATUS_FILE_REJECTED);
		Feedback feedback = DAOSubBatchGeneration.getInstance().updateFILE_SUMMARY_Table(
				 pdo.getString(P_IN_INTERNAL_FILEID)
				,STATUS_FILE_REJECTED
				,oldStatus
				,0/*numOfCompletedChunks*/);

		return feedback;
	}
}
