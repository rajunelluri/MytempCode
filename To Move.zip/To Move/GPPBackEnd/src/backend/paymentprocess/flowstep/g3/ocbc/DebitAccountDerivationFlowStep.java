package backend.paymentprocess.flowstep.g3.ocbc;

import static backend.businessobject.BOProxies.m_accountDerivationLogging;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.D_ACCOUNT_DERIVATION_TYPE;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.OX_STTLM_AMT;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_DBT_AMT;
import backend.paymentprocess.accountderivation.common.AccountDerivationConstants.AccountDerivationType;
import backend.paymentprocess.flowstep.AbstractFlowStep;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;

public class DebitAccountDerivationFlowStep extends AbstractFlowStep {
	@Override
	public void performPreAction(PDO pdo) {
		pdo.set(D_ACCOUNT_DERIVATION_TYPE, AccountDerivationType.Debit.toString());
	}

	@Override
	public Feedback performMainAction(PDO pdo) throws Exception {			
		Feedback feedback = m_accountDerivationLogging.performAccountDerivation(Admin.getContextAdmin(), pdo.getMID());			
		return feedback;
	}
	
	@Override
	public Feedback performPostAction(PDO pdo,Feedback feedback) {
		if(!feedback.isSuccessful()) return feedback;
		
		if (pdo.getDEBIT_ACCOUNT() != null){
			pdo.set(P_DBT_AMT, pdo.getDecimal(OX_STTLM_AMT));
		}
		return feedback;
	}
}
