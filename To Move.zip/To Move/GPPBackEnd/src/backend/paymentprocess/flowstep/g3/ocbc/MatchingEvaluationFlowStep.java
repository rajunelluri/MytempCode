package backend.paymentprocess.flowstep.g3.ocbc;

import static backend.core.module.MessageConstantsInterface.MESSAGE_STATUS_CANCELED;
import static backend.core.module.MessageConstantsInterface.MESSAGE_STATUS_COMPLETE;
import static backend.core.module.MessageConstantsInterface.MESSAGE_STATUS_REJECTED;
import static backend.core.module.MessageConstantsInterface.MESSAGE_STATUS_SERVICE_COMPLETE;
import static backend.core.module.MessageConstantsInterface.MONITOR_FLAG_MATCH;
import static backend.core.module.MessageConstantsInterface.RELATION_TYPE_ORIGINAL_PAYMENT;
import static backend.paymentprocess.flow.base.FlowName.G3CancellationFlow;
import static backend.paymentprocess.flow.base.FlowName.G3IncomingReversalFlow;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.D_G3_IMMEDIATE_FLOW_NAME;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.MF_CANCEL_MATCH_STS;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_MSG_STS;
import static com.fundtech.errors.ProcessErrorConstants.MessageStatusChanged;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.paymentprocess.erroraudit.ErrorAuditUtils;
import backend.paymentprocess.flowstep.AbstractFlowStep;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.errorhandling.ProcessError;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.errors.ProcessErrorConstants;

public class MatchingEvaluationFlowStep extends AbstractFlowStep {
	final static Logger logger = LoggerFactory.getLogger(MatchingEvaluationFlowStep.class);
	private final String TRACE_GRACEFUL_TERMINATION_STATUS = "Final graceful termination status for MID {}: {}. ";
	private final String TRACE_INITIATED_REQUEST_HAS_NO_MATCHED_PAYMENT = "The Initiated request has no matched payment !";
	private String sCancellationMatchStatus;
	private String origMsgTerminationStatus;
	
	@Override
	public void performPreAction(PDO pdo) {
		sCancellationMatchStatus = pdo.getString(MF_CANCEL_MATCH_STS);
		if (G3IncomingReversalFlow.equals(pdo.get(D_G3_IMMEDIATE_FLOW_NAME)) ||  G3CancellationFlow.equals(pdo.get(D_G3_IMMEDIATE_FLOW_NAME))){
			origMsgTerminationStatus=MESSAGE_STATUS_CANCELED;
		}
		else
		{
			origMsgTerminationStatus=MESSAGE_STATUS_REJECTED;
		}

	}
	
	@Override
	public Feedback performMainAction(PDO pdo) throws Throwable {
		PDO pdoOriginalPayment = null;
		Feedback feedback = new Feedback();
		String initiatingMsgOldStatus = pdo.getString(P_MSG_STS);		
		String origMsgOldStatus = null;
		
		if (MONITOR_FLAG_MATCH.equals(sCancellationMatchStatus)) {
			pdoOriginalPayment = pdo.getLinkedMsg(RELATION_TYPE_ORIGINAL_PAYMENT);
			origMsgOldStatus = pdoOriginalPayment.getString(P_MSG_STS);
			
			//TODO Need to provide special instructions
			// for if(MESSAGE_STATUS_POST_EXCEPTION.equals(origMsgOldStatus))
			if(!MESSAGE_STATUS_COMPLETE.equals(origMsgOldStatus)){
				//Orig msg status was changed, then we need to set the Cancellation\Reversal msg status,
				//Cancellation\Reversal request (Camt_056\Pacs_007) has found a matched payment - then it goes to SERVICE_COMPLETE
				pdo.set(P_MSG_STS,MESSAGE_STATUS_SERVICE_COMPLETE);
				pdo.getField(P_MSG_STS).setOriginalValue(MESSAGE_STATUS_SERVICE_COMPLETE);
				logger.info(TRACE_GRACEFUL_TERMINATION_STATUS, pdo.getMID(),MESSAGE_STATUS_SERVICE_COMPLETE);
				ErrorAuditUtils.setErrors(new ProcessError(ProcessErrorConstants.MessageStatusChanged, new Object[] { initiatingMsgOldStatus, MESSAGE_STATUS_SERVICE_COMPLETE }),pdo);
			
				//The Orig msg status change
				pdoOriginalPayment.set(P_MSG_STS, origMsgTerminationStatus);
				logger.info(TRACE_GRACEFUL_TERMINATION_STATUS, pdoOriginalPayment.getMID(),origMsgTerminationStatus);
				ErrorAuditUtils.setErrors(new ProcessError(MessageStatusChanged, new Object[] { origMsgOldStatus, origMsgTerminationStatus }),pdoOriginalPayment);
			}
			
		}else{//Cancellation/Reversal request (Camt_056/Pacs_007) has no matched payment 
			logger.info(TRACE_INITIATED_REQUEST_HAS_NO_MATCHED_PAYMENT);
			feedback.setErrorText(TRACE_INITIATED_REQUEST_HAS_NO_MATCHED_PAYMENT);
			feedback.setFailure();
		}
		
		return feedback;
	}
}
