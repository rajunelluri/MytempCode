package backend.paymentprocess.enrichment.ejbinterfaces;

import javax.ejb.Local;

/**
 * Local interface for Enrichment.
 */
@Local
public interface EnrichmentLocal extends Enrichment{} ; 