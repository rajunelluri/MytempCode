package backend.paymentprocess.enrichment.ejbinterfaces;

import javax.ejb.Remote;
import com.fundtech.core.security.Admin;

/**
 * Remote interface for Enrichment.
 */
@Remote
public interface Enrichment{

	public static final String REMOTE_JNDI_NAME="ejb/EnrichmentBean";
	
	
	public com.fundtech.datacomponent.response.Feedback repairAndEnrich(final Admin admin ) throws java.lang.Exception ;
	
	public com.fundtech.datacomponent.response.Feedback enrichParty(final Admin admin ) throws java.lang.Exception ;
	
	public com.fundtech.datacomponent.response.Feedback derivePartyIdentifier(final Admin admin, boolean isCredit ) throws java.lang.Exception ;
	
	public com.fundtech.datacomponent.response.Feedback cleanExistingMessageParties(final Admin admin) throws java.lang.Exception ;
	
}//EOI  