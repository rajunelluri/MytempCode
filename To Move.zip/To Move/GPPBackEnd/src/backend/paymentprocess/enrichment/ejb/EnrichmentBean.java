package backend.paymentprocess.enrichment.ejb;

import javax.ejb.Stateless;
import backend.core.SuperSLSB;
import com.fundtech.core.security.Admin;
import backend.businessobject.proxies.interceptors.InterceptorSetType;
import backend.paymentprocess.enrichment.businessobjects.BOEnrichment;
import backend.paymentprocess.enrichment.ejbinterfaces.EnrichmentLocal;
import backend.paymentprocess.enrichment.ejbinterfaces.Enrichment;

@Stateless
public class EnrichmentBean extends SuperSLSB<Enrichment> implements EnrichmentLocal, Enrichment{
	
	public EnrichmentBean() { super(backend.paymentprocess.enrichment.businessobjects.BOEnrichment.class, InterceptorSetType.Complete) ; }//EOM
	
	
	public com.fundtech.datacomponent.response.Feedback repairAndEnrich(final Admin admin ) throws java.lang.Exception {
		return this.m_bo.repairAndEnrich(admin ) ;
	}//EOM

	public com.fundtech.datacomponent.response.Feedback enrichParty(final Admin admin ) throws java.lang.Exception {
		return this.m_bo.enrichParty(admin ) ;
	}//EOM

	public com.fundtech.datacomponent.response.Feedback derivePartyIdentifier(final Admin admin, boolean isCredit ) throws java.lang.Exception {
		return this.m_bo.derivePartyIdentifier(admin, isCredit ) ;
	}//EOM

	public com.fundtech.datacomponent.response.Feedback cleanExistingMessageParties(final Admin admin ) throws java.lang.Exception {
		return this.m_bo.cleanExistingMessageParties(admin) ;
	}//EOM

}//EOC