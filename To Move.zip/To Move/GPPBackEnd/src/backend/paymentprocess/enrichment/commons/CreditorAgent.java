package backend.paymentprocess.enrichment.commons;

//Field 57
public class CreditorAgent extends Role {

	public CreditorAgent() {
		
  	 super();
	 this.bicFieldId = "X_CDTR_AGT_BIC_2AND";
	 this.ibanFieldId ="X_CDTR_AGT_ACCT_IBAN";
	 this.accountNumberFieldId ="X_CDTR_AGT_ACCT_ID";
	 this.nccMemberIdFieldId = "X_CDTR_AGT_ID_2AND";
	 this.nccCodeFieldId = "X_CDTR_AGT_CLR_SYS_CD";	 
	 this.nccProprietaryFieldId = "X_CDTR_AGT_CLR_SYS_PRTRY";
	 this.nameFieldId = "X_CDTR_AGT_NM_2AND";
	 this.addressFieldId = "X_CDTR_AGT_ADRLINE_2AND";
	 this.postalCodeFieldId = "X_CDTR_AGT_PSTCD";
	 this.cityFieldId = "X_CDTR_AGT_CITY";
	 this.stateFieldId = "X_CDTR_AGT_CTRY_SUB_DIV";
	 this.countryFieldId ="X_CDTR_AGT_CTRY_2AND";
	}

}
