package backend.paymentprocess.enrichment.commons;

//Field 54
public class InstructedRmbAgent extends Role {

	public InstructedRmbAgent() {
		
		super();
		this.bicFieldId = "X_INSTD_RMB_AGT_BIC_2AND";
		this.ibanFieldId = "X_INSTD_RMB_AGT_ACCT_IBAN";
		this.accountNumberFieldId ="X_INSTD_RMB_AGT_ACCT_ID_2AND";
		this.nccMemberIdFieldId = "X_INSTD_RMB_AGT_ID_2AND";
		this.nccCodeFieldId = "X_INSTD_RMB_AGT_CLR_SYS_CD";				 	
		this.nccProprietaryFieldId = "X_INSTD_RMB_AGT_CLR_SYS_PRTRY";
	}

}
