package backend.paymentprocess.enrichment.commons;

public class InitiatingParty extends Role {
	
	public InitiatingParty() {
		
	 super();
	 this.custCodeId = "X_INITG_PTY_ID";
	 this.nameFieldId = "X_INITG_PTY_NM";
	 this.addressFieldId = "X_INITG_PTY_ADRLINE";
	 this.postalCodeFieldId = "X_INITG_PTY_PSTCD";
	 this.cityFieldId = "X_INITG_PTY_CITY";
	 this.stateFieldId = "X_INITG_PTY_CTRY_SUB_DIV";
	 this.countryFieldId = "X_INITG_PTY_CTRY";
	 
	}

}
