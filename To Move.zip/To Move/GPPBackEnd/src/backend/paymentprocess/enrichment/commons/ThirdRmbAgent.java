package backend.paymentprocess.enrichment.commons;

//Field 55
public class ThirdRmbAgent extends Role {

	public ThirdRmbAgent() {

		super();
		this.bicFieldId = "X_THRD_RMB_AGT_BIC_2AND";
		this.ibanFieldId = "X_THRD_RMB_AGT_ACCT_IBAN";
		this.accountNumberFieldId ="X_THRD_RMB_AGT_ACCT_ID_2AND";
		this.nccMemberIdFieldId = "X_THRD_RMB_AGT_ID_2AND";
		this.nccCodeFieldId = "X_THRD_RMB_AGT_CLR_SYS_CD";				 	
		this.nccProprietaryFieldId = "X_THRD_RMB_AGT_CLR_SYS_PRTRY";
		
	}

}
