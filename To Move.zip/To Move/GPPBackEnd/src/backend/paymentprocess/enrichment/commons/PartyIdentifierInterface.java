package backend.paymentprocess.enrichment.commons;


public interface PartyIdentifierInterface {
		
	
		public String getCustCode();
		public void setCustCode(String custCode);
		public String getIBAN();	
		public void setIBAN(String iban);		
		public String getBIC();		
		public void setBIC(String bic);		
		public String getNCCCode();		
		public void setNCCCode(String nccCode);		
		public String getNCCMemberID();		
		public void setNCCMemberID(String nccMemberID);		
		public String getNCCProprietaryValue();		
		public void setNCCProprietaryValue(String nccProprietaryValue);		
		public String getAccountNumber();		
		public void setAccountNumber(String accountNumber);		
		public String getOffice();		
		public void setOffice(String office);		
		public String getInstructionCurrency();		
		public void setInstructionCurrency(String instructionCurrency);
		public boolean isFirstInChainAndHasIbanOrAccNo();
		public void setIsFirstInChainAndHasIbanOrAccNo(boolean isFirstInChainAndHasIbanOrAccNo);
		public String getPartyId();
		public void setPartyId(String partyId);
		public PartyIdType getPartyIdType();
		public void setPartyIdType(PartyIdType partyIdType);		
				
		public boolean isEmpty();
	}	

