package backend.paymentprocess.enrichment.commons;

//Field 53
public class InstructingRmbAgent extends Role {

	public InstructingRmbAgent() {

		 super();
		 this.bicFieldId = "X_INSTG_RMB_AGT_BIC_2AND";
		 this.ibanFieldId = "X_INSTG_RMB_AGT_ACCT_IBAN";
		 this.accountNumberFieldId ="X_INSTG_RMB_AGT_ACCT_ID_2AND";
		 this.nccMemberIdFieldId = "X_INSTG_RMB_AGT_ID_2AND";
		 this.nccCodeFieldId = "X_INSTG_RMB_AGT_CLR_SYS_CD";				 	
		 this.nccProprietaryFieldId = "X_INSTG_RMB_AGT_CLR_SYS_PRTRY";		
	}

}
