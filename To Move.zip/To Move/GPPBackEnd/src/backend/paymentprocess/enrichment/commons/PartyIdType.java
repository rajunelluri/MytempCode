package backend.paymentprocess.enrichment.commons;

public enum PartyIdType {
	SA, USABA, CU;
	
	
	private final static String ABA = "FW";
	private final static String BIC = "BIC";
	private final static String CC = "CU";
	
	
	public static String getPartyTypeFromFilterType(String filterType){
		String partyType = null;
		if (filterType.contains(BIC)) {
			partyType  = PartyIdType.SA.name();
		}
		else if (filterType.contains(ABA)) {
			partyType  = PartyIdType.USABA.name();
		}
		else {
			if (filterType.contains(CC)) {
				partyType  = PartyIdType.CU.name();
			}
		}
		return partyType;
	}
}
