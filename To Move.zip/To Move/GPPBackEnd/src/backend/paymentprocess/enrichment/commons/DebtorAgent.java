package backend.paymentprocess.enrichment.commons;

//Field 52
public class DebtorAgent extends Role {	
	
	
	public DebtorAgent(){
		
	 super();
	 this.bicFieldId = "X_DBTR_AGT_BIC_2AND";
	 this.ibanFieldId = "X_DBTR_AGT_ACCT_IBAN";
	 this.accountNumberFieldId ="X_DBTR_AGT_ACCT_ID";
	 this.nccMemberIdFieldId = "X_DBTR_AGT_ID_2AND";
	 this.nccCodeFieldId = "X_DBTR_AGT_CLR_SYS_CD";	
	 this.nccProprietaryFieldId = "X_DBTR_AGT_CLR_SYS_PRTRY";
	 this.nameFieldId = "X_DBTR_AGT_ACCT_NM";
	 this.addressFieldId = "X_DBTR_AGT_ADRLINE_2AND";
	 this.postalCodeFieldId = "X_DBTR_AGT_PSTCD";
	 this.cityFieldId = "X_DBTR_AGT_CITY";
	 this.stateFieldId = "X_DBTR_AGT_CTRY_SUB_DIV";
	 this.countryFieldId ="X_DBTR_AGT_CTRY_2AND";
		
	}
	
}
