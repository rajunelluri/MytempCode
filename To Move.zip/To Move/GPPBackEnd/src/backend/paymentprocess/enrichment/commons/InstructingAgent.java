package backend.paymentprocess.enrichment.commons;

//Sender
public class InstructingAgent extends Role {
	
	public InstructingAgent() {
		
	 super();
	 this.bicFieldId = "X_INSTG_AGT_BIC_2AND";
	 this.nccMemberIdFieldId = "X_INSTG_AGT_ID_2AND";		
	 this.nccCodeFieldId = "X_INSTG_AGT_CLR_SYS_CD";
	 this.nccProprietaryFieldId = "X_INSTG_AGT_CLR_SYS_PRTRY";
	 this.nameFieldId = "X_INSTG_AGT_NM_2AND";
	 this.addressFieldId = "X_INSTG_AGT_ADRLINE_2AND";
	 this.countryFieldId = "X_INSTG_AGT_CTRY_2AND";
	}

}
