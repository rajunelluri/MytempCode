package backend.paymentprocess.enrichment.commons;

public class NotificationCreditAccountOwner extends Role {

	public NotificationCreditAccountOwner() {
		super();
		this.custCodeId = "P_CDT_CUST_CD";	
	}

}
