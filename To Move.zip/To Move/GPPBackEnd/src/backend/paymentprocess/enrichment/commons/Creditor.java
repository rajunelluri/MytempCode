package backend.paymentprocess.enrichment.commons;

//Field 58/59
public class Creditor extends Role {

	public Creditor() {

		super();
		this.bicFieldId = "X_CDTR_BIC";
		this.ibanFieldId = "X_CDTR_ACCT_IBAN";
		this.accountNumberFieldId ="X_CDTR_ACCT_ID";
		this.nccMemberIdFieldId = "X_CDTR_ID";
		this.nccCodeFieldId = "X_CDTR_CLR_SYS_CD";				 	
		this.nccProprietaryFieldId = "X_CDTR_CLR_SYS_PRTRY";	
	}

}
