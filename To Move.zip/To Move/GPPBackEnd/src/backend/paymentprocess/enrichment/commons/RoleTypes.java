package backend.paymentprocess.enrichment.commons;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public enum RoleTypes {

	DBTR_AGT {
		public RoleInterface getRoleInterface() {
			return new DebtorAgent();
		}

		public String[] getInverseRole() {
			return new String[] { CDTR.name(), CDTR_AGT.name() };
		}
	},
	DBTR {
		public RoleInterface getRoleInterface() {
			return new Debtor();
		}

		public String[] getInverseRole() {
			return null;
		}
	},
	CDTR_AGT {
		public RoleInterface getRoleInterface() {
			return new CreditorAgent();
		}

		public String[] getInverseRole() {
			return new String[] { DBTR_AGT.name() };
		}
	},
	INRMY_AGT {
		public RoleInterface getRoleInterface() {
			return new IntermediaryAgent();
		}

		public String[] getInverseRole() {
			return new String[] { INSTG_RMB_AGT.name(), INSTD_RMB_AGT.name(), THRD_RMB_AGT.name() };
		}
	},
	SENDER {
		public RoleInterface getRoleInterface() {
			return new InstructingAgent();
		}

		public String[] getInverseRole() {
			return new String[] { RECEIVER.name() };
		}
	},
	RECEIVER {
		public RoleInterface getRoleInterface() {
			return new InstructedAgent();
		}

		public String[] getInverseRole() {
			return new String[] { SENDER.name() };
		}
	},
	INITG_PTY {
		public RoleInterface getRoleInterface() {
			return new InitiatingParty();
		}

		public String[] getInverseRole() {
			return null;
		}
	},
	INSTG_RMB_AGT {
		public RoleInterface getRoleInterface() {
			return new InstructingRmbAgent();
		}

		public String[] getInverseRole() {
			return new String[] { INRMY_AGT.name() };
		}
	},
	INSTD_RMB_AGT {
		public RoleInterface getRoleInterface() {
			return new InstructedRmbAgent();
		}

		public String[] getInverseRole() {
			return new String[] { INRMY_AGT.name() };
		}
	},
	THRD_RMB_AGT {
		public RoleInterface getRoleInterface() {
			return new ThirdRmbAgent();
		}

		public String[] getInverseRole() {
			return new String[] { INRMY_AGT.name() };
		}
	},
	CDTR {
		public RoleInterface getRoleInterface() {
			return new Creditor();
		}

		public String[] getInverseRole() {
			return new String[] { DBTR_AGT.name() };
		}
	},
	PNG_CTRPTY {//this is not a 'Classic' role but a derived one
		public RoleInterface getRoleInterface() {
			return null;
		}

		public String[] getInverseRole() {
			return new String[] { RCVG_CTRPTY.name() };
		}
	},
	RCVG_CTRPTY {//this is not a 'Classic' role but a derived one
		public RoleInterface getRoleInterface() {
			return null;
		}

		public String[] getInverseRole() {
			return new String[] { PNG_CTRPTY.name() };
		}
	}, NTF_ACCT_OWNR { /*what about credit/debit?*/

		public RoleInterface getRoleInterface() {
			return new NotificationCreditAccountOwner();
		}
		
		public String[] getInverseRole() {
			return null;
		}
		
	};

	public abstract RoleInterface getRoleInterface();

	public abstract String[] getInverseRole();

	public static RoleTypes[] getCreditRoleTypes() {
		return new RoleTypes[] { RECEIVER, CDTR, CDTR_AGT, INRMY_AGT,NTF_ACCT_OWNR };
	}

	public static RoleTypes[] getDebitRoleTypes() {
		return new RoleTypes[] { SENDER, DBTR_AGT, INSTG_RMB_AGT, INSTD_RMB_AGT, THRD_RMB_AGT };
	}
	/*
	 * gets an array of roles and returns the inverse roles for net deduction
	  */
	public static String[] inverseRoles (String[] originalRoles){

		Set<String> inverseRoles = new HashSet<String>();

		for (String originalRole : originalRoles){
			RoleTypes role = RoleTypes.valueOf(originalRole);
			inverseRoles.addAll(Arrays.asList(role.getInverseRole()));
		}

		return inverseRoles.toArray(new String[0]);
	}
}
