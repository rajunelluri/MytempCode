package backend.paymentprocess.enrichment.commons;

import com.fundtech.util.GlobalConstants;

public enum InterfaceSubTypeFlow {
	OWD{
		@Override
		public String getFlowType(){return GlobalConstants.BP;};
	},
	IWD{
		@Override
		public String getFlowType(){return GlobalConstants.BP;};
	},
	ORD{
		@Override
		public String getFlowType(){return GlobalConstants.BP;};
	},
	IRD{
		@Override
		public String getFlowType(){return GlobalConstants.BP;};
	},
	OWF{
		@Override
		public String getFlowType(){return GlobalConstants.BP;};
	},
	ORF{
		@Override
		public String getFlowType(){return GlobalConstants.BP;};
	},
	BPFILE{
		@Override
		public String getFlowType(){return GlobalConstants.BP;};
	},
	RTF{
		@Override
		public String getFlowType(){return GlobalConstants.RT;};
	};
	
	public abstract String getFlowType();
	
	public static String getFlowType(String subType){
		try{
			InterfaceSubTypeFlow interfaceSubType= InterfaceSubTypeFlow.valueOf(subType);
			return interfaceSubType.getFlowType();
		}catch(Exception e)
		{
			return GlobalConstants.RT;
		}
	}
}
