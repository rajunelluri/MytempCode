package backend.paymentprocess.enrichment.commons;

import static com.fundtech.util.GlobalConstants.DEFAULT_SERVER_OFFICE_NAME;
import static com.fundtech.util.GlobalUtils.isListNullOrEmpty;
import static com.fundtech.util.GlobalUtils.isNullOrEmpty;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.businessobject.BOProxies;
import backend.paymentprocess.accountderivation.businessobjects.BOAccountDerivation;
import backend.paymentprocess.paymentservices.common.IBANMethod;
import backend.paymentprocess.paymentservices.common.IBANStatus;
import backend.paymentprocess.paymentservices.exception.PaymentServicesException;
import backend.paymentprocess.paymentservices.input.IBANInputData;
import backend.paymentprocess.paymentservices.output.IBANOutputData;

import com.fundtech.cache.entities.Accounts;
import com.fundtech.cache.entities.CountryNcc;
import com.fundtech.cache.entities.Customrs;
import com.fundtech.cache.entities.Ncc;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.security.Admin;

public class LoadCustomer {

	private static final Logger logger = LoggerFactory.getLogger(LoadCustomer.class);

	
	public LoadCustomer() {

	
	}

	public static String getPartyCustCode(PartyIdentifierInterface partyIdentifier) {
		String custCode = null;
		if (StringUtils.isNotEmpty(partyIdentifier.getCustCode())) {
			custCode = partyIdentifier.getCustCode();
		} else if (StringUtils.isNotEmpty(partyIdentifier.getIBAN())) {
			String accountNumber = getAccountNumberFromIBAN(partyIdentifier.getIBAN(), partyIdentifier.getOffice());
			if (StringUtils.isNotEmpty(accountNumber)) {
				Customrs customer = getCustomerUsingAccount(accountNumber, partyIdentifier.getInstructionCurrency(), partyIdentifier.getOffice());
				custCode = (customer != null) ? customer.getCustCode() : null;
			}
			if (custCode == null && StringUtils.isNotEmpty(partyIdentifier.getBIC())) {
				custCode = getCustomerUsingBIC(partyIdentifier.getBIC(), partyIdentifier.getOffice());
			}
		} else if (StringUtils.isNotEmpty(partyIdentifier.getAccountNumber())) {
			Customrs customer = getCustomerUsingAccount(partyIdentifier.getAccountNumber(), partyIdentifier.getInstructionCurrency(),
					partyIdentifier.getOffice());
			custCode = (customer != null) ? customer.getCustCode() : null;
			if (custCode == null && StringUtils.isNotEmpty(partyIdentifier.getBIC())) {
				custCode = getCustomerUsingBIC(partyIdentifier.getBIC(), partyIdentifier.getOffice());
			}
			//IDLM-12.Additional check for QC # 13387 to Load the customer by NCC if it's a complex one.
			if (StringUtils.isEmpty(custCode) && StringUtils.isNotEmpty(partyIdentifier.getNCCMemberID())) {
				custCode = getCustomerUsingNCC(partyIdentifier.getNCCCode(), partyIdentifier.getNCCProprietaryValue(), partyIdentifier.getNCCMemberID(),
						partyIdentifier.getOffice());
			}
		} else if (StringUtils.isNotEmpty(partyIdentifier.getNCCMemberID())) {
			custCode = getCustomerUsingNCC(partyIdentifier.getNCCCode(), partyIdentifier.getNCCProprietaryValue(), partyIdentifier.getNCCMemberID(),
					partyIdentifier.getOffice());
		} else if (StringUtils.isNotEmpty(partyIdentifier.getBIC())) {
			custCode = getCustomerUsingBIC(partyIdentifier.getBIC(), partyIdentifier.getOffice());
		}
		return custCode;
	}

	private static String getAccountNumberFromIBAN(String iban, String office) {
		logger.debug("Getting account from IBAN: " + iban);
		IBANOutputData ibanOutputData = performIBANValidationAndDeconstruction(iban, office);
		IBANStatus ibanStatus = ibanOutputData.getStatus();

		String account = null;

		if (ibanStatus == IBANStatus.Valid) {

			// Gets the account number from the passed IBAN
			account = ibanOutputData.getAccountNumber();
			logger.debug("Valid IBAN. account: " + account);
		} else if (ibanStatus == IBANStatus.NonIBAN) {
			// Non IBAN; the "passed IBAN" actually stands for an account number.
			// Since this is non IBAN, tries to load the account using the value,
			// which actually stands for an account number.
			account = iban;
			logger.debug("Non IBAN. account: " + account);
		} else {
			logger.debug("Not IBAN");
		}

		return account;
	}

	private static IBANOutputData performIBANValidationAndDeconstruction(String iban, String office) {
		IBANInputData ibanInputData = new IBANInputData();
		ibanInputData.setPotentialIban(iban);
		ibanInputData.setMethod(IBANMethod.ValidationAndDeconstruction);
		ibanInputData.setOffice(office);
		IBANOutputData ibanOutputData = new IBANOutputData();
		try {
			ibanOutputData = BOProxies.m_paymentServicesLogging.performIBANHandling(Admin.getContextAdmin(), ibanInputData);
		} catch (PaymentServicesException e) {
			logger.error("Error while trying to deconsturct iban: " + e.getMessage());
			ibanOutputData.setStatus(IBANStatus.NonIBAN);
		}

		return ibanOutputData;
	}

	private static Customrs getCustomerUsingAccount(String accountNumber, String currency, String office) {

		Accounts account = null;

		// STEP 1 -
		// Tries to load the account using the account number, office & currency.
		logger.debug(String.format("Trying to get Account[%s], Cur[%s], Office[%s] from cache", accountNumber, currency, office));
		account = CacheKeys.accountsKey.getSingle(accountNumber, currency, office);
		//
		// No specific account entry was found; tries to load the account using the account
		// number & the office.
		if (account == null) {
			logger.debug("Account was not found. Trying to get account without using the currency");
			List<Accounts> listAccounts = CacheKeys.accountsAllCurrenciesKey.get(accountNumber, office);

			// Uses the account in index 0.
			if (!isListNullOrEmpty(listAccounts)) {
				account = listAccounts.get(0);
				logger.debug("Account was found in cache");
			}
		} else {
			logger.debug("Account was found in cache");
		}

		// In case:
		// 1) No account was found yet
		// AND 2) We're in debit side
		// AND 3) The source of the account number is either field 53, ('Instructing Reimbursement Agent') or field 54, ('Instructed Reimbursement
		// Agent')
		// , then tries to get the account using the account alias for updating the related
		if (account == null) {
			account = BOAccountDerivation.getAccountUsingAccAlias(accountNumber, office, currency, null);

			// Tries getting the account without using the currency.
			if (account == null) {
				account = BOAccountDerivation.getAccountUsingAccAlias(accountNumber, office, null, null);
			}
		}

		if (account != null) {
			logger.debug(String.format("Trying to load the Customer using CustCode[%s], Office[%s]", account.getCustCode(), account.getOffice()));
			Customrs customer = CacheKeys.customrsKey.getSingle(account.getCustCode(), account.getOffice());
			if (customer != null) {
				logger.debug("Customer was found");
				return customer;
			}
			logger.debug("Customer was not found");

		}

		return null;
	}

	private static String getCustomerUsingBIC(String bic, String office) {

		Customrs customer = null;

		// Tries to load the customer record using the BIC or the ABA and the payment office.
		// NOTE: when 'bUseABACache' is true, then 'sFirstInChainBIC' holds actually an ABA value.
		logger.debug(String.format("Trying to load the Customer using bic[%s], Office[%s]", bic, office));
		customer = CacheKeys.customrsBICandOfficeKey.getSingle(bic, office);

		// Failed loading the customer record; tries to load it using the BIC/ABA and the '***' office.
		if (customer == null && !DEFAULT_SERVER_OFFICE_NAME.equals(office)) {
			logger.debug(String.format("Trying to load the Customer using bic[%s], Office[%s]", bic, DEFAULT_SERVER_OFFICE_NAME));
			customer = CacheKeys.customrsBICandOfficeKey.getSingle(bic, DEFAULT_SERVER_OFFICE_NAME);
		}

		// Failed loading the customer record and the BIC ISN'T an ABA.
		// In case the BIC length is smaller then 8, no need to continue.
		if (customer == null && bic.length() >= 8) {
			String extendedBIC = bic.substring(0, 8) + "XXX";

			// Tries loading the customer using the recieved BIC + 'xxx' suffix against the payment office.
			logger.debug(String.format("Trying to load the Customer using bic[%s], Office[%s]", extendedBIC, office));
			customer = CacheKeys.customrsBICandOfficeKey.getSingle(extendedBIC, office);

			// Tries loading the customer using the recieved BIC + 'xxx' suffix against the default '***' office.
			if (customer == null && !DEFAULT_SERVER_OFFICE_NAME.equals(office)) {
				logger.debug(String.format("Trying to load the Customer using bic[%s], Office[%s]", extendedBIC, DEFAULT_SERVER_OFFICE_NAME));
				customer = CacheKeys.customrsBICandOfficeKey.getSingle(extendedBIC, DEFAULT_SERVER_OFFICE_NAME);
			}
		}

		if (customer != null && StringUtils.isNotEmpty(customer.getCustCode())) {
			logger.debug("Customer was found: " + customer.getCustCode());
		}

		return customer != null ? customer.getCustCode() : null;
	}

	private static String getCustomerUsingNCC(String nccCodeID, String nccProprietaryID, String nccMemberID, String office) {

		// If we have empty NCC code and empty NCC proprietary, then tries and get related values using the NCC member ID.
		if (isNullOrEmpty(nccCodeID) && isNullOrEmpty(nccProprietaryID)) {

			logger.debug(String.format("Trying to get NCC records using NCC member ID '%s' and payment office %s.", nccMemberID, office));
			List<Ncc> listNcc = CacheKeys.nccOfficeNccCodeKey.get(null, office, nccMemberID);

			// No NCC record(s) were found under the payment office; tries under the default office.
			if (isListNullOrEmpty(listNcc)) {
				logger.debug(String.format("Trying to get NCC records using NCC member ID '%s' and '***' deafult office.", nccMemberID));
				listNcc = CacheKeys.nccOfficeNccCodeKey.get(null, DEFAULT_SERVER_OFFICE_NAME, nccMemberID);
			}
			// Found NCC record(s).
			if (!isListNullOrEmpty(listNcc)) {
				int iSize = listNcc.size();

				if (iSize == 1) {
					Ncc ncc = listNcc.get(0);
					return ncc.getCustCode();
					// More then one NCC record
				} else {
					logger.debug(String.format("Customer cannot be found. Multiple records for NCC member ID: %s", nccMemberID));
					return null;
				}
				// No NCC records.
			} else {
				logger.debug(String.format("Customer cannot be found. Invalid NCC member ID: %s", nccMemberID));
				return null;
			}
		} else {

			String nccID = StringUtils.isNotEmpty(nccCodeID) ? nccCodeID : nccProprietaryID;

			// Gets the CountryNcc object for the passed clearing system ID code.
			logger.debug("Trying to load the COuntryNCC using NCC ID: " + nccID);
			CountryNcc countryNcc = CacheKeys.countryNccClrsysCodeKey.getSingle(nccID);

			// COUNTRY_NCC entry was found.
			if (countryNcc != null) {
				logger.debug("CountryNCC was found");
				// Length comparison.
				logger.debug(String.format("CountryNCC max length[%s], min length[%s], NCC MemberId Length[%d]", countryNcc.getNccLengthMax(), countryNcc.getNccLengthMin(), nccMemberID.length()));

				// Success.
				if (countryNcc.isValidNCCLength(nccMemberID.length())) { 

					// 2nd parameter: NCC.NCC_TYPE_ISO - compared against 'nccCodeID'.
					// 3rd parameter: NCC.NCC_CODE - compared against 'nccMemberID'.
					logger.debug(String.format("Trying to load the NCC using Office[%s], NCC ID[%s], nccMemberId[%s]", office, nccID, nccMemberID));
					Ncc ncc = CacheKeys.nccKey.getSingle(office, nccID, nccMemberID);

					// Failure; tries getting the NCC entry using the '***' office.
					if (ncc == null && !DEFAULT_SERVER_OFFICE_NAME.equals(office)) {
						logger.debug(String.format("Trying to load the NCC using Office[%s], NCC ID[%s], nccMemberId[%s]",
								DEFAULT_SERVER_OFFICE_NAME, nccID, nccMemberID));
						ncc = CacheKeys.nccKey.getSingle(DEFAULT_SERVER_OFFICE_NAME, nccID, nccMemberID);
					}

					// Valid NCC entry.
					if (ncc != null) {
						logger.debug(String.format("NCC was found. Trying to load the customer using cust code[%s]", ncc.getCustCode()));
						Customrs customrs = CacheKeys.customrsCCKey.getSingle(ncc.getCustCode());
						if (customrs != null) {
							logger.debug("Customer was found");
							return ncc.getCustCode();
						}
					}
				}
			}
			logger.debug("Customer was not found");
			return null;
		}
	}

	// =================================Party Enrichment GLM implementation===================================

	public static void setPartyId(PartyIdentifierInterface partyIdentifier) {

		String BIC_FOUND_MESSAGE = "BIC was found for party. BIC value is {}.";
		String ABA_FOUND_MESSAGE = "BIC was Not found for party. will use ABA instead:  {}.";
		String CUST_CODE_NO_BIC_FOUND_MESSAGE = "BIC was Not found for party. will use cust code instead:  {}.";
		String CUST_CODE_NO_ABA_FOUND_MESSAGE = "ABA was Not found for party. will use cust code instead:  {}.";
		String CUST_WAS_FOUND = "customer was found in GPP.";

		String partyId = null;
		PartyIdType partyIdType = null;

		String bic = null, aba = null, custCode = null;
		String localOffice = partyIdentifier.getOffice();

		// trying to find BIC
		bic = partyIdentifier.getBIC();
		Customrs customer = CacheKeys.customrsBICandOfficeKey.getSingle(bic, DEFAULT_SERVER_OFFICE_NAME);
		if (!isNullOrEmpty(bic) && customer != null) {
			logger.info(CUST_WAS_FOUND);
			logger.info(BIC_FOUND_MESSAGE, bic);
			partyId = bic;
			partyIdType = PartyIdType.SA;

		} else { // no success with finding BIC directly, try with NCC
			logger.info("BIC was NOT found for party. trying to find party id using NCC...");

			String nccCode = partyIdentifier.getNCCMemberID();
			String nccTypeCode = partyIdentifier.getNCCCode();
			String nccTypePrtry = partyIdentifier.getNCCProprietaryValue();
			String nccType = isNullOrEmpty(nccTypeCode) ? nccTypePrtry : nccTypeCode;

			Ncc ncc = CacheKeys.nccKey.getSingle(DEFAULT_SERVER_OFFICE_NAME, nccType, nccCode);
			if (ncc != null) {// found NCC
				logger.info("NCC was found valid. ncc code is : {}", nccCode);

				if (PartyIdType.USABA.name().equals(ncc.getNccTypeIso())) {// NCC type is USABA
					logger.info("NCC ISO type is 'USABA'");
					customer = CacheKeys.customrsABAandOfficeKey.getSingle(nccCode, DEFAULT_SERVER_OFFICE_NAME);

					if (customer != null) {
						logger.info(CUST_WAS_FOUND);
						bic = customer.getSwiftId();
						if (!isNullOrEmpty(bic)) {// trying to find BIC through NCC
							logger.info(BIC_FOUND_MESSAGE, bic);
							partyId = bic;
							partyIdType = PartyIdType.SA;

						} else {// BIC not found. use ABA instead
							aba = customer.getAba();
							logger.info(ABA_FOUND_MESSAGE, aba);
							partyId = aba;
							partyIdType = PartyIdType.USABA;
						}
					}

				} else {// NCC type is NOT USABA
					logger.info("NCC type is NOT 'USABA' . it is {}", ncc.getNccTypeIso());
					custCode = ncc.getCustCode();
					customer = CacheKeys.customrsCCKey.getSingle(custCode);

					if (customer != null) {
						logger.info(CUST_WAS_FOUND);
						bic = customer.getSwiftId();
						if (!isNullOrEmpty(bic)) {// trying to find BIC through NCC
							logger.info(BIC_FOUND_MESSAGE, bic);
							partyId = bic;
							partyIdType = PartyIdType.SA;
						} else {// BIC not found. use customer code instead
							logger.info(CUST_CODE_NO_BIC_FOUND_MESSAGE, custCode);
							partyId = custCode;
							partyIdType = PartyIdType.CU;
						}
					}
				}
			}
			if (isNullOrEmpty(partyId)) {// no success with NCC. if is it is first in chain party (debit or credit), will try to use IBAN and account
											// number
				logger.info("found no valid NCC. trying to find party id using IBAN and account number  ...");

				if (partyIdentifier.isFirstInChainAndHasIbanOrAccNo()) {
					logger.info("party is first in chain");

					String iban = partyIdentifier.getIBAN();
					String accountNumber;
					if (!isNullOrEmpty(iban)) {
						logger.info("trying to derive account number from IBAN : {}, with office : {}.", new String[] { iban, localOffice });

						accountNumber = getAccountNumberFromIBAN(iban, localOffice);
					} else {
						logger.info("IBAN is empty. fetching account number directly...");
						accountNumber = partyIdentifier.getAccountNumber();
					}
					if (!isNullOrEmpty(accountNumber)) {
						logger.info("account number was found : {}", accountNumber);

						customer = getCustomerUsingAccount(accountNumber, partyIdentifier.getInstructionCurrency(), localOffice);
						if (customer != null) {
							logger.info(CUST_WAS_FOUND);

							bic = customer.getSwiftId();
							if (!isNullOrEmpty(bic)) {// BIC was found
								logger.info(BIC_FOUND_MESSAGE, bic);
								partyId = bic;
								partyIdType = PartyIdType.SA;

							} else {
								aba = customer.getAba();
								if (!isNullOrEmpty(aba)) {// ABA was found
									logger.info(ABA_FOUND_MESSAGE, aba);
									partyId = aba;
									partyIdType = PartyIdType.USABA;

								} else {// Customer code will be used as default
									custCode = customer.getCustCode();
									logger.info(CUST_CODE_NO_ABA_FOUND_MESSAGE, custCode);
									partyId = custCode;
									partyIdType = PartyIdType.CU;
								}
							}
						}
					}
				} else if (!isNullOrEmpty(partyIdentifier.getCustCode())) {					
					customer = CacheKeys.customrsCCKey.getSingle(partyIdentifier.getCustCode());
					if (customer != null) {
						logger.info(CUST_WAS_FOUND+" using the party identifier custcode {}",partyIdentifier.getCustCode());						
						if (!isNullOrEmpty(customer.getSwiftId())) {
							logger.info(BIC_FOUND_MESSAGE, customer.getSwiftId());
							partyId = customer.getSwiftId();
							partyIdType = PartyIdType.SA;

						} else  if (!isNullOrEmpty(customer.getAba())) {// BIC not found. use ABA instead
							logger.info(ABA_FOUND_MESSAGE, customer.getAba());
							partyId = customer.getAba();
							partyIdType = PartyIdType.USABA;
						} else {// Customer code will be used as default							
							logger.info(CUST_CODE_NO_ABA_FOUND_MESSAGE, partyIdentifier.getCustCode());
							partyId = partyIdentifier.getCustCode();
							partyIdType = PartyIdType.CU;
						}
					}

				} else {				
					logger.info("party is not first in chain or has no IBAN and no account number");
				}
			}
		}
		// set data
		partyIdentifier.setPartyId(partyId);
		partyIdentifier.setPartyIdType(partyIdType);
		if (!isNullOrEmpty(partyId))
			logger.info("finished party ID enrichment. party id found : {} . party id type : {}.", new String[] { partyId, partyIdType.name() });
		else
			logger.info("no party enrichment details was found for this party");
	}

}
