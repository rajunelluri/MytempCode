package backend.paymentprocess.enrichment.commons;

import com.fundtech.cache.entities.Customrs;
import com.fundtech.core.paymentprocess.data.PDO;

public interface RoleInterface {
	
	/**
	 * gets the fields identifying a customer in order to load a customer
	 * @param pdo - the object from which the customer attributes are taken
	 * @return PartyIdentifierInterface - an object holding the data
	 */
	public PartyIdentifierInterface getPartyIdentifier(PDO pdo);
	
	/**
	 * enriches the PDO object with the customers BIC details
	 * @param customer - the object from which the BIC details are taken
	 * @param pdo - the object to enrich
	 */
	public void enrichBIC(Customrs customer,PDO pdo);
	
	/**
	 * enriches the PDO object with the customers name and address related details
	 * @param customer - the object from which the name and address details are taken
	 * @param pdo - the object to enrich
	 */
	public void enrichNameAndAddress(Customrs customer,PDO pdo);
	
	
	public String getBicFieldId();
	public String getIbanFieldId();
	public String getCustCodeId();
	public String getAccountNumberFieldId();
	public String getNccCodeFieldId();
	public String getNccMemberIdFieldId();
	public String getNccProprietaryFieldIdD();
	public String getNameFieldId();
	public String getAddressFieldId();
	public String getPostalCodeFieldId();
	public String getCityFieldId();
	public String getStateFieldId();
	public String getCountryFieldId();
	
	
}
