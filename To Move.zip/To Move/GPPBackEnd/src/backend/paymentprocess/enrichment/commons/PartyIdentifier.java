package backend.paymentprocess.enrichment.commons;

import static com.fundtech.util.GlobalConstants.CLOSING_SQUARE_BRACKET;
import static com.fundtech.util.GlobalConstants.COMMA_SPACE;
import static com.fundtech.util.GlobalConstants.OPENING_SQUARE_BRACKET;
import static com.fundtech.util.GlobalUtils.isNullOrEmpty;

import com.fundtech.util.GlobalConstants;

public class PartyIdentifier implements PartyIdentifierInterface {

	private String office;
	private String IBAN;
	private String BIC;
	private String custCode;
	private String NCCCode;
	private String NCCMemberID;
	private String NCCProprietaryValue;
	private String instructionCurrency;
	private String accountNumber;

	private boolean isFirstInChainAndHasIbanOrAccNo;

	private String partyId;
	private PartyIdType partyIdType;

	

	public PartyIdentifier() {
		// Default constructor
	};

	@Override
	public String getAccountNumber() {
		return this.accountNumber;
	}

	@Override
	public String getBIC() {
		return this.BIC;
	}

	@Override
	public String getCustCode() {
		return this.custCode;
	}

	public void setCustCode(String custCode) {
		this.custCode = custCode;
	}

	@Override
	public String getIBAN() {
		return this.IBAN;
	}

	@Override
	public String getInstructionCurrency() {
		return this.instructionCurrency;
	}

	@Override
	public String getNCCCode() {
		return this.NCCCode;
	}

	@Override
	public String getNCCMemberID() {
		return this.NCCMemberID;
	}

	@Override
	public String getNCCProprietaryValue() {
		return this.NCCProprietaryValue;
	}

	@Override
	public String getOffice() {
		return this.office;
	}

	public boolean isFirstInChainAndHasIbanOrAccNo() {
		return isFirstInChainAndHasIbanOrAccNo;
	}

	public String getPartyId() {
		return partyId;
	}

	public PartyIdType getPartyIdType() {
		return partyIdType;
	}

	@Override
	public boolean isEmpty() {
		return isNullOrEmpty(getBIC()) && isNullOrEmpty(getIBAN()) && isNullOrEmpty(getNCCCode()) && isNullOrEmpty(getNCCMemberID())
				&& isNullOrEmpty(getNCCProprietaryValue()) && isNullOrEmpty(getAccountNumber()) && isNullOrEmpty(getCustCode());
	}

	@Override
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	@Override
	public void setBIC(String bic) {
		this.BIC = bic;
	}

	@Override
	public void setIBAN(String iban) {
		this.IBAN = iban;

	}

	@Override
	public void setInstructionCurrency(String instructionCurrency) {
		this.instructionCurrency = instructionCurrency;
	}

	@Override
	public void setNCCCode(String nccCode) {
		this.NCCCode = nccCode;
	}

	@Override
	public void setNCCMemberID(String nccMemberID) {
		this.NCCMemberID = nccMemberID;
	}

	@Override
	public void setNCCProprietaryValue(String nccProprietaryValue) {
		this.NCCProprietaryValue = nccProprietaryValue;
	}

	@Override
	public void setOffice(String office) {
		this.office = office;
	}

	public void setIsFirstInChainAndHasIbanOrAccNo(boolean isFirstInChainAndHasIbanOrAccNo) {
		this.isFirstInChainAndHasIbanOrAccNo = isFirstInChainAndHasIbanOrAccNo;
	}

	public void setPartyId(String partyId) {
		this.partyId = partyId;
	}

	public void setPartyIdType(PartyIdType partyIdType) {
		this.partyIdType = partyIdType;
	}

	public String toString() {

		StringBuilder partyIdentifierData = new StringBuilder();
		partyIdentifierData.append(GlobalConstants.OPENING_CURLY_BRACKET);
		partyIdentifierData.append("office: ").append(OPENING_SQUARE_BRACKET).append(this.getOffice()).append(CLOSING_SQUARE_BRACKET);
		partyIdentifierData.append(COMMA_SPACE).append("Instruction currency: ").append(OPENING_SQUARE_BRACKET).append(this.getInstructionCurrency())
				.append(CLOSING_SQUARE_BRACKET);
		if (!isNullOrEmpty(this.getBIC()))
			partyIdentifierData.append(COMMA_SPACE).append("BIC: ").append(OPENING_SQUARE_BRACKET).append(this.getBIC())
					.append(CLOSING_SQUARE_BRACKET);
		if (!isNullOrEmpty(this.getCustCode()))
			partyIdentifierData.append(COMMA_SPACE).append("Customer Code: ").append(OPENING_SQUARE_BRACKET).append(this.getCustCode());
		if (!isNullOrEmpty(this.getIBAN()))
			partyIdentifierData.append(COMMA_SPACE).append("IBAN: ").append(OPENING_SQUARE_BRACKET).append(this.getIBAN())
					.append(CLOSING_SQUARE_BRACKET);
		if (!isNullOrEmpty(this.getAccountNumber()))
			partyIdentifierData.append(COMMA_SPACE).append("Account number: ").append(OPENING_SQUARE_BRACKET).append(this.getAccountNumber())
					.append(CLOSING_SQUARE_BRACKET);
		if (!isNullOrEmpty(this.getNCCCode()))
			partyIdentifierData.append(COMMA_SPACE).append("NCC Code: ").append(OPENING_SQUARE_BRACKET).append(this.getNCCCode())
					.append(CLOSING_SQUARE_BRACKET);
		if (!isNullOrEmpty(this.getNCCProprietaryValue()))
			partyIdentifierData.append(COMMA_SPACE).append("NCC Proprietary value: ").append(OPENING_SQUARE_BRACKET)
					.append(this.getNCCProprietaryValue()).append(CLOSING_SQUARE_BRACKET);
		if (!isNullOrEmpty(this.getNCCMemberID()))
			partyIdentifierData.append(COMMA_SPACE).append("NCC Member ID: ").append(OPENING_SQUARE_BRACKET).append(this.getNCCMemberID());
		if (isFirstInChainAndHasIbanOrAccNo)
			partyIdentifierData.append(" this party is first in chain and has an IBAN" + " or account number");
		partyIdentifierData.append(GlobalConstants.CLOSING_CURLY_BRACKET);

		return partyIdentifierData.toString();
	}
}