package backend.paymentprocess.enrichment.commons;

//field 56
public class IntermediaryAgent extends Role {

	public IntermediaryAgent() {
		
	 super();
	 this.bicFieldId = "X_INTRMY_AGT1_BIC_2AND";
	 this.ibanFieldId = "X_INTRMY_AGT1_ACCT_IBAN";
	 this.accountNumberFieldId ="X_INTRMY_AGT1_ACCT_ID";
	 this.nccMemberIdFieldId = "X_INTRMY_AGT1_ID_2AND";
	 this.nccCodeFieldId = "X_INTRMY_AGT1_CLR_SYS_CD";	 
	 this.nccProprietaryFieldId = "X_INTRMY_AGT1_CLR_SYS_PRTRY";
	 this.nameFieldId = "X_INTRMY_AGT1_ACCT_NM";
	 this.addressFieldId = "X_INTRMY_AGT1_ADRLINE_2AND";
	 this.postalCodeFieldId = "X_INTRMY_AGT1_PSTCD";
	 this.cityFieldId = "X_INTRMY_AGT1_CITY";
	 this.stateFieldId = "X_INTRMY_AGT1_CTRY_SUB_DIV";
	 this.countryFieldId = "X_INTRMY_AGT1_CTRY_2AND";
	 
	}

}
