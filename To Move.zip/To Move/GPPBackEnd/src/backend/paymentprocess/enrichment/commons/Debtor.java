package backend.paymentprocess.enrichment.commons;


public class Debtor extends Role {

	public Debtor() {
		
     super();
	 this.bicFieldId = "X_DBTR_BIC";
	 this.ibanFieldId = "X_DBTR_ACCT_IBAN";
	 this.accountNumberFieldId ="X_DBTR_ACCT_ID";
	 this.nccCodeFieldId = "X_DBTR_CLR_SYS_CD";
	 this.nccMemberIdFieldId = "X_DBTR_ID_2AND";
	 this.nccProprietaryFieldId = "X_DBTR_CLR_SYS_PRTRY";
	 this.nameFieldId = "X_DBTR_NM";
	 this.addressFieldId = "X_DBTR_ADRLINE";
	 this.postalCodeFieldId = "X_DBTR_PSTCD";
	 this.cityFieldId = "X_DBTR_CITY";
	 this.stateFieldId = "X_DBTR_CTRY_SUB_DIV";
	 this.countryFieldId ="X_DBTR_CTRY";
	}
		
}
