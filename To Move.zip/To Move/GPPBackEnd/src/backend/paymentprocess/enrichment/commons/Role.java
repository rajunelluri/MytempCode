package backend.paymentprocess.enrichment.commons;

import static com.fundtech.util.GlobalUtils.isNullOrEmpty;

import com.fundtech.cache.entities.Customrs;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;

public abstract class Role implements RoleInterface {

	@Override
	public void enrichBIC(Customrs customer, PDO pdo) {

		setFieldToPDO(getBicFieldId(), customer.getSwiftId(), pdo);
	}

	@Override
	public void enrichNameAndAddress(Customrs customer, PDO pdo) {

		setFieldToPDO(getNameFieldId(), customer.getCustName(), pdo);

		String addressFieldId = getAddressFieldId();
		if (!isNullOrEmpty(addressFieldId)) {
			pdo.deleteAllOccurrences(addressFieldId);
			int i = 0;
			if (!isNullOrEmpty(customer.getAddress1()))
				pdo.set(customer.getAddress1(), addressFieldId, i++);
			if (!isNullOrEmpty(customer.getAddress2()))
				pdo.set(customer.getAddress2(), addressFieldId, i++);
			if (!isNullOrEmpty(customer.getAddress3()))
				pdo.set(customer.getAddress3(), addressFieldId, i++);
			if (!isNullOrEmpty(customer.getAddress4()))
				pdo.set(customer.getAddress4(), addressFieldId, i++);
		}

		setFieldToPDO(getPostalCodeFieldId(), customer.getZip(), pdo);
		setFieldToPDO(getCityFieldId(), customer.getCity(), pdo);
		setFieldToPDO(getStateFieldId(), customer.getState(), pdo);
		setFieldToPDO(getCountryFieldId(), customer.getCountrycode(), pdo);

	}

	@Override
	public PartyIdentifierInterface getPartyIdentifier(PDO pdo) {

		PartyIdentifier partyIdentifier = new PartyIdentifier();
		partyIdentifier.setBIC(pdo.getString(getBicFieldId()));
		partyIdentifier.setCustCode(pdo.getString(getCustCodeId()));
		partyIdentifier.setNCCCode(pdo.getString(getNccCodeFieldId()));
		partyIdentifier.setNCCMemberID(pdo.getString(getNccMemberIdFieldId()));
		partyIdentifier.setNCCProprietaryValue(pdo.getString(getNccProprietaryFieldIdD()));
		partyIdentifier.setIBAN(pdo.getString(getIbanFieldId()));
		partyIdentifier.setAccountNumber(pdo.getString(getAccountNumberFieldId()));
		partyIdentifier.setOffice(pdo.getString(PDOConstantFieldsInterface.P_OFFICE));
		partyIdentifier.setInstructionCurrency(pdo.getString(PDOConstantFieldsInterface.X_STTLM_CCY));
		partyIdentifier.setIsFirstInChainAndHasIbanOrAccNo(isFirstInChainAndHasIbanOrAccNo(pdo));

		return partyIdentifier;
	}

	protected String bicFieldId;
	protected String custCodeId;
	protected String ibanFieldId;
	protected String accountNumberFieldId;
	protected String nccCodeFieldId;
	protected String nccMemberIdFieldId;
	protected String nccProprietaryFieldId;
	protected String nameFieldId;
	protected String addressFieldId;
	protected String postalCodeFieldId;
	protected String cityFieldId;
	protected String stateFieldId;
	protected String countryFieldId;

	public String getBicFieldId() {
		return this.bicFieldId;
	}

	public String getCustCodeId() {
		return this.custCodeId;
	}

	public String getIbanFieldId() {
		return this.ibanFieldId;
	}

	public String getAccountNumberFieldId() {
		return this.accountNumberFieldId;
	}

	public String getNccCodeFieldId() {
		return this.nccCodeFieldId;
	}

	public String getNccMemberIdFieldId() {
		return this.nccMemberIdFieldId;
	}

	public String getNccProprietaryFieldIdD() {
		return this.nccProprietaryFieldId;
	}

	public String getNameFieldId() {
		return this.nameFieldId;
	}

	public String getAddressFieldId() {
		return this.addressFieldId;
	}

	public String getPostalCodeFieldId() {
		return this.postalCodeFieldId;
	}

	public String getCityFieldId() {
		return this.cityFieldId;
	}

	public String getStateFieldId() {
		return this.stateFieldId;
	}

	public String getCountryFieldId() {
		return this.countryFieldId;
	}

	private <T> void setFieldToPDO(String fieldId, T value, PDO pdo) {
		if (!isNullOrEmpty(fieldId))
			pdo.set(fieldId, value);
	}

	/*
	 * this logic is needed for party Enrichment with IBAN or Account number. only parties which are 1st in
	 * credit or debit chain are allowed to be enriched with IBAN or Account Number.
	 */
	private boolean isFirstInChainAndHasIbanOrAccNo(PDO pdo) {
		
		String cdtChainIbanFieldId =  pdo.getString(PDOConstantFieldsInterface.D_1ST_IN_CDT_CHA_IBAN_FLD_ID);
		String cdtChainAccNoFieldId =  pdo.getString(PDOConstantFieldsInterface.D_1ST_IN_CDT_CHA_ACCNUM_FLD_ID);
		String dbtChainIbanFieldId =  pdo.getString(PDOConstantFieldsInterface.D_1ST_IN_DBT_CHA_IBAN_FLD_ID);
		String dbtChainAccNoFieldId =  pdo.getString(PDOConstantFieldsInterface.D_1ST_IN_DBT_CHA_ACCNUM_FLD_ID);
		
		boolean isMatchingCdtIban, isMatchingCdtAccNo,isMatchingDbtIban, isMatchingDbtAccNo;
		
		isMatchingCdtIban = !isNullOrEmpty(this.getIbanFieldId()) ? this.getIbanFieldId().equals(cdtChainIbanFieldId): false;
		isMatchingCdtAccNo = !isNullOrEmpty(this.getAccountNumberFieldId()) ? this.getAccountNumberFieldId().equals(cdtChainAccNoFieldId): false;
		isMatchingDbtIban = !isNullOrEmpty(this.getIbanFieldId()) ? this.getIbanFieldId().equals(dbtChainIbanFieldId): false;
		isMatchingDbtAccNo = !isNullOrEmpty(this.getAccountNumberFieldId()) ? this.getAccountNumberFieldId().equals(dbtChainAccNoFieldId): false;
		
		boolean isFirstInChainAndHasIbanOrAccNo = isMatchingCdtIban || isMatchingCdtAccNo || isMatchingDbtIban || isMatchingDbtAccNo;
		
		return isFirstInChainAndHasIbanOrAccNo;
	}

}
