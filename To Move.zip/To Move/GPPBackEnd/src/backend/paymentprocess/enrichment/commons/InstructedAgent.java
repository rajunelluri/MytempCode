package backend.paymentprocess.enrichment.commons;

//Receiver
public class InstructedAgent extends Role {

	public InstructedAgent() {
		
 	 super();
	 this.bicFieldId = "X_INSTD_AGT_BIC_2AND";
	 this.nccMemberIdFieldId = "X_INSTD_AGT_ID_2AND";
	 this.nccCodeFieldId = "X_INSTD_AGT_CLR_SYS_CD";	 
	 this.nccProprietaryFieldId = "X_INSTD_AGT_CLR_SYS_PRTRY";
	 this.nameFieldId = "X_INSTD_AGT_NM_2AND";
	 this.addressFieldId = "X_INSTD_AGT_ADRLINE_2AND";
	 this.countryFieldId = "X_INSTD_AGT_CTRY_2AND";
	}

}
