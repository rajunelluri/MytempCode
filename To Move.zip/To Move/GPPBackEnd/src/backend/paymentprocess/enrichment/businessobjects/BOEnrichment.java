package backend.paymentprocess.enrichment.businessobjects;

import static backend.businessobject.BOProxies.m_messageHandleLogging;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.businessobject.BOBasic;
import backend.businessobject.BOProxies;
import backend.core.module.MessageConstantsInterface;
import backend.paymentprocess.dao.CachedPDOMembersLoader;
import backend.paymentprocess.enrichment.commons.LoadCustomer;
import backend.paymentprocess.enrichment.commons.PartyIdType;
import backend.paymentprocess.enrichment.commons.PartyIdentifierInterface;
import backend.paymentprocess.enrichment.commons.RoleInterface;
import backend.paymentprocess.enrichment.commons.RoleTypes;
import backend.paymentprocess.erroraudit.ErrorAuditUtils;
import backend.util.ServerConstants;

import com.fundtech.annotations.Expose;
import com.fundtech.annotations.Wrap;
import com.fundtech.cache.entities.Customrs;
import com.fundtech.cache.entities.Mop;
import com.fundtech.cache.entities.MsgParties;
import com.fundtech.cache.entities.MsgPartiesId;
import com.fundtech.cache.entities.RuleResult;
import com.fundtech.cache.entities.RuleResults;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_MSG_TYPE; 
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.core.paymentprocess.findfirstinchain.FindFirstInChainConstants.ChainType;
import com.fundtech.core.paymentprocess.findfirstinchain.MessageChainsData.ChainData;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.datacomponent.response.SimpleResponseDataComponent;
import com.fundtech.errors.ProcessErrorConstants;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalUtils;


@Wrap

public class BOEnrichment extends BOBasic implements MessageConstantsInterface, PDOConstantFieldsInterface {

	private static final Logger logger = LoggerFactory.getLogger(BOEnrichment.class);


	private static String ENRICH_BIC_LIST = "BIC";
	//private static String ENRICH_NAME_AND_ADDRESS_LIST = "NameAndAddress";

	public BOEnrichment() {
		super();		
	}

	@Expose
	public Feedback repairAndEnrich() throws Exception {

		Admin admin = Admin.getContextAdmin();
		PDO pdo = Admin.getContextPDO();
		Feedback feedback;

		feedback = ((SimpleResponseDataComponent) m_messageHandleLogging.manipulateMessageData(admin,
				pdo.getMID(), new String[] { pdo.getString(P_OFFICE), ServerConstants.DEFAULT_SERVER_OFFICE_NAME })).getFeedback();

		if (feedback.isSuccessful()) {
			// repair and enrichment should be execute once.
			pdo.set(MF_REPAIR_N_ENRICHEMENT_STS,MessageConstantsInterface.MONITOR_FLAG_PROCESSED);
			//if the mop was set by the manipulation Rules it should be mapped to the PDO.m_debitMop
			//if it wasn't, there is no harm to copy it here in order for both to be the same.
			pdo.setDEBIT_MOP(CachedPDOMembersLoader.loadDebitMop(pdo));
			// enrich party service
			feedback = this.enrichParty();
		}

		return feedback;

	}

	@Expose
	public Feedback enrichParty() throws Exception {

		final String MESSAGE_PARTY_START_ENRICH = "BOEnrichment.enrichParty(): Trying to enrich role type: %s for MID: %s";
		final String MESSAGE_PARTY_IDENTIFIER_EMPTY = "BOEnrichment.enrichParty(): PartyIdentifier for role type [%s] is empty";
		final String MESSAGE_PARTY_COULD_NOT_BE_LOADED = "BOEnrichment.enrichParty():Got null custCode from loadCustomer service for the given partyIdentifier: %s";
		final String MESSAGE_COULD_NOT_LOAD_CUSTOMER_ENTITY = "BOEnrichment.enrichParty():Customer entity returned null for custCode: [%s], office: [%s]";
		final String MESSAGE_PARTY_SUCCESS_ENRICH = "BOEnrichment.enrichParty(): Party [%s] was enriched successfully with [%s] Fields";
		final String MESSAGE_PARTY_LOADED_FOR_DEF_OFFICE = "BOEnrichment.enrichParty(): Loading Party [%s] from def_office [%s]";

		Feedback feedback = new Feedback();
		PDO pdo = Admin.getContextPDO();
		String office = pdo.getString(P_OFFICE);
		String enrichPartyMonitorValue = MONITOR_FLAG_X;

		RuleResults ruleResults = BOProxies.m_internalRuleExecutionLogging.executeRule(Admin.getContextAdmin(),
				RULE_TYPE_ID_PARTY_DETAILS_ENRICHMENT, null, pdo.getMID(), new String[] { office,
			GlobalConstants.DEFAULT_SERVER_OFFICE_NAME });

		for (RuleResult ruleResult : ruleResults.getResults()) {
			PartyIdentifierInterface partyIdentifier;
			String roleType;
			RoleInterface party;
			Customrs customer;
			String custCode;
			String fieldsToEnrich;

			roleType = ruleResult.getAction();
			party = RoleTypes.valueOf(roleType).getRoleInterface();

			logger.info(String.format(MESSAGE_PARTY_START_ENRICH, roleType, pdo.getMID()));

			//Retrieve the relevant fields from PDO in order to load the relevant Customer
			partyIdentifier = party.getPartyIdentifier(pdo);

			if (!partyIdentifier.isEmpty()) {
				//Load customer
				custCode = LoadCustomer.getPartyCustCode(partyIdentifier);
				if (!GlobalUtils.isNullOrEmpty(custCode)) {
					fieldsToEnrich = ruleResult.getSecAction();
					customer = CacheKeys.customrsKey.getSingle(custCode, office);
					if(customer==null)
					{
						String defOffice = CacheKeys.SystParKey.getSingleParmValue(GlobalConstants.DEF_OFFICE);
						customer = CacheKeys.customrsKey.getSingle(custCode,defOffice);
						logger.info(String.format(MESSAGE_PARTY_LOADED_FOR_DEF_OFFICE, custCode,defOffice));
					}
					// Enrich with the relevant details according to the list chosen (BIC/Name and Address)
					if (customer != null) {
						if (fieldsToEnrich.equals(ENRICH_BIC_LIST)) {
							party.enrichBIC(customer, pdo);
						} else {
							party.enrichNameAndAddress(customer, pdo);
						}
						//Update the monitor. 'Failure' should not be overridden
						enrichPartyMonitorValue = (enrichPartyMonitorValue.equals(MONITOR_FLAG_FAILURE)) ? 
								enrichPartyMonitorValue	: MONITOR_FLAG_SUCCESS;
						logger.info(String.format(MESSAGE_PARTY_SUCCESS_ENRICH, roleType, fieldsToEnrich));
					} else {						
						logger.info(String.format(MESSAGE_COULD_NOT_LOAD_CUSTOMER_ENTITY, custCode, office));						
					}
				} else {
					logger.info(String.format(MESSAGE_PARTY_COULD_NOT_BE_LOADED,
							partyIdentifier.toString()));
					ErrorAuditUtils.setError(ProcessErrorConstants.loadCustomerFailed, pdo.getMID(), pdo.getIsHistory(), null,
							roleType);
					//Setting monitor to 'Failure' if one of the customers could not be loaded
					enrichPartyMonitorValue = MONITOR_FLAG_FAILURE;

				}
			} else {
				logger.info(String.format(MESSAGE_PARTY_IDENTIFIER_EMPTY, roleType));
			}
		}
		pdo.set(MF_ENRICH_PARTY, enrichPartyMonitorValue);
		return feedback;
	}

	@Expose
	public Feedback derivePartyIdentifier(boolean isCredit) {

		Feedback feedback = new Feedback();

		String partyId = null, partyIdType = null;

		PartyIdentifierInterface partyData;
		PDO pdo = Admin.getContextPDO();

		pdo.setMsgPartiesWasCalc(true);

		RoleTypes[] roleTypes = isCredit ? RoleTypes.getCreditRoleTypes() : RoleTypes.getDebitRoleTypes();
		logger.info("deriving party identifiers for {} side roles ", isCredit ? "credit" : "debit" );

		String existingMsgParty = (null==pdo.getListMSG_PARTIES())? "No previous MSG_PARTIES exist." : pdo.getListMSG_PARTIES().toString();
		logger.debug("pdo HashCode:{}   Existing MSG_PARTIES: [{}]", System.identityHashCode(pdo), existingMsgParty );


		for (RoleTypes role : roleTypes){

			// Special case NTF_ACCT_OWNR only for MT210
			if (role.equals(RoleTypes.NTF_ACCT_OWNR) &&	!MESSAGE_TYPE_SWIFT_210.equals(pdo.getString(P_MSG_TYPE))) {
				continue;
			}

			//get relevant data to derive partyIdentifier
			partyData = role.getRoleInterface().getPartyIdentifier(pdo);
			logger.info("trying to derive party identifier for role type: {}", role.name() );
			//derive party identifier
			LoadCustomer.setPartyId(partyData);

			partyId = partyData.getPartyId();
			partyIdType = partyData.getPartyIdType() == null ? null : partyData.getPartyIdType().name();			

			if (partyId != null){//party id was derived for this party - add it to list

				MsgPartiesId id = new MsgPartiesId(pdo.getMID(), role.name());
				MsgParties msgParty  = new MsgParties(id, pdo.getString(P_OFFICE), partyId, partyIdType);				
				pdo.addListMSG_PARTIES(msgParty);

				if(role.equals(RoleTypes.RECEIVER)){
					pdo.set(D_RECEIVER_PARTY_ID, partyId);
					pdo.set(D_RECEIVER_PARTY_ID_TYPE, partyIdType);
				}
			}
		}

		//special case for Receiver role
		if (isCredit && pdo.get(D_RECEIVER_PARTY_ID) == null) {
			findReceiver(pdo);
			String partyIdReceiver = pdo.getString(D_RECEIVER_PARTY_ID);
			String partyIdTypeReceiver = pdo.getString(D_RECEIVER_PARTY_ID_TYPE);

			if (partyIdReceiver != null) {

				MsgPartiesId id = new MsgPartiesId(pdo.getMID(), RoleTypes.RECEIVER.name());
				MsgParties msgParty = new MsgParties(id, pdo.getString(P_OFFICE), partyIdReceiver, partyIdTypeReceiver);
				pdo.addListMSG_PARTIES(msgParty);
			}
		}

		//counterparty derivation
		if (isCredit) {
			deriveReceivingCounterparty(pdo.getMID());
		} else
			derivePayingCounterparty(pdo.getMID());
		//EO counterparty derivation
		return feedback;
	}

	@Expose
	public void cleanExistingMessageParties(){

		PDO pdo = Admin.getContextPDO();
		pdo.setListMSG_PARTIES(null);
	}

	public void deriveReceivingCounterparty(String mid) {

		PDO pdo = PaymentDataFactory.load(mid);
		String partyId = null, partyIdType = null;		

		logger.info("deriving Receiving Counterparty...");

		if (pdo.get(D_RECEIVER_PARTY_ID) == null) {
			findReceiver(pdo);
		}
		partyId = pdo.getString(D_RECEIVER_PARTY_ID);		
		partyIdType = pdo.getString(D_RECEIVER_PARTY_ID_TYPE);		

		// initializing Receiving Counterparty
		pdo.set(D_RCVG_CTRPTY_ID, partyId);
		pdo.set(D_RCVG_CTRPTY_ID_TYPE, partyIdType);

		if (!GlobalUtils.isNullOrEmpty(partyId)) {
			logger.info("Receiving Counterparty id is [{}] of type {}", partyId, partyIdType);
		} else
			logger.info("No receiving Counterparty was found");
	}

	public void derivePayingCounterparty(String mid) {

		PDO pdo = PaymentDataFactory.load(mid);
		String partyId = null, partyIdType = null;
		String dbtrAgtPartyId = null, dbtrAgtPartyIdType = null, senderPartyId = null, senderAgtPartyIdType = null;
		List<MsgParties> msgParties = pdo.getListMSG_PARTIES();

		logger.info("deriving Paying Counterparty...");
		if (msgParties != null){
			for (MsgParties msgPartyEntry : msgParties) {

				if (msgPartyEntry.getPartyRole().equals(RoleTypes.DBTR_AGT.name())) {
					dbtrAgtPartyId = msgPartyEntry.getPartyId();
					dbtrAgtPartyIdType = msgPartyEntry.getPartyIdType();

				} else if (msgPartyEntry.getPartyRole().equals(RoleTypes.SENDER.name())) {
					senderPartyId = msgPartyEntry.getPartyId();
					senderAgtPartyIdType = msgPartyEntry.getPartyIdType();
				}
			}
		}

		if (!GlobalUtils.isNullOrEmpty(dbtrAgtPartyId)) {

			logger.info("Debtor agent party was found and it shall be the paying counterparty");
			partyId = dbtrAgtPartyId;
			partyIdType = dbtrAgtPartyIdType;

		} else {

			Mop debitMop = CacheKeys.mopKey.getSingle(pdo.getString(P_OFFICE),
					pdo.getString(P_DBT_MOP));

			if (!GlobalUtils.isNullOrEmpty(senderPartyId) && !senderPartyId.equals(debitMop.getMopbicaddress())) {

				logger.info("Sender party was found and it shall be the paying counterparty");
				partyId = senderPartyId;
				partyIdType = senderAgtPartyIdType;
			}
		}
		// initializing Paying Counterparty derived fields
		pdo.set(D_PNG_CTRPTY_ID, partyId);
		pdo.set(D_PNG_CTRPTY_ID_TYPE, partyIdType);

		if (!GlobalUtils.isNullOrEmpty(partyId)) {
			logger.info("Paying Counterparty id is [{}] of type {}", partyId, partyIdType);
		} else
			logger.info("No paying Counterparty was found");
	}

	//please note that this function initializes 2 derived fields. if value not found it sets their value to "0"
	private void findReceiver(PDO pdo) {

		String partyId = null, partyIdType = null;

		if (pdo.getCreditChainsData(false) == null) {
			logger.info("credit chain data is missing, can not find receiver");
			return;
		}

		logger.info("Trying to locate receiver role...");

		List<MsgParties> msgParties = pdo.getListMSG_PARTIES();
		Customrs creditCustomer = pdo.getCREDIT_CUSTOMER();
		if (msgParties != null && creditCustomer != null) { // assuming that First in credit chain was derived 

			String custCode = creditCustomer.getCustCode();
			logger.info("First in credit chain customer code is [{}]", custCode);

			int iChainIndex = pdo.getInteger(D_CHAIN_INDEX);
			ChainData chainData = pdo.getCreditChainsData().getSpecificChainData(iChainIndex);

			if (chainData == null) {
				logger.info("credit chain data is missing, can not find receiver");
				return;
			}

			Mop creditMop = CacheKeys.mopKey.getSingle(pdo.getString(P_OFFICE),
					pdo.getString(P_CDT_MOP));

			ChainType type = chainData.getChainType();
			logger.info("credit chain type is of type [{}]", type.name());
			
			// QC NAGE 22819 [NAGE 19] - 
			// Temporary. TODO: Need to consider a case the P_CORRESPONDENT is NOT BIC. Need to write cleaner

			if (ChainType.Correspondent.equals(type)) {
				
				String correspondentBic = pdo.getString(P_CORRESPONDENT);
				
				if (!correspondentBic.equals(creditMop.getMopbicaddress())) {// only if BIC not equal MOPBICAddress for credit Mop

					logger.debug("Setting the correspondent bic {} as the RECEIVER for MSG_PARTIES ", correspondentBic);
					pdo.set(D_RECEIVER_PARTY_ID, correspondentBic);
					pdo.set(D_RECEIVER_PARTY_ID_TYPE, PartyIdType.SA.name());
				} 
			} 
			
			else if (!(type.equals(ChainType.Creditor) && pdo.getNSetOffice().getCustCode().equals(custCode))) { // if chain type is creditor
																												 //and is not the local bank
				RoleTypes roleType = roleConversionUtility(type);
				for (MsgParties msgPartyEntry : msgParties) {

					if (roleType != null && msgPartyEntry.getPartyRole().equals(roleType.name())) {

						if (!GlobalUtils.isNullOrEmpty(msgPartyEntry.getPartyId())
								&& !msgPartyEntry.getPartyId().equals(creditMop.getMopbicaddress())) {// only if BIC not equal MOPBICAddress for
																										// credit Mop
							logger.debug("Setting first in credit chain {} as the RECEIVER for MSG_PARTIES",roleType.name());

							partyId = msgPartyEntry.getPartyId();
							partyIdType = msgPartyEntry.getPartyIdType();
							break;
						}
					}
				}

				// initializing temporary fields(instead of members) in order not to execute logic twice.
				pdo.set(D_RECEIVER_PARTY_ID, partyId);
				pdo.set(D_RECEIVER_PARTY_ID_TYPE, partyIdType);
			}
		}
	}

	private RoleTypes roleConversionUtility(ChainType chainType) {

		RoleTypes roleType;
		switch (chainType) {

		case Creditor:
			roleType = RoleTypes.CDTR;
			break;
		case CreditorAgent:
			roleType = RoleTypes.CDTR_AGT;
			break;
		case IntermediaryAgent:
			roleType = RoleTypes.INRMY_AGT;
			break;
		case Receiver:
			roleType = RoleTypes.RECEIVER;
			break;
		default:
			roleType = null;
		}
		return roleType;
	}

}
