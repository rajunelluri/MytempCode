package backend.paymentprocess.flow.base;

import org.slf4j.Logger;

import backend.paymentprocess.flowstepselector.StepSelector;

import com.fundtech.datacomponent.response.Feedback;

public interface Flow {		
	
	/**
	 * 
	 * @return Returns the StepSelector for the flow.
	 */
	
	public StepSelector getStepSelector();
	
	/**
	 * Execute message flow
	 * @param mid
	 * The mid of the message
	 * @return Retunes Feedback objects that contains success / failure
	 * @throws Throwable
	 */
	
	public Feedback execute(java.lang.String mid)  throws Throwable;
	//public com.fundtech.datacomponent.response.Feedback execute(final Admin admin, java.lang.String mid)  throws Throwable;
	
	public Logger getLogger();
	
	/**
	 * 
	 * @return
	 * The stuatus of the message in case the flow fails
	 */
	public String getFailureStatus();
	
	public FlowName getFlowName();
	
}


