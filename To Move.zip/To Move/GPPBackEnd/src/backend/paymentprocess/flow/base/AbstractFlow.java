package backend.paymentprocess.flow.base;

import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_MSG_STS;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.businessobject.BOBasic;
import backend.core.module.MessageConstantsInterface;
import backend.paymentprocess.baseprocess.businessobjects.BOBaseProcess;
import backend.paymentprocess.flowstep.FlowStep;
import backend.paymentprocess.flowstepselector.StepSelector;
import backend.paymentprocess.highvalueprocess.businessobjects.BOHighValueProcess;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.datacomponent.response.ServiceFeedback;
import com.fundtech.util.Monitors;

public abstract class AbstractFlow extends BOBasic implements Flow, MessageConstantsInterface, PDOConstantFieldsInterface {
	protected static Logger logger = LoggerFactory.getLogger(AbstractFlow.class);
	
	private static final String FLOW = "flow";

	protected String failureStatus = MESSAGE_STATUS_REPAIR;
	
	protected FlowName flowName;

	protected AbstractFlow(){
		flowName = getFlowName();					
		failureStatus = getFailureStatus();		
	}
	
	/**
	 * The preFlow method should prepare prerequisites information for the flow to be execute  
	 * @param feedback
	 * @return
	 */
	protected Feedback preFlow(Feedback feedback) {		
		return feedback;
	}

	protected Feedback postFlow(Feedback feedback) {		
		return feedback;
	}

	protected Feedback preFlowOutter(Feedback feedback) {
		long startTime = System.currentTimeMillis();
		
		feedback = preFlow(feedback);
		
		Monitors.FLOWS.stepEnd(System.currentTimeMillis()-startTime, "PreFlow", getFlowName().name());
		
		return feedback;
	}

	protected Feedback postFlowOutter(Feedback feedback) {
		long startTime = System.currentTimeMillis();
		
		feedback = postFlow(feedback);
		
		Monitors.FLOWS.stepEnd(System.currentTimeMillis()-startTime, "PostFlow", getFlowName().name());
		
		return feedback;
	}
	
	/**
	 * 
	 */
	@Override
	//public Feedback execute(Admin admin, String mid) throws Throwable {
	public Feedback execute(String mid) throws Throwable {		
		PDO pdo = PaymentDataFactory.load(mid);
		
		long startTime = monitorFlowStart(pdo);
		
		getLogger().debug("Start preFlow for {}",getFlowName());
		Feedback feedback = preFlowOutter(new Feedback()); // todo: check the feedback!!!
		StepSelector stepsSelector = getStepSelector();
		if (stepsSelector != null) {
			getLogger().debug("Start executeFlowSteps for {}",getFlowName());
			feedback = executeFlowSteps(stepsSelector);
			getLogger().debug("Start postFlow for {}",getFlowName());
			feedback = postFlowOutter(feedback);
		}

		monitorFlowEnd(startTime,pdo);
		

		return feedback;
	}

	protected Feedback executeFlowSteps(StepSelector stepsSelector) throws Throwable {

		ServiceFeedback serviceFeedback = new ServiceFeedback();
		String finalStatus = null;

		PDO pdo = getFlowPdo();
		
		getLogger().info("start flow for mid {}.", new String[] { pdo.getMID() });

		while (stepsSelector.hasNextStep()) {
			FlowStep currentStep = stepsSelector.getNextStep();

			serviceFeedback = handleStepExecution(currentStep,pdo);

			if (serviceFeedback.shouldStopProcess()) {				
				finalStatus = serviceFeedback.isMessageStatusChanged() ? pdo.getString(P_MSG_STS) : failureStatus;
				getLogger().debug("stopping flow");
				break;
			}
		}
		
		if(shouldExecuteTerminationSubFlow()) {
			long terminamtionStartTime = System.currentTimeMillis();
			BOHighValueProcess.performTerminationSubFlow(pdo, finalStatus);
			Monitors.FLOWS.stepEnd(System.currentTimeMillis()-terminamtionStartTime,"TerminationSubFlow",getFlowName().name());
		}

		return serviceFeedback.getFeedback();

	}

	protected boolean shouldExecuteTerminationSubFlow() {		
		return true;
	}

	public ServiceFeedback handleStepExecution(FlowStep currentStep,PDO pdo) {
		long startTime = System.currentTimeMillis();
		getLogger().info(">>>>Flow step execution. Current step: {}", currentStep.getClass().getSimpleName());
		logger.debug("handleStepExecution Before - U_CDT_SEG_CODE is {} , U_DBT_SEG_CODE is {} ",pdo.get(PDOConstantFieldsInterface.U_CDT_SEG_CODE),pdo.get(PDOConstantFieldsInterface.U_DBT_SEG_CODE));

		String oldStatus;
		Feedback feedback = new Feedback();
		boolean isStatusChanged = false;

		try {
			oldStatus = pdo.getString(P_MSG_STS);			
			feedback = currentStep.execute(pdo);
			isStatusChanged = BOBaseProcess.compareMessageStatusBeforeAfter(oldStatus, pdo, currentStep.getClass().getSimpleName(), feedback);

		} catch (Throwable e) {
			genericServiceExceptionHandling(e, FLOW, currentStep.getClass().getSimpleName());
			feedback.setFailure();
			feedback.setErrorText(FLOW);
		}
		
		logger.debug("handleStepExecution After - U_CDT_SEG_CODE is {} , U_DBT_SEG_CODE is {} ",pdo.get(PDOConstantFieldsInterface.U_CDT_SEG_CODE),pdo.get(PDOConstantFieldsInterface.U_DBT_SEG_CODE));
		Monitors.FLOWS.stepEnd(System.currentTimeMillis()-startTime,currentStep.getClass().getSimpleName(),getFlowName().name());


		//logger.debug("PDO after step {}:\n" + pdo.toString(),currentStep.getClass().getSimpleName());
		return new ServiceFeedback(isStatusChanged, feedback,currentStep.stopOnStatusChange());
	}
	

	protected PDO getFlowPdo() {
		return Admin.getContextPDO();
	}
	
	private long monitorFlowStart(PDO pdo) {
		if (pdo.get("D_FLOW_NAME") != null) //outter invocation thru businessflowselector
			return 0;
		
		long startTime = System.currentTimeMillis();
		
		pdo.set("D_FLOW_NAME",getFlowName().name());		
		Monitors.FLOWS.flowStart(pdo);
		
		return startTime;
	}
	
	private void monitorFlowEnd(long startTime, PDO pdo) {
		if (startTime == 0)
			return;
		
		Monitors.FLOWS.flowEnd((System.currentTimeMillis()-startTime),pdo);		
	}
}
