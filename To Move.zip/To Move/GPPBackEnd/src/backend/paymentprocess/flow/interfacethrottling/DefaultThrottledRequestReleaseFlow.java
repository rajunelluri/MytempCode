
package backend.paymentprocess.flow.interfacethrottling;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.paymentprocess.flow.base.AbstractFlow;
import backend.paymentprocess.flow.base.FlowName;
import backend.paymentprocess.flowstep.FlowStep;
import backend.paymentprocess.flowstep.interfacethrottling.ReleaseRequestSteps;
import backend.paymentprocess.flowstepselector.AbstractStepSelector;
import backend.paymentprocess.flowstepselector.StepSelector;
import backend.paymentprocess.interfaces.throttling.PendingThrottledRequestReleaseFlow;

import com.fundtech.cache.entities.PendingOutgoingRequest;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.interfaces.throttling.InterfaceThrottlingService;
import com.fundtech.spring.SpringApplicationContext;
import com.fundtech.util.Monitors;

public class DefaultThrottledRequestReleaseFlow extends AbstractFlow implements PendingThrottledRequestReleaseFlow {
	private static final Logger logger = LoggerFactory.getLogger(DefaultThrottledRequestReleaseFlow.class);
	
	InterfaceThrottlingService service = (InterfaceThrottlingService)SpringApplicationContext.getBean("InterfaceThrottlingService");
	
	@Override
	public Feedback execute(PendingOutgoingRequest releasedRequest,boolean isBatchContext) {
		long startTime = System.currentTimeMillis();
		
		PDO releasedPDO = PaymentDataFactory.load(releasedRequest.getMid());
				
		releasedPDO.set("D_FLOW_INPUT",(Object)(new Object[]{releasedRequest,isBatchContext}));
		
		Monitors.FLOWS.stepEnd((System.currentTimeMillis()-startTime),"preFlow",getFlowName().toString());
		
		
		try {
			execute(releasedPDO.getMID());
		} catch (Throwable e) {
			String message = String.format("failed to release request, mid: %s, interface %s"
					,releasedRequest.getMid(),releasedRequest.getInterfaceName()); 
			logger.error(message,e);
			if (service != null) //histeric
				service.serviceErrorLog(message,e);
		} finally {
			releasedPDO.set("D_FLOW_INPUT",(String)null);
		}
		
		return new Feedback();
	}
	
	@Override
	public FlowName getFlowName() {		
		return FlowName.DefaultThrottledRequestReleaseFlow;
	}
	
	@Override
	public StepSelector getStepSelector() {
		return new AbstractStepSelector() {
			@Override
			public FlowStep[] getSteps() {
				return new FlowStep[] {
					 new ReleaseRequestSteps.SendRequestStep()
				    ,new ReleaseRequestSteps.UpdatePdoStep()
					,new ReleaseRequestSteps.PaymentFlowStep()
					,new ReleaseRequestSteps.SavePdoStep()
				};
			}
		};
	}

	@Override
	public String getFailureStatus() {
		return null;
	}
	
	@Override
	public Logger getLogger() {
		return logger;
	}

	@Override
	protected boolean shouldExecuteTerminationSubFlow() {
		return false;
	}
	
	
}
