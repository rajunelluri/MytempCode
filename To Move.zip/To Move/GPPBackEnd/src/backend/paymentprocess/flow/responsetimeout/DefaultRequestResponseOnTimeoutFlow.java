
package backend.paymentprocess.flow.responsetimeout;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.paymentprocess.flow.base.AbstractFlow;
import backend.paymentprocess.flow.base.FlowName;
import backend.paymentprocess.flowstep.FlowStep;
import backend.paymentprocess.flowstep.responsetimeout.OnTimeoutSteps;
import backend.paymentprocess.flowstepselector.AbstractStepSelector;
import backend.paymentprocess.flowstepselector.StepSelector;
import backend.paymentprocess.interfaces.timeout.RequestResponseOnTimeoutFlow;

import com.fundtech.core.general.flows.FlowException;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.errors.ProcessErrorConstants;
import com.fundtech.util.timeout.Expected;
import com.fundtech.util.timeout.ExpectedResponseInterface;

public class DefaultRequestResponseOnTimeoutFlow extends AbstractFlow implements RequestResponseOnTimeoutFlow {
	private static final Logger logger = LoggerFactory.getLogger(DefaultRequestResponseOnTimeoutFlow.class);
	private static final String FLOW_EXCEPTION = "flow";
	@Override
	public void onTimeout(Expected expected) {
		Feedback feedback = new Feedback();
		ExpectedResponseInterface expectedResponse = (ExpectedResponseInterface)expected;
		PDO requestPDO = PaymentDataFactory.load(expectedResponse.getRequestMID());
		requestPDO.set("D_FLOW_INPUT",expected);
		
		try {
			feedback = execute(requestPDO.getMID());
		} catch (Throwable e) {
			logger.error("on timeout flow failed",e);
		} finally {
			requestPDO.set("D_FLOW_INPUT",(String)null);
			if (!feedback.isSuccessful() && feedback.getErrorText().compareTo(FLOW_EXCEPTION) == 0)
			{
				Throwable t = null;
				throw new FlowException(ProcessErrorConstants.GenericError, t, Admin.getContextAdmin().getFlowID()) ;
			}
		}
	}
		
	@Override
	public FlowName getFlowName() {		
		return FlowName.DefaultRequestResponseOnTimeoutFlow;
	}
	
	@Override
	public StepSelector getStepSelector() {
		return new AbstractStepSelector() {
			@Override
			public FlowStep[] getSteps() {
				return new FlowStep[] {
					 new OnTimeoutSteps.IncreaseInterfaceFailureCounter()
				    ,new OnTimeoutSteps.UpdateInterfaceMonitor()
					,new OnTimeoutSteps.ApplyRetry()
					,new OnTimeoutSteps.SavePDO()
				};
			}	
		};
	}

	@Override
	public String getFailureStatus() {
		return null;
	}
	
	@Override
	public Logger getLogger() {
		return logger;
	}

	@Override
	protected boolean shouldExecuteTerminationSubFlow() {		
		return false;
	}
}
