package backend.paymentprocess.flow.g3.ocbc.notification;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.core.module.MessageConstantsInterface;
import backend.paymentprocess.erroraudit.ErrorAuditUtils;
import backend.paymentprocess.flow.base.FlowName;
import backend.paymentprocess.flow.g3.ocbc.OCBCAbstractFlow;
import backend.paymentprocess.flowstepselector.StepSelector;
import backend.paymentprocess.flowstepselector.ocbc.DDNotificationAcceptStepSelector;
import backend.paymentprocess.flowstepselector.ocbc.DDNotificationRejectStepSelector;
import backend.paymentprocess.messagenotification.common.NotificationTypeType;
import backend.util.ServerConstants;

import com.fundtech.cache.entities.Errcodes;
import com.fundtech.cache.entities.WebSessionInfo;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.errorhandling.ProcessError;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.errors.ProcessErrorConstants;
import com.fundtech.util.GlobalConstants;

public class DDNotificationFlow extends OCBCAbstractFlow {

	@Override
	protected Feedback preFlow(Feedback feedback) {
		super.preFlow(feedback);
		String confirmationFlow = getFlowPdo().getString(PDOConstantFieldsInterface.D_CONFIRMATION_FLOW);

		getFlowPdo().set(D_G3_IMMEDIATE_FLOW_NAME, FlowName.G3DDNotificaition);
		
		getFlowPdo().set(P_MSG_CLASS, MSG_CLASS_DD);//until payment classification rule is invoked
		if (NotificationTypeType.ACTC.name().equals(confirmationFlow)){//ACTC
			getFlowPdo().set(D_FLOW_CONTEXT, ACCEPT_FLOW);
			
		}else if (NotificationTypeType.RJCT.name().equals(confirmationFlow)){//RJCT
			getFlowPdo().set(D_FLOW_CONTEXT, REJECTION_FLOW);
			
			ProcessError pError;
			
			if (getFlowPdo().getString(PDOConstantFieldsInterface.D_BUTTON_ID) !=null){
				
				//This the case ForceReject was pressed by user while message was in timeout queue 
				WebSessionInfo webSessionInfo = Admin.getContextAdmin().getNSetWebSessionInfo();
				String userId = webSessionInfo.getUserID();
				pError=new ProcessError(ProcessErrorConstants.PaymentForceRejected,new Object[] {getFlowPdo().getString(PDOConstantFieldsInterface.P_TX_CTGY), userId}); 	
				getFlowPdo().set(PDOConstantFieldsInterface.P_MSG_STS, MessageConstantsInterface.MESSAGE_STATUS_REJECTED);
				
			} else {
				//In case of a RJCT we leave it to the user to decide if to Cancel the payment and do reverse accounting, if required, or to Resent it.
				String contents =null;
				Errcodes errcode = null;
				String mop = getFlowPdo().getString(PDOConstantFieldsInterface.P_DBT_MOP);
				
				errcode= CacheKeys.errcodesKey.getSingle(ServerConstants.DEFAULT_SERVER_OFFICE_NAME, mop
						, getFlowPdo().getString(PDOConstantFieldsInterface.X_MOP_NOTIFICATION_MSG_TYPE),  getFlowPdo().getString(PDOConstantFieldsInterface.X_RJCT_RSN));
				
				if (errcode == null){
					errcode= CacheKeys.errcodesKey.getSingle(ServerConstants.DEFAULT_SERVER_OFFICE_NAME, null
							, getFlowPdo().getString(PDOConstantFieldsInterface.X_MOP_NOTIFICATION_MSG_TYPE),  getFlowPdo().getString(PDOConstantFieldsInterface.X_RJCT_RSN));
	
				}
				
				contents = errcode != null ? errcode.getContents() : GlobalConstants.EMPTY_STRING;
				
				pError=new ProcessError(ProcessErrorConstants.PaymentRejected,getFlowPdo().getMID(), null,new Object[]{mop,contents}); 
			}
	        ErrorAuditUtils.setErrors(pError);
		}
		return feedback;
	}

	@Override
	public StepSelector getStepSelector() {
		String confirmationFlow = getFlowPdo().getString(PDOConstantFieldsInterface.D_CONFIRMATION_FLOW);
		
		if (NotificationTypeType.ACTC.name().equals(confirmationFlow)){//ACTC
			return new DDNotificationAcceptStepSelector();	
		}else if (NotificationTypeType.RJCT.name().equals(confirmationFlow)){//RJCT
			return new DDNotificationRejectStepSelector();
	        
		}else{
			return null;
		}
	}

	@Override
	public Logger getLogger() {
		return LoggerFactory.getLogger(DDNotificationFlow.class);
	}

	@Override
	public String getFailureStatus() {
		return MESSAGE_STATUS_REJECTED;
	}

	@Override
	public FlowName getFlowName() {
		flowName = FlowName.G3DDNotificaition;
		return flowName;
	}

}
