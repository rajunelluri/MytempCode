package backend.paymentprocess.flow.g3.ocbc.bulk;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.paymentprocess.flow.base.FlowName;
import backend.paymentprocess.flowstep.FlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.RepairAndEnrichedFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.SetCompleteFlowStep;
import backend.paymentprocess.flowstepselector.AbstractStepSelector;
import backend.paymentprocess.flowstepselector.StepSelector;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.datacomponent.response.Feedback;


public class CTDDCompletionFlow  extends IncomingBPPreProcessing{
	final String CT_DD_BP_FLOW_START = "Starting BP completion flow for CT, DD {}";
	
	@Override
	public StepSelector getStepSelector() {
		return new AbstractStepSelector(){
			@Override
			public FlowStep[] getSteps(){
			return new FlowStep[] {
					new RepairAndEnrichedFlowStep(),
					new SetCompleteFlowStep ()
				};
			}
		};
	}

	@Override
	public Logger getLogger() {
		return LoggerFactory.getLogger(CTDDCompletionFlow.class);
	}

	@Override
	public String getFailureStatus() {
		return MESSAGE_STATUS_REJECTED;
	}

	@Override
	protected Feedback preFlow(Feedback feedback) {
		super.preFlow(feedback);
		PDO pdo = getFlowPdo();
		super.configufeFlow(pdo);
		
		logger.info(CT_DD_BP_FLOW_START,pdo.getMID());

		pdo.set(D_FLOW_CONTEXT, BULK_MAIN_FLOW);
		pdo.set(D_G3_IMMEDIATE_FLOW_NAME, getFlowName());
		
		
		return feedback;
	}

	@Override
	public FlowName getFlowName() {
		flowName = FlowName.G3CTDDCompletion;
		return flowName;
	}

}
