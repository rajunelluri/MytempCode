package backend.paymentprocess.flow.g3.ocbc.bulk;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.util.GlobalConstants;

import backend.paymentprocess.flow.base.FlowName;
import backend.paymentprocess.flowstep.FlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.CreditAccountDerivationFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.DebitAccountSelectionFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.DepartmentSelectionFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.DuplicateCheckFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.MOPSelectionFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.PauseFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.RReturnRejectIndexMatchingCheckFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.ReceivingBankValidationFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.RepairAndEnrichedFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.STPValidationFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.feecalculation.DebitFeeCalculationFlowStep;
import backend.paymentprocess.flowstepselector.AbstractStepSelector;
import backend.paymentprocess.flowstepselector.StepSelector;

public class DDRejectReturnIncomingBPPreProcessing extends BulkPreProcessingFlow
{
	final String DDINCOMING_REJECT_RETURN_BP_PREPROCESSING_FLOW_START = "Starting BP Pre-Processing flow for Incoming reject return of debit transfer , MID: {}";
	final int MSG_RETURNED = 2;

	@Override
	public StepSelector getStepSelector() {
		return new AbstractStepSelector(){
			@Override
			public FlowStep[] getSteps(){
			return new FlowStep[] { 
					new ReceivingBankValidationFlowStep(), 
					new DepartmentSelectionFlowStep(), 
					new RepairAndEnrichedFlowStep(), 
					new STPValidationFlowStep(), 
					new DuplicateCheckFlowStep(), 
					new RReturnRejectIndexMatchingCheckFlowStep(), 
					new DebitAccountSelectionFlowStep(), 
					new CreditAccountDerivationFlowStep(),	
					new MOPSelectionFlowStep(),
					new DebitFeeCalculationFlowStep(),
					new PauseFlowStep()
				};
			}
		};
	}
	
	@Override
	protected Feedback preFlow(Feedback feedback) {
		super.preFlow(feedback);
		PDO pdo = getFlowPdo();
		super.configufeFlow(pdo);
		
		logger.info(DDINCOMING_REJECT_RETURN_BP_PREPROCESSING_FLOW_START,pdo.getMID());

		pdo.set(D_G3_IMMEDIATE_FLOW_NAME, getFlowName());
		pdo.set(D_FLOW_CONTEXT, BULK_MAIN_FLOW);
	        pdo.set(P_BUSINESS_FLOW_TP, GlobalConstants.BP);
		pdo.set(OX_BTCH_BOOKG, new Boolean(true));			// needed for the Force S message creation
		pdo.set(P_MSG_STS, MESSAGE_STATUS_RECEIVED);        
		// X_INSTD_AGT_BIC_2AND is set to null during BOSetBasicProperties, thus setting it here according to OX_INSTD_AGT_BIC_2AND.
		pdo.set(X_INSTD_AGT_BIC_2AND, (String)pdo.get(OX_INSTD_AGT_BIC_2AND));
		pdo.set(P_TX_CTGY, TX_CATEGORY_DRI);
		pdo.set(REJECT_MESSAGE_ID, new Integer(MSG_RETURNED));  
		pdo.set(IS_REJECT_MESSAGE, Boolean.FALSE); // This is a return message.
		pdo.set(P_INSTR_ID, pdo.getString(X_ORGNL_INSTR_ID));
		pdo.set(P_ORIG_INSTR_ID, pdo.getString(OX_INSTR_ID));
		pdo.set(P_MSG_CLASS, MSG_CLASS_IRT);			
		
		return feedback;
	}

	@Override
	public Logger getLogger()
	{
		return LoggerFactory.getLogger(DDRejectReturnIncomingBPPreProcessing.class);
	}

	@Override
	public String getFailureStatus()
	{
		return MESSAGE_STATUS_REJECTED;
	}

	@Override
	public FlowName getFlowName()
	{
		flowName = FlowName.G3DDPreProcessingRejectReturnIncoming;
		return flowName;
	}

}
