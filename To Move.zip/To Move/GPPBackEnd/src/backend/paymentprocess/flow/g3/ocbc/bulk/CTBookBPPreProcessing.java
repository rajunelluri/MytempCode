package backend.paymentprocess.flow.g3.ocbc.bulk;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.paymentprocess.flow.base.FlowName;
import backend.paymentprocess.flowstep.FlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.CreditAccountSelectionFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.CreditPartyDerivationFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.DepartmentSelectionFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.DuplicateCheckFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.MOPSelectionFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.PauseFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.RepairAndEnrichedFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.STPValidationFlowStep;
import backend.paymentprocess.flowstepselector.AbstractStepSelector;
import backend.paymentprocess.flowstepselector.StepSelector;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.datacomponent.response.Feedback;

public class CTBookBPPreProcessing  extends BulkFlow{

	@Override
	public StepSelector getStepSelector() {
		return new AbstractStepSelector() {
			@Override
			public FlowStep[] getSteps() {
				return new FlowStep[]{new DepartmentSelectionFlowStep(), 
						new RepairAndEnrichedFlowStep(), 
						new STPValidationFlowStep(), 
						new DuplicateCheckFlowStep(),
						new CreditPartyDerivationFlowStep(), 
						new CreditAccountSelectionFlowStep(), 
						new MOPSelectionFlowStep(),
						new PauseFlowStep()};
			}
		};
	}

	@Override
	public Logger getLogger() {
		return LoggerFactory.getLogger(CTBookBPPreProcessing.class);
	}

	@Override
	public String getFailureStatus() {
		return MESSAGE_STATUS_REJECTED;
	}

	@Override
	protected Feedback preFlow(Feedback feedback) {
		super.preFlow(feedback);
		PDO pdo = getFlowPdo();
		super.configufeFlow(pdo);
		
		pdo.set(D_FLOW_CONTEXT, BULK_MAIN_FLOW);
		pdo.set(P_MSG_CLASS, MSG_CLASS_PAY);//until payment classification rule is invoked			
		pdo.set(P_BASE_AMT, pdo.get(OX_STTLM_AMT));
		pdo.set(P_BASE_CCY, pdo.getNSetOffice().getCurrency());
		pdo.set(P_DBT_AMT, pdo.getDecimal(OX_STTLM_AMT));// since bulk individual has no debt account derivation, this is needed for principle reversal posting	

		return feedback;
	}

	@Override
	public FlowName getFlowName() {
		flowName = FlowName.G3CTBook;
		return flowName;
	}

}
