package backend.paymentprocess.flow.g3.ocbc.bulk;

import static backend.businessobject.BOProxies.m_generateTransactionLogging;
import static backend.paymentprocess.SubBatchProcessInterface.STATUS_FILE_DISTRIBUTED;
import static com.fundtech.util.GlobalConstants.BP;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import backend.paymentprocess.SubBatchProcessInterface;
import backend.paymentprocess.commons.MessageUtils;
import backend.paymentprocess.commons.MsgClassType;
import backend.paymentprocess.debulkingprocess.businessobjects.BODebulkingProcess;
import backend.paymentprocess.flowstep.FlowStep;
import backend.paymentprocess.flowstepselector.StepSelector;
import backend.paymentprocess.g3utils.ErrorMappingUtils;
import backend.paymentprocess.highvalueprocess.businessobjects.BOHighValueProcess;
import backend.util.ServerUtils;

import com.fundtech.cache.entities.ExternalErrorMessage;
import com.fundtech.cache.entities.Msgerr;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.datacomponent.response.ServiceFeedback;
import com.fundtech.datacomponent.response.SimpleResponseDataComponent;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalUtils;

public abstract class IncomingBPPreProcessing  extends BulkPreProcessingFlow{
	
	
	@Override
	protected Feedback executeFlowSteps(StepSelector stepsSelector) throws Throwable {

		ServiceFeedback serviceFeedback = new ServiceFeedback();
		String finalStatus = null;

		PDO pdo = getFlowPdo();
		getLogger().info("start flow for mid {}.", new String[] { pdo.getMID() });

		while (stepsSelector.hasNextStep()) {
			FlowStep currentStep = stepsSelector.getNextStep();
			serviceFeedback = handleStepExecution(currentStep,pdo);
			
			if (serviceFeedback.shouldStopProcess()) {
				String strPmntSrc=pdo.getString(PDOConstantFieldsInterface.P_PMNT_SRC);
				String strBatchMsgTp=pdo.getString(PDOConstantFieldsInterface.P_BATCH_MSG_TP);
				if (GlobalConstants.CREATE.equalsIgnoreCase(strPmntSrc) || 
				   (GlobalUtils.isNullOrEmpty(strPmntSrc) && SubBatchProcessInterface.BATCH_MESSAGE_TYPE_SUB.equals(strBatchMsgTp)))
				{
					finalStatus = serviceFeedback.isMessageStatusChanged() ? pdo.getString(P_MSG_STS): MESSAGE_STATUS_REPAIR;
				}else{
					finalStatus = serviceFeedback.isMessageStatusChanged() ? pdo.getString(P_MSG_STS) : getFailureStatus();
				}
				getLogger().debug("stopping flow");
				break;
			}
		}
		if (MESSAGE_STATUS_REJECTED.equals(finalStatus)){
			SimpleResponseDataComponent generateTransactionResponse = 
					m_generateTransactionLogging.generateRelatedTransaction(Admin.getContextAdmin(), pdo.getMID(), RELATION_TYPE_ORIGINAL_PAYMENT, RELATION_TYPE_OUTGOING_REJECT_RETURN);
			Feedback feedback = generateTransactionResponse.getFeedback();

	        Object[] arrData = generateTransactionResponse.getDataArray();
	        boolean bValidGeneratedMID = ServerUtils.isArrayNotNullAndNotEmpty(arrData); 
	          
	        String rejectReturnGeneratedMID = null;
	          
	        // Executes formatting and transmission for the answer MID.
	        if(feedback.isSuccessful())
	        {
	          	// Valid generated MID.
	          	if(bValidGeneratedMID)
	          	{
	          		rejectReturnGeneratedMID = generateTransactionResponse.getDataArray()[0].toString();
	          		logger.info("Generated 'Reject Return' message MID: {}.", rejectReturnGeneratedMID);
	          		PDO pdoRejectReturn = pdo.getLinkedMsg(RELATION_TYPE_OUTGOING_REJECT_RETURN);
	          		pdoRejectReturn.promoteToPrimary();
	          		
	          		pdoRejectReturn.set(P_IN_INTERNAL_FILEID, GlobalUtils.generateGUIDRandom());
	          		pdoRejectReturn.set(P_BATCH_MSG_TP, pdo.getString(P_BATCH_MSG_TP));
	          		pdoRejectReturn.set(P_BUSINESS_FLOW_TP, BP);
	           		pdoRejectReturn.set(X_RTN_RSN_PRTRY,getRtnRsnCode(pdo));//needed for calculating ctrlSum of pacs004
	       
	          		String chunkId=GlobalUtils.generateGUID();
	          		pdoRejectReturn.set(P_CHUNK_ID, chunkId);
	          		String bulkId=GlobalUtils.generateGUID();
	          		pdoRejectReturn.set(D_BULK_ID, bulkId);
	          		
	          		MsgClassType msgClass = MessageUtils.getMsgClassType(pdo);
	          		if (GlobalUtils.isObjectNullOrEmpty(msgClass.getDestMop(pdo))){
	          			pdoRejectReturn.set(msgClass.getSourceMopLogicalField(), "BOOK");
	          			pdoRejectReturn.getNSetCREDIT_MOP();
	          			pdoRejectReturn.getNSetDEBIT_MOP();
	          		}
	          		
	          		//send the reject payment to processing
	          		List<PDO> pdoList = new ArrayList<PDO>();
	          		pdoList.add(pdoRejectReturn);
	          		BODebulkingProcess dprocess = new BODebulkingProcess();
	          		
	          		dprocess.runDebulkInner(pdoList, pdoRejectReturn.getString(P_IN_INTERNAL_FILEID), STATUS_FILE_DISTRIBUTED, chunkId, 500, new Map[1],"FndtBatchMsg_SingleTypeBatch_Pacs_004", false,feedback, bulkId);
	          	}
	        }
		}
		pdo.promoteToPrimary();
		pdo.resetRelationsMap();
		if(shouldExecuteTerminationSubFlow())
			BOHighValueProcess.performTerminationSubFlow(pdo, finalStatus);

		return serviceFeedback.getFeedback();

	}
	
	
	
	/**
	 * Derive reason code
	 * @param pdo
	 * @return
	 */
	private String getRtnRsnCode(PDO pdo){
		List<ExternalErrorMessage> extnErrs = pdo.getExternalErrorMessages();
  		String rtnRsn = null;
  		if (!GlobalUtils.isListNullOrEmpty(extnErrs)){
  			rtnRsn = ErrorMappingUtils.getG3Code(extnErrs.get(0).getInterfaceId(), extnErrs.get(0).getErrorCode());
  		}else{
  			List<Msgerr> internalErrs = pdo.getListMSGERR();
  			if (!GlobalUtils.isListNullOrEmpty(internalErrs)){
      			long code = internalErrs.get(0).getErrorCode();
      			rtnRsn = ErrorMappingUtils.getG3Code("GPP", Long.toString(code));
      		}
  		}
  		
  		return rtnRsn;
	}

}
