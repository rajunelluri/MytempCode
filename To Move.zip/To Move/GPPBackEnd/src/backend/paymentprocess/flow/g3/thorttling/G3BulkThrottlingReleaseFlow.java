
package backend.paymentprocess.flow.g3.thorttling;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.paymentprocess.flow.base.FlowName;
import backend.paymentprocess.flow.interfacethrottling.DefaultThrottledRequestReleaseFlow;
import backend.paymentprocess.flowstep.FlowStep;
import backend.paymentprocess.flowstep.g3.interfacethrottling.G3ReleaseRequestSteps;
import backend.paymentprocess.flowstep.interfacethrottling.ReleaseRequestSteps;
import backend.paymentprocess.flowstepselector.AbstractStepSelector;
import backend.paymentprocess.flowstepselector.StepSelector;

public class G3BulkThrottlingReleaseFlow extends DefaultThrottledRequestReleaseFlow {
	private static final Logger logger = LoggerFactory.getLogger(G3BulkThrottlingReleaseFlow.class);
	
	@Override
	public FlowName getFlowName() {		
		return FlowName.G3BulkThrottledRequestReleaseFlow;
	}
	
	@Override
	public StepSelector getStepSelector() {
		return new AbstractStepSelector() {
			@Override
			public FlowStep[] getSteps() {
				return new FlowStep[] {
					 new G3ReleaseRequestSteps.G3BulkSendRequestStep()
				    ,new ReleaseRequestSteps.UpdatePdoStep()
					,new ReleaseRequestSteps.PaymentFlowStep()
					,new ReleaseRequestSteps.SavePdoStep()
				};
			};
		};
	}
	
	@Override
	public Logger getLogger() {
		return logger;
	}
}
