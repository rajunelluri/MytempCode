package backend.paymentprocess.flow.g3.ocbc;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.core.module.MessageConstantsInterface;
import backend.paymentprocess.flow.base.FlowName;
import backend.paymentprocess.flowstep.FlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.PostingErrorCorrectionFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.PrinciplePostingOAReversalFlowStep;
import backend.paymentprocess.flowstepselector.AbstractStepSelector;
import backend.paymentprocess.flowstepselector.StepSelector;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.util.Monitors;

/**
 * @author Srinivasa.goru
 *
 */
public class PostingErrorCorrectionFlow extends OCBCAbstractFlow {
	
	@Override
	public StepSelector getStepSelector() {
		return new AbstractStepSelector() {
			@Override
			public FlowStep[] getSteps() {
				return new FlowStep[]{new PostingErrorCorrectionFlowStep(), new PrinciplePostingOAReversalFlowStep()};
			}
		};
	}
	
	@Override
	public String getFailureStatus() {
		return MESSAGE_STATUS_MP_ERROR;
	}
	
	@Override
	public FlowName getFlowName() {
		flowName =FlowName.G3PostingErrorCorrectionFlow;
		return flowName;
	}
	
	@Override
	protected Feedback preFlow(Feedback feedback)  {
		super.preFlow(feedback);
		Monitors.POSTING.info("Perform PostingErrorCorrectionFlow");
		PDO pdo = getFlowPdo();
		String oXInsructionId=pdo.getString(PDOConstantFieldsInterface.OX_INSTR_ID);
        String xInsructionId=pdo.getString(PDOConstantFieldsInterface.X_INSTR_ID);
        if(StringUtils.isEmpty(oXInsructionId) && !StringUtils.isEmpty(xInsructionId)){
            pdo.set(PDOConstantFieldsInterface.OX_INSTR_ID, xInsructionId);
        }
		String txCtgy = pdo.getString(PDOConstantFieldsInterface.P_TX_CTGY);
		pdo.set(UDF_SYSTEM_REVERSE_TYPE, pdo.getString(D_REVERSE_TYPE));
		if(pdo.isBulkSubBatchPayment())
		{
			pdo.set(PDOConstantFieldsInterface.D_FLOW_CONTEXT, MessageConstantsInterface.BULK_SUBBACTH_FLOW_ERROR_CORRECTION);
		}
		else if(pdo.isBulkIndividualPayment() && "CTO".equals(txCtgy) && "BOOK".equals(pdo.getString(P_CDT_MOP)) && "BOOK".equals(pdo.getString(P_DBT_MOP)))
		{
			pdo.set(PDOConstantFieldsInterface.D_FLOW_CONTEXT, MessageConstantsInterface.BULK_INDIVIDUAL_ERROR_CORRECTION);
		}
		else {
		pdo.set(PDOConstantFieldsInterface.D_FLOW_CONTEXT, ERROR_CORRECTION);
		}
		return feedback;
	}
	
	@Override
	public Logger getLogger() {
		return LoggerFactory.getLogger(PostingErrorCorrectionFlow.class);
	}
}
