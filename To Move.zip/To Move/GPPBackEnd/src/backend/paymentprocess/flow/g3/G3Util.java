package backend.paymentprocess.flow.g3;

import static backend.paymentprocess.flow.base.FlowName.G3CTBook;
import static backend.paymentprocess.flow.base.FlowName.G3CTBookPostPosting;
import static backend.paymentprocess.flow.base.FlowName.G3CTIncoming;
import static backend.paymentprocess.flow.base.FlowName.G3CTIncomingPostPosting;
import static backend.paymentprocess.flow.base.FlowName.G3CTOutgoing;
import static backend.paymentprocess.flow.base.FlowName.G3CTOutgoingPostPosting;
import static backend.paymentprocess.flow.base.FlowName.G3DDBook;
import static backend.paymentprocess.flow.base.FlowName.G3DDBookPostPosting;
import static backend.paymentprocess.flow.base.FlowName.G3DDIncoming;
import static backend.paymentprocess.flow.base.FlowName.G3DDIncomingPostPosting;
import static backend.paymentprocess.flow.base.FlowName.G3DDOutgoing;
import static backend.paymentprocess.flow.base.FlowName.G3ReversalOutgoing;
import static backend.paymentprocess.flow.base.FlowName.G3BulkSubBatchFlow;
import static backend.paymentprocess.flow.base.FlowName.G3CTOIndividualOutgoing;
import static backend.paymentprocess.flow.base.FlowName.G3CTIndividualOutgoingPostS;
import static backend.paymentprocess.flow.base.FlowName.G3CTIndividualBookPostS;
import static backend.paymentprocess.flow.base.FlowName.G3CTBookPreProcessStepSelector;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.D_G3_IMMEDIATE_FLOW_NAME;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_CDT_ACCT_CCY;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_CDT_ACCT_NB;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_CDT_ACCT_OFFICE;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_DBT_ACCT_CCY;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_DBT_ACCT_NB;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_DBT_ACCT_OFFICE;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_DBT_AMT;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.core.module.MessageConstantsInterface;
import backend.paymentprocess.flow.base.FlowName;
import backend.paymentprocess.memopost.common.PostingAccType;
import static backend.paymentprocess.SubBatchProcessInterface.STATUS_FILE_DUPLICATE;
import static backend.paymentprocess.SubBatchProcessInterface.STATUS_FILE_NOT_VALID_NUMBER_OF_TX;
import static backend.paymentprocess.SubBatchProcessInterface.STATUS_FILE_NOT_VALID_XML;
import static backend.paymentprocess.SubBatchProcessInterface.STATUS_FILE_REJECTED;

import com.fundtech.cache.entities.Accounts;
import com.fundtech.cache.entities.FileSummary;
import com.fundtech.cache.entities.Journalmessages;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.errors.ProcessErrorConstants;

public class G3Util {
	static Logger log=LoggerFactory.getLogger(G3Util.class);
	private final static Set<FlowName> CTO_FLOWS = new HashSet<FlowName>(Arrays.asList(new FlowName[]{G3CTOutgoing ,G3CTOutgoingPostPosting,G3BulkSubBatchFlow,G3CTOIndividualOutgoing,G3CTIndividualOutgoingPostS})); 
	private final static Set<FlowName> DDO_FLOWS = new HashSet<FlowName>(Arrays.asList(new FlowName[]{G3DDOutgoing}));
	private final static Set<FlowName> DDI_FLOWS = new HashSet<FlowName>(Arrays.asList(new FlowName[]{G3DDIncoming ,G3DDIncomingPostPosting}));
	private final static Set<FlowName> CTI_FLOWS = new HashSet<FlowName>(Arrays.asList(new FlowName[]{G3CTIncoming ,G3CTIncomingPostPosting}));
	private final static Set<FlowName> BOOK_FLOWS = new HashSet<FlowName>(Arrays.asList(new FlowName[]{G3CTBook ,G3CTBookPostPosting,G3DDBook, G3DDBookPostPosting,G3CTIndividualBookPostS,G3CTBookPreProcessStepSelector}));
	
	
	public static boolean isCTIncoming(PDO pdo) {
		return CTI_FLOWS.contains( pdo.get(D_G3_IMMEDIATE_FLOW_NAME));
	}

	public static boolean isDDIncoming(PDO pdo) {
		return DDI_FLOWS.contains( pdo.get(D_G3_IMMEDIATE_FLOW_NAME));
	}

	public static boolean isIncoming(PDO pdo) {
		return isCTIncoming(pdo) || isDDIncoming(pdo);
	}

	public static boolean isCTOutgoing(PDO pdo) {
		return CTO_FLOWS.contains(pdo.get(D_G3_IMMEDIATE_FLOW_NAME));
	}

	public static boolean isDDOutgoing(PDO pdo) {
		return DDO_FLOWS.contains( pdo.get(D_G3_IMMEDIATE_FLOW_NAME));
	}

	public static boolean isOutgoing(PDO pdo) {
		return isCTOutgoing(pdo) || isDDOutgoing(pdo) || isReversalOutgoing(pdo);
	}

	public static boolean isBook(PDO pdo) {
		return BOOK_FLOWS.contains(pdo.get(D_G3_IMMEDIATE_FLOW_NAME));
	}
	
	public static boolean isReversalOutgoing(PDO pdo) {
		return (FlowName) pdo.get(D_G3_IMMEDIATE_FLOW_NAME) == G3ReversalOutgoing;
	}

	public static PostingAccType[] getPostingRejectionContext() {
		return rejectionContext;
	}
	public static PostingAccType[] getPostingReversalContext() {
		return reversalContext;
	}

	public static PostingAccType[] getBulkSubBatchPostingContext() {
		return bulkSubBatchContext;
	}
	
	public static PostingAccType[] getBulkIndividualPostingContext() {
		return bulkIndividualContext;
	}
	
	public static PostingAccType[] getBulkIndividualReversalPostingContext() {
		return bulkIndividualReversalContext;
	}
	
	public static PostingAccType[] getBulkIndividualBookReversalPostingContext() {
		return bulkIndividualBookReversalContext;
	}
	
	public static PostingAccType[] getPostingMainContext() {
		return mainContext;
	}
		public static boolean isSufficientFunds(PDO pdo){
			
			BigDecimal principleAmount = pdo.getDecimal(P_DBT_AMT);
			BigDecimal feesAmount = pdo
					.getDecimal(PDOConstantFieldsInterface.D_DUMMY_DBT_FEE_POST_AMT);
			
			String customerBalance=(String)pdo.get("***^AVAILABLE_BALANCE");
			
			BigDecimal debitAmount;
			if (principleAmount!=null && feesAmount!=null) {
				debitAmount = principleAmount.add(feesAmount);
			}else if(principleAmount!=null){
				debitAmount = principleAmount;
			}else{
				debitAmount=feesAmount;
			}
			
			Double dCustomerBalance=customerBalance!=null?Double.valueOf(customerBalance):0;
			Double ddebitAmount=debitAmount!=null?debitAmount.doubleValue():0;
			if(dCustomerBalance>=ddebitAmount){
				return true;
			}
			pdo.set(PDOConstantFieldsInterface.P_MSG_STS, MessageConstantsInterface.MESSAGE_STATUS_REJECTED);
			log.warn("Available blance "+dCustomerBalance+" is not sufficient for transaction amount "+principleAmount+" and fees amount "+feesAmount);
			return false;
		}
		
		public static Feedback populateCreditAccount(PDO pdo, Feedback feedback) {
			if (pdo.getCREDIT_ACCOUNT() == null) {
				Accounts creditAccount = new Accounts();
				creditAccount.setAccNo(pdo.getString(P_CDT_ACCT_NB));
				creditAccount.setCurrency(pdo.getString(P_CDT_ACCT_CCY));
				creditAccount.setOffice(pdo.getString(P_CDT_ACCT_OFFICE));
				creditAccount.setAccType("ACC");
				pdo.setCREDIT_ACCOUNT(creditAccount);
				
			}
			return feedback;
		}
		
		public static Feedback populateDebitAccount(PDO pdo, Feedback feedback) {
			if (pdo.getDEBIT_ACCOUNT() == null) {
				Accounts debitAccount = new Accounts();
				debitAccount.setAccNo(pdo.getString(P_DBT_ACCT_NB));
				debitAccount.setCurrency(pdo.getString(P_DBT_ACCT_CCY));
				debitAccount.setOffice(pdo.getString(P_DBT_ACCT_OFFICE));
				debitAccount.setAccType("ACC");
				pdo.setDEBIT_ACCOUNT(debitAccount);
				
			}
			return feedback;
		}

	private static PostingAccType[] rejectionContext = new PostingAccType[] { PostingAccType.MAIN_CR_R, PostingAccType.MAIN_DR_R };
	private static PostingAccType[] reversalContext = new PostingAccType[] { PostingAccType.MAIN_CR_R, PostingAccType.MAIN_DR_R };
	private static PostingAccType[] mainContext = new PostingAccType[] { PostingAccType.MAIN_CR, PostingAccType.MAIN_DR };
	private static PostingAccType[] bulkSubBatchContext = new PostingAccType[] { PostingAccType.BSA_CR, PostingAccType.MAIN_DR };
	private static PostingAccType[] bulkIndividualContext = new PostingAccType[] { PostingAccType.MAIN_CR, PostingAccType.BSA_DR };
	private static PostingAccType[] bulkIndividualReversalContext = new PostingAccType[] { PostingAccType.MAIN_CR_R, PostingAccType.MAIN_DR_R };
	private static PostingAccType[] bulkIndividualBookReversalContext = new PostingAccType[] { PostingAccType.BSA_CR_R, PostingAccType.MAIN_DR_R };
	
	public static void setRsnPrtry(PDO pdo) {
		FileSummary fileSummary = pdo.getNSetIncomingFileSummary();

		Journalmessages jm = null;
		String fileStatus = null;

		// if file is invalid XML, there won't be any FileSummary on it
		if (fileSummary != null)
			fileStatus = fileSummary.getStatus();

		if (StringUtils.isEmpty(fileStatus))
			fileStatus = pdo.getString("F_FILE_STATUS");

		if (fileStatus.contains(STATUS_FILE_NOT_VALID_XML))
			jm = CacheKeys.journalMessagesKey.getSingle(ProcessErrorConstants.BulkFileInvalidXml);
		else if (fileStatus.contains(STATUS_FILE_DUPLICATE))
			jm = CacheKeys.journalMessagesKey.getSingle(ProcessErrorConstants.BulkFileDuplicate);
		else if (fileStatus.contains(STATUS_FILE_NOT_VALID_NUMBER_OF_TX))
			jm = CacheKeys.journalMessagesKey.getSingle(ProcessErrorConstants.BulkFileNbOfTxFail);
		else if (fileStatus.contains(STATUS_FILE_REJECTED))
			jm = CacheKeys.journalMessagesKey.getSingle(ProcessErrorConstants.BulkFileProcessingFail);

		if (jm != null)
			pdo.set(PDOConstantFieldsInterface.D_ACK_STS_RSN_PRTRY,
					"GPP" + jm.getErrorCode());

	}
}
