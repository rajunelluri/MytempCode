package backend.paymentprocess.flow.g3.ocbc.bulk;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.paymentprocess.flow.base.FlowName;
import backend.paymentprocess.flowstep.FlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.CreditAccountSelectionFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.DebitAccountDerivationFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.DepartmentSelectionFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.DuplicateCheckFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.MOPSelectionFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.PauseFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.RIndexMatchingCheckFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.ReceivingBankValidationFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.RepairAndEnrichedFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.STPValidationFlowStep;
import backend.paymentprocess.flowstepselector.AbstractStepSelector;
import backend.paymentprocess.flowstepselector.StepSelector;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.util.GlobalConstants;

public class CTIncomingBPPreProcessing  extends IncomingBPPreProcessing{
	final String CTINCOMING_BP_FLOW_START = "Starting BP flow for Incoming credit transfer , MID: {}";
	
	@Override
	public StepSelector getStepSelector() {
		return new AbstractStepSelector(){
			@Override
			public FlowStep[] getSteps(){
			return new FlowStep[] { 
					new ReceivingBankValidationFlowStep(), 
					new DepartmentSelectionFlowStep(), 
					new RepairAndEnrichedFlowStep(), 
					new STPValidationFlowStep(), 
					new DuplicateCheckFlowStep(), 
					new RIndexMatchingCheckFlowStep(), 
					new DebitAccountDerivationFlowStep(),	//TODO
					new CreditAccountSelectionFlowStep(), 
					new MOPSelectionFlowStep(),
					//new CreditFeeCalculationFlowStep(),
					new PauseFlowStep()
				};
			}
		};
	}

	@Override
	public Logger getLogger() {
		return LoggerFactory.getLogger(CTIncomingBPPreProcessing.class);
	}

	@Override
	public String getFailureStatus() {
		return MESSAGE_STATUS_REJECTED;
	}

	@Override
	protected Feedback preFlow(Feedback feedback) {
		super.preFlow(feedback);
		PDO pdo = getFlowPdo();
		super.configufeFlow(pdo);
		
		logger.info(CTINCOMING_BP_FLOW_START,pdo.getMID());

		pdo.set(D_FLOW_CONTEXT, BULK_MAIN_FLOW);
		pdo.set(D_G3_IMMEDIATE_FLOW_NAME, getFlowName());
		pdo.set(P_MSG_CLASS, MSG_CLASS_PAY);//until payment classification rule is invoked			
		pdo.set(P_BASE_AMT, pdo.get(OX_STTLM_AMT));
		pdo.set(P_BASE_CCY, pdo.getNSetOffice().getCurrency());
		pdo.set(P_TX_CTGY, TX_CATEGORY_CTI);
		pdo.set(P_BUSINESS_FLOW_TP, GlobalConstants.BP);
		pdo.set(P_ORIG_INSTR_ID, pdo.getString(OX_INSTR_ID));
		pdo.set(OX_BTCH_BOOKG, new Boolean(true)); // needed for the Force S message creation
		
		return feedback;
	}

	@Override
	public FlowName getFlowName() {
		flowName = FlowName.G3CTIncoming;
		return flowName;
	}

}
