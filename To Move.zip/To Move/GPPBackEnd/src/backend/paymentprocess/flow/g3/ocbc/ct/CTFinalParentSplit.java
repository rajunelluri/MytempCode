package backend.paymentprocess.flow.g3.ocbc.ct;

import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.X_ORGNL_GRP_STS;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.core.module.MessageConstantsInterface;
import backend.dataaccess.dao.DAOBasic;
import backend.paymentprocess.flow.base.FlowName;
import backend.paymentprocess.flow.g3.ocbc.OCBCAbstractFlow;
import backend.paymentprocess.flowstep.FlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.PauseFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.PostingFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.SnewSplitCreateRFPaymentFlowStep;
import backend.paymentprocess.flowstepselector.AbstractStepSelector;
import backend.paymentprocess.flowstepselector.StepSelector;


import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.util.GlobalConstants;

public class CTFinalParentSplit extends OCBCAbstractFlow {

	@Override
	public FlowName getFlowName() {		
		flowName = FlowName.CTFinalParentSplit;
		return flowName;
	}		
	
	@Override
	public String getFailureStatus() {
		return MESSAGE_STATUS_REJECTED;
	}
	
	@Override
	public Logger getLogger() {
		return LoggerFactory.getLogger(CTFinalParentSplit.class);		
	}
	
	@Override
	public StepSelector getStepSelector() {
		return new AbstractStepSelector(){
			@Override
			public FlowStep[] getSteps(){
				return new FlowStep[]{ 
						new SnewSplitCreateRFPaymentFlowStep(), //if not actc - create rf  payment post it and finalize its status. else do nothing.
					//	new PauseFlowStep() //end Parent split paymnent
						
					/*	new SplitCreateRFPaymentFlowStep(), 
						new PostingFlowStep(),  //will be skipped if a monitor of RF payment indicator will say that no posting is needed.
						new PauseFlowStep(),   //will be skipped if a monitor of RF payment indicator will say that no posting is needed. at the end needs to replace the context to the parent PDO
						new PauseFlowStep()*/}; // needs to handle the final status of the parent.
			}
		};
	}

	@Override
	protected Feedback preFlow(Feedback feedback)  {
		super.preFlow(feedback);
		PDO pdo = getFlowPdo();

		pdo.set(D_G3_IMMEDIATE_FLOW_NAME, flowName);
		pdo.set(D_FLOW_CONTEXT, MAIN_FLOW);
		pdo.set(P_MSG_CLASS, MSG_CLASS_PAY);// until payment classification rule is invoked
		pdo.set(P_BASE_AMT, pdo.get(OX_STTLM_AMT));
		pdo.set(P_BASE_CCY, pdo.getNSetOffice().getCurrency());
		pdo.set(P_BUSINESS_FLOW_TP, GlobalConstants.RT);
		
		//needs to calculate if RF is needed to be created and fill a logical field ?? to hold that indication in the flow.
		boolean IsRfInPostex = pdo.IsRfPayment() && pdo.getStatus().equals(MESSAGE_STATUS_POST_EXCEPTION);
			//only RF payments coming from postex should not check the overall status
			if(!IsRfInPostex)
			{
				try {
				pdo.set(D_OVERALL_SPLIT_STATUS, GetOverAllSplitStatus(pdo));	
				pdo.set(X_ORGNL_GRP_STS,pdo.get(D_OVERALL_SPLIT_STATUS));
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else
			{
				pdo.set(PDOConstantFieldsInterface.D_SKIP_SPLIT_RF,"SKIP");
			}
			
		

		return feedback;
	}
/**
 * String GetOverAllSplitStatus()
 * @param pdo
 * @pre all children split payments of the parent are in final status 
 * @return the overall ack/nack from g3 status - case : all acked "ACTC" all nacked "RJCT" some nacked some not "PART"
 * @throws Exception 
 */
	private String GetOverAllSplitStatus(PDO pdo) throws Exception  {
		final String AllAcked = "ACTC"; //all split children recieved ack from G3
		final String AllNacked = "RJCT";//all split children recieved nack from G3
		final String PartiallyNacked = "PART";//some of the  split children recieved nack , some recieved ack from G3
		
		final int COMPLETED_PAYMENTS = 0 ;
		final int REJECTED_PAYMENTS = 1 ;
		final int REST_OF_PAYMENTS = 2 ;
		
		int [] NumberOfpayments = new int[3];
		
		String OverAllStatus = AllAcked; //init
		
		NumberOfpayments = CheckMfamilyChildrenStatuses(pdo.getMID());
		
		int nTotalChildrenCount = NumberOfpayments[COMPLETED_PAYMENTS] +  NumberOfpayments[REJECTED_PAYMENTS]+  NumberOfpayments[REST_OF_PAYMENTS] + 0;
		
		if (nTotalChildrenCount ==  NumberOfpayments[COMPLETED_PAYMENTS]){
			OverAllStatus = AllAcked;
		}
		else if(nTotalChildrenCount ==  NumberOfpayments[REJECTED_PAYMENTS]){
			OverAllStatus = AllNacked;
		}
		else if(NumberOfpayments[REST_OF_PAYMENTS] > 0){
			logger.debug("houston we have a problem , one of the split payments are in unexpected status");
		}
		else{
			OverAllStatus = PartiallyNacked;
		}
		
		return OverAllStatus;
	}
/**
 * 
 * @param sMid
 * @return an array of integer to report how many split payments are in complete , rejected or in any other status (which is not expected)
 * @throws Exception
 */
private int[] CheckMfamilyChildrenStatuses(String sMid) throws SQLException,Exception {
	
	final String SplitRelation = MessageConstantsInterface.RELATION_TYPE_CHILD_PAYMENT;
	final String SELECT_STATEMENT = "select MI.P_MSG_STS STATUS ,count(*) COUNT from MINF MI where MI.P_MID in (select MF.RELATED_MID from MFAMILY MF where MF.P_MID = ? and MF.Related_Type =  ? ) group by MI.p_Msg_Sts" ;
	final String SELECT_STATEMENT_2 =  "select 1 STATUS ,2 COUNT from dual /* ? ? */";
	final int COMPLETED_PAYMENTS = 0 ;
	final int REJECTED_PAYMENTS = 1 ;
	final int REST_OF_PAYMENTS = 2 ;
	
	Connection conn = null;
	PreparedStatement ps = null; 
	ResultSet rs = null;
	DAOBasic m_dao = new DAOBasic();
	
	int [] NumberOfpaymentsInner = new int[3];
	
	try
	{
		 
		
		conn = m_dao.getConnection();
		ps = conn.prepareStatement(SELECT_STATEMENT);
		ps.setString(1, sMid); //related MID from event params
		ps.setString(2, SplitRelation); //split relation of mfamily 
		rs = ps.executeQuery();
		
		while (rs.next())
		{
			String sStatus = rs.getString("STATUS");
			int Count = rs.getInt("COUNT");
			if (sStatus.equals(MessageConstantsInterface.MESSAGE_STATUS_COMPLETE)){
				
				NumberOfpaymentsInner[COMPLETED_PAYMENTS] += Count;
			}
			else if (sStatus.equals(MessageConstantsInterface.MESSAGE_STATUS_REJECTED)){
				NumberOfpaymentsInner[REJECTED_PAYMENTS] += Count ;
			}
			else{
				NumberOfpaymentsInner[REST_OF_PAYMENTS] += Count;
			}
		}		
	} catch (Throwable e) {												
								
		String error = "Failed decrypting file:  and stop the upload process. " + "Exception from class: " + e.getClass().getName();
		logger.error(error,e);
	}finally{
		m_dao.releaseResources(rs, ps, conn);
	}
	
	
	return NumberOfpaymentsInner;
}
}
