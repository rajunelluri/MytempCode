
package backend.paymentprocess.flow.g3.responsetimeout;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.paymentprocess.flow.base.FlowName;
import backend.paymentprocess.flow.responsetimeout.DefaultRequestResponseOnTimeoutFlow;
import backend.paymentprocess.flowstep.FlowStep;
import backend.paymentprocess.flowstep.g3.responsetimeout.G3OnTimeoutSteps;
import backend.paymentprocess.flowstep.responsetimeout.OnTimeoutSteps;
import backend.paymentprocess.flowstepselector.AbstractStepSelector;
import backend.paymentprocess.flowstepselector.StepSelector;

public class G3RequestResponseOnTimeoutFlow extends DefaultRequestResponseOnTimeoutFlow {
	private static final Logger logger = LoggerFactory.getLogger(G3RequestResponseOnTimeoutFlow.class);
	
	@Override
	public FlowName getFlowName() {		
		return FlowName.G3RequestResponseOnTimeoutFlow;
	}
	
	@Override
	public StepSelector getStepSelector() {
		return new AbstractStepSelector() {
			@Override
			public FlowStep[] getSteps() {
				return new FlowStep[] {
					 new OnTimeoutSteps.EnsureNotFinalStatus()
					,new OnTimeoutSteps.IncreaseInterfaceFailureCounter()
				    ,new OnTimeoutSteps.UpdateInterfaceMonitor()
					,new OnTimeoutSteps.ApplyRetry()
					,new G3OnTimeoutSteps.AfterAllRetries() 
					,new OnTimeoutSteps.SavePDO()
				};
			}	
		};
	}
	
	@Override
	public Logger getLogger() {
		return logger;
	}	
}
