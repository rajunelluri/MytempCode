package backend.paymentprocess.flow.g3.ocbc.ct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.core.module.MessageConstantsInterface;
import backend.paymentprocess.flow.base.FlowName;
import backend.paymentprocess.flow.g3.ocbc.OCBCAbstractFlow;
import backend.paymentprocess.flowstep.FlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.CreditAccountSelectionFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.CreditPartyDerivationFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.DebitAccountSelectionFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.DepartmentSelectionFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.DuplicateCheckFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.FormatOutAndTransmissionFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.MOPSelectionFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.MessageReceivedNotificationFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.RepairAndEnrichedFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.STPValidationFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.SetCompleteFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.WarehousingFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.postingandfeeslogic.CTBookPostingAndFeesLogicFlowStep;
import backend.paymentprocess.flowstepselector.AbstractStepSelector;
import backend.paymentprocess.flowstepselector.StepSelector;
import backend.paymentprocess.flowstepselector.ocbc.ManualCreateCTBookStepSelector;

import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.util.GlobalConstants;

public class CTBook extends OCBCAbstractFlow {

	@Override
	protected Feedback preFlow(Feedback feedback) {
		super.preFlow(feedback);
		getFlowPdo().set(D_G3_IMMEDIATE_FLOW_NAME, FlowName.G3CTBook);
		getFlowPdo().set(D_FLOW_CONTEXT, MAIN_FLOW);
		getFlowPdo().set(P_MSG_CLASS, MSG_CLASS_PAY);//until payment classification rule is invoked
		getFlowPdo().set(P_BASE_AMT, getFlowPdo().get(OX_STTLM_AMT));
		getFlowPdo().set(P_BASE_CCY, getFlowPdo().getNSetOffice().getCurrency());
		getFlowPdo().set(P_BUSINESS_FLOW_TP, GlobalConstants.RT);
		
		return feedback;
	}

	@Override
	public StepSelector getStepSelector() 
	{
		if (GlobalConstants.CREATE.equalsIgnoreCase(getFlowPdo().getString(PDOConstantFieldsInterface.P_PMNT_SRC)) &&
			(MessageConstantsInterface. MESSAGE_STATUS_RECEIVED.equalsIgnoreCase(getFlowPdo().getString(PDOConstantFieldsInterface.P_MSG_STS)) ||
			 MessageConstantsInterface.   MESSAGE_STATUS_REPAIR.equalsIgnoreCase(getFlowPdo().getString(PDOConstantFieldsInterface.P_MSG_STS)) ||
			 MessageConstantsInterface.   MESSAGE_STATUS_VERIFY.equalsIgnoreCase(getFlowPdo().getString(PDOConstantFieldsInterface.P_MSG_STS)) ||
			 MessageConstantsInterface.MESSAGE_STATUS_TIME_HOLD.equalsIgnoreCase(getFlowPdo().getString(PDOConstantFieldsInterface.P_MSG_STS)) ||
			 MessageConstantsInterface.APPROVE_CHANGE_HOLDTIME.equalsIgnoreCase(getFlowPdo().getString(PDOConstantFieldsInterface.P_MSG_STS)))) 
		{
			return new ManualCreateCTBookStepSelector(getFlowPdo().getString(PDOConstantFieldsInterface.P_MSG_STS));
		}
		else
		{
			return new AbstractStepSelector() 
			{
				@Override
				public FlowStep[] getSteps() 
				{
					return new FlowStep[]
					{
					       new MessageReceivedNotificationFlowStep(), 
					       new DepartmentSelectionFlowStep(), 
					       new WarehousingFlowStep(),
					       new RepairAndEnrichedFlowStep(), 
					       new STPValidationFlowStep(), 
					       new DuplicateCheckFlowStep(), 
					       new DebitAccountSelectionFlowStep(),
					       new CreditPartyDerivationFlowStep(), 
					       new CreditAccountSelectionFlowStep(), 
					       new MOPSelectionFlowStep(), 
					       new CTBookPostingAndFeesLogicFlowStep(), 
					       new SetCompleteFlowStep(), 
						   new FormatOutAndTransmissionFlowStep()};
				}
			};
		}
	}

	@Override
	public Logger getLogger() {
		return LoggerFactory.getLogger(CTBook.class);
	}

	@Override
	public String getFailureStatus() {
		return MESSAGE_STATUS_REJECTED;
	}

	@Override
	public FlowName getFlowName() {
		flowName = FlowName.G3CTBook;
		return flowName;
	}

}
