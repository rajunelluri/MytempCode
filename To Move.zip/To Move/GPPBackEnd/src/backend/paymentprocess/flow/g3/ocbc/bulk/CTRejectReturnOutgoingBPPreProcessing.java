package backend.paymentprocess.flow.g3.ocbc.bulk;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.paymentprocess.flow.base.FlowName;
import backend.paymentprocess.flowstep.FlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.BulkingProfileFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.CreditPartyDerivationFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.MOPValidationFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.PauseFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.feecalculation.CreditFeeCalculationFlowStep;
import backend.paymentprocess.flowstepselector.AbstractStepSelector;
import backend.paymentprocess.flowstepselector.StepSelector;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.datacomponent.response.Feedback;

public class CTRejectReturnOutgoingBPPreProcessing  extends BulkPreProcessingFlow{
	final String CTOUTGOING_REJECT_RETURN_BP_PREPROCESSING_FLOW_START = "Starting BP Pre-Processing flow for Outgoing reject return of credit transfer , MID: {}";

	@Override
	public StepSelector getStepSelector() {
		return new AbstractStepSelector(){
			@Override
			public FlowStep[] getSteps(){
				return new FlowStep[] { 
						new CreditPartyDerivationFlowStep(),
						new MOPValidationFlowStep(),
						new BulkingProfileFlowStep(),
						new CreditFeeCalculationFlowStep(),
						new PauseFlowStep()
				};
			}
		};
	}

	@Override
	public Logger getLogger() {
		return LoggerFactory.getLogger(CTRejectReturnOutgoingBPPreProcessing.class);
	}

	@Override
	public String getFailureStatus() {
		return MESSAGE_STATUS_REJECTED;
	}

	@Override
	protected Feedback preFlow(Feedback feedback) {
		super.preFlow(feedback);
		PDO pdo = getFlowPdo();
		super.configufeFlow(pdo);

		logger.info(CTOUTGOING_REJECT_RETURN_BP_PREPROCESSING_FLOW_START,pdo.getMID());
		//TODO GALIT: Check if needed..
		pdo.set(D_G3_IMMEDIATE_FLOW_NAME, getFlowName());
		pdo.set(OX_BTCH_BOOKG, new Boolean(false));			// do not create message
		pdo.set(P_CDT_AMT, pdo.get(OX_STTLM_AMT)); // in fee calc, we set X_STTLM_AMT with P_CDT_AMT so it has to be populated with the amount 
		pdo.set(P_ORIG_INSTR_ID, pdo.getString(OX_INSTR_ID));
		return feedback;
	}

	@Override
	public FlowName getFlowName() {
		flowName = FlowName.G3CTPreProcessingRejectReturnOutgoing;
		return flowName;
	}

}
