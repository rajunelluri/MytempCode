package backend.paymentprocess.flow.g3.ocbc.bulk;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.core.paymentprocess.errorhandling.ProcessError;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.errors.ProcessErrorConstants;

import backend.paymentprocess.erroraudit.ErrorAuditUtils;
import backend.paymentprocess.flow.base.FlowName;
import backend.paymentprocess.flowstep.FlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.CreditAccountSelectionFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.DebitAccountDerivationFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.MOPSelectionFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.RReturnRejectIndexMatchingCheckFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.feecalculation.CreditFeeCalculationFlowStep;
import backend.paymentprocess.flowstepselector.AbstractStepSelector;
import backend.paymentprocess.flowstepselector.StepSelector;

public class CTRejectReturnIncomingBPPreProcessingManualMatch extends BulkPreProcessingFlow
{

	@Override
	public StepSelector getStepSelector() {
		return new AbstractStepSelector(){
			@Override
			public FlowStep[] getSteps(){
			return new FlowStep[] { 
					new RReturnRejectIndexMatchingCheckFlowStep(), 
					new DebitAccountDerivationFlowStep(),	
					new CreditAccountSelectionFlowStep(), 
					new MOPSelectionFlowStep(),
					new CreditFeeCalculationFlowStep()
				};
			}
		};
	}

	@Override 
	public Feedback postFlow(Feedback feedback) {
		if (feedback.isSuccessful())
		{
			PDO pdo = getFlowPdo();
			pdo.set(P_MSG_STS, MESSAGE_STATUS_COMPLETE);

			PDO pdoOriginalPayment = pdo.getLinkedMsg(RELATION_TYPE_ORIGINAL_PAYMENT);
			if (pdoOriginalPayment != null)
			{
				String sOriginalOldMessageStatus = pdoOriginalPayment.getString(P_MSG_STS);
				pdoOriginalPayment.set(P_MSG_STS, MESSAGE_STATUS_RETURNED);
		
				ProcessError processError = new ProcessError(ProcessErrorConstants.MessageStatusChanged, new Object[]{sOriginalOldMessageStatus,MESSAGE_STATUS_RETURNED});
				ErrorAuditUtils.setErrors(processError, pdoOriginalPayment);
				
				try {
					PaymentDataFactory.batchSave(true, pdoOriginalPayment);
				} catch (Throwable e) {
					logger.error("fail to save pdo, mid = {} with error: ",pdoOriginalPayment.getMID(),e.getMessage());	
					feedback.setException(e);
				}
			}
		}
	
		return feedback;
	}
	
	@Override
	public Logger getLogger()
	{
		return LoggerFactory.getLogger(CTRejectReturnIncomingBPPreProcessingManualMatch.class);
	}

	@Override
	public String getFailureStatus()
	{
		return MESSAGE_STATUS_REJECTED;
	}

	@Override
	public FlowName getFlowName()
	{
		flowName = FlowName.G3CTPreProcessingRejectReturnIncomingManualMatch;
		return flowName;
	}

}
