package backend.paymentprocess.flow.g3.ocbc.notification;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.core.module.MessageConstantsInterface;
import backend.paymentprocess.erroraudit.ErrorAuditUtils;
import backend.paymentprocess.flow.base.FlowName;
import backend.paymentprocess.flow.g3.ocbc.OCBCAbstractFlow;
import backend.paymentprocess.flowstepselector.StepSelector;
import backend.paymentprocess.flowstepselector.ocbc.CTNotificationAcceptStepSelector;
import backend.paymentprocess.flowstepselector.ocbc.CTSplitNotificationAcceptStepSelector;
import backend.paymentprocess.flowstepselector.ocbc.NotificationRejectStepSelector;
import backend.paymentprocess.flowstepselector.ocbc.NotificationSplitRejectStepSelector;
import backend.paymentprocess.messagenotification.common.NotificationTypeType;
import backend.util.ServerConstants;

import com.fundtech.annotations.Wrap;
import com.fundtech.cache.entities.Errcodes;
import com.fundtech.cache.entities.WebSessionInfo;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.core.paymentprocess.errorhandling.ProcessError;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.errors.ProcessErrorConstants;
import com.fundtech.util.GlobalConstants;

@Wrap
public class CTNotificationFlow extends OCBCAbstractFlow {

	@Override
	protected Feedback preFlow(Feedback feedback) {
		super.preFlow(feedback);
		PDO flowPdo = getFlowPdo();
		String confirmationFlow = flowPdo.getString(PDOConstantFieldsInterface.D_CONFIRMATION_FLOW);

		flowPdo.set(D_G3_IMMEDIATE_FLOW_NAME, FlowName.G3CTNotificaition);
		flowPdo.set(P_MSG_CLASS, MSG_CLASS_PAY);//until payment classification rule is invoked

		if (NotificationTypeType.ACTC.name().equals(confirmationFlow))
		{//ACTC
			flowPdo.set(D_FLOW_CONTEXT, ACCEPT_FLOW);
		}
		else if (NotificationTypeType.RJCT.name().equals(confirmationFlow))
		{//RJCT
			flowPdo.set(D_FLOW_CONTEXT, REJECTION_FLOW);
			flowPdo.set(PDOConstantFieldsInterface.D_IS_EC_CALL_NOT_REQUIRED, true) ;
			
			ProcessError pError;
			if (flowPdo.getString(PDOConstantFieldsInterface.D_BUTTON_ID) !=null)
			{
				
				//This the case ForceReject was pressed by user while message was in timeout queue 
				WebSessionInfo webSessionInfo = Admin.getContextAdmin().getNSetWebSessionInfo();
				String userId = webSessionInfo.getUserID();
				pError=new ProcessError(ProcessErrorConstants.PaymentForceRejected,new Object[] {flowPdo.getString(PDOConstantFieldsInterface.P_TX_CTGY), userId}); 	
				flowPdo.set(PDOConstantFieldsInterface.P_MSG_STS, MessageConstantsInterface.MESSAGE_STATUS_REJECTED);
				
			}
			else 
			{//In case of a RJCT we leave it to the user to decide if to Cancel the payment and do reverse accounting, if required, or to Resent it.
				String contents =null;
				Errcodes errcode = null;
	
				String mop = flowPdo.getString(PDOConstantFieldsInterface.P_CDT_MOP);
				
				errcode= CacheKeys.errcodesKey.getSingle(ServerConstants.DEFAULT_SERVER_OFFICE_NAME, mop
						, flowPdo.getString(PDOConstantFieldsInterface.X_MOP_NOTIFICATION_MSG_TYPE),  flowPdo.getString(PDOConstantFieldsInterface.X_RJCT_RSN));
	
				if (errcode == null){
					errcode= CacheKeys.errcodesKey.getSingle(ServerConstants.DEFAULT_SERVER_OFFICE_NAME, null
							, flowPdo.getString(PDOConstantFieldsInterface.X_MOP_NOTIFICATION_MSG_TYPE),  flowPdo.getString(PDOConstantFieldsInterface.X_RJCT_RSN));
				}
	
				contents = errcode != null ? errcode.getContents() : GlobalConstants.EMPTY_STRING;
	
				pError=new ProcessError(ProcessErrorConstants.PaymentRejected,flowPdo.getMID(), null,new Object[]{mop,contents}); 
			}
			ErrorAuditUtils.setErrors(pError);
			
	        // Load related S-payment and update UDF fields for ROF fees calculation
	        final String S_MESSAGE_TYPE = "P_BATCH_MSG_TP = 'S'";
	        String sInInternalFileId = flowPdo.getString(PDOConstantFieldsInterface.P_IN_INTERNAL_FILEID);
	        String sChunkId = flowPdo.getString(PDOConstantFieldsInterface.P_CHUNK_ID);
	        String sUniqueGroupingId = flowPdo.getString(PDOConstantFieldsInterface.P_UNIQUE_GROUPING_ID);
	        Integer sIsHistoryValue = flowPdo.getIsHistory();
	        
	     	List<PDO> sPaymentList = PaymentDataFactory.load(sInInternalFileId, sChunkId, sUniqueGroupingId, sIsHistoryValue, S_MESSAGE_TYPE);
	     	PDO sPaymentPDO = (sPaymentList!=null && !sPaymentList.isEmpty()) ? sPaymentList.toArray(new PDO[]{})[0] : null;
	        if(sPaymentPDO!=null)
	        {
	        	flowPdo.set(PDOConstantFieldsInterface.U_DBT_CIF_TYPE, sPaymentPDO.getString(PDOConstantFieldsInterface.U_DBT_CIF_TYPE));
	        	flowPdo.set(PDOConstantFieldsInterface.U_DBT_SEG_CODE, sPaymentPDO.getString(PDOConstantFieldsInterface.U_DBT_SEG_CODE));
	        }
		}
		
		return feedback;
	}

	@Override
	public StepSelector getStepSelector() {
		String confirmationFlow = getFlowPdo().getString(PDOConstantFieldsInterface.D_CONFIRMATION_FLOW);
		//if user forced accept/reject from timeout save the ack status to DB
		if (getFlowPdo().getString(PDOConstantFieldsInterface.D_BUTTON_ID) !=null &&
				getFlowPdo().getString(PDOConstantFieldsInterface.P_PMNT_SRC).equals(MessageConstantsInterface.PMNT_SRC_LOANS)){
			getFlowPdo().set(PDOConstantFieldsInterface.P_ACK_STS,confirmationFlow);
		}
		
		if(getFlowPdo().getString(PDOConstantFieldsInterface.P_PMNT_SRC).equals(MessageConstantsInterface.PMNT_SRC_LOANS) && IsPaymentisASplitChild(getFlowPdo())){
			if (NotificationTypeType.ACTC.name().equals(confirmationFlow)){
				return new CTSplitNotificationAcceptStepSelector();
			}else if (NotificationTypeType.RJCT.name().equals(confirmationFlow)){
				return new NotificationSplitRejectStepSelector();   
			}
		}
		else if (NotificationTypeType.ACTC.name().equals(confirmationFlow)){
			return new CTNotificationAcceptStepSelector();
		}else if (NotificationTypeType.RJCT.name().equals(confirmationFlow)){
			return new NotificationRejectStepSelector();   
		}
		return null;
	}

	private boolean IsPaymentisASplitChild(PDO flowPdo) {
		boolean isMultipleSplit = false;
		if (flowPdo.get(PDOConstantFieldsInterface.MF_SPLIT_STATUS) != null && flowPdo.get(PDOConstantFieldsInterface.MF_SPLIT_STATUS).equals(MessageConstantsInterface.MONITOR_FLAG_CHILD)){
			isMultipleSplit = true;
		}
		return isMultipleSplit;
	}

	@Override
	public Logger getLogger() {
		return LoggerFactory.getLogger(CTNotificationFlow.class);
	}

	@Override
	public String getFailureStatus() {
		return MESSAGE_STATUS_REJECTED;
	}

	@Override
	public FlowName getFlowName() {
		flowName = FlowName.G3CTNotificaition;
		return flowName;
	}

}
