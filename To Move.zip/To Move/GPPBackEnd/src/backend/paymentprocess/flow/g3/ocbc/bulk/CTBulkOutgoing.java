package backend.paymentprocess.flow.g3.ocbc.bulk;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.paymentprocess.flow.base.FlowName;
import backend.paymentprocess.flowstepselector.StepSelector;
import backend.paymentprocess.flowstepselector.ocbc.CTBulkOutgoingStepSelector;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.datacomponent.response.Feedback;

public class CTBulkOutgoing extends BulkFlow{

	@Override
	protected Feedback preFlow(Feedback feedback) {
		super.preFlow(feedback);
		PDO pdo = getFlowPdo();

		super.configufeFlow(pdo);

		pdo.set(D_FLOW_CONTEXT, BULK_MAIN_FLOW);
		pdo.set(D_G3_IMMEDIATE_FLOW_NAME, getFlowName());
		pdo.set(P_MSG_CLASS, MSG_CLASS_PAY);//until payment classification rule is invoked			
		pdo.set(P_BASE_AMT, pdo.get(OX_STTLM_AMT));
		pdo.set(P_BASE_CCY, pdo.getNSetOffice().getCurrency());

		// since bulk individual has no debt account derivation, this is needed for principle reversal posting
		pdo.set(P_DBT_AMT, pdo.getDecimal(OX_STTLM_AMT));
		return feedback;
	}

	@Override
	public StepSelector getStepSelector() {
		return new CTBulkOutgoingStepSelector(getFlowPdo());
	}

	@Override
	public Logger getLogger() {
		return LoggerFactory.getLogger(CTBulkOutgoing.class);
	}

	@Override
	public String getFailureStatus() {
		return MESSAGE_STATUS_REJECTED;
	}

	@Override
	public FlowName getFlowName() {
		flowName = FlowName.G3CTOutgoing;
		return flowName;
	}

}
