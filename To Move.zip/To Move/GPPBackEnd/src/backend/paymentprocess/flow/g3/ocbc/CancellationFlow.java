package backend.paymentprocess.flow.g3.ocbc;

import static backend.paymentprocess.flow.base.FlowName.G3CancellationFlow;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.paymentprocess.flow.base.FlowName;
import backend.paymentprocess.flowstepselector.StepSelector;
import backend.paymentprocess.flowstepselector.ocbc.CancellationStepSelector;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.util.GlobalConstants;

public class CancellationFlow extends OCBCAbstractFlow {
	final String TRACE_PERFORM_CANCELLATION_MESSAGE_HANDLING_PROCESS_INPUT = "executeCancellationFlow input - MID: {}, Incoming Message: {}, P_MSG_TYPE: {}, Initial P_MSG_STS: {}";
	
	@Override
	protected Feedback preFlow(Feedback feedback) {
		super.preFlow(feedback);
		PDO pdo = getFlowPdo();
		boolean bIncomingMessage = pdo.isIncomingMessage();
		
		pdo.set(P_MSG_STS, MESSAGE_STATUS_RECEIVED);
		pdo.set(D_G3_IMMEDIATE_FLOW_NAME, getFlowName());
		pdo.set(PDOConstantFieldsInterface.D_TRIGGERED_RELATION_TYPE, RELATION_TYPE_INCOMING_CANCELLATION_REQUEST);
		pdo.set(D_FLOW_CONTEXT, REJECTION_FLOW);
		pdo.set(P_BUSINESS_FLOW_TP, GlobalConstants.RT);

		
		//since in BOSetBasicProperties X_INSTD_AGT_BIC_2AND is set to null, take the orig field and set it to X_INSTD_AGT_BIC_2AND
		pdo.set(X_INSTD_AGT_BIC_2AND, pdo.getString(OX_INSTD_AGT_BIC_2AND));
		
		logger.info(TRACE_PERFORM_CANCELLATION_MESSAGE_HANDLING_PROCESS_INPUT,  new Object[]{pdo.getMID(), bIncomingMessage, pdo.getString(P_MSG_TYPE), pdo.getString(P_MSG_STS)});
		
		return feedback;
	}

	@Override
	public StepSelector getStepSelector() {
		return new CancellationStepSelector();
	}

	@Override
	public Logger getLogger() {
		return LoggerFactory.getLogger(CancellationFlow.class);
	}

	@Override
	public String getFailureStatus() {
		return MESSAGE_STATUS_SERVICE_RELEASE;
	}

	@Override
	public FlowName getFlowName() {
		flowName = G3CancellationFlow;
		return flowName;
	}
}
