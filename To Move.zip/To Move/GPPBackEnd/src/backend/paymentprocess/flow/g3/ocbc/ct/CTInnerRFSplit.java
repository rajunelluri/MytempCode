package backend.paymentprocess.flow.g3.ocbc.ct;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import backend.paymentprocess.flow.base.FlowName;
import backend.paymentprocess.flow.g3.ocbc.OCBCAbstractFlow;
import backend.paymentprocess.flowstep.FlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.PauseFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.PostingFlowStep;
import backend.paymentprocess.flowstepselector.AbstractStepSelector;
import backend.paymentprocess.flowstepselector.StepSelector;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.util.GlobalConstants;

public class CTInnerRFSplit extends OCBCAbstractFlow {

	@Override
	public FlowName getFlowName() {		
		flowName = FlowName.CTFinalParentSplit;
		return flowName;
	}		
	
	@Override
	public String getFailureStatus() {
		return MESSAGE_STATUS_REJECTED;
	}
	
	@Override
	public Logger getLogger() {
		return LoggerFactory.getLogger(CTFinalParentSplit.class);		
	}
	
	@Override
	public StepSelector getStepSelector() {
		return new AbstractStepSelector(){
			@Override
			public FlowStep[] getSteps(){
				return new FlowStep[]{ 
						new PostingFlowStep(),
						new PauseFlowStep()};
			}
		};
	}

	@Override
	protected Feedback preFlow(Feedback feedback)  {
		super.preFlow(feedback);
		PDO pdo = getFlowPdo();

		pdo.set(D_G3_IMMEDIATE_FLOW_NAME, flowName);
		pdo.set(D_FLOW_CONTEXT, RF_PAYMENT_FLOW);
		pdo.set(P_MSG_CLASS, MSG_CLASS_PAY);// until payment classification rule is invoked
		pdo.set(P_BASE_AMT, pdo.get(OX_STTLM_AMT));
		pdo.set(P_BASE_CCY, pdo.getNSetOffice().getCurrency());
		pdo.set(P_BUSINESS_FLOW_TP, GlobalConstants.RT);

		return feedback;
	}

}
