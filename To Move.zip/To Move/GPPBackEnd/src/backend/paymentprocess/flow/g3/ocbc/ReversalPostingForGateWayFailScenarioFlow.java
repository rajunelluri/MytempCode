package backend.paymentprocess.flow.g3.ocbc;

import static com.fundtech.util.GlobalConstants.LOANS;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.paymentprocess.flow.base.FlowName;
import backend.paymentprocess.flowstepselector.StepSelector;
import backend.paymentprocess.flowstepselector.ocbc.NotificationSplitRejectStepSelector;
import backend.paymentprocess.flowstepselector.ocbc.RejectIndividualGateWayScenarioStepSelector;
import backend.paymentprocess.messagenotification.common.NotificationTypeType;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.util.GlobalConstants;

public class ReversalPostingForGateWayFailScenarioFlow extends OCBCAbstractFlow {
	
	@Override
	public StepSelector getStepSelector() {
		if (LOANS.equalsIgnoreCase(getFlowPdo().getString(P_PMNT_SRC))) {
			return new NotificationSplitRejectStepSelector();
		}else{	
		return new RejectIndividualGateWayScenarioStepSelector();
		}
	}
	
	@Override
	public String getFailureStatus() {
		return MESSAGE_STATUS_POST_EXCEPTION;
	}
	
	@Override
	public FlowName getFlowName() {
		if (LOANS.equalsIgnoreCase(getFlowPdo().getString(P_PMNT_SRC))) {
			flowName = FlowName.G3CTNotificaition;
		} else {
		flowName =FlowName.G3ReversePostingForGatewayDown;
		}
		return flowName;
	}
	
	@Override
	protected Feedback preFlow(Feedback feedback)  {
		super.preFlow(feedback);
		PDO pdo = getFlowPdo();
		if (LOANS.equalsIgnoreCase(pdo.getString(P_PMNT_SRC))) {
			pdo.set(D_G3_IMMEDIATE_FLOW_NAME, flowName);
			pdo.set(D_FLOW_CONTEXT, REJECTION_FLOW);
			pdo.set(P_MSG_CLASS, MSG_CLASS_PAY);// until payment classification rule is invoked
			pdo.set(P_ACK_STS, NotificationTypeType.RJCT.name());
			pdo.set(P_BASE_AMT, pdo.get(OX_STTLM_AMT));
			pdo.set(P_BASE_CCY, pdo.getNSetOffice().getCurrency());
			pdo.set(P_BUSINESS_FLOW_TP, GlobalConstants.RT);
		}

		return feedback;
	}
	
	@Override
	public Logger getLogger() {
		return LoggerFactory.getLogger(ReversalPostingForGateWayFailScenarioFlow.class);
	}
}
