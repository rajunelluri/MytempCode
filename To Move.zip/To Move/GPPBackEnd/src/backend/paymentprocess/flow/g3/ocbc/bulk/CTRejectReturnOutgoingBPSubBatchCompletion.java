package backend.paymentprocess.flow.g3.ocbc.bulk;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.paymentprocess.flow.base.FlowName;
import backend.paymentprocess.flowstep.FlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.FormatOutFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.MOPValidationFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.PauseFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.SetCompleteFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.feecalculation.DebitFeeCalculationFlowStep;
import backend.paymentprocess.flowstepselector.AbstractStepSelector;
import backend.paymentprocess.flowstepselector.StepSelector;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.datacomponent.response.Feedback;

public class CTRejectReturnOutgoingBPSubBatchCompletion  extends BulkPreProcessingFlow{
	final String DDOUTGOING_REJECT_RETURN_BP_SUBBATCHCOMPLETION_FLOW_START = "Starting BP Sub-Batch Completion flow for Outgoing reject return of debit transfer , MID: {}";

	@Override
	public StepSelector getStepSelector() {
		return new AbstractStepSelector(){
			@Override
			public FlowStep[] getSteps(){
				return new FlowStep[] { 
						new SetCompleteFlowStep(),
						new FormatOutFlowStep()
				};
			}
		};
	}

	@Override
	public Logger getLogger() {
		return LoggerFactory.getLogger(CTRejectReturnOutgoingBPSubBatchCompletion.class);
	}

	@Override
	public String getFailureStatus() {
		return MESSAGE_STATUS_REJECTED;
	}

	@Override
	protected Feedback preFlow(Feedback feedback) {
		super.preFlow(feedback);
		PDO pdo = getFlowPdo();
		super.configufeFlow(pdo);
		
		logger.info(DDOUTGOING_REJECT_RETURN_BP_SUBBATCHCOMPLETION_FLOW_START,pdo.getMID());

		return feedback;
	}

	@Override
	public FlowName getFlowName() {
		flowName = FlowName.G3DDSubBatchCompletionRejectReturnOutgoing;
		return flowName;
	}


}
