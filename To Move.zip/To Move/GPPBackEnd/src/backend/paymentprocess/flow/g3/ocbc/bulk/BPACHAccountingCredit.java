package backend.paymentprocess.flow.g3.ocbc.bulk;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.paymentprocess.flow.base.AbstractFlow;
import backend.paymentprocess.flow.base.FlowName;
import backend.paymentprocess.flowstepselector.StepSelector;
import backend.paymentprocess.flowstepselector.ocbc.BPACHAccountingCreditStepSelector;

import com.fundtech.datacomponent.response.Feedback;

public class BPACHAccountingCredit  extends AbstractFlow{
	
	@Override
	public StepSelector getStepSelector() {
		return new BPACHAccountingCreditStepSelector();
	}

	@Override
	protected Feedback preFlow(Feedback feedback) {
		getFlowPdo().set(D_FLOW_CONTEXT, BULK_ACCOUNTING_MSG_FLOW);
		getFlowPdo().set(D_G3_IMMEDIATE_FLOW_NAME, getFlowName());
		getFlowPdo().set(P_DBT_MOP, "BOOK");
		getFlowPdo().set(P_CDT_MOP, "BOOK");
		Object valueTime = getFlowPdo().get(D_BULK_SUBBATCH_VALUE_TIME);
		if(valueTime != null)
			getFlowPdo().set(UDF_SYSTEM_VALUE_TIME, getFlowPdo().get(D_BULK_SUBBATCH_VALUE_TIME));//until payment classification rule is invoked
		
		return feedback;

	}

	@Override
	public Logger getLogger() {
		return LoggerFactory.getLogger(BPACHAccountingCredit.class);
	}

	@Override
	public String getFailureStatus() {
		return MESSAGE_STATUS_REJECTED;
	}

	@Override
	public FlowName getFlowName() {
		flowName = FlowName.G3ACHAccountingCredit;
		return flowName;
	}

}
