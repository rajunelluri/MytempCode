package backend.paymentprocess.flow.g3.ocbc.bulk;

import java.math.BigDecimal;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.util.GlobalUtils;

import backend.paymentprocess.flow.base.FlowName;
import backend.paymentprocess.flowstepselector.StepSelector;
import backend.paymentprocess.flowstepselector.ocbc.DDBulkOutgoingNoSubBatchStepSelector;

public class DDBulkOutgoingNoSubBatch extends BulkFlow{

	@Override
	public StepSelector getStepSelector() {
		return new DDBulkOutgoingNoSubBatchStepSelector(getFlowPdo());
	}

	@Override
	protected Feedback preFlow(Feedback feedback) {		
		super.preFlow(feedback);
		PDO pdo = getFlowPdo();

		pdo.set(D_FLOW_CONTEXT, MAIN_FLOW);
		pdo.set(D_G3_IMMEDIATE_FLOW_NAME, getFlowName());
		pdo.set(P_MSG_CLASS, MSG_CLASS_DD);//until payment classification rule is invoked			
		pdo.set(P_BASE_AMT, pdo.get(OX_STTLM_AMT));		
		pdo.set(P_BASE_CCY, pdo.getNSetOffice().getCurrency());

		//Defect 50545  -  needed for non fee step flows
		BigDecimal sttlmAmount = getFlowPdo().getDecimal(X_STTLM_AMT);
		String ccy = getFlowPdo().getString(P_BASE_CCY);
		if (sttlmAmount != null && sttlmAmount.doubleValue() != 0 && ccy != null){			//Defect #44450
			sttlmAmount = GlobalUtils.adjustPrecisionBD(sttlmAmount.doubleValue(), GlobalUtils.getPrecision(ccy)); 
			getFlowPdo().set(X_STTLM_AMT,sttlmAmount);
		}

		return feedback;
	}
	
	@Override
	public Logger getLogger() {
		return LoggerFactory.getLogger(DDBulkOutgoingNoSubBatch.class);
	}

	@Override
	public String getFailureStatus() {
		return MESSAGE_STATUS_REJECTED;
	}

	@Override
	public FlowName getFlowName() {
		flowName = FlowName.G3DDOutgoing;
		return flowName;
	}
}
