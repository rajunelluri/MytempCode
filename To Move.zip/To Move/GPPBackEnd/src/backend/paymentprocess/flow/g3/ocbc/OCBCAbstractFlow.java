package backend.paymentprocess.flow.g3.ocbc;

import backend.businessobject.tx.SpringTransactionProxy;
import backend.paymentprocess.contingency.ContingencyLogLastResource;
import backend.paymentprocess.flow.base.AbstractFlow;
import backend.paymentprocess.ocbc.contingency.PostingContingencyLogLastResource;

import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;

public abstract class OCBCAbstractFlow extends AbstractFlow {
	
	
	/**
	 * Set last resource to include posting info in case of an exception
	 */
	@Override
	protected Feedback preFlow(Feedback feedback) {
		try{
			Admin.getContextAdmin().registerLastResourcesHandler(SpringTransactionProxy.m_txWrapper.get(), false/*bFailIfHandlerAlreadyExists*/);
			Admin.getContextAdmin().registerLastResource(new PostingContingencyLogLastResource());
			Admin.getContextAdmin().removeLastResource(ContingencyLogLastResource.class.getName());
		}catch (Throwable e) {
			  logger.error("Failed to register last resource",e);
		}
		return feedback;
	}



}
