package backend.paymentprocess.flow.g3.ocbc.bulk;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.paymentprocess.flow.base.FlowName;
import backend.paymentprocess.flowstepselector.StepSelector;
import backend.paymentprocess.flowstepselector.ocbc.DDBulkBookNoSubBatchStepSelector;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.datacomponent.response.Feedback;

public class DDBulkBookNoSubBatch extends BulkFlow {

	@Override
	protected Feedback preFlow(Feedback feedback) {
		super.preFlow(feedback);
		PDO pdo = getFlowPdo();

		super.configufeFlow(pdo);
		
		pdo.set(D_FLOW_CONTEXT, MAIN_FLOW);
		pdo.set(P_MSG_CLASS, MSG_CLASS_DD);//until payment classification rule is invoked			
		pdo.set(P_BASE_AMT, pdo.get(OX_STTLM_AMT));
		pdo.set(P_BASE_CCY, pdo.getNSetOffice().getCurrency());

		return feedback;		
	}

	@Override
	public StepSelector getStepSelector() {
		return new DDBulkBookNoSubBatchStepSelector(getFlowPdo());
	}

	@Override
	public Logger getLogger() {
		return LoggerFactory.getLogger(DDBulkBookNoSubBatch.class);
	}

	@Override
	public String getFailureStatus() {
		return MESSAGE_STATUS_REJECTED;
	}

	@Override
	public FlowName getFlowName() {
		flowName = FlowName.G3DDBook;
		return flowName;
	}

}
