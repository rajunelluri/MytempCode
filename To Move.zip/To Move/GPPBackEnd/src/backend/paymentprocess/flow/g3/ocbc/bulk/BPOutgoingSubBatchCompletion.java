package backend.paymentprocess.flow.g3.ocbc.bulk;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.paymentprocess.flow.base.FlowName;
import backend.paymentprocess.flowstep.FlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.BulkingProfileFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.FormatOutFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.MOPValidationFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.SetCompleteFlowStep;
import backend.paymentprocess.flowstepselector.AbstractStepSelector;
import backend.paymentprocess.flowstepselector.StepSelector;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.datacomponent.response.Feedback;

public class BPOutgoingSubBatchCompletion  extends BulkFlow{
	final String BP_SUB_BATCH_OUTGOING_COMPLETION_FLOW_START = "Starting BP Outgoing flow for Sub Batch Completion , MID: {}";
	
	@Override
	public StepSelector getStepSelector() {
		return new AbstractStepSelector(){
			@Override
			public FlowStep[] getSteps(){
			return new FlowStep[] { 
					new MOPValidationFlowStep(),
					new BulkingProfileFlowStep(),
					new SetCompleteFlowStep(),
					new FormatOutFlowStep(),
				};
			}
		};
	}

	@Override
	public Logger getLogger() {
		return LoggerFactory.getLogger(BPIncomingSubBatchCompletion.class);
	}

	@Override
	public String getFailureStatus() {
		return MESSAGE_STATUS_REJECTED;
	}

	@Override
	protected Feedback preFlow(Feedback feedback) {
		super.preFlow(feedback);
		PDO pdo = getFlowPdo();
		super.configufeFlow(pdo);
		
		logger.info(BP_SUB_BATCH_OUTGOING_COMPLETION_FLOW_START,pdo.getMID());

		return feedback;
	}

	@Override
	public FlowName getFlowName() {
		flowName = FlowName.G3BPOutgoingSubBatchCompletion;
		return flowName;
	}

}
