package backend.paymentprocess.flow.g3.ocbc.ct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.core.module.MessageConstantsInterface;
import backend.paymentprocess.flow.base.FlowName;
import backend.paymentprocess.flow.g3.ocbc.OCBCAbstractFlow;
import backend.paymentprocess.flowstep.FlowStep;
import backend.paymentprocess.flowstep.common.InstructionIdGenerationFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.CapacityCheckFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.CreditPartyDerivationFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.DebitAccountSelectionFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.DepartmentSelectionFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.DuplicateCheckFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.FormatOutAndTransmissionFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.MOPSelectionFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.MessageReceivedNotificationFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.RepairAndEnrichedFlowStep;
import backend.paymentprocess.flowstep.common.InstructionIdReGenerationFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.STPValidationFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.SpecialInstructionFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.WarehousingFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.feecalculation.DummyDebitFeeCalculationFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.postingandfeeslogic.CTODebitPostingAndFeesLogicFlowStep;
import backend.paymentprocess.flowstepselector.AbstractStepSelector;
import backend.paymentprocess.flowstepselector.StepSelector;
import backend.paymentprocess.flowstepselector.ocbc.ManualCreateCTOutgoingStepSelector;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.util.GlobalConstants;

public class CTOutgoing extends OCBCAbstractFlow {

	@Override
	public FlowName getFlowName() {		
		flowName =FlowName.G3CTOutgoing;
		return flowName;
	}

	@Override
	public String getFailureStatus() {
		return MESSAGE_STATUS_REJECTED;
	}
	
	@Override
	public Logger getLogger() {
		return LoggerFactory.getLogger(CTOutgoing.class);		
	}	
	
	@Override
	public StepSelector getStepSelector() {
		
		if (GlobalConstants.CREATE.equalsIgnoreCase(getFlowPdo().getString(PDOConstantFieldsInterface.P_PMNT_SRC))) {
			return new ManualCreateCTOutgoingStepSelector(getFlowPdo().getString(PDOConstantFieldsInterface.P_MSG_STS));
		}
		else if(MessageConstantsInterface.APPROVE_CHANGE_HOLDTIME.equalsIgnoreCase(getFlowPdo().getString(PDOConstantFieldsInterface.P_MSG_STS))
				|| MessageConstantsInterface.MESSAGE_STATUS_TIME_HOLD.equalsIgnoreCase(getFlowPdo().getString(PDOConstantFieldsInterface.P_MSG_STS))){
			return new AbstractStepSelector() {
				@Override
				public FlowStep[] getSteps() {
					return new FlowStep[]{ 
							new WarehousingFlowStep(),
							new InstructionIdReGenerationFlowStep(), 
							new MessageReceivedNotificationFlowStep(),
							new DepartmentSelectionFlowStep(),
							new RepairAndEnrichedFlowStep(), 
							new STPValidationFlowStep(), 
							new SpecialInstructionFlowStep(), 
							new DuplicateCheckFlowStep(), 
							new DebitAccountSelectionFlowStep(),
							new CreditPartyDerivationFlowStep(),  
							new MOPSelectionFlowStep(), 
							new CapacityCheckFlowStep(), 
							new DummyDebitFeeCalculationFlowStep(), 
							new CTODebitPostingAndFeesLogicFlowStep(), 
							new FormatOutAndTransmissionFlowStep() };

				}
			};
		}
		else{
			return new AbstractStepSelector() {
				@Override
				public FlowStep[] getSteps() {
					return new FlowStep[]{ new InstructionIdGenerationFlowStep(), 
							new MessageReceivedNotificationFlowStep(),
							new DepartmentSelectionFlowStep(),
							new WarehousingFlowStep(), 
							new RepairAndEnrichedFlowStep(), 
							new STPValidationFlowStep(), 
							new SpecialInstructionFlowStep(), 
							new DuplicateCheckFlowStep(), 
							new DebitAccountSelectionFlowStep(),
							new CreditPartyDerivationFlowStep(),  
							new MOPSelectionFlowStep(), 
							new CapacityCheckFlowStep(), 
							new DummyDebitFeeCalculationFlowStep(), 
							new CTODebitPostingAndFeesLogicFlowStep(), 
							new FormatOutAndTransmissionFlowStep() };

				}
			};
		}
		
		
	}

	@Override
	protected Feedback preFlow(Feedback feedback) {
		super.preFlow(feedback);
		PDO pdo = getFlowPdo();

		pdo.set(D_G3_IMMEDIATE_FLOW_NAME, flowName);
		pdo.set(D_FLOW_CONTEXT, MAIN_FLOW);
		pdo.set(P_MSG_CLASS, MSG_CLASS_PAY);// until payment classification rule is invoked
		pdo.set(P_BASE_AMT, pdo.get(OX_STTLM_AMT));
		pdo.set(P_BASE_CCY, pdo.getNSetOffice().getCurrency());
		pdo.set(P_BUSINESS_FLOW_TP, GlobalConstants.RT);

		return feedback;
	}

}
