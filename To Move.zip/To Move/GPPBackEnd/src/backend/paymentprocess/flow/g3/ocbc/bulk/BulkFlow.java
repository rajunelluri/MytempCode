
package backend.paymentprocess.flow.g3.ocbc.bulk;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.cxf.common.util.StringUtils;

import backend.paymentprocess.flow.base.AbstractFlow;
import backend.staticdata.profilehandler.ProfileConstants;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.util.GlobalDateTimeUtil;

public abstract class BulkFlow extends AbstractFlow {
	
	protected void configufeFlow(PDO pdo) {
		setBulkTimeHoldField(pdo);
	}
	
	/**
	 * sets the D_BULK_INDIVIDUAL_VALUE_TIME field which is later on used bulk to set the holdtime to
	 * the S payment
	 */
	protected void setBulkTimeHoldField(PDO pdo) {		
		getFlowPdo().set(D_BULK_INDIVIDUAL_VALUE_TIME, valueTimeToDate(getFlowPdo().getString(UDF_SYSTEM_VALUE_TIME)));
	}

	protected Date valueTimeToDate(String valueTime) {
		if (StringUtils.isEmpty(valueTime))
			return null;
		
		if(ProfileConstants.TIME_HHMMSS.equals(valueTime))
			return null;
		
		try {
			return new SimpleDateFormat(GlobalDateTimeUtil.STATIC_DATA_TIME).parse(valueTime);
		} catch (ParseException e) {
			return null;
		}		
	}
}
