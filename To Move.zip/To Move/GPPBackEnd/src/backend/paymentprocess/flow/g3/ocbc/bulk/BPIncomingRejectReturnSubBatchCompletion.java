package backend.paymentprocess.flow.g3.ocbc.bulk;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.paymentprocess.erroraudit.ErrorAuditUtils;
import backend.paymentprocess.flow.base.FlowName;
import backend.paymentprocess.flowstep.FlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.FormatOutAndTransmissionFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.SetCompleteFlowStep;
import backend.paymentprocess.flowstepselector.AbstractStepSelector;
import backend.paymentprocess.flowstepselector.StepSelector;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.core.paymentprocess.errorhandling.ProcessError;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.errors.ProcessErrorConstants;

public class BPIncomingRejectReturnSubBatchCompletion  extends BulkFlow{
	final String BP_INCOMING_REJECT_RETURN_SUB_BATCH_COMPLETION_FLOW_START = "Starting BP Incoming Reject Return flow for Sub Batch Completion , MID: {}";
	
	@Override
	public StepSelector getStepSelector() {
		return new AbstractStepSelector(){
			@Override
			public FlowStep[] getSteps(){
			return new FlowStep[] { 
					new SetCompleteFlowStep(), 
					new FormatOutAndTransmissionFlowStep()
				};
			}
		};
	}

	@Override
	public Logger getLogger() {
		return LoggerFactory.getLogger(BPIncomingRejectReturnSubBatchCompletion.class);
	}

	@Override
	public String getFailureStatus() {
		return MESSAGE_STATUS_REJECTED;
	}

	@Override
	protected Feedback preFlow(Feedback feedback) {
		super.preFlow(feedback);
		PDO pdo = getFlowPdo();
		super.configufeFlow(pdo);
		
		logger.info(BP_INCOMING_REJECT_RETURN_SUB_BATCH_COMPLETION_FLOW_START,pdo.getMID());

		return feedback;
	}

	@Override
	protected Feedback postFlow(Feedback feedback) {
		feedback = new Feedback();
		
		PDO pdo = getFlowPdo();
		PDO pdoOriginalPayment = pdo.getLinkedMsg(RELATION_TYPE_ORIGINAL_PAYMENT);
		if (pdoOriginalPayment != null)
		{
			String sOriginalOldMessageStatus = pdoOriginalPayment.getString(P_MSG_STS);
			pdoOriginalPayment.set(P_MSG_STS, MESSAGE_STATUS_RETURNED);
	
			ProcessError processError = new ProcessError(ProcessErrorConstants.MessageStatusChanged, new Object[]{sOriginalOldMessageStatus,MESSAGE_STATUS_RETURNED});
			ErrorAuditUtils.setErrors(processError, pdoOriginalPayment);
			try {
				PaymentDataFactory.batchSave(true, pdoOriginalPayment);
			} catch (Throwable e) {
				logger.error("fail to save pdo, mid = {} with error: ",pdoOriginalPayment.getMID(),e.getMessage());	
				feedback.setException(e);
			}
		}
		return feedback;
	}
	
	@Override
	public FlowName getFlowName() {
		flowName = FlowName.G3BPIncomingRejectReturnSubBatchCompletion;
		return flowName;
	}

}
