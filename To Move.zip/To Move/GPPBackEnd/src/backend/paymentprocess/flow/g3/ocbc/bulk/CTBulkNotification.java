package backend.paymentprocess.flow.g3.ocbc.bulk;


import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.paymentprocess.erroraudit.ErrorAuditUtils;
import backend.paymentprocess.flow.base.FlowName;
import backend.paymentprocess.flow.g3.ocbc.OCBCAbstractFlow;
import backend.paymentprocess.flowstepselector.StepSelector;
import backend.paymentprocess.flowstepselector.ocbc.CTBulkNotificationAcceptStepSelector;
import backend.paymentprocess.flowstepselector.ocbc.CTBulkNotificationRejectStepSelector;
import backend.paymentprocess.messagenotification.common.NotificationTypeType;
import backend.util.ServerConstants;

import com.fundtech.cache.entities.Errcodes;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.core.paymentprocess.errorhandling.ProcessError;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.errors.ProcessErrorConstants;
import com.fundtech.util.GlobalConstants;

public class CTBulkNotification extends OCBCAbstractFlow {

	@Override
	protected Feedback preFlow(Feedback feedback) {
		super.preFlow(feedback);
		PDO pdo = getFlowPdo();
		String confirmationFlow = pdo.getString(PDOConstantFieldsInterface.D_CONFIRMATION_FLOW);
		//String origMsgSts = (String)pdo.getOriginalValue(P_MSG_STS);
		pdo.set(D_G3_IMMEDIATE_FLOW_NAME, FlowName.G3CTNotificaition);
		
		pdo.set(P_MSG_CLASS, MSG_CLASS_PAY);//until payment classification rule is invoked
		
		if (NotificationTypeType.ACTC.name().equals(confirmationFlow))
		{//ACTC
			pdo.set(D_FLOW_CONTEXT, ACCEPT_FLOW);
		}
		else if (NotificationTypeType.RJCT.name().equals(confirmationFlow))
		{//RJCT
			pdo.set(D_FLOW_CONTEXT, BULK_INDIVIDUAL_REJECTION_FLOW);
			if (!NotificationTypeType.NAK.getValue().equals(pdo.getString(PDOConstantFieldsInterface.X_IS_NAK))){
				logger.info("Message Notification: handle RJCT, X_IS_NAC is empty or false, then msg status = NAK");
				pdo.set(P_MSG_STS, MESSAGE_STATUS_NAK);
			}
//			In case of a RJCT we leave it to the user to decide if to Cancel the payment and do reverse accounting, if required, or to Resent it.
			String contents =null;
			Errcodes errcode = null;
			String mop = pdo.getString(PDOConstantFieldsInterface.P_CDT_MOP);

			errcode= CacheKeys.errcodesKey.getSingle(ServerConstants.DEFAULT_SERVER_OFFICE_NAME, mop
					, pdo.getString(PDOConstantFieldsInterface.X_MOP_NOTIFICATION_MSG_TYPE),  pdo.getString(PDOConstantFieldsInterface.X_RJCT_RSN));
			
			if (errcode == null){
				errcode= CacheKeys.errcodesKey.getSingle(ServerConstants.DEFAULT_SERVER_OFFICE_NAME, null
						, pdo.getString(PDOConstantFieldsInterface.X_MOP_NOTIFICATION_MSG_TYPE),  pdo.getString(PDOConstantFieldsInterface.X_RJCT_RSN));
			}
			
			contents = errcode != null ? errcode.getContents() : GlobalConstants.EMPTY_STRING;
			
			ProcessError pError=new ProcessError(ProcessErrorConstants.PaymentRejected,pdo.getMID(), null,new Object[]{mop,contents}); 
	        ErrorAuditUtils.setErrors(pError);	 
	        
	        // Load related S-payment and update UDF fields for ROF fees calculation
	        final String S_MESSAGE_TYPE = "P_BATCH_MSG_TP = 'S'";
	        String sInInternalFileId = pdo.getString(PDOConstantFieldsInterface.P_IN_INTERNAL_FILEID);
	        String sChunkId = pdo.getString(PDOConstantFieldsInterface.P_CHUNK_ID);
	        String sUniqueGroupingId = pdo.getString(PDOConstantFieldsInterface.P_UNIQUE_GROUPING_ID);
	        Integer iIsHistoryValue = pdo.getIsHistory();
	        
	     	List<PDO> sPaymentList = PaymentDataFactory.load(sInInternalFileId, sChunkId, sUniqueGroupingId, iIsHistoryValue, S_MESSAGE_TYPE);
	     	PDO sPaymentPDO = (sPaymentList!=null && !sPaymentList.isEmpty()) ? sPaymentList.toArray(new PDO[]{})[0] : null;
	        if(sPaymentPDO!=null)
	        {
	        	pdo.set(PDOConstantFieldsInterface.U_DBT_CIF_TYPE, sPaymentPDO.getString(PDOConstantFieldsInterface.U_DBT_CIF_TYPE));
	        	pdo.set(PDOConstantFieldsInterface.U_DBT_SEG_CODE, sPaymentPDO.getString(PDOConstantFieldsInterface.U_DBT_SEG_CODE));
	        }
		}
		return feedback;
	}

	@Override
	public StepSelector getStepSelector() {
		String confirmationFlow = getFlowPdo().getString(PDOConstantFieldsInterface.D_CONFIRMATION_FLOW);
		
		if (NotificationTypeType.ACTC.name().equals(confirmationFlow)){//ACTC
			return new CTBulkNotificationAcceptStepSelector();
			
		}else if (NotificationTypeType.RJCT.name().equals(confirmationFlow)){//RJCT
			return new CTBulkNotificationRejectStepSelector();
		}else{
			return null;
		}
	        
	}

	@Override
	public Logger getLogger() {
		return LoggerFactory.getLogger(CTBulkNotification.class);
	}

	@Override
	public String getFailureStatus() {
		return MESSAGE_STATUS_REJECTED;
	}

	@Override
	public FlowName getFlowName() {
		flowName = FlowName.G3CTNotificaition;
		return flowName;
	}

}
