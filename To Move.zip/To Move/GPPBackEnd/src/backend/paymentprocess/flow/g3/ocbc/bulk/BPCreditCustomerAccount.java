package backend.paymentprocess.flow.g3.ocbc.bulk;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.paymentprocess.SubBatchProcessInterface;
import backend.paymentprocess.flow.base.FlowName;
import backend.paymentprocess.flow.g3.G3Util;
import backend.paymentprocess.flowstep.FlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.BulkRepairAndEnrichmentFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.BulkSubBatchCreditAccountInquiryFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.SetCompleteFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.feecalculation.CreditFeeCalculationFlowStep;
import backend.paymentprocess.flowstepselector.AbstractStepSelector;
import backend.paymentprocess.flowstepselector.StepSelector;
import backend.paymentprocess.highvalueprocess.businessobjects.BOHighValueProcess;

import com.fundtech.annotations.Wrap;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.datacomponent.response.ServiceFeedback;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalUtils;


@Wrap
public class BPCreditCustomerAccount extends BulkFlow {
	final String SUB_BATCH_BP_FLOW_START = "Starting Sub Batch S payment for DDO flow , MID: {}";

	@Override
	public StepSelector getStepSelector() {
		return new AbstractStepSelector(){
			@Override
			public FlowStep[] getSteps(){
			return new FlowStep[] { 
					new BulkRepairAndEnrichmentFlowStep(),
					new BulkSubBatchCreditAccountInquiryFlowStep(),
					new CreditFeeCalculationFlowStep(),
					new SetCompleteFlowStep()
				};
			}
		};
	}

	@Override
	protected Feedback preFlow(Feedback feedback) {
		super.configufeFlow(getFlowPdo());
		
		logger.info(SUB_BATCH_BP_FLOW_START,getFlowPdo().getMID());
		
		getFlowPdo().set(D_FLOW_CONTEXT, BULK_SUBBACTH_FLOW);
		getFlowPdo().set(D_G3_IMMEDIATE_FLOW_NAME, getFlowName());
		getFlowPdo().set(P_DBT_MOP, "BOOK");
		getFlowPdo().set(P_CDT_MOP, "BOOK");
		Object valueTime = getFlowPdo().get(D_BULK_SUBBATCH_VALUE_TIME);
		if(valueTime != null)
			getFlowPdo().set(UDF_SYSTEM_VALUE_TIME, getFlowPdo().get(D_BULK_SUBBATCH_VALUE_TIME));//until payment classification rule is invoked
		
		return feedback;

	}
	
	protected Feedback executeFlowSteps(StepSelector stepsSelector) throws Throwable {

		ServiceFeedback serviceFeedback = new ServiceFeedback();
		String finalStatus = null;

		PDO pdo = getFlowPdo();
		getLogger().info("start flow for mid {}.", new String[] { pdo.getMID() });

		while (stepsSelector.hasNextStep()) {
			FlowStep currentStep = stepsSelector.getNextStep();
			serviceFeedback = handleStepExecution(currentStep,pdo);
			
			if (serviceFeedback.shouldStopProcess()) {
				String strPmntSrc=pdo.getString(PDOConstantFieldsInterface.P_PMNT_SRC);
				String strBatchMsgTp=pdo.getString(PDOConstantFieldsInterface.P_BATCH_MSG_TP);
				if (GlobalConstants.CREATE.equalsIgnoreCase(strPmntSrc) || 
				   (GlobalUtils.isNullOrEmpty(strPmntSrc) && SubBatchProcessInterface.BATCH_MESSAGE_TYPE_SUB.equals(strBatchMsgTp)))
				{
					finalStatus = serviceFeedback.isMessageStatusChanged() ? pdo.getString(P_MSG_STS): MESSAGE_STATUS_REPAIR;
				}else{
					finalStatus = serviceFeedback.isMessageStatusChanged() ? pdo.getString(P_MSG_STS) : getFailureStatus();
					if (MESSAGE_STATUS_REJECTED.equalsIgnoreCase(finalStatus)) {
						G3Util.setRsnPrtry(pdo);
					}
				}
				getLogger().debug("stopping flow");
				break;
			}
		}
		
		if(shouldExecuteTerminationSubFlow())
			BOHighValueProcess.performTerminationSubFlow(pdo, finalStatus);

		return serviceFeedback.getFeedback();

	}

	@Override
	public Logger getLogger() {
		return LoggerFactory.getLogger(CTBulkOutgoingNoSubBatch.class);
	}

	@Override
	public String getFailureStatus() {
		return MESSAGE_STATUS_REJECTED;
	}

	@Override
	public FlowName getFlowName() {
		flowName = FlowName.G3BPSubBatchFlow;
		return flowName;
	}

}
