package backend.paymentprocess.flow.g3.ocbc.dd;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.paymentprocess.flow.base.FlowName;
import backend.paymentprocess.flow.g3.ocbc.OCBCAbstractFlow;
import backend.paymentprocess.flowstep.FlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.CapacityCheckFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.CreditAccountDerivationFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.DDIPrincipleAndFeesFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.DebitAccountSelectionFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.DepartmentSelectionFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.DuplicateCheckFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.FormatOutAndTransmissionFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.MOPSelectionFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.MandateInquiryFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.MandateValidationFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.MessageClassificationFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.RIndexMatchingCheckFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.ReceivingBankValidationFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.RepairAndEnrichedFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.STPValidationFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.SetCompleteFlowStep;
import backend.paymentprocess.flowstepselector.AbstractStepSelector;
import backend.paymentprocess.flowstepselector.StepSelector;

import com.fundtech.cache.entities.Accounts;
import com.fundtech.cache.entities.Mop;
import com.fundtech.cache.entities.SwiftId;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.liquidity.Account;
import com.fundtech.util.GlobalConstants;

public class DDIncoming extends OCBCAbstractFlow {
	
	@Override
	public FlowName getFlowName() {		
		flowName = FlowName.G3DDIncoming;
		return flowName;
	}		
	
	@Override
	public String getFailureStatus() {
		return MESSAGE_STATUS_REJECTED;
	}
	
	
	@Override
	public Logger getLogger() {
		return LoggerFactory.getLogger(DDIncoming.class);		
	}	
	
	
	@Override
	public StepSelector getStepSelector() {
		return new AbstractStepSelector() {
			@Override
			public FlowStep[] getSteps() {
				return new FlowStep[]{ new ReceivingBankValidationFlowStep(), 
									   new DepartmentSelectionFlowStep(), 
									   new RepairAndEnrichedFlowStep(), 
									   new STPValidationFlowStep(), 
									   new DuplicateCheckFlowStep(), 
									   new RIndexMatchingCheckFlowStep(), 
									   new CreditAccountDerivationFlowStep(),
									   new MandateInquiryFlowStep(),
									   new DebitAccountSelectionFlowStep(), 
									   new MOPSelectionFlowStep(), 
									   new CapacityCheckFlowStep(), 
									   new DDIPrincipleAndFeesFlowStep(), 
									   new SetCompleteFlowStep(), 
									   new FormatOutAndTransmissionFlowStep()};
			}
		};
	}

	@Override
	protected Feedback preFlow(Feedback feedback) {
		super.preFlow(feedback);
		PDO pdo = getFlowPdo();

		pdo.set(D_G3_IMMEDIATE_FLOW_NAME, flowName);
		pdo.set(D_FLOW_CONTEXT, MAIN_FLOW);
		pdo.set(P_MSG_CLASS, MSG_CLASS_DD);// until payment classification rule is invoked
		pdo.set(P_BASE_AMT, pdo.get(OX_STTLM_AMT));
		pdo.set(P_BASE_CCY, pdo.getNSetOffice().getCurrency());
		pdo.set(P_BUSINESS_FLOW_TP, GlobalConstants.RT);
		pdo.set(P_TX_CTGY, TX_CATEGORY_DDI);
		String sOffice=pdo.getString(P_OFFICE);
		//When the processing failed before the credit account derivation -for position keeping processing #73480
		Mop creditMop = CacheKeys.mopKey.getSingle(sOffice, "G3");
		if (null != creditMop){
			SwiftId swiftId = CacheKeys.swiftIdKey.getSingle(pdo.getString(PDOConstantFieldsInterface.P_OFFICE), "G3" ,creditMop.getSenderBic());
			if (null!= swiftId){
	        Accounts swiftIdAcc = CacheKeys.accountsKey.getSingle(swiftId.getAccNo(), pdo.getNSetOffice().getCurrency(), swiftId.getOffice());
	        logger.debug("Set settlment account {} to credit account",swiftIdAcc.getUidAccounts());
			pdo.setCREDIT_ACCOUNT(swiftIdAcc);
			}
		}

		return feedback;
	}

}
