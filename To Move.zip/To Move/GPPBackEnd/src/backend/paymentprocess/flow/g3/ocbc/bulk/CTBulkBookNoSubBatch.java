package backend.paymentprocess.flow.g3.ocbc.bulk;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.datacomponent.response.Feedback;

import backend.paymentprocess.flow.base.FlowName;
import backend.paymentprocess.flowstepselector.StepSelector;
import backend.paymentprocess.flowstepselector.ocbc.CTBulkBookNoSubBatchStepSelector;

public class CTBulkBookNoSubBatch extends BulkFlow {

	@Override
	public StepSelector getStepSelector() {
		return new CTBulkBookNoSubBatchStepSelector(getFlowPdo());
	}

	@Override
	public Logger getLogger() {
		return LoggerFactory.getLogger(CTBulkBookNoSubBatch.class);
	}

	@Override
	public String getFailureStatus() {
		return MESSAGE_STATUS_REJECTED;
	}

	@Override
	protected Feedback preFlow(Feedback feedback) {
		super.preFlow(feedback);
		PDO pdo = getFlowPdo();

		super.configufeFlow(pdo);
		
		pdo.set(D_FLOW_CONTEXT, MAIN_FLOW);
		pdo.set(P_MSG_CLASS, MSG_CLASS_PAY);//until payment classification rule is invoked
		pdo.set(P_BASE_AMT, pdo.get(OX_STTLM_AMT));
		pdo.set(P_BASE_CCY, pdo.getNSetOffice().getCurrency());

		return feedback;
	}

	@Override
	public FlowName getFlowName() {
		flowName = FlowName.G3CTBook;
		return flowName;
	}

}
