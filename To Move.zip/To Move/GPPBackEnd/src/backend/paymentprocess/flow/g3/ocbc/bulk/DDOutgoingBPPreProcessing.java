package backend.paymentprocess.flow.g3.ocbc.bulk;

import java.math.BigDecimal;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.paymentprocess.flow.base.FlowName;
import backend.paymentprocess.flowstep.FlowStep;
import backend.paymentprocess.flowstep.common.InstructionIdGenerationFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.CreditAccountSelectionFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.DebitPartyDerivationFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.DepartmentSelectionFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.DuplicateCheckFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.MOPSelectionFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.PauseFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.RIndexMatchingCheckFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.RepairAndEnrichedFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.STPValidationFlowStep;
import backend.paymentprocess.flowstep.g3.ocbc.WarehousingFlowStep;
import backend.paymentprocess.flowstepselector.AbstractStepSelector;
import backend.paymentprocess.flowstepselector.StepSelector;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.util.GlobalUtils;

public class DDOutgoingBPPreProcessing  extends BulkPreProcessingFlow{
	final String DDOUTGOING_BP_FLOW_START = "Starting BP flow for Outgoing debit transfer , MID: {}";
	
	@Override
	public StepSelector getStepSelector() {
		return new AbstractStepSelector(){
			@Override
			public FlowStep[] getSteps() {
				return new FlowStep[]{
						new InstructionIdGenerationFlowStep(), 
						new DepartmentSelectionFlowStep(), 
						new RepairAndEnrichedFlowStep(), 
						new STPValidationFlowStep(), 
						new DuplicateCheckFlowStep(), 
						new CreditAccountSelectionFlowStep(), 
						new DebitPartyDerivationFlowStep(), 
						new MOPSelectionFlowStep(),
						new RIndexMatchingCheckFlowStep(), 
						new PauseFlowStep()
				};
			}
		};
	}

	@Override
	public Logger getLogger() {
		return LoggerFactory.getLogger(DDOutgoingBPPreProcessing.class);
	}

	@Override
	public String getFailureStatus() {
		return MESSAGE_STATUS_REJECTED;
	}

	@Override
	protected Feedback preFlow(Feedback feedback) {
		super.preFlow(feedback);
		PDO pdo = getFlowPdo();
		super.configufeFlow(pdo);
		
		logger.info(DDOUTGOING_BP_FLOW_START,pdo.getMID());
		
		pdo.set(D_FLOW_CONTEXT, BULK_MAIN_FLOW);
		pdo.set(D_G3_IMMEDIATE_FLOW_NAME, getFlowName());
		pdo.set(P_MSG_CLASS, MSG_CLASS_DD);//until payment classification rule is invoked			
		pdo.set(P_BASE_AMT, pdo.get(OX_STTLM_AMT));
		pdo.set(P_BASE_CCY, pdo.getNSetOffice().getCurrency());
		pdo.set(P_TX_CTGY, TX_CATEGORY_DDO);
		pdo.set(P_ORIG_INSTR_ID, pdo.getString(OX_INSTR_ID));
		pdo.set(P_DBT_AMT, pdo.getDecimal(OX_STTLM_AMT));// since bulk individual has no credit account derivation, this is needed for principle reversal posting	
		
		//Defect 50545  -  needed for non fee step flows
		BigDecimal sttlmAmount = getFlowPdo().getDecimal(X_STTLM_AMT);
		String ccy = getFlowPdo().getString(P_BASE_CCY);
		if (sttlmAmount != null && sttlmAmount.doubleValue() != 0 && ccy != null){			//Defect #44450
			sttlmAmount = GlobalUtils.adjustPrecisionBD(sttlmAmount.doubleValue(), GlobalUtils.getPrecision(ccy)); 
			getFlowPdo().set(X_STTLM_AMT,sttlmAmount);
		}

		return feedback;
	}

	@Override
	public FlowName getFlowName() {
		flowName = FlowName.G3DDOutgoing;
		return flowName;
	}

}
