package backend.paymentprocess.commons;

import com.fundtech.cache.entities.Accounts;
import com.fundtech.cache.entities.CurrencyBu;
import com.fundtech.cache.entities.Customrs;
import com.fundtech.cache.entities.Mop;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;

public enum MsgClassType {
	DD {
		@Override
		public boolean isSourceAccountAsset(PDO pdo) {
			return pdo.getNSetCREDIT_ACCOUNT() != null && pdo.getNSetCREDIT_ACCOUNT().getAsset() != null
					&& pdo.getNSetCREDIT_ACCOUNT().getAsset() != 0;
		}

		@Override
		public String getSourceMopLogicalField() {
			return PDOConstantFieldsInterface.P_CDT_MOP;
		}

		@Override
		public String getDestMopLogicalField() {
			return PDOConstantFieldsInterface.P_DBT_MOP;
		}
		
		@Override
		public String getDestValueDateLogicalField() {
			return PDOConstantFieldsInterface.P_DBT_VD;
		}
		
		@Override
		public String getSourceValueDateLogicalField() {
			return PDOConstantFieldsInterface.P_CDT_VD;
		}
		
		@Override
		public String getDestAccountCycleLogicalField() {
			return PDOConstantFieldsInterface.P_DBT_ACCT_CYCLE;
		}

		@Override
		public Customrs getDestCustomer(PDO pdo) {
			return pdo.getNSetDEBIT_CUSTOMER();
		}

		@Override
		public Accounts getDestAccount(PDO pdo) {
			return pdo.getNSetDEBIT_ACCOUNT();
		}

		@Override
		public Customrs getSourceCustomer(PDO pdo) {
			return pdo.getNSetCREDIT_CUSTOMER();
		}

		@Override
		public Accounts getSourceAccount(PDO pdo) {
			return pdo.getNSetCREDIT_ACCOUNT();
		}

		@Override
		public String getSourceAccoutCcyLogicalField() {
			return PDOConstantFieldsInterface.P_CDT_ACCT_CCY;
		}

		@Override
		public String getDestAccoutCcyLogicalField() {
			return PDOConstantFieldsInterface.P_DBT_ACCT_CCY;
		}

		@Override
		public String getDestAccoutNoLogicalField() {
			return PDOConstantFieldsInterface.P_DBT_ACCT_NB;
		}

		@Override
		public String getSourceAccoutNoLogicalField() {
			return PDOConstantFieldsInterface.P_CDT_ACCT_NB;
		}

		@Override
		public String getDestAccoutOfficeLogicalField() {
			return PDOConstantFieldsInterface.P_DBT_ACCT_OFFICE;
		}

		@Override
		public CurrencyBu getDestCurrency(PDO pdo) {
			return pdo.getNSetDebitCurrency();
		}

		@Override
		public CurrencyBu getSourceCurrency(PDO pdo) {
			return pdo.getNSetCreditCurrency();
		}

		@Override
		public String getDestCustCountrycodeLogicalField() {
			return PDOConstantFieldsInterface.F_DBT_CUST_COUNTRYCODE;
		}

		@Override
		public Mop getDestMop(PDO pdo) {
			return pdo.getNSetDEBIT_MOP();
		}

		@Override
		public void updateDestMop(PDO pdo, Mop mop) {
			pdo.setDEBIT_MOP(mop);

		}

		@Override
		public void updateDestAccount(PDO pdo, Accounts account) {
			pdo.setDEBIT_ACCOUNT(account);

		}

		@Override
		public String getDestAmountLogicalField() {
			return PDOConstantFieldsInterface.P_DBT_AMT;
		}

		@Override
		public String getSourceAmountLogicalField() {
			return PDOConstantFieldsInterface.P_CDT_AMT;
		}

	},
	DEFAULT;

	public boolean isSourceAccountAsset(PDO pdo) {
		return pdo.getNSetDEBIT_ACCOUNT() != null && pdo.getNSetDEBIT_ACCOUNT().getAsset() != null && pdo.getNSetDEBIT_ACCOUNT().getAsset() != 0;
	}

	public String getSourceMopLogicalField() {
		return PDOConstantFieldsInterface.P_DBT_MOP;
	}

	public String getDestMopLogicalField() {
		return PDOConstantFieldsInterface.P_CDT_MOP;
	}
	
	public String getDestValueDateLogicalField() {
		return PDOConstantFieldsInterface.P_CDT_VD;
	}
	
	public String getSourceValueDateLogicalField() {
		return PDOConstantFieldsInterface.P_DBT_VD;
	}
	
	public String getDestAccountCycleLogicalField() {
		return PDOConstantFieldsInterface.P_CDT_ACCT_CYCLE;
	}

	public Customrs getDestCustomer(PDO pdo) {
		return pdo.getNSetCREDIT_CUSTOMER();
	}

	public Customrs getSourceCustomer(PDO pdo) {
		return pdo.getNSetDEBIT_CUSTOMER();
	}

	public Accounts getDestAccount(PDO pdo) {
		return pdo.getNSetCREDIT_ACCOUNT();
	}

	public Accounts getSourceAccount(PDO pdo) {
		return pdo.getNSetDEBIT_ACCOUNT();
	}

	public String getSourceAccoutCcyLogicalField() {
		return PDOConstantFieldsInterface.P_DBT_ACCT_CCY;
	}

	public String getDestAccoutCcyLogicalField() {
		return PDOConstantFieldsInterface.P_CDT_ACCT_CCY;
	}

	public String getDestAccoutNoLogicalField() {
		return PDOConstantFieldsInterface.P_CDT_ACCT_NB;
	}

	public String getSourceAccoutNoLogicalField() {
		return PDOConstantFieldsInterface.P_DBT_ACCT_NB;
	}

	public String getDestAccoutOfficeLogicalField() {
		return PDOConstantFieldsInterface.P_CDT_ACCT_OFFICE;
	}

	public CurrencyBu getSourceCurrency(PDO pdo) {
		return pdo.getNSetDebitCurrency();
	}

	public CurrencyBu getDestCurrency(PDO pdo) {
		return pdo.getNSetCreditCurrency();
	}

	public String getDestCustCountrycodeLogicalField() {
		return PDOConstantFieldsInterface.F_CDT_CUST_COUNTRYCODE;
	}

	public String getDestAmountLogicalField() {
		return PDOConstantFieldsInterface.P_CDT_AMT;
	}

	public String getSourceAmountLogicalField() {
		return PDOConstantFieldsInterface.P_DBT_AMT;
	}

	public Mop getDestMop(PDO pdo) {
		return pdo.getNSetCREDIT_MOP();
	}

	public void updateDestMop(PDO pdo, Mop mop) {
		pdo.setCREDIT_MOP(mop);
	}

	public void updateDestAccount(PDO pdo, Accounts account) {
		pdo.setCREDIT_ACCOUNT(account);	
	}
}
