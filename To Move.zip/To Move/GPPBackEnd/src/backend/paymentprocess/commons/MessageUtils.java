package backend.paymentprocess.commons;

import static backend.core.module.MessageConstantsInterface.MSG_CLASS_DD;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.F_OFFICE_BDT;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_MSG_CLASS;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_PROC_DT;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.X_ORGNL_MSG_NM_ID;
import static com.fundtech.util.GlobalUtils.setObject;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;
import java.util.List;

import javax.xml.namespace.QName;

import org.apache.commons.lang.StringUtils;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlObjectBase;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.dataaccess.dao.DAOBasic;
import backend.paymentprocess.dao.DAS;
import backend.staticdata.dataaccess.dao.IdentifierDAO;

import com.fundtech.cache.entities.Banks;
import com.fundtech.cache.entities.SwiftId;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.general.PluginFactory;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.das.DASInterface;
import com.fundtech.core.paymentprocess.data.das.DASInterface.XmlLocationType;
import com.fundtech.core.paymentprocess.data.paymenttypes.PaymentType;
import com.fundtech.core.security.Admin;
import com.fundtech.jndi.ServiceLocator;
import com.fundtech.scl.commonTypes.MsgTableEntryBaseType;
import com.fundtech.scl.commonTypes.MtableDocument;
import com.fundtech.scl.commonTypes.RecordType;
import com.fundtech.scl.commonTypes.TABLE;
import com.fundtech.spring.SpringApplicationContext;
import com.fundtech.util.GlobalConstants;

public class MessageUtils {
	private static final Logger logger = LoggerFactory.getLogger(MessageUtils.class);
	
	private static IdentifierDAO identifierDao = (IdentifierDAO)SpringApplicationContext.getBean("identifierDAO"); 
	
	 private static final String SELECT_NEWJOURNAL = 
			"SELECT J.USERNAME, J.MID P_MID, J.XML_RELATED_FIELDS_DATA, TIME_STAMP \r\n" + 
			"  FROM NEWJOURNAL J\r\n" + 
			" WHERE J.ERROR_CODE = 40061\r\n" + 
			"   AND J.MID = ?\r\n"+ 
			"   AND J.PARTITION_ID = ?\r\n"+ 
			" ORDER BY TIME_STAMP ASC";
	
	public static boolean isDirectDebit(PDO pdo){
		String msgClass = pdo.getString(P_MSG_CLASS);
		boolean isDirectDebit = StringUtils.contains(msgClass, MSG_CLASS_DD) || StringUtils.contains(pdo.getString(X_ORGNL_MSG_NM_ID), "pacs.003");
		return isDirectDebit;
	}
	
	public static MsgClassType getMsgClassType(PDO pdo){		
		MsgClassType msgClassType =  isDirectDebit(pdo) ? MsgClassType.DD :MsgClassType.DEFAULT;
		return msgClassType;
	}
	
	public static boolean isFutureProcessingDate(PDO pdo) {
		Date processingDate = pdo.getDate(P_PROC_DT);
	    Date officeBusinessDate = pdo.getDate(F_OFFICE_BDT);
	      
	    String monitorSendSchedule = pdo.getString(PDOConstantFieldsInterface.MU_SEND_TO_SCHEDULE);
	    
	    if(processingDate != null 
	           && processingDate.after(officeBusinessDate) 
	    	   && (StringUtils.isEmpty(monitorSendSchedule) || !"F".equals(monitorSendSchedule))) {
	    	logger.info("payment processing date {} is in the future." 
	    				+ " (business date: {}, MU_SEND_TO_SCHEDULE: {})"
	    				,new Object[]{processingDate,officeBusinessDate,monitorSendSchedule});
	    	
	    	return true;
	    }
	    
	    return false;
	}
	
	public static void setExtn(PDO pdoSource,PDO pdoTarget) throws Exception {
		setExtn(pdoTarget,pdoSource.getXml(XmlLocationType.XML_MSG_EXTN.name()));	
	}
	
	public static void setExtn(PDO pdoTarget,XmlObjectBase extnXbean) throws Exception {
	  	PaymentType EXT = PaymentType.valueOf(PaymentType.PT_EXTN);
	  	
	  	pdoTarget.addXmlDocument(XmlLocationType.XML_MSG_EXTN,EXT,extnXbean);
  		pdoTarget.addXmlDocument(XmlLocationType.XML_ORIG_MSG_EXTN,EXT,extnXbean);
  		
	  	List listGroupsToParse = CacheKeys.LogicalFieldsXPathGroupsKey.get(null, EXT, "XML_MSG_EXTN");
	  	
	  	//apply the extn to the PDO fields
	  	DAS das = (DAS)PluginFactory.get(DASInterface.class);
	  	das.performXmlMapping(XmlLocationType.XML_MSG_EXTN
	  			,EXT
	  			,extnXbean
	  			,pdoTarget.getDataMap()
	  			,pdoTarget
	  			,true/* bDeriveOrigFields */
					,true/* bConjoinedMode */
					,true/* bMergeContext */
					,listGroupsToParse);  		
	}
	
	 /**
	 * Return the old value of logicalFieldName from newJournal.
	 * 
	 * Example of use: getOldValueOfLogicalField(pdo.getMID(), "P_HOLD_DATE");
	 * 
	 * @param pdo
	 * @param logicalFieldName 
	 */
  public static String getOldValueOfLogicalField(String mid, String logicalFieldName, Integer iPatitionID){ 

		//String mid = "12919B5855LU0094";
		//String logicalFieldName ="X_INSTR_ID";
		DAOBasic dao = new DAOBasic(); 
		Connection conn = null ; 
		PreparedStatement psNewjournalModification = null ; 
		ResultSet rsNewjournalModification = null;

		final Admin admin = Admin.getContextAdmin() ; 

		final boolean bOrigSupportsSharedResourcesValue = admin.supportsSharedResources() ;
		if(!bOrigSupportsSharedResourcesValue) admin.enableSharedResourcesSupport() ;

		try{
			conn = dao.getConnection() ; 

			psNewjournalModification = conn.prepareStatement(SELECT_NEWJOURNAL) ; 

			setObject(psNewjournalModification, 1, mid) ;
			setObject(psNewjournalModification, 2, iPatitionID) ;
			
			rsNewjournalModification = psNewjournalModification.executeQuery() ; 

			MtableDocument mtable = null ;  

			// UDFs support  
			final String XML_RELATED_FIELDS_DATA_COLUMN = "XML_RELATED_FIELDS_DATA" ;

			final QName newValueQname = new QName("http://fundtech.com/SCL/CommonTypes", "NEW_VALUE") ;
			final QName oldValueQname = new QName("http://fundtech.com/SCL/CommonTypes", "OLD_VALUE") ;

			// The query is ordered by MID - loop on it and handle each MID (if the same MID appears more than once wait to the last one)
			while(rsNewjournalModification.next()) { 
				mtable = (MtableDocument) GlobalConstants.getDbType().getXmlColumnContent(rsNewjournalModification, XML_RELATED_FIELDS_DATA_COLUMN) ;
				if (mtable == null) continue; // Skip empty XML_RELATED_FIELDS_DATA_COLUMN


				// Extract the XML fields and update the Map<FieldLogicalId, FieldData>
				for(RecordType mtableRecord : mtable.getMtable().getRecordArray()) { 
					for(MsgTableEntryBaseType mtableRecordColumn : mtableRecord.getColumnArray()) { 

						String sFieldLogicalId = mtableRecordColumn.getId() ; 
						if (sFieldLogicalId.compareTo(logicalFieldName) !=0) continue ;  
						
						//if the column is an instance of a TABLE (e.g. MSG_NOTES) - skip 
						if(mtableRecordColumn.schemaType() == TABLE.type) continue ;  

						XmlObject[] arrValueXbeanHolder = mtableRecordColumn.selectChildren(newValueQname);
						
						String sOldValue = null ; 
						arrValueXbeanHolder = mtableRecordColumn.selectChildren(oldValueQname) ;
						//if no node was selected (new field audit) set the old value to null 
						sOldValue = (arrValueXbeanHolder.length == 0 ? null : ((XmlObjectBase)arrValueXbeanHolder[0]).getStringValue()) ;  
						if (sOldValue != null)
							return sOldValue;

					}//EO for MsgTableEntryBaseType
				}//EO for RecordType 
			} // END while rsNewjournalModification


		}catch(Throwable t){ 
			t.printStackTrace() ; 
		}finally { 
			ServiceLocator.releaseResources(rsNewjournalModification, psNewjournalModification, conn) ; 
		}//EO catch block
		return null; 
	}//EOM 
  
  public static String getLocalOfficeFromSwiftId(String bic){
	  String office = null;
	  // 1st check in related BANKS table cache.
	  Banks bank = CacheKeys.banksPerSwiftIDKey.getSingle(bic);

	  if(bank != null){
		  logger.info("");
		  office = bank.getOffice();
	  }else{ // 2nd check in related SWIFT_ID table cache.
		  // Checks if this BIC is in SWIFT_ID table.
		  SwiftId swiftId = CacheKeys.swiftIdPerSwiftIdKey.getSingle(bic);
		  if(swiftId != null){
			  logger.info("");
			  office = swiftId.getOffice();
		  }
	  }
 
	  return office;
  }
  
  public static String getMopFromSwiftId(String bic,String office){
	  String mop=null;
	  SwiftId swiftId=CacheKeys.swiftIdKey.getSingle(bic); 
	  if(swiftId!=null)
		  mop=swiftId.getMop();
	  return mop;
  }
  
  public static String getBic(PDO pdo){
	  String bic=null;
	  String office=pdo.getString(PDOConstantFieldsInterface.P_OFFICE);
	  
	  IdentifierDAO identifierDAO=(IdentifierDAO)SpringApplicationContext.getBean("identifierDAO");
	  try {
		List<String>bics=identifierDAO.getSwiftBICs(office, "G3");
		  bic=bics.get(0);
	} catch (Exception e) {
		logger.warn("No bic found.");
	}
	  
	  return bic;
	  
  }
}
