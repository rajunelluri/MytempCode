package backend.paymentprocess.closeopennewoutfiles.ejbinterfaces;

import com.fundtech.core.general.flows.FlowException;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;
import java.io.Serializable;
import javax.ejb.Remote;

@Remote
public abstract interface CloseOpenNewOutFiles
{
  public static final String REMOTE_JNDI_NAME = "ejb/CloseOpenNewOutFilesBean";

  public abstract Feedback processCloseOpenNewOutFiles(Admin paramAdmin, Serializable paramSerializable)
    throws FlowException;
}

/* Location:           d:\Projects\GPP_SP\GPPBackEnd\src\
 * Qualified Name:     backend.paymentprocess.closeopennewoutfiles.ejbinterfaces.CloseOpenNewOutFiles
 * JD-Core Version:    0.6.0
 */