package backend.paymentprocess.closeopennewoutfiles.ejbinterfaces;

import javax.ejb.Local;

@Local
public abstract interface CloseOpenNewOutFilesLocal extends CloseOpenNewOutFiles
{
}

/* Location:           d:\Projects\GPP_SP\GPPBackEnd\src\
 * Qualified Name:     backend.paymentprocess.closeopennewoutfiles.ejbinterfaces.CloseOpenNewOutFilesLocal
 * JD-Core Version:    0.6.0
 */