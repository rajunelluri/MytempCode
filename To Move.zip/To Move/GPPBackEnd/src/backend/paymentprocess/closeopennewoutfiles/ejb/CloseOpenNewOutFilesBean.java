/*    */ package backend.paymentprocess.closeopennewoutfiles.ejb;
/*    */ 
/*    */ import backend.paymentprocess.asynch.timers.AbstractTimer;
/*    */ import backend.paymentprocess.asynch.timers.TimerBeanInterface;
/*    */ import backend.paymentprocess.closeopennewoutfiles.businessobjects.BOCloseOpenNewOutFiles;
/*    */ import backend.paymentprocess.closeopennewoutfiles.ejbinterfaces.CloseOpenNewOutFiles;
/*    */ import backend.paymentprocess.closeopennewoutfiles.ejbinterfaces.CloseOpenNewOutFilesLocal;
/*    */ import com.fundtech.core.general.flows.FlowException;
/*    */ import com.fundtech.core.security.Admin;
/*    */ import com.fundtech.datacomponent.response.Feedback;
/*    */ import java.io.Serializable;
/*    */ import javax.ejb.Stateless;
/*    */ 
/*    */ @Stateless
/*    */ public class CloseOpenNewOutFilesBean extends AbstractTimer<CloseOpenNewOutFiles>
/*    */   implements CloseOpenNewOutFiles, CloseOpenNewOutFilesLocal, TimerBeanInterface
/*    */ {
/*    */   private static final long serialVersionUID = 3206093459760846163L;
/*    */   private static final String TIMEOUT_METHOD = "onCloseOpenNewOutFilesTimeOut";
/*    */ 
/*    */   public CloseOpenNewOutFilesBean()
/*    */   {
/* 28 */     super(BOCloseOpenNewOutFiles.class, CloseOpenNewOutFiles.class, "onCloseOpenNewOutFilesTimeOut");
/*    */   }
/*    */ 
/*    */   public Feedback processCloseOpenNewOutFiles(Admin admin, Serializable tuple) throws FlowException {
/* 32 */     return ((CloseOpenNewOutFiles)getBOInstance()).processCloseOpenNewOutFiles(admin, tuple);
/*    */   }
/*    */ }

/* Location:           c:\Documents and Settings\ofer.baranes\Desktop\OCBC\MassPayment\RND_import\classes\closeopennewoutfiles\ejb\
 * Qualified Name:     backend.paymentprocess.closeopennewoutfiles.ejb.CloseOpenNewOutFilesBean
 * JD-Core Version:    0.6.0
 */