/**
 * 
 */
package backend.paymentprocess.closeopennewoutfiles.businessobjects;

import static com.fundtech.util.GlobalUtils.isNullOrEmpty;

import java.io.Serializable;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.cxf.common.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.businessobject.BOBasic;
import backend.businessobject.BOProxies;
import backend.core.module.MessageConstantsInterface;
import backend.dataaccess.dto.DTOSingleValue;
import backend.paymentprocess.SubBatchProcessInterface;
import backend.paymentprocess.baseprocess.businessobjects.BOBaseProcess;
import backend.paymentprocess.closeopennewoutfiles.common.CloseOpenNewOutFileData;
import backend.paymentprocess.closeopennewoutfiles.dao.DAOCloseOpenNewOutFiles;
import backend.paymentprocess.debulkingprocess.dao.DAODebulkingProcess;
import backend.paymentprocess.g3utils.InstructionIdGenerator;
import backend.paymentprocess.interfaces.common.TransmissionType;
import backend.paymentprocess.subbatchgeneration.dao.DAOSubBatchGeneration;
import backend.util.ServerConstants;

import com.fundtech.cache.entities.APaymentPerGroupMsgID;
import com.fundtech.cache.entities.Accounts;
import com.fundtech.cache.entities.Banks;
import com.fundtech.cache.entities.BulkingProfile;
import com.fundtech.cache.entities.InterfaceTypes;
import com.fundtech.cache.entities.Mop;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.general.flows.FlowException;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.core.paymentprocess.data.paymenttypes.PaymentType;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.scl.massPayment.CloseOpenOutFilesRequestDocument;
import com.fundtech.scl.rebulkProcessService.ProcessRebulkRequestDocument;
import com.fundtech.spring.SpringApplicationContext;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalDateTimeUtil;
import com.fundtech.util.GlobalUtils;
import com.fundtech.util.datetime.DateAndZone;
import com.fundtech.util.datetime.NewASDateTimeUtils;


/**
 * @author eranm
 *
 */

public class BOCloseOpenNewOutFiles extends BOBasic implements SubBatchProcessInterface, MessageConstantsInterface
{

	private static final Logger logger = LoggerFactory.getLogger(BOCloseOpenNewOutFiles.class);
	private static DAOCloseOpenNewOutFiles m_daoCloseOpenNewOutFiles = DAOCloseOpenNewOutFiles.getInstance();
	private static DAOSubBatchGeneration m_daoSubBatchGeneration =  DAOSubBatchGeneration.getInstance();
	private static DAODebulkingProcess m_daoDebulkingProcess = DAODebulkingProcess.getInstance();

	private static final String ERROR_MESSAGE_LOAD_PDO_FAILURE = "ERROR: BOCloseOpenNewOutFiles.getNewPDOFromTemplatePDO - failed load PDO for individual MID: ";
	private static Method m_processCloseOpenNewOutFilesInner = null;

	private static final String COLUMN_SUSPENSE_ACCT_UID = "SUSPENSE_ACCT_UID";
	private static final String COLUMN_TOTAL_MSG_COUNT_NB = "TOTAL_MSG_COUNT_NB";
	private static final String COLUMN_OUT_GROUPING_ID = "OUT_GROUPING_ID";
	private static final String COLUMN_INDIVIDUAL_MID = "INDIVIDUAL_MID";
	private static final String COLUMN_TOTAL_STTLM_AMT = "TOTAL_STTLM_AMT";
	private static final String COLUMN_OUT_CHUNK_ID = "OUT_CHUNK_ID";
	private static final String COLUMN_STTLM_DATE = "STTLM_DT";

	static
	{
		try
		{
			m_processCloseOpenNewOutFilesInner = BOCloseOpenNewOutFiles.class.getDeclaredMethod("processCloseOpenNewOutFilesInner", Serializable.class);
		}catch(Exception e)
		{
			logger.error(e.getMessage());
		}
	}


	public Feedback processCloseOpenNewOutFiles(Serializable tuple) throws FlowException
	{
		return (Feedback)super.executeInProtectedBoundaries(m_processCloseOpenNewOutFilesInner, tuple);
	}


	public Feedback processCloseOpenNewOutFilesInner(Serializable tuple) throws Throwable
	{	


		final String COLUMN_OUT_FILE_GROUPING_ID = "OUT_FILE_GROUPING_ID";
		Feedback feedback = new Feedback();

		CloseOpenOutFilesRequestDocument doc = null;

		doc = (CloseOpenOutFilesRequestDocument)tuple ;
		CloseOpenNewOutFileData data = new CloseOpenNewOutFileData();
		boolean lastSendingTime;
		boolean shouldContinue = true;
		int numberOfSentOutFiles ;
		int numberOfFutureLastSendingTimeFiles;
		final int maxFilesPerDay;
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		String UID_MOP = doc.getCloseOpenOutFilesRequest().getUidMop();
		data.setFromTime(!GlobalUtils.isNullOrEmpty(doc.getCloseOpenOutFilesRequest().getFromTime()) ? doc.getCloseOpenOutFilesRequest().getFromTime() : null) ;
		data.setTimeToSend(!GlobalUtils.isNullOrEmpty(doc.getCloseOpenOutFilesRequest().getToTime()) ? doc.getCloseOpenOutFilesRequest().getToTime() : null) ;
		boolean isUserRequest = doc.getCloseOpenOutFilesRequest().getUserRequest();
		logger.info("BOCloseOpenNewOutFiles parameters : UID_MOP : {} , FromTime : {} , Totime : {} ",new Object[]{UID_MOP,data.getFromTime(),data.getTimeToSend()});

		Mop mop = CacheKeys.mopKey.getSingle(UID_MOP);
		String bulkingProfileUID = mop.getBulkingProfileUid();
		String office = mop.getOffice();
		String mopName = mop.getMop();
		data.setMopName(mopName);
		BulkingProfile bulkProfile = CacheKeys.bulkingProfileKey.getSingle(bulkingProfileUID);
		data.setExpectAck(bulkProfile.getAckInd() != null  ? bulkProfile.getAckInd() : false);
		String bulkingProfileName = bulkProfile.getBpName();
		maxFilesPerDay = bulkProfile.getMaxFilesPerDay() != null  ?  bulkProfile.getMaxFilesPerDay().intValue() : Integer.MAX_VALUE;
		data.setMinTransactionPerFile(isUserRequest ? 1 :  bulkProfile.getMinTranPerFile().intValue());
		data.setMaxBulksPerFile(bulkProfile.getMaxBulkPerFile() != null ? bulkProfile.getMaxBulkPerFile().intValue() : Integer.MAX_VALUE);
		data.setMaxTranPerBulk( bulkProfile.getMaxTranPerBulk().intValue());
		Banks banks = CacheKeys.banksKey.getSingle(office);
		logger.info("BOCloseOpenNewOutFiles for MOP : {} , Bulking Profile : {} ",mopName, bulkingProfileName);

		//Get current time for the office ( MOP office)
		DateAndZone dateAndZone = NewASDateTimeUtils.getCurrentDateAndZoneByOffice(office);
		//Get time converted to HH24:MI
		long lofficeTime = dateAndZone.getDate().getTime();
		Date currentDate = new Date(lofficeTime);
		SimpleDateFormat simpleShortTimeFormat = GlobalDateTimeUtil.getSimpleShortTimeFormat();
		String currentOfficeTime  = simpleShortTimeFormat.format(currentDate) ;

		con = m_daoCloseOpenNewOutFiles.getConnection();
		//Check if the current office time (converted to HH24:MI) is marked as a Last Sending time 
		lastSendingTime = m_daoCloseOpenNewOutFiles.CheckIfLastSendingTime(con,bulkingProfileUID,currentOfficeTime);
		//marked as Last sending time 
		if (lastSendingTime) {
			data.setSendingTimeMarkedAsLast(true);
			data.setMinTransactionPerFile(1);

		}else {
			data.setSendingTimeMarkedAsLast(false);
			Date officeDate = banks.getBsnessdate();
			numberOfSentOutFiles = m_daoCloseOpenNewOutFiles.CheckNumberOfSentOutFiles(con,mopName,officeDate);
			logger.info("Number of files that were sent out for the bulking profile {} : {}",bulkingProfileName,numberOfSentOutFiles);
			numberOfFutureLastSendingTimeFiles = m_daoCloseOpenNewOutFiles.CheckNumberOfFutureLastSendingFiles(con,bulkingProfileUID,currentOfficeTime);
			logger.info("Number of last sending file we are going to have for the bulking profile {} : {}",
					bulkingProfileName,numberOfFutureLastSendingTimeFiles);
			logger.info("Max files per day allowed for the bulking profile {} : {}",bulkingProfileName,maxFilesPerDay); 


			// we can only send in the sending time that are marked as last, need to wait to a sending time that is defined as Last 
			if (numberOfSentOutFiles >= maxFilesPerDay - numberOfFutureLastSendingTimeFiles) {
				shouldContinue = false;

			}else {
				//we'll be used in case we'll need to generate more than one file for this window
				data.setNumberOfFilesCanBeSent( maxFilesPerDay - numberOfSentOutFiles - numberOfFutureLastSendingTimeFiles) ;
				logger.info("Number of files that can be sent (Beside the last sending times) for  bulking profile {} : {}",
						bulkingProfileName,data.getNumberOfFilesCanBeSent());
			}
		}
		//We are allowed to continue send file according to the logic above
		if (shouldContinue) {
			try {
				ps = m_daoCloseOpenNewOutFiles.getOutFileGroupingID(con,data);
				rs = ps.executeQuery();
			  if(!rs.isBeforeFirst())
				  logger.error("out file grouping id was not created for the outgoing file");
				//Number of files that can be generated:
				//1.If SendingTimeMarkedAsLast - create as much as needed
				//TODO 2.If not SendingTimeMarkedAsLast -  Loop only numberOfFilesCanBeSent times (SendingTimeMarkedAsLast ||
				while (rs.next() && (data.isSendingTimeMarkedAsLast() || data.getNumberOfCurrentSentFiles() <= data.getNumberOfFilesCanBeSent())){
					String outFileGroupingID = rs.getString(COLUMN_OUT_FILE_GROUPING_ID);
					logger.info("Start accumaltion for out file grouping id {} " , outFileGroupingID);
					feedback = accumulationAndCreatingAccounting(con,data,outFileGroupingID,bulkProfile,feedback);
				}
				logger.info("Number of sent files : {}",data.getNumberOfCurrentSentFiles()); 
			}
			catch(Throwable t){
				throw new FlowException(t);
			}finally{
				m_daoCloseOpenNewOutFiles.releaseResources(con,ps, rs);
			}

		}


		return feedback;
	}


	private Feedback accumulationAndCreatingAccounting(Connection con ,CloseOpenNewOutFileData data ,String outFileGroupingID,BulkingProfile bulkProfile,Feedback feedback) throws Throwable {



		data.setOutFileID(GlobalUtils.generateGUID()); //new MID for the new INTERNAL_FILE_ID of the out file which is about to be created
		data.setGroupMsgId(GlobalUtils.generateGUID());
		data.setAccountingMID(GlobalUtils.generateGUID()); //MID for the accounting message 
		List<String> outChunkIdList = new ArrayList<String>();

		logger.info("Method Input : outFileGroupingID - {} , fromTime - {} , TiemToSend - {} ",new Object[]{outFileGroupingID,data.getFromTime(),data.getTimeToSend()});
		PreparedStatement psSelect = null;
		PreparedStatement psUpdate = null;
		ResultSet rs = null;
		try {
			psSelect = m_daoCloseOpenNewOutFiles.getOutFileBufferInfoForOutFileGroupingID(con,outFileGroupingID,data.getFromTime(),data.getTimeToSend());
			rs = psSelect.executeQuery();
			double totalSttlmAmt = 0;
			int numberOfTransactionsInChunk = 0;
			PDO accountingPDO = null;
			Map<String, Object> accumulationsMap =  new HashMap<String, Object>(); 
			String previousSuspenceAccount = null;
			String currentSuspenceAccount = null;
			String currentOutGroupingID = null;
			String previousOutGroupingID = null;
			Date previousSttlmDt = null;
			Date currentSttlmDt = null;
			boolean shouldUpdateAccountingMID;

			while (rs.next() && !GlobalUtils.isNullOrEmpty(data.getOutFileID())){
				data.setMessageInsertInCurrentRound(false);
				//In order to figure out later if need to close group or insert 'A' Payment
				previousOutGroupingID = currentOutGroupingID;
				currentOutGroupingID = rs.getString(COLUMN_OUT_GROUPING_ID);
				previousSuspenceAccount = currentSuspenceAccount;
				currentSuspenceAccount = rs.getString(COLUMN_SUSPENSE_ACCT_UID);
				previousSttlmDt = currentSttlmDt;
				currentSttlmDt =  new Date(rs.getDate(COLUMN_STTLM_DATE).getTime());

				shouldUpdateAccountingMID = !GlobalUtils.isNullOrEmpty(currentSuspenceAccount);
				//Check if suspense account has been changed ( need to insert a new 'A' message for the accumulation before this entry ) 
				if (!GlobalUtils.isNullOrEmpty(previousSuspenceAccount) && !previousSuspenceAccount.equals(currentSuspenceAccount) ||
						!GlobalUtils.isObjectNullOrEmpty((previousSttlmDt)) && !previousSttlmDt.equals(currentSttlmDt)) {
					accumulationsMap.put(COLUMN_TOTAL_STTLM_AMT,Double.toString(data.getTotalSttlmAmt()));
					accumulationsMap.put(COLUMN_TOTAL_MSG_COUNT_NB,data.getSumTotalTranInBulk());

					accountingPDO = InsertAccountingMessage(data,bulkProfile,accumulationsMap,feedback);

				}

				//Get the number of transactions in the chunk for the limitation check
				numberOfTransactionsInChunk = rs.getInt(COLUMN_TOTAL_MSG_COUNT_NB);

				//Check if need to close the group and the file 
				if ((!GlobalUtils.isNullOrEmpty(previousOutGroupingID) && !previousOutGroupingID.equals(currentOutGroupingID)) 
						|| (numberOfTransactionsInChunk + data.getSumTotalTranInBulk()> data.getMaxTranPerBulk()) ) {

					//Close Group
					CloseGroup(data);
					//Check if need to Close File
					if(data.getNumberOfBulksInFile() == data.getMaxBulksPerFile()) {
						//Close File
						feedback = CloseFile(con,data,accountingPDO,bulkProfile,feedback,outChunkIdList,false/*ShouldCheckforLeftOvers*/,outFileGroupingID,accumulationsMap);
					}
				}

				// Entry can be aggregated into a file since we didn't reach the limitation
				if (!GlobalUtils.isNullOrEmpty(data.getOutFileID()))
				{
					//Means this is the first transaction related to new 'A' Payment
					if ( GlobalUtils.isMapNullOrEmpty(accumulationsMap) ) {
						accumulationsMap = new HashMap<String, Object>(); 
						accumulationsMap.put(COLUMN_OUT_GROUPING_ID,currentOutGroupingID);
						accumulationsMap.put(COLUMN_INDIVIDUAL_MID,rs.getString(COLUMN_INDIVIDUAL_MID));
						accumulationsMap.put(COLUMN_SUSPENSE_ACCT_UID,rs.getString(COLUMN_SUSPENSE_ACCT_UID));
						accumulationsMap.put(COLUMN_STTLM_DATE,rs.getTimestamp(COLUMN_STTLM_DATE));
					}

					//Accumulate the total amount
					data.addToTotalSttlmAmt(rs.getDouble(COLUMN_TOTAL_STTLM_AMT));
					data.addToSumTotalTranInBulk(numberOfTransactionsInChunk);
					String outChunkID = rs.getString(COLUMN_OUT_CHUNK_ID);

					psUpdate = m_daoCloseOpenNewOutFiles.updateOUT_FILE_BUFFERS(con,data.getOutFileID(),data.getGroupMsgId(),data.getAccountingMID(),outChunkID,shouldUpdateAccountingMID);
					int roweffected = psUpdate.executeUpdate();
					//No entries where effected i.e. clear indication that another tread is working in parallel on the same MOP (Need to figure out when...)
					if (GlobalConstants.ZERO_INTEGER.equals(roweffected)) {
						throw new FlowException("Update out file buffers failed - another thread is working in parallel on the same MOP");
					}else {
						outChunkIdList.add(outChunkID);
					}

				}
			}//EO While(rs.next)

			//Need close Group and File if not closed yet 
			if (!GlobalUtils.isNullOrEmpty(data.getOutFileID())) {

				//close group
				CloseGroup(data);
				//close file
				feedback = CloseFile(con, data, accountingPDO,bulkProfile,feedback,outChunkIdList,false/*ShouldCheckforLeftOvers*/,outFileGroupingID,accumulationsMap);
			} 
		}
		catch(Throwable t){
			throw new FlowException(t);
		}finally{
			m_daoCloseOpenNewOutFiles.releaseResources(psUpdate, rs);
			m_daoCloseOpenNewOutFiles.releaseResources(psSelect);
		}



		return feedback;  

	}

	private Feedback CloseFile(Connection conn ,CloseOpenNewOutFileData data ,PDO pdo ,BulkingProfile bulkProfile ,Feedback feedback , 
			List outChunkIdList, boolean ShouldCheckforLeftOvers,String outFileGroupingID,Map<String , Object> accumulationsMap) throws Throwable{

		boolean canCreateAnotherFileFromLeftOvers;

		//Accounting message was NOT just inserted (since the suspense account was also changed )
		//Means we have to insert a new payment ( Need to update accumulation map with totals )
		if (!GlobalUtils.isMapNullOrEmpty(accumulationsMap)){
			accumulationsMap.put(COLUMN_TOTAL_STTLM_AMT,Double.toString(data.getTotalSttlmAmt()));
			accumulationsMap.put(COLUMN_TOTAL_MSG_COUNT_NB,data.getSumTotalTranInBulk());
			data.setMessageInsertInCurrentRound(false);
			logger.info("CloseFile - Need to insert Accounting message (Not yet insert");
			pdo = InsertAccountingMessage(data,bulkProfile,accumulationsMap,feedback);
		}

		handleFilesummaryCreationAndSendOut(pdo,data, bulkProfile);
		data.addToNumberOfCurrentSentFiles(1);
		data.setNumberOfBulksInFile(0);
		data.setSumTotalTranInFile(0);

		if (data.isSendingTimeMarkedAsLast()) {
			data.setOutFileID(GlobalUtils.generateGUID());
		}else{//Need to add logic if leftover meet the minimum limitation ( And UI setup ) and if not, skip it(set outFileId[0] to null) for the next entry of OUT_FILE_GROUPING_ID
			// Currently we are not using that option
			if (ShouldCheckforLeftOvers) {
				canCreateAnotherFileFromLeftOvers =  (data.getNumberOfCurrentSentFiles() < data.getNumberOfFilesCanBeSent()) &&
						m_daoCloseOpenNewOutFiles.getOutFileGroupingIDLeftOvers(conn,outFileGroupingID,data.getMinTransactionPerFile(),outChunkIdList);
				data.setOutFileID(canCreateAnotherFileFromLeftOvers ? GlobalUtils.generateGUID() : null );
			}else
				data.setOutFileID(null);
		}

		return feedback;
	}

	private void handleFilesummaryCreationAndSendOut(PDO pdo, CloseOpenNewOutFileData data, BulkingProfile bulkingProfile ) throws Throwable
	{
		//handleFilesummaryCreationAndSendOut(pdo,data, data.getOutFileID(), bulkProfile, data.getSumTotalTranInFile(), data.getTimeToSend());
		// Updates FILE_SUMMARY with dealt internal file ID, status 'ReadyToBeSent' and MID of 
		// the credit lump sum process if such one was created.
		boolean isCreditLumpSum = bulkingProfile.getCreditLumpSum() != null && bulkingProfile.getCreditLumpSum();
		String internalFileId =  data.getOutFileID();
		String lastCompletedMid = pdo.getMID();
		String outGroupId = pdo.getString(PDOConstantFieldsInterface.P_OUT_GROUPING_ID);
		String office = pdo.getString(PDOConstantFieldsInterface.P_OFFICE);   
		String department = pdo.getString(PDOConstantFieldsInterface.P_DEPARTMENT) ;
		
		
		//get mop from db and not from pdo, because pdo might be the A message, which has a MOP=BOOK 
		String mopName = data.getMopName();
		Mop mop =  CacheKeys.mopKey.getSingle(office, mopName);
		
	    
		String sendingInst = mop != null && mop.getSenderBic() != null ? mop.getSenderBic() : null; 
		String finCopyService = mop != null ? mop.getFincopyservice() : null;
		 
		String receiverBic = bulkingProfile.getReceiverBic();
		String outFileBuffStatus = SubBatchProcessInterface.STATUS_POSTING_COMPLETED;
		
		long currentMillis =  System.currentTimeMillis();

		// Set priority for JMS
		HashMap mapContext = null;
		if( pdo != null ){
			mapContext= new HashMap();
			mapContext.put( "PRIORITY", pdo.getString( PDOConstantFieldsInterface.P_PRIORITY));
		}

		String fileName;
		String fileType;
		String fileReference;
		if ("G3BULK".equals(mopName)){//TODO GALIT: Temp solution for deciding whether it is G3 or SEPA	
			fileType = getG3FileType(pdo);
			fileName = createG3FileName(pdo,fileType,mop,office,currentMillis);
			fileReference = fileName;
			m_daoCloseOpenNewOutFiles.updateOUT_FILE_BUFFERSGroupMsgId(data.getOutFileID(),data.getGroupMsgId(),fileReference);
		}else{
			fileType = bulkingProfile.getFileType();
			fileName = internalFileId;
			fileReference = internalFileId;
		}


		m_daoDebulkingProcess.createFileSummaryEntry(null, office, department,internalFileId, fileName, bulkingProfile.getFileDes(),
				currentMillis, null, null, sendingInst, new Timestamp(currentMillis), SubBatchProcessInterface.STATUS_READY_TO_BE_SENT, null, null,
				null, null, null, fileReference, data.getSumTotalTranInFile(),null, null, null, null, bulkingProfile.getUidBulkingProfile(),
				outGroupId, "O", finCopyService, bulkingProfile.getMaxTranPerBulk(), bulkingProfile.getMinTranPerFile(), data.getMopName(), 
				data.getTimeToSend(), lastCompletedMid, data.getMopName(), isCreditLumpSum, receiverBic, bulkingProfile.getTestCode(),
				fileType, null, null, data.isExpectAck(), null, null, null, 0,0, 0, 0);


		if (isCreditLumpSum)
		{
			PDO creditLumpSum = PaymentDataFactory.load(lastCompletedMid);
			if (MessageConstantsInterface.MONITOR_FLAG_WAITING.equals(creditLumpSum.getString(PDOConstantFieldsInterface.MF_POSTING_STS)))
				outFileBuffStatus = SubBatchProcessInterface.STATUS_POSTING_WAS_SENT;
		}

		InterfaceTypes interfaceType= CacheKeys.interfaceTypesKey.getSingle(GlobalConstants.DEFAULT_SERVER_OFFICE_NAME, InterfaceTypes.INTERFACE_TYPE_MASSPMNTS, 
				InterfaceTypes.INTERFACE_SUB_TYPE_FSEND_O);

		ProcessRebulkRequestDocument rebulkReq = ProcessRebulkRequestDocument.Factory.newInstance();
		rebulkReq.setProcessRebulkRequest(internalFileId + GlobalConstants.COMMA + SubBatchProcessInterface.STATUS_READY_TO_BE_SENT); 

		if (interfaceType != null) TransmissionType.valueOf(interfaceType.getRequestProtocol()).transmitInTx(rebulkReq, null, interfaceType, null, mapContext);	  
	}


	private String getG3FileType(PDO pdo){
		//derive fileType from pdo and not from bulking profile
		String msgType = pdo.getString(PDOConstantFieldsInterface.P_MSG_TYPE);
		if (MessageConstantsInterface.MESSAGE_TYPE_PACS_009.equals(pdo.getString(PDOConstantFieldsInterface.P_MSG_TYPE))){//this is the A-msg
			String outInternalFileId = pdo.getString(PDOConstantFieldsInterface.P_OUT_INTERNAL_FILEID);
			DTOSingleValue dto = m_daoCloseOpenNewOutFiles.getMSG_TYPEbyOUT_FILE_ID(outInternalFileId);
			msgType = dto.getValue();		
		}
		if (MessageConstantsInterface.MESSAGE_TYPE_PACS_004.equals(msgType)){
			return "ORD";
		}else{
			return "OWD";
		}
	}

	private String createG3FileName(PDO pdo, String fileType, Mop mop,String office,long currentMillis){

		//build fileName for outgoing file according to G3 format
		StringBuilder generatedFileName=new StringBuilder();

		String ccy=""; 
		if (mop!=null){
			ccy = mop.getCurrency();
		}
		if (ccy==null){
			ccy = pdo.getString(PDOConstantFieldsInterface.X_STTLM_CCY);
		}
		generatedFileName.append(ccy);

		generatedFileName.append(fileType);

		//get only date from time stamp in yyyyMMdd format:
		Date currDateTime=new Date();
		currDateTime.setTime(currentMillis);
		DateFormat formatter=new SimpleDateFormat("yyyyMMdd");
		String date = formatter.format(currDateTime);
		generatedFileName.append(date);


		InstructionIdGenerator instructionIdGenerator = (InstructionIdGenerator) SpringApplicationContext.getBean("g3InstructionIdGenerator");
		instructionIdGenerator.generateInstructionId(false, true, true,office);
		//bic
		try{
			String bic = instructionIdGenerator.getLocalBic(office);
			if (!StringUtils.isEmpty(bic)) {
				if(bic.length()<=8){
					generatedFileName.append(bic);
				}else{
					generatedFileName.append(bic.substring(0, 8));
				}
			}
		} catch (Exception ex) {
			logger.error("Failed to get BIC for office {} message, caught exception:{}", office, ex.getMessage());
		}	

		//B
		generatedFileName.append("B");

		//seq number
		int seqNum = instructionIdGenerator.getSequenceNumber();
		int p=String.valueOf(seqNum).length();
		for(int i=7;i-p>0;i--){
			generatedFileName.append("0");
		}
		generatedFileName.append(seqNum);

		String g3fileName = generatedFileName.toString();
		return g3fileName;

	}


	private void CloseGroup(CloseOpenNewOutFileData data ) {

		final String TRACE_METHOD_INPUT = "";
		logger.info(TRACE_METHOD_INPUT);

		//Create new UID for the next group
//		data.setGroupMsgId(GlobalUtils.generateGUID());
		data.addToNumberOfBulksInFile(1);
		data.addToSumTotalTranInFile(data.getSumTotalTranInBulk());
		data.setSumTotalTranInBulk(0);	  
	}


	private PDO InsertAccountingMessage(CloseOpenNewOutFileData data,BulkingProfile bulkProfile , Map<String , Object> accumulateMap ,Feedback feedback ) {

		final String TRACE_CREDIT_LUMP_SUM = "Credit lump sum value: ";
		final String TRACE_NEED_TO_CREATE_ACCOUNTING_PAYMENT = "Need to create accounting message for the group : " ;
		final String TRACE_AFTER_CLOSE_OPEN_NEW_OUT_FILES_FLOW = "after executing close open new out files flow";
		final String TRACE_CREATING_ACCOUNTING_PAYMENT = "Creating A Payment using : Individual MID - {} , Out Internal File Id - {} , Out Msg Bulk ID - {} ," +
				"Total sttlm amount - {} , Debit Account - {} "; 
		final String TRACE_PDO_BATCH_SAVE_BEFORE = "BEFORE calling 'PaymentDataFactory.batchSave'";
		final String TRACE_PDO_BATCH_SAVE_AFTER = "AFTER calling 'PaymentDataFactory.batchSave'";
		String sMID_CreditLumpSum = null;
		boolean isCreditLumpSum = bulkProfile.getCreditLumpSum() != null && bulkProfile.getCreditLumpSum();
		logger.info(TRACE_CREDIT_LUMP_SUM + isCreditLumpSum);
		String suspenseAccount = (String)accumulateMap.get(COLUMN_SUSPENSE_ACCT_UID);
		boolean needToCreateAccounting = !GlobalUtils.isNullOrEmpty(suspenseAccount);
		logger.info(TRACE_NEED_TO_CREATE_ACCOUNTING_PAYMENT + needToCreateAccounting);

		String sINDIVIDUAL_MID = (String)accumulateMap.get(COLUMN_INDIVIDUAL_MID);
		PDO pdo = null;
		if(isCreditLumpSum && needToCreateAccounting)
		{
			String totalSttlmAmt = (String)accumulateMap.get(COLUMN_TOTAL_STTLM_AMT);
			// Loads the template PDO and gets from it a new PDO for rest of the process while updating some values in it
			logger.info(TRACE_CREATING_ACCOUNTING_PAYMENT,new Object[]{sINDIVIDUAL_MID,data.getOutFileID(),data.getGroupMsgId(),totalSttlmAmt,suspenseAccount});

			pdo = getNewPDOFromTemplatePDO(data.getAccountingMID() ,sINDIVIDUAL_MID, totalSttlmAmt, data.getOutFileID(), data.getGroupMsgId(), suspenseAccount);
			pdo.promoteToPrimary();
			sMID_CreditLumpSum = pdo.getMID();
			// Executes flow.      
			feedback = BOProxies.m_businessFlowSelectorLogging.executeFlow(Admin.getContextAdmin(), sMID_CreditLumpSum, false/*save pdo*/,ServerConstants.EMPTY_OBJECT_ARRAY) ;
			logger.info(TRACE_AFTER_CLOSE_OPEN_NEW_OUT_FILES_FLOW);	 
			try {
				logger.info(TRACE_PDO_BATCH_SAVE_BEFORE);
				PaymentDataFactory.batchSave(true, pdo);
				logger.info(TRACE_PDO_BATCH_SAVE_AFTER);
			}
			catch(Throwable t) {
				throw new FlowException(t);
			}
			Timestamp sttlmDateTimeStamp = (Timestamp)accumulateMap.get(COLUMN_STTLM_DATE);
			String formattedDate = GlobalDateTimeUtil.getFormattedDateString(sttlmDateTimeStamp,GlobalDateTimeUtil.STATIC_DATA_DATE);

			//Put In cache the data (A payment related to group_msg_id + suspence acct + sttlm dt 
			APaymentPerGroupMsgID aPaymentPerGroupMsgID = new APaymentPerGroupMsgID(formattedDate,data.getGroupMsgId(),suspenseAccount,data.getAccountingMID());
			CacheKeys.APaymentPerGroupMsgIDKey.putSingle(aPaymentPerGroupMsgID,formattedDate,data.getGroupMsgId(),suspenseAccount);

			//We insert the Accounting message
			data.setMessageInsertInCurrentRound(true);
			//Need to Start new accumulation
			accumulateMap.clear();
			//Reset the total settlement amount
			data.setTotalSttlmAmt(0);
			data.setAccountingMID(GlobalUtils.generateGUID());
		}else {
			pdo = PaymentDataFactory.load(sINDIVIDUAL_MID);
		}

		return pdo;

	}

	private PDO getNewPDOFromTemplatePDO(String accountingMID ,String sIndividualMID, String totalSttlmAmount,  String sInternalFileID ,
			String sOutBulkMsgId, String suspenseAcctUid)
	{


		PDO newPDO = PaymentDataFactory.newPDO(PaymentType.valueOf(PaymentType.PT_PACS_009), true/*bTransient*/, true/*bPrimary*/, false/*bConjoinedOrigNCurrentMode*/,accountingMID);

		// Loads the template PDO of the passed 'sIndividualMID' from MINF table.
		PDO templatePDO = PaymentDataFactory.load(sIndividualMID);

		// Valid PDO.
		if(templatePDO != null)
		{

			newPDO.set(PDOConstantFieldsInterface.P_TX_CTGY, templatePDO.getString(PDOConstantFieldsInterface.P_TX_CTGY));
		    newPDO.set(PDOConstantFieldsInterface.P_BUSINESS_FLOW_TP, templatePDO.getString(PDOConstantFieldsInterface.P_BUSINESS_FLOW_TP));
		    newPDO.set(PDOConstantFieldsInterface.P_IS_HISTORY, templatePDO.getString(PDOConstantFieldsInterface.P_IS_HISTORY));
			String sCreditCurrency = templatePDO.getString(PDOConstantFieldsInterface.X_STTLM_CCY);
			newPDO.set(PDOConstantFieldsInterface.X_STTLM_CCY, sCreditCurrency);
			newPDO.set(PDOConstantFieldsInterface.OX_STTLM_CCY, sCreditCurrency);

			totalSttlmAmount = !isNullOrEmpty(totalSttlmAmount) ? totalSttlmAmount : ServerConstants.ZERO_VALUE;
			BigDecimal amount = new BigDecimal(totalSttlmAmount);
			newPDO.set(PDOConstantFieldsInterface.P_CDT_AMT, amount);
			newPDO.set(PDOConstantFieldsInterface.X_STTLM_AMT, GlobalUtils.adjustPrecisionBD(amount,sCreditCurrency));
			newPDO.set(PDOConstantFieldsInterface.OX_STTLM_AMT, GlobalUtils.adjustPrecisionBD(amount,sCreditCurrency));

			newPDO.set(PDOConstantFieldsInterface.P_DBT_AMT, amount);

			newPDO.set(PDOConstantFieldsInterface.P_BATCH_MSG_TP, BATCH_MESSAGE_TYPE_ACCOUNTING);
			newPDO.set(BOBaseProcess.getDestinationMopLogicalField(templatePDO), MOP_BOOK);
			newPDO.set(PDOConstantFieldsInterface.P_MSG_SUB_TYPE, MESSAGE_SUB_TYPE_ACC);

			newPDO.set(PDOConstantFieldsInterface.P_DEPARTMENT, templatePDO.getString(PDOConstantFieldsInterface.P_DEPARTMENT));

			String sOffice = templatePDO.getString(PDOConstantFieldsInterface.P_OFFICE);
			newPDO.set(PDOConstantFieldsInterface.P_OFFICE, sOffice);

			newPDO.set(PDOConstantFieldsInterface.X_STTLM_DT_1B, templatePDO.getDate(PDOConstantFieldsInterface.X_STTLM_DT_1B));
			newPDO.set(PDOConstantFieldsInterface.P_PROC_DT, templatePDO.getDate(PDOConstantFieldsInterface.P_PROC_DT));

			newPDO.set(PDOConstantFieldsInterface.X_TX_NO, "1");
			newPDO.set(PDOConstantFieldsInterface.X_CHRG_BR, "SLEV");
			String mid= newPDO.getMID();
			newPDO.set(PDOConstantFieldsInterface.X_MSG_ID, mid);
			newPDO.set(PDOConstantFieldsInterface.X_INSTR_ID, mid);
			newPDO.set(PDOConstantFieldsInterface.X_END_TO_END_ID, mid);
			newPDO.set(PDOConstantFieldsInterface.X_TX_ID, mid);

			newPDO.set(PDOConstantFieldsInterface.X_STTLM_MTD, "CLRG");
			String localOfficeBic = templatePDO.getNSetOffice().getSwiftId();
			newPDO.set(PDOConstantFieldsInterface.X_INSTG_AGT_BIC_2AND, localOfficeBic);
			newPDO.set(PDOConstantFieldsInterface.X_INSTD_AGT_BIC_2AND, localOfficeBic);
			newPDO.set(PDOConstantFieldsInterface.P_CDT_VD, templatePDO.get(PDOConstantFieldsInterface.P_CDT_VD));
			newPDO.set(PDOConstantFieldsInterface.P_DBT_VD, templatePDO.get(PDOConstantFieldsInterface.P_DBT_VD));
			newPDO.set(PDOConstantFieldsInterface.X_CDTR_NM, templatePDO.get(PDOConstantFieldsInterface.X_CDTR_ACCT_NM));

			newPDO.copyGroup(templatePDO, "XML_MSG", PDOConstantFieldsInterface.X_DBTR, PDOConstantFieldsInterface.X_DBTR_ACCT);


			String suspenceAcctSide = templatePDO.getString(PDOConstantFieldsInterface.P_SUSPENSE_ACCT_SIDE);

			if (suspenceAcctSide.equals("CDT")) {//Credit transfer
				// Sets the CREDIT account related fields from the loaded MINF .
				newPDO.set(PDOConstantFieldsInterface.P_CDT_ACCT_NB, templatePDO.getString(PDOConstantFieldsInterface.P_CDT_ACCT_NB));
				newPDO.set(PDOConstantFieldsInterface.P_CDT_ACCT_CCY,templatePDO.getString(PDOConstantFieldsInterface.P_CDT_ACCT_CCY));
				newPDO.set(PDOConstantFieldsInterface.P_CDT_ACCT_OFFICE,templatePDO.getString(PDOConstantFieldsInterface.P_CDT_ACCT_OFFICE));

				// Sets the DEBIT account to be the suspenseAcctUid
				Accounts debitAccount = CacheKeys.accountsKey.getSingle(suspenseAcctUid);
				newPDO.set(PDOConstantFieldsInterface.P_DBT_ACCT_NB, debitAccount != null ? debitAccount.getAccNo() : null);
				newPDO.set(PDOConstantFieldsInterface.P_DBT_ACCT_CCY, debitAccount != null ? debitAccount.getCurrency() : null);
				newPDO.set(PDOConstantFieldsInterface.P_DBT_ACCT_OFFICE, debitAccount != null ? debitAccount.getOffice() : null);
			}else { //Direct debit 

				// Sets the CREDIT account to be the suspenseAcctUid
				Accounts debitAccount = CacheKeys.accountsKey.getSingle(suspenseAcctUid);
				newPDO.set(PDOConstantFieldsInterface.P_CDT_ACCT_NB, debitAccount != null ? debitAccount.getAccNo() : null);
				newPDO.set(PDOConstantFieldsInterface.P_CDT_ACCT_CCY, debitAccount != null ? debitAccount.getCurrency() : null);
				newPDO.set(PDOConstantFieldsInterface.P_CDT_ACCT_OFFICE, debitAccount != null ? debitAccount.getOffice() : null);

				// Sets the DEBIT account related fields from the loaded MINF .
				newPDO.set(PDOConstantFieldsInterface.P_DBT_ACCT_NB, templatePDO.getString(PDOConstantFieldsInterface.P_DBT_ACCT_NB));
				newPDO.set(PDOConstantFieldsInterface.P_DBT_ACCT_CCY,templatePDO.getString(PDOConstantFieldsInterface.P_DBT_ACCT_CCY));
				newPDO.set(PDOConstantFieldsInterface.P_DBT_ACCT_OFFICE,templatePDO.getString(PDOConstantFieldsInterface.P_DBT_ACCT_OFFICE));
			}

			newPDO.set(PDOConstantFieldsInterface.X_CDTR_ACCT_ID, CacheKeys.accountsKey.getSingle(suspenseAcctUid).getAccNo());

			newPDO.set(PDOConstantFieldsInterface.P_DBT_CUST_CD, templatePDO.getString(PDOConstantFieldsInterface.P_DBT_CUST_CD));

			// Note: the P_IN_INTERNAL_FILEID remains empty.
			newPDO.set(PDOConstantFieldsInterface.P_OUT_INTERNAL_FILEID, sInternalFileID);
			newPDO.set(PDOConstantFieldsInterface.P_OUT_GROUPING_ID, templatePDO.getString(PDOConstantFieldsInterface.P_OUT_GROUPING_ID));
			newPDO.set(PDOConstantFieldsInterface.P_OUT_BULK_MSGID , sOutBulkMsgId); 
			newPDO.set(PDOConstantFieldsInterface.MF_FEE_PROC_STS, MONITOR_FLAG_PROCESSED);

			CacheKeys.ProcessPDOKey.removeFromLocalAndPropagateToRemote(templatePDO);
		}

		// Couldn't load PDO.
		else
		{
			logger.info(ERROR_MESSAGE_LOAD_PDO_FAILURE + sIndividualMID);
		}



		return newPDO;
	}  


}
