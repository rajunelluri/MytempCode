package backend.paymentprocess.closeopennewoutfiles.dao;



import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.dataaccess.dao.DAOBasic;
import backend.dataaccess.dto.DTOSingleValue;
import backend.paymentprocess.closeopennewoutfiles.common.CloseOpenNewOutFileData;

import com.fundtech.core.general.StatementParameter;
import com.fundtech.core.general.flows.FlowException;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalUtils;

/**
 * 
 */
public class DAOCloseOpenNewOutFiles extends DAOBasic
{

  private static final Logger logger = LoggerFactory.getLogger(DAOCloseOpenNewOutFiles.class);
  private static DAOCloseOpenNewOutFiles m_daoCloseOpenNewOutFiles = new DAOCloseOpenNewOutFiles();
 // private static BackendTracer GlobalTracer = GlobalTracer;
  
  /**
   * Private constructor. 
   */
  private DAOCloseOpenNewOutFiles()
  {
  }
  
  public static DAOCloseOpenNewOutFiles getInstance()
  {
    return m_daoCloseOpenNewOutFiles;
  }
  
  public Feedback updateOUT_FILE_BUFFERS_OUT_FILE_ID(String outFileId, String outGroupingId, String status)
  {
    final String SELECT_STATEMENT = "Update OUT_FILE_BUFFERS set OUT_FILE_ID = ?\r\n, status=?" + 
    		"WHERE OUT_GROUPING_ID = ? AND OUT_FILE_ID IS NULL";
    
    StatementParameter[] arrStatementParameters = new StatementParameter[]{new StatementParameter(outFileId, Types.VARCHAR),
    																		new StatementParameter(status, Types.VARCHAR),
                                                                           new StatementParameter(outGroupingId, Types.VARCHAR)};

    return doUpdate(SELECT_STATEMENT, arrStatementParameters, null, null);
  }

  public DTOSingleValue getBULKING_PROFILEbyOUT_GROUPING_ID(String sOutGroupingID)
  {
    final String SELECT_STATEMENT = "select BULKING_PROFILE from OUT_FILE_BUFFERS where OUT_GROUPING_ID = ? ";
    
    StatementParameter[] arrStatementParameters = new StatementParameter[]{new StatementParameter(sOutGroupingID, Types.VARCHAR)};
    
    return getSingleValue(SELECT_STATEMENT, arrStatementParameters, null);
  }
  
  public DTOSingleValue getMSG_TYPEbyOUT_FILE_ID(String sOutFileID)
  {
    final String SELECT_STATEMENT = "select MSG_TYPE from OUT_FILE_BUFFERS where OUT_FILE_ID = ? ";
    
    StatementParameter[] arrStatementParameters = new StatementParameter[]{new StatementParameter(sOutFileID, Types.VARCHAR)};
    
    return getSingleValue(SELECT_STATEMENT, arrStatementParameters, null);
  }

  public boolean CheckIfLastSendingTime(Connection conn ,String bulkingProfileUID , String currentOfficeTime) throws FlowException{
	  
	  PreparedStatement ps = null;
	  ResultSet rs = null;
	  int prevLastSendingTime = 0 ;
	  int nextLastSendingTime = 0 ;
	  
	  String SELECT_STATEMENT = "SELECT COUNT(*) FROM BULKING_SENDING_TIMES WHERE BULKING_PROFILE_UID = ? AND TIME_TO_SEND = ? AND \r\n" +
			  "LAST_SEND_TIME_IND <> 0";

	  try {
		  ps = conn.prepareStatement(SELECT_STATEMENT);

		  GlobalUtils.setObject(ps, 1, bulkingProfileUID);
		  GlobalUtils.setObject(ps, 2, currentOfficeTime);

		  rs = ps.executeQuery();
		  while (rs.next()){
			  logger.info("CheckIfLastSendingTime : Query - {} , Parameters - 1){} 2){} ,result : count = {} ",
					  new Object[]{SELECT_STATEMENT,bulkingProfileUID,currentOfficeTime,prevLastSendingTime});
			 if (rs.getInt(1) != 0){// return true if current time is last sending time
				 return true;
			 }
		  }

	  }catch(Throwable t){
		  throw new FlowException(t);
	  }finally{
		  super.releaseResources(ps, rs);
	  }

	  

	  
	  // check if we have last sending time before current time
	  SELECT_STATEMENT = "SELECT COUNT(*) FROM BULKING_SENDING_TIMES WHERE BULKING_PROFILE_UID = ? AND TIME_TO_SEND < ? AND \r\n" +
	  									"LAST_SEND_TIME_IND <> 0";
	  
	  try {
		    ps = conn.prepareStatement(SELECT_STATEMENT);
    
	      	GlobalUtils.setObject(ps, 1, bulkingProfileUID);
    	    GlobalUtils.setObject(ps, 2, currentOfficeTime);
      
      		rs = ps.executeQuery();
      		while (rs.next()){
      			prevLastSendingTime = rs.getInt(1);
      		}
      		
	  }catch(Throwable t){
		  throw new FlowException(t);
	  }finally{
		  super.releaseResources(ps, rs);
	  }
	  
	   logger.info("CheckIfLastSendingTime : Query - {} , Parameters - 1){} 2){} ,result : count = {} ",
					new Object[]{SELECT_STATEMENT,bulkingProfileUID,currentOfficeTime,prevLastSendingTime});
	  
	  // check if we have last sending time after current time
	  SELECT_STATEMENT = "SELECT COUNT(*) FROM BULKING_SENDING_TIMES WHERE BULKING_PROFILE_UID = ? AND TIME_TO_SEND > ? AND \r\n" +
			  "LAST_SEND_TIME_IND <> 0";

	  try {
		  ps = conn.prepareStatement(SELECT_STATEMENT);

		  GlobalUtils.setObject(ps, 1, bulkingProfileUID);
		  GlobalUtils.setObject(ps, 2, currentOfficeTime);

		  rs = ps.executeQuery();
		  while (rs.next()){
			  nextLastSendingTime = rs.getInt(1);
		  }

	  }catch(Throwable t){
		  throw new FlowException(t);
	  }finally{
		  super.releaseResources(ps, rs);
	  }
	  
	   logger.info("CheckIfLastSendingTime : Query - {} , Parameters - 1){} 2){} ,result : count = {} ",
					new Object[]{SELECT_STATEMENT,bulkingProfileUID,currentOfficeTime,nextLastSendingTime});
 
	  // if there is no previous last sending time or 
	  //there is previous last sending time, but there are also last sending time in the future - current time is not last sending time
	  return (prevLastSendingTime == 0 || (prevLastSendingTime != 0 && nextLastSendingTime != 0)) ? false : true ;
  }
  
   public int CheckNumberOfSentOutFiles(Connection conn , String mop , Date officeDate) {
	  
	  final String COLUMN_NUMEBR_OF_SENT_FILES= "NUMEBR_OF_SENT_FILES";
	   
	  PreparedStatement ps = null;
	  ResultSet rs = null;
	  int result = 0 ;
	  final String SELECT_STATEMENT = "SELECT COUNT(*) NUMEBR_OF_SENT_FILES FROM FILE_SUMMARY WHERE DIRECTION = 'O' AND \r\n" +
	   									"FILE_SUMMARY.MOP = ? AND FILE_SUMMARY.BSNESSDATE = ? AND STATUS IN ('ReadyToBeSent', 'FileWasSent')";
		   							
	  try {
		    ps = conn.prepareStatement(SELECT_STATEMENT);
    
	      	GlobalUtils.setObject(ps, 1, mop);
    	    GlobalUtils.setObject(ps, 2, new java.sql.Date(officeDate.getTime()));
      
      		rs = ps.executeQuery();
      		while (rs.next()){
			  result = rs.getInt(COLUMN_NUMEBR_OF_SENT_FILES);
      		}
      		
	  }catch(Throwable t){
		  throw new FlowException(t);
	  }finally{
		  super.releaseResources(ps, rs);
	  }   
		   
	   
	  return result;
   }
   
 
   public int CheckNumberOfFutureLastSendingFiles(Connection conn,String bulkingProfileUID, String officeTime){
	  final String COLUMN_NUMEBR_OF_LAST_SENDING_TIME= "NUMEBR_OF_LAST_SENDING_TIME";
	  
	  PreparedStatement ps = null;
	  ResultSet rs = null;
	  int result = 0 ;
	  final String SELECT_STATEMENT = "SELECT COUNT(*) NUMEBR_OF_LAST_SENDING_TIME FROM BULKING_SENDING_TIMES WHERE \r\n" +
	  									"BULKING_PROFILE_UID = ?  and TIME_TO_SEND > ? and LAST_SEND_TIME_IND <> 0 ";
	  
	   try {
		    ps = conn.prepareStatement(SELECT_STATEMENT);
    
	      	GlobalUtils.setObject(ps, 1, bulkingProfileUID);
    	    GlobalUtils.setObject(ps, 2, officeTime);
      
      		rs = ps.executeQuery();
      		while (rs.next()){
			  result = rs.getInt(COLUMN_NUMEBR_OF_LAST_SENDING_TIME);
      		}
      		
	  }catch(Throwable t){
		  throw new FlowException(t);
	  }finally{
		  super.releaseResources(ps, rs);
	  }   
	  
	  return result;
	   
   }
   
  public PreparedStatement getOutFileGroupingID (Connection conn,CloseOpenNewOutFileData data) throws Throwable
  {  
	  final String whereConditionFromTime = "AND TIME_TO_SEND >=  ? \r\n";
	  final String whereConditionToTime = "AND TIME_TO_SEND <=  ? \r\n";
	  final String havingSumTransactionHigherThen= "HAVING SUM(TOTAL_MSG_COUNT_NB) >= ? \r\n";
	  
	  
	  String fromTimeCondition = !GlobalUtils.isNullOrEmpty(data.getFromTime()) ?  whereConditionFromTime  : GlobalConstants.EMPTY_STRING;
	  String toTimeCondition = !GlobalUtils.isNullOrEmpty(data.getTimeToSend()) ?  whereConditionToTime  : GlobalConstants.EMPTY_STRING;
	  String havingSumTransactionHigherThenCondition = (!data.isSendingTimeMarkedAsLast()) ?  havingSumTransactionHigherThen  : GlobalConstants.EMPTY_STRING;
	  
	  final String SELECT_STATEMENT = "SELECT OUT_FILE_GROUPING_ID ,SUM(TOTAL_MSG_COUNT_NB) SUM_TOTAL_MSG_COUNT \r\n" +
	  								  "FROM OUT_FILE_BUFFERS \r\n" +
	  								  "WHERE MOP = ? AND OUT_FILE_GROUPING_ID IS NOT NULL \r\n" +
	  								  "AND OUT_FILE_ID is null \r\n" +
	  								  fromTimeCondition + toTimeCondition +
	  								  "GROUP by OUT_FILE_GROUPING_ID \r\n" +
	  								  havingSumTransactionHigherThenCondition;
  
	  PreparedStatement ps = conn.prepareStatement(SELECT_STATEMENT);
  	  int i = 1;
      GlobalUtils.setObject(ps, i++, data.getMopName());
      if (!GlobalUtils.isNullOrEmpty(fromTimeCondition)) {
    	  GlobalUtils.setObject(ps, i++, data.getFromTime());
      }
      if (!GlobalUtils.isNullOrEmpty(toTimeCondition)) {
    	  GlobalUtils.setObject(ps, i++, data.getTimeToSend());
      }
      if (!data.isSendingTimeMarkedAsLast()) {
      	GlobalUtils.setObject(ps, i++, data.getMinTransactionPerFile());
      }
      
      logger.info("Query - {} , Parameters - 1)MOP - {} 2)Time >=  {} 3)Time <= {} 4)Min Transaction Per File - {} ",
    		  new Object[]{SELECT_STATEMENT,data.getMopName(),data.getFromTime(),data.getTimeToSend(),data.getMinTransactionPerFile()});  
      
      return ps;
  }
  
  public PreparedStatement getOutFileBufferInfoForOutFileGroupingID(Connection conn,String outFileGroupingID, String fromTime, String toTime) throws Throwable
  {
  		final String whereConditionFromTime = "AND TIME_TO_SEND >=  ? \r\n";
	final String whereConditionToTime = "AND TIME_TO_SEND <=  ? \r\n";
	  
	String fromTimeCondition = !GlobalUtils.isNullOrEmpty(fromTime) ?  whereConditionFromTime  : GlobalConstants.EMPTY_STRING;
	String toTimeCondition = !GlobalUtils.isNullOrEmpty(toTime) ?  whereConditionToTime  : GlobalConstants.EMPTY_STRING;
	
  	final String SELECT_STATEMENT = "SELECT OUT_CHUNK_ID, OUT_GROUPING_ID, SUSPENSE_ACCT_UID, TOTAL_MSG_COUNT_NB,  INDIVIDUAL_MID, \r\n " +
  									    "TOTAL_STTLM_AMT, MSG_TYPE , STTLM_DT \r\n" +
	  									"FROM OUT_FILE_BUFFERS \r\n" +
	  									"WHERE OUT_FILE_GROUPING_ID = ? \r\n" +
	  									"AND OUT_FILE_ID is null \r\n" + 
	  									fromTimeCondition + toTimeCondition +
	  									"ORDER BY OUT_GROUPING_ID, SUSPENSE_ACCT_UID, STTLM_DT, TOTAL_MSG_COUNT_NB, OUT_CHUNK_ID";
  
	PreparedStatement ps = conn.prepareStatement(SELECT_STATEMENT);
	int i = 1;
    GlobalUtils.setObject(ps, i++, outFileGroupingID);
    if (!GlobalUtils.isNullOrEmpty(fromTimeCondition)) {
    	  GlobalUtils.setObject(ps, i++, fromTime);
    }
    if (!GlobalUtils.isNullOrEmpty(toTimeCondition)) {
    	  GlobalUtils.setObject(ps, i++, toTime);
    }
    logger.info("Query - {} , Parameters - 1){} 2){} 3){} ",
			  							new Object[]{SELECT_STATEMENT,outFileGroupingID,fromTime,toTime});  

  	return ps;
  }
  
  
  public PreparedStatement updateOUT_FILE_BUFFERS(Connection conn,String outFileId, String outGroupingId, String accountingMID ,String outChunkID,
		  							boolean updateAccountingMID) throws Throwable
  {

	String accoutingUpdate = updateAccountingMID ? ", ACCOUNTING_MID = ? " : "";
	
	final String UPDATE_STATEMENT =  "UPDATE OUT_FILE_BUFFERS SET OUT_FILE_ID = ? , GROUP_MSG_ID = ? " + accoutingUpdate + 
					"WHERE OUT_CHUNK_ID = ? AND OUT_FILE_ID is Null " ;

	PreparedStatement ps = conn.prepareStatement(UPDATE_STATEMENT); 
	int i = 1;
	GlobalUtils.setObject(ps, i++, outFileId);
	GlobalUtils.setObject(ps, i++, outGroupingId);
	if (updateAccountingMID) {
		GlobalUtils.setObject(ps, i++, accountingMID);
	}
	GlobalUtils.setObject(ps, i++, outChunkID);
	
	return ps;
  }
  
  /**
   * update group message ID to hold file name
   * @param conn
   * @param outFileId
   * @param prevGrpMsgId
   * @param newGrpMsgId
   * @param outChunkID
   * @return
   * @throws Throwable
   */
  public void updateOUT_FILE_BUFFERSGroupMsgId(String outFileId, String prevGrpMsgId, String newGrpMsgId) throws Throwable
  {
	  

	  final String UPDATE_STATEMENT =  "UPDATE OUT_FILE_BUFFERS SET GROUP_MSG_ID = ? " + 
			  "WHERE OUT_FILE_ID = ? AND GROUP_MSG_ID = ?" ;

	  PreparedStatement ps = null;
	  try {
		  Connection conn = super.getConnection();
		  ps = conn.prepareStatement(UPDATE_STATEMENT); 
		  int i = 1;
		  GlobalUtils.setObject(ps, i++, newGrpMsgId);
		  GlobalUtils.setObject(ps, i++, outFileId);
		  GlobalUtils.setObject(ps, i++, prevGrpMsgId);
		  ps.executeUpdate();
	  }catch(Throwable t){
		  throw new FlowException(t);
	  }finally{
		  super.releaseResources(ps);
	  }   
  }
  
  public boolean getOutFileGroupingIDLeftOvers (Connection conn,String outFileGroupingID , int minTranPerFile ,List<String> outChunkID) throws Throwable
  {
	  
  	  PreparedStatement ps = null;
  	  ResultSet rs = null;
	  boolean canCreateAnotherFileFromLeftOvers = false;
	  
	  final String SELECT_STATEMENT = "SELECT SUM(TOTAL_MSG_COUNT_NB) SUM_TOTAL_MSG_COUNT \r\n" +
	  								  "FROM OUT_FILE_BUFFERS \r\n" +
	  								  "WHERE OUT_FILE_GROUPING_ID = ? \r\n" +
	  								  "AND OUT_CHUNK_ID NOT IN (" + GlobalUtils.buildInStringElements(outChunkID.toArray(new String[outChunkID.size()]))+ " )AND OUT_FILE_ID is null \r\n" +
	  								  "HAVING SUM(TOTAL_MSG_COUNT_NB) >= ? \r\n";
	  
	  try {
		   ps = conn.prepareStatement(SELECT_STATEMENT);
	       GlobalUtils.setObject(ps, 1, outFileGroupingID);
	       GlobalUtils.setObject(ps, 2, minTranPerFile);
	       rs = ps.executeQuery();
	       if (rs.next())
	       		canCreateAnotherFileFromLeftOvers = true;
	  }catch(Throwable t){
		  throw new FlowException(t);
	  }finally{
		  super.releaseResources(ps,rs);
	  }   
       
      return canCreateAnotherFileFromLeftOvers;
  }
  
  
}


