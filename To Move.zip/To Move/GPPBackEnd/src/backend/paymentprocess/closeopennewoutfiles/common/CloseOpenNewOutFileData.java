/**
 * 
 */
package backend.paymentprocess.closeopennewoutfiles.common;

/**
 * @author eranm
 *
 */
public class CloseOpenNewOutFileData {
	
	private boolean SendingTimeMarkedAsLast;
	private int numberOfFilesCanBeSent;
	private int minTransactionPerFile;
	private int numberOfCurrentSentFiles;
    private String fromTime;
    private String timeToSend;
    private int maxTranPerBulk;
	private int maxBulksPerFile;
	private String outFileID; 
	private String groupMsgId;
	private String accountingMID;
	private int sumTotalTranInBulk; //will be used to count the total transaction that we've aggregated into the current group
	private int sumTotalTranInFile;
	private int numberOfBulksInFile;//will be used to count the total groups that we've aggregated into the current file
	private boolean messageInsertInCurrentRound;
	private double totalSttlmAmt;
	private String mopName;
	private boolean expectAck;
	
	public CloseOpenNewOutFileData() {
		
		this.setTotalSttlmAmt(0);
		this.numberOfCurrentSentFiles = 0 ;
		this.sumTotalTranInBulk = 0;
		this.numberOfBulksInFile = 0;
		this.sumTotalTranInFile = 0;
		this.setMessageInsertInCurrentRound(false);
	}
	/**
	 * @param sendingTimeMarkedAsLast the sendingTimeMarkedAsLast to set
	 */
	public void setSendingTimeMarkedAsLast(boolean sendingTimeMarkedAsLast) {
		SendingTimeMarkedAsLast = sendingTimeMarkedAsLast;
	}

	/**
	 * @return the sendingTimeMarkedAsLast
	 */
	public boolean isSendingTimeMarkedAsLast() {
		return SendingTimeMarkedAsLast;
	}

	/**
	 * @param numberOfFilesCanBeSent the numberOfFilesCanBeSent to set
	 */
	public void setNumberOfFilesCanBeSent(int numberOfFilesCanBeSent) {
		this.numberOfFilesCanBeSent += numberOfFilesCanBeSent;
	}

	/**
	 * @return the numberOfFilesCanBeSent
	 */
	public int getNumberOfFilesCanBeSent() {
		return numberOfFilesCanBeSent;
	}

	/**
	 * @param minTransactionPerFile the minTransactionPerFile to set
	 */
	public void setMinTransactionPerFile(int minTransactionPerFile) {
		this.minTransactionPerFile = minTransactionPerFile;
	}

	/**
	 * @return the minTransactionPerFile
	 */
	public int getMinTransactionPerFile() {
		return minTransactionPerFile;
	}

	/**
	 * @param numberOfCurrentSentFiles the numberOfCurrentSentFiles to set
	 */
	public void addToNumberOfCurrentSentFiles(int numberOfCurrentSentFiles) {
		this.numberOfCurrentSentFiles += numberOfCurrentSentFiles;
	}

	/**
	 * @return the numberOfCurrentSentFiles
	 */
	public int getNumberOfCurrentSentFiles() {
		return numberOfCurrentSentFiles;
	}
	/**
	 * @param fromTime the fromTime to set
	 */
	public void setFromTime(String fromTime) {
		this.fromTime = fromTime;
	}
	/**
	 * @return the fromTime
	 */
	public String getFromTime() {
		return fromTime;
	}
	/**
	 * @param timeToSend the timeToSend to set
	 */
	public void setTimeToSend(String timeToSend) {
		this.timeToSend = timeToSend;
	}
	/**
	 * @return the timeToSend
	 */
	public String getTimeToSend() {
		return timeToSend;
	}
	/**
	 * @param maxTranPerBulk the maxTranPerBulk to set
	 */
	public void setMaxTranPerBulk(int maxTranPerBulk) {
		this.maxTranPerBulk = maxTranPerBulk;
	}
	/**
	 * @return the maxTranPerBulk
	 */
	public int getMaxTranPerBulk() {
		return maxTranPerBulk;
	}
	/**
	 * @param maxBulksPerFile the maxBulksPerFile to set
	 */
	public void setMaxBulksPerFile(int maxBulksPerFile) {
		this.maxBulksPerFile = maxBulksPerFile;
	}
	/**
	 * @return the maxBulksPerFile
	 */
	public int getMaxBulksPerFile() {
		return maxBulksPerFile;
	}
	/**
	 * @param outFileID the outFileID to set
	 */
	public void setOutFileID(String outFileID) {
		this.outFileID = outFileID;
	}
	/**
	 * @return the outFileID
	 */
	public String getOutFileID() {
		return outFileID;
	}
	/**
	 * @param groupMsgId the groupMsgId to set
	 */
	public void setGroupMsgId(String groupMsgId) {
		this.groupMsgId = groupMsgId;
	}
	/**
	 * @return the groupMsgId
	 */
	public String getGroupMsgId() {
		return groupMsgId;
	}
	/**
	 * @param accountingMID the accountingMID to set
	 */
	public void setAccountingMID(String accountingMID) {
		this.accountingMID = accountingMID;
	}
	/**
	 * @return the accountingMID
	 */
	public String getAccountingMID() {
		return accountingMID;
	}
	/**
	 * @param sumTotalTranInBulk the sumTotalTranInBulk to add
	 */
	public void addToSumTotalTranInBulk(int sumTotalTranInBulk) {
		this.sumTotalTranInBulk += sumTotalTranInBulk;
	}
	
	/**
	 * @param sumTotalTranInBulk the sumTotalTranInBulk to set
	 */
	public void setSumTotalTranInBulk(int sumTotalTranInBulk) {
		this.sumTotalTranInBulk = sumTotalTranInBulk;
	}
	
	/**
	 * @return the sumTotalTranInBulk
	 */
	public int getSumTotalTranInBulk() {
		return sumTotalTranInBulk;
	}
	
	/**
	 * @param numberOfBulksInFile the numberOfBulksInFile to set
	 */
	public void setNumberOfBulksInFile(int numberOfBulksInFile) {
		this.numberOfBulksInFile = numberOfBulksInFile;
	}
	/**
	 * @param numberOfBulksInFile the numberOfBulksInFile to add
	 */
	public void addToNumberOfBulksInFile(int numberOfBulksInFile) {
		this.numberOfBulksInFile += numberOfBulksInFile;
	}
	/**
	 * @return the numberOfBulksInFile
	 */
	public int getNumberOfBulksInFile() {
		return numberOfBulksInFile;
	}
	/**
	 * @param messageInsertInCurrentRound the messageInsertInCurrentRound to set
	 */
	public void setMessageInsertInCurrentRound(boolean messageInsertInCurrentRound) {
		this.messageInsertInCurrentRound = messageInsertInCurrentRound;
	}
	/**
	 * @return the messageInsertInCurrentRound
	 */
	public boolean isMessageInsertInCurrentRound() {
		return messageInsertInCurrentRound;
	}
	/**
	 * @param sumTotalTranInFile the sumTotalTranInFile to set
	 */
	public void addToSumTotalTranInFile(int sumTotalTranInFile) {
		this.sumTotalTranInFile += sumTotalTranInFile;
	}
	/**
	 * @return the sumTotalTranInFile
	 */
	public int getSumTotalTranInFile() {
		return sumTotalTranInFile;
	}

	public void setSumTotalTranInFile(int sumTotalTranInFile) {
		this.sumTotalTranInFile = sumTotalTranInFile;
	}
	/**
	 * @param totalSttlmAmt the totalSttlmAmt to set
	 */
	public void addToTotalSttlmAmt(double totalSttlmAmt) {
		this.totalSttlmAmt += totalSttlmAmt;
	}
	
	/**
	 * @param totalSttlmAmt the totalSttlmAmt to set
	 */
	public void setTotalSttlmAmt(double totalSttlmAmt) {
		this.totalSttlmAmt = totalSttlmAmt;
	}
	/**
	 * @return the totalSttlmAmt
	 */
	public double getTotalSttlmAmt() {
		return totalSttlmAmt;
	}
	/**
	 * @param mopName the mopName to set
	 */
	public void setMopName(String mopName) {
		this.mopName = mopName;
	}
	/**
	 * @return the mopName
	 */
	public String getMopName() {
		return mopName;
	}
	/**
	 * @param expectAck the expectAck to set
	 */
	public void setExpectAck(boolean expectAck) {
		this.expectAck = expectAck;
	}
	/**
	 * @return the expectAck
	 */
	public boolean isExpectAck() {
		return expectAck;
	}
	
}
