package backend.paymentprocess.balanceinquiry.ejbinterfaces;

import javax.ejb.Local;

/**
 * Local interface for BalanceInquiry.
 */
@Local
public interface BalanceInquiryLocal extends BalanceInquiry{} ; 