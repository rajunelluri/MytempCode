package backend.paymentprocess.balanceinquiry.ejbinterfaces;

import javax.ejb.Remote;
import com.fundtech.core.security.Admin;

/**
 * Remote interface for BalanceInquiry.
 */
@Remote
public interface BalanceInquiry{

	public static final String REMOTE_JNDI_NAME="ejb/BalanceInquiryBean";
	
	
	public com.fundtech.datacomponent.response.Feedback handleBalanceInquiry(final Admin admin, java.lang.String sMID ) throws java.lang.Exception ;

}//EOI  