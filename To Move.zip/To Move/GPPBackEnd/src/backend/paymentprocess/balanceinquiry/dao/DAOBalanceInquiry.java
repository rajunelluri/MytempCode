package backend.paymentprocess.balanceinquiry.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.fundtech.util.ExceptionController;
import com.fundtech.util.GlobalUtils;

import backend.dataaccess.dao.DAOBasic;

/**
 * 
 */
public class DAOBalanceInquiry extends DAOBasic
{
  private static DAOBalanceInquiry m_daoBalanceInquiry = new DAOBalanceInquiry();
  
  /**
   * Private constructor. 
   */
  private DAOBalanceInquiry()
  {
  }
  
  public static DAOBalanceInquiry getInstance()
  {
  	return m_daoBalanceInquiry;
  }
  
  /**
   * 
   */
  public int updateACCOUNTS_TableForBIBlockDiffPayerBankAndPayeeBank(String sDebitAccountUID, String sP_DBT_AMT, String sP_CDT_AMT, String sCreditAccountUID, Long lDebitAsset)
  {
  	// sDebitAccountUID  = 1st binding parameter.
  	// sP_DBT_AMT        = 2nd binding parameter.
  	// sP_CDT_AMT        = 3rd binding parameter.
  	// sCreditAccountUID = 4th binding parameter.
  	// lDebitAsset       = 5th binding parameter.
  	
  	// Original query with binding parameters and not with '?' signs:
  	// UPDATE ACCOUNTS SET BALANCE = NVL(BALANCE,0) + DECODE( UID_ACCOUNTS , :1 , -1 * :2 , :3),
  	// OUT_TOTAL = NVL(OUT_TOTAL,0) + :2 * DECODE( UID_ACCOUNTS , :1 , 1, 0),
  	// OUT_NO = NVL(OUT_NO,0) + DECODE( UID_ACCOUNTS , :1 , 1, 0),
  	// IN_TOTAL = NVL(IN_TOTAL,0) + :3 * DECODE( UID_ACCOUNTS , :1, 0, 1),
  	// IN_NO = NVL(IN_NO,0) +  DECODE( UID_ACCOUNTS , :1, 0, 1)
  	// WHERE UID_ACCOUNTS IN (:1 , :4 ) AND (:5 <> 0 OR NVL((SELECT NVL(BALANCE, 0) - :2 FROM ACCOUNTS WHERE UID_ACCOUNTS = :1 ), -1) >= 0)
  	
    final String UPDATE_STATEMENT =     
	    /* Row 1 */ "UPDATE ACCOUNTS SET BALANCE = NVL(BALANCE, 0) + DECODE( UID_ACCOUNTS , ? , -1 * ? , ?), " +
	    /* Row 2 */ "OUT_TOTAL = NVL(OUT_TOTAL, 0) + ? * DECODE( UID_ACCOUNTS , ? , 1, 0), " +
	    /* Row 3 */ "OUT_NO = NVL(OUT_NO, 0) + DECODE( UID_ACCOUNTS , ? , 1, 0), " +
	    /* Row 4 */ "IN_TOTAL = NVL(IN_TOTAL,0) + ? * DECODE( UID_ACCOUNTS , ?, 0, 1), " +
	    /* Row 5 */ "IN_NO = NVL(IN_NO, 0) +  DECODE( UID_ACCOUNTS , ?, 0, 1) " +
	    /* Row 6 */ "WHERE UID_ACCOUNTS IN (? , ? ) AND (? <> 0 OR NVL((SELECT NVL(BALANCE, 0) - ? FROM ACCOUNTS WHERE UID_ACCOUNTS = ? ), -1) >= 0)";
    
    int iEffectedRows = -1;
    
    Connection conn = null;
    PreparedStatement ps = null;
    
		try
		{
			conn = super.getConnection();
			ps = conn.prepareStatement(UPDATE_STATEMENT);
	
	    int iCounter = 1;
	    
	    // Row 1.
	    GlobalUtils.setObject(ps, iCounter++, sDebitAccountUID);
	    GlobalUtils.setObject(ps, iCounter++, sP_DBT_AMT);
	    GlobalUtils.setObject(ps, iCounter++, sP_CDT_AMT);
	    
	    // Row 2.
	    GlobalUtils.setObject(ps, iCounter++, sP_DBT_AMT);
	    GlobalUtils.setObject(ps, iCounter++, sDebitAccountUID);
	
	    // Row 3.
	    GlobalUtils.setObject(ps, iCounter++, sDebitAccountUID);
	
	    // Row 4.
	    GlobalUtils.setObject(ps, iCounter++, sP_CDT_AMT);
	    GlobalUtils.setObject(ps, iCounter++, sDebitAccountUID);
	
	    // Row 5.
	    GlobalUtils.setObject(ps, iCounter++, sDebitAccountUID);
	    
	    // Row 6.
	    // 
	    // Uses ordered accounts in order to avoid dead lock in the database.
	    String[] arrOrderedAccounts = getOrderedAccountsArray(sCreditAccountUID, sDebitAccountUID);
	    //
	    GlobalUtils.setObject(ps, iCounter++, arrOrderedAccounts[0]);
	    GlobalUtils.setObject(ps, iCounter++, arrOrderedAccounts[1]);
	    //
	    GlobalUtils.setObject(ps, iCounter++, lDebitAsset);
	    GlobalUtils.setObject(ps, iCounter++, sP_DBT_AMT);
	    GlobalUtils.setObject(ps, iCounter++, sDebitAccountUID);
	    
	    iEffectedRows = ps.executeUpdate();
		}
		
	  catch(Exception e)
	  {
	  	ExceptionController.getInstance().handleException(e, this);
	  }
	  finally
	  {
	  	super.releaseResources(conn, ps);
	  }

    return iEffectedRows;
  }    
  
  /**
   * 
   */
  public int updateACCOUNTS_TableForBIBlockSamePayerBankAndPayeeBank(String sDebitAccountUID, String sP_DBT_AMT)
  {
  	// sDebitAccountUID  = 1st binding parameter.
  	// sP_DBT_AMT        = 2nd binding parameter.
  	
  	// Original query with binding parameters and not with '?' signs:
  	// UPDATE ACCOUNTS SET 
  	// OUT_TOTAL = NVL(OUT_TOTAL,0) + :2,
  	// OUT_NO = NVL(OUT_NO,0) + 1,
  	// IN_TOTAL = NVL(IN_TOTAL,0) + :2,
  	// IN_NO = NVL(IN_NO,0) +  1
  	// WHERE UID_ACCOUNTS = :1

    final String UPDATE_STATEMENT =     
	    /* Row 1 */ "UPDATE ACCOUNTS SET " +
	    /* Row 2 */ "OUT_TOTAL = NVL(OUT_TOTAL, 0) + ?, " +
	    /* Row 3 */ "OUT_NO = NVL(OUT_NO, 0) + 1, " +
	    /* Row 4 */ "IN_TOTAL = NVL(IN_TOTAL, 0) + ?, " +
	    /* Row 5 */ "IN_NO = NVL(IN_NO, 0) +  1 " +
	    /* Row 6 */ "WHERE UID_ACCOUNTS = ?";
    
    int iEffectedRows = -1;
    
    Connection conn = null;
    PreparedStatement ps = null;
    
		try
		{
			conn = super.getConnection();
			ps = conn.prepareStatement(UPDATE_STATEMENT);
    
	    int iCounter = 1;
	    
	    // Row 2.
	    GlobalUtils.setObject(ps, iCounter++, sP_DBT_AMT);
	
	    // Row 4.
	    GlobalUtils.setObject(ps, iCounter++, sP_DBT_AMT);
	
	    // Row 6.
	    GlobalUtils.setObject(ps, iCounter++, sDebitAccountUID);
	    
	    iEffectedRows = ps.executeUpdate();
		}

	  catch(Exception e)
	  {
	  	ExceptionController.getInstance().handleException(e, this);
	  }
	  finally
	  {
	  	super.releaseResources(conn, ps);
	  }

    return iEffectedRows;
  }
  
  /**
   * 
   */
  public int updateACCOUNTS_TableForBIUnblockDiffPayerBankAndPayeeBank(String sCreditAccountUID, String sP_CDT_AMT, String sP_DBT_AMT, String sDebitAccountUID)
  {
  	// sCreditAccountUID = 1st binding parameter.
  	// sP_CDT_AMT        = 2nd binding parameter.
  	// sP_DBT_AMT        = 3rd binding parameter.
  	// sDebitAccountUID  = 4th binding parameter.
  	
  	// Original query with binding parameters and not with '?' signs:
  	// UPDATE ACCOUNTS SET BALANCE = NVL(BALANCE,0) + DECODE( UID_ACCOUNTS , :1 , -1 * :2 , :3),
  	// OUT_TOTAL = NVL(OUT_TOTAL, 0) + :2 * DECODE( UID_ACCOUNTS , :1 , 1, 0),
    // OUT_NO = NVL(OUT_NO, 0) + DECODE( UID_ACCOUNTS , :1 , 1, 0),
  	// IN_TOTAL = NVL(IN_TOTAL, 0) + :3 * DECODE( UID_ACCOUNTS , :1, 0, 1),
  	// IN_NO = NVL(IN_NO, 0) +  DECODE( UID_ACCOUNTS , :1, 0, 1)
  	// WHERE UID_ACCOUNTS IN (:1 , :4 )
  	
    final String UPDATE_STATEMENT =     
	    /* Row 1 */ "UPDATE ACCOUNTS SET BALANCE = NVL(BALANCE,0) + DECODE( UID_ACCOUNTS , ? , -1 * ? , ?), " +
	    /* Row 2 */ "OUT_TOTAL = NVL(OUT_TOTAL, 0) + ? * DECODE( UID_ACCOUNTS , ? , 0, -1), " +
	    /* Row 3 */ "OUT_NO = NVL(OUT_NO, 0) + DECODE( UID_ACCOUNTS , ? , 0, -1), " +
	    /* Row 4 */ "IN_TOTAL = NVL(IN_TOTAL, 0) + ? * DECODE( UID_ACCOUNTS , ?, -1, 0), " +
	    /* Row 5 */ "IN_NO = NVL(IN_NO, 0) +  DECODE( UID_ACCOUNTS , ?, -1, 0) " +
	    /* Row 6 */ "WHERE UID_ACCOUNTS IN (? , ?)";
    
    int iEffectedRows = -1;
    
    Connection conn = null;
    PreparedStatement ps = null;
    
		try
		{
			conn = super.getConnection();
			ps = conn.prepareStatement(UPDATE_STATEMENT);
    
	    int iCounter = 1;
	    
	    // Row 1.
	    GlobalUtils.setObject(ps, iCounter++, sCreditAccountUID);
	    GlobalUtils.setObject(ps, iCounter++, sP_CDT_AMT);
	    GlobalUtils.setObject(ps, iCounter++, sP_DBT_AMT);
	    
	    // Row 2.
	    GlobalUtils.setObject(ps, iCounter++, sP_CDT_AMT);
	    GlobalUtils.setObject(ps, iCounter++, sCreditAccountUID);
	
	    // Row 3.
	    GlobalUtils.setObject(ps, iCounter++, sCreditAccountUID);
	
	    // Row 4.
	    GlobalUtils.setObject(ps, iCounter++, sP_DBT_AMT);
	    GlobalUtils.setObject(ps, iCounter++, sCreditAccountUID);
	
	    // Row 5.
	    GlobalUtils.setObject(ps, iCounter++, sCreditAccountUID);
	    
	    // Row 6.
	    // 
	    // Uses ordered accounts in order to avoid dead lock in the database.
	    String[] arrOrderedAccounts = getOrderedAccountsArray(sCreditAccountUID, sDebitAccountUID);
	    //
	    GlobalUtils.setObject(ps, iCounter++, arrOrderedAccounts[0]);
	    GlobalUtils.setObject(ps, iCounter++, arrOrderedAccounts[1]);
	    
	    iEffectedRows = ps.executeUpdate();
		}
		
	  catch(Exception e)
	  {
	  	ExceptionController.getInstance().handleException(e, this);
	  }
	  finally
	  {
	  	super.releaseResources(conn, ps);
	  }

    return iEffectedRows;
  }  
  
  /**
   * 
   */
  public int updateACCOUNTS_TableForBIUnblockSamePayerBankAndPayeeBank(String sCreditAccountUID, String sP_CDT_AMT)
  {
  	// sCreditAccountUID = 1st binding parameter.
  	// sP_CDT_AMT        = 2nd binding parameter.
  	
  	// Original query with binding parameters and not with '?' signs:
  	// UPDATE ACCOUNTS SET 
  	// OUT_TOTAL = NVL(OUT_TOTAL, 0) - :2, 
  	// OUT_NO = NVL(OUT_NO, 0) - 1,
  	// IN_TOTAL = NVL(IN_TOTAL, 0) - :2,
  	// IN_NO = NVL(IN_NO, 0) -  1
  	// WHERE UID_ACCOUNTS = :1

    final String UPDATE_STATEMENT =     
	    /* Row 1 */ "UPDATE ACCOUNTS SET " +
	    /* Row 2 */ "OUT_TOTAL = NVL(OUT_TOTAL, 0) - ?, " +
	    /* Row 3 */ "OUT_NO = NVL(OUT_NO, 0) - 1, " +
	    /* Row 4 */ "IN_TOTAL = NVL(IN_TOTAL, 0) - ?, " +
	    /* Row 5 */ "IN_NO = NVL(IN_NO, 0) -  1 " +
	    /* Row 6 */ "WHERE UID_ACCOUNTS = ?";
    
    int iEffectedRows = -1;
    
    Connection conn = null;
    PreparedStatement ps = null;
    
		try
		{
			conn = super.getConnection();
			ps = conn.prepareStatement(UPDATE_STATEMENT);
    
	    int iCounter = 1;
	    
	    // Row 2.
	    GlobalUtils.setObject(ps, iCounter++, sP_CDT_AMT);
	
	    // Row 4.
	    GlobalUtils.setObject(ps, iCounter++, sP_CDT_AMT);
	
	    // Row 6.
	    GlobalUtils.setObject(ps, iCounter++, sCreditAccountUID);
	    
	    iEffectedRows = ps.executeUpdate();
		}
		
	  catch(Exception e)
	  {
	  	ExceptionController.getInstance().handleException(e, this);
	  }
	  finally
	  {
	  	super.releaseResources(conn, ps);
	  }

    return iEffectedRows;
  }
  
  /**
   * 
   */
  private String[] getOrderedAccountsArray(String sFirstAccount, String sSecondAccount)
  {
  	return (sFirstAccount.compareTo(sSecondAccount) < 0 ? new String[]{sFirstAccount, sSecondAccount} : new String[]{sSecondAccount, sFirstAccount});
  }
}