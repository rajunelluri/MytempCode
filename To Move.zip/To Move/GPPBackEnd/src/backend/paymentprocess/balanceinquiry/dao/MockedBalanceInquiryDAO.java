
package backend.paymentprocess.balanceinquiry.dao;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;

/*
  	table ACCOUNTS_BI_INTERNAL(
	  	OFFICE         CHAR(3),
	  	ACC_NO         VARCHAR2(34),
	  	CURRENCY       CHAR(3),
	  	CUR_BALANCE    NUMBER(19,4) default (0))
 */

public class MockedBalanceInquiryDAO {
	private static final Logger logger = LoggerFactory.getLogger(MockedBalanceInquiryDAO.class);
	
	private JdbcTemplate jdbcTemplate;

	public void setDataSource(DataSource dataSource){
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public double getAccountBalance(String office,String acctNo,String currency) {		
		final String sql = "select CUR_BALANCE from ACCOUNTS_BI_INTERNAL where OFFICE = ? and ACC_NO = ? and CURRENCY=?";
		logger.debug("executing {}, office: {}, acctNo: {}, currency: {}"
				,new Object[]{sql,office,acctNo,currency});
		
		try {			
			double balance = (Double)jdbcTemplate.queryForObject(sql,new Object[]{office,acctNo,currency},Double.class);	
			return balance;
		} catch (Exception e) {
			return 0.0;
		}
	}
	
	public boolean setAccountBalance(String office,String acctNo,String currency,double newBalance) {
		String sql = "update ACCOUNTS_BI_INTERNAL set CUR_BALANCE=? where OFFICE = ? and ACC_NO = ? and CURRENCY=?";		
		logger.debug("executing {}, office: {}, acctNo: {}, currency: {}, newBalance: {}"
				,new Object[]{sql,office,acctNo,currency,newBalance});
		
		int rows = jdbcTemplate.update(sql,new Object[]{newBalance,office,acctNo,currency});
		if (rows == 0) {
			sql = "insert into ACCOUNTS_BI_INTERNAL (CUR_BALANCE,OFFICE,ACC_NO,CURRENCY) values(?,?,?,?)";		
			logger.debug("executing {}, office: {}, acctNo: {}, currency: {}, newBalance: {}"
					,new Object[]{sql,office,acctNo,currency,newBalance});
			
			jdbcTemplate.update(sql,new Object[]{newBalance,office,acctNo,currency});
			return true; //was created
		}
		return false;	//was updated
	}

	public void addToAccountBalance(String office,String acctNo,String currency,double amount) {
		final String sql = "update ACCOUNTS_BI_INTERNAL set CUR_BALANCE = CUR_BALANCE + ? where OFFICE = ? and ACC_NO = ? and CURRENCY=?";
		logger.debug("executing {}, office: {}, acctNo: {}, currency: {}, amount: {}",new Object[]{sql,office,acctNo,currency,amount});
		
		jdbcTemplate.update(sql,new Object[]{amount,office,acctNo,currency});
	}
	
	public boolean removeAccount(String office,String acctNo,String currency) {
		final String sql = "delete from ACCOUNTS_BI_INTERNAL where OFFICE = ? and ACC_NO = ? and CURRENCY=?";
		logger.debug("executing {}, office: {}, acctNo: {}, currency: {}"
				,new Object[]{sql,office,acctNo,currency});
		
		int rows = jdbcTemplate.update(sql,new Object[]{office,acctNo,currency});
		return rows != 0;
	}
}