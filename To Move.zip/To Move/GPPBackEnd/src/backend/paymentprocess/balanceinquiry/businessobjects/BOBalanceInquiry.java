package backend.paymentprocess.balanceinquiry.businessobjects;


import static backend.businessobject.BOProxies.m_internalInterfacesLogging;
import static com.fundtech.cache.entities.InterfaceTypes.INTERFACE_TYPE_BI;
import static com.fundtech.cache.entities.InterfaceTypes.STATUS_ACTIVE;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.businessobject.BOBasic;
import backend.core.module.MessageConstantsInterface;

import com.fundtech.annotations.Expose;
import com.fundtech.annotations.Wrap;
import com.fundtech.cache.entities.Accounts;
import com.fundtech.cache.entities.InterfaceTypes;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;


@Wrap (tx="Bean")

public class BOBalanceInquiry extends BOBasic implements PDOConstantFieldsInterface, MessageConstantsInterface
{

	private static final Logger logger = LoggerFactory.getLogger(BOBalanceInquiry.class);
  // Balance inquiry mode types.
  public enum BI_MODE
  {
    Block,Unblock;
    
    public String toString() 
    {
      return name();
    }
  };
  
  @Expose
  public Feedback handleBalanceInquiry(String sMID) throws Exception {
	  PDO pdo = PaymentDataFactory.load(sMID);
	  Feedback feedback = new Feedback();
	   
	  if (!isBalanceInquiryEnabled(pdo)) {
		  logger.debug("Interface ***^BI is not ACTIVE, skip Balance Inquiry");
		  return feedback;
	  }
	  
	  if (!isEligibleAccount(pdo))
		  return feedback;
	  
	  logger.debug("performing balance inquiry for account {}",pdo.get(P_DBT_ACCT_NB));
	  
	  try {
		  feedback.setFeedback(m_internalInterfacesLogging.performOutgoingRequestHandler(
				(Admin)Admin.getContextAdmin()
				,sMID
				,INTERFACE_TYPE_BI
				,(String)null));
		
	  } catch (Throwable e) {
		logger.error("error occured",e);
	  }		  
	  
	  return feedback;
  }
  
  private boolean isEligibleAccount(PDO pdo) {
	 Accounts account  =  pdo.getNSetDEBIT_ACCOUNT();
	 if (account != null  
			 && account.getAsset().intValue() == 0 /*non asset*/
			 && account.getHostblchck() == 1) /*selected*/ 
		 return true;
	 
	 logger.debug("{} debit account {} is not eligilbe for balance inquiry"
				,pdo.getMID(),pdo.get(P_DBT_ACCT_NB));
	 
	 return false;
  }

/*
    
    BOC note: uncompleted impl, remarked and use mock only for now (oferb) 
    
  @Expose
  public Feedback handleBalanceInquiry(String sMID) throws Exception
  {
	  PDO pdo = PaymentDataFactory.load(sMID);
	  Feedback feedback = new Feedback();
	  
	  if (isMockedBalanceInquiry(pdo)) 
		  return new BOMockedBalanceInquiry().handleBalanceInquiry(sMID);
	  
	  boolean notYetImplemented = true;
	  
	  if (notYetImplemented)
		  return feedback;
	  
	  final String TRACE_METHOD_INPUT = "handleBalanceInquiry input - Mode: {}, MF_BI_STS: {}.";
	  final String TRACE_BLOCKING_WAS_ALREADY_DONE = "Blocking was already done; exits with successful feedback...";
	  final String TRACE_UNBLOCKING_ALREADY_DONE_OR_BALANCE_WAS_NOT_BLOCKED = "Unblocking was already done or balance was not blocked therefore no need to unblock it; exits with successful feedback...";
	  final String TRACE_ACCOUNT_UIDs_AND_AMOUNTS_DATA = "Debit account UID: {}, P_DBT_AMT: {}, P_CDT_AMT: {}, Credit account UID: {}, Debit acc is asset: {}.";

	  final String TRACE_EXECUTES_QUERY_CASE_BLOCK_MODE_DIFF_BANKS = "Executes query for 'Block' mode and different banks, (AKA 'OnUS')...";
	  final String TRACE_EXECUTES_QUERY_CASE_BLOCK_MODE_SAME_BANK = "Executes query for 'Block' mode and same bank, (AKA 'not OnUS')...";
	  final String TRACE_EFFECTED_ROWS = "Effected rows, (if greater then 0, then balance is sufficient): {}.";
	  final String TRACE_STATUS_CHANGE_TO_NSF = "Insufficient balance - status will be changed to NSF, P_RELEASE_INDEX will be set to: {}";

	  final String TRACE_EXECUTES_QUERY_CASE_UNBLOCK_MODE_DIFF_BANKS = "Executes query for 'Unblock' mode and different banks, (AKA 'OnUS')...";
	  final String TRACE_EXECUTES_QUERY_CASE_UNBLOCK_MODE_SAME_BANK = "Executes query for 'Unblock' mode and same bank, (AKA 'not OnUS')...";

		
    Admin admin = Admin.getContextAdmin();
    
    BI_MODE biMode = (BI_MODE)pdo.get(D_BI_MODE);
    String sMF_BI_STS = pdo.getString(MF_BI_STS);
    logger.info(TRACE_METHOD_INPUT, biMode, sMF_BI_STS);
    
    // Block & balance inquiry was already processed.
    if(BI_MODE.Block == biMode && MONITOR_FLAG_PROCESSED.equals(sMF_BI_STS))
    {
    	logger.info(TRACE_BLOCKING_WAS_ALREADY_DONE);
    }
    
    // Unblocking was already done or balance was not blocked therefore no need to unblock it.
    else if(BI_MODE.Unblock == biMode && !MONITOR_FLAG_PROCESSED.equals(sMF_BI_STS))
    {
    	logger.info(TRACE_UNBLOCKING_ALREADY_DONE_OR_BALANCE_WAS_NOT_BLOCKED);
    }
    
    // Block or Unblock.
    else
    {
    	Accounts debitAccount =  pdo.getNSetDEBIT_ACCOUNT();
    	String sDebitAccountUID = debitAccount.getUidAccounts();
		 	String sP_DBT_AMT = pdo.getString(P_DBT_AMT);
		 	String sP_CDT_AMT = pdo.getString(P_CDT_AMT);
		 	String sCreditAccountUID = pdo.getNSetCREDIT_ACCOUNT().getUidAccounts();
		 	Long lDebitAsset = debitAccount.getAsset();
		 	lDebitAsset = lDebitAsset != null ? lDebitAsset : ServerConstants.ZERO_LONG;
		 	
		 	logger.info(TRACE_ACCOUNT_UIDs_AND_AMOUNTS_DATA,  new Object[]{ sDebitAccountUID, sP_DBT_AMT, sP_CDT_AMT, sCreditAccountUID, lDebitAsset});
		 	
      // Block.
      if(BI_MODE.Block == biMode)
      {
      	int iEffectedRows = 0;
      	
      	// Payer bank and payee bank are not the same, (AKA 'not OnUS'); i.e. the credit account, (not the end one of the actual  
      	// beneficiary, but the credit account of the receiving bank), is not the same as the debit account.
      	if(!sDebitAccountUID.equals(sCreditAccountUID))
      	{
      		logger.info(TRACE_EXECUTES_QUERY_CASE_BLOCK_MODE_DIFF_BANKS);
      		iEffectedRows = ServiceLocator.getInstance().SLSBlookup(TxIsolation.class).updateACCOUNTS_TableForBIBlockDiffPayerBankAndPayeeBank(admin, sDebitAccountUID, sP_DBT_AMT, sP_CDT_AMT, sCreditAccountUID, lDebitAsset);
      	}
      	
      	// Payer bank and payee bank are the same bank, (AKA 'OnUS').
      	else
      	{
      		logger.info(TRACE_EXECUTES_QUERY_CASE_BLOCK_MODE_SAME_BANK);
      		iEffectedRows = ServiceLocator.getInstance().SLSBlookup(TxIsolation.class).updateACCOUNTS_TableForBIBlockSamePayerBankAndPayeeBank(admin, sDebitAccountUID, sP_DBT_AMT);
      	}
      	
      	logger.info(TRACE_EFFECTED_ROWS, iEffectedRows);

      	// If no rows where effected, then it means that there is not enough balance in the debit account therefore we should
      	// set the status to NSF.
      	if(iEffectedRows == 0)
      	{
      		String sReleaseIndex = BOHighValueProcess.getNSFReleaseIndex(pdo.getString(P_OFFICE));
      		pdo.set(P_RELEASE_INDEX, sReleaseIndex);
      		
      		pdo.set(P_MSG_STS, MESSAGE_STATUS_NSF);
      		logger.info(TRACE_STATUS_CHANGE_TO_NSF, sReleaseIndex);
      		
      		// Error code 40091: 'No sufficient funds for party account no |1 - payment was routed to NSF'. 
	        Object[] arrNonPaymentFields = new Object[]{(pdo.getNSetDEBIT_ACCOUNT().getAccNo())};
	        ErrorAuditUtils.setErrors(new ProcessError(ProcessErrorConstants.NoSufficientFunds, arrNonPaymentFields));
      	}
      	
      	else if(iEffectedRows > 0) pdo.set(MF_BI_STS, MONITOR_FLAG_PROCESSED);
      }
      
      // Unblock.
      else if(BI_MODE.Unblock == biMode)
      {
      	// Payer bank and payee bank are not the same, (AKA 'not OnUS'); i.e. the credit account, (not the end one of the actual  
      	// beneficiary, but the credit account of the receiving bank), is not the same as the debit account.
      	if(!sDebitAccountUID.equals(sCreditAccountUID))
      	{
      		logger.info(TRACE_EXECUTES_QUERY_CASE_UNBLOCK_MODE_DIFF_BANKS);
      		ServiceLocator.getInstance().SLSBlookup(TxIsolation.class).updateACCOUNTS_TableForBIUnblockDiffPayerBankAndPayeeBank(admin, sCreditAccountUID, sP_CDT_AMT, sP_DBT_AMT, sDebitAccountUID);
      	}
      	
      	// Payer bank and payee bank are the same bank, (AKA 'OnUS').
      	else
      	{
      		logger.info(TRACE_EXECUTES_QUERY_CASE_UNBLOCK_MODE_SAME_BANK);
      		ServiceLocator.getInstance().SLSBlookup(TxIsolation.class).updateACCOUNTS_TableForBIUnblockSamePayerBankAndPayeeBank(admin, sCreditAccountUID, sP_CDT_AMT);
      	}
      	
      	pdo.set(MF_BI_STS, MONITOR_FLAG_X);
      	pdo.set(D_BI_UNBLOCK_EXECUTED, ServerConstants.BOOL_TRUE);
      }
    }

    
    
    return feedback;
  }*/

  private boolean isBalanceInquiryEnabled(PDO pdo) {	  
	  InterfaceTypes BIInterface = CacheKeys.interfaceTypesKey.getSingle(
			  		"***",INTERFACE_TYPE_BI,null);
	  
	  if (BIInterface == null || !STATUS_ACTIVE.equals(BIInterface.getInterfaceStatus())) 		  
		 return false;
	  
	  return true;
  }
}
