package backend.paymentprocess.balanceinquiry.ejb;

import javax.ejb.Stateless;
import backend.core.SuperSLSB;
import com.fundtech.core.security.Admin;
import backend.businessobject.proxies.interceptors.InterceptorSetType;
import backend.paymentprocess.balanceinquiry.businessobjects.BOBalanceInquiry;
import backend.paymentprocess.balanceinquiry.ejbinterfaces.BalanceInquiryLocal;
import backend.paymentprocess.balanceinquiry.ejbinterfaces.BalanceInquiry;

@Stateless
public class BalanceInquiryBean extends SuperSLSB<BalanceInquiry> implements BalanceInquiryLocal, BalanceInquiry{
	
	public BalanceInquiryBean() { super(backend.paymentprocess.balanceinquiry.businessobjects.BOBalanceInquiry.class, InterceptorSetType.Complete) ; }//EOM
	
	
	public com.fundtech.datacomponent.response.Feedback handleBalanceInquiry(final Admin admin, java.lang.String sMID ) throws java.lang.Exception {
		return this.m_bo.handleBalanceInquiry(admin, sMID ) ;
	}//EOM

}//EOC