package backend.paymentprocess.accountderivation.businessobjects;

import static backend.businessobject.BOProxies.m_paymentServicesLogging;
import static com.fundtech.errors.ProcessErrorConstants.AccountDerivationFailureAccountDoesNotAllowConversion;
import static com.fundtech.errors.ProcessErrorConstants.AccountDerivationFailureExpectedAssetAccount;
import static com.fundtech.errors.ProcessErrorConstants.AccountDerivationFailureUnexpectedCurrency;
import static com.fundtech.util.GlobalUtils.isListNullOrEmpty;
import static com.fundtech.util.GlobalUtils.isNullOrEmpty;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.core.module.MessageConstantsInterface;
import backend.paymentprocess.accountderivation.common.AccountDerivationConstants.AccountDerivationType;
import backend.paymentprocess.accountderivation.exception.AccountDerivationException;
import backend.paymentprocess.erroraudit.ErrorAuditUtils;
import backend.paymentprocess.glm.basic.businessobjects.BOGLMBasic;
import backend.paymentprocess.paymentservices.common.IBANMethod;
import backend.paymentprocess.paymentservices.common.IBANStatus;
import backend.paymentprocess.paymentservices.exception.PaymentServicesException;
import backend.paymentprocess.paymentservices.input.IBANInputData;
import backend.paymentprocess.paymentservices.output.IBANOutputData;
import backend.util.ServerConstants;

import com.fundtech.annotations.Expose;
import com.fundtech.cache.entities.Accounts;
import com.fundtech.cache.entities.CurrencyBu;
import com.fundtech.cache.entities.Customrs;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.core.paymentprocess.errorhandling.ProcessError;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;

public class BOAnticipatedFundAccountDerivation extends BOGLMBasic
				implements PDOConstantFieldsInterface, MessageConstantsInterface {	
	private static final Logger logger = LoggerFactory.getLogger(BOAnticipatedFundAccountDerivation.class);
	
	public static final int NON_ASSET = 0;
	
	@Expose
	//TBD return account,customer and inject it to the PDO within the flow
	/**
	 * Note: as part of account derivation the customer is loaded too
	 */
	public Feedback performAccountDerivation(String mid) throws AccountDerivationException {
		Feedback feedback = new Feedback();
		
	  	PDO pdo = PaymentDataFactory.load(mid);
	  		  	
	  	String derivationType = pdo.getString(D_ACCOUNT_DERIVATION_TYPE);
	    boolean isCredit = AccountDerivationType.Credit.name().equals(derivationType);
	    
	    logger.debug("perform {} account derivation on {}.",derivationType,mid);
	    	    
	    try {	    	
	    	feedback = isCredit ? deriveCreditAccount(mid) : deriveDebitAccount(mid);
		    
	    	handleAccountEnrichment(isCredit,pdo);
    		
	    	//cancel an error feedback if credit\debit account successfully derived via enrichment
    		if (!feedback.isSuccessful() && isAccountDerived(pdo,isCredit)) 
    			feedback = new Feedback();
	    } catch(Throwable e) {
	    	genericServiceExceptionHandling(e, "anticipated funds account derivation", derivationType);
	    }
	    
	    return feedback;
	  }
	  
	  private Feedback deriveCreditAccount(String mid) {
		Feedback feedback = new Feedback();
		Accounts accounts = null;

		PDO pdo = PaymentDataFactory.load(mid);

		boolean isRVR = MESSAGE_SUB_TYPE_RVR.equals(pdo.getString(P_MSG_SUB_TYPE));
		boolean isChaps = isCHAPSMessage(pdo);
		String office = pdo.getString(P_OFFICE);
		String currency = pdo.getString(OX_STTLM_CCY);
		String accountNo = pdo.getString(X_NTF_ACCT_ID);
		String sender = pdo.getString(OX_INSTG_AGT_BIC_2AND);
		String reciever = pdo.getString(OX_INSTD_AGT_BIC_2AND);
		
		if (isChaps && !isRVR) {
			logger.debug("credit account derivation is not required for CHAPS none RVR message");
			return feedback;
		}
		
		
		// For MT210 not RVR and an outgoing message should use field 25
	    String localOfficeBic = pdo.getNSetOffice().getSwiftId();
		boolean shouldUseF25MT210 = (MESSAGE_TYPE_SWIFT_210.equals(pdo.getString(P_MSG_TYPE)) && !isRVR &&
									 localOfficeBic.equals(pdo.get(X_INSTG_AGT_BIC_2AND)) && 
									 !localOfficeBic.equals(pdo.get(X_INSTD_AGT_BIC_2AND)) );

		if (shouldUseF25MT210) {
			logger.debug("credit account derivation is not required for  MT210 none RVR outgoing message");
			return feedback;
		}
		
		
		logger.debug("deriving credit account office {},currecny {},account(field 25) {}, is RVR {}"
				,new Object[]{office,currency,accountNo,isRVR});
		
		try {			
			accounts = handleExistsAccount(pdo, true);
			
			if (accounts == null)				
				accounts = deriveAccountUsingField25(mid);
			
			//if 25 doesn't exists
			if (accounts == null && isNullOrEmpty(accountNo) && !isRVR &&  !isLocalBank(sender,reciever)) {
				Customrs customer = loadParty(null,null,sender,office,currency);
				updatePDOWithCustomerData(pdo, customer, true); //is it neccecary on this point?
				
				if (customer != null) {
					logger.debug("deriving credit account as sender {} non asset account",sender);					
					accounts = deriveCustomerAccount(customer,currency,false/*asset*/);	
				}									
			}						
		} catch (AccountDerivationException e) {			
			ProcessError error = e.getProcessError() != null 
								? e.getProcessError()
								: getGenericFailureProcessError(feedback);
			configureErrorFeedback(error, feedback);
			logger.error("error deriving credit account {}", feedback);
			ErrorAuditUtils.setErrors(error,pdo.getIsHistory());
			accounts = null;
			return feedback;
		}  finally {
			logger.debug("derived credit account: {}",(accounts != null ? accounts.getAccNo() : null));

			if (accounts != null)
				updatePDOAccountData(pdo, accounts, true);
		}
		
		return feedback;
	}

	private Feedback deriveDebitAccount(String mid) {
		Feedback feedback = new Feedback();

		PDO pdo = PaymentDataFactory.load(mid);

		boolean isRVR = MESSAGE_SUB_TYPE_RVR.equals(pdo.getString(P_MSG_SUB_TYPE));
		boolean isChaps = isCHAPSMessage(pdo);
		String subType = pdo.getString(P_MSG_SUB_TYPE);
		String office = pdo.getString(P_OFFICE);
		String currency = pdo.getString(OX_STTLM_CCY);
				
		if (isAccountDerived(pdo, false)) {
			logger.debug("no need to derive debit account, already derived");
			return feedback;
		}

		if (MESSAGE_SUB_TYPE_RVR.equals(subType)) {
			logger.debug("no need to derive debit account for sub type RVR");
			return feedback;
		}

		Accounts accounts = null;

		try {
			accounts = deriveDebitAccountUsingIdentifier(pdo);

			if (accounts == null)
				accounts = handleExistsAccount(pdo, false);

			if (accounts == null) {
				
				// For MT210 not RVR and an outgoing message should use field 25
			    String localOfficeBic = pdo.getNSetOffice().getSwiftId();
				boolean shouldUseF25MT210 = (MESSAGE_TYPE_SWIFT_210.equals(pdo.getString(P_MSG_TYPE)) && !isRVR &&
											 localOfficeBic.equals(pdo.get(X_INSTG_AGT_BIC_2AND)) && 
											 !localOfficeBic.equals(pdo.get(X_INSTD_AGT_BIC_2AND)) );
				
				if (isChaps && !isRVR) { 
					logger.debug("Debit account derivation for CHAPS none RVR message is using F25");
					accounts = deriveAccountUsingField25(pdo.getMID());
				} else if (shouldUseF25MT210) {
					logger.debug("Debit account derivation for MT210 none RVR outgoing message is using F25");
					accounts = deriveAccountUsingField25(pdo.getMID());
				} else {
					accounts = deriveDebitAccountUsingField56(pdo);
				}
			}
			
			if (accounts == null)
				accounts = deriveCurrencyDefaultNostroAccount(currency, office);		
		} catch (AccountDerivationException e) {
			ProcessError error = e.getProcessError() != null 
								? e.getProcessError()
								: getGenericFailureProcessError(feedback);
			configureErrorFeedback(error, feedback);
			ErrorAuditUtils.setErrors(error,pdo.getIsHistory());
			logger.error("error deriving debit account {}", feedback);
			accounts = null;
			return feedback;
		} finally {
			logger.debug("derived debit account: {}",
					(accounts != null ? accounts.getAccNo() : "false"));
			
			if (accounts != null)
				updatePDOAccountData(pdo, accounts, false);
		}

		return feedback;
	}

	private Accounts deriveDebitAccountUsingIdentifier(PDO pdo) throws AccountDerivationException {
		logger.debug("deriving debit account using identifier");

		BOAccountDerivation bo = new BOAccountDerivation();

		boolean[] continueFlag = new boolean[] {true};
		Object[] errorHolder = new Object[2];

		boolean derived = bo.deriveAccountFromIdentifiersData(
				continueFlag, errorHolder, false /*toleranceCurrecny*/,false);

		//no attempt to derive took place (account data wasn't supplied)
		if (!derived && continueFlag[0])
			return null;

		if (!derived)
			throw new AccountDerivationException(
					"debit account derivation using identifier failed",
							bo.getFailureProcessError(errorHolder));

		Accounts accounts = pdo.getDEBIT_ACCOUNT();
		accounts = applyAssetCriteria(accounts, true);

		if (accounts == null) {	
			String accNo = pdo.getDEBIT_ACCOUNT().getAccNo();
			BOAccountDerivation.clearPDOAccountData(false);
			throw new AccountDerivationException("identifier account is non asset"
					,new ProcessError(AccountDerivationFailureExpectedAssetAccount
							,new Object[]{accNo}));
		}

		logger.debug("successfully derived account {} using identifier",accounts.getAccNo());

		return accounts;
	}

	/**
	 * handle already exists Account on PDO, (either as a result of manipulation or use GUI changes);
	 * Copied from BOAccountDerivation, see notes there.
	 */
	private Accounts handleExistsAccount(PDO pdo, boolean isCredit) throws AccountDerivationException {		
		String existsAccount = getAccountNumber(pdo,isCredit);		
		String monitorValue = pdo.getString(MU_CDT_ACC_NB_MANUALY_ENTERED);
		boolean manuallyEntered = MONITOR_FLAG_MANUAL_VALUE.equals(monitorValue); 
		
		if (isNullOrEmpty(existsAccount) 
				|| (isCredit && !manuallyEntered))
			return null;
		
		logger.debug("check validity of explicitly(User|Rule) configured {} account {}"
					,isCredit ? "credit" : "debit",existsAccount);
			
		BOAccountDerivation bo = new BOAccountDerivation();
		Object[] errorHolder = new Object[2];
		ProcessError error = null;
		Accounts accounts = null;
		
		boolean validAccount = bo.handleExistingAccount(existsAccount,isCredit,errorHolder);
		
		if (validAccount) { 
			accounts = getAccounts(pdo,isCredit);
			
			if (!isCredit && accounts!=null && !"VOS".equals(accounts.getPositionType()))
				accounts = applyAssetCriteria(accounts, true);
			
			if (accounts == null) {
				BOAccountDerivation.clearPDOAccountData(isCredit,false);
				error = new ProcessError(AccountDerivationFailureExpectedAssetAccount
								,new Object[]{existsAccount});				
			}
		} else {
			error =  bo.getFailureProcessError(errorHolder);
		}
		
		if (error != null) {
			//replace conversion related error with 'unexpected currency' error
			if (error.getErrorCode() == AccountDerivationFailureAccountDoesNotAllowConversion) 
				error = new ProcessError(AccountDerivationFailureUnexpectedCurrency
						,accounts.getAccNo(),pdo.get(OX_STTLM_CCY));
			
			throw new AccountDerivationException("exists account is invalid",error);
		}
		
		return accounts;
	}
	
	private Accounts deriveAccountUsingField25(String mid) {
		Accounts accounts = null;

		PDO pdo = PaymentDataFactory.load(mid);

		String subType = pdo.getString(P_MSG_SUB_TYPE);
		String office = pdo.getString(P_OFFICE);
		String currecy = pdo.getString(OX_STTLM_CCY);
		boolean isIban = StringUtils.isNotEmpty(pdo.getString(X_NTF_ACCT_IBAN));
		String accountNo = isIban ? pdo.getString(X_NTF_ACCT_IBAN) : pdo.getString(X_NTF_ACCT_ID);		
		
		if (accountNo == null) {
			logger.debug("field 25 is missing or empty value");
			return null;
		}
		
		logger.debug("deriving account using Field 25, sub type {} ",subType);
		
		logger.debug("first attempt: deriving account using Field 25 'account'");
		accounts = deriveAccount(accountNo, isIban ,true, currecy, office);

		logger.debug("found account using Field 25? {}", accounts != null);

		return accounts;
	}
	
	private Accounts deriveDebitAccountUsingField56(PDO pdo) {
		Accounts accounts = null;

		String office = pdo.getString(P_OFFICE);
		String currecy = pdo.getString(OX_STTLM_CCY);
		String accountNo = pdo.getString(X_INTRMY_AGT1_ACCT_ID);
		String iban = pdo.getString(X_INTRMY_AGT1_ACCT_IBAN);
		String bic = pdo.getString(X_INTRMY_AGT1_BIC_2AND);
		
		if (isNullOrEmpty(accountNo) && isNullOrEmpty(iban) && isNullOrEmpty(bic)) {
			logger.debug("field 56 is missing");
			return null;
		}
		
		if (!isNullOrEmpty(accountNo)) {
			logger.debug("attempt deriving debit account using Field 56 'account'");
			accounts = deriveAccount(accountNo,false/*isIBAN*/,false/*isAlias*/,currecy,office);			
		}
		
		if (accounts == null && !isNullOrEmpty(iban)) {
			logger.debug("attempt deriving debit account using Field 56 'iban'");				
			accounts = deriveAccount(iban,true/*isIBAN*/,false/*isAlias*/,currecy,office);
		}
		
		if (accounts != null && accounts.getAsset().intValue() == NON_ASSET) {
			logger.debug("account {} is not valid as it none asset account",accounts.getAccNo());
			accounts = null;			
		}
		
		if (accounts == null) {
			Customrs customer = loadParty(iban,accountNo,bic,office,currecy);
			updatePDOWithCustomerData(pdo, customer, false); //is it neccecary on this point?
		
			boolean accountQuotedInPayment = !isNullOrEmpty(accountNo) || !isNullOrEmpty(iban);
			
			if (customer != null && (!accountQuotedInPayment || customer.getStpAccountDerivation() != 0)) {								
				logger.debug("attempt deriving debit account using Field 56 'bic'");
				//accounts = deriveCustomerAccount(bic, office,currecy,true/*assetAccount*/,true/*checkSTPFlag*/);
				accounts = deriveCustomerAccount(customer,currecy,true/*assetAccount*/);
			}			
		}

		logger.debug("found debit accounts using Field 56? {}",accounts != null);

		return accounts;
	}
	
	private Accounts deriveAccount( String accountNo
			  						 ,boolean isIBAN
			  						 ,boolean firstAsAlias
			  						 ,String currecy
			  						 ,String office) {
		  if (isNullOrEmpty(accountNo) || isNullOrEmpty(currecy) || isNullOrEmpty(office))
			  return null;
		  
		  logger.debug("deriving account: {}, Currency: {}, Office: {}, isIBAN {}"
	  					,new Object[]{ accountNo, currecy, office,isIBAN});
	  	   
		  if (isIBAN) 
			  accountNo = parseIBANAccout(accountNo,office);
		  
		  if (accountNo == null) //null is possible on invalid IBAN
			  return null;
		  
		  Accounts accounts = null;
		  
		  if (firstAsAlias) {  			  
			  accounts = BOAccountDerivation.getAccountUsingAccAlias(accountNo,office,currecy,null); //TBD custCode could be null?
			  logger.debug("account lookup using alias succeeded? {}",accounts != null);
		  }

		  if (accounts == null) {
			  accounts = CacheKeys.accountsKey.getSingle(accountNo, currecy, office);
			  
			  if (accounts != null && !currecy.equals(accounts.getCurrency())) {
				  logger.debug("invalid account, un expected currency: {}",accounts.getCurrency());
				  accounts = null;
			  }
			  
			  logger.debug("account {} lookup succeeded? {}",accountNo,accounts != null);
		  }
		  
		  return accounts;
	  }
	  	  
	  private Accounts deriveCustomerAccount( Customrs customrs
			  								 ,String currecy			  								 
			  								 ,boolean assetAccount) {
		if (customrs == null || isNullOrEmpty(currecy))
			return null;
		
		logger.debug("deriving customer ({}) {} account on currency {}"
				,new Object[]{customrs.getCustCode(),assetAccount ? "asset" : "non asset",currecy});

		List<Accounts> listAccounts = CacheKeys.accountsPerCustCodeAndCurrencyKey.get(customrs.getCustCode(),currecy);
		
		if (listAccounts == null || listAccounts.isEmpty())
			return null;
		
		Accounts accounts = getPrefferedAccount(listAccounts);
		accounts = applyAssetCriteria(accounts,assetAccount);
		
		return accounts;
	  }
	  
	  //TBD: should fallback to global office as well?
	  private Accounts deriveCurrencyDefaultNostroAccount(String currecy, String office) {
		  if (isNullOrEmpty(currecy) || isNullOrEmpty(office))
			  return null;
		  
		  logger.debug("deriving default nostro account of currency {} on office {}",currecy,office);
		
	      CurrencyBu currencyBu = CacheKeys.currencyBuKey.getSingle(office, currecy);
	    
	      if (currencyBu == null) {
	    	  logger.debug("CurrencyBu doesn't exists, currency {}, office {}.", currecy, office);
	    	  return null;
	      }
	      
	      String defaultNostroAccUID = currencyBu.getDefaultnostroacc();
	      
	      if(isNullOrEmpty(defaultNostroAccUID)) {
	    	  logger.debug("Null defaultNostroAcc");
	    	  return null;
	      }
	      
	      Accounts  accounts = CacheKeys.accountsKey.getSingle(defaultNostroAccUID);
	    	
	      logger.debug("currency default account {} exists? {} ",defaultNostroAccUID,accounts != null);
	      
	  	  return accounts;
	  }
	  
	  /**
	   * @return account number or null if invalid IBAN
	   */
	  private String parseIBANAccout(String IBAN,String office) {
		Admin admin = Admin.getContextAdmin();
		
		IBANInputData ibanInputData = new IBANInputData();
		ibanInputData.setPotentialIban(IBAN);
		ibanInputData.setMethod(IBANMethod.ValidationAndDeconstruction);
		ibanInputData.setOffice(office);
		
		IBANOutputData ibanOutputData = new IBANOutputData();
		try {
			ibanOutputData = m_paymentServicesLogging.performIBANHandling(admin, ibanInputData);
		} catch (PaymentServicesException e) {
			logger.error("Error while trying to deconsturct iban: " + e.getMessage());
			ibanOutputData.setStatus(IBANStatus.NonIBAN);
		}
		
		logger.debug("parsing IBAN {}, status: {}, account number {}"
				,new Object[]{IBAN,ibanOutputData.getStatus(),ibanOutputData.getAccountNumber()});
		
		if (IBANStatus.Valid == ibanOutputData.getStatus()) 
			return ibanOutputData.getAccountNumber();
		
		return null;
	 }
	  	  
	  private Accounts getPrefferedAccount(List<Accounts> listAccounts) {
	      if (listAccounts == null || listAccounts.isEmpty())
	    	  return null;
	      
	  	  logger.debug("looking for preffered account within {} accounts",listAccounts.size());
	  	  
	      if(listAccounts.size() == 1) 
	    	  return listAccounts.get(0);
	      
	    
	      Accounts preferredAccounts = null;
	      
	      // More then one account; look for the preferred
	      for (Accounts accounts : listAccounts) {
	    	  if (accounts.getPreferredacc() != 0) {
	    		  if (preferredAccounts != null) {
	    			  logger.debug("more then on account ({},{}) flagged as preferred, invalid status"
	    					  ,preferredAccounts.getAccNo(),accounts.getAccNo());
	    			  return null;
	    		  }
	    		  preferredAccounts = accounts;
	    	  }
	      }
	      
	      logger.debug("preffered account is {}",preferredAccounts.getAccNo());
	      
		  return preferredAccounts;
	  }
	  

	  private Accounts applyAssetCriteria(Accounts account,boolean assetAccount) {
		  if (account == null)
			  return null;
		  
		  if((assetAccount && account.getAsset().intValue() != NON_ASSET)
			  || (!assetAccount && account.getAsset().intValue() == NON_ASSET)) 
			  return account;
        
		  logger.debug("account {} does not matches {} criteria"
					  ,account.getAccNo(),assetAccount ? "asset" : "non asset");
		  
		  return null;
	  }
	  
	  /**
	   * load a party according to its identifier and apply it on the PDO
	   */
	  private Customrs loadParty(String iban, String accountNo, String bic,String office,String currency) {
		  Customrs customer = null;
		  
		  if (!isNullOrEmpty(iban)) 
			  customer = getCustomerByAccount(iban,true,office,currency);		  
		  else if (!isNullOrEmpty(accountNo))
			  customer = getCustomerByAccount(accountNo,false,office,currency);
		  
		  if (customer == null)
			  customer = getCustomerByBic(bic,office);
		  		  
		  return customer;
	  }

	  private Customrs getCustomerByAccount(String accountNo,boolean isIBAN,String office,String currency) {
		  logger.debug("get customer by account {} which is IBAN? {}",accountNo,isIBAN);
		  
		  if (isIBAN)
			  accountNo = parseIBANAccout(accountNo,office);
		  
		  if (accountNo == null) {
			  logger.debug("couldn't get customer using null account number");
			  return null;  
		  }
		  
		  logger.debug("first account lookup: using office and currency");
		
		  Accounts accounts = CacheKeys.accountsKey.getSingle(accountNo,currency,office);
	
		  if (accounts == null) {
			  logger.debug("second account lookup: using office only");
			  List<Accounts> listAccounts = CacheKeys.accountsAllCurrenciesKey.get(accountNo, office);
	
			  if (!isListNullOrEmpty(listAccounts))
				  accounts = listAccounts.get(0);		
		  }
		  
		  if (accounts == null) {
			  logger.debug("couldn't get customer using null accounts");
			  return null;  
		  }
		  
	      Customrs customer = CacheKeys.customrsKey.getSingle(accounts.getCustCode(),accounts.getOffice());
	      
	      logger.debug("get customer by custcode {} successed? {}",accounts.getCustCode(),customer != null);
		  
		  return customer;
	  }
	  
	  /**
	   * @param bic short or long format
	   */
	  private Customrs getCustomerByBic(String bic,String office) {
		logger.debug("get customer: bic {}, office {}", bic,office);
		
		if (isNullOrEmpty(bic) || isNullOrEmpty(office))
			return null;
		
	  	Customrs customrs = null;
	  	
	    if(!isNullOrEmpty(bic)) {	    		      
	      logger.debug("customer first lookup attempt: bic {}, office {}",bic,office);
	      customrs = CacheKeys.customrsBICandOfficeKey.getSingle(bic, office);
	      
	      if(customrs == null) {
	        logger.debug("customer second lookup attempt: bic {}, office '***'");
	        customrs = CacheKeys.customrsBICandOfficeKey.getSingle(bic, ServerConstants.DEFAULT_SERVER_OFFICE_NAME); 
	      }
	      
	      // Failed loading the customer; in case the BIC length is smaller then 8, no need to continue.
	      if(customrs == null && bic.length() >= 8) {
	      	String extendedBIC = bic.substring(0,8) + "XXX";
	      	
	      	// Tries loading the customer using the recieved BIC + 'XXX' suffix against the payment office.
	      	logger.debug("customer third lookup attempt: bic {}, office",extendedBIC,office);	        
	        customrs = CacheKeys.customrsBICandOfficeKey.getSingle(extendedBIC, office);
	        
	        // Tries loading the customer using the recieved BIC + 'XXX' suffix against the default '***' office.
	        if(customrs == null) {
	        	logger.debug("customer forth lookup attempt: bic {}, office '***'" ,extendedBIC);
	            customrs = CacheKeys.customrsBICandOfficeKey.getSingle(extendedBIC, ServerConstants.DEFAULT_SERVER_OFFICE_NAME);        	
	        }
	      }
	    }
	  	
	  	logger.debug("found customer by bic? {}", customrs != null);
	  	
	  	return customrs;
	  }
	  
	  private void updatePDOAccountData(PDO pdo, Accounts accounts, boolean credit) {
		  if (accounts == null || pdo == null)
			  return;
		  
		  BOAccountDerivation.updatePDOWithAccountData(accounts, credit);
	  }
	  
	  private void updatePDOWithCustomerData(PDO pdo,Customrs customrs,boolean credit) {
		  if (customrs == null || pdo == null)
			  return;
		  
		  logger.debug("setting PDO {} cutomer and cust code to  {}",
				  new Object[]{credit ? "credit" : "debit", customrs.getCustCode()});
		  
		  if (credit) {
	    	 pdo.setCREDIT_CUSTOMER(customrs);
	    	 pdo.set(P_CDT_CUST_CD, customrs.getCustCode());
	  	  } else {
	  		 pdo.setDEBIT_CUSTOMER(customrs);
	  		 pdo.set(P_DBT_CUST_CD, customrs.getCustCode());
	  	  }
	  }

	  private boolean handleAccountEnrichment(boolean creditAccount,PDO pdo) throws Exception {
		boolean alreadyDerived = isAccountDerived(pdo, creditAccount);
		  return new BOAccountDerivation().handleAccountEnrichment(creditAccount,alreadyDerived);
	}

	private boolean isAccountDerived(PDO pdo, boolean creditAccount) {
		boolean derived = creditAccount ? pdo.getCREDIT_ACCOUNT() != null : pdo
				.getDEBIT_ACCOUNT() != null;
		logger.debug("was {} account derived? {}", (creditAccount ? "credit"
				: "debit"), derived);
		return derived;
	}

	private String getAccountNumber(PDO pdo, boolean isCredit) {
		return isCredit ? pdo.getString(P_CDT_ACCT_NB) : pdo.getString(P_DBT_ACCT_NB);			
	}
	
	private Accounts getAccounts(PDO pdo, boolean isCredit) {
		return isCredit ? pdo.getCREDIT_ACCOUNT() : pdo.getDEBIT_ACCOUNT();			
	}
	
	private boolean isLocalBank(String senderBic, String recieverBic) {
		boolean isLocal = false;
	  
		try {
			isLocal = senderBic.substring(0,8).equals(recieverBic.substring(0,8));			  			  
		} catch (Exception e) {
			logger.error("unexpected error {}",e.getMessage());			  
		}	finally {
			logger.debug("sender is {}, reciever is {}, is local? {}"
					,new Object[]{senderBic,recieverBic,isLocal});			  
		}		
	  
		return isLocal;
   }

}// class
