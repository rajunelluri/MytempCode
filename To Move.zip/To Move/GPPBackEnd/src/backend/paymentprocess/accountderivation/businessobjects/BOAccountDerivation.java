package backend.paymentprocess.accountderivation.businessobjects;

import static backend.businessobject.BOProxies.m_internalInterfacesLogging;
import static backend.businessobject.BOProxies.m_paymentServicesLogging;
import static backend.paymentprocess.flow.base.FlowName.G3CTBook;
import static backend.paymentprocess.flow.base.FlowName.G3CTBookPreProcessStepSelector;
import static backend.paymentprocess.flow.base.FlowName.G3CTIncoming;
import static backend.paymentprocess.flow.base.FlowName.G3DDBook;
import static backend.paymentprocess.flow.base.FlowName.G3DDOutgoing;
import static com.fundtech.util.GlobalConstants.EMPTY_STRING;
import static com.fundtech.util.GlobalUtils.NVL;
import static com.fundtech.util.GlobalUtils.isArrayNotNullAndNotEmpty;
import static com.fundtech.util.GlobalUtils.isListNullOrEmpty;
import static com.fundtech.util.GlobalUtils.isNullOrEmpty;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.businessobject.BOBasic;
import backend.businessobject.BOProxies;
import backend.businessobject.proxies.LoadPDO;
import backend.core.module.MessageConstantsInterface;
import backend.dataaccess.dto.DTOSingleValue;
import backend.paymentprocess.accountderivation.common.AccountDerivationConstants;
import backend.paymentprocess.accountderivation.common.AccountDerivationConstants.AccountDerivationType;
import backend.paymentprocess.accountderivation.dao.DAOAccountDerivation;
import backend.paymentprocess.accountderivation.exception.AccountDerivationException;
import backend.paymentprocess.commons.MessageUtils;
import backend.paymentprocess.commons.MsgClassType;
import backend.paymentprocess.erroraudit.ErrorAuditUtils;
import backend.paymentprocess.flow.base.FlowName;
import backend.paymentprocess.flow.g3.G3Util;
import backend.paymentprocess.paymentservices.businessobjects.BOPaymentServices;
import backend.paymentprocess.paymentservices.common.IBANMethod;
import backend.paymentprocess.paymentservices.common.IBANStatus;
import backend.paymentprocess.paymentservices.exception.PaymentServicesException;
import backend.paymentprocess.paymentservices.input.IBANInputData;
import backend.paymentprocess.paymentservices.output.IBANOutputData;
import backend.util.ServerConstants;
import backend.util.ServerUtils;

import com.bcsis.ocbc.gpp.intf.acctinq.util.AccountInquiryUtil;
import com.fundtech.annotations.Expose;
import com.fundtech.annotations.Wrap;
import com.fundtech.cache.entities.AccountInquiryResponse;
import com.fundtech.cache.entities.Accounts;
import com.fundtech.cache.entities.Banks;
import com.fundtech.cache.entities.ClientId;
import com.fundtech.cache.entities.ComboData;
import com.fundtech.cache.entities.Customrs;
import com.fundtech.cache.entities.ExternalErrorMessage;
import com.fundtech.cache.entities.InterfaceTypes;
import com.fundtech.cache.entities.Mop;
import com.fundtech.cache.entities.Reasons;
import com.fundtech.cache.entities.RuleResult;
import com.fundtech.cache.entities.SwiftId;
import com.fundtech.cache.entities.VendorCodes;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.cache.syspar.SystemParametersInterface;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.errorhandling.ProcessError;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.datacomponent.response.SimpleResponseDataComponent;
import com.fundtech.errors.ProcessErrorConstants;
import com.fundtech.util.ExceptionController;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalStringUtil;
import com.fundtech.util.GlobalUtils;

/**
 * Title: BOAccountDerivation Description: Business object for account derivation Company: Fundtech Israel Author: Asaf Levy Date: 07/09/2008
 * 
 * @version 1.0
 */
@Wrap
public class BOAccountDerivation extends BOBasic implements PDOConstantFieldsInterface, MessageConstantsInterface {

	private static final Logger logger = LoggerFactory.getLogger(BOAccountDerivation.class);
	private static DAOAccountDerivation m_daoAccountDerivation = DAOAccountDerivation.getInstance();
	private static final ProcessError m_pErrorAccountDerivationFailure = new ProcessError(ProcessErrorConstants.AccountDerivationFailure);
	private static final String UNSUCESSFUL_SERVICE_RESPONSE_RECIEVED = "Unsuccessful Account inquiry response recieved will Not be saved to cache, account Number: {}, Currency: {}";
	private static final String SUCESSFUL_SERVICE_RESPONSE_RECIEVED= "Sucessful RT BULK Account inquiry response recieved will be saved to cache, account Number: {}, Currency: {}";
	private static Set<Integer> m_setOptionalErrorCodes;

	private static final String CREDIT_INDICATOR = "C";
	private static final String DEBIT_INDICATOR = "D";
	private static final String G3 = "G3";

	/**
   * 
   */
	static {
		m_setOptionalErrorCodes = new HashSet<Integer>();
		m_setOptionalErrorCodes.add(ProcessErrorConstants.AccountDerivationFailure);
		m_setOptionalErrorCodes.add(ProcessErrorConstants.AccountDerivationFailureNoAccountObjectForDebitMOPandInstdAgentBIC);
		m_setOptionalErrorCodes.add(ProcessErrorConstants.AccountDerivationFailureNoIdentifierObjectForDebitMOPandInstdAgentBIC);
		m_setOptionalErrorCodes.add(ProcessErrorConstants.AccountDerivationFailureSingleFoundAccountDoesNotAllowConversion);
		m_setOptionalErrorCodes.add(ProcessErrorConstants.AccountDerivationFailureMoreThenOnePreferredAccountForCustomerCodeAndCurrency);
		m_setOptionalErrorCodes.add(ProcessErrorConstants.AccountDerivationFailureMoreThenOnePreferredAccountForCustomerCode);
		m_setOptionalErrorCodes.add(ProcessErrorConstants.AccountDerivationFailureMultipleAccountsFoundForCustomerCodeAndCurrencyAndNoneAllowsConversion);
		m_setOptionalErrorCodes.add(ProcessErrorConstants.AccountDerivationFailureMultipleAccountsFoundForCustomerCodeAndNoneAllowsConversion);
		m_setOptionalErrorCodes.add(ProcessErrorConstants.AccountDerivationFailureMultipleAccountsFoundForCustomerCodeAndCurrencyAndNoneIsPreferred);
		m_setOptionalErrorCodes.add(ProcessErrorConstants.AccountDerivationFailureMultipleAccountsFoundForCustomerCodeAndNoneIsPreferred);
		m_setOptionalErrorCodes.add(ProcessErrorConstants.AccountDerivationFailureForAccountQuotedInPaymentSingleAccWasFoundAndNotAllowsConversion);
		m_setOptionalErrorCodes.add(ProcessErrorConstants.AccountDerivationFailureForAccountQuotedInPaymentMultipleAccountsFoundAndNoneAllowsConversion);
		m_setOptionalErrorCodes.add(ProcessErrorConstants.AccountDerivationFailureForAccountQuotedInPaymentMultipleAccountsFoundAndNoneIsPreferred);
		m_setOptionalErrorCodes.add(ProcessErrorConstants.AccountDerivationFailureAccountDoesNotAllowConversion);
		m_setOptionalErrorCodes.add(ProcessErrorConstants.AccountDerivationFailureAccountDerivedFromDebitMOPWithDiffCurrAndAndNotAllowsConversion);
		m_setOptionalErrorCodes.add(ProcessErrorConstants.AccountDerivationFailurePreferredAccountIsNotAnAssetAccount);
		m_setOptionalErrorCodes.add(ProcessErrorConstants.AccountDerivationFailurePreferredAccountIsNotANonAssetAccount);
		m_setOptionalErrorCodes.add(ProcessErrorConstants.AccountDerivationFailureSingleFoundAccountIsNotAnAssetAccount);
		m_setOptionalErrorCodes.add(ProcessErrorConstants.AccountDerivationFailureSingleFoundAccountIsNotANonAssetAccount);
		m_setOptionalErrorCodes.add(ProcessErrorConstants.AccountDerivationFailureNoSupportForSenderID_CP_Or_FW);
		m_setOptionalErrorCodes.add(ProcessErrorConstants.AccountDerivationFailureNullValueInPDOForMOPAndSenderID);
		m_setOptionalErrorCodes.add(ProcessErrorConstants.AccountDerivationFailureExpectedAssetAccount);
		m_setOptionalErrorCodes.add(ProcessErrorConstants.AccountDerivationFailureUnexpectedCurrency);
	}

	/**
	 * 1. Account derivation will search the account in GPP Accounts table. 2. If the Account is not found then Account inquiry will be performed. 3.
	 * If the account is found ( it may be a customer account or the bank account) then if the field (New in accounts table) HOST_CDB_CHCK_DBT (for
	 * debit account derivation) is TRUE then Account inquiry will be performed.
	 */
	public static Set<Integer> getOptionalErrorCodesSet() {
		return m_setOptionalErrorCodes;
	};

	@Expose
	@LoadPDO
	public Feedback performAccountInquiry(final String mid) throws Exception {

		Feedback retFeedback = new Feedback();
		PDO pdo = Admin.getContextPDO();
		boolean isCredit;// true for Credit, false for Debit.

		isCredit = pdo.getString(D_ACCOUNT_DERIVATION_TYPE).equals(AccountDerivationType.Credit.toString());

		String accountNumber = isCredit ? pdo.getString(X_CDTR_ACCT_ID) : pdo.getString(X_DBTR_ACCT_ID);
		String accountOffice = pdo.getString(P_OFFICE);
		String accountCurrency = null;
		// currency assignment
		if (G3Util.isIncoming(pdo)) {
			accountCurrency = pdo.getString(X_STTLM_CCY);
		} else if (isCredit) {
			accountCurrency = pdo.getString(X_CDTR_ACCT_CCY);
		} else {
			accountCurrency = pdo.getString(X_DBTR_ACCT_CCY);
		}// EO currency assignment

		Accounts account = CacheKeys.accountsKey.getSingle(accountNumber, accountCurrency, accountOffice);
		boolean isCDBRequired = false;
		if (account != null) {
			isCDBRequired = isCredit ? account.getCdbCheckCrInd() : account.getCdbCheckDrInd();
		}

		boolean goAccountInquiry = (account == null) || isCDBRequired;

		if (goAccountInquiry) {

			logger.debug("paymet goes to account inquiry service with account number {}  due  to: {}", new Object[] { accountNumber,
					null == account ? "account does not exist in GPP" : isCDBRequired ? "account exists in GPP but CDB flag is up" : "" });
			retFeedback = performAccountInquiryInner(pdo, isCredit, accountNumber, accountCurrency);

		} else {
			updatePDOWithAccountData(account,isCredit);
		}

		return retFeedback;
	}
	
	private String performAccountInquiryInterfaceSelection(PDO pdo, String interfaceType) 
	{
		List<RuleResult> listRuleResults;
		String interfaceName = interfaceType; // The default if no rule defined will assume that interface name equal to the interface type
		try {
			listRuleResults = BOProxies.m_internalRuleExecutionLogging.executeRule(Admin.getContextAdmin(), MessageConstantsInterface.RULE_TYPE_ID_INTERFACE_TYPE_SELECTION,
					interfaceType, pdo.getMID(), new String[] { pdo.getString(PDOConstantFieldsInterface.P_OFFICE), GlobalConstants.DEFAULT_SERVER_OFFICE_NAME }).getResults();
			if (listRuleResults != null && listRuleResults.size() > 0) {
				interfaceName = listRuleResults.get(0).getAction();
			}
		} catch (Exception e) {
			logger.error("Error while invoking interface type selection rule", e);
		}
		return interfaceName;
	}

	private Feedback performAccountInquiryInner(PDO pdo, boolean isCredit, String accountNumber, String accountCurrency) throws AccountDerivationException {

		Feedback retFeedback = new Feedback();
		AccountInquiryResponse accountInquiryResp = null;
		SimpleResponseDataComponent response = null;
		String internalFileID = pdo.getString(PDOConstantFieldsInterface.P_IN_INTERNAL_FILEID);
		boolean shouldUseCacheForRtBulkMessage = pdo.isBulkPayment() 
													&& GlobalConstants.RT.equals(pdo.get(PDOConstantFieldsInterface.P_BUSINESS_FLOW_TP))
													&& ((MessageUtils.isDirectDebit(pdo) && isCredit) 
															|| (!MessageUtils.isDirectDebit(pdo) && !isCredit));
		try {
			
			// Fix for Defect #79853 - in case of RT Bulk I-Message
			// The account inquiry execution moved to after the Warehousing flow step
			// And in order not to do a redundant calls we will be using new cache: accountInquiryKey
			if(shouldUseCacheForRtBulkMessage)
			{
				accountInquiryResp = CacheKeys.accountInquiryKey.getSingle(internalFileID);
			}
			
			String interfaceName = null;
			if(accountInquiryResp != null && accountInquiryResp.getResponse() != null)
			{
				logger.info("Taking Account Response from Distributed cache");
				response = accountInquiryResp.getResponse();
				
				//added new BCSIS code used for PDO update supporting the new cache response
				AccountInquiryUtil.storeResponseToPDO(pdo, response.getDataArray()[0]);
			}
			else
			{
				logger.info("Going to account inquiry");
				interfaceName = performAccountInquiryInterfaceSelection(pdo,"ACCNT_INQ");
				
				response = m_internalInterfacesLogging.performOutgoingRequestHandler(Admin.getContextAdmin(), pdo.getMID(), interfaceName, (HashMap)null);
				
				retFeedback = response.getFeedback();
				if(!response.getFeedback().isSuccessful())
					logger.debug(UNSUCESSFUL_SERVICE_RESPONSE_RECIEVED,accountNumber,accountCurrency);
				else if(shouldUseCacheForRtBulkMessage)
				{
					//in case of RT Bulk I message - we will save the response in a new cache AccountInquiryKey
					//this is a solution for avoiding redundant multiple calls
					logger.debug(SUCESSFUL_SERVICE_RESPONSE_RECIEVED,accountNumber,accountCurrency);
					accountInquiryResp = new AccountInquiryResponse(internalFileID, response);
					CacheKeys.accountInquiryKey.putSingle(accountInquiryResp,internalFileID);
				}
			}
			
			List<ExternalErrorMessage> listOfErrors = pdo.getExternalErrorMessages();
			
			if (!GlobalUtils.isListNullOrEmpty(listOfErrors)) {
			
				ExternalErrorMessage externalError = listOfErrors.get(0);
				ProcessError processError = null;
				Object[] params = null;
				if (interfaceName.equals("EBS_INQ")){
					String errorCode = externalError.getErrorCode();
					String errorInterfaceName = externalError.getInterfaceId();
					String SOAErrors = "0100,0110,0200,0300";
					if (SOAErrors.contains(errorCode)){
						params = new Object[2];
						params[0] = interfaceName;
						params[1] = externalError.getErrorDescription();
						processError = new ProcessError(40190, params);
						ErrorAuditUtils.setErrors(processError,pdo.getIsHistory());
						
					}else{
						//Error code for EBS_INQ interface
						params = new Object[5];
						params[0] = "Credit";
						params[1] = pdo.getString(X_CDTR_ACCT_ID);
						params[2] = InterfaceTypes.INTERFACE_TYPE_EBS_INQ;
						params[3] = externalError.getErrorCode();
						params[4] = externalError.getErrorDescription();
						processError = new ProcessError(40214, params);
						ErrorAuditUtils.setErrors(processError,pdo.getIsHistory());
					}
				}else{
					//Error code for ACCOUNT_INQUIRY interface
					params = new Object[5];
					params[0] = InterfaceTypes.INTERFACE_TYPE_ACCT_INQ;
					params[1] = isCredit ? AccountDerivationConstants.AccountDerivationType.Credit.name() : AccountDerivationConstants.AccountDerivationType.Debit.name();
					params[2] = isCredit ? pdo.getString(X_CDTR_ACCT_ID) : pdo.getString(X_DBTR_ACCT_ID);
					params[3] = externalError.getErrorCode();
					params[4] = externalError.getErrorDescription();
					processError = new ProcessError(98343, params);
					ErrorAuditUtils.setErrors(processError,pdo.getIsHistory());
				}
				String formattedErorrMsg = ErrorAuditUtils.getInstance().loadErrorAuditText(Long.valueOf(processError.getErrorCode()), pdo.getMID(), params);
				configureErrorFeedback(processError.getErrorCode(), formattedErorrMsg, retFeedback);
			} else {// Temporary put dummy values in missing PDO fields until fixed in Inquiry interface

				if (isCredit) {
					pdo.set(P_CDT_ACCT_OFFICE, pdo.getString(P_OFFICE));
					pdo.set(F_CDT_ACCT_ACC_TYPE, "ACC");
				} else {
					pdo.set(P_DBT_ACCT_OFFICE, pdo.getString(P_OFFICE));
					pdo.set(F_DBT_ACCT_ACC_TYPE, "ACC");
				}
			}
		} 
		catch (Throwable ex) 
		{
			//throw new AccountDerivationException(ex.getMessage());
			logger.debug("Error in Account Derivation " + ex.getMessage());
			ProcessError pError = new ProcessError(ProcessErrorConstants.MessageStatusChanged, new Object[] { pdo.getString(P_MSG_STS),MESSAGE_STATUS_REPAIR });
			ErrorAuditUtils.setErrors(pError,pdo);
			
			retFeedback.setFailure();
			pdo.set(P_MSG_STS, MESSAGE_STATUS_REPAIR);
			handleError(1001,pError.getDescription(), null, retFeedback);
		}
		
		
		

		return retFeedback;
	}

	/**
	 * Finds the first in chain of either credit or debit side for the passed MID.
	 */
	@Expose
	@LoadPDO
	public Feedback performAccountDerivation(final String sMID) throws AccountDerivationException {

		// perform account derivation from internal GPP accounts
		ArrayList<ProcessError> processErrors = new ArrayList<ProcessError>();
		Feedback feedback = performAccountDerivationInner(sMID, processErrors);

		// in case account derivation is not successful try to perform
		// virtual account derivation, which is based on checking the account id using client id profile
		if (!feedback.isSuccessful()) {

			// we need to check if virtual account processing of type "Client id" is needed
			final String CLIENT_ID = "Client Id";
			if (isVirtualAccountProcessingNeeded(CLIENT_ID)) {

				// in this process credit account on payment is checked against client id profile
				feedback = executeVirtualAccountProcessing();

				// when virtual account derivation is successful
				// perform the account derivation process again with newly derived account number to fill all needed fields on pdo
				if (feedback.isSuccessful()) {
					feedback = performAccountDerivationInner(sMID, processErrors);
				}
			} else {
				// in case when virtual account derivation needed we do not want
				// the error of credit account derivation to be printed on the payment
				// so we only print it here after the virtual account derivation check
				if (processErrors.size() >= 1) {
					ErrorAuditUtils.setErrors(processErrors.get(0));
				}
			}
		}

		return feedback;
	}

	/**
	 * Checks two aspects: 1. Are we in flow which needs the virtual account derivation 2. Is office allows virtual account derivation
	 * 
	 * @param processingType the type of virtual account processing
	 * @return true - for virtual account derivation, false - otherwise
	 */
	private boolean isVirtualAccountProcessingNeeded(String processingType) {
		final String TRACE_VIRTUAL_ACCOUNT_PROCESSING_VALUE = "System parameter VIRTUAL_ACCOUNT_PROCESSING value: {}";
		final String TRACE_ELIGIBLE_FLOWS_FOR_VIRTUAL_ACCOUNT_DERIVATION = "Flow {} is eligible for virtual account derivation";
		final String TRACE_NOT_ELIGIBLE_FLOWS_FOR_VIRTUAL_ACCOUNT_DERIVATION = "Flow {} is NOT eligible for virtual account derivation";

		PDO pdo = Admin.getContextPDO();
		String sP_OFFICE = pdo.getString(P_OFFICE);

		// Step 1
		// The following map holds flow names that are eligible for virtual account derivation
		// Add here the names for other eligible flows
		final Set<FlowName> ELIGIBLE_FLOWS_FOR_VIRTUAL_ACCOUNT_DERIVATION = new HashSet<FlowName>(Arrays.asList(new FlowName[] { G3CTIncoming, G3CTBook, G3DDBook,
				G3CTBookPreProcessStepSelector, G3DDOutgoing }));
		FlowName sFlowName = (FlowName) pdo.get(D_G3_IMMEDIATE_FLOW_NAME);
		if (!ELIGIBLE_FLOWS_FOR_VIRTUAL_ACCOUNT_DERIVATION.contains(sFlowName)) {
			logger.info(TRACE_NOT_ELIGIBLE_FLOWS_FOR_VIRTUAL_ACCOUNT_DERIVATION, sFlowName);
			return false;
		}

		// Step 2
		// Virtual account processing is defined on office level
		String sVIRTUAL_ACCOUNT_PROCESSING = CacheKeys.SystParKey.getSingleParmValue(sP_OFFICE, SystemParametersInterface.SYS_PAR_VIRTUAL_ACCOUNT_PROCESSING);

		logger.info(TRACE_VIRTUAL_ACCOUNT_PROCESSING_VALUE, sVIRTUAL_ACCOUNT_PROCESSING);
		boolean isEligibleProcessingType = sVIRTUAL_ACCOUNT_PROCESSING.equalsIgnoreCase(processingType);
		if (isEligibleProcessingType) {
			logger.info(TRACE_ELIGIBLE_FLOWS_FOR_VIRTUAL_ACCOUNT_DERIVATION, sFlowName);
		}
		// pay attention: the check is case insensitive
		return isEligibleProcessingType;
	}

	private Feedback performAccountDerivationInner(final String sMID, ArrayList<ProcessError> processErrors) throws AccountDerivationException {
		final String EXCEPTION_MESSAGE = "Exception has occured in 'BOAccountDerivation.performAccountDerivation'.";
		final String TRACE_INPUT_DATA = "MID = {}, Account derivation type = {}, Payment office = {}, Inst. currency = {}.";
		final String TRACE_MESSAGE_ACCOUNT_QUOTED_IN_PAYMENT = "Account quoted in payment: {}.";
		final String TRACE_CREDIT_ACCOUNT_WAS_SET_USING_CDB = "Credit account was set using CDB lookup during load customer stage; skips the account derivation process.";

		Feedback feedback = new Feedback();

		PDO pdo = Admin.getContextPDO();

		// Gets what type of account needs to be derived: credit or debit.
		String sAccountDerivationType = pdo.getString(D_ACCOUNT_DERIVATION_TYPE);
		boolean bCreditAccountDerivation = sAccountDerivationType.equals(AccountDerivationType.Credit.toString());
		boolean isDirectDebit = MessageUtils.isDirectDebit(pdo);

		if (bCreditAccountDerivation && MSG_CLASS_OPI.equals(pdo.getString(P_MSG_CLASS))) {
			return feedback;
		}

		String sPaymentOffice = pdo.getString(P_OFFICE);
		String sInstCurrency = pdo.getString(OX_STTLM_CCY);

		Object[] arrInputData = new Object[] { sMID, sAccountDerivationType, sPaymentOffice, sInstCurrency };
		logger.info(TRACE_INPUT_DATA, arrInputData);

		boolean bSuccessfulAccountDerivation = false;

		// In case CDB lookup was executed then this field has been set to true during 'BOLoadCustomer.executeAccountLookupRule' method.
		// In that case, if we're in credit side, then if the credit account was already set into the PDO, (during the CDB lookup),
		// then no need to continue the process.
		Object oD_CDB_LOOKUP_WAS_EXECUTED = pdo.getWithTransientLookup(D_CDB_LOOKUP_WAS_EXECUTED);
		boolean bCDBLookupWasExecuted = oD_CDB_LOOKUP_WAS_EXECUTED != null && ((Boolean) oD_CDB_LOOKUP_WAS_EXECUTED).booleanValue();
		if (bCreditAccountDerivation && bCDBLookupWasExecuted && pdo.getCREDIT_ACCOUNT() != null) {
			logger.info(TRACE_CREDIT_ACCOUNT_WAS_SET_USING_CDB);
			bSuccessfulAccountDerivation = true;
		}

		try {
			if (!bSuccessfulAccountDerivation) {
				// START Special case for DEBIT MT 910 message and CREDIT MT900 message
				boolean bMT910Handling = false;
				boolean bMT900Handling = false;
				String sMSG_TYPE = pdo.getString(P_MSG_TYPE);
				String sMSG_CLASS = pdo.getString(P_MSG_CLASS);
				sMSG_CLASS = sMSG_CLASS != null ? sMSG_CLASS.trim() : ServerConstants.EMPTY_STRING;

				if (!bCreditAccountDerivation && (MESSAGE_TYPE_SWIFT_910.equals(sMSG_TYPE) || MESSAGE_TYPE_910.equals(sMSG_TYPE) || MESSAGE_TYPE_SWIFT_298_012.equals(sMSG_TYPE))
						&& !MSG_CLASS_AF.equals(sMSG_CLASS)) {
					bMT910Handling = true;
				}
				// special case for MT900/298_011 messages - Credit Account derivation is performed although bCreditAccountDerivation flag is false
				if (!bCreditAccountDerivation && (MESSAGE_TYPE_SWIFT_900.equals(sMSG_TYPE) || MESSAGE_TYPE_SWIFT_298_011.equals(sMSG_TYPE))) {
					bMT900Handling = true;
				}

				logger.debug("is MT900 Handling {}, is MT910 Handling {}", bMT900Handling, bMT910Handling);
				// END Special case for DEBIT MT 910 message and CREDIT MT900 message

				// In case of an error that stops the process, will contain:
				// Index 0 - the error code.
				// Index 1 - the error variables, (binding parameters); might be null.
				Object[] arrProcessErrorData = new Object[2];

				// STEP 1 -
				// Checks if we already have an account number sets into dealt PDO.
				String sExistingAccount = bCreditAccountDerivation ? pdo.getString(P_CDT_ACCT_NB) : pdo.getString(P_DBT_ACCT_NB);
				//
				// Account already exists, (either as a result of manipulation or user GUI changes);
				// need to check if conversion is relevant for this payment and if so make sure that the found account allows conversion.
				if (!isNullOrEmpty(sExistingAccount)) {
					// This monitor field will be true only when the user has manually entered a CREDIT account in the GUI, so:
					// - For INCOMING messages, it will be empty.
					// - For OUTGOING messages, once the user selects manually a credit account, the monitor field will be set to 'M'
					// and will remain as such through the entire message life cycle.
					// NOTE: The above monitor field is set in the GUI to 'M' only for CREDIT account, as DEBIT account is a mandatory field
					// and is always entered by the user.
					String sMU_CDT_ACC_NUM_MANUALY_ENTERED = pdo.getString(MU_CDT_ACC_NB_MANUALY_ENTERED);
					boolean bAccNumManuallyEntered = MONITOR_FLAG_MANUAL_VALUE.equals(sMU_CDT_ACC_NUM_MANUALY_ENTERED);

					// According to above explanation regarding the MU_CDT_ACC_NUM_MANUALY_ENTERED monitor field, we should
					// consider an existing account only in the following cases:
					// 1) Debit account derivation.
					// 2) Credit account derivation for which the account was manually entered by the user.
					// - An example for credit account derivation for which the existing account shouldn't be considered:
					// 1) User created a message, entered a BIC in field 57 and submitted the message.
					// 2) The application derived the account number using the BIC but the message fell to REPAIR because
					// of some problem, (e.g. no valid MOPs).
					// 3) The user changed the BIC value in field 57 and re-submitted the message; when arriving to the
					// account derivation, the old account that was derived in section 1 is not relevant anymore and the
					// account should be derived again using the new BIC.
					if (!bCreditAccountDerivation && !bMT900Handling /* for MT900, debit derivation is actually credit derivation */
							|| (bCreditAccountDerivation && bAccNumManuallyEntered)) {
						bSuccessfulAccountDerivation = handleExistingAccount(sExistingAccount, bCreditAccountDerivation, arrProcessErrorData);
					}
				}

				// If we have a valid value in 'arrProcessErrorData[0]' then it means that we had an existing account that doesn't allow
				// conversion; we need to stop the process.
				boolean bContinue = arrProcessErrorData[0] == null;

				if (!bSuccessfulAccountDerivation && bContinue) {
					boolean[] arrContinue = new boolean[] { true };

					// Will be executed if:
					// Debit derivation and we're not in DD. (for MT900, debit derivation is actually credit derivation)
					// OR Credit derivation and we're in DD.

					if ((!bCreditAccountDerivation && !isDirectDebit && !bMT900Handling) || (bCreditAccountDerivation && isDirectDebit)) {
						bSuccessfulAccountDerivation = deriveAccountFromIdentifiersData(arrContinue, arrProcessErrorData, true, bCreditAccountDerivation);
					}

					// Continues if we're in:
					// 1) CREDIT side derivation.
					// OR 2) DEBIT side derivation and 'deriveDebitAccountFromIdentifiersData' didn't succeed in
					// deriving the account and didn't marked the 'arrContinue' flag as false.
					if (bCreditAccountDerivation || (!bCreditAccountDerivation && !bSuccessfulAccountDerivation && arrContinue[0])) {
						// Checks if an account was quoted in the payment, where lookup is as follows:
						// 1) Account that was derived from an IBAN, (in case IBAN was found as first in chain);
						// If value exists, then it was set into the PDO during 'BOLoadCustomer.loadCustomerUsingIBAN' method.
						// 2) "DIRECT" account that was found as first in chain.
						// If value exists, then it was set into the PDO during the find first in chain process.
						String sAccountQuotedInPayment = bCreditAccountDerivation ? pdo.getString(D_CDT_IBAN_DERIVED_ACCOUNT) : pdo.getString(D_DBT_IBAN_DERIVED_ACCOUNT);

						if (sAccountQuotedInPayment == null) {
							sAccountQuotedInPayment = bCreditAccountDerivation ? pdo.getString(D_FIRST_IN_CDT_CHAIN_ACC_NUM) : pdo.getString(D_FIRST_IN_DBT_CHAIN_ACC_NUM);
						}

						logger.info(TRACE_MESSAGE_ACCOUNT_QUOTED_IN_PAYMENT, sAccountQuotedInPayment);
						boolean bAccountQuotedInPayment = !isNullOrEmpty(sAccountQuotedInPayment);

						if (bMT910Handling)
							bSuccessfulAccountDerivation = deriveMT910Account(sPaymentOffice, sInstCurrency, arrProcessErrorData);

						if (bMT900Handling)
							bSuccessfulAccountDerivation = deriveMT900Account(sPaymentOffice, sInstCurrency, arrProcessErrorData);

						// STEP 3 -
						// Tries to derive the account from account quoted in the payment only if
						// we have a valid value for it.
						if (!bSuccessfulAccountDerivation && !bMT900Handling && !bMT910Handling & bAccountQuotedInPayment) {
							bSuccessfulAccountDerivation = deriveAccountFromAccountQuotedInPayment(bCreditAccountDerivation, sAccountQuotedInPayment, arrProcessErrorData);
						}

						// STEP 4 -
						// Derivation from account has failed and this is not a 900/910 message.
						if (!bSuccessfulAccountDerivation && !bMT900Handling && !bMT910Handling) {
							final String TRACE_GETTING_CUSTOMRS_DATA = "MID: {}, AccountDerivationType: {}, P_DBT_CUST_CD: {}, P_CDT_CUST_CD: {}.";
							final String TRACE_CUSTOMRS_DATA = "MID: {}, Customrs object ID: {}, STP_ACCOUNT_DERIVATION: {}, Account quoted in payment: {}.";
							final String TRACE_CUSTOMRS_IS_NULL = "MID: {}, No Customrs object was found.";

							String sP_DBT_CUST_CD = pdo.getString(PDOConstantFieldsInterface.P_DBT_CUST_CD);
							String sP_CDT_CUST_CD = pdo.getString(PDOConstantFieldsInterface.P_CDT_CUST_CD);

							logger.info(TRACE_GETTING_CUSTOMRS_DATA, new Object[] { sMID, sAccountDerivationType, sP_DBT_CUST_CD, sP_CDT_CUST_CD });

							// Gets the customer data.
							Customrs customrs = bCreditAccountDerivation ? pdo.getNSetCREDIT_CUSTOMER() : pdo.getNSetDEBIT_CUSTOMER();

							if (customrs != null) {
								logger.info(TRACE_CUSTOMRS_DATA, new Object[] { sMID, customrs, customrs.getStpAccountDerivation(), bAccountQuotedInPayment });
							} else {
								logger.info(TRACE_CUSTOMRS_IS_NULL, sMID);
							}

							// Valid customer data.
							if (customrs != null) {
								// STEP 5 -
								// The decision to try and derive the account from the customer is according to:
								// 1) No account was quoted in payment.
								// OR
								// 2) Account was quoted in payment, we failed account derivation using
								// this account and the customer is flagged for 'STP account derivation'.
								if (!bAccountQuotedInPayment || customrs.getStpAccountDerivation() != 0) {
									// Resets the 'arrProcessErrorData' array which might includes errors from the call to the
									// 'deriveAccountFromAccountQuotedInPayment' method if it was called in an earlier step.
									arrProcessErrorData = new Object[2];
									bSuccessfulAccountDerivation = deriveAccountFromCustomerData(bCreditAccountDerivation, arrProcessErrorData);
								}
							}

							// This situation shouldn't occur as the customer data should have been set
							// in an earlier step of the process, ('load customer' step), and in case
							// of failure there, the process should have been stopped before arriving
							// to the account derivation step; however, we cover this case for tracing.
							else {
								final String MESSAGE_ILLEGAL_STATE_WHEN_ARRIVING_TO_ACCOUNT_DERIVATION = "Illegal state - in 'Account derivation', but customer data wasn't set in previous step !!!";
								logger.info(MESSAGE_ILLEGAL_STATE_WHEN_ARRIVING_TO_ACCOUNT_DERIVATION);
							}
						}
					}
				}

				// Invokes the account enrichment rule, (rule type ID 170/171 for credit/debit). In case of MT900 the credit side should be filled and
				// vice versa in case of MT910,
				// in rest cases should be predefined by derivation type
				if (bMT900Handling) {
					bSuccessfulAccountDerivation = handleAccountEnrichment(true, bSuccessfulAccountDerivation);
				}
				if (bMT910Handling) {
					bSuccessfulAccountDerivation = handleAccountEnrichment(false, bSuccessfulAccountDerivation);
				} else {
					bSuccessfulAccountDerivation = handleAccountEnrichment(bCreditAccountDerivation, bSuccessfulAccountDerivation);
				}

				if (!bSuccessfulAccountDerivation) {
					ProcessError processError = getFailureProcessError(arrProcessErrorData);

					// DEBIT account derivation always returns successful feedback, even if an actual process error was found;
					// We keep the error and it will be used and set into the PDO at the end of the 'BOPISNMatching.performPISNMatchingProcess'
					// method, (look there for the D_DEBIT_ACC_DERIVATION_PROCESS_ERROR field); this is done so the process won't be stopped and that
					// payment
					// classification rule will be executed.
					// Exception for 900/910/298_011/298_012 messages - When account derivation fails fall immediately to REPAIR status
					if (!bCreditAccountDerivation) {
						String sFlowName = NVL(pdo.getString(D_G3_IMMEDIATE_FLOW_NAME), EMPTY_STRING);
						Boolean isG3Flow = sFlowName.startsWith(G3); // Added by Ronen M according to Liat M
						String msgType = pdo.getString(P_MSG_TYPE);
						if (isG3Flow || MESSAGE_TYPE_SWIFT_900.equals(msgType) || MESSAGE_TYPE_SWIFT_298_011.equals(msgType) || MESSAGE_TYPE_SWIFT_910.equals(msgType)
								|| MESSAGE_TYPE_SWIFT_298_012.equals(msgType)) {
							configureErrorFeedback(processError.getErrorCode(), processError.getDescription(), feedback);
							ErrorAuditUtils.setErrors(processError, pdo.getIsHistory());
							ExternalErrorMessage error = new ExternalErrorMessage("GPP", String.valueOf(processError.getErrorCode()),
									String.valueOf(processError.getDescription()), pdo.getMID(), pdo.getIsHistory());
							pdo.addExternalErrorMessage(error);
						} else {
							pdo.setTransient(D_DEBIT_ACC_DERIVATION_PROCESS_ERROR, processError);
						}
					}

					// CREDIT account derivation.
					else {
						processErrors = new ArrayList<ProcessError>();
						processErrors.add(processError);
						// audit trail moved outside of the function, because of virtual account derivation
						configureErrorFeedback(processError.getErrorCode(), processError.getDescription(), feedback);
						// ErrorAuditUtils.setErrors(processError);
						logger.error(processError.getErrorCode() + "-" + processError.getDescription());
					}
				}
			}

		} catch (Exception e) {
			ExceptionController.getInstance().handleException(e, this);

			String sOriginalExceptionMessage = e.getMessage();
			String sExceptionMessage = sOriginalExceptionMessage != null ? sOriginalExceptionMessage : EXCEPTION_MESSAGE;
			throw new AccountDerivationException(sExceptionMessage, e);
		}

		return feedback;
	}

	/**
   * 
   */
	public boolean handleAccountEnrichment(boolean bCreditAccountDerivation, boolean bSuccessfulAccountDerivationAlreadySucceed) throws Exception {
		final String ACCOUNT_ENRICH_RULE_RESULTS = "{} account enrichment rule results - Main action 1: {}, Secondary action 2: {}.";
		final String CREDIT = "Credit";
		final String DEBIT = "Debit";
		final String SECONDARY_ACTION_DEFAULT_ACCOUNT = "DEFAULT_ACCOUNT";
		final String SECONDARY_ACTION_OVERRIDE_ACCOUNT = "OVERRIDE_ACCOUNT";
		// final String TRACE_SECONDARY_ACTION_DEFAULT_ACCOUNT_AND_DERIVATION_ALREADY_SUCCEED =
		// "Secondary action is DEFAULT_ACCOUNT and derivation has already succeed; sets {} to 'N'.";
		final String TRACE_SET_MONITOR_FIELD_TO_ENRICH = "Sets {} to 'E'.";
		final String TRACE_VALID_ACCOUNTS_OBJECT = "Valid Accounts object using UID {}; derivation success !!!";
		final String TRACE_INVALID_ACCOUNTS_OBJECT = "No valid Accounts object using UID {}; derivation failure & {} won't be set to 'E' !!!";
		final String TRACE_SKIP_REST_OF_PROCESS = "Skips rest of process; OVERRIDE_ACCOUNT action and rule action '{}' equals current {} account values.";

		boolean bSuccessfulAccountDerivation = bSuccessfulAccountDerivationAlreadySucceed;

		PDO pdo = Admin.getContextPDO();

		// Gets the related monitor field value.
		String sRelatedMonitorFieldName = bCreditAccountDerivation ? MF_CDT_ACCT_ENRICH : MF_DBT_ACCT_ENRICH;
		String sCREDIT_DEBIT = (bCreditAccountDerivation ? CREDIT : DEBIT);

		// STEP 1 -
		// Invokes the credit/debit account enrichment rule, (rule type ID 170/171).
		String sRuleTypeID = bCreditAccountDerivation ? RULE_TYPE_ID_CREDIT_ACCOUNT_ENRICHMENT : RULE_TYPE_ID_DEBIT_ACCOUNT_ENRICHMENT;
		String[] arrRuleActions = BOProxies.m_paymentServicesLogging.invokeRuleWithSecondaryAction(Admin.getContextAdmin(), sRuleTypeID, bCreditAccountDerivation);
		logger.info(ACCOUNT_ENRICH_RULE_RESULTS, new Object[] { sCREDIT_DEBIT, arrRuleActions[0], arrRuleActions[1] });

		// Enrichment is required.
		if (isArrayNotNullAndNotEmpty(arrRuleActions)) {
			String sAccountsProfileUID = arrRuleActions[0];
			String sSecondaryAction = arrRuleActions[1];

			if (!isNullOrEmpty(sSecondaryAction)) {
				boolean bOverrideAccountSecondaryAction = SECONDARY_ACTION_OVERRIDE_ACCOUNT.equals(sSecondaryAction);

				// Enters the enrichment process if:
				// 1) Secondary action is DEFAULT_ACCOUNT and account derivation didn't succeed yet; i.e. the default account
				// should be set.
				// OR 2) Secondary action is OVERRIDE_ACCOUNT; i.e. whether account derivation has already succeed or not,
				// the account should be overridden.
				if ((SECONDARY_ACTION_DEFAULT_ACCOUNT.equals(sSecondaryAction) && !bSuccessfulAccountDerivationAlreadySucceed) || bOverrideAccountSecondaryAction) {
					// In case there was no successfull account derivation, sets the value to empty string, which satisfis us for the ahead
					// comparison using this variable.
					String sCurrentRelatedUIDValue = bSuccessfulAccountDerivationAlreadySucceed ? getCurrentUIDValue(bCreditAccountDerivation) : ServerConstants.EMPTY_STRING;

					// Skips the rest of the process if:
					// 1) We're in OVERRIDE_ACCOUNT secondary action.
					// AND 2) We had successfull account derivation prior to the call to this method.
					// AND 3) The rule action, (i.e. the ACCOUNTS record UID), equals the already derived account number.
					boolean bSkip = bOverrideAccountSecondaryAction && bSuccessfulAccountDerivationAlreadySucceed && sCurrentRelatedUIDValue.equals(sAccountsProfileUID);

					// No skip.
					if (!bSkip) {
						Accounts accounts = CacheKeys.accountsKey.getSingle(sAccountsProfileUID);

						// Valid Accounts object.
						if (accounts != null) {
							logger.info(TRACE_VALID_ACCOUNTS_OBJECT, sAccountsProfileUID);
							logger.info(TRACE_SET_MONITOR_FIELD_TO_ENRICH, sRelatedMonitorFieldName);

							// Sets related service monitor to 'E'.
							pdo.set(sRelatedMonitorFieldName, MONITOR_FLAG_ENRICHED);

							// Updates the accounts data.
							updatePDOWithAccountData(accounts, bCreditAccountDerivation);
							bSuccessfulAccountDerivation = true;

							// Updates the related customer data.
							String sCustCode = accounts.getCustCode();
							Customrs customrs = CacheKeys.customrsCCKey.getSingle(sCustCode);

							if (bCreditAccountDerivation) {
								pdo.setCREDIT_CUSTOMER(customrs);
								pdo.set(P_CDT_CUST_CD, sCustCode);
							} else {
								pdo.setDEBIT_CUSTOMER(customrs);
								pdo.set(P_DBT_CUST_CD, sCustCode);
							}
						}

						// Invalid Accounts object.
						else {
							logger.info(TRACE_INVALID_ACCOUNTS_OBJECT, sAccountsProfileUID, sRelatedMonitorFieldName);
							bSuccessfulAccountDerivation = false;
						}
					}
				}

				// Rest of the process was skipped.
				else {
					logger.info(TRACE_SKIP_REST_OF_PROCESS, sAccountsProfileUID, sCREDIT_DEBIT);
				}
			}
		}

		return bSuccessfulAccountDerivation;
	}

	/**
   * 
   */
	private String getCurrentUIDValue(boolean bCreditAccountDerivation) {

		StringBuilder sbCurrentRelatedUIDValue = new StringBuilder();

		PDO pdo = Admin.getContextPDO();

		if (bCreditAccountDerivation) {
			sbCurrentRelatedUIDValue.append(pdo.getString(P_CDT_ACCT_OFFICE)).append(ServerConstants.POWER_SIGN).append(pdo.getString(P_CDT_ACCT_NB))
					.append(ServerConstants.POWER_SIGN).append(pdo.getString(P_CDT_ACCT_CCY));
		}

		else {
			sbCurrentRelatedUIDValue.append(pdo.getString(P_DBT_ACCT_OFFICE)).append(ServerConstants.POWER_SIGN).append(pdo.getString(P_DBT_ACCT_NB))
					.append(ServerConstants.POWER_SIGN).append(pdo.getString(P_DBT_ACCT_CCY));
		}

		return sbCurrentRelatedUIDValue.toString();
	}

	/**
	 * Derives the account from a MT900 or MT298_011 message.
	 * 
	 * @return true when derivation succeeded
	 */
	private boolean deriveMT900Account(String sPaymentOffice, String sInstCurrency, Object[] arrProcessErrorData) {
		return deriveMT900orMT910Account(sPaymentOffice, sInstCurrency, true, arrProcessErrorData);
	}

	/**
	 * Derives the account from a MT910 or MT298_012 message.
	 * 
	 * @return true when derivation succeeded
	 */
	private boolean deriveMT910Account(String sPaymentOffice, String sInstCurrency, Object[] arrProcessErrorData) {
		return deriveMT900orMT910Account(sPaymentOffice, sInstCurrency, false, arrProcessErrorData);
	}

	private boolean deriveMT900orMT910Account(String paymentOffice, String instCurrency, boolean isCredit, Object[] arrProcessErrorData) {
		logger.debug("deriveMT900orMT910Account paymentOffice {}, instCurrency {}, isCredit {}", new Object[] { paymentOffice, instCurrency, isCredit });

		boolean bSuccessfulAccountDerivation = true;

		PDO pdo = Admin.getContextPDO();

		// Holds the account number received in field 25 is the account that has been credited by the sender of the MT910.
		String accountId = null;
		if (StringUtils.isNotEmpty(pdo.getString(X_NTF_ACCT_ID))) {
			accountId = pdo.getString(X_NTF_ACCT_ID);
		} else if (StringUtils.isNotEmpty(pdo.getString(X_NTF_ACCT_IBAN))) {
			accountId = BOAccountDerivation.parseIBANAccout(pdo.getString(X_NTF_ACCT_IBAN), paymentOffice);
		}

		// String sP_CUST_CODE = pdo.getString(P_DBT_CUST_CD);
		// - do not use this field for getting account by alias, because cases in which
		// the account doesn't match the sender should be caught by a Validation Rule (20) and send message to REPAIR

		// first try to get account by alias
		Accounts accounts = null;
		if (accountId != null) {
			accounts = getAccountUsingAccAlias(accountId, paymentOffice, instCurrency, null);
		}

		if (accounts == null) {
			// account was not found by alias, try to find it by acc. number
			accounts = CacheKeys.accountsKey.getSingle(accountId, instCurrency, paymentOffice);// may return account with a different ccy that
																								// requested
			if ((accounts != null) && (instCurrency != null) && (!instCurrency.equals(accounts.getCurrency()))) {
				accounts = null;
			}
		}

		if (accounts != null) {
			updatePDOWithAccountData(accounts, isCredit);
			// save derived account info - it will be used in Account Validation Step
			pdo.setSTMT_ACCT(accounts);
			String accountCustCode = accounts.getCustCode();
			Customrs accountOwner = CacheKeys.customrsCCKey.getSingle(accountCustCode);
			if (accountOwner != null) {
				// Account and account's owner were found, set pdo with account's owner data
				pdo.setSTMT_ACCT_OWNR(accountOwner);
			} else {// fail account derivation step
				bSuccessfulAccountDerivation = false;
				logger.error("Failing Account Derivation step because of wrong configuration - A customer with cust_code={} cannot be found in DB", accountCustCode);
				arrProcessErrorData[0] = ProcessErrorConstants.PartyCannotBeFound;
				pdo.set(P_MSG_STS, MESSAGE_STATUS_REPAIR);
			}

		} else {
			bSuccessfulAccountDerivation = false;
			pdo.set(P_MSG_STS, MESSAGE_STATUS_REPAIR);
		}

		return bSuccessfulAccountDerivation;
	}

	/**
   * 
   */
	public static Accounts getAccountUsingAccAlias(String sAccAlias, String sPaymentOffice, String sInstCurrency, String sCustCode) {

		Accounts accounts = null;

		DTOSingleValue dto = m_daoAccountDerivation.getAccountUsingAccAlias(sAccAlias, sPaymentOffice, sInstCurrency, sCustCode);
		Feedback feedback = dto.getFeedBack();

		if (dto.isFeedBackSuccess()) {
			if (!dto.isEmpty()) {
				String sAccountNumber = dto.getValue();

				if (!isNullOrEmpty(sAccountNumber) && !isNullOrEmpty(sInstCurrency)) {
					accounts = CacheKeys.accountsKey.getSingle(sAccountNumber, sInstCurrency, sPaymentOffice);
				}

				if (accounts == null && isNullOrEmpty(sInstCurrency)) {
					List<Accounts> listAccounts = CacheKeys.accountsAllCurrenciesKey.get(sAccountNumber, sPaymentOffice);

					// Uses the account in index 0.
					// This code was added for a case in load customer where the account in field 53/54 actually stands for account asset number,
					// (ACCOUNTS.ACC_ALIAS),
					// and since in load customer, when we use the 'accountsAllCurrenciesKey' cache in the usual account number case, we also take
					// index 0,
					// then also follows the same logic here.
					if (!isListNullOrEmpty(listAccounts)) {
						accounts = listAccounts.get(0);
					}
				}
			}
		}

		else {
			logger.info(ServerUtils.getFeedbackString(feedback));
		}

		return accounts;
	}

	/**
   * 
   */
	public boolean handleExistingAccount(String sExistingAccount, boolean bCreditAccountDerivation, Object[] arrProcessErrorData) {
		final String TRACE_EXISTING_ACCOUNT_DETAILS = "Existing account details - Account number: {}, Adjusted account number acc. to office prefs: {}, Currency: {}, Office: {}.";
		final String TRACE_NO_ACCOUNTS_RECORD_FOUND_FOR_EXISTING_ACCOUNT = "No ACCOUNTS record was found for existing account {} !!!";
		final String TRACE_DIFFERENT_INST_CURR_AND_ACCOUNT_CURR = "Instruction currency {} is different then account currency {}; account allows conversion: {}.";
		final String TRACE_EQUAL_INST_CURR_AND_ACCOUNT_CURR = "Instruction currency & account currency are the same: {}.";

		final String TRACE_METHOD_RESULT = "Successful account derivation: {}.";

		boolean bSuccessfulAccountDerivation = false;

		PDO pdo = Admin.getContextPDO();

		String sAccountCurrency, sAccountOffice;

		if (bCreditAccountDerivation) {
			sAccountCurrency = pdo.getString(P_CDT_ACCT_CCY);
			sAccountOffice = pdo.getString(P_CDT_ACCT_OFFICE);
		} else {
			sAccountCurrency = pdo.getString(P_DBT_ACCT_CCY);
			sAccountOffice = pdo.getString(P_DBT_ACCT_OFFICE);
		}

		// Adjusts the recieved account according to office preferences.
		String sAdjustedAccount = BOPaymentServices.adjustAccountAccordingToOfficePreferences(sExistingAccount, sAccountOffice);

		logger.info(TRACE_EXISTING_ACCOUNT_DETAILS, new Object[] { sExistingAccount, sAdjustedAccount, sAccountCurrency, sAccountOffice });

		// Loads the Accounts record and updates relevant PDO data.
		Accounts accounts = CacheKeys.accountsKey.getSingle(sAdjustedAccount, sAccountCurrency, sAccountOffice);

		// Account was found; need to check if conversion is relevant for this payment and if so make sure that
		// the found account allows conversion.
		if (accounts != null) {
			String sInstCurrency = pdo.getString(OX_STTLM_CCY);

			// Account currency & instruction currency are not the same; checks if the account allows conversion.
			if (!sInstCurrency.equals(sAccountCurrency)) {
				Long lAllowConversion = bCreditAccountDerivation ? accounts.getCreditConversion() : accounts.getDebitConversion();
				logger.info(TRACE_DIFFERENT_INST_CURR_AND_ACCOUNT_CURR, new Object[] { sInstCurrency, sAccountCurrency, (lAllowConversion.intValue() != 0) });
				bSuccessfulAccountDerivation = (lAllowConversion.intValue() != 0);
			}

			// Account currency & instruction currency are the same; found account is a valid one.
			else {
				logger.info(TRACE_EQUAL_INST_CURR_AND_ACCOUNT_CURR, sInstCurrency);
				bSuccessfulAccountDerivation = true;
			}
		}

		// Not likely that we'll enter this part because we're in this method after account was entered in the GUI and passed validation there.
		else {
			logger.info(TRACE_NO_ACCOUNTS_RECORD_FOUND_FOR_EXISTING_ACCOUNT, sAdjustedAccount);
		}

		logger.info(TRACE_METHOD_RESULT, bSuccessfulAccountDerivation);

		// Valid account; updates PDO relevant class member.
		if (bSuccessfulAccountDerivation) {
			if (bCreditAccountDerivation) {
				pdo.setCREDIT_ACCOUNT(accounts);
			} else {
				pdo.setDEBIT_ACCOUNT(accounts);
			}

			// This code of loads STMT_ACCT and STMT_ACCT_OWNR.
			// It was added here for SC/SN messages that
			// goes back into the flow (for ex. after manual matching) after already going through the CREDIT/DEBIT account derivation in the first
			// flow execution.
			// In these cases, P_DBT_ACCT_NB/P_CDT_ACCT_NB will already be set and the payments will get into this derivation flow
			// (handleExistingAccount).
			// In the cont. of the flow - the account validation uses the STMT_ACCT and STMT_ACCT_OWNR so we need to make sure they are loaded here
			// just as they are loaded in the regular account
			// derivation flow that the SC/SN payment go through on the first run.
			pdo.setSTMT_ACCT(accounts);
			String accountCustCode = accounts.getCustCode();
			Customrs accountOwner = CacheKeys.customrsCCKey.getSingle(accountCustCode);
			if (accountOwner != null) {
				// Account and account's owner were found, set pdo with account's owner data
				pdo.setSTMT_ACCT_OWNR(accountOwner);
			} else {
				logger.error("Failing Account Derivation step because of wrong configuration - A customer with cust_code={} cannot be found in DB", accountCustCode);
				arrProcessErrorData[0] = ProcessErrorConstants.PartyCannotBeFound;
				accounts = null;
			}
			// /--///

		}

		// Not a valid account
		else if (accounts != null) {
			// Error code 40133: 'Failed to derive account number; account does not allow conversion: account |1, office |2 and currency |3'.
			arrProcessErrorData[0] = ProcessErrorConstants.AccountDerivationFailureAccountDoesNotAllowConversion;
			arrProcessErrorData[1] = new Object[] { sExistingAccount, sAccountOffice, sAccountCurrency };

			accounts = null;
		} else {
			// TBD account not exists error
		}

		return bSuccessfulAccountDerivation;
	}

	/**
	 * Returns the right process error for a failure in the process.
	 */
	public ProcessError getFailureProcessError(Object[] arrProcessErrorData) {

		ProcessError processError = null;

		if (arrProcessErrorData[0] != null) {
			Object[] arrNonPaymentFields = (Object[]) arrProcessErrorData[1];
			processError = new ProcessError((Integer) arrProcessErrorData[0], arrNonPaymentFields);
		}

		else {
			processError = m_pErrorAccountDerivationFailure;
		}

		return processError;
	}

	/**
	 * Derives the account using the data in the SWIFT_ID table.
	 */
	public boolean deriveAccountFromIdentifiersData(boolean[] arrContinue, Object[] arrProcessErrorData, boolean toleranceCurrecny, boolean isCreditAcctDerivation) {
		final String MESSAGE_SRC_MOP_AND_ORIG_CLR_SYS_ID = "Source MOP: {}, OX_CLR_SYS_ID: {}.";
		final String MESSAGE_SWIFTID_LOOKUP_DETAILS = "Tries loading SwiftId using Source MOP '{}' and SWIFT_ID, (might be NCC member ID) '{}'.";
		final String MESSAGE_SWIFTID_LOOKUP_DETAILS_2ND_TIME = "Didn't find SwiftId using 8 chars BIC; tries loading it using Source MOP '{}' and BIC '{}'.";
		final String MESSAGE_SEND_REC_IDCODE = "MOP {}, SEND_REC_IDCODE: {}.";
		final String MESSAGE_SWIFTID_RETRIEVED = "The Selected Swift ID is : {}.";
		final String MESSAGE_WILL_PERFORM_DERIVATION = "The account derivation will be performed since the related mop {} has a settlement account.";
		final String MESSAGE_WILL_NOT_PERFORM_DERIVATION = "The account derivation will not be performed since the related mop {} doesn't have a settlement account.";
		final String MESSAGE_ACCOUNT_WAS_FOUND = "Account was found using identifiers data, (SWIFT_ID table).";
		final String MESSAGE_ACCOUNT_WAS_FOUND_BUT_WITH_DIFF_CURR_AND_NO_CONVERSION_ALLOWED = "Account was found using identifiers data, (SWIFT_ID table), but account currency is different then payment currency and account doesn't allow conversion; account number: {}, office: {}, account currency: {}, payment currency: {}.";
		final String MESSAGE_ACCOUNT_WAS_NOT_FOUND = "Account wasn't found using identifiers data, (SWIFT_ID table).";
		final String MESSAGE_LEGAL_SEND_REC_IDCODE_BUT_NO_VALUE = "MOP {} holds SEND_REC_IDCODE {}, but related field, (OX_INSTD_AGT_BIC_2AND or OX_INSTD_AGT_ID_2AND), does not hold any value; account derivation will fail...";
		final String MESSAGE_INVALID_SEND_REC_IDCODE = "MOP {} holds null/empty SEND_REC_IDCODE column; account derivation will fail...";
		final String MESSAGE_OUTPUT = "Method results - Successful account derivation: {}, Continue: {}, Account/Office/Currency: {}, {}, {}.";

		final String SEND_REC_IDCODE_SA = "SA";

		final String CREDIT = "credit";
		final String DEBIT = "debit";

		boolean bSuccessfulAccountDerivation = false;
		String sAccountNumber = null, sOffice = null, sCurrency = null;
		String sDerivationSide = isCreditAcctDerivation ? CREDIT : DEBIT;

		PDO pdo = Admin.getContextPDO();

		MsgClassType msgClassType = MessageUtils.getMsgClassType(pdo);
		String mopName = pdo.getString(msgClassType.getSourceMopLogicalField());
		String sOX_CLR_SYS_ID = pdo.getString(OX_CLR_SYS_ID);
		String messageType = pdo.getString(P_MSG_TYPE);
		logger.info(MESSAGE_SRC_MOP_AND_ORIG_CLR_SYS_ID, mopName, sOX_CLR_SYS_ID);

		sOffice = pdo.getString(P_OFFICE);
		Mop mop = CacheKeys.mopKey.getSingle(sOffice, mopName);
		boolean bSettAccExists = mop != null && mop.getSettAccExists();

		// Guy Segev 17/11 - Temp fix for interoffice functionality
		//final String sInterOfficeFinCopy = "XXX";

		if (MESSAGE_TYPE_SWIFT_298_011.equals(messageType) || MESSAGE_TYPE_SWIFT_298_012.equals(messageType)) {// no need to derive for those message
																												// types
			return bSuccessfulAccountDerivation;
		}

		// The only mandatory condition for account derivation is that the MOP settlement account exists,
		// Otherwise we should fall due to wrong setup.  (Yoni S. Shay A. 01/09/13)
		boolean shouldPerformDerivation = bSettAccExists;

		logger.info(shouldPerformDerivation ? MESSAGE_WILL_PERFORM_DERIVATION : MESSAGE_WILL_NOT_PERFORM_DERIVATION,mopName);
		
		if (shouldPerformDerivation)

		{
			String sSendRecIdcode = mop.getSendRecIdcode();
			logger.info(MESSAGE_SEND_REC_IDCODE, mopName, sSendRecIdcode);

			// Valid SEND_REC_IDCODE.
			if (!isNullOrEmpty(sSendRecIdcode)) {
				String sSWIFT_IDLookUpValue = null;
				boolean isSendRecIDcodeSA = SEND_REC_IDCODE_SA.equals(sSendRecIdcode);

				// in case of G3 mop, the SA value should be taken from X_INSTD_AGT_ID_2AND
				// since it is being mapped in all G3 flows in R&E rules	 (Liat M. , Yoni S. , Shay A. 01/09/13)
				if (isSendRecIDcodeSA) {
					sSWIFT_IDLookUpValue = pdo.getString(OX_INSTD_AGT_BIC_2AND);
					if (GlobalUtils.isNullOrEmpty(sSWIFT_IDLookUpValue)) sSWIFT_IDLookUpValue = pdo.getString(X_INSTD_AGT_BIC_2AND);
				} else {
					// NCC member ID.
					sSWIFT_IDLookUpValue = pdo.getString(OC_INSTD_AGT_ID);
				}
				
				logger.info(MESSAGE_SWIFTID_RETRIEVED,sSWIFT_IDLookUpValue);
				if (!isNullOrEmpty(sSWIFT_IDLookUpValue)) {
					logger.info(MESSAGE_SWIFTID_LOOKUP_DETAILS, mopName, sSWIFT_IDLookUpValue);

					SwiftId swiftId = CacheKeys.swiftIdPerMOPandOfficeKey.getSingle(sOffice, mopName, sSWIFT_IDLookUpValue);
					// If initial lookup was according to BIC and BIC length is 8 and no SwiftId object was found, then
					// searches again while concatenating 'XXX' to the BIC.
					if (swiftId == null && isSendRecIDcodeSA && sSWIFT_IDLookUpValue.length() == 8) {
						String sExtendedBIC = sSWIFT_IDLookUpValue + "XXX";
						logger.info(MESSAGE_SWIFTID_LOOKUP_DETAILS_2ND_TIME, mopName, sExtendedBIC);
						swiftId = CacheKeys.swiftIdPerMOPandOfficeKey.getSingle(sOffice, mopName, sExtendedBIC);
					}

					if (swiftId != null) {
						sAccountNumber = swiftId.getAccNo();
						sCurrency = swiftId.getCurrency();

						// Tries to load the account using the account number, office & currency.
						Accounts accounts = CacheKeys.accountsKey.getSingle(sAccountNumber, sCurrency, sOffice);

						// Found valid account.
						if (accounts != null) {
							String sInstCurrency = pdo.getString(OX_STTLM_CCY) != null ? pdo.getString(OX_STTLM_CCY) : pdo.getString(X_STMT_BAL, 0, X_STMT_BAL_CCY);
							Long lAllowConversion;

							if (toleranceCurrecny) {
								lAllowConversion = new Long(1);
							} else {
								lAllowConversion = isCreditAcctDerivation ? accounts.getCreditConversion() : accounts.getDebitConversion();
							}

							// Assures that:
							// 1) The account currency equals the payment currency.
							// OR 2) The account currency doesn't equal the payment currency but the account allows conversion.
							if (sInstCurrency.equals(sCurrency) || (!sInstCurrency.equals(sCurrency) && lAllowConversion.intValue() != 0)) {
								logger.info(MESSAGE_ACCOUNT_WAS_FOUND);
								updatePDOWithAccountData(accounts, isCreditAcctDerivation);
								bSuccessfulAccountDerivation = true;
							}

							// Failure.
							// Error code 40147: 'Failed to derive account number from debit MOP |1 and Instructed agent BIC |2;
							// found account's currency doesn't equal the payment currency and account doesn't allow debit conversion: account number
							// |3, office |4 and currency |5'.
							else {
								logger.info(MESSAGE_ACCOUNT_WAS_FOUND_BUT_WITH_DIFF_CURR_AND_NO_CONVERSION_ALLOWED, new Object[] { sAccountNumber, sOffice, sCurrency,
										sInstCurrency });
								arrProcessErrorData[0] = ProcessErrorConstants.AccountDerivationFailureAccountDerivedFromDebitMOPWithDiffCurrAndAndNotAllowsConversion;
								arrProcessErrorData[1] = new Object[] { mopName, sSWIFT_IDLookUpValue, sAccountNumber, sOffice, sCurrency };
							}
						}

						// Failure.
						// Error code 40114: 'Failed to derive account number from debit MOP |1 and Instructed agent BIC |2;
						// account object wasn't found for account number |3, office |4 and currency |5'.
						else {
							arrProcessErrorData[0] = ProcessErrorConstants.AccountDerivationFailureNoAccountObjectForDebitMOPandInstdAgentBIC;
							arrProcessErrorData[1] = new Object[] { mopName, sSWIFT_IDLookUpValue, sAccountNumber, sOffice, sCurrency };
						}

						// In any case, (valid or invalid account), notifies the caller method not to continue.
						arrContinue[0] = false;
					}

					// Notify the caller method not to continue.
					else {
						logger.info(MESSAGE_ACCOUNT_WAS_NOT_FOUND);

						// Failure.
						// Error code 40115: 'Failed to derive account number; identifier object, (SWIFT_ID), wasn't found for debit MOP |1 and
						// Instructed agent BIC |2'.
						arrProcessErrorData[0] = ProcessErrorConstants.AccountDerivationFailureNoIdentifierObjectForDebitMOPandInstdAgentBIC;
						arrProcessErrorData[1] = new Object[] { mopName, sSWIFT_IDLookUpValue };

						arrContinue[0] = false;
					}
				}

				// Null 'sSWIFT_IDLookUpValue'.
				else {
					logger.info(MESSAGE_LEGAL_SEND_REC_IDCODE_BUT_NO_VALUE, mopName, sSendRecIdcode);

					// Error code 28353: 'Failed to derive account number; for |1 MOP |2 sender ID is |3 but value of |4 is null'.
					arrProcessErrorData[0] = ProcessErrorConstants.AccountDerivationFailureNullValueInPDOForMOPAndSenderID;
					arrProcessErrorData[1] = new Object[] { sDerivationSide, mopName, sSendRecIdcode,
							(isSendRecIDcodeSA && !mop.getImmediate()) ? OX_INSTD_AGT_BIC_2AND : OC_INSTD_AGT_ID };

					arrContinue[0] = false;
				}
			}

			// Null/empty SEND_REC_IDCODE column.
			else {
				logger.info(MESSAGE_INVALID_SEND_REC_IDCODE, mopName);
				arrContinue[0] = false;
			}
		}

		logger.info(MESSAGE_OUTPUT, new Object[] { bSuccessfulAccountDerivation, arrContinue[0], sAccountNumber, sOffice, sCurrency });

		return bSuccessfulAccountDerivation;
	}

	/**
   * 
   */
	public static boolean isCreditIndicatorForDebitField53B_54B_55B() {
		final String TRACE_CREDIT_DEBIT_INDICATOR = "D_1ST_IN_DBT_CHA_ACCNUM_FLD_ID: {}, Debit/Credit indicator, (relevant only if 'D_1ST_IN_DBT_CHA_ACCNUM_FLD_ID' is X_STTLM_ACCT_ID, X_INSTD_RMB_AGT_ACCT_ID_2AND or X_THRD_RMB_AGT_ACCT_ID_2AND): {}.";
		final String TRACE_METHOD_OUTPUT = "Method result: {}.";

		PDO pdo = Admin.getContextPDO();

		String sD_1ST_IN_DBT_CHA_ACCNUM_FLD_ID = pdo.getString(D_1ST_IN_DBT_CHA_ACCNUM_FLD_ID);

		String sDebitCreditIndicator = null;
		if (X_STTLM_ACCT_ID.equals(sD_1ST_IN_DBT_CHA_ACCNUM_FLD_ID))
			sDebitCreditIndicator = pdo.getString(X_INSTG_RMB_AGT_ACCT_DB_CD_IND); // Field 53.
		else if (X_INSTD_RMB_AGT_ACCT_ID_2AND.equals(sD_1ST_IN_DBT_CHA_ACCNUM_FLD_ID))
			sDebitCreditIndicator = pdo.getString(X_INSTD_RMB_AGT_ACCT_DB_CD_IND); // Field 54.
		else if (X_THRD_RMB_AGT_ACCT_ID_2AND.equals(sD_1ST_IN_DBT_CHA_ACCNUM_FLD_ID))
			sDebitCreditIndicator = pdo.getString(X_THRD_RMB_AGT_ACCT_DB_CD_IND); // Field 55.

		logger.info(TRACE_CREDIT_DEBIT_INDICATOR, sD_1ST_IN_DBT_CHA_ACCNUM_FLD_ID, sDebitCreditIndicator);

		// This boolean determines what account is going to be debited; in case field 53B/54B/55B was sent with a 'C' notation, (e.g.
		// :53B:/C/20531613000),
		// then it means that the sender bank defines this account, which means that in ACCOUNTS table it will be kept in ACC_ALIAS column,
		// and according to that the account lookup should be performed.
		// This account won't be kept in the reciever ACCOUNTS table in column ACC_NO.
		//
		// True - account was found in field 53B/54B/55B with CREDIT indicator, (e.g. :53B:/C/20531613000); need to look for the account
		// using ACCOUNTS.ACC_ALIAS.
		// False - either account was found in field 53B/54B/55B with DEBIT indicator or no indicator was sent at all; in both cases
		// need to look for the account using ACCOUNTS.ACC_NO.
		boolean bField53B_54B_55B_CreditIndicator = (X_STTLM_ACCT_ID.equals(sD_1ST_IN_DBT_CHA_ACCNUM_FLD_ID)
				|| X_INSTD_RMB_AGT_ACCT_ID_2AND.equals(sD_1ST_IN_DBT_CHA_ACCNUM_FLD_ID) || X_THRD_RMB_AGT_ACCT_ID_2AND.equals(sD_1ST_IN_DBT_CHA_ACCNUM_FLD_ID))
				&& CREDIT_INDICATOR.equals(sDebitCreditIndicator);
		logger.info(TRACE_METHOD_OUTPUT, bField53B_54B_55B_CreditIndicator);

		return bField53B_54B_55B_CreditIndicator;
	}

	/**
	 * Derives the account using the account quoted in the payment, if such one was indeed quoted; if not, the derivation process will continue using
	 * the customer data that was set into the PDO in an earlier process.
	 */
	private boolean deriveAccountFromAccountQuotedInPayment(boolean bCreditAccountDerivation, String sAccountQuotedInPayment, Object[] arrProcessErrorData) {
		final String MESSAGE_ACCOUNT_WAS_NOT_FOUND_USING_CURR_AND_OFFICE = "Account wasn't found using currency & office; tries loading it using only office.";
		// final String MESSAGE_ACCOUNT_WAS_NOT_FOUND_USING_OFFICE =
		// "Account wasn't found using only office; continues to account lookup rule execution.";
		final String MESSAGE_SINGLE_ACCOUNT_WAS_FOUND_WITH_ALLOW_CONVERSION_VALUE = "Single account was found - allow conversion value: {}.";
		final String MESSAGE_MULTIPLE_ACCOUNTS_WERE_FOUND = "Multiple accounts were found; calls 'getPreferredAccount'.";

		boolean bSuccessfulAccountDerivation = true;

		PDO pdo = Admin.getContextPDO();

		Accounts accounts = null;

		String sPaymentOffice = pdo.getString(P_OFFICE);
		String sInstCurrency = pdo.getString(OX_STTLM_CCY);

		// True - account was found in field 53B/54B/55B with CREDIT indicator, (e.g. :53B:/C/20531613000); need to look for the account
		// using ACCOUNTS.ACC_ALIAS.
		// False - either account was found in field 53B/54B/55B with DEBIT indicator or no indicator was sent at all; in both cases
		// need to look for the account using ACCOUNTS.ACC_NO.
		boolean bField53B_54B_55B_CreditIndicator = isCreditIndicatorForDebitField53B_54B_55B();

		// Lookup using ACCOUNTS.ACC_ALIAS.
		if (bField53B_54B_55B_CreditIndicator) {
			accounts = getAccountUsingAccAlias(sAccountQuotedInPayment, sPaymentOffice, sInstCurrency, null);
		}

		// Lookup using ACCOUNTS.ACC_NO.
		else {
			// Gets all accounts in the database with this account number and office.
			List<Accounts> listAccounts = CacheKeys.accountsAllCurrenciesKey.get(sAccountQuotedInPayment, sPaymentOffice);
			boolean bAccountExistsInDatabase = !isListNullOrEmpty(listAccounts);

			// Account exists in the database.
			if (bAccountExistsInDatabase) {
				// Tries to load the account using the quoted account number, office & currency.
				accounts = CacheKeys.accountsKey.getSingle(sAccountQuotedInPayment, sInstCurrency, sPaymentOffice);
				//
				// No specific account entry was found; tries to derive the account from the list of accounts which was fetched
				// earlier using only the office, and which is surely a VALID one.
				if (accounts == null) {
					logger.info(MESSAGE_ACCOUNT_WAS_NOT_FOUND_USING_CURR_AND_OFFICE);

					int iNumOfAccounts = listAccounts.size();

					// Single account.
					// This account's currency is SURELY different then the instruction currency !
					// Need to check if the account allows conversion.
					if (iNumOfAccounts == 1) {
						accounts = listAccounts.get(0);

						Long lAllowConversion = bCreditAccountDerivation ? accounts.getCreditConversion() : accounts.getDebitConversion();

						logger.info(MESSAGE_SINGLE_ACCOUNT_WAS_FOUND_WITH_ALLOW_CONVERSION_VALUE, lAllowConversion.intValue());

						// In case this single account DOESN'T allow conversion, it can't be used as the derived account.
						if (lAllowConversion.intValue() == 0) {
							// Error code 40123: 'Failed to derive account number; for account quoted in payment |1, single account was found
							// but it doesn't allow conversion: account |2, office |3 and currency |4'.
							arrProcessErrorData[0] = ProcessErrorConstants.AccountDerivationFailureForAccountQuotedInPaymentSingleAccWasFoundAndNotAllowsConversion;
							arrProcessErrorData[1] = new Object[] { sAccountQuotedInPayment, sAccountQuotedInPayment, accounts.getOffice(), accounts.getCurrency() };

							accounts = null;
						}
					}

					// More then one account; looks for the preferred one, where the returned value might be null; see there.
					else {
						logger.info(MESSAGE_MULTIPLE_ACCOUNTS_WERE_FOUND);
						accounts = getPreferredAccount(listAccounts, bCreditAccountDerivation, true, arrProcessErrorData, sAccountQuotedInPayment, null, sInstCurrency, 0, null);
					}
				}
			}

			// In case:
			// 1) No account was found yet
			// AND 2) We're in debit side
			// AND 3) The source of the account number is either field 53, ('Instructing Reimbursement Agent') or field 54, ('Instructed Reimbursement
			// Agent')
			// , then tries to get the account using the account alias.
			// Gets the field name of the first in chain debit account number.
			String sD_1ST_IN_DBT_CHA_ACCNUM_FLD_ID = pdo.getString(D_1ST_IN_DBT_CHA_ACCNUM_FLD_ID);
			if (accounts == null && !bCreditAccountDerivation && (X_STTLM_ACCT_ID.equals(sD_1ST_IN_DBT_CHA_ACCNUM_FLD_ID) /* 53 */
					|| X_INSTG_RMB_AGT_ACCT_ID_2AND.equals(sD_1ST_IN_DBT_CHA_ACCNUM_FLD_ID) /* 53 */
			|| X_INSTD_RMB_AGT_ACCT_ID_2AND.equals(sD_1ST_IN_DBT_CHA_ACCNUM_FLD_ID) /* 54 */)) {
				logger.info("Debit side, no account was found and D_1ST_IN_DBT_CHA_ACCNUM_FLD_ID is {}. Looks for the account using ACCOUNTS.ACC_ALIAS",
						sD_1ST_IN_DBT_CHA_ACCNUM_FLD_ID);
				accounts = BOAccountDerivation.getAccountUsingAccAlias(sAccountQuotedInPayment, sPaymentOffice, sInstCurrency, null);

				// Tries getting the account without using the currency.
				if (accounts == null) {
					accounts = BOAccountDerivation.getAccountUsingAccAlias(sAccountQuotedInPayment, sPaymentOffice, null, null);
				}

				// Account was found;
				// Updates the related D field to hold the actual account number.
				if (accounts != null) {
					String sNewAccountNumber = accounts.getAccNo();

					// Updates the related D field for rest of the process.
					logger.info("Modifies D_FIRST_IN_DBT_CHAIN_ACC_NUM to {}, (the actual account number of the asset account number in ACC_ALIAS {}).", sNewAccountNumber,
							sAccountQuotedInPayment);
					pdo.set(D_FIRST_IN_DBT_CHAIN_ACC_NUM, sNewAccountNumber);
				}
			}

		}
		// Found a valid account, where it could be:
		// 1) An account with the SAME currency as the instruction currency.
		// OR 2) An account with a DIFFERENT currency then the instruction currency.
		if (accounts != null) {
			updatePDOWithAccountData(accounts, bCreditAccountDerivation);
		}

		else {
			bSuccessfulAccountDerivation = false;
		}

		return bSuccessfulAccountDerivation;
	}

	/**
	 * Gets a list of Accounts objects and returns the prefered one from that list; In case no prefered account was found or in case we have more then
	 * one preferred account, returned value is null.
	 * 
	 * @param bCheckAllowConversion true - the 'allow conversion' property matters and needs to be checked. false - no need for checking the 'allow
	 * conversion' property since the passed list of accounts are already in the instruction currency.
	 * @param arrProcessErrorData will hold process error data in case no preferred account is found.
	 * @param sAccountNumber will hold a value when this method is called from the 'deriveAccountFromAccountQuotedInPayment' method; required for
	 * possible process error in case no preferred account is found.
	 * @param sCustCode will hold a valid value when this method is called from the 'deriveAccountFromCustomerData' method; required for possible
	 * process error in case no preferred account is found.
	 * @param sInstCurrency will hold a valid value when this method is called from the 'deriveAccountFromAccountQuotedInPayment' and
	 * 'deriveAccountFromCustomerData' methods; required for possible process error in case no preferred account is found.
	 * @param iField53_54_55_Indicator optional values: 0 - Not relevant for rest of process. 1 - Indicator is 'C'. 2 - Indicator is 'D'.
	 * @param sIndicatorRelatedField optional values: 53B/54B/55B.
	 **/
	private Accounts getPreferredAccount(List<Accounts> listAccounts, boolean bCreditAccountDerivation, boolean bCheckAllowConversion, Object[] arrProcessErrorData,
			String sAccountNumber, String sCustCode, String sInstCurrency, int iField53_54_55_Indicator, String sIndicatorRelatedField) {
		final String INPUT_CHECK_ALLOW_CONVERSION = "bCheckAllowConversion: {}.";
		final String MESSAGE_CURRENT_ACCOUNT_DETAILS = "Current account: {}, Currency: {}, Preferred: {}, Allows conversion: {}, Asset flag: {}.";
		final String MESSAGE_FOUND_FIRST_PREFERRED_ACCOUNT = "Found first preferred account: {}.";
		final String MESSAGE_MORE_THEN_ONE_PREFERRED_ACCOUNT_THAT_ALLOWS_CONVERSION = "Illegal setup: more then one preferred account that allows conversion !";
		final String MESSAGE_FOUND_FIRST_ASSET_OR_NON_ASSET_ACCOUNT = "Found first {} account: {}. Preferred: {}.";

		final String MESSAGE_NON_PREFERRED_ACCOUNT_REPLACED_BY_PREFERRED_ONE = "Found preferred {} account {}; replaces previous found {} account {}, which is not set as prefrred.";
		final String MESSAGE_TWO_NON_PREFERRED_ACCOUNTS_WERE_FOUND = "Previous found {} account {} is not set as preferred and current found {} account {} is not set as preferred; sets 'preferredAccount' to null and continues the loop.";

		final String ASSET = "asset";
		final String NON_ASSET = "non-asset";

		logger.info(INPUT_CHECK_ALLOW_CONVERSION, bCheckAllowConversion);

		Accounts preferredAccount = null;

		// NOTE: A preferred account is an account that:
		// 1) If 'iField53_54_55_Indicator' is 0, a preferred account is one that is marked as preferred AND THAT ALSO allows conversion !!!
		// 2) If 'iField53_54_55_Indicator' isn't 0, a preferred account is one that is an asset account, (in case 'iField53_54_55_Indicator' is 1),
		// or a non-asset account, (in case 'iField53_54_55_Indicator' is 2).
		// In addition, the account should also allow conversion.
		// In case more then one account was found, then the preferred account, (that fills all above conditions), will be selected.
		boolean bAlreadyFoundOnePreferredAccount = false;

		boolean bMoreThenOnePreferredAccount = false;
		boolean bContinue = true;

		int iSize = listAccounts.size();
		for (int i = 0; i < iSize && bContinue; i++) {
			Accounts accounts = listAccounts.get(i);

			Long lPreferredAccount = accounts.getPreferredacc();
			lPreferredAccount = lPreferredAccount != null ? lPreferredAccount : ServerConstants.ZERO_LONG;

			Long lAsset = accounts.getAsset();
			lAsset = lAsset != null ? lAsset : ServerConstants.ZERO_LONG;

			// This boolean default value is set to true and it will be set to true/false according to the 'allow conversion' flag of the dealt
			// account only if the caller method has requested to check it, (the 'bCheckAllowConversion' parameter).
			boolean bAccountAllowsConversion = true;
			//
			if (bCheckAllowConversion) {
				Long lAllowConversion = bCreditAccountDerivation ? accounts.getCreditConversion() : accounts.getDebitConversion();
				bAccountAllowsConversion = lAllowConversion.intValue() != 0;
			}

			logger.info(MESSAGE_CURRENT_ACCOUNT_DETAILS,
					new Object[] { accounts.getAccNo(), accounts.getCurrency(), lPreferredAccount.intValue(), bAccountAllowsConversion, lAsset });

			// No credit/debit indicator.
			if (iField53_54_55_Indicator == 0) {
				// Sets the returned Accounts object to be the current one from the listonly if this is a preferred account that allows conversion.
				if (lPreferredAccount.intValue() != 0 && bAccountAllowsConversion) {
					// This is the first found preferred account.
					if (!bAlreadyFoundOnePreferredAccount) {
						logger.info(MESSAGE_FOUND_FIRST_PREFERRED_ACCOUNT, accounts.getAccNo());
						preferredAccount = accounts;
						bAlreadyFoundOnePreferredAccount = true;
					}
					//
					// We already found a preferred account; this is the second one found and that's illegal.
					// Gets out of the loop and sets returned value to null for the caller method.
					else {
						logger.info(MESSAGE_MORE_THEN_ONE_PREFERRED_ACCOUNT_THAT_ALLOWS_CONVERSION);
						preferredAccount = null;

						bContinue = false;
						bMoreThenOnePreferredAccount = true;
					}
				}
			}

			// Credit/Debit indicator exists.
			else {
				// Sets the returned Accounts object to be the current one from the list that is an asset or non asset according to the
				// 'iField53_54_55_Indicator' value.
				// This account is also considered as the preferred account.
				if (((iField53_54_55_Indicator == 1 && lAsset != 0) || (iField53_54_55_Indicator == 2 && lAsset == 0)) && bAccountAllowsConversion) {
					String sAssetNonAsset = iField53_54_55_Indicator == 1 ? ASSET : NON_ASSET;

					// This is the first found account.
					if (!bAlreadyFoundOnePreferredAccount) {
						logger.info(MESSAGE_FOUND_FIRST_ASSET_OR_NON_ASSET_ACCOUNT, new Object[] { sAssetNonAsset, accounts.getAccNo(), lPreferredAccount });
						preferredAccount = accounts;
						bAlreadyFoundOnePreferredAccount = true;
					}
					//
					// Found a second asset or non-asset account; needs to check who's the preferred between the two, where:
					// 1) If first found account is not preferred account and second one is preferred, then sets
					// the second one to be the preferred account for rest of the loop.
					// 2) If first found account is not preferred and second one is not preferred as well, then none of them can be
					// set as the selected account, (as none of them are preferred); loop will continue to search for a preferred account.
					// 3) If first found account is preferred and second one is preferred as well then this is an illegal setup;
					// gets out of the loop and sets returned value to null for the caller method.
					else {
						// Stands for whether the first account that was found is a preferred one or not.
						Long lFirstAccountPreferred = preferredAccount.getPreferredacc();
						lFirstAccountPreferred = lFirstAccountPreferred != null ? lFirstAccountPreferred : ServerConstants.ZERO_LONG;

						// First found account is not preferred account and second one is preferred; sets the second one to be 'preferredAccount'.
						if (lFirstAccountPreferred == 0 && lPreferredAccount != 0) {
							logger.info(MESSAGE_NON_PREFERRED_ACCOUNT_REPLACED_BY_PREFERRED_ONE, new Object[] { sAssetNonAsset, accounts.getAccNo(), sAssetNonAsset,
									preferredAccount.getAccNo() });
							preferredAccount = accounts;
						}

						// Previous found account is not preferred and second one is not preferred as well.
						// Sets 'preferredAccount' to null, as between the 2 accounts, at least one should be preferred.
						// The loop continues and if an additional account will be found that is a preferred one, then this will be the selected one.
						else if (lFirstAccountPreferred == 0 && lPreferredAccount == 0) {
							logger.info(MESSAGE_TWO_NON_PREFERRED_ACCOUNTS_WERE_FOUND,
									new Object[] { sAssetNonAsset, preferredAccount.getAccNo(), sAssetNonAsset, accounts.getAccNo() });
							preferredAccount = null;
							bAlreadyFoundOnePreferredAccount = false;
						}

						// Previous found account is preferred and current account is preferred as well.
						// This is an illegal setup; gets out of the loop and sets returned value to null for the caller method.
						else if (lFirstAccountPreferred != 0 && lPreferredAccount != 0) {
							logger.info(MESSAGE_MORE_THEN_ONE_PREFERRED_ACCOUNT_THAT_ALLOWS_CONVERSION);
							preferredAccount = null;
							bContinue = false;
							bMoreThenOnePreferredAccount = true;
						}
					}
				}
			}
		}

		// Failure, we need to initialize a process error message & no such one was initialized yet.
		if (preferredAccount == null && arrProcessErrorData != null && arrProcessErrorData[0] == null) {
			// More then one preferred account that allows conversion was found.
			if (bMoreThenOnePreferredAccount) {
				// Call was made from the 'deriveAccountFromCustomerData' method.
				if (!isNullOrEmpty(sCustCode)) {
					// Error code 40117: 'Failed to derive account number; more then one preferred account that allows conversion was found for
					// customer code |1 and currency |2'.
					if (sInstCurrency != null) {
						arrProcessErrorData[0] = ProcessErrorConstants.AccountDerivationFailureMoreThenOnePreferredAccountForCustomerCodeAndCurrency;
						arrProcessErrorData[1] = new Object[] { sCustCode, sInstCurrency };
					}

					// Error code 40118: 'Failed to derive account number; more then one preferred account that allows conversion was found for
					// customer code |1'.
					else {
						arrProcessErrorData[0] = ProcessErrorConstants.AccountDerivationFailureMoreThenOnePreferredAccountForCustomerCode;
						arrProcessErrorData[1] = new Object[] { sCustCode };
					}
				}
			}

			else {
				// Method was called from the 'deriveAccountFromAccountQuotedInPayment' method.
				if (!isNullOrEmpty(sAccountNumber)) {
					// Preferred account was found but it doesn't allow conversion.
					if (bAlreadyFoundOnePreferredAccount) {
						// Error code 40124: 'Failed to derive account number; for account quoted in payment |1, multiple accounts were found but none
						// of them allows conversion'.
						arrProcessErrorData[0] = ProcessErrorConstants.AccountDerivationFailureForAccountQuotedInPaymentMultipleAccountsFoundAndNoneAllowsConversion;
					}

					else {
						// Error code 40125: 'Failed to derive account number; for account quoted in payment |1, multiple accounts were found but none
						// of them is preferred'.
						arrProcessErrorData[0] = ProcessErrorConstants.AccountDerivationFailureForAccountQuotedInPaymentMultipleAccountsFoundAndNoneIsPreferred;
					}
					arrProcessErrorData[1] = new Object[] { sAccountNumber };
				}

				// Method was called from the 'deriveAccountFromCustomerData' method.
				else {
					// Preferred account was found but it doesn't allow conversion.
					if (bAlreadyFoundOnePreferredAccount) {
						// Error code 40119: 'Failed to derive account number; for customer code |1 and currency |2, multiple accounts were found but
						// none of them allows conversion'.
						if (sInstCurrency != null) {
							arrProcessErrorData[0] = ProcessErrorConstants.AccountDerivationFailureMultipleAccountsFoundForCustomerCodeAndCurrencyAndNoneAllowsConversion;
							arrProcessErrorData[1] = new Object[] { sCustCode, sInstCurrency };
						}

						// Error code 40120: 'Failed to derive account number; for customer code |1, multiple accounts were found but none of them
						// allows conversion'.
						else {
							arrProcessErrorData[0] = ProcessErrorConstants.AccountDerivationFailureMultipleAccountsFoundForCustomerCodeAndNoneAllowsConversion;
							arrProcessErrorData[1] = new Object[] { sCustCode };
						}
					}

					// Preferred account WASN'T found.
					else {
						// Error code 40121: 'Failed to derive account number; for customer code |1 and currency |2, multiple accounts were found but
						// none of them is preferred'.
						if (sInstCurrency != null) {
							arrProcessErrorData[0] = ProcessErrorConstants.AccountDerivationFailureMultipleAccountsFoundForCustomerCodeAndCurrencyAndNoneIsPreferred;
							arrProcessErrorData[1] = new Object[] { sCustCode, sInstCurrency };
						}

						// Error code 40122: 'Failed to derive account number; for customer code |1, multiple accounts were found but none of them is
						// preferred'.
						else {
							arrProcessErrorData[0] = ProcessErrorConstants.AccountDerivationFailureMultipleAccountsFoundForCustomerCodeAndNoneIsPreferred;
							arrProcessErrorData[1] = new Object[] { sCustCode };
						}
					}
				}
			}
		}

		return preferredAccount;
	}

	/**
	 * Derives the account from the customer data which was set into the PDO in an earlier step, ('load customer' step).
	 */
	private boolean deriveAccountFromCustomerData(boolean bCreditAccountDerivation, Object[] arrProcessErrorData) {
		final String CREDIT_DEBIT_INDICATOR_RELATED_DATA = "D_1ST_IN_DBT_CHA_BIC_FLD_ID: {}, X_INSTG_RMB_AGT_ACCT_DB_CD_IND (53B debit/credit indicator): {}, X_INSTD_RMB_AGT_ACCT_DB_CD_IND (54B debit/credit indicator): {}, X_THRD_RMB_AGT_ACCT_DB_CD_IND (55B debit/credit indicator): {}, 'iField53_54_55_Indicator' value for rest of the process: {}.";
		final String MESSAGE_TRIES_LOADING_ACCOUNT_USING_CUST_CODE_AND_CURRENCY = "Tries loading the account using cust code {} and currency {}.";
		final String MESSAGE_SINGLE_ACCOUNT_WAS_FOUND = "Single account was found: {}.";
		final String MESSAGE_MULTIPLE_ACCOUNTS_WERE_FOUND = "Multiple accounts - {} - were found; calls 'getPreferredAccount'.";
		final String MESSAGE_TRIES_LOADING_ACCOUNT_USING_ONLY_CUST_CODE = "No account was found using cust code {} and currency {}; tries loading the account using only cust code {}.";
		final String MESSAGE_FOUND_SINGLE_ACCOUNT = "Found single account: {}, Allows conversion: {}.";

		final String FIELD_53B = "53B";
		final String FIELD_54B = "54B";
		final String FIELD_55B = "55B";

		boolean bSuccessfulAccountDerivation = true;
		PDO pdo = Admin.getContextPDO();

		Accounts accounts = null;

		String sD_1ST_IN_DBT_CHA_BIC_FLD_ID = null;

		// Optional values are:
		// 0 - Not relevant for rest of process.
		// 1 - Indicator is 'C'.
		// 2 - Indicator is 'D'.
		int iField53_54_55_Indicator = 0;

		String sIndicatorRelatedField = null;

		// In case of debit account derivation, then if:
		// 1) The first in chain BIC field was 'X_INSTG_AGT_BIC_2AND', (i.e. Instructing Agent)
		// AND 2) Field 53B/54B/55B has arrived with debit or credit indicator, (e.g. ':53B:/C' or ':53B:/D')
		// , then the selected account should be as follows:
		// 1) If field 53B/54B/55B indicator is C, then account should be an ASSET account. If there is more then one account for this customer, then
		// the preferred one should be an ASSET one, and if such one was not found then an error will be raised.
		// 2) If field 53B/54B/55B indicator is D, then account should be a NON ASSET account. If there is more then one account for this customer,
		// then
		// the preferred one should be a NON ASSET one, and if such one was not found then an error will be raised.
		//
		// Note that if the above 2 conditions are fulfilled then field 53B/54B/55B, for sure, doesn't have an account number that follows it,
		// , (i.e. as above and as oppossed to, for example, ':53B:/C/20531613000'), otherwise the first in chain BIC couldn't have been
		// 'X_INSTG_AGT_BIC_2AND', (see logic of find 1st in debit chain in 'BOFindFirstInChain.findFirstInDebitChain' method).
		if (!bCreditAccountDerivation) {
			sD_1ST_IN_DBT_CHA_BIC_FLD_ID = pdo.getString(D_1ST_IN_DBT_CHA_BIC_FLD_ID);

			String sField53_DebitCreditIndicator = pdo.getString(X_INSTG_RMB_AGT_ACCT_DB_CD_IND); // Field 53.
			String sField54_DebitCreditIndicator = pdo.getString(X_INSTD_RMB_AGT_ACCT_DB_CD_IND); // Field 54.
			String sField55_DebitCreditIndicator = pdo.getString(X_THRD_RMB_AGT_ACCT_DB_CD_IND); // Field 55.

			String sDebitCreditIndicator = null;

			// The indicator according to which we set the 'sDebitCreditIndicator' value is determined according to the order
			// of the debit chains starting from field 55 to field 53.
			// i.e. in case, the payment includes, for example, both field 54 indicator and field 53 indicator, the 54 one will be considered.
			if (!isNullOrEmpty(sField55_DebitCreditIndicator)) {
				sDebitCreditIndicator = sField55_DebitCreditIndicator;
				sIndicatorRelatedField = FIELD_55B;
			} else if (!isNullOrEmpty(sField54_DebitCreditIndicator)) {
				sDebitCreditIndicator = sField54_DebitCreditIndicator;
				sIndicatorRelatedField = FIELD_54B;
			} else if (!isNullOrEmpty(sField53_DebitCreditIndicator)) {
				sDebitCreditIndicator = sField53_DebitCreditIndicator;
				sIndicatorRelatedField = FIELD_53B;
			}

			if (X_INSTG_AGT_BIC_2AND.equals(sD_1ST_IN_DBT_CHA_BIC_FLD_ID)) {
				if (CREDIT_INDICATOR.equals(sDebitCreditIndicator))
					iField53_54_55_Indicator = 1;
				else if (DEBIT_INDICATOR.equals(sDebitCreditIndicator))
					iField53_54_55_Indicator = 2;
			}

			logger.info(CREDIT_DEBIT_INDICATOR_RELATED_DATA, new Object[] { sD_1ST_IN_DBT_CHA_BIC_FLD_ID, sField53_DebitCreditIndicator, sField54_DebitCreditIndicator,
					sField55_DebitCreditIndicator, iField53_54_55_Indicator });
		}

		// Note that if we arrived here, then the 'Customrs' object must be a valid one;
		// if there was no such one, then the process would have been stopped already
		// in the 'performAccountDerivation' method.
		Customrs customrs = bCreditAccountDerivation ? pdo.getNSetCREDIT_CUSTOMER() : pdo.getNSetDEBIT_CUSTOMER();

		String sCustCode = customrs.getCustCode();
		String sInstCurrency = pdo.getString(OX_STTLM_CCY);

		int iNumOfAccounts;

		logger.info(MESSAGE_TRIES_LOADING_ACCOUNT_USING_CUST_CODE_AND_CURRENCY, new Object[] { sCustCode, sInstCurrency });

		// STEP 1 -
		// Tries to load the account using the cust code & the currency.
		List<Accounts> listAccounts = CacheKeys.accountsPerCustCodeAndCurrencyKey.get(sCustCode, sInstCurrency);

		if (!isListNullOrEmpty(listAccounts)) {
			iNumOfAccounts = listAccounts.size();

			// Single account.
			if (iNumOfAccounts == 1) {
				accounts = listAccounts.get(0);
				logger.info(MESSAGE_SINGLE_ACCOUNT_WAS_FOUND, accounts.getAccNo());

				// Failure.
				// Asset/NonAsset account verification has failed; set related error.
				if (iField53_54_55_Indicator != 0 && !verifyAccountAsAssetOrNonAsset(accounts, iField53_54_55_Indicator)) {
					setErrorMessageForAssetNoAssetAccountVerificationFailure(accounts, iField53_54_55_Indicator, sIndicatorRelatedField, arrProcessErrorData);
					accounts = null;
				}
			}

			// More then one account; looks for the preferred one, where the returned value might be null; see there.
			else {
				logger.info(MESSAGE_MULTIPLE_ACCOUNTS_WERE_FOUND, iNumOfAccounts);

				// The 3rd parameter is the 'bCheckAllowConversion' which is sent as false,
				// since we're already in the right currency.
				accounts = getPreferredAccount(listAccounts, bCreditAccountDerivation, false, arrProcessErrorData, null, sCustCode, sInstCurrency, iField53_54_55_Indicator,
						sIndicatorRelatedField);
			}
		}

		// STEP 2 -
		// Tries to load the account using only the cust code.
		else {
			logger.info(MESSAGE_TRIES_LOADING_ACCOUNT_USING_ONLY_CUST_CODE, new Object[] { sCustCode, sInstCurrency, sCustCode });

			listAccounts = CacheKeys.accountsPerCustCodeAllCurrenciesKey.get(sCustCode);

			if (!isListNullOrEmpty(listAccounts)) {
				iNumOfAccounts = listAccounts.size();

				// Single account.
				if (iNumOfAccounts == 1) {
					Accounts singleFoundAccount = listAccounts.get(0);

					Long lAllowConversion = bCreditAccountDerivation ? singleFoundAccount.getCreditConversion() : singleFoundAccount.getDebitConversion();

					logger.info(MESSAGE_FOUND_SINGLE_ACCOUNT, singleFoundAccount.getAccNo(), lAllowConversion.intValue());

					// If the account allows conversion, sets it as the returned value.
					if (lAllowConversion.intValue() != 0) {
						accounts = listAccounts.get(0);

						// Failure.
						// Asset/NonAsset account verification has failed; set related error.
						if (iField53_54_55_Indicator != 0 && !verifyAccountAsAssetOrNonAsset(accounts, iField53_54_55_Indicator)) {
							setErrorMessageForAssetNoAssetAccountVerificationFailure(accounts, iField53_54_55_Indicator, sIndicatorRelatedField, arrProcessErrorData);
							accounts = null;
						}
					}

					else {
						Accounts tempAccounts = listAccounts.get(0);

						// Failure.
						// Error code 40116: 'Failed to derive account number; for customer code |1, single account was found but it doesn't allow
						// conversion: account |2, office |3 and currency |4'.
						arrProcessErrorData[0] = ProcessErrorConstants.AccountDerivationFailureSingleFoundAccountDoesNotAllowConversion;
						arrProcessErrorData[1] = new Object[] { sCustCode, tempAccounts.getAccNo(), tempAccounts.getOffice(), tempAccounts.getCurrency() };
					}
				}

				// More then one account; looks for the preferred one, where the returned
				// value might be null; see there.
				else {
					logger.info(MESSAGE_MULTIPLE_ACCOUNTS_WERE_FOUND, iNumOfAccounts);

					// The 3rd parameter is the 'bCheckAllowConversion' which is sent as false,
					// since we're already in the right currency.
					accounts = getPreferredAccount(listAccounts, bCreditAccountDerivation, true, arrProcessErrorData, null, sCustCode, null, iField53_54_55_Indicator,
							sIndicatorRelatedField);
				}
			}
		}

		// Found a valid account.
		if (accounts != null) {
			updatePDOWithAccountData(accounts, bCreditAccountDerivation);
		}
		//
		// No valid account; sets error into the PDO.
		// Error code '40041': Fail to derive account number.
		else {
			bSuccessfulAccountDerivation = false;
		}

		return bSuccessfulAccountDerivation;
	}

	/**
   * 
   */
	private void setErrorMessageForAssetNoAssetAccountVerificationFailure(Accounts accounts, int iField53Indicator, String sIndicatorRelatedField, Object[] arrProcessErrorData) {

		if (arrProcessErrorData != null && arrProcessErrorData[0] == null) {
			arrProcessErrorData[1] = new Object[] { accounts.getCustCode(), accounts.getAccNo(), sIndicatorRelatedField };

			// Error code 40251: 'Failed to derive account number; for customer code |1, single account |2 was found but field |3:/C exists and the
			// account is not an asset account'.
			if (iField53Indicator == 1) {
				arrProcessErrorData[0] = ProcessErrorConstants.AccountDerivationFailureSingleFoundAccountIsNotAnAssetAccount;
			}

			// Error code 40252: 'Failed to derive account number; for customer code |1, single account |2 was found but field |3:/D exists and the
			// account is not a non asset account'.
			else // iField53Indicator == 2
			{
				arrProcessErrorData[0] = ProcessErrorConstants.AccountDerivationFailureSingleFoundAccountIsNotANonAssetAccount;
			}

		}

	}

	/**
   * 
   */
	private boolean verifyAccountAsAssetOrNonAsset(Accounts accounts, int iField53_54_55_Indicator) {
		final String TRACE_METHOD_INPUT = "Method input - Account number: {}, Asset flag: {}, Field 53/54/55 indicator, (1 for 'C', 2 for 'D'): {}.";
		final String TRACE_METHOD_OUTPUT = "Method output - bValidAccount: {}.";

		boolean bValidAccount = true;

		String sAccountNumber = accounts.getAccNo();
		Long lAssetAccount = accounts.getAsset();
		logger.info(TRACE_METHOD_INPUT, sAccountNumber, new Object[] { lAssetAccount, iField53_54_55_Indicator });

		// Indicator is 'C', (e.g. ':53B:/C'); account must be an asset one.
		if (iField53_54_55_Indicator == 1)
			bValidAccount = lAssetAccount.intValue() != 0;

		// Indicator is 'D', (e.g. ':53B:/D'); account must be a non asset one.
		else if (iField53_54_55_Indicator == 2)
			bValidAccount = lAssetAccount.intValue() == 0;

		logger.info(TRACE_METHOD_OUTPUT, bValidAccount);

		return bValidAccount;
	}

	/**
	 * Sets the PDO object with the account data using the passed Accounts object.
	 */
	public static void updatePDOWithAccountData(Accounts accounts, boolean bCreditAccountDerivation) {
		final String TRACE_UPDATE_PDO_CREDIT_DATA = "MID: {}, setting P_CDT_ACCT_NB as {}, P_CDT_ACCT_OFFICE as {}, P_CDT_ACCT_CCY as {}.";
		final String TRACE_UPDATE_PDO_DEBIT_DATA = "MID: {}, setting P_DBT_ACCT_NB as {}, P_DBT_ACCT_OFFICE as {}, P_DBT_ACCT_CCY as {}.";

		PDO pdo = Admin.getContextPDO();

		String sAccountNumber = accounts.getAccNo();
		String sAccountOffice = accounts.getOffice();
		String sAccountCurrency = accounts.getCurrency();

		if (bCreditAccountDerivation) {
			logger.info(TRACE_UPDATE_PDO_CREDIT_DATA, new Object[] { pdo.getMID(), sAccountNumber, sAccountOffice, sAccountCurrency });

			pdo.setCREDIT_ACCOUNT(accounts);
			pdo.set(P_CDT_ACCT_NB, sAccountNumber);
			pdo.set(P_CDT_ACCT_OFFICE, sAccountOffice);
			pdo.set(P_CDT_ACCT_CCY, sAccountCurrency);
		} else // Debit.
		{
			logger.info(TRACE_UPDATE_PDO_DEBIT_DATA, new Object[] { pdo.getMID(), sAccountNumber, sAccountOffice, sAccountCurrency });

			pdo.setDEBIT_ACCOUNT(accounts);
			Accounts concentrationAccount = CacheKeys.accountsKey.getSingle(pdo.getDEBIT_ACCOUNT().getConcentrationAccNo(), pdo.getDEBIT_ACCOUNT().getConcentrationAccCcy(), pdo
					.getDEBIT_ACCOUNT().getConcentrationAccOffice());
			if (concentrationAccount != null) {
				pdo.setDEBIT_CNCNTRTN_ACCOUNT(concentrationAccount);
			}

			pdo.set(P_DBT_ACCT_NB, sAccountNumber);
			pdo.set(P_DBT_ACCT_OFFICE, sAccountOffice);
			pdo.set(P_DBT_ACCT_CCY, sAccountCurrency);
		}

	}

	public static void clearPDOAccountData(boolean bCreditAccountDerivation) {
		clearPDOAccountData(bCreditAccountDerivation, true);
	}

	/**
	 * @param includeRawData should also delete raw data (P_ fields) or only reference data which has been derived from the raw data (Usefull when raw
	 * data was manually enterer and not automatically detected)
	 */
	public static void clearPDOAccountData(boolean bCreditAccountDerivation, boolean includeRawData) {
		final String TRACE_UPDATE_PDO_CREDIT_DATA = "clearing credit account data MID: {}, setting P_CDT_ACCT_NB as null, P_CDT_ACCT_OFFICE as null, P_CDT_ACCT_CCY as null.";
		final String TRACE_UPDATE_PDO_DEBIT_DATA = "clearing debit account MID: {}, setting P_DBT_ACCT_NB as null, P_DBT_ACCT_OFFICE as null, P_DBT_ACCT_CCY as null.";
		final String TRACE_UPDATE_PDO_CREDIT_REFERNCE_DATA = "clearing credit account data MID: {}, setting CREDIT_ACCOUNT as null";
		final String TRACE_UPDATE_PDO_DEBIT_REFERNCE_DATA = "clearing debit account MID: {}, setting DEDIT_ACCOUNT as null";

		PDO pdo = Admin.getContextPDO();

		if (bCreditAccountDerivation) {

			if (includeRawData) {
				logger.info(TRACE_UPDATE_PDO_CREDIT_DATA);
				pdo.set(P_CDT_ACCT_NB, (String) null);
				pdo.set(P_CDT_ACCT_OFFICE, (String) null);
				pdo.set(P_CDT_ACCT_CCY, (String) null);
				pdo.setCREDIT_ACCOUNT(null);
			} else {
				logger.info(TRACE_UPDATE_PDO_CREDIT_REFERNCE_DATA);
				pdo.setCREDIT_ACCOUNT(null);
			}
		} else // Debit.
		{

			if (includeRawData) {
				logger.info(TRACE_UPDATE_PDO_DEBIT_DATA);
				pdo.set(P_DBT_ACCT_NB, (String) null);
				pdo.set(P_DBT_ACCT_OFFICE, (String) null);
				pdo.set(P_DBT_ACCT_CCY, (String) null);
				pdo.setDEBIT_ACCOUNT(null);
			} else {
				logger.info(TRACE_UPDATE_PDO_DEBIT_REFERNCE_DATA);
				pdo.setDEBIT_ACCOUNT(null);
			}
		}
	}

	public static String parseIBANAccout(String IBAN, String office) {
		Admin admin = Admin.getContextAdmin();

		IBANInputData ibanInputData = new IBANInputData();
		ibanInputData.setPotentialIban(IBAN);
		ibanInputData.setMethod(IBANMethod.ValidationAndDeconstruction);
		ibanInputData.setOffice(office);

		IBANOutputData ibanOutputData = new IBANOutputData();
		try {
			ibanOutputData = m_paymentServicesLogging.performIBANHandling(admin, ibanInputData);
		} catch (PaymentServicesException e) {
			logger.error("Error while trying to deconsturct iban: " + e.getMessage());
			ibanOutputData.setStatus(IBANStatus.NonIBAN);
		}

		logger.debug("parsing IBAN {}, status: {}, account number {}", new Object[] { IBAN, ibanOutputData.getStatus(), ibanOutputData.getAccountNumber() });

		if (IBANStatus.Valid == ibanOutputData.getStatus())
			return ibanOutputData.getAccountNumber();

		return null;
	}

	/**
	 * Performs primary checks for virtual account derivation and calls to the inner method to perform the derivation.
	 * 
	 * @return feedback with details of the success or failure of the process
	 */
	public Feedback executeVirtualAccountProcessing() {
		final String TRACE_CLIENTIDLENGTH_VALUE = "System parameter CLIENTIDLENGTH value: {}.";

		// Serializable oRequest = null;
		Feedback feedback = new Feedback();

		PDO pdo = Admin.getContextPDO();
		String sP_OFFICE = pdo.getString(P_OFFICE);

		String sSYS_PAR_CLIENTIDLENGTH = CacheKeys.SystParKey.getSingleParmValue(sP_OFFICE, SystemParametersInterface.SYS_PAR_CLIENTIDLENGTH);
		logger.info(TRACE_CLIENTIDLENGTH_VALUE, sSYS_PAR_CLIENTIDLENGTH);
		int iCLIENTIDLENGTH = Integer.parseInt(sSYS_PAR_CLIENTIDLENGTH);

		// If we arrived here, then:
		// X_CDTR_ACCT_ID must hold a value, (it is a condition in the related account lookup rule), which was kept also in
		// D_FIRST_IN_CDT_CHAIN_ACC_NUM;
		// if credit party enrichment rule was executed then the value in D_FIRST_IN_CDT_CHAIN_ACC_NUM was cleaned.
		String sX_CDTR_ACCT_ID = pdo.getString(X_CDTR_ACCT_ID);

		// STEP 1 -
		// Performs beneficiary account validation.
		// In case returned value is null and X_CDTR_ACCT_ID value length is less then defined CLIENTIDLENGTH system parameter,
		// then message status was set to REPAIR and no need to continue the flow even if debit MOP is set to
		// eligible for virtual account processing.
		// 02-06-2013 it was decided not to perform this checks, because on BOFA they was specific to India offices
		// String sBeneficiaryAccNumber = validateBeneficiaryAccNumber(sX_CDTR_ACCT_ID, iCLIENTIDLENGTH);

		String sBeneficiaryAccNumber = null;
		// Continues process.
		if (!MESSAGE_STATUS_REPAIR.equals(pdo.getString(P_MSG_STS))) {
			// STEP 2 -
			// If required, performs virtual account processing.
			if (sBeneficiaryAccNumber == null) {
				sBeneficiaryAccNumber = executeVirtualAccountProcessingInner(sX_CDTR_ACCT_ID, iCLIENTIDLENGTH);
			}

			// STEP 3 -
			// If beneficiary account number, prepares interface request object.
			// If it's null/empty, message was set to REPAIR during the 'executeVirtualAccountProcessing' method.
			if (!isNullOrEmpty(sBeneficiaryAccNumber)) {
				// Sets this field as the beneficiary account number.
				pdo.set(X_CDTR_ACCT_ID, sBeneficiaryAccNumber);

				// Sets fields for created 'ACMT_023' message from the call to the 'super.handleOut' method.
				pdo.set(X_MSG_ID, pdo.getMID());
				if (pdo.getDate(X_CRE_DT_TM) == null)
					pdo.set(X_CRE_DT_TM, pdo.getDate(P_CREATE_DT));
				// in DEUT we do not need these fields
				// pdo.set(X_VRFN_ACCT_OTHR_ID, sBeneficiaryAccNumber);
				// pdo.set(X_VRFN_AGT_BIC, pdo.getString(X_INSTG_AGT_BIC_2AND));

				// after virtual account derivation success put the derived account number into
				// D_CDT_IBAN_DERIVED_ACCOUNT field for further processing
				pdo.set(D_CDT_IBAN_DERIVED_ACCOUNT, sBeneficiaryAccNumber);

				// Request object will be created using the INTERFACE_TYPES.REQUEST_FORMAT_TYPE column which is set to VERIFY_ACC
				// which is defined in XML_FORMAT_TYPE_RELATIONS.FORMAT_TYPE.
				// oRequest = super.handleOut(pdo.getMID(), mapInterfaceTypeMetadata, feedback);
			}
		}

		// Status might have been changed to REPAIR during the 'validateBeneficiaryAccNumber' method or during the 'executeVirtualAccountProcessing'
		// method.
		if (MESSAGE_STATUS_REPAIR.equals(pdo.getString(P_MSG_STS))) {
			final String REPAIR_FEEDBACK_REASON = "BeneficiaryAccountValidationInterfaceHandler.handleOut - Message status was changed to REAPIR";

			feedback.setFailure();
			feedback.setErrorCode(1);
			feedback.setErrorText(REPAIR_FEEDBACK_REASON);
		}

		return feedback;
	}

	@SuppressWarnings("unused")
	private String validateBeneficiaryAccNumber(String sX_CDTR_ACCT_ID, int iCLIENTIDLENGTH) {
		final String TRACE_METHOD_INPUT = "X_CDTR_ACCT_ID: {}, Length: {}, CLIENTIDLENGTH: {}.";
		final String TRACE_SETS_TO_REPAIR = "X_CDTR_ACCT_ID length ({}) is less then CLIENTIDLENGTH system parameter value ({}); sets message status to REPAIR.";
		final String TRACE_METHOD_RESULT = "Returned beneficiary account number: {}.";

		final String REASON_TYPE_BRANCH_CD = "BRANCH_CD";

		String sBeneficiaryAccNumber = null;

		int iLength = sX_CDTR_ACCT_ID.length();
		logger.info(TRACE_METHOD_INPUT, new Object[] { sX_CDTR_ACCT_ID, iLength, iCLIENTIDLENGTH });

		// Do nothing; message will be set to REPAIR later on.
		if (iLength < iCLIENTIDLENGTH) {
			logger.info(TRACE_SETS_TO_REPAIR, iLength, iCLIENTIDLENGTH);
			Admin.getContextPDO().set(P_MSG_STS, MESSAGE_STATUS_REPAIR);

			// Error code 28336: 'Beneficiary account number length (|1) is less then CLIENTIDLENGTH system parameter value (|2)'.
			Object[] arrErrorParams = new Object[] { iLength, iCLIENTIDLENGTH };
			ErrorAuditUtils.setError(ProcessErrorConstants.BeneAccValidationFailureLengthLessThenCLIENTIDLENGTHLength, Admin.getContextPDO().getMID(), null, arrErrorParams);
		}

		// Will use this account number for the account lookup.
		else if (iLength == iCLIENTIDLENGTH)
			sBeneficiaryAccNumber = sX_CDTR_ACCT_ID;

		// 4 stands for branch code.
		else if (iLength == (4 + iCLIENTIDLENGTH)) {
			String sBranchCode = sX_CDTR_ACCT_ID.substring(0, 4);
			Reasons reasons = CacheKeys.reasonsKey.getSingle(REASON_TYPE_BRANCH_CD, sBranchCode);

			// Valid branch code; rest of the account number, (i.e. from index 4), will be used for the account lookup.
			if (reasons != null) {
				sBeneficiaryAccNumber = sX_CDTR_ACCT_ID.substring(4);
			}
		}

		logger.info(TRACE_METHOD_RESULT, sBeneficiaryAccNumber);

		return sBeneficiaryAccNumber;
	}

	/**
	 * Performs virtual account derivation. Uses parties, MOP, client Id and vendor code profiles.
	 * 
	 * @param sX_CDTR_ACCT_ID the account from the payment
	 * @param iCLIENTIDLENGTH the allowed account length from syst_par
	 * @return the derived account id, null in case of failure
	 */
	public String executeVirtualAccountProcessingInner(String sX_CDTR_ACCT_ID, int iCLIENTIDLENGTH) {
		final String TRACE_METHOD_INPUT = "X_CDTR_ACCT_ID: {}, Length: {}, CLIENTIDLENGTH: {}.";
		final String TRACE_METHOD_RESULT = "Returned beneficiary account number: {}, P_MSG_STS: {}.";
		final String TRACE_DEBIT_MOP_DATA = "Debit MOP: {}";
		final String TRACE_DEBIT_MOP_ELIGIBLE_FOR_VIRTUAL_ACC_PROC = ", Eligible for virtual acc processing: {}.";
		final String TRACE_INVALID_BRANCH_CODE = "ERROR: null/empty branch code; message status will be set to REPAIR...";
		final String TRACE_INVALID_MOP_OR_MOP_NOT_ELIGIBLE_FOR_VIRTUAL_ACC_PROCESSING = "ERROR: invalid MOP record or MOP isn't eligible for virtual account processing; message status will be set to REPAIR...";
		final String TRACE_INVALID_CLIENT_ID_OR_CLIENT_ID_NOT_ELIGIBLE_FOR_VIRTUAL_ACC_PROCESSING = "ERROR: invalid CLIENT_ID record or client ID isn't eligible for virtual account processing, (type 'None'); message status will be set to REPAIR...";
		final String TRACE_X_CDTR_ACCT_ID_AFTER_ADJUSTMENT_PLUS_REMAINING_CHARS = "X_CDTR_ACCT_ID after adjustment to CLIENTIDLENGTH ({}): {}, Remaining chars: {}.";
		final String TRACE_INVALID_CLIENT_ID_RECORD = "No CLIENT_ID record was found for branch code {} and client ID {}.";
		final String TRACE_VALID_CLIENT_ID_RECORD = "Valid CLIENT_ID record was found for branch code {} and client ID {} - Type of virtual account processing: {}.";
		final String TRACE_CLIENT_ID_DATA = "Client ID data - Type virtual acc. processing: {}, Account number: {}, Vendor code range from: {}, Vendor code range to: {}, "
				+ "Include client ID in beneficiary info: {}, Virtual account prefix: {}.";

		final String TRACE_STRAIGHT_OR_ALIAS_LOOKUP_VALIDATION_FAILURE = "Straight OR Alias lookup validation has failed for vendor code {}.";
		final String TRACE_RANGE_VALIDATION_CANNOT_BE_EXECUTED = "Range check cannot be executed for vendor code {}; From: {}, To: {}; either From value or To value are empty or vendor code contains non-digit chars.";
		final String TRACE_RANGE_VALIDATION_FAILURE = "Range check has failed for vendor code {}; From: {}, To: {}.";

		final String VIRTUAL_ACC_PROC_TYPE_NONE = "1";
		final String VIRTUAL_ACC_PROC_TYPE_NO_VALIDATION_REQUIRED = "2";
		final String VIRTUAL_ACC_PROC_TYPE_STRAIGHT_LOOKUP = "3";
		final String VIRTUAL_ACC_PROC_TYPE_ALIAS_LOOKUP = "4";
		final String VIRTUAL_ACC_PROC_TYPE_VALIDATE_VENDOR_CODE_RANGE = "5";

		int iErrorCode = 0;
		Object[] arrErrorParams = null;

		final String ACC_PROC = "ACC_PROC";

		String sBeneficiaryAccNumber = null;

		PDO pdo = Admin.getContextPDO();
		String sP_OFFICE = pdo.getString(P_OFFICE);

		// In G3 flows we do not have credit customer data at this stage yet
		Customrs customer = getLocalOfficeCustomer(pdo);
		String sBranchCode = null;
		if (customer != null) {
			sBranchCode = customer.getBranchCode();
		}

		int iLength = sX_CDTR_ACCT_ID.length();
		logger.info(TRACE_METHOD_INPUT, new Object[] { sX_CDTR_ACCT_ID, iLength, iCLIENTIDLENGTH });
		if (iLength < iCLIENTIDLENGTH) {
			logger.info(TRACE_INVALID_CLIENT_ID_OR_CLIENT_ID_NOT_ELIGIBLE_FOR_VIRTUAL_ACC_PROCESSING);

			// Error code 28339: 'Beneficiary account validation failure - no CLIENT_ID record for client ID |1 and branch code |2 or client
			// ID is not eligible for virtual account processing'.
			iErrorCode = ProcessErrorConstants.BeneAccValidationFailureNoCLIENT_IDRecordOrClientIDNotEligibleForVirtualAccProcessing;
			arrErrorParams = new Object[] { sX_CDTR_ACCT_ID, sBranchCode };
		} else {

			// Gets MOP record according to the flow type
			String sMOP = getMOPForDerivation(pdo);
			Mop mop = CacheKeys.mopKey.getSingle(sP_OFFICE, sMOP);

			String sDebitMOPTrace = TRACE_DEBIT_MOP_DATA + (mop != null ? TRACE_DEBIT_MOP_ELIGIBLE_FOR_VIRTUAL_ACC_PROC : ServerConstants.EMPTY_STRING);
			Object[] arrVariables = mop != null ? new Object[] { sMOP, mop.getEligibleForVirtualAccProc() } : new Object[] { sMOP };
			logger.info(sDebitMOPTrace, arrVariables);

			// Either MOP record wasn't found, (unlikely to happen), or record was found but MOP isn't eligible for virtual account processing.
			if (mop == null || (mop != null && !mop.getEligibleForVirtualAccProc())) {
				logger.info(TRACE_INVALID_MOP_OR_MOP_NOT_ELIGIBLE_FOR_VIRTUAL_ACC_PROCESSING);

				// Error code 28338: 'Beneficiary account validation failure - debit MOP |1 is not eligible for virtual account processing'.
				iErrorCode = ProcessErrorConstants.BeneAccValidationFailureDebitMOPNotEligibleForVirtualAccProcessing;
				arrErrorParams = new Object[] { sMOP };
			}

			// Continues to actual virtual account processing.
			else {
				// Sets client ID to be in the length of the CLIENTIDLENGTH system parameter.
				String sClientID = sX_CDTR_ACCT_ID.substring(0, iCLIENTIDLENGTH);

				// 'sX_CDTR_ACCT_ID' is for sure greater then 'iCLIENTIDLENGTH' otherwise, we wouldn't have arrived here.
				// The additional chars can stand for vendor code or vendor alias.
				String sVendorCodeRemainingChars = sX_CDTR_ACCT_ID.substring(iCLIENTIDLENGTH);
				logger.info(TRACE_X_CDTR_ACCT_ID_AFTER_ADJUSTMENT_PLUS_REMAINING_CHARS, new Object[] { iCLIENTIDLENGTH, sClientID, sVendorCodeRemainingChars });

				// Gets branch code of the credit customer.
				// Customrs creditCustomer = pdo.getCREDIT_CUSTOMER();

				// Valid branch code.
				if (!isNullOrEmpty(sBranchCode)) {
					ClientId clientId = CacheKeys.clientIdKey.getSingle(sP_OFFICE, sClientID, sBranchCode);

					if (clientId == null) {
						logger.info(TRACE_INVALID_CLIENT_ID_RECORD, sBranchCode, sClientID);
					} else {
						logger.info(TRACE_VALID_CLIENT_ID_RECORD, new Object[] { sBranchCode, sClientID, clientId.getTypeVirtualAccProc() });
					}

					// Either:
					// 1) Didn't get back CLIENT_ID record.
					// OR 2) Got back CLIENT_ID record and its type of virtual account processing is 'None'; i.e. not eligible for virtual account
					// processing.
					if (clientId == null
							|| (clientId != null && (isNullOrEmpty(clientId.getTypeVirtualAccProc()) || VIRTUAL_ACC_PROC_TYPE_NONE.equals(clientId.getTypeVirtualAccProc())))) {
						logger.info(TRACE_INVALID_CLIENT_ID_OR_CLIENT_ID_NOT_ELIGIBLE_FOR_VIRTUAL_ACC_PROCESSING);

						// Error code 28339: 'Beneficiary account validation failure - no CLIENT_ID record for client ID |1 and branch code |2 or
						// client
						// ID is not eligible for virtual account processing'.
						iErrorCode = ProcessErrorConstants.BeneAccValidationFailureNoCLIENT_IDRecordOrClientIDNotEligibleForVirtualAccProcessing;
						arrErrorParams = new Object[] { sClientID, sBranchCode };
					}

					// Valid client ID record which is eligible for virtual account processing.
					else {
						String sTypeVirtualAccProc = clientId.getTypeVirtualAccProc();
						ComboData comboData = CacheKeys.comboIDsKey.getSingle(ACC_PROC);
						String sVirtualAccProcName = comboData.getData().get(sTypeVirtualAccProc);

						String sAccNo = clientId.getAccNo();
						String sVendorCodeRngFrom = clientId.getVendorCodeRngFrom();
						String sVendorCodeRngTo = clientId.getVendorCodeRngTo();
						Boolean boolInclClientBenInf = clientId.getInclClientBenInf();

						String sVirtualAccPfx = clientId.getVirtualAccPfx();
						if (sVirtualAccPfx == null)
							sVirtualAccPfx = ServerConstants.EMPTY_STRING;

						logger.info(TRACE_CLIENT_ID_DATA, /* sTypeVirtualAccProc, */new Object[] { sVirtualAccProcName, sAccNo, sVendorCodeRngFrom, sVendorCodeRngTo,
								boolInclClientBenInf, sVirtualAccPfx });

						// No validation is required.
						if (VIRTUAL_ACC_PROC_TYPE_NO_VALIDATION_REQUIRED.equals(sTypeVirtualAccProc)) {
							sBeneficiaryAccNumber = sAccNo;
						}

						// Straight lookup OR Alias lookup.
						else if (VIRTUAL_ACC_PROC_TYPE_STRAIGHT_LOOKUP.equals(sTypeVirtualAccProc) || VIRTUAL_ACC_PROC_TYPE_ALIAS_LOOKUP.equals(sTypeVirtualAccProc)) {
							boolean bStraightLookup = VIRTUAL_ACC_PROC_TYPE_STRAIGHT_LOOKUP.equals(sTypeVirtualAccProc);

							if (!isNullOrEmpty(sVendorCodeRemainingChars) && !GlobalStringUtil.isStringContainOnlyDigits(sVendorCodeRemainingChars)) {
								logger.info(TRACE_RANGE_VALIDATION_CANNOT_BE_EXECUTED, new Object[] { sVendorCodeRemainingChars, sVendorCodeRngFrom, sVendorCodeRngTo });

								// Error code 28351: 'Beneficiary account validation failure - for client ID |1 and branch code |2 either From
								// value (|3) or To value (|4) are empty or vendor code (|5) contains non-digit chars";
								iErrorCode = ProcessErrorConstants.BeneAccValidationFailureVendorCodeRangeValidationCannotBeExecuted;
								arrErrorParams = new Object[] { sClientID, sBranchCode, sVendorCodeRngFrom, sVendorCodeRngTo, sVendorCodeRemainingChars };
							} else {

								VendorCodes vendorCodes = bStraightLookup ? CacheKeys.vendorCodesVendorCodeKey.getSingle(sP_OFFICE, sBranchCode, sClientID,
										sVendorCodeRemainingChars) : CacheKeys.vendorCodesVendorAliasKey.getSingle(sP_OFFICE, sBranchCode, sClientID, sVendorCodeRemainingChars);

								if (vendorCodes != null) {
									sBeneficiaryAccNumber = vendorCodes.getAccountNumber();
									if (sBeneficiaryAccNumber == null)
										sBeneficiaryAccNumber = sAccNo;

									// 27/06/203 this was added to original R&D code by BA
									if (VIRTUAL_ACC_PROC_TYPE_ALIAS_LOOKUP.equals(sTypeVirtualAccProc)) {
										sVendorCodeRemainingChars = vendorCodes.getVendorCode();
									}
								} else {
									logger.info(TRACE_STRAIGHT_OR_ALIAS_LOOKUP_VALIDATION_FAILURE, sVendorCodeRemainingChars);

									// Error code 28340: 'Beneficiary account validation failure - no VENDOR_CODES record was found for client ID |1,
									// branch
									// code |2 and vendor code |3'.
									// Error code 28341: 'Beneficiary account validation failure - no VENDOR_CODES record was found for client ID |1,
									// branch
									// code |2 and vendor alias |3'.
									iErrorCode = bStraightLookup ? ProcessErrorConstants.BeneAccValidationFailureNoVENDOR_CODESRecordFoundForVendorCode
											: ProcessErrorConstants.BeneAccValidationFailureNoVENDOR_CODESRecordFoundForVendorAlias;
									arrErrorParams = new Object[] { sClientID, sBranchCode, sVendorCodeRemainingChars };
								}
							}
						}

						// Validate vendor code range.
						else if (VIRTUAL_ACC_PROC_TYPE_VALIDATE_VENDOR_CODE_RANGE.equals(sTypeVirtualAccProc)) {
							// Verifies that the vendor code is in the allowed range.
							if (!isNullOrEmpty(sVendorCodeRngFrom) && !isNullOrEmpty(sVendorCodeRngTo) && GlobalStringUtil.isStringContainOnlyDigits(sVendorCodeRemainingChars)) {
								Double dFrom = Double.parseDouble(sVendorCodeRngFrom);
								Double dTo = Double.parseDouble(sVendorCodeRngTo);
								Double dVendorCode = Double.valueOf(0);
								if (!sVendorCodeRemainingChars.isEmpty()) {
									dVendorCode = Double.parseDouble(sVendorCodeRemainingChars);
								}

								if (!sVendorCodeRemainingChars.isEmpty() && dFrom <= dVendorCode && dVendorCode <= dTo) {
									sBeneficiaryAccNumber = sAccNo;
								}

								else {
									logger.info(TRACE_RANGE_VALIDATION_FAILURE, new Object[] { sVendorCodeRemainingChars, sVendorCodeRngFrom, sVendorCodeRngTo });

									// Error code 28342: 'Beneficiary account validation failure - for client ID |1 and branch code |2 vendor code
									// |3 is not between |4 and |5'.
									iErrorCode = ProcessErrorConstants.BeneAccValidationFailureVendorCodeOutOfRange;
									arrErrorParams = new Object[] { sClientID, sBranchCode, sVendorCodeRemainingChars, sVendorCodeRngFrom, sVendorCodeRngTo };
								}
							}

							// Validation can't be executed; either From value or To value are empty or vendor code contains non-digit chars.
							else {
								logger.info(TRACE_RANGE_VALIDATION_CANNOT_BE_EXECUTED, new Object[] { sVendorCodeRemainingChars, sVendorCodeRngFrom, sVendorCodeRngTo });

								// Error code 28351: 'Beneficiary account validation failure - for client ID |1 and branch code |2 either From
								// value (|3) or To value (|4) are empty or vendor code (|5) contains non-digit chars";
								iErrorCode = ProcessErrorConstants.BeneAccValidationFailureVendorCodeRangeValidationCannotBeExecuted;
								arrErrorParams = new Object[] { sClientID, sBranchCode, sVendorCodeRngFrom, sVendorCodeRngTo, sVendorCodeRemainingChars };
							}
						}

						// 06/06/2013 It was decided not to create UDF filed, as current solution is on Product level
						// Sets 'P_VENDOR_CODE' field, if beneficiary account number was set above.
						if (!isNullOrEmpty(sBeneficiaryAccNumber)) {
							String sVENDOR_CD = boolInclClientBenInf ? sVirtualAccPfx + sClientID + sVendorCodeRemainingChars : sVirtualAccPfx + sVendorCodeRemainingChars;
							pdo.set(P_VENDOR_CODE, sVENDOR_CD);
						}
					}

					if (clientId != null) {
						// Error code 28861: 'Virtual account processing of type |1 has completed on virtual account |2.'
						ProcessError pError = new ProcessError(ProcessErrorConstants.VirtualAccountProcessingCompleted, pdo.getMID(), null, new Object[] {
								clientId.getTypeVirtualAccProc(), sX_CDTR_ACCT_ID });
						ErrorAuditUtils.setErrors(pError, pdo.getIsHistory());
					}

				}

				// Null/empty branch code; message should go to REPAIR.
				else {
					logger.info(TRACE_INVALID_BRANCH_CODE);

					// Error code 28337: 'Beneficiary account validation failure - credit customer |1 has no valid branch code'.
					iErrorCode = ProcessErrorConstants.BeneAccValidationFailureCreditCustomerHasNoValidBranchCode;
					arrErrorParams = new Object[] { customer.getCustCode() };
				}
			}
		}

		if (iErrorCode != 0) {
			ErrorAuditUtils.setError(iErrorCode, pdo.getMID(), pdo.getIsHistory(), null, arrErrorParams);
		}

		if (isNullOrEmpty(sBeneficiaryAccNumber)) {
			pdo.set(P_MSG_STS, MESSAGE_STATUS_REPAIR);
		}

		logger.info(TRACE_METHOD_RESULT, sBeneficiaryAccNumber, pdo.getString(P_MSG_STS));

		return sBeneficiaryAccNumber;
	}

	/**
	 * Get the MOP that should be used during virtual account derivation process
	 * 
	 * @param pdo the payment
	 * @return the MOP that should be used to perform derivation
	 */
	private String getMOPForDerivation(PDO pdo) {

		// by default get the debit MOP
		String sMOP = pdo.getString(P_DBT_MOP);

		// for G3 DD Book flow use credit MOP
		// when new flows are to be added this issue should be reconsidered again
		String sFlowName = NVL(pdo.getString(D_G3_IMMEDIATE_FLOW_NAME), EMPTY_STRING);
		if (sFlowName.equals(G3DDBook.name()) || sFlowName.equals(G3DDOutgoing.name())) {
			sMOP = pdo.getString(P_CDT_MOP);
		}
		return sMOP;
	}

	/**
	 * Get the BIC from the payment to use in virtual account derivation process.
	 * 
	 * @param pdo the payment
	 * @return the BIC that should be used in virtual account derivation process.
	 */
	private Customrs getLocalOfficeCustomer(PDO pdo) {
		// String sFlowName = NVL(pdo.getString(D_G3_IMMEDIATE_FLOW_NAME), EMPTY_STRING);
		//
		// // by default get BIC from this xpath
		// String bic = pdo.getString("X_DBTR_AGT_BIC_2AND");
		// // otherwise consider the flow
		// if (sFlowName.equals(G3CTIncoming.name())) {
		// bic = pdo.getString("X_PMT_INSTG_AGT_ID");
		// } else if (sFlowName.equals(G3DDBook.name())) {
		// bic = pdo.getString("X_CDTR_AGT_BIC_2AND");
		// }
		//
		// String office = pdo.getString(P_OFFICE);
		// // TODO check what if bic is null
		// Customrs creditCustomer = CacheKeys.customrsBICandOfficeKey.getSingle(bic, office);

		// use local office to get branch Code
		// From solution: For G3 solution in Singapore, branch codes are not relevant and therefore branch code derivation is not applied.
		// Instead, a dummy branch code, defined under local office, will be selected in all cases and for all messages
		String office = pdo.getString(P_OFFICE);
		Banks banks = CacheKeys.banksKey.getSingle(office);
		Customrs creditCustomer = CacheKeys.customrsKey.getSingle(banks.getCustCode(), office);
		return creditCustomer;
	}
}
