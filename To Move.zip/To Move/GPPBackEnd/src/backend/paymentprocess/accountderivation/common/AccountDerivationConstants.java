package backend.paymentprocess.accountderivation.common;

/**
 * Title:       AccountDerivationConstants
 * Description: Class for holding finding account derivation constants
 * Company:     Fundtech Israel
 * Author:      Asaf Levy
 * Date:        07/09/2008
 * @version     1.0
 */
public class AccountDerivationConstants
{
  // Customer types.
  public enum AccountDerivationType
  {
    Debit,Credit;
    
    public String toString() 
    {
      return name();
    }
  };
  
  // Account lookup types.
  public enum AccountLookupType
  {
    External,Internal;
    
    public String toString() 
    {
      return name();
    }
  };
}