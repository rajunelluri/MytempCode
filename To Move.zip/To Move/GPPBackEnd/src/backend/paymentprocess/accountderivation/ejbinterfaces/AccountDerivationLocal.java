package backend.paymentprocess.accountderivation.ejbinterfaces;

import javax.ejb.Local;

/**
 * Local interface for AccountDerivation.
 */
@Local
public interface AccountDerivationLocal extends AccountDerivation{} ; 