package backend.paymentprocess.accountderivation.ejbinterfaces;

import javax.ejb.Remote;
import com.fundtech.core.security.Admin;

/**
 * Remote interface for AccountDerivation.
 */
@Remote
public interface AccountDerivation{

	public static final String REMOTE_JNDI_NAME="ejb/AccountDerivationBean";
	
	public com.fundtech.datacomponent.response.Feedback performAccountInquiry(final Admin admin, java.lang.String sMID ) throws backend.paymentprocess.accountderivation.exception.AccountDerivationException ;
	
	/** 
	 * Finds the first in chain of either credit or debit side for the passed MID.
	 */
	public com.fundtech.datacomponent.response.Feedback performAccountDerivation(final Admin admin, java.lang.String sMID ) throws backend.paymentprocess.accountderivation.exception.AccountDerivationException ;

	public boolean handleAccountEnrichment(final Admin admin , boolean bCreditAccountDerivation, boolean bSuccessfulAccountDerivationAlreadySucceed) throws Exception ;
}//EOI  