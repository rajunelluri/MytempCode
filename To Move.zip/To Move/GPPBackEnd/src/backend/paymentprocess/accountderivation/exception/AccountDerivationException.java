package backend.paymentprocess.accountderivation.exception;

import com.fundtech.core.paymentprocess.errorhandling.BusinessException;
import com.fundtech.core.paymentprocess.errorhandling.ProcessError;

/**
 * Title:       AccountDerivationException
 * Description: Class for all account derivation exceptions
 * Company:     Fundtech Israel
 * Author:      Asaf Levy
 * Date:        07/09/2008
 * @version     1.0
 */
public class AccountDerivationException extends BusinessException
{
  private static final long serialVersionUID = -463673756708464723L;
  
  private ProcessError processError;
  
  public AccountDerivationException()
  {
    super();
  }
  
  public AccountDerivationException(String string)
  {
    super(string);
  }
  
  public AccountDerivationException(String string,ProcessError processError)
  {
    super(string);
    this.processError = processError;
  }
  
  public AccountDerivationException(String string, Throwable e)
  {
    super(string, e);
  }
  
  public ProcessError getProcessError() {
	  return processError;
  }
}
