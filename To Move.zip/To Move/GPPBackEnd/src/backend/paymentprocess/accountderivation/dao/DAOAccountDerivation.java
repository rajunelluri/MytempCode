package backend.paymentprocess.accountderivation.dao;

import static com.fundtech.util.GlobalUtils.isNullOrEmpty;

import java.sql.Types;

import com.fundtech.core.general.StatementParameter;

import backend.dataaccess.dao.DAOBasic;
import backend.dataaccess.dto.DTOSingleValue;

/**
 * Title:       DAOAccountDerivation
 * Description: DAO object for finding first in chain
 * Company:     Fundtech Israel
 * Author:      Asaf Levy
 * Date:        07/09/2008
 * @version     1.0
 */
public class DAOAccountDerivation extends DAOBasic
{
  private static DAOAccountDerivation m_daoAccountDerivation = new DAOAccountDerivation();
  
  /**
   * Private constructor. 
   */
  private DAOAccountDerivation()
  {
  }
  
  public static DAOAccountDerivation getInstance()
  {
  	return m_daoAccountDerivation;
  }
  
  /**
   * 
   */
  public DTOSingleValue getAccountUsingAccAlias(String sAccountAlias, String sPaymentOffice, String sInstCurrency, String sCustCode)
  {
  	final String SELECT_STATEMENT_1 = "SELECT ACC_NO FROM ACCOUNTS WHERE ACC_ALIAS = ? AND OFFICE = ?";
  	final String SELECT_STATEMENT_2 = "SELECT ACC_NO FROM ACCOUNTS WHERE ACC_ALIAS = ? AND OFFICE = ? AND CURRENCY = ?";
  	final String SELECT_STATEMENT_3 = "SELECT ACC_NO FROM ACCOUNTS WHERE ACC_ALIAS = ? AND OFFICE = ? AND CURRENCY = ? AND CUST_CODE = ?";
  	
  	StatementParameter[] arrParameters;
  	String sSelectStatement;
  	
  	// Both currency and cust code are null.
  	if(isNullOrEmpty(sInstCurrency) && isNullOrEmpty(sCustCode))
  	{
  		sSelectStatement = SELECT_STATEMENT_1;
  		
  		arrParameters = new StatementParameter[]{new StatementParameter(sAccountAlias, Types.VARCHAR),
																			  		   new StatementParameter(sPaymentOffice, Types.VARCHAR)};  		  		
  	}
  	
  	// Cust code is null.
  	else if(isNullOrEmpty(sCustCode))
  	{
  		sSelectStatement = SELECT_STATEMENT_2;
  		
  		arrParameters = new StatementParameter[]{new StatementParameter(sAccountAlias, Types.VARCHAR),
																			  		   new StatementParameter(sPaymentOffice, Types.VARCHAR),
																			  		   new StatementParameter(sInstCurrency, Types.VARCHAR)};  		  		
  	}
  	
  	else
  	{
  		sSelectStatement = SELECT_STATEMENT_3;

  		arrParameters = new StatementParameter[]{new StatementParameter(sAccountAlias, Types.VARCHAR),
																				  		 new StatementParameter(sPaymentOffice, Types.VARCHAR),
																				  		 new StatementParameter(sInstCurrency, Types.VARCHAR),
																				  		 new StatementParameter(sCustCode, Types.VARCHAR)};  		
  	}
  	
  	return getSingleValue(sSelectStatement, arrParameters, null);
  }
}