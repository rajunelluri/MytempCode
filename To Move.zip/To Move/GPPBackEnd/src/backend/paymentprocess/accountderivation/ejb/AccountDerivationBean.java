package backend.paymentprocess.accountderivation.ejb;

import javax.ejb.Stateless;
import backend.core.SuperSLSB;
import com.fundtech.core.security.Admin;
import backend.businessobject.proxies.interceptors.InterceptorSetType;
import backend.paymentprocess.accountderivation.businessobjects.BOAccountDerivation;
import backend.paymentprocess.accountderivation.ejbinterfaces.AccountDerivationLocal;
import backend.paymentprocess.accountderivation.ejbinterfaces.AccountDerivation;

@Stateless
public class AccountDerivationBean extends SuperSLSB<AccountDerivation> implements AccountDerivationLocal, AccountDerivation{
	
	public AccountDerivationBean() { super(backend.paymentprocess.accountderivation.businessobjects.BOAccountDerivation.class, InterceptorSetType.Complete) ; }//EOM
	
	
	public com.fundtech.datacomponent.response.Feedback performAccountInquiry(final Admin admin, java.lang.String sMID ) throws backend.paymentprocess.accountderivation.exception.AccountDerivationException {
		return this.m_bo.performAccountDerivation(admin, sMID ) ;
	}//EOM
	
	/** 
	 * Finds the first in chain of either credit or debit side for the passed MID.
	 */
	public com.fundtech.datacomponent.response.Feedback performAccountDerivation(final Admin admin, java.lang.String sMID ) throws backend.paymentprocess.accountderivation.exception.AccountDerivationException {
		return this.m_bo.performAccountDerivation(admin, sMID ) ;
	}//EOM

	/** 
	 * Finds the first in chain of either credit or debit side for the passed MID.
	 */
	public boolean handleAccountEnrichment(final Admin admin , boolean bCreditAccountDerivation, boolean bSuccessfulAccountDerivationAlreadySucceed) throws Exception {
		return this.m_bo.handleAccountEnrichment(admin, bCreditAccountDerivation,bSuccessfulAccountDerivationAlreadySucceed ) ;
	}//EOM
}//EOC