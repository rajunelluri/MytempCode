package backend.paymentprocess.anticipatedfundsflow.ejbinterfaces;

import javax.ejb.Local;

/**
 * Local interface for AnticipatedFundsFlow.
 */
@Local
public interface AnticipatedFundsFlowLocal extends AnticipatedFundsFlow{} ; 