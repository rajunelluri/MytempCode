package backend.paymentprocess.anticipatedfundsflow.ejbinterfaces;

import javax.ejb.Remote;
import com.fundtech.core.security.Admin;

/**
 * Remote interface for AnticipatedFundsFlow.
 */
@Remote
public interface AnticipatedFundsFlow{

	public static final String REMOTE_JNDI_NAME="ejb/AnticipatedFundsFlowBean";
	
	
	/** 
	 */
	public com.fundtech.datacomponent.response.Feedback performAnticipatedFundsProcess(final Admin admin, java.lang.String sMID ) ;

}//EOI  