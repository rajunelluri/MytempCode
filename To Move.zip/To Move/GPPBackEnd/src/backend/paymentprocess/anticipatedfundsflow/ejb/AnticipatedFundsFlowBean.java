package backend.paymentprocess.anticipatedfundsflow.ejb;

import javax.ejb.Stateless;
import backend.core.SuperSLSB;
import com.fundtech.core.security.Admin;
import backend.businessobject.proxies.interceptors.InterceptorSetType;
import backend.paymentprocess.anticipatedfundsflow.businessobjects.BOAnticipatedFundsFlow;
import backend.paymentprocess.anticipatedfundsflow.ejbinterfaces.AnticipatedFundsFlowLocal;
import backend.paymentprocess.anticipatedfundsflow.ejbinterfaces.AnticipatedFundsFlow;

@Stateless
public class AnticipatedFundsFlowBean extends SuperSLSB<AnticipatedFundsFlow> implements AnticipatedFundsFlowLocal, AnticipatedFundsFlow{
	
	public AnticipatedFundsFlowBean() { super(backend.paymentprocess.anticipatedfundsflow.businessobjects.BOAnticipatedFundsFlow.class, InterceptorSetType.Complete) ; }//EOM
	
	
	/** 
	 */
	public com.fundtech.datacomponent.response.Feedback performAnticipatedFundsProcess(final Admin admin, java.lang.String sMID ) {
		return this.m_bo.performAnticipatedFundsProcess(admin, sMID ) ;
	}//EOM

}//EOC