
package backend.paymentprocess.anticipatedfundsflow.businessobjects;

public interface FlowControl {
	FlowStep lastStep();
	FlowStep nextStep();
}
