
package backend.paymentprocess.anticipatedfundsflow.businessobjects;

public enum FlowStep {	
   StartFlow
  ,HandleExpiration	  	  
  ,ScheduleExpirationEvent 
  ,Department_rule_selection
  ,Repair_and_enrichment
  ,BASE_currency_conversion
  ,Compliance_validation
  ,Duplicate_check
  ,Debit_party_processing
  ,Credit_party_processing
  ,Message_classification
  ,Matching_to_Payment
  ,MOP_selection
  ,Complete
  ,EndFlow
  ,Validation_rules
  ,Gracefull_Termination 
}
