
package backend.paymentprocess.anticipatedfundsflow.businessobjects;

import static backend.core.module.MessageConstantsInterface.EVENT_AF_EXPIRATION;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.D_EVENT_ID;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_AF_EXPIRE_TIME;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_OFFICE;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_RELEASE_INDEX;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.X_STTLM_DT_1B;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;

import backend.dataaccess.dao.DAOBasic;
import backend.services.events.handlers.PaymentDistributerEventHandler;
import backend.services.timers.ITimerService;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.spring.SpringApplicationContext;
import com.fundtech.util.datetime.NewASDateTimeUtils;

public class AnticipatedFundsExpiration {
	private static final Logger logger = LoggerFactory.getLogger(AnticipatedFundsExpiration.class);
	
	public static void scheduleExpirationEvent(PDO pdo) throws Exception {
		Date expirationTime = evaluateExpirationTime(pdo);
	  
  		if (expirationTime == null)
  			return;
	  
  		StringBuilder releaseIndex = new StringBuilder(EVENT_AF_EXPIRATION);
  		releaseIndex.append("^").append(pdo.getMID());
  		releaseIndex.append("^").append(pdo.getString(P_AF_EXPIRE_TIME));
  		
  		Map<String,String> parameters = new HashMap<String,String>();
  		parameters.put("releaseIndex",releaseIndex.toString());
  		try {
  			ITimerService timerService = (ITimerService)SpringApplicationContext.getBean("TimerService");   	 	
  			timerService.scheduleOneTimeEvent(EVENT_AF_EXPIRATION,parameters,expirationTime);
  		} catch (BeansException e) { //Allow Dual mode with old scheduler , TBD remove   
  			logger.debug("Using old scheduler");
  	  		//Note: if event already exists it won't be added (tx wouldn't be damaged)
  	  		//Note: using pdo.hadFieldChanged(P_AF_EXPIRE_TIME) didn't work...
  	  		PaymentDistributerEventHandler.addOneTimeEvent(EVENT_AF_EXPIRATION
  				  ,releaseIndex.toString()
  				  ,null
  				  ,new java.sql.Timestamp(expirationTime.getTime()));
  	  		
  		}
		
  		pdo.set(P_RELEASE_INDEX,releaseIndex.toString());
  	}
    
	public static boolean isExpiredAF(PDO pdo) {
  		if (isExpirationEvent(pdo)) {
  			logger.debug("AF expired via AF_EXPIRATION event");
  			return true;
  		}
  		
  		Date expirationTime = evaluateExpirationTime(pdo);
  		
  		if (expirationTime == null)
  			return false;
  		
  		boolean expired = false;
  		
  		//manually detection of expiration (as best effort) 
  		try {  			
  			String time = new DAOBasic().getSysTimeInMillisecondsFromDB().getValue();
  			Date dbTime = new Date(Long.parseLong(time));
  			expired = dbTime.after(expirationTime); 
  			
  			if (expired)
  				logger.debug("AF expired by examining expiration time {} against current db time {}" +
  						" (missing AF_EXPIRATION event?!)",expirationTime,dbTime);
  			
  			/* Quartz
  			Date now = new Date();	
  			expired = now.after(expirationTime);
	  		if (expired)
	  			logger.debug("AF expired by examining expiration time {} against current time {}" +
	  					" (missing AF_EXPIRATION event?!)",expirationTime,now);
	  					*/
  		} catch (Exception ignored) {  
  			logger.debug("best effort to manually detect expired AF failed {}",ignored);
  		}
  		
  		return expired;
	}

	
	public static Date evaluateExpirationTime(PDO pdo) {	  
  		String expirationTime = pdo.getString(P_AF_EXPIRE_TIME);
	  
  		if (StringUtils.isEmpty(expirationTime))
  			return null;
	  
  		Date settlementDate = pdo.getDate(X_STTLM_DT_1B);
  		Calendar cal = Calendar.getInstance();
  		cal.setTime(settlementDate);
  		cal.set(Calendar.HOUR_OF_DAY,Integer.parseInt(expirationTime.substring(0,2)));
  		cal.set(Calendar.MINUTE,Integer.parseInt(expirationTime.substring(3,5)));
	  
  		Date officeTime = cal.getTime();
	  
  		Date systemTime = NewASDateTimeUtils.converFromOfficeDateToServerDate(officeTime,pdo.getString(P_OFFICE));
	  
  		logger.debug("AF expiration: {}/{} (system time/office time) ",systemTime,officeTime);
	  
  		return new Date(systemTime.getTime()); //force java.util.Date (Quartz)
  	}

  	private static boolean isExpirationEvent(PDO pdo) {
  		return EVENT_AF_EXPIRATION.equals(pdo.getString(D_EVENT_ID));
	}
}


/*String time = new DAOBasic().getSysTimeInMillisecondsFromDB().getValue();
	Date dbTime = new Date(Long.parseLong(time));
	expired = dbTime.after(expirationTime); 
	
	if (expired)
		logger.debug("AF expired by examining expiration time {} against current db time {}" +
				" (missing AF_EXPIRATION event?!)",expirationTime,dbTime);
	 */