
package backend.paymentprocess.anticipatedfundsflow.businessobjects;
 
import static backend.businessobject.BOProxies.m_complianceLogging;
import static backend.businessobject.BOProxies.m_enrichmentLogging;
import static backend.businessobject.BOProxies.m_internalAFPartyProcessingLogging;
import static backend.businessobject.BOProxies.m_matchingCheckLogging;
import static backend.businessobject.BOProxies.m_mopSelectionLogging;
import static backend.core.module.MessageConstantsInterface.AF_MATCH_STATUS_NONE;
import static backend.core.module.MessageConstantsInterface.AF_TYPE_PREADVICE;
import static backend.core.module.MessageConstantsInterface.MESSAGE_STATUS_CANCELED;
import static backend.core.module.MessageConstantsInterface.MESSAGE_STATUS_COMPEX;
import static backend.core.module.MessageConstantsInterface.MESSAGE_STATUS_COMPLETE;
import static backend.core.module.MessageConstantsInterface.MESSAGE_STATUS_DUPEX;
import static backend.core.module.MessageConstantsInterface.MESSAGE_STATUS_RECEIVED;
import static backend.core.module.MessageConstantsInterface.MESSAGE_STATUS_REPAIR;
import static backend.core.module.MessageConstantsInterface.MESSAGE_STATUS_WAIT_MATCH;
import static backend.core.module.MessageConstantsInterface.MONITOR_FLAG_COMPLIANCE_HIT;
import static backend.core.module.MessageConstantsInterface.MONITOR_FLAG_COMPLIANCE_WAIT;
import static backend.core.module.MessageConstantsInterface.MONITOR_FLAG_FAILURE;
import static backend.core.module.MessageConstantsInterface.MONITOR_FLAG_FORCE;
import static backend.core.module.MessageConstantsInterface.MONITOR_FLAG_X;
import static backend.core.module.MessageConstantsInterface.MSG_CLASS_NAC;
import static backend.core.module.MessageConstantsInterface.RULE_TYPE_ID_DEPARTMENT;
import static backend.core.module.MessageConstantsInterface.RULE_TYPE_ID_PAYMENT_CLASSIFICATION;
import static backend.core.module.MessageConstantsInterface.RULE_TYPE_ID_REPAIR_AND_ENRICHMENT_SELECTION;
import static backend.paymentprocess.anticipatedfundsflow.businessobjects.AnticipatedFundsExpiration.scheduleExpirationEvent;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.D_CURRENCY_CONVERSION_TYPE;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.D_RULE_TYPE_ID;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.D_THROTTLING_MANUAL_MOP_SELECTION;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.MF_AF_MATCH_STS;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.MF_COMPLIANCE_VALIDATION_STS;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.MF_MOP_SELECTION_STS;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.MU_COMPLIANCE_FORCE_STS;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_AF_EXPIRE_TIME;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_AF_TYPE;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_MSG_CLASS;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_MSG_STS;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.X_SWIFT_DIRECTION_IND;
import static com.fundtech.errors.ProcessErrorConstants.AnticipatedFundsExpired;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.businessobject.BOProxies;
import backend.paymentprocess.baseprocess.businessobjects.BOBaseProcess;
import backend.paymentprocess.currencyconversion.common.CurrencyConversionConstants.ConversionType;
import backend.paymentprocess.erroraudit.ErrorAuditUtils;
import backend.paymentprocess.glm.basic.businessobjects.BOGLMBasic;
import backend.paymentprocess.highvalueprocess.businessobjects.BOHighValueProcess;
import backend.paymentprocess.matchingcheck.businessobjects.MatchType;
import backend.paymentprocess.mopselection.output.MopSelectionOutputData;
import backend.paymentprocess.partyprocessing.businessobjects.BOPartyProcessing;

import com.fundtech.annotations.Expose;
import com.fundtech.annotations.Wrap;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.core.paymentprocess.errorhandling.ProcessError;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.datacomponent.response.GlobalAbstractResponseDataComponent;
import com.fundtech.util.ExceptionController;


@Wrap (tx="Bean")
public class BOAnticipatedFundsFlow extends BOGLMBasic {
  private static final Logger logger = LoggerFactory.getLogger(BOAnticipatedFundsFlow.class);
	
  private static final String SERVICE_ANTICIPATED_FUNDS_FLOW = "anticipated funds flow";
  private static final String COMPLIANCE_MODULE = "Compliance check";
  private static final String DUPLICATE_CHECK_MODULE = "Duplicate check";

  @Expose
  public Feedback performAnticipatedFundsProcess(String mid) {
    Feedback feedback = new Feedback();
    Admin admin = Admin.getContextAdmin();
    String terminationStatus = null;
    
    PDO pdo = PaymentDataFactory.load(mid);
    FlowControl flowControl = new AnticipatedFundsFlowControl(pdo);
    
    try {
    	while (feedback.isSuccessful() && flowControl.lastStep() != FlowStep.EndFlow)
    		feedback = executeStep(flowControl.nextStep(),admin,pdo);    	
    } catch(Throwable e) {
    	feedback = genericServiceExceptionHandling(e, SERVICE_ANTICIPATED_FUNDS_FLOW, flowControl.lastStep().name());      
   		pdo.promoteToPrimary(); //TBD what's that?!
   		terminationStatus = MESSAGE_STATUS_REPAIR;
    } finally {
    	//Ensure non-zero error code.
    	if(!feedback.isSuccessful()) {      
          if(feedback.getErrorCode() == 0)  
            feedback.setErrorCode(1);
        }
        
    	try {
    		executeStep(FlowStep.Validation_rules,admin,pdo);    		
    	} catch(Throwable  ex) {
    		ExceptionController.getInstance().handleException(ex, this);
    	} finally {
    		try {
				executeStep(FlowStep.Gracefull_Termination,admin,pdo,terminationStatus);
			} catch (Throwable ex) {
				ExceptionController.getInstance().handleException(ex, this);
			}
    	}
    }
    	
    return feedback;
  }

	public Feedback performTerminationFlow(String mid,String terminationStatus) {
  		Admin admin = Admin.getContextAdmin();
  		PDO pdo = PaymentDataFactory.load(mid);
  		Feedback feedback;
	  
  		try {
  			feedback = executeStep(FlowStep.Gracefull_Termination,admin,pdo,terminationStatus);
  		} catch (Throwable e) {
  			feedback = genericServiceExceptionHandling(e, SERVICE_ANTICIPATED_FUNDS_FLOW, FlowStep.Gracefull_Termination.name());
  			ExceptionController.getInstance().handleException(e, this);
  		}
	  
  		return feedback;
  	}
  
  private Feedback executeStep(FlowStep step,Admin admin,PDO pdo,Object...params) throws Throwable {
	Feedback feedback = new Feedback();
		
	logger.debug("executing step '"+step+"'");
	
	try {
		switch (step) {				
			case StartFlow:
			    logger.info("BOAnticipatedFundsFlow: MID: {}, Initial status: {}."
			  		  ,pdo.getMID(), pdo.getString(P_MSG_STS));
			    
			    //before changing status to 'RECEIVED', set default values 
			    setDefaultValues(pdo);
			    
			    // Even if the payment enters this method with a non-(RECEIVED) status - e.g. REPAIR - 
			    // then it will get the right status again during the flow which will either fail or succeed.
			    // If the flow will succeed, status will be set eventually to COMPLETE.
			    pdo.set(P_MSG_STS, MESSAGE_STATUS_RECEIVED);			    
				break;
			case HandleExpiration:	
				handleExpiredAF(pdo);
				break;
			case ScheduleExpirationEvent:
				scheduleExpirationEvent(pdo);
				break;
			case Department_rule_selection:
				feedback = BOBaseProcess.executeMapPaymentInfoUsingRules(pdo.getMID(), RULE_TYPE_ID_DEPARTMENT, null);		    
				break;
			case Repair_and_enrichment:
				pdo.set(D_RULE_TYPE_ID, RULE_TYPE_ID_REPAIR_AND_ENRICHMENT_SELECTION);			    
			    feedback = m_enrichmentLogging.repairAndEnrich(admin);
				break;
			case BASE_currency_conversion:
				  pdo.set(D_CURRENCY_CONVERSION_TYPE, ConversionType.Base.toString());
			      feedback = BOProxies.m_currencyConversionLogging.performCurrencyConversion(admin, pdo.getMID());		    
				break;
			case Compliance_validation:
				if(MONITOR_FLAG_X.equals(pdo.getString(MF_COMPLIANCE_VALIDATION_STS))) {			      
			      String sOldStatus = pdo.getString(P_MSG_STS);
			      feedback = m_complianceLogging.performComplianceCheck(admin, pdo.getMID(),true);
			      
			      String sMF_COMPLIANCE_VALIDATION_STS = pdo.getString(MF_COMPLIANCE_VALIDATION_STS);
			      String sMU_COMPLIANCE_OVERRIDE_STS = pdo.getString(MU_COMPLIANCE_FORCE_STS);
			      
			      if(   (MONITOR_FLAG_COMPLIANCE_HIT.equals(sMF_COMPLIANCE_VALIDATION_STS) && !MONITOR_FLAG_FORCE.equals(sMU_COMPLIANCE_OVERRIDE_STS))
			      	 || MONITOR_FLAG_COMPLIANCE_WAIT.equals(sMF_COMPLIANCE_VALIDATION_STS))
			      {
			      	pdo.set(P_MSG_STS, MESSAGE_STATUS_COMPEX);
			      }
			      
			      //if message status had been changed, the Feedback would be marked as failure 
			      //The message status could have been set also to REPAIR in case no compliance validation rule was found.			      
			      BOBaseProcess.compareMessageStatusBeforeAfter(sOldStatus, pdo, COMPLIANCE_MODULE, feedback);			      
			    }
				break;
			case Duplicate_check:
				 String sOldStatus = pdo.getString(P_MSG_STS);
			     GlobalAbstractResponseDataComponent response = m_matchingCheckLogging.performDuplicateCheck(admin, pdo.getMID());
			     feedback = response.getFeedback();
			     BOBaseProcess.compareMessageStatusBeforeAfter(sOldStatus, pdo, DUPLICATE_CHECK_MODULE, feedback);
				break;
			case Debit_party_processing:
				feedback = m_internalAFPartyProcessingLogging.performPartyProcessing(admin, pdo.getMID(),BOPartyProcessing.PROCESSING_TYPE_DEBIT);
				if (!feedback.isSuccessful())
					setStatus(pdo,MESSAGE_STATUS_REPAIR);
				break;
			case Credit_party_processing:
				feedback = m_internalAFPartyProcessingLogging.performPartyProcessing(admin, pdo.getMID(),BOPartyProcessing.PROCESSING_TYPE_CREDIT);
				if (!feedback.isSuccessful())
					setStatus(pdo,MESSAGE_STATUS_REPAIR);
				break;
			case Message_classification:
			    feedback = BOBaseProcess.executeMapPaymentInfoUsingRules(pdo.getMID(), RULE_TYPE_ID_PAYMENT_CLASSIFICATION, null);
			    if (MSG_CLASS_NAC.equals(pdo.get(P_MSG_CLASS))) {
			    	logger.debug("message was classified as {}, set the 210 match monitor status to {} and stop processing",MSG_CLASS_NAC,AF_MATCH_STATUS_NONE);			    	
			    	pdo.set(P_MSG_STS,MESSAGE_STATUS_COMPLETE); //candidate for overridden by STP rule
			    	pdo.set(MF_AF_MATCH_STS, AF_MATCH_STATUS_NONE);
			    }
			    break;
			case Matching_to_Payment:
				feedback = BOProxies.m_anticipatedFundsLogging.matchAnticipatedFundTo(admin, pdo.getMID());
				break;
			case MOP_selection:
				enableMopSelection(pdo);
				
				MopSelectionOutputData mopSelectionOutputData = m_mopSelectionLogging.performMopSelection(admin, pdo.getMID());
				
				if (pdo.getString(MF_MOP_SELECTION_STS).equals(MONITOR_FLAG_FAILURE))
		        	  feedback = mopSelectionOutputData.getFeedback();
		        else 
		            feedback.setSuccess();		          
				break;
			case Complete:
				//unclean handling of 'Complete' step, TBD well defining
				if (!MESSAGE_STATUS_WAIT_MATCH.equals(pdo.get(P_MSG_STS)))
					setStatus(pdo,MESSAGE_STATUS_COMPLETE);
				break;
			case Validation_rules: 
				if (!(MESSAGE_STATUS_CANCELED.equals(pdo.get(P_MSG_STS))
						|| MESSAGE_STATUS_DUPEX.equals(pdo.get(P_MSG_STS))))
				feedback = BOBaseProcess.executeValidationSelectionRule(pdo,pdo.getString(P_MSG_STS));
				break;				
			case Gracefull_Termination:
				String status = (String)params[0];
				//TBD could use the HVF impl? 
				BOHighValueProcess.performTerminationSubFlow(pdo, status);
				break;
		}
	} catch (Throwable e) {
		throw e;
	}
	
	return feedback;	
  } 
  
	private void setDefaultValues(PDO pdo) {  		
  		//set the swift direction for manually created AF
  		if (MESSAGE_STATUS_RECEIVED.equals(pdo.getString(P_MSG_STS))
  			&& StringUtils.isEmpty(pdo.getString(X_SWIFT_DIRECTION_IND))) 
  			pdo.set(X_SWIFT_DIRECTION_IND,"I");
  		
	    //set the AF_TYPE for incoming AF's or created AF with no type
	    if (StringUtils.isEmpty(pdo.getString(P_AF_TYPE))) 
	    	pdo.set(P_AF_TYPE,AF_TYPE_PREADVICE);
	    
	    if (isEarmarked(pdo) && StringUtils.isEmpty(pdo.getString(P_AF_EXPIRE_TIME))) {
			  logger.debug("setting earmark default expiration time to EOD (23:59)");
			  pdo.set(P_AF_EXPIRE_TIME,"23:59");
		}
  	}

	private void enableMopSelection(PDO pdo) {
  		if("true".equals(pdo.get(D_THROTTLING_MANUAL_MOP_SELECTION))) {
	    	logger.debug("switch from manual Mop Selection to none manual Mop Selection");
	    	pdo.set(MF_MOP_SELECTION_STS,MONITOR_FLAG_X);
	    }	
  	}
	
  	private void handleExpiredAF(PDO pdo) {
  		handleCanceldAF(pdo);
		ErrorAuditUtils.setErrors(new ProcessError(AnticipatedFundsExpired,pdo.getIsHistory()));
  	}
  	
  	private void handleCanceldAF(PDO pdo) {
  		if (MESSAGE_STATUS_CANCELED.equals(pdo.get(P_MSG_STS))) {
  			logger.debug("expired AF already canceled.");
  			return;
  		}
  		
  		setStatus(pdo,MESSAGE_STATUS_CANCELED);
  		disallowMatch(pdo, MatchType.AF_Payment);		
  	}  	
}//class
