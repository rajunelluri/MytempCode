
package backend.paymentprocess.anticipatedfundsflow.businessobjects;

import static backend.core.module.MessageConstantsInterface.MSG_CLASS_NAC;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_MSG_CLASS;
import static backend.paymentprocess.anticipatedfundsflow.businessobjects.AnticipatedFundsExpiration.*;

import java.util.Arrays;
import java.util.ListIterator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.core.paymentprocess.data.PDO;

public class AnticipatedFundsFlowControl implements FlowControl {
	private static final Logger logger = LoggerFactory.getLogger(AnticipatedFundsFlowControl.class);
	
	private ListIterator<FlowStep> itrerator;
	private FlowStep lastStep = null;
	
	private PDO pdoAF;	
	
	public AnticipatedFundsFlowControl(PDO pdoAF) {
		this.pdoAF = pdoAF;
		initialize();
	}
		
	private void initialize() {	
		itrerator = Arrays.asList(FlowStep.values()).listIterator();				  		
	}

	public FlowStep lastStep() {
		return lastStep;
	}
	
	public FlowStep nextStep() {
		analayzeLastStepResult();
		
		FlowStep currentStep = itrerator.next();
		
		String skipReason = null;
		
		switch (currentStep) {
		case HandleExpiration:
			if (!isExpiredAF(pdoAF)) 
				skipReason = "not an expired AF";									
			break;
		case Duplicate_check:
			if (!pdoAF.isNew()) 			
				skipReason = "not a new AF";								
		}
		
		if (skipReason != null) {
			logger.debug("{}, skipping {} step",skipReason,currentStep);
			return nextStep();
		}
		
		lastStep = currentStep;	
		
		return currentStep;	
	}

	private void analayzeLastStepResult() {
		if (lastStep == null)
			return;
		
		switch (lastStep) {
		case Message_classification:
			if (MSG_CLASS_NAC.equals(pdoAF.get(P_MSG_CLASS))) {
				logger.debug("classified as NAC, ending flow");
				forwardTo(FlowStep.EndFlow);
			}
			break;
		case HandleExpiration: 		
			logger.debug("AF was expired, ending flow");
			forwardTo(FlowStep.EndFlow);
			break;
		}
	}

	private void forwardTo(FlowStep step) {
		if (step == null)
			return;
		
		logger.debug("forwarding flow to '{}'",step);
		
		while (itrerator.hasNext()) {
			if (itrerator.next() == step) {
				itrerator.previous();
				break;
			}
		}
	}	
}
