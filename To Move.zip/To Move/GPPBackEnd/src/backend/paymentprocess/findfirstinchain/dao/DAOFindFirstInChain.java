package backend.paymentprocess.findfirstinchain.dao;

import backend.dataaccess.dao.DAOBasic;

/**
 * Title:       DAOFindFirstInChain
 * Description: DAO object for finding first in chain
 * Company:     Fundtech Israel
 * Author:      Asaf Levy
 * Date:        07/09/2008
 * @version     1.0
 */
public class DAOFindFirstInChain extends DAOBasic
{
  private static DAOFindFirstInChain m_daoFindFirstInChain = new DAOFindFirstInChain();
  
  /**
   * Private constructor. 
   */
  private DAOFindFirstInChain()
  {
  }
  
  public static DAOFindFirstInChain getInstance()
  {
  	return m_daoFindFirstInChain;
  }
}