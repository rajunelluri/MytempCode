package backend.paymentprocess.findfirstinchain.businessobjects;

import static com.fundtech.util.GlobalUtils.isListNullOrEmpty;
import static com.fundtech.util.GlobalUtils.isNullOrEmpty;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fundtech.annotations.Expose;
import com.fundtech.annotations.Wrap;
import com.fundtech.cache.entities.LogicalFields;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.fields.FieldType;
import com.fundtech.core.paymentprocess.errorhandling.ProcessError;
import com.fundtech.core.paymentprocess.findfirstinchain.FindFirstInChainConstants;
import com.fundtech.core.paymentprocess.findfirstinchain.MessageChainsData;
import com.fundtech.core.paymentprocess.findfirstinchain.FindFirstInChainConstants.ChainType;
import com.fundtech.core.paymentprocess.findfirstinchain.FindFirstInChainConstants.ChainTypeOrigin;
import com.fundtech.core.paymentprocess.findfirstinchain.FindFirstInChainConstants.FirstInChainType;
import com.fundtech.core.paymentprocess.findfirstinchain.MessageChainsData.ChainData;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.errors.ProcessErrorConstants;
import com.fundtech.util.ExceptionController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import backend.businessobject.BOBasic;
import backend.businessobject.proxies.LoadPDO;
import backend.core.module.MessageConstantsInterface;
import backend.paymentprocess.erroraudit.ErrorAuditUtils;
import backend.paymentprocess.findfirstinchain.exception.FindFirstInChainException;
import backend.paymentprocess.stprules.businessobjects.BOSTPRules;
import backend.util.ServerConstants;


/**
 * Title:       BOFindFirstInChain
 * Description: Business object for finding first in chain
 * Company:     Fundtech Israel
 * Author:      Asaf Levy
 * Date:        07/09/2008
 * @version     1.0
 */
@Wrap(interceptionSet="PdoHandling") 

public class BOFindFirstInChain extends BOBasic implements PDOConstantFieldsInterface, MessageConstantsInterface
{

	private static final Logger logger = LoggerFactory.getLogger(BOFindFirstInChain.class);
  // Constants. 
  //
  // Process errors.
  private static final ProcessError PROCESS_ERROR_UNABLE_TO_IDENTIFY_FIRST_IN_CREDIT_CHAIN = new ProcessError(ProcessErrorConstants.UnableToIdentifyFirstInCreditChain);
  private static final ProcessError PROCESS_ERROR_UNABLE_TO_IDENTIFY_FIRST_IN_DEBIT_CHAIN = new ProcessError(ProcessErrorConstants.UnableToIdentifyFirstInDebitChain);
  
  // Map in which:
  //  Key - Credit chain type, (Receiver,Correspondent,IntermediaryAgent,CreditorAgent,Creditor).
  //  Value - Map in which:
  //           Key - ChainTypeOrigin, ('BIC' or 'NCC' for now).
  //           Value - List of one or more field names.
  private static Map<ChainType, Map<ChainTypeOrigin, List<String>>> m_mapCreditChainMappedFields = null;
  
	// Ncc type: FW, ISO code: USABA, (see definition in COUNTRY_NCC).
  private static final String CLRSYS_CODE_USABA = "USABA";
  
  /**
   * 
   */
  private static void initCreditChainMappedFieldsMap()
  {
  	
  	
  	m_mapCreditChainMappedFields = new HashMap<ChainType, Map<ChainTypeOrigin, List<String>>>();
  	
  	// Receiver.
  	Map<ChainTypeOrigin, List<String>> mapReceiverChainTypeFields = new HashMap<ChainTypeOrigin, List<String>>();
  	//
  	List<String> listReceiverBICFields = new ArrayList();
  	listReceiverBICFields.add(X_INSTD_AGT_BIC_2AND);
  	mapReceiverChainTypeFields.put(ChainTypeOrigin.BIC, listReceiverBICFields);
  	m_mapCreditChainMappedFields.put(ChainType.Receiver, mapReceiverChainTypeFields);
  	
  	// Correspondent.
  	Map<ChainTypeOrigin, List<String>> mapCorrespondentChainTypeFields = new HashMap<ChainTypeOrigin, List<String>>();
  	//
  	List<String> listCorrespondentBICFields = new ArrayList();
  	listCorrespondentBICFields.add(P_CORRESPONDENT);
  	mapCorrespondentChainTypeFields.put(ChainTypeOrigin.BIC, listCorrespondentBICFields);
  	m_mapCreditChainMappedFields.put(ChainType.Correspondent, mapCorrespondentChainTypeFields);
  	
  	// IntermediaryAgent.
  	Map<ChainTypeOrigin, List<String>> mapIntermediaryAgentChainTypeFields = new HashMap<ChainTypeOrigin, List<String>>();
  	//
  	List<String> listIntermediaryAgentBICFields = new ArrayList();
  	listIntermediaryAgentBICFields.add(X_INTRMY_AGT1_BIC_2AND);
  	mapIntermediaryAgentChainTypeFields.put(ChainTypeOrigin.BIC, listIntermediaryAgentBICFields);
  	//
  	List<String> listIntermediaryAgentNCCFields = new ArrayList();
  	listIntermediaryAgentNCCFields.add(X_INTRMY_AGT1_CLR_SYS_CD); // NCC code.
  	listIntermediaryAgentNCCFields.add(X_INTRMY_AGT1_CLR_SYS_PRTRY); // NCC proprietary.
  	listIntermediaryAgentNCCFields.add(X_INTRMY_AGT1_ID_2AND); // NCC member ID.
  	mapIntermediaryAgentChainTypeFields.put(ChainTypeOrigin.NCC, listIntermediaryAgentNCCFields);
  	//
  	m_mapCreditChainMappedFields.put(ChainType.IntermediaryAgent, mapIntermediaryAgentChainTypeFields);
  	
  	// CreditorAgent.
  	Map<ChainTypeOrigin, List<String>> mapCreditorAgentChainTypeFields = new HashMap<ChainTypeOrigin, List<String>>();
  	//
  	List<String> listCreditorAgentBICFields = new ArrayList();
  	listCreditorAgentBICFields.add(X_CDTR_AGT_BIC_2AND);
  	//listCreditorAgentBICFields.add(X_CDTR_AGT_ID_2AND); // Initialized from NCC code or propietary in case X_CDTR_AGT_BIC_2AND is null.
  	mapCreditorAgentChainTypeFields.put(ChainTypeOrigin.BIC, listCreditorAgentBICFields);
  	//
  	List<String> listCreditorAgentNCCFields = new ArrayList();
  	listCreditorAgentNCCFields.add(X_CDTR_AGT_CLR_SYS_CD); // NCC code.
  	listCreditorAgentNCCFields.add(X_CDTR_AGT_CLR_SYS_PRTRY); // NCC proprietary.
  	listCreditorAgentNCCFields.add(X_CDTR_AGT_ID_2AND); // NCC member ID.
  	mapCreditorAgentChainTypeFields.put(ChainTypeOrigin.NCC, listCreditorAgentNCCFields);
  	//
  	m_mapCreditChainMappedFields.put(ChainType.CreditorAgent, mapCreditorAgentChainTypeFields);

  	// Creditor.
  	Map<ChainTypeOrigin, List<String>> mapCreditorChainTypeFields = new HashMap<ChainTypeOrigin, List<String>>();
  	//
  	List<String> listCreditorBICFields = new ArrayList();
  	listCreditorBICFields.add(X_CDTR_BIC);
  	mapCreditorChainTypeFields.put(ChainTypeOrigin.BIC, listCreditorBICFields);
  	//
  	List<String> listCreditorNCCFields = new ArrayList();
  	listCreditorNCCFields.add(X_CDTR_CLR_SYS_CD); // NCC code.
  	listCreditorNCCFields.add(X_CDTR_CLR_SYS_PRTRY); // NCC proprietary.
  	listCreditorNCCFields.add(X_CDTR_ID); // NCC member ID.
  	mapCreditorChainTypeFields.put(ChainTypeOrigin.NCC, listCreditorNCCFields);
  	//  		
  	m_mapCreditChainMappedFields.put(ChainType.Creditor, mapCreditorChainTypeFields);
  	
  	
  }

  /**
   * 
   */
  private static List<String> getSpecificCreditChainFieldToMap(ChainType chainType, ChainTypeOrigin chainTypeOrigin)
  {
  	final String TRACE_METHOD_INPUT = "Method input - Chain type: {}, Chain type origin: {}.";
  	final String TRACE_METHOD_RESULT = "Returned valid list of fields for passed chain type and chain type origin: {}.";
  	
  	
  	
  	List<String> listFields = null;
  	logger.info(TRACE_METHOD_INPUT, chainType, chainTypeOrigin);
  	
  	if(m_mapCreditChainMappedFields == null)
  	{
  		initCreditChainMappedFieldsMap();
  	}
  	
  	Map<ChainTypeOrigin, List<String>> mapChainTypeFields = m_mapCreditChainMappedFields.get(chainType);
  	
  	if(mapChainTypeFields != null)
  	{
  		listFields = mapChainTypeFields.get(chainTypeOrigin);
  	}
  	
  	logger.info(TRACE_METHOD_RESULT, !isListNullOrEmpty(listFields));
  	
  	
  	return listFields;
  }
  
  /**
   * 
   */
  public static List<String> getSpecificCreditChainFieldToMap(int iIndex, ChainTypeOrigin chainTypeOrigin)
  {
  	final String TRACE_METHOD_INPUT = "Method input - Index: {}, Chain type origin: {}.";
  	final String TRACE_METHOD_RESULT = "Returned field names to map: {}.";

  	
  	logger.info(TRACE_METHOD_INPUT, iIndex, chainTypeOrigin);
  	
  	List<String> listRetFieldNamesToMap = null;
  	StringBuilder sbReturnedFieldNames = null;
  	
  	// Returns: Receiver,Correspondent,IntermediaryAgent,CreditorAgent,Creditor.
  	ChainType chainType = FindFirstInChainConstants.ChainType.arrFirstInCreditChainType[iIndex]; 
  	
  	List<String> listFieldsToMap = getSpecificCreditChainFieldToMap(chainType, chainTypeOrigin);
  	
  	if(!isListNullOrEmpty(listFieldsToMap))
  	{
  		listRetFieldNamesToMap = new ArrayList<String>();
  		
  		int iSize = listFieldsToMap.size();
  		PDO pdo = Admin.getContextPDO();
  		
  		// BIC.
  		// List size is 1 or 2.
  		if(ChainTypeOrigin.BIC.equals(chainTypeOrigin))
  		{
    		if(iSize == 1) listRetFieldNamesToMap.add(listFieldsToMap.get(0));
    		
    		else // size = 2; adds to the returned list either index 0 or index 1.
    		{
    			listRetFieldNamesToMap.add(pdo.getString(listFieldsToMap.get(0)) != null ? listFieldsToMap.get(0) : listFieldsToMap.get(1));
    		}
  		}
  		
  		// NCC.
  		// List size is always 3.
  		else if(ChainTypeOrigin.NCC.equals(chainTypeOrigin))
  		{
  			listRetFieldNamesToMap.addAll(listFieldsToMap);
//  			// Adds to the returned list either index 0 or index 1, (NCC code or NCC proprietary).
//  			listRetFieldNamesToMap.add(pdo.getString(listFieldsToMap.get(0)) != null ? listFieldsToMap.get(0) : listFieldsToMap.get(1));
//  			
//  			// Adds to the returned list index 2 which stands for the NCC member ID.
//  			listRetFieldNamesToMap.add(listFieldsToMap.get(2));
  		}
  		
  		sbReturnedFieldNames = new StringBuilder();
  		int iRetListSize = listRetFieldNamesToMap.size();
  		for(int i=0; i<iRetListSize; i++)
  		{
  			sbReturnedFieldNames.append(listRetFieldNamesToMap.get(i));
  			if(i < (iRetListSize-1)) sbReturnedFieldNames.append(ServerConstants.COMMA_SPACE);
  		}
  	}
  	
  	logger.info(TRACE_METHOD_RESULT, sbReturnedFieldNames.toString());
  	
  	
  	return listRetFieldNamesToMap;
  }
  
  /**
   * 
   */
  public static void setChainField(Boolean bCreditSide, Integer iChainIndex, ChainTypeOrigin chainTypeOrigin, String sValue)
  {
  	final String INPUT_DATA = "Method input - Credit side: {}, Chain index: {}}, Chain type origin: {}, Value to set: {}.";
  	final String TRACE_RELATED_FIELD_NAME = "Related field name is: {}.";
  	final String TRACE_NULL_RELATED_FIELD_NAME = "ERROR: Null related field name was received; no set will be done into the PDO!!";
  	
  	
  	
  	logger.info(INPUT_DATA,  new Object[]{bCreditSide, iChainIndex, chainTypeOrigin, sValue});
  	
  	String sRelatedFieldName = ChainType.getChainIndexRelatedFieldName(bCreditSide, iChainIndex, chainTypeOrigin);
  	logger.info(TRACE_RELATED_FIELD_NAME, sRelatedFieldName);
  	
  	if(sRelatedFieldName != null)
  	{
  		Admin.getContextPDO().set(sRelatedFieldName, sValue);
  	}
  	
  	else
  	{
  		logger.info(TRACE_NULL_RELATED_FIELD_NAME);
  	}
  	
  	
  }
  
  /**
   * Finds the first in chain of either credit or debit side for the passed MID.
   */
  @LoadPDO
  @Expose
  public Feedback findFirstInChain(final String sMID) throws FindFirstInChainException
  {
    final String EXCEPTION_MESSAGE = "Exception has occured in 'BOFindFirstInChain.findFirstInChain'.";
    final String INPUT_DATA = "First in chain type = {}.";
    
    
    
    Feedback feedback = null;
    
    PDO pdo = Admin.getContextPDO();
    
    // Gets what type of first in chain needs to be found: credit or debit.
    String sFindFirstInChainType = pdo.getString(D_FIND_FIRST_IN_CHAIN_TYPE);
    logger.info(INPUT_DATA, sFindFirstInChainType);
    
    try
    {
      // Credit side.
      if(sFindFirstInChainType.equals(FirstInChainType.Credit.toString()))
      {
        feedback = findFirstInCreditChain();
      }
      
      else // Debit.
      {
        feedback = findFirstInDebitChain();
      }
    }
    catch(Exception e)
    {
      ExceptionController.getInstance().handleException(e, this);
      
      String sOriginalExceptionMessage = e.getMessage();
      String sExceptionMessage = sOriginalExceptionMessage != null ? 
                                 sOriginalExceptionMessage : EXCEPTION_MESSAGE;
      throw new FindFirstInChainException(sExceptionMessage, e);
    }
    
         

    return feedback;
  }
  
  /**
   * 
   */
  public static boolean getCREDIT_RecieverFirstInChain(PDO pdo, FirstInChainDataHolder firstInChainDataHolder)
  {
  	final String X_INSTD_AGT_BIC_2AND_VALUE = "X_INSTD_AGT_BIC_2AND: {}";
  	final String X_INSTD_AGT_CLR_SYS_CD_VALUE = "X_INSTD_AGT_CLR_SYS_CD: {}";
  	final String X_INSTD_AGT_CLR_SYS_PRTRY_VALUE = "X_INSTD_AGT_CLR_SYS_PRTRY: {}";
  	final String X_INSTD_AGT_ID_2AND_VALUE = "X_INSTD_AGT_ID_2AND: {}";
  	
  	
  	
  	boolean bFoundFirstInChain = false;
  	
  	// BIC.
    String sReceiverBIC = pdo.getString(X_INSTD_AGT_BIC_2AND);
    logger.info(X_INSTD_AGT_BIC_2AND_VALUE, sReceiverBIC);
    
    if(!isNullOrEmpty(sReceiverBIC))
    {
      bFoundFirstInChain = true;
      firstInChainDataHolder.setChainTypeOrigin(ChainTypeOrigin.BIC);
      firstInChainDataHolder.setBICValue(sReceiverBIC);
      firstInChainDataHolder.setBICFieldName(X_INSTD_AGT_BIC_2AND);
    }
    
    // NCC
    String sX_INSTD_AGT_CLR_SYS_PRTRY = null; // NCC proprietary.
    //
    // NCC Code ID.
    String sX_INSTD_AGT_CLR_SYS_CD = pdo.getString(X_INSTD_AGT_CLR_SYS_CD);
    logger.info(X_INSTD_AGT_CLR_SYS_CD_VALUE, sX_INSTD_AGT_CLR_SYS_CD);
    if(!isNullOrEmpty(sX_INSTD_AGT_CLR_SYS_CD))
    {
      bFoundFirstInChain = true;
      firstInChainDataHolder.setNCCCodeValue(sX_INSTD_AGT_CLR_SYS_CD);
      firstInChainDataHolder.setNCCCodeFieldName(X_INSTD_AGT_CLR_SYS_CD);      
    }
    //
    // No NCC code ID, checks for NCC proprietary.
    else
    {
    	sX_INSTD_AGT_CLR_SYS_PRTRY = pdo.getString(X_INSTD_AGT_CLR_SYS_PRTRY);
      logger.info(X_INSTD_AGT_CLR_SYS_PRTRY_VALUE, sX_INSTD_AGT_CLR_SYS_PRTRY);	      	
      if(!isNullOrEmpty(sX_INSTD_AGT_CLR_SYS_PRTRY))
      {
        bFoundFirstInChain = true;
        firstInChainDataHolder.setNCCProprietaryValue(sX_INSTD_AGT_CLR_SYS_PRTRY);
        firstInChainDataHolder.setNCCProprietaryFieldName(X_INSTD_AGT_CLR_SYS_PRTRY);        
      }
    }
    //
    if(!isNullOrEmpty(sX_INSTD_AGT_CLR_SYS_CD) || !isNullOrEmpty(sX_INSTD_AGT_CLR_SYS_PRTRY))
    {	      
      // NCC member ID.
      String sX_INSTD_AGT_ID_2AND = pdo.getString(X_INSTD_AGT_ID_2AND);
      logger.info(X_INSTD_AGT_ID_2AND_VALUE, sX_INSTD_AGT_ID_2AND);
      firstInChainDataHolder.setNCCMemberIDValue(sX_INSTD_AGT_ID_2AND);
      firstInChainDataHolder.setNCCMemberIDFieldName(X_INSTD_AGT_ID_2AND);
    }    
    
    // Name.
    if(getChainSingleField(X_INSTD_AGT_NM_2AND, ChainTypeOrigin.NAME, D_FIRST_IN_CDT_CHAIN_NAME, D_1ST_CDT_CHA_NAME_FLD_ID, firstInChainDataHolder))
    {
    	bFoundFirstInChain = true;

	    // Sets chain type origin to NAME only if first in chain wasn't found in the BIC field.
	    if(isNullOrEmpty(sReceiverBIC)) firstInChainDataHolder.setChainTypeOrigin(ChainTypeOrigin.NAME);
    }
    
    // Address.
    if(getChainSingleField(X_INSTD_AGT_ADRLINE_2AND, ChainTypeOrigin.ADDR, D_FIRST_IN_CDT_CHAIN_ADDR, D_1ST_CDT_CHA_ADDR_FLD_ID, firstInChainDataHolder))
    {
    	bFoundFirstInChain = true;

	    // Sets chain type origin to ADDR only if first in chain wasn't found in the BIC/Name fields.
	    if(isNullOrEmpty(sReceiverBIC) && firstInChainDataHolder.getChainTypeOrigin() != ChainTypeOrigin.NAME)
	    {
	    	firstInChainDataHolder.setChainTypeOrigin(ChainTypeOrigin.ADDR);
	    }
    }
    
    firstInChainDataHolder.setChainTypeName(ChainType.Receiver);
    
    
    
    return bFoundFirstInChain;
  }
  
  /**
   * 
   */
  public static boolean getCREDIT_CorrespondentFirstInChain(PDO pdo, FirstInChainDataHolder firstInChainDataHolder)
  {
  	final String P_CORRESPONDENT_VALUE = "P_CORRESPONDENT: {}";
  	
  	
  	
  	boolean bFoundFirstInChain = false;
  	
    String sCorrespondentBIC = pdo.getString(P_CORRESPONDENT);
    logger.info(P_CORRESPONDENT_VALUE, sCorrespondentBIC);
    
    if(!isNullOrEmpty(sCorrespondentBIC))
    {
      bFoundFirstInChain = true;
      firstInChainDataHolder.setChainTypeName(ChainType.Correspondent);
      firstInChainDataHolder.setChainTypeOrigin(ChainTypeOrigin.BIC);
      firstInChainDataHolder.setBICValue(sCorrespondentBIC);
      firstInChainDataHolder.setBICFieldName(P_CORRESPONDENT);
    }
  	
    
    
    return bFoundFirstInChain;
  }
  
  /**
   * SWIFT: field 56.
   */
  public static boolean getCREDIT_IntermediaryAgentFirstInChain(PDO pdo, FirstInChainDataHolder firstInChainDataHolder)
  {
  	final String X_INTRMY_AGT1_BIC_2AND_VALUE = "X_INTRMY_AGT1_BIC_2AND: {}";
  	final String X_INTRMY_AGT1_ACCT_IBAN_VALUE = "X_INTRMY_AGT1_ACCT_IBAN: {}";
  	final String X_INTRMY_AGT1_ACCT_ID_VALUE = "X_INTRMY_AGT1_ACCT_ID: {}";
  	final String X_INTRMY_AGT1_CLR_SYS_CD_VALUE = "X_INTRMY_AGT1_CLR_SYS_CD: {}";
  	final String X_INTRMY_AGT1_CLR_SYS_PRTRY_VALUE = "X_INTRMY_AGT1_CLR_SYS_PRTRY: {}";
  	final String X_INTRMY_AGT1_ID_2AND_VALUE = "X_INTRMY_AGT1_ID_2AND: {}";
  	
  	
  	
  	boolean bFoundFirstInChain = false;
  	boolean bIsUSABA = false;
  	
  	// BIC.
    String sIntermediaryAgentBIC = pdo.getString(X_INTRMY_AGT1_BIC_2AND);
    logger.info(X_INTRMY_AGT1_BIC_2AND_VALUE, sIntermediaryAgentBIC);
    if(!isNullOrEmpty(sIntermediaryAgentBIC))
    {
      bFoundFirstInChain = true;
	    firstInChainDataHolder.setChainTypeOrigin(ChainTypeOrigin.BIC);
	    firstInChainDataHolder.setBICValue(sIntermediaryAgentBIC);
	    firstInChainDataHolder.setBICFieldName(X_INTRMY_AGT1_BIC_2AND);
    }
    
    // IBAN.
    String sIntermediaryAgentIBAN = pdo.getString(X_INTRMY_AGT1_ACCT_IBAN);
    logger.info(X_INTRMY_AGT1_ACCT_IBAN_VALUE, sIntermediaryAgentIBAN);
    if(!isNullOrEmpty(sIntermediaryAgentIBAN))
    {
      bFoundFirstInChain = true;
	    firstInChainDataHolder.setIBANValue(sIntermediaryAgentIBAN);
	    firstInChainDataHolder.setIBANFieldName(X_INTRMY_AGT1_ACCT_IBAN);
      
      // Sets chain type origin to IBAN only if first in chain wasn't found in the BIC field.
      if(isNullOrEmpty(sIntermediaryAgentBIC)) firstInChainDataHolder.setChainTypeOrigin(ChainTypeOrigin.IBAN);
    }
    
    // Account number.
    String sIntermediaryAgentAccountID = pdo.getString(X_INTRMY_AGT1_ACCT_ID);
    logger.info(X_INTRMY_AGT1_ACCT_ID_VALUE, sIntermediaryAgentAccountID);
    if(!isNullOrEmpty(sIntermediaryAgentAccountID))
    {
      bFoundFirstInChain = true;
      
      // Handles account cleanup according to char sets profiles definition.
      sIntermediaryAgentAccountID = BOSTPRules.replaceStringUsingCharSetDefinition(sIntermediaryAgentAccountID, pdo.getString(P_OFFICE), null);
      pdo.set(X_INTRMY_AGT1_ACCT_ID, sIntermediaryAgentAccountID);
      
	    firstInChainDataHolder.setAccountNumberValue(sIntermediaryAgentAccountID);
	    firstInChainDataHolder.setAccountNumberFieldName(X_INTRMY_AGT1_ACCT_ID);
      
      // Sets chain type origin to ACC only if first in chain wasn't found in the BIC/IBAN fields.
      if(isNullOrEmpty(sIntermediaryAgentBIC) && isNullOrEmpty(sIntermediaryAgentIBAN))
      	                       firstInChainDataHolder.setChainTypeOrigin(ChainTypeOrigin.ACC);
    }
    
    // NCC.
    String sX_INTRMY_AGT1_CLR_SYS_PRTRY = null; // NCC proprietary.
    //
    // NCC Code ID.
    String sX_INTRMY_AGT1_CLR_SYS_CD = pdo.getString(X_INTRMY_AGT1_CLR_SYS_CD);
    logger.info(X_INTRMY_AGT1_CLR_SYS_CD_VALUE, sX_INTRMY_AGT1_CLR_SYS_CD);
    if(!isNullOrEmpty(sX_INTRMY_AGT1_CLR_SYS_CD))
    {
        bFoundFirstInChain = true;
        if(CLRSYS_CODE_USABA.equals(sX_INTRMY_AGT1_CLR_SYS_CD))
         {
           bIsUSABA = true;
         }
         else
         {
            firstInChainDataHolder.setNCCCodeValue(sX_INTRMY_AGT1_CLR_SYS_CD);
            firstInChainDataHolder.setNCCCodeFieldName(X_INTRMY_AGT1_CLR_SYS_CD);
         }
    }
    //
    // No NCC code ID, checks for NCC proprietary.
    else
    {
    	sX_INTRMY_AGT1_CLR_SYS_PRTRY = pdo.getString(X_INTRMY_AGT1_CLR_SYS_PRTRY);
      logger.info(X_INTRMY_AGT1_CLR_SYS_PRTRY_VALUE, sX_INTRMY_AGT1_CLR_SYS_PRTRY);	      	
      if(!isNullOrEmpty(sX_INTRMY_AGT1_CLR_SYS_PRTRY))
      {
        bFoundFirstInChain = true;
        firstInChainDataHolder.setNCCProprietaryValue(sX_INTRMY_AGT1_CLR_SYS_PRTRY);
        firstInChainDataHolder.setNCCProprietaryFieldName(X_INTRMY_AGT1_CLR_SYS_PRTRY);
      }
    }
    //
    // NCC member ID; initializes it even if no NCC code or proprietary were found.
    String sX_INTRMY_AGT1_ID_2AND = pdo.getString(X_INTRMY_AGT1_ID_2AND);
    logger.info(X_INTRMY_AGT1_ID_2AND_VALUE, sX_INTRMY_AGT1_ID_2AND);
    if(!isNullOrEmpty(sX_INTRMY_AGT1_ID_2AND))
    {
    	bFoundFirstInChain = true;
    
	    // Set the value of member id in BIC if the clearing code is USABA.
	    if(bIsUSABA)
	    {
	      firstInChainDataHolder.setBICValue(sX_INTRMY_AGT1_ID_2AND);
	      firstInChainDataHolder.setBICFieldName(X_INTRMY_AGT1_ID_2AND);
	    }
	    else
	    {
	      firstInChainDataHolder.setNCCMemberIDValue(sX_INTRMY_AGT1_ID_2AND);
	      firstInChainDataHolder.setNCCMemberIDFieldName(X_INTRMY_AGT1_ID_2AND);
	    }
	  
	    // Sets chain type origin to NCC only if first in chain wasn't found in the BIC/IBAN/ACC fields.
	    if(isNullOrEmpty(sIntermediaryAgentBIC) && isNullOrEmpty(sIntermediaryAgentIBAN) && isNullOrEmpty(sIntermediaryAgentAccountID)) 
	  	                       firstInChainDataHolder.setChainTypeOrigin(ChainTypeOrigin.NCC);
    }
    
    // Name.
    if(getChainSingleField(X_INTRMY_AGT1_NM_2AND, ChainTypeOrigin.NAME, D_FIRST_IN_CDT_CHAIN_NAME, D_1ST_CDT_CHA_NAME_FLD_ID, firstInChainDataHolder))
    {
    	bFoundFirstInChain = true;

      // Sets chain type origin to NAME only if first in chain wasn't found in the BIC/IBAN/Account/NCC fields.
      if(   isNullOrEmpty(sIntermediaryAgentBIC) && isNullOrEmpty(sIntermediaryAgentIBAN) && isNullOrEmpty(sIntermediaryAgentAccountID)
      	 && isNullOrEmpty(sX_INTRMY_AGT1_CLR_SYS_CD) && isNullOrEmpty(sX_INTRMY_AGT1_CLR_SYS_PRTRY)	&& isNullOrEmpty(sX_INTRMY_AGT1_ID_2AND)) 
      {
      	firstInChainDataHolder.setChainTypeOrigin(ChainTypeOrigin.NAME);
      }
    }
    
    // Address.
    if(getChainSingleField(X_INTRMY_AGT1_ADRLINE_2AND, ChainTypeOrigin.ADDR, D_FIRST_IN_CDT_CHAIN_ADDR, D_1ST_CDT_CHA_ADDR_FLD_ID, firstInChainDataHolder))
    {
    	bFoundFirstInChain = true;

      // Sets chain type origin to ADDR only if first in chain wasn't found in the BIC/IBAN/Account/NCC/Name fields.
      if(   isNullOrEmpty(sIntermediaryAgentBIC) && isNullOrEmpty(sIntermediaryAgentIBAN) && isNullOrEmpty(sIntermediaryAgentAccountID)
      	 && isNullOrEmpty(sX_INTRMY_AGT1_CLR_SYS_CD) && isNullOrEmpty(sX_INTRMY_AGT1_CLR_SYS_PRTRY)	&& isNullOrEmpty(sX_INTRMY_AGT1_ID_2AND)
      	 && firstInChainDataHolder.getChainTypeOrigin() != ChainTypeOrigin.NAME) 
      {
      	firstInChainDataHolder.setChainTypeOrigin(ChainTypeOrigin.ADDR);
      }
    }
    
    if(bFoundFirstInChain) firstInChainDataHolder.setChainTypeName(ChainType.IntermediaryAgent);
  	
    
    
    return bFoundFirstInChain;
  }
  
  /**
   * SWIFT: field 57.
   */
  public static boolean getCREDIT_CreditorAgentFirstInChain(PDO pdo, FirstInChainDataHolder firstInChainDataHolder)
  {
  	final String X_CDTR_AGT_BIC_2AND_VALUE = "X_CDTR_AGT_BIC_2AND: {}";
  	final String X_CDTR_AGT_ACCT_IBAN_VALUE = "X_CDTR_AGT_ACCT_IBAN: {}";
  	final String X_CDTR_ACCT_IBAN_VALUE = "X_CDTR_ACCT_IBAN: {}";
  	final String X_CDTR_AGT_ACCT_ID_VALUE = "X_CDTR_AGT_ACCT_ID: {}";
  	final String X_CDTR_AGT_CLR_SYS_CD_VALUE = "X_CDTR_AGT_CLR_SYS_CD: {}";
  	final String X_CDTR_AGT_CLR_SYS_PRTRY_VALUE = "X_CDTR_AGT_CLR_SYS_PRTRY: {}";
  	final String X_CDTR_AGT_ID_2AND_VALUE = "X_CDTR_AGT_ID_2AND: {}";
  	
  	
  	
  	ChainType chainType = firstInChainDataHolder.getChainType();
  	
  	boolean bFoundFirstInChain = false;
  	boolean bSkipNCCStep = false;
  	
  	// Used both in BIC and NCC.
  	String sX_CDTR_AGT_CLR_SYS_CD = null; // NCC code.
  	String sX_CDTR_AGT_CLR_SYS_PRTRY = null; // NCC proprietary.
  	String sX_CDTR_AGT_ID_2AND = null; // NCC member ID.
  	
    // BIC.
    String sCreditorAgentBIC = pdo.getString(X_CDTR_AGT_BIC_2AND);
    String sCreditorAgentABA = null;
    logger.info(X_CDTR_AGT_BIC_2AND_VALUE, sCreditorAgentBIC);
    if(!isNullOrEmpty(sCreditorAgentBIC))
    {
      bFoundFirstInChain = true;
      
      if(chainType == ChainType.IntermediaryAgent)
      {
      	firstInChainDataHolder.setCreditorAgentFieldValue(sCreditorAgentBIC);
      	firstInChainDataHolder.setCreditorAgentFieldName(X_CDTR_AGT_BIC_2AND);
      }
      else
      {
		    firstInChainDataHolder.setBICValue(sCreditorAgentBIC);
		    firstInChainDataHolder.setBICFieldName(X_CDTR_AGT_BIC_2AND);
      }
    }
    //
    // Didn't find X_CDTR_AGT_BIC_2AND field.
    // Checks if NCC code exists, (X_CDTR_AGT_CLR_SYS_CD), or if NCC proprietary exists, (X_CDTR_AGT_CLR_SYS_PRTRY);
    // if found one of them and value is 'USABA', then the value in 'X_CDTR_AGT_ID_2AND' should be used in load customer service 
    // for loading the customer using the CUSTOMRS.ABA column.
    // NOTE: If this is the case, then later on in this method, the NCC step will be skipped using the set of the 'bSkipNCCStep' boolean.
    if(!bFoundFirstInChain)
    {
      sX_CDTR_AGT_CLR_SYS_CD = pdo.getString(X_CDTR_AGT_CLR_SYS_CD);
      logger.info(X_CDTR_AGT_CLR_SYS_CD_VALUE, sX_CDTR_AGT_CLR_SYS_CD);
      
      // NCC code doesn't exist; looks for NCC proprietary.
      if(isNullOrEmpty(sX_CDTR_AGT_CLR_SYS_CD))
      {
      	sX_CDTR_AGT_CLR_SYS_PRTRY = pdo.getString(X_CDTR_AGT_CLR_SYS_PRTRY);
	      logger.info(X_CDTR_AGT_CLR_SYS_PRTRY_VALUE, sX_CDTR_AGT_CLR_SYS_PRTRY);
      }
      //
      // Found either NCC code or NCC proprietary that equals 'USABA'.
      if(   (!isNullOrEmpty(sX_CDTR_AGT_CLR_SYS_CD) && CLRSYS_CODE_USABA.equals(sX_CDTR_AGT_CLR_SYS_CD))
      	 || (!isNullOrEmpty(sX_CDTR_AGT_CLR_SYS_PRTRY) && CLRSYS_CODE_USABA.equals(sX_CDTR_AGT_CLR_SYS_PRTRY))	)
      {
      	bSkipNCCStep = true;
      
	      sCreditorAgentABA = pdo.getString(X_CDTR_AGT_ID_2AND);
	      String sFieldOrigin = X_CDTR_AGT_ID_2AND;
	      logger.info(X_CDTR_AGT_ID_2AND_VALUE, sCreditorAgentABA);
	      
	      if(!isNullOrEmpty(sCreditorAgentABA))
	      {
	        bFoundFirstInChain = true;
	
	        if(chainType == ChainType.IntermediaryAgent)
	        {
	        	firstInChainDataHolder.setCreditorAgentFieldValue(sCreditorAgentABA);
	        	firstInChainDataHolder.setCreditorAgentFieldName(sFieldOrigin);
	        }
	        else
	        {
	  		    firstInChainDataHolder.setBICValue(sCreditorAgentABA);
	  		    firstInChainDataHolder.setBICFieldName(sFieldOrigin);
	        }
	      }
	    }
    }
    //
    if(bFoundFirstInChain)
    {
    	if(chainType == ChainType.IntermediaryAgent) firstInChainDataHolder.setCreditorAgentChainTypeOrigin(ChainTypeOrigin.BIC);
    	else firstInChainDataHolder.setChainTypeOrigin(ChainTypeOrigin.BIC);
    }
     
    // IBAN.
    String sCreditorAgentIBAN = pdo.getString(X_CDTR_AGT_ACCT_IBAN);
    String sCreditorIBAN = null;
    logger.info(X_CDTR_AGT_ACCT_IBAN_VALUE, sCreditorAgentIBAN);
    if(!isNullOrEmpty(sCreditorAgentIBAN))
    {
      bFoundFirstInChain = true;
      
      if(chainType == ChainType.IntermediaryAgent)
      {
      	firstInChainDataHolder.setCreditorAgentFieldValue(sCreditorAgentIBAN);
      	firstInChainDataHolder.setCreditorAgentFieldName(X_CDTR_AGT_ACCT_IBAN);
      }
      else
      {
      	firstInChainDataHolder.setIBANValue(sCreditorAgentIBAN);
      	firstInChainDataHolder.setIBANFieldName(X_CDTR_AGT_ACCT_IBAN);
      }
    }
    //
    // No IBAN was found in this party; tries to get it from the 'Creditor' party.
    // Note that if there is a valid IBAN value is found here, (i.e. in the  'Creditor' party),
    // and we didn't found BIC above, there will be NO check/entrance later on into the 'Creditor' party, 
    // (getCREDIT_CreditorFirstInChain), and the BIC will remain empty !!!
    //
    // ASAF - 03/08/2010 - Remarked for NBG CR #103975.
//    else
//    {
//      sCreditorIBAN = pdo.getString(X_CDTR_ACCT_IBAN);
//      logger.info(X_CDTR_ACCT_IBAN_VALUE, sCreditorIBAN);
//      if(!isNullOrEmpty(sCreditorIBAN))
//      {
//        bFoundFirstInChain = true;
//        
//        if(chainType == ChainType.IntermediaryAgent)
//        {
//        	firstInChainDataHolder.setCreditorAgentFieldValue(sCreditorIBAN);
//        	firstInChainDataHolder.setCreditorAgentFieldName(X_CDTR_ACCT_IBAN);
//        }
//        else
//        {
//        	firstInChainDataHolder.setIBANValue(sCreditorIBAN);
//        	firstInChainDataHolder.setIBANFieldName(X_CDTR_ACCT_IBAN);
//        }
//      }        
//    }
    //
    // Sets chain type origin to IBAN only if first in chain wasn't found in the BIC field.
    if(bFoundFirstInChain && isNullOrEmpty(sCreditorAgentBIC) && isNullOrEmpty(sCreditorAgentABA))
    {
    	if(chainType == ChainType.IntermediaryAgent) firstInChainDataHolder.setCreditorAgentChainTypeOrigin(ChainTypeOrigin.IBAN);
    	else firstInChainDataHolder.setChainTypeOrigin(ChainTypeOrigin.IBAN);
    }
    
    // Account number.
    String sCreditorAgentAccountID = pdo.getString(X_CDTR_AGT_ACCT_ID);
    logger.info(X_CDTR_AGT_ACCT_ID_VALUE, sCreditorAgentAccountID);
    if(!isNullOrEmpty(sCreditorAgentAccountID))
    {
      bFoundFirstInChain = true;
      
      // Handles account cleanup according to char sets profiles definition.
      sCreditorAgentAccountID = BOSTPRules.replaceStringUsingCharSetDefinition(sCreditorAgentAccountID, pdo.getString(P_OFFICE), null);
      pdo.set(X_CDTR_AGT_ACCT_ID, sCreditorAgentAccountID);
      
      boolean bNoBICOrABAOrIBANExists = isNullOrEmpty(sCreditorAgentBIC) && isNullOrEmpty(sCreditorAgentABA)
    	         && isNullOrEmpty(sCreditorAgentIBAN) && isNullOrEmpty(sCreditorIBAN);
      
      if(chainType == ChainType.IntermediaryAgent && bNoBICOrABAOrIBANExists )
      {
      	firstInChainDataHolder.setCreditorAgentFieldValue(sCreditorAgentAccountID);
      	firstInChainDataHolder.setCreditorAgentFieldName(X_CDTR_AGT_ACCT_ID);
      }
      else
      {
      	firstInChainDataHolder.setAccountNumberValue(sCreditorAgentAccountID);
      	firstInChainDataHolder.setAccountNumberFieldName(X_CDTR_AGT_ACCT_ID);
      }
      
      // Sets chain type origin to ACC only if first in chain wasn't found in the BIC/IBAN fields.
      if( bNoBICOrABAOrIBANExists)
      {
      	if(chainType == ChainType.IntermediaryAgent) firstInChainDataHolder.setCreditorAgentChainTypeOrigin(ChainTypeOrigin.ACC);
      	else firstInChainDataHolder.setChainTypeOrigin(ChainTypeOrigin.ACC);
      }
    }
    
    // NCC.
    if(!bSkipNCCStep)
    {
      // NCC Code ID.
	    sX_CDTR_AGT_CLR_SYS_CD = pdo.getString(X_CDTR_AGT_CLR_SYS_CD);
	    logger.info(X_CDTR_AGT_CLR_SYS_CD_VALUE, sX_CDTR_AGT_CLR_SYS_CD);
	    if(!isNullOrEmpty(sX_CDTR_AGT_CLR_SYS_CD))
	    {
	      bFoundFirstInChain = true;
		    firstInChainDataHolder.setNCCCodeValue(sX_CDTR_AGT_CLR_SYS_CD);
		    firstInChainDataHolder.setNCCCodeFieldName(X_CDTR_AGT_CLR_SYS_CD);
	    }
      //
      // No NCC code ID, checks for NCC proprietary.
      else
      {
      	sX_CDTR_AGT_CLR_SYS_PRTRY = pdo.getString(X_CDTR_AGT_CLR_SYS_PRTRY);
	      logger.info(X_CDTR_AGT_CLR_SYS_PRTRY_VALUE, sX_CDTR_AGT_CLR_SYS_PRTRY);	      	
	      if(!isNullOrEmpty(sX_CDTR_AGT_CLR_SYS_PRTRY))
	      {
	        bFoundFirstInChain = true;
	        firstInChainDataHolder.setNCCProprietaryValue(sX_CDTR_AGT_CLR_SYS_PRTRY);
	        firstInChainDataHolder.setNCCProprietaryFieldName(X_CDTR_AGT_CLR_SYS_PRTRY);
	      }
      }
	    //
	    // NCC member ID; initializes it even if no NCC code or proprietary were found.	    
      sX_CDTR_AGT_ID_2AND = pdo.getString(X_CDTR_AGT_ID_2AND);
      logger.info(X_CDTR_AGT_ID_2AND_VALUE, sX_CDTR_AGT_ID_2AND);
      if(!isNullOrEmpty(sX_CDTR_AGT_ID_2AND))
      {
        bFoundFirstInChain = true;
		    firstInChainDataHolder.setNCCMemberIDValue(sX_CDTR_AGT_ID_2AND);
		    firstInChainDataHolder.setNCCMemberIDFieldName(X_CDTR_AGT_ID_2AND);
	    
	      // Sets chain type origin to NCC only if first in chain wasn't found in the BIC/IBAN/ACC fields.
	      if(   isNullOrEmpty(sCreditorAgentBIC) && isNullOrEmpty(sCreditorAgentABA)
	         && isNullOrEmpty(sCreditorAgentIBAN) && isNullOrEmpty(sCreditorIBAN)
	         && isNullOrEmpty(sCreditorAgentAccountID))
	      {
	      	if(chainType == ChainType.IntermediaryAgent) firstInChainDataHolder.setCreditorAgentChainTypeOrigin(ChainTypeOrigin.NCC);
	      	else firstInChainDataHolder.setChainTypeOrigin(ChainTypeOrigin.NCC);
	      }
      }
    }
    
    // Name.
    if(getChainSingleField(X_CDTR_AGT_NM_2AND, ChainTypeOrigin.NAME, D_FIRST_IN_CDT_CHAIN_NAME, D_1ST_CDT_CHA_NAME_FLD_ID, firstInChainDataHolder))
    {
    	bFoundFirstInChain = true;

	    // Sets chain type origin to NAME only if first in chain wasn't found in the BIC/IBAN/Account/NCC fields.
      if(   isNullOrEmpty(sCreditorAgentBIC) && isNullOrEmpty(sCreditorAgentABA)
         && isNullOrEmpty(sCreditorAgentIBAN) && isNullOrEmpty(sCreditorIBAN)
         && isNullOrEmpty(sCreditorAgentAccountID) 
         && isNullOrEmpty(sX_CDTR_AGT_CLR_SYS_CD) && isNullOrEmpty(sX_CDTR_AGT_CLR_SYS_PRTRY) && isNullOrEmpty(sX_CDTR_AGT_ID_2AND))
      {
      	if(chainType == ChainType.IntermediaryAgent) firstInChainDataHolder.setCreditorAgentChainTypeOrigin(ChainTypeOrigin.NAME);
      	else firstInChainDataHolder.setChainTypeOrigin(ChainTypeOrigin.NAME);
      }
    }
    
    // Address.
    if(getChainSingleField(X_CDTR_AGT_ADRLINE_2AND, ChainTypeOrigin.ADDR, D_FIRST_IN_CDT_CHAIN_ADDR, D_1ST_CDT_CHA_ADDR_FLD_ID, firstInChainDataHolder))
    {
    	bFoundFirstInChain = true;

	    // Sets chain type origin to ADDR only if first in chain wasn't found in the BIC/IBAN/Account/NCC/Name fields.
      if(   isNullOrEmpty(sCreditorAgentBIC) && isNullOrEmpty(sCreditorAgentABA)
         && isNullOrEmpty(sCreditorAgentIBAN) && isNullOrEmpty(sCreditorIBAN)
         && isNullOrEmpty(sCreditorAgentAccountID) 
         && isNullOrEmpty(sX_CDTR_AGT_CLR_SYS_CD) && isNullOrEmpty(sX_CDTR_AGT_CLR_SYS_PRTRY) && isNullOrEmpty(sX_CDTR_AGT_ID_2AND)
	    	 && firstInChainDataHolder.getChainTypeOrigin() != ChainTypeOrigin.NAME)
	    {
      	if(chainType == ChainType.IntermediaryAgent) firstInChainDataHolder.setCreditorAgentChainTypeOrigin(ChainTypeOrigin.ADDR);
      	else firstInChainDataHolder.setChainTypeOrigin(ChainTypeOrigin.ADDR);
	    }
    }
    
    if(bFoundFirstInChain)
    {
    	if(chainType == ChainType.IntermediaryAgent) firstInChainDataHolder.setCreditorAgentChainType(ChainType.CreditorAgent);
    	else firstInChainDataHolder.setChainTypeName(ChainType.CreditorAgent);
    }
    
    
    
    return bFoundFirstInChain;
  }
  
  /**
   * SWIFT: field 58/9. 
   */
  public static boolean getCREDIT_CreditorFirstInChain(PDO pdo, FirstInChainDataHolder firstInChainDataHolder)
  {
  	final String X_CDTR_BIC_VALUE = "X_CDTR_BIC: {}";
  	final String X_CDTR_ACCT_IBAN_VALUE = "X_CDTR_ACCT_IBAN: {}";
  	final String X_CDTR_ACCT_ID_VALUE = "X_CDTR_ACCT_ID: {}";
  	final String X_CDTR_CLR_SYS_CD_VALUE = "X_CDTR_CLR_SYS_CD: {}";
  	final String X_CDTR_CLR_SYS_PRTRY_VALUE = "X_CDTR_CLR_SYS_PRTRY: {}";
  	final String X_CDTR_ID_VALUE = "X_CDTR_ID: {}";
  	
  	
  	
  	boolean bFoundFirstInChain = false;
  	
  	// BIC.
    String sCreditorBIC = pdo.getString(X_CDTR_BIC);
    logger.info(X_CDTR_BIC_VALUE, sCreditorBIC);
    if(!isNullOrEmpty(sCreditorBIC))
    {
      bFoundFirstInChain = true;
	    firstInChainDataHolder.setChainTypeOrigin(ChainTypeOrigin.BIC);
	    firstInChainDataHolder.setBICValue(sCreditorBIC);
	    firstInChainDataHolder.setBICFieldName(X_CDTR_BIC);
    }
    
    // IBAN.
    String sCreditorIBAN = pdo.getString(X_CDTR_ACCT_IBAN);
    logger.info(X_CDTR_ACCT_IBAN_VALUE, sCreditorIBAN);
    if(!isNullOrEmpty(sCreditorIBAN))
    {
      bFoundFirstInChain = true;
	    firstInChainDataHolder.setIBANValue(sCreditorIBAN);
	    firstInChainDataHolder.setIBANFieldName(X_CDTR_ACCT_IBAN);
      
	    // Sets chain type origin to IBAN only if first in chain wasn't found in the BIC field.
      if(isNullOrEmpty(sCreditorBIC)) firstInChainDataHolder.setChainTypeOrigin(ChainTypeOrigin.IBAN);
    }
    
    // Account number.
    String sCreditorAccountID = pdo.getString(X_CDTR_ACCT_ID);
    logger.info(X_CDTR_ACCT_ID_VALUE, sCreditorAccountID);
    if(!isNullOrEmpty(sCreditorAccountID))
    {
      bFoundFirstInChain = true;
      
      // Handles account cleanup according to char sets profiles definition.
      sCreditorAccountID = BOSTPRules.replaceStringUsingCharSetDefinition(sCreditorAccountID, pdo.getString(P_OFFICE), null);
      pdo.set(X_CDTR_ACCT_ID, sCreditorAccountID);
      
	    firstInChainDataHolder.setAccountNumberValue(sCreditorAccountID);
	    firstInChainDataHolder.setAccountNumberFieldName(X_CDTR_ACCT_ID);
	    
	    // Sets chain type origin to ACC only if first in chain wasn't found in the BIC/IBAN fields.
	    if(isNullOrEmpty(sCreditorBIC) && isNullOrEmpty(sCreditorIBAN)) firstInChainDataHolder.setChainTypeOrigin(ChainTypeOrigin.ACC);
    }
    
    // NCC.
    String sX_CDTR_CLR_SYS_PRTRY = null; // NCC proprietary.
    //
    // NCC Code ID.
    String sX_CDTR_CLR_SYS_CD = pdo.getString(X_CDTR_CLR_SYS_CD);
    logger.info(X_CDTR_CLR_SYS_CD_VALUE, sX_CDTR_CLR_SYS_CD);
    if(!isNullOrEmpty(sX_CDTR_CLR_SYS_CD))
    {
      bFoundFirstInChain = true;
	    firstInChainDataHolder.setNCCCodeValue(sX_CDTR_CLR_SYS_CD);
	    firstInChainDataHolder.setNCCCodeFieldName(X_CDTR_CLR_SYS_CD);
    }
    //
    // No NCC code ID, checks for NCC proprietary.
    else
    {
    	sX_CDTR_CLR_SYS_PRTRY = pdo.getString(X_CDTR_CLR_SYS_PRTRY);
      logger.info(X_CDTR_CLR_SYS_PRTRY_VALUE, sX_CDTR_CLR_SYS_PRTRY);	      	
      if(!isNullOrEmpty(sX_CDTR_CLR_SYS_PRTRY))
      {
        bFoundFirstInChain = true;
        firstInChainDataHolder.setNCCProprietaryValue(sX_CDTR_CLR_SYS_PRTRY);
        firstInChainDataHolder.setNCCProprietaryFieldName(X_CDTR_CLR_SYS_PRTRY);
      }
    }
    //
    // NCC member ID; initializes it even if no NCC code or proprietary were found.	        
    String sX_CDTR_ID = pdo.getString(X_CDTR_ID);
    logger.info(X_CDTR_ID_VALUE, sX_CDTR_ID);
    if(!isNullOrEmpty(sX_CDTR_ID))
    {
    	bFoundFirstInChain = true;
	    firstInChainDataHolder.setNCCMemberIDValue(sX_CDTR_ID);
	    firstInChainDataHolder.setNCCMemberIDFieldName(X_CDTR_ID);
    
	    // Sets chain type origin to NCC only if first in chain wasn't found in the BIC/IBAN/ACC fields.
	    if(isNullOrEmpty(sCreditorBIC) && isNullOrEmpty(sCreditorIBAN) && isNullOrEmpty(sCreditorAccountID)) 
	    	                                              firstInChainDataHolder.setChainTypeOrigin(ChainTypeOrigin.NCC);
    }

    // Name.
    if(getChainSingleField(X_CDTR_NM, ChainTypeOrigin.NAME, D_FIRST_IN_CDT_CHAIN_NAME, D_1ST_CDT_CHA_NAME_FLD_ID, firstInChainDataHolder))
    {
    	bFoundFirstInChain = true;

	    // Sets chain type origin to NAME only if first in chain wasn't found in the BIC/IBAN/Account fields.
	    if(   isNullOrEmpty(sCreditorBIC) && isNullOrEmpty(sCreditorIBAN) && isNullOrEmpty(sCreditorAccountID)
	    	 &&	isNullOrEmpty(sX_CDTR_CLR_SYS_CD) && isNullOrEmpty(sX_CDTR_CLR_SYS_PRTRY) && isNullOrEmpty(sX_CDTR_ID))
	    	          firstInChainDataHolder.setChainTypeOrigin(ChainTypeOrigin.NAME);
    }
    
    // Address.
    if(getChainSingleField(X_CDTR_ADRLINE, ChainTypeOrigin.ADDR, D_FIRST_IN_CDT_CHAIN_ADDR, D_1ST_CDT_CHA_ADDR_FLD_ID, firstInChainDataHolder))
    {
    	bFoundFirstInChain = true;

	    // Sets chain type origin to ADDR only if first in chain wasn't found in the BIC/IBAN/Account/Name fields.
	    if(   isNullOrEmpty(sCreditorBIC) && isNullOrEmpty(sCreditorIBAN) 
	    	 && isNullOrEmpty(sCreditorAccountID) 
	    	 &&	isNullOrEmpty(sX_CDTR_CLR_SYS_CD) && isNullOrEmpty(sX_CDTR_CLR_SYS_PRTRY) && isNullOrEmpty(sX_CDTR_ID)
	    	 && firstInChainDataHolder.getChainTypeOrigin() != ChainTypeOrigin.NAME)
	    {
	    	firstInChainDataHolder.setChainTypeOrigin(ChainTypeOrigin.ADDR);
	    }
    }

    if(bFoundFirstInChain) firstInChainDataHolder.setChainTypeName(ChainType.Creditor);
  	
    
    
    return bFoundFirstInChain;
  }
  
  /**
   * Finds the first in chain for the CREDIT side.
   */
  private Feedback findFirstInCreditChain()
  {
    
    
    Feedback feedback = new Feedback();
    
    PDO pdo = Admin.getContextPDO();
    boolean bFoundFirstInChain = false;
    
    // In case of successful process, it will be set again at the end.
    pdo.removePaymentField(D_SUCCESSFUL_CREDIT_FIRST_IN_CHAIN);
    
    ChainType chainType = null;
    ChainTypeOrigin chainTypeOrigin = null;
    
    // These variables will be set only when 'Intermediary agent' was found as first in chain and 'Creditor Agent' 
    // chain wasn't set yet in the related pdo class member.
    ChainType creditorAgentChainType = null;
    ChainTypeOrigin creditorAgentChainTypeOrigin = null;
    String sCreditorAgentFieldValue = null;
    String sCreditorAgentFieldName = null;
    
    FirstInChainDataHolder firstInChainDataHolder = new FirstInChainDataHolder(); 
    
    ////////////////////////////////////////////////
    ////////// RECEIVER ////////////////////////////
    ////////////////////////////////////////////////
    
    // STEP 1 - 
    // Looks in the 'Reciever' field.
    bFoundFirstInChain = getCREDIT_RecieverFirstInChain(pdo, firstInChainDataHolder);
    if(bFoundFirstInChain)
    {
    	mapChainDataToPDODerivedFields(pdo, firstInChainDataHolder);
      chainType = firstInChainDataHolder.getChainType();
      chainTypeOrigin = firstInChainDataHolder.getChainTypeOrigin();
    }
    
    //////////////////////////////////////////////
    ////////// CORRESPONDENT /////////////////////
    //////////////////////////////////////////////

    // STEP 2 - 
    // Looks in the 'Correspondent' field.
    if(!bFoundFirstInChain)
    {
    	bFoundFirstInChain = getCREDIT_CorrespondentFirstInChain(pdo, firstInChainDataHolder);
      if(bFoundFirstInChain)
      {
        pdo.set(D_FIRST_IN_CDT_CHAIN_BIC, firstInChainDataHolder.getBICValue());
        pdo.set(D_1ST_IN_CDT_CHA_BIC_FLD_ID, firstInChainDataHolder.getBICFieldName());
        
        chainType = firstInChainDataHolder.getChainType();
        chainTypeOrigin = firstInChainDataHolder.getChainTypeOrigin();
      }
    }
    
    //////////////////////////////////////////////
    ////////// INTERMEDIARY AGENT ////////////////
    //////////////////////////////////////////////
    
    // STEP 3 - 
    // Looks in the 'Intermediary agent' fields.
    // SWIFT: field 56.
    if(!bFoundFirstInChain)
    {
    	bFoundFirstInChain = getCREDIT_IntermediaryAgentFirstInChain(pdo, firstInChainDataHolder);
    	
    	if(bFoundFirstInChain)
    	{
    		mapChainDataToPDODerivedFields(pdo, firstInChainDataHolder);
        chainType = firstInChainDataHolder.getChainType();
        chainTypeOrigin = firstInChainDataHolder.getChainTypeOrigin();
    	}
    }
    
    ////////////////////////// ////////////////////
    ////////// CREDITOR AGENT /////////////////////
    ///////////////////////////////////////////////
    
    // STEP 4 - 
    // Looks in the 'Creditor agent' fields in case:
    //    1) First in chain wasn't found yet.
    // OR 2) First in chain was found in the 'Intermediary Agent' fields and 'Creditor Agent' chain wasn't found yet;
    //       required for bank routing service, which starts its transfer method logic from the 'Intermediary Agent' fields,
    //       but requires also 'Creditor agent' chain data.
    //
    // SWIFT: field 57.
    if(   !bFoundFirstInChain
    	 || (   bFoundFirstInChain && chainType == ChainType.IntermediaryAgent 
    			 && pdo.getCreditChainsData().getSpecificChainData(ChainType.getChainTypeIndex(ChainType.CreditorAgent)) == null)	)
    {
    	bFoundFirstInChain = getCREDIT_CreditorAgentFirstInChain(pdo, firstInChainDataHolder);
    	
    	if(bFoundFirstInChain)
    	{
    		// 1st in chain was found earlier in the 'Intermediary Agent' fields; 
    		// just sets the creditor agent related fields which may be null.
    		if(chainType == ChainType.IntermediaryAgent)
    		{
          // Creditor agent related fields.
          creditorAgentChainType = firstInChainDataHolder.getCreditorAgentChainType();
          creditorAgentChainTypeOrigin = firstInChainDataHolder.getCreditorAgentChainTypeOrigin();
          sCreditorAgentFieldValue = firstInChainDataHolder.getCreditorAgentFieldValue();
          sCreditorAgentFieldName = firstInChainDataHolder.getCreditorAgentFieldName();
    		}
    		
    		// 1st in chain was found in the 'Creditor agent' fields.  
    		else
    		{
    			mapChainDataToPDODerivedFields(pdo, firstInChainDataHolder);
    		}

        chainType = firstInChainDataHolder.getChainType();
        chainTypeOrigin = firstInChainDataHolder.getChainTypeOrigin();
    	}
    }
    
    //////////////////////////////////////////
    ////////// CREDITOR //////////////////////
    //////////////////////////////////////////
    
    // STEP 5 - 
    // Looks in the 'Creditor' fields.
    if(!bFoundFirstInChain)
    {
    	bFoundFirstInChain = getCREDIT_CreditorFirstInChain(pdo, firstInChainDataHolder);
      
    	if(bFoundFirstInChain)
    	{
    		mapChainDataToPDODerivedFields(pdo, firstInChainDataHolder);
        chainType = firstInChainDataHolder.getChainType();
        chainTypeOrigin = firstInChainDataHolder.getChainTypeOrigin();
    	}
    }
    
    // Updates related PDO class member.
    if(bFoundFirstInChain)
    {
    	final String TRACE_1 = "Found first in chain data - calls 'getChainData' for found MAIN chain type...";
    	final String TRACE_2 = "Found first in chain data - calls 'getChainData' for found CREDITOR AGENT chain type...";

    	logger.info(TRACE_1);
    	ChainData chainData = getChainData(chainType, chainTypeOrigin, false, null, null);
    	pdo.setCreditChainData(chainData);
    	pdo.set(D_CHAIN_INDEX, ChainType.getChainTypeIndex(chainType));
    	pdo.set(D_CREDIT_PARTIES_NM, pdo.getCreditChainsData().getNumberOfParties() + "");
    	
    	if(creditorAgentChainType != null)
    	{
    		logger.info(TRACE_2);
      	ChainData creditorAgentChainData = getChainData(creditorAgentChainType, creditorAgentChainTypeOrigin, true, sCreditorAgentFieldName, sCreditorAgentFieldValue);
      	pdo.setCreditChainData(creditorAgentChainData);
    	}
    	
      // Sets related D field. 
    	pdo.set(D_SUCCESSFUL_CREDIT_FIRST_IN_CHAIN, ServerConstants.BOOL_TRUE);
    }
    
    // First in chain wasn't found.
    // Sets error into the PDO object.
    // Error code '40039': Unable to identify 1st in credit chain.
    else
    {
      feedback.setFailure();
      configureErrorFeedback(PROCESS_ERROR_UNABLE_TO_IDENTIFY_FIRST_IN_CREDIT_CHAIN.getErrorCode(),
                             PROCESS_ERROR_UNABLE_TO_IDENTIFY_FIRST_IN_CREDIT_CHAIN.getDescription(),
                             feedback);
      ErrorAuditUtils.setErrors(PROCESS_ERROR_UNABLE_TO_IDENTIFY_FIRST_IN_CREDIT_CHAIN,pdo.getIsHistory());
    }

    if(chainType!=null){
    	pdo.set(D_PARTY_ROLE_NAME, chainType.toString());
    }
    return feedback;
  }
  
  /**
   * 
   */
  private void mapChainDataToPDODerivedFields(PDO pdo, FirstInChainDataHolder firstInChainDataHolder)
  {
	// BIC.
    pdo.set(D_FIRST_IN_CDT_CHAIN_BIC, firstInChainDataHolder.getBICValue());
    pdo.set(D_1ST_IN_CDT_CHA_BIC_FLD_ID, firstInChainDataHolder.getBICFieldName());
    // IBAN.
    pdo.set(D_FIRST_IN_CDT_CHAIN_IBAN, firstInChainDataHolder.getIBANValue());
    pdo.set(D_1ST_IN_CDT_CHA_IBAN_FLD_ID, firstInChainDataHolder.getIBANFieldName());
    
    // Account number.
    pdo.set(D_FIRST_IN_CDT_CHAIN_ACC_NUM, firstInChainDataHolder.getAccountNumberValue());
    pdo.set(D_1ST_IN_CDT_CHA_ACCNUM_FLD_ID, firstInChainDataHolder.getAccountNumberFieldName());
    
    // NCC code.
    pdo.set(D_FIRST_IN_CDT_CHAIN_NCC_CODE, firstInChainDataHolder.getNCCCodeValue());
    pdo.set(D_1ST_IN_CDT_CHA_NCC_CD_FLD_ID, firstInChainDataHolder.getNCCCodeFieldName());
    
    // NCC proprietary.
    pdo.set(D_FIRST_IN_CDT_CHAIN_NCC_PRTRY, firstInChainDataHolder.getNCCProprietaryValue());
    pdo.set(D_1ST_IN_CDT_CHA_NCC_PRTRY_FLD_ID, firstInChainDataHolder.getNCCProprietaryFieldName());    

    // NCC member ID.
    pdo.set(D_1ST_IN_CDT_CHA_NCC_MEM_ID, firstInChainDataHolder.getNCCMemberIDValue());
    pdo.set(D_1ST_CDT_CHA_NCC_MEM_FLD_ID, firstInChainDataHolder.getNCCMemberIDFieldName());
  	
    // Name.
    pdo.set(D_FIRST_IN_CDT_CHAIN_NAME, firstInChainDataHolder.getNameValue());
    pdo.set(D_1ST_CDT_CHA_NAME_FLD_ID, firstInChainDataHolder.getNameFieldName());

    // Address
    pdo.set(D_FIRST_IN_CDT_CHAIN_ADDR, firstInChainDataHolder.getAddressValue());
    pdo.set(D_1ST_CDT_CHA_ADDR_FLD_ID, firstInChainDataHolder.getAddressFieldName());
    
    
  }
  
  /**
   * 
   */
  private ChainData getChainData(ChainType chainType, ChainTypeOrigin chainTypeOrigin, boolean bSetCountryCode,
  		                           String sCreditorAgentFieldName, String sCreditorAgentFieldValue)
  {
  	final String TRACE_METHOD_INPUT = "Method input - Chain type: {}, Chain type origin: {}, Creditor agent field name, (may be null): {}, Creditor agent field value, (may be null): {}.";
  	final String TRACE_FIRST_IN_CHAIN_DATA_ADDITIONAL_DATA = "Found first in chain additional data - Field name: {}, Field value: {}, Country code (may be null): {}.";

  	
  	
  	logger.info(TRACE_METHOD_INPUT, new Object[] {chainType, chainTypeOrigin, sCreditorAgentFieldName, sCreditorAgentFieldValue});
  	
  	ChainData chainData = null;
  	String sFieldName, sFieldValue, sSecondFieldName = null, sSecondFieldValue = null;
  	String sCountryCode = null;
  	
  	PDO pdo = Admin.getContextPDO();
  	
  	// If these variables are not null, then they will be used for the final created new ChainData object.
  	// Will happen when the chain type is 'CreditorAgent' and the first is chain is actually the 'IntermediaryAgent'
  	// chain type, (see logic and call to this method at the end of the 'findFirstInCreditChain' method).
  	if(!isNullOrEmpty(sCreditorAgentFieldName) && !isNullOrEmpty(sCreditorAgentFieldValue))
  	{
  		sFieldName = sCreditorAgentFieldName;
  		sFieldValue = sCreditorAgentFieldValue;
  		
  		if(ChainTypeOrigin.BIC == chainTypeOrigin && bSetCountryCode)
  		{
  			sCountryCode = sFieldValue.substring(4,6);
  		}
  	}
  	
  	else
  	{
	  	// Figures field name and value.
	  	//
	  	// BIC.
	  	if(ChainTypeOrigin.BIC == chainTypeOrigin)
	  	{
	  		sFieldName = pdo.getString(D_1ST_IN_CDT_CHA_BIC_FLD_ID);
	  		sFieldValue = pdo.getString(D_FIRST_IN_CDT_CHAIN_BIC);
	  		
	  		if(bSetCountryCode)
	  		{
	  			sCountryCode = sFieldValue.substring(4,6);
	  		}
	  	}
	  	
	  	// IBAN.
	  	else if(ChainTypeOrigin.IBAN == chainTypeOrigin)
	  	{
	  		sFieldName = pdo.getString(D_1ST_IN_CDT_CHA_IBAN_FLD_ID);
	  		sFieldValue = pdo.getString(D_FIRST_IN_CDT_CHAIN_IBAN);
	  	}
	  	
	  	// Account number.
	  	else if(ChainTypeOrigin.ACC == chainTypeOrigin)
	  	{
	  		sFieldName = pdo.getString(D_1ST_IN_CDT_CHA_IBAN_FLD_ID);
	  		sFieldValue = pdo.getString(D_FIRST_IN_CDT_CHAIN_IBAN);
	  	}

	  	else // NCC
	  	{
	  		// Checks if NCC code was found.
	  		sFieldName = pdo.getString(D_1ST_IN_CDT_CHA_NCC_CD_FLD_ID);
	  		if(isNullOrEmpty(sFieldName)) 
	  		{
	  			sFieldValue = pdo.getString(D_FIRST_IN_CDT_CHAIN_NCC_CODE);
	  		}
	  		else // NCC proprietary was found.
	  		{
	  			sFieldName = pdo.getString(D_1ST_IN_CDT_CHA_NCC_PRTRY_FLD_ID);
	  			sFieldValue = pdo.getString(D_FIRST_IN_CDT_CHAIN_NCC_PRTRY);
	  		}
	  		
	  		sSecondFieldName = pdo.getString(D_1ST_CDT_CHA_NCC_MEM_FLD_ID);
	  		sSecondFieldValue = pdo.getString(D_1ST_IN_CDT_CHA_NCC_MEM_ID);
	  	}
  	}
  	
  	logger.info(TRACE_FIRST_IN_CHAIN_DATA_ADDITIONAL_DATA, new Object[] {sFieldName, sFieldValue, sCountryCode});
  	
  	chainData = new MessageChainsData.ChainData(chainType, chainTypeOrigin, sFieldName, sFieldValue, sSecondFieldName, sSecondFieldValue);
  	if(sCountryCode != null) chainData.setCountryCode(sCountryCode);
  	
  	
  	
  	return chainData;
  }
  
  /**
   * Finds the first in chain for the DEBIT side.
   */
  private Feedback findFirstInDebitChain()
  {
    final String TRACE_MESSAGE_ORIG_MSG_TYPE = "P_ORIG_MSG_TYPE: {}.";
    
    
    
    Feedback feedback = new Feedback();
    PDO pdo = Admin.getContextPDO();
    boolean bFoundFirstInChain = false;
    
    // In case of successful process, it will be set again at the end.
    pdo.removePaymentField(D_SUCCESSFUL_DEBIT_FIRST_IN_CHAIN);
    
    String sP_ORIG_MSG_TYPE = pdo.getString(P_ORIG_MSG_TYPE);
    logger.info(TRACE_MESSAGE_ORIG_MSG_TYPE, sP_ORIG_MSG_TYPE);
    
    // Pain_001 message.
    if(MESSAGE_TYPE_PAIN_001.equalsIgnoreCase(sP_ORIG_MSG_TYPE))
    {
    	bFoundFirstInChain = getDEBIT_DebtorAccountFirstInChain();
    }
    
    // Not a Pain_001 message.
    else
    {
      //////////////////////////////////
      ///////// P_DBT_ACCT_NB //////////
      //////////////////////////////////
    	
    	bFoundFirstInChain = getDEBIT_DebitAccountFirstInChain();
    	
      //////////////////////////////////////////////
      ///////// THIRD REIMBURSEMENT AGENT //////////
      //////////////////////////////////////////////
    	
    	// SWIFT field: 55.
      if(!bFoundFirstInChain)
      {
      	bFoundFirstInChain = getDEBIT_ThirdReimbursementAgentFirstInChain();
      }
      
      ///////////////////////////////////////////////////
      ///////// INSTRUCTED REIMBURSEMENT AGENT //////////
      ///////////////////////////////////////////////////

      // SWIFT field: 54.
      if(!bFoundFirstInChain)
      {
      	bFoundFirstInChain = getDEBIT_InstructedReimbursementAgentFirstInChain();
      }
      
      //////////////////////////////////////////////////
      //////// INSTRUCTING REIMBURSEMENT AGENT /////////
      //////////////////////////////////////////////////

      // SWIFT field: 53.
      if(!bFoundFirstInChain)
      {
      	bFoundFirstInChain = getDEBIT_InstructingReimbursementAgentFirstInChain();
      }
      
      ////////////////////////////////////
      //////// INSTRUCTING AGENT /////////
      ////////////////////////////////////
      
      if(!bFoundFirstInChain)
      {
      	bFoundFirstInChain = getDEBIT_InstructingAgentFirstInChain();
      }
    }
    
    // First in chain wasn't found.
    // Sets error into the PDO object.
    // Error code '40040': Unable to identify 1st in debit chain.
    if(!bFoundFirstInChain)
    {
      feedback.setFailure();
      configureErrorFeedback(PROCESS_ERROR_UNABLE_TO_IDENTIFY_FIRST_IN_DEBIT_CHAIN.getErrorCode(),
                             PROCESS_ERROR_UNABLE_TO_IDENTIFY_FIRST_IN_DEBIT_CHAIN.getDescription(),
                             feedback);
      ErrorAuditUtils.setErrors(PROCESS_ERROR_UNABLE_TO_IDENTIFY_FIRST_IN_DEBIT_CHAIN,pdo.getIsHistory());
    }
    else // Sets related D field. 
    {
    	pdo.set(D_SUCCESSFUL_DEBIT_FIRST_IN_CHAIN, ServerConstants.BOOL_TRUE);
    }
    
    
    
    return feedback;
  }
  
  /**
   * 
   */
  private boolean getDEBIT_DebtorAccountFirstInChain()
  {
  	final String TRACE_X_DBTR_ACCT_IBAN_VALUE = "X_DBTR_ACCT_IBAN: {}.";
  	final String TRACE_X_DBTR_ACCT_ID_VALUE = "X_DBTR_ACCT_ID: {}.";
  	
  	
  	
  	boolean bFoundFirstInChain = false;
  	PDO pdo = Admin.getContextPDO();
  	
    String sDebtorAccountIBAN = pdo.getString(X_DBTR_ACCT_IBAN);
    logger.info(TRACE_X_DBTR_ACCT_IBAN_VALUE, sDebtorAccountIBAN);
    if(!isNullOrEmpty(sDebtorAccountIBAN))
    {
      bFoundFirstInChain = true;
      pdo.set(D_FIRST_IN_DBT_CHAIN_IBAN, sDebtorAccountIBAN);
      pdo.set(D_1ST_IN_DBT_CHA_IBAN_FLD_ID, X_DBTR_ACCT_IBAN);
    }
    
    String sDebtorAccountID = pdo.getString(X_DBTR_ACCT_ID);
    logger.info(TRACE_X_DBTR_ACCT_ID_VALUE, sDebtorAccountID);
    if(!isNullOrEmpty(sDebtorAccountID))
    {
      bFoundFirstInChain = true;
      
      // Handles account cleanup according to char sets profiles definition.
      sDebtorAccountID = BOSTPRules.replaceStringUsingCharSetDefinition(sDebtorAccountID, pdo.getString(P_OFFICE), null);
      pdo.set(X_DBTR_ACCT_ID, sDebtorAccountID);
      
      pdo.set(D_FIRST_IN_DBT_CHAIN_ACC_NUM, sDebtorAccountID);
      pdo.set(D_1ST_IN_DBT_CHA_ACCNUM_FLD_ID, X_DBTR_ACCT_ID);
    }
  	
  	
  	
  	return bFoundFirstInChain;
  }
  
  /**
   * SWIFT field: 55.
   */
  private boolean getDEBIT_ThirdReimbursementAgentFirstInChain()
  {
  	final String X_THRD_RMB_AGT_BIC_2AND_VALUE = "X_THRD_RMB_AGT_BIC_2AND: {}";
  	final String X_THRD_RMB_AGT_ACCT_ID_2AND_VALUE = "X_THRD_RMB_AGT_ACCT_ID_2AND: {}";
  	final String X_THRD_RMB_AGT_CLR_SYS_CD_VALUE = "X_THRD_RMB_AGT_CLR_SYS_CD: {}";
  	final String X_THRD_RMB_AGT_CLR_SYS_PRTRY_VALUE = "X_THRD_RMB_AGT_CLR_SYS_PRTRY: {}";
  	final String X_THRD_RMB_AGT_ID_2AND_VALUE = "X_THRD_RMB_AGT_ID_2AND: {}";
  	
  	
  	
  	boolean bFoundFirstInChain = false;
  	PDO pdo = Admin.getContextPDO();
  	
    // BIC.
    String sX_THRD_RMB_AGT_BIC_2AND = pdo.getString(X_THRD_RMB_AGT_BIC_2AND);
    logger.info(X_THRD_RMB_AGT_BIC_2AND_VALUE, sX_THRD_RMB_AGT_BIC_2AND);
    if(!isNullOrEmpty(sX_THRD_RMB_AGT_BIC_2AND))
    {
      bFoundFirstInChain = true;
      pdo.set(D_FIRST_IN_DBT_CHAIN_BIC, sX_THRD_RMB_AGT_BIC_2AND);
      pdo.set(D_1ST_IN_DBT_CHA_BIC_FLD_ID, X_THRD_RMB_AGT_BIC_2AND);
    }
    
    // Account.
    String sX_THRD_RMB_AGT_ACCT_ID_2AND = pdo.getString(X_THRD_RMB_AGT_ACCT_ID_2AND);
    logger.info(X_THRD_RMB_AGT_ACCT_ID_2AND_VALUE, sX_THRD_RMB_AGT_ACCT_ID_2AND);
    if(!isNullOrEmpty(sX_THRD_RMB_AGT_ACCT_ID_2AND))
    {
      bFoundFirstInChain = true;
      
      // Handles account cleanup according to char sets profiles definition.
      sX_THRD_RMB_AGT_ACCT_ID_2AND = BOSTPRules.replaceStringUsingCharSetDefinition(sX_THRD_RMB_AGT_ACCT_ID_2AND, pdo.getString(P_OFFICE), null);
      pdo.set(X_THRD_RMB_AGT_ACCT_ID_2AND, sX_THRD_RMB_AGT_ACCT_ID_2AND);
      
      pdo.set(D_FIRST_IN_DBT_CHAIN_ACC_NUM, sX_THRD_RMB_AGT_ACCT_ID_2AND);
      pdo.set(D_1ST_IN_DBT_CHA_ACCNUM_FLD_ID, X_THRD_RMB_AGT_ACCT_ID_2AND);
    }
    
    // NCC.
    //
    String sX_THRD_RMB_AGT_CLR_SYS_PRTRY = null; // NCC proprietary.
    //
    // NCC Code ID.
    String sX_THRD_RMB_AGT_CLR_SYS_CD = pdo.getString(X_THRD_RMB_AGT_CLR_SYS_CD);
    logger.info(X_THRD_RMB_AGT_CLR_SYS_CD_VALUE, sX_THRD_RMB_AGT_CLR_SYS_CD);
    //
    if(!isNullOrEmpty(sX_THRD_RMB_AGT_CLR_SYS_CD))
    {
      bFoundFirstInChain = true;
      pdo.set(D_FIRST_IN_DBT_CHAIN_NCC_CODE, sX_THRD_RMB_AGT_CLR_SYS_CD);
      pdo.set(D_1ST_IN_DBT_CHA_NCC_CD_FLD_ID, X_THRD_RMB_AGT_CLR_SYS_CD);
    }
    //
    // No NCC code ID, checks for NCC proprietary.
    else
    {
      sX_THRD_RMB_AGT_CLR_SYS_PRTRY = pdo.getString(X_THRD_RMB_AGT_CLR_SYS_PRTRY);
      logger.info(X_THRD_RMB_AGT_CLR_SYS_PRTRY_VALUE, sX_THRD_RMB_AGT_CLR_SYS_PRTRY);	      	
      if(!isNullOrEmpty(sX_THRD_RMB_AGT_CLR_SYS_PRTRY))
      {
        bFoundFirstInChain = true;
        pdo.set(D_FIRST_IN_DBT_CHAIN_NCC_PRTRY, sX_THRD_RMB_AGT_CLR_SYS_PRTRY);
        pdo.set(D_1ST_IN_DBT_CHA_NCC_PRTRY_FLD_ID, X_THRD_RMB_AGT_CLR_SYS_PRTRY);
      }
    }
    //
    // NCC member ID; initializes it even if no NCC code or proprietary were found.    
    String sX_THRD_RMB_AGT_ID_2AND = pdo.getString(X_THRD_RMB_AGT_ID_2AND);
    logger.info(X_THRD_RMB_AGT_ID_2AND_VALUE, sX_THRD_RMB_AGT_ID_2AND);
    if(!isNullOrEmpty(sX_THRD_RMB_AGT_ID_2AND))
    {
      bFoundFirstInChain = true;        
	    pdo.set(D_1ST_IN_DBT_CHA_NCC_MEM_ID, sX_THRD_RMB_AGT_ID_2AND);
	    pdo.set(D_1ST_DBT_CHA_NCC_MEM_FLD_ID, X_THRD_RMB_AGT_ID_2AND);
    }
    
    // Name.
    if(getChainSingleField(X_THRD_RMB_AGT_NM_2AND, ChainTypeOrigin.NAME, D_FIRST_IN_DBT_CHAIN_NAME, D_1ST_DBT_CHA_NAME_FLD_ID, null)) bFoundFirstInChain = true;
    
    // Address.
    if(getChainSingleField(X_THRD_RMB_AGT_ADRLINE_2AND, ChainTypeOrigin.ADDR, D_FIRST_IN_DBT_CHAIN_ADDR, D_1ST_DBT_CHA_ADDR_FLD_ID, null)) bFoundFirstInChain = true;
  	
  	
  	
  	return bFoundFirstInChain;
  }

  /**
   * SWIFT field: 54.
   */
  private boolean getDEBIT_InstructedReimbursementAgentFirstInChain()
  {
  	final String X_INSTD_RMB_AGT_BIC_2AND_VALUE = "X_INSTD_RMB_AGT_BIC_2AND: {}";
  	final String X_INSTD_RMB_AGT_ACCT_IBAN_VALUE = "X_INSTD_RMB_AGT_ACCT_IBAN: {}";
  	final String X_INSTD_RMB_AGT_ACCT_ID_2AND_VALUE = "X_INSTD_RMB_AGT_ACCT_ID_2AND: {}";
  	final String X_INSTD_RMB_AGT_CLR_SYS_CD_VALUE = "X_INSTD_RMB_AGT_CLR_SYS_CD: {}";
  	final String X_THRD_RMB_AGT_CLR_SYS_PRTRY_VALUE = "X_THRD_RMB_AGT_CLR_SYS_PRTRY: {}";
  	final String X_INSTD_RMB_AGT_ID_2AND_VALUE = "X_INSTD_RMB_AGT_ID_2AND: {}";
  	
  	
  	
  	boolean bFoundFirstInChain = false;
  	PDO pdo = Admin.getContextPDO();
  	
    // BIC.
    String sX_INSTD_RMB_AGT_BIC_2AND = pdo.getString(X_INSTD_RMB_AGT_BIC_2AND);
    logger.info(X_INSTD_RMB_AGT_BIC_2AND_VALUE, sX_INSTD_RMB_AGT_BIC_2AND);
    if(!isNullOrEmpty(sX_INSTD_RMB_AGT_BIC_2AND))
    {
      bFoundFirstInChain = true;
      pdo.set(D_FIRST_IN_DBT_CHAIN_BIC, sX_INSTD_RMB_AGT_BIC_2AND);
      pdo.set(D_1ST_IN_DBT_CHA_BIC_FLD_ID, X_INSTD_RMB_AGT_BIC_2AND);
    }
    
    // IBAN.
    String sX_INSTD_RMB_AGT_ACCT_IBAN = pdo.getString(X_INSTD_RMB_AGT_ACCT_IBAN);
    logger.info(X_INSTD_RMB_AGT_ACCT_IBAN_VALUE, sX_INSTD_RMB_AGT_ACCT_IBAN);
    if(!isNullOrEmpty(sX_INSTD_RMB_AGT_ACCT_IBAN))
    {
      bFoundFirstInChain = true;
      pdo.set(D_FIRST_IN_DBT_CHAIN_IBAN, sX_INSTD_RMB_AGT_ACCT_IBAN);
      pdo.set(D_1ST_IN_DBT_CHA_IBAN_FLD_ID, X_INSTD_RMB_AGT_ACCT_IBAN);        
    }        
    
    // Account.
    String sX_INSTD_RMB_AGT_ACCT_ID_2AND = pdo.getString(X_INSTD_RMB_AGT_ACCT_ID_2AND);
    logger.info(X_INSTD_RMB_AGT_ACCT_ID_2AND_VALUE, sX_INSTD_RMB_AGT_ACCT_ID_2AND);
    if(!isNullOrEmpty(sX_INSTD_RMB_AGT_ACCT_ID_2AND))
    {
      bFoundFirstInChain = true;
      
      // Handles account cleanup according to char sets profiles definition.
      sX_INSTD_RMB_AGT_ACCT_ID_2AND = BOSTPRules.replaceStringUsingCharSetDefinition(sX_INSTD_RMB_AGT_ACCT_ID_2AND, pdo.getString(P_OFFICE), null);
      pdo.set(X_INSTD_RMB_AGT_ACCT_ID_2AND, sX_INSTD_RMB_AGT_ACCT_ID_2AND);
      
      pdo.set(D_FIRST_IN_DBT_CHAIN_ACC_NUM, sX_INSTD_RMB_AGT_ACCT_ID_2AND);
      pdo.set(D_1ST_IN_DBT_CHA_ACCNUM_FLD_ID, X_INSTD_RMB_AGT_ACCT_ID_2AND);
    }
    
    // NCC.
    String sX_INSTD_RMB_AGT_CLR_SYS_PRTRY = null; // NCC proprietary.
    //
    // NCC Code ID.
    String sX_INSTD_RMB_AGT_CLR_SYS_CD = pdo.getString(X_INSTD_RMB_AGT_CLR_SYS_CD);
    logger.info(X_INSTD_RMB_AGT_CLR_SYS_CD_VALUE, sX_INSTD_RMB_AGT_CLR_SYS_CD);
    if(!isNullOrEmpty(sX_INSTD_RMB_AGT_CLR_SYS_CD))
    {
      bFoundFirstInChain = true;
      pdo.set(D_FIRST_IN_DBT_CHAIN_NCC_CODE, sX_INSTD_RMB_AGT_CLR_SYS_CD);
      pdo.set(D_1ST_IN_DBT_CHA_NCC_CD_FLD_ID, X_INSTD_RMB_AGT_CLR_SYS_CD);
    }
    //
    // No NCC code ID, checks for NCC proprietary.
    else
    {
    	sX_INSTD_RMB_AGT_CLR_SYS_PRTRY = pdo.getString(X_INSTD_RMB_AGT_CLR_SYS_PRTRY);
      logger.info(X_THRD_RMB_AGT_CLR_SYS_PRTRY_VALUE, sX_INSTD_RMB_AGT_CLR_SYS_PRTRY);	      	
      if(!isNullOrEmpty(sX_INSTD_RMB_AGT_CLR_SYS_PRTRY))
      {
        bFoundFirstInChain = true;
        pdo.set(D_FIRST_IN_DBT_CHAIN_NCC_PRTRY, sX_INSTD_RMB_AGT_CLR_SYS_PRTRY);
        pdo.set(D_1ST_IN_DBT_CHA_NCC_PRTRY_FLD_ID, X_INSTD_RMB_AGT_CLR_SYS_PRTRY);
      }
    }
    //
    // NCC member ID; initializes it even if no NCC code or proprietary were found.    
    String sX_INSTD_RMB_AGT_ID_2AND = pdo.getString(X_INSTD_RMB_AGT_ID_2AND);
    logger.info(X_INSTD_RMB_AGT_ID_2AND_VALUE, sX_INSTD_RMB_AGT_ID_2AND);
    if(!isNullOrEmpty(sX_INSTD_RMB_AGT_ID_2AND))
    {
      bFoundFirstInChain = true;    
	    pdo.set(D_1ST_IN_DBT_CHA_NCC_MEM_ID, sX_INSTD_RMB_AGT_ID_2AND);
	    pdo.set(D_1ST_DBT_CHA_NCC_MEM_FLD_ID, X_INSTD_RMB_AGT_ID_2AND);
    }
    
    // Name.
    if(getChainSingleField(X_INSTD_RMB_AGT_NM_2AND, ChainTypeOrigin.NAME, D_FIRST_IN_DBT_CHAIN_NAME, D_1ST_DBT_CHA_NAME_FLD_ID, null)) bFoundFirstInChain = true;
    
    // Address.
    if(getChainSingleField(X_INSTD_RMB_AGT_ADRLINE_2AND, ChainTypeOrigin.ADDR, D_FIRST_IN_DBT_CHAIN_ADDR, D_1ST_DBT_CHA_ADDR_FLD_ID, null)) bFoundFirstInChain = true;
  	
  	
  	
  	return bFoundFirstInChain;
  }

  /**
   * SWIFT field: 53.
   */
  private boolean getDEBIT_InstructingReimbursementAgentFirstInChain()
  {
  	final String X_INSTG_RMB_AGT_BIC_2AND_VALUE = "X_INSTG_RMB_AGT_BIC_2AND: {}";
  	final String X_STTLM_ACCT_IBAN_VALUE = "X_STTLM_ACCT_IBAN: {}";
  	final String X_INSTG_RMB_AGT_ACCT_IBAN_VALUE = "X_INSTG_RMB_AGT_ACCT_IBAN: {}.";
  	final String X_STTLM_ACCT_ID_VALUE = "X_STTLM_ACCT_ID: {}";
  	final String X_INSTG_RMB_AGT_ACCT_ID_2AND_VALUE = "X_INSTG_RMB_AGT_ACCT_ID_2AND: {}";
  	final String X_INSTG_RMB_AGT_CLR_SYS_CD_VALUE = "X_INSTG_RMB_AGT_CLR_SYS_CD: {}";
  	final String X_INSTG_RMB_AGT_CLR_SYS_PRTRY_VALUE = "X_INSTG_RMB_AGT_CLR_SYS_PRTRY: {}";
  	final String X_INSTG_RMB_AGT_ID_2AND_VALUE = "X_INSTG_RMB_AGT_ID_2AND: {}";

  	
  	
  	boolean bFoundFirstInChain = false;
  	PDO pdo = Admin.getContextPDO();
  	
    // BIC.
    String sX_INSTG_RMB_AGT_BIC_2AND = pdo.getString(X_INSTG_RMB_AGT_BIC_2AND);
    logger.info(X_INSTG_RMB_AGT_BIC_2AND_VALUE, sX_INSTG_RMB_AGT_BIC_2AND);
    if(!isNullOrEmpty(sX_INSTG_RMB_AGT_BIC_2AND))
    {
      bFoundFirstInChain = true;
      pdo.set(D_FIRST_IN_DBT_CHAIN_BIC, sX_INSTG_RMB_AGT_BIC_2AND);
      pdo.set(D_1ST_IN_DBT_CHA_BIC_FLD_ID, X_INSTG_RMB_AGT_BIC_2AND);
    }
    
    // IBAN.
    String sX_STTLM_ACCT_IBAN = pdo.getString(X_STTLM_ACCT_IBAN);
    logger.info(X_STTLM_ACCT_IBAN_VALUE, sX_STTLM_ACCT_IBAN);
    if(!isNullOrEmpty(sX_STTLM_ACCT_IBAN))
    {
      bFoundFirstInChain = true;
      pdo.set(D_FIRST_IN_DBT_CHAIN_IBAN, sX_STTLM_ACCT_IBAN);
      pdo.set(D_1ST_IN_DBT_CHA_IBAN_FLD_ID, X_STTLM_ACCT_IBAN);
    }
    else // Looks in the 'X_INSTG_RMB_AGT_ACCT_IBAN' field.
    {
    	String sX_INSTG_RMB_AGT_ACCT_IBAN = pdo.getString(X_INSTG_RMB_AGT_ACCT_IBAN);
      logger.info(X_INSTG_RMB_AGT_ACCT_IBAN_VALUE, sX_INSTG_RMB_AGT_ACCT_IBAN);
      if(!isNullOrEmpty(sX_INSTG_RMB_AGT_ACCT_IBAN))
      {
        bFoundFirstInChain = true;
        pdo.set(D_FIRST_IN_DBT_CHAIN_IBAN, sX_INSTG_RMB_AGT_ACCT_IBAN);
        pdo.set(D_1ST_IN_DBT_CHA_IBAN_FLD_ID, X_INSTG_RMB_AGT_ACCT_IBAN);
      }        	
    }
    
    // Account.
    String sX_STTLM_ACCT_ID = pdo.getString(X_STTLM_ACCT_ID);
    logger.info(X_STTLM_ACCT_ID_VALUE, sX_STTLM_ACCT_ID);
    if(!isNullOrEmpty(sX_STTLM_ACCT_ID))
    {
      bFoundFirstInChain = true;
      
      // Handles account cleanup according to char sets profiles definition.
      sX_STTLM_ACCT_ID = BOSTPRules.replaceStringUsingCharSetDefinition(sX_STTLM_ACCT_ID, pdo.getString(P_OFFICE), null);
      pdo.set(X_STTLM_ACCT_ID, sX_STTLM_ACCT_ID);
      
      pdo.set(D_FIRST_IN_DBT_CHAIN_ACC_NUM, sX_STTLM_ACCT_ID);
      pdo.set(D_1ST_IN_DBT_CHA_ACCNUM_FLD_ID, X_STTLM_ACCT_ID);
    }
    else // Looks in the 'X_INSTG_RMB_AGT_ACCT_ID_2AND' field.
    {
    	String sX_INSTG_RMB_AGT_ACCT_ID_2AND = pdo.getString(X_INSTG_RMB_AGT_ACCT_ID_2AND);
      logger.info(X_INSTG_RMB_AGT_ACCT_ID_2AND_VALUE, sX_INSTG_RMB_AGT_ACCT_ID_2AND);
      if(!isNullOrEmpty(sX_INSTG_RMB_AGT_ACCT_ID_2AND))
      {
        bFoundFirstInChain = true;
        
        // Handles account cleanup according to char sets profiles definition.
        sX_INSTG_RMB_AGT_ACCT_ID_2AND = BOSTPRules.replaceStringUsingCharSetDefinition(sX_INSTG_RMB_AGT_ACCT_ID_2AND, pdo.getString(P_OFFICE), null);
        pdo.set(X_INSTG_RMB_AGT_ACCT_ID_2AND, sX_INSTG_RMB_AGT_ACCT_ID_2AND);
                    
        pdo.set(D_FIRST_IN_DBT_CHAIN_ACC_NUM, sX_INSTG_RMB_AGT_ACCT_ID_2AND);
        pdo.set(D_1ST_IN_DBT_CHA_ACCNUM_FLD_ID, X_INSTG_RMB_AGT_ACCT_ID_2AND);
      }        	
    }        
    
    // NCC.
    String sX_INSTG_RMB_AGT_CLR_SYS_PRTRY = null; // NCC proprietary.
    //
    // NCC Code ID.
    String sX_INSTG_RMB_AGT_CLR_SYS_CD = pdo.getString(X_INSTG_RMB_AGT_CLR_SYS_CD);
    logger.info(X_INSTG_RMB_AGT_CLR_SYS_CD_VALUE, sX_INSTG_RMB_AGT_CLR_SYS_CD);
    if(!isNullOrEmpty(sX_INSTG_RMB_AGT_CLR_SYS_CD))
    {
      bFoundFirstInChain = true;
      pdo.set(D_FIRST_IN_DBT_CHAIN_NCC_CODE, sX_INSTG_RMB_AGT_CLR_SYS_CD);
      pdo.set(D_1ST_IN_DBT_CHA_NCC_CD_FLD_ID, X_INSTG_RMB_AGT_CLR_SYS_CD);
    }
    //
    // No NCC code ID, checks for NCC proprietary.
    else
    {
    	sX_INSTG_RMB_AGT_CLR_SYS_PRTRY = pdo.getString(X_INSTG_RMB_AGT_CLR_SYS_PRTRY);
      logger.info(X_INSTG_RMB_AGT_CLR_SYS_PRTRY_VALUE, sX_INSTG_RMB_AGT_CLR_SYS_PRTRY);	      	
      if(!isNullOrEmpty(sX_INSTG_RMB_AGT_CLR_SYS_PRTRY))
      {
        bFoundFirstInChain = true;
        pdo.set(D_FIRST_IN_DBT_CHAIN_NCC_PRTRY, sX_INSTG_RMB_AGT_CLR_SYS_PRTRY);
        pdo.set(D_1ST_IN_DBT_CHA_NCC_PRTRY_FLD_ID, X_INSTG_RMB_AGT_CLR_SYS_PRTRY);
      }
    }
    //
    // NCC member ID; initializes it even if no NCC code or proprietary were found.    
    String sX_INSTG_RMB_AGT_ID_2AND = pdo.getString(X_INSTG_RMB_AGT_ID_2AND);
    logger.info(X_INSTG_RMB_AGT_ID_2AND_VALUE, sX_INSTG_RMB_AGT_ID_2AND);
    if(!isNullOrEmpty(sX_INSTG_RMB_AGT_ID_2AND))
    {
      bFoundFirstInChain = true;        
	    pdo.set(D_1ST_IN_DBT_CHA_NCC_MEM_ID, sX_INSTG_RMB_AGT_ID_2AND);
	    pdo.set(D_1ST_DBT_CHA_NCC_MEM_FLD_ID, X_INSTG_RMB_AGT_ID_2AND);
    }
    
    // Name.
    if(getChainSingleField(X_INSTG_RMB_AGT_NM_2AND, ChainTypeOrigin.NAME, D_FIRST_IN_DBT_CHAIN_NAME, D_1ST_DBT_CHA_NAME_FLD_ID, null)) bFoundFirstInChain = true;
    
    // Address.
    if(getChainSingleField(X_INSTG_RMB_AGT_ADRLINE_2AND, ChainTypeOrigin.ADDR, D_FIRST_IN_DBT_CHAIN_ADDR, D_1ST_DBT_CHA_ADDR_FLD_ID, null)) bFoundFirstInChain = true;
  	
  	
  	
  	return bFoundFirstInChain;
  }

  /**
   * 
   */
  private boolean getDEBIT_InstructingAgentFirstInChain()
  {
  	final String X_INSTG_AGT_BIC_2AND_VALUE = "X_INSTG_AGT_BIC_2AND: {}";
  	final String X_INSTG_AGT_CLR_SYS_CD_VALUE = "X_INSTG_AGT_CLR_SYS_CD: {}";
  	final String X_INSTG_RMB_AGT_CLR_SYS_PRTRY_VALUE = "X_INSTG_RMB_AGT_CLR_SYS_PRTRY: {}";
  	final String X_INSTG_AGT_ID_2AND_VALUE = "X_INSTG_AGT_ID_2AND: {}";

  	
  	
  	boolean bFoundFirstInChain = false;
  	PDO pdo = Admin.getContextPDO();
  	
    // BIC.
    String sX_INSTG_AGT_BIC_2AND = pdo.getString(X_INSTG_AGT_BIC_2AND);
    logger.info(X_INSTG_AGT_BIC_2AND_VALUE, sX_INSTG_AGT_BIC_2AND);
    if(!isNullOrEmpty(sX_INSTG_AGT_BIC_2AND))
    {
      bFoundFirstInChain = true;
      pdo.set(D_FIRST_IN_DBT_CHAIN_BIC, sX_INSTG_AGT_BIC_2AND);
      pdo.set(D_1ST_IN_DBT_CHA_BIC_FLD_ID, X_INSTG_AGT_BIC_2AND);
    }
    
    // NCC.
    String sX_INSTG_AGT_CLR_SYS_PRTRY = null; // NCC proprietary.
    //
    // NCC Code ID.
    String sX_INSTG_AGT_CLR_SYS_CD = pdo.getString(X_INSTG_AGT_CLR_SYS_CD);
    logger.info(X_INSTG_AGT_CLR_SYS_CD_VALUE, sX_INSTG_AGT_CLR_SYS_CD);
    if(!isNullOrEmpty(sX_INSTG_AGT_CLR_SYS_CD))
    {
      bFoundFirstInChain = true;
      pdo.set(D_FIRST_IN_DBT_CHAIN_NCC_CODE, sX_INSTG_AGT_CLR_SYS_CD);
      pdo.set(D_1ST_IN_DBT_CHA_NCC_CD_FLD_ID, X_INSTG_AGT_CLR_SYS_CD);
    }
    //
    // No NCC code ID, checks for NCC proprietary.
    else
    {
    	sX_INSTG_AGT_CLR_SYS_PRTRY = pdo.getString(X_INSTG_AGT_CLR_SYS_PRTRY);
      logger.info(X_INSTG_RMB_AGT_CLR_SYS_PRTRY_VALUE, sX_INSTG_AGT_CLR_SYS_PRTRY);	      	
      if(!isNullOrEmpty(sX_INSTG_AGT_CLR_SYS_PRTRY))
      {
        bFoundFirstInChain = true;
        pdo.set(D_FIRST_IN_DBT_CHAIN_NCC_PRTRY, sX_INSTG_AGT_CLR_SYS_PRTRY);
        pdo.set(D_1ST_IN_DBT_CHA_NCC_PRTRY_FLD_ID, X_INSTG_AGT_CLR_SYS_PRTRY);
      }
    }
    //
    // NCC member ID; initializes it even if no NCC code or proprietary were found.    
    String sX_INSTG_AGT_ID_2AND = pdo.getString(X_INSTG_AGT_ID_2AND);
    logger.info(X_INSTG_AGT_ID_2AND_VALUE, sX_INSTG_AGT_ID_2AND);
    if(!isNullOrEmpty(sX_INSTG_AGT_ID_2AND))
    {
      bFoundFirstInChain = true;        
	    pdo.set(D_1ST_IN_DBT_CHA_NCC_MEM_ID, sX_INSTG_AGT_ID_2AND);
	    pdo.set(D_1ST_DBT_CHA_NCC_MEM_FLD_ID, X_INSTG_AGT_ID_2AND);
    }
    
    // Name.
    if(getChainSingleField(X_INSTG_AGT_NM_2AND, ChainTypeOrigin.NAME, D_FIRST_IN_DBT_CHAIN_NAME, D_1ST_DBT_CHA_NAME_FLD_ID, null)) bFoundFirstInChain = true;
    
    // Address.
    if(getChainSingleField(X_INSTG_AGT_ADRLINE_2AND, ChainTypeOrigin.ADDR, D_FIRST_IN_DBT_CHAIN_ADDR, D_1ST_DBT_CHA_ADDR_FLD_ID, null)) bFoundFirstInChain = true;
  	
  	
  	
  	return bFoundFirstInChain;
  }
  
  /**
   * Sets first in DEBIT chain using the P_DBT_ACCT_NB field. 
   */
  private boolean getDEBIT_DebitAccountFirstInChain()
  {
  	final String TRACE_MONITOR_FLAGS_DATA = "MU_DBT_ACC_NB_MANUALY_ENTERED: {}, MF_DBT_ACCT_ENRICH: {}.";
  	final String ERROR_MESSAGE = "NOTE, (Optional ERROR): P_DBT_ACCT_NB holds a value [{}], but either P_DBT_ACCT_CCY or P_DBT_ACCT_OFFICE or both of them are empty; might fail account derivation later on...";

  	
  	
  	boolean bFoundFirstInChain = false;
  	PDO pdo = Admin.getContextPDO();
  	
  	// If required, checks the P_DBT_ACCT_NB field.
  	String sMU_DBT_ACC_NUM_MANUALY_ENTERED = pdo.getString(MU_DBT_ACC_NB_MANUALY_ENTERED);
  	String sMF_DBT_ACCT_ENRICH = pdo.getString(MF_DBT_ACCT_ENRICH); // Debit acc. enrichment rule OR some manipulation rule.
  	logger.info(TRACE_MONITOR_FLAGS_DATA, sMU_DBT_ACC_NUM_MANUALY_ENTERED, sMF_DBT_ACCT_ENRICH);

  	if(   MONITOR_FLAG_MANUAL_VALUE.equals(sMU_DBT_ACC_NUM_MANUALY_ENTERED) 	
  		 || MONITOR_FLAG_ENRICHED.equals(sMF_DBT_ACCT_ENRICH))
  	{
  		String sP_DBT_ACCT_NB = pdo.getString(P_DBT_ACCT_NB);
  		
  		if(!isNullOrEmpty(sP_DBT_ACCT_NB))
  		{
        bFoundFirstInChain = true;
        pdo.set(D_FIRST_IN_DBT_CHAIN_ACC_NUM, sP_DBT_ACCT_NB);
        pdo.set(D_1ST_IN_DBT_CHA_ACCNUM_FLD_ID, P_DBT_ACCT_NB);
        
        String sP_DBT_ACCT_CCY = pdo.getString(P_DBT_ACCT_CCY);
        String sP_DBT_ACCT_OFFICE = pdo.getString(P_DBT_ACCT_OFFICE);
        
        // If P_DBT_ACCT_NB holds a value, then both P_DBT_ACCT_CCY & P_DBT_ACCT_OFFICE should hold
        // a valid value as well, otherwise in case we'll arrive to account derivation service,
        // the 'BOAccountDerivation.handleExistingAccount' method will fail; thus, the error message here for notification.
        if(isNullOrEmpty(sP_DBT_ACCT_CCY) || isNullOrEmpty(sP_DBT_ACCT_OFFICE))
        {
        	logger.info(ERROR_MESSAGE, sP_DBT_ACCT_NB);
        }
  		}
  	}

  	
  	
  	return bFoundFirstInChain;
  }
  
  /**
   * Currently supports only ChainTypeOrigin 'NAME' and 'ADDR' !!!
   */
  private static boolean getChainSingleField(String sFieldLogicalID, ChainTypeOrigin chainTypeOrigin,
  		                                       String sDerivedFieldLogicalIDToSetValueTo, String sDerivedFieldLogicalIDToSetIDTo,
  		                                       FirstInChainDataHolder firstInChainDataHolder)
  {
  	final String TRACE_METHOD_INPUT = "Method input - Field logical ID: {}, Chain type origin: {}, Derived field to set value to: {}, Derived field to set ID to: {}, Valid FirstInChainDataHolder object: {}.";
  	final String TRACE_METHOD_OUTPUT = "Method output - Found first in chain: {}.";
  	
  	final String TRACE_FIELD_VALUE = "{}: {}.";
  	
  	
  	logger.info(TRACE_METHOD_INPUT,  new Object[]{sFieldLogicalID, chainTypeOrigin, sDerivedFieldLogicalIDToSetValueTo, sDerivedFieldLogicalIDToSetIDTo, (firstInChainDataHolder != null)});
  	
  	boolean bFoundFirstInChain = false;
  	
  	PDO pdo = Admin.getContextPDO();
  	
  	String sFieldValue = null;
  	
  	LogicalFields logicalFields = CacheKeys.LogicalFieldsIdKey.getSingle(sFieldLogicalID);
		FieldType fieldType = logicalFields.getFieldType();
		if(FieldType.isXmlMulti(fieldType))
		{
			int iFieldOccurrences = pdo.countOccurrences(sFieldLogicalID);
			if(iFieldOccurrences > 0)
			{
				// In case of multi XML field, no need for all field data; index 0 satisfies us to know if there is an actual value.
				Object oFieldValue = pdo.get(new Object[] {sFieldLogicalID, 0});
				if(oFieldValue != null) sFieldValue = ((String)oFieldValue).trim();
			}
		}
		else sFieldValue = pdo.getString(sFieldLogicalID);
  	
    logger.info(TRACE_FIELD_VALUE, sFieldLogicalID, sFieldValue);
    if(!isNullOrEmpty(sFieldValue))
    {
      bFoundFirstInChain = true;
      
      if(firstInChainDataHolder == null)
      {
        pdo.set(sDerivedFieldLogicalIDToSetValueTo, sFieldValue);
        pdo.set(sDerivedFieldLogicalIDToSetIDTo, sFieldLogicalID);
      }
      
      else
      {
      	if(ChainTypeOrigin.NAME == chainTypeOrigin)
      	{
	  	    firstInChainDataHolder.setNameValue(sFieldValue);
	  	    firstInChainDataHolder.setNameFieldName(sFieldLogicalID);
      	}
      	else if(ChainTypeOrigin.ADDR == chainTypeOrigin)
      	{
	  	    firstInChainDataHolder.setAddressValue(sFieldValue);
	  	    firstInChainDataHolder.setAddressFieldName(sFieldLogicalID);
      	}
      }
    }
    
    logger.info(TRACE_METHOD_OUTPUT, bFoundFirstInChain);
    
  	
    return bFoundFirstInChain;
  }
  
  /**
   * 
   */
  public static class FirstInChainDataHolder implements java.io.Externalizable,java.lang.Cloneable
  {
  	FirstInChainType m_firstInChainType;
  	
    ChainType m_chainType;
    ChainTypeOrigin m_chainTypeOrigin;

    String m_sBICValue;
    String m_sBICFieldName;
  	
    String m_sIBANValue;
    String m_sIBANFieldName;

    String m_sAccountNumberValue;
    String m_sAccountNumberFieldName;
    
    String m_sNCCCodeValue;
    String m_sNCCCodeFieldName;

    String m_sNCCProprietaryValue;
    String m_sNCCProprietaryFieldName;

    String m_sNCCMemberIDValue;
    String m_sNCCMemberIDFieldName;

    String m_sNameValue;
    String m_sNameFieldName;

    String m_sAddressValue;
    String m_sAddressFieldName;

    ChainType m_creditorAgentChainType;
    ChainTypeOrigin m_creditorAgentChainTypeOrigin;
    String m_sCreditorAgentFieldValue;
    String m_sCreditorAgentFieldName;
    
    String m_sCustCode;
    String m_sCountryCode;
    
    public FirstInChainDataHolder()
    {
    }
    
    public FirstInChainType getFirstInChainType() {return m_firstInChainType;};
    public ChainType getChainType() {return m_chainType;};
    public ChainTypeOrigin getChainTypeOrigin() {return m_chainTypeOrigin;};
    public String getBICValue() {return m_sBICValue;};
    public String getBICFieldName() {return m_sBICFieldName;};
    public String getIBANValue() {return m_sIBANValue;};
    public String getIBANFieldName() {return m_sIBANFieldName;};
    public String getAccountNumberValue() {return m_sAccountNumberValue;};
    public String getAccountNumberFieldName() {return m_sAccountNumberFieldName;};
    public String getNCCCodeValue() {return m_sNCCCodeValue;};
    public String getNCCCodeFieldName() {return m_sNCCCodeFieldName;};
    public String getNCCProprietaryValue() {return m_sNCCProprietaryValue;};
    public String getNCCProprietaryFieldName() {return m_sNCCProprietaryFieldName;};
    public String getNCCMemberIDValue() {return m_sNCCMemberIDValue;};
    public String getNCCMemberIDFieldName() {return m_sNCCMemberIDFieldName;};
    public String getNameValue() {return m_sNameValue;};
    public String getNameFieldName() {return m_sNameFieldName;};
    public String getAddressValue() {return m_sAddressValue;};
    public String getAddressFieldName() {return m_sAddressFieldName;};
    public ChainType getCreditorAgentChainType() {return m_creditorAgentChainType;};
    public ChainTypeOrigin getCreditorAgentChainTypeOrigin() {return m_creditorAgentChainTypeOrigin;};
    public String getCreditorAgentFieldValue() {return m_sCreditorAgentFieldValue;};
    public String getCreditorAgentFieldName() {return m_sCreditorAgentFieldName;};
    public String getCustCode() {return m_sCustCode;};
    public String getCountryCode() {return m_sCountryCode;};
    
    public void setFirstInChainType(FirstInChainType firstInChainType) {m_firstInChainType = firstInChainType;};
    public void setChainTypeName(ChainType chainType) {m_chainType = chainType;};
    public void setChainTypeOrigin(ChainTypeOrigin chainTypeOrigin) {m_chainTypeOrigin = chainTypeOrigin;};
    public void setBICValue(String sBICValue) {m_sBICValue = sBICValue;};
    public void setBICFieldName(String sBICFieldName) {m_sBICFieldName = sBICFieldName;};
    public void setIBANValue(String sIBANValue) {m_sIBANValue = sIBANValue;};
    public void setIBANFieldName(String sIBANFieldName) {m_sIBANFieldName = sIBANFieldName;};
    public void setAccountNumberValue(String sAccountNumberValue) {m_sAccountNumberValue = sAccountNumberValue;};
    public void setAccountNumberFieldName(String sAccountNumberFieldName) {m_sAccountNumberFieldName = sAccountNumberFieldName;};
    public void setNCCCodeValue(String sNCCCodeValue) {m_sNCCCodeValue = sNCCCodeValue;};
    public void setNCCCodeFieldName(String sNCCCodeFieldName) {m_sNCCCodeFieldName = sNCCCodeFieldName;};
    public void setNCCProprietaryValue(String sNCCProprietaryValue) {m_sNCCProprietaryValue = sNCCProprietaryValue;};
    public void setNCCProprietaryFieldName(String sNCCProprietaryFieldName) {m_sNCCProprietaryFieldName = sNCCProprietaryFieldName;};
    public void setNCCMemberIDValue(String sNCCMemberIDValue) {m_sNCCMemberIDValue = sNCCMemberIDValue;};
    public void setNCCMemberIDFieldName(String sNCCMemberIDFieldName) {m_sNCCMemberIDFieldName = sNCCMemberIDFieldName;};
    public void setNameValue(String sNameValue) {m_sNameValue = sNameValue;};
    public void setNameFieldName(String sNameFieldName) {m_sNameFieldName = sNameFieldName;};
    public void setAddressValue(String sAddressValue) {m_sAddressValue = sAddressValue;};
    public void setAddressFieldName(String sAddressFieldName) {m_sAddressFieldName = sAddressFieldName;};
    public void setCreditorAgentChainType(ChainType creditorAgentChainType) {m_creditorAgentChainType = creditorAgentChainType;};
    public void setCreditorAgentChainTypeOrigin(ChainTypeOrigin creditorAgentChainTypeOrigin) {m_creditorAgentChainTypeOrigin = creditorAgentChainTypeOrigin;};
    public void setCreditorAgentFieldValue(String sCreditorAgentFieldValue) {m_sCreditorAgentFieldValue = sCreditorAgentFieldValue;};
    public void setCreditorAgentFieldName(String sCreditorAgentFieldName) {m_sCreditorAgentFieldName = sCreditorAgentFieldName;};
    public void setCustCode(String sCustCode) {m_sCustCode = sCustCode;};
    public void setCountryCode(String sCountryCode) {m_sCountryCode = sCountryCode;};
    
    public void readExternal(java.io.ObjectInput in) throws java.io.IOException, ClassNotFoundException
  	{
    	m_firstInChainType = (FirstInChainType)in.readObject();
  		m_chainType = (ChainType)in.readObject();
  		m_chainTypeOrigin = (ChainTypeOrigin)in.readObject();
  		m_sBICValue = (String)in.readObject();
  		m_sBICFieldName = (String)in.readObject();
  		m_sIBANValue = (String)in.readObject();
  		m_sIBANFieldName = (String)in.readObject();
  		m_sAccountNumberValue = (String)in.readObject();
  		m_sAccountNumberFieldName = (String)in.readObject();
  		m_sNCCCodeValue = (String)in.readObject();
  		m_sNCCCodeFieldName = (String)in.readObject();
  		m_sNCCProprietaryValue = (String)in.readObject();
  		m_sNCCProprietaryFieldName = (String)in.readObject();
  		m_sNCCMemberIDValue = (String)in.readObject();
  		m_sNCCMemberIDFieldName = (String)in.readObject();
  		m_sNameValue = (String)in.readObject();
  		m_sNameFieldName = (String)in.readObject();
  		m_sAddressValue = (String)in.readObject();
  		m_sAddressFieldName = (String)in.readObject();
      m_creditorAgentChainType = (ChainType)in.readObject();
      m_creditorAgentChainTypeOrigin = (ChainTypeOrigin)in.readObject();
      m_sCreditorAgentFieldValue = (String)in.readObject(); 
      m_sCreditorAgentFieldName = (String)in.readObject();
      m_sCustCode = (String)in.readObject();
      m_sCountryCode = (String)in.readObject();
  	}

  	public void writeExternal(java.io.ObjectOutput out) throws java.io.IOException
  	{
  		out.writeObject(m_firstInChainType);
  		out.writeObject(m_chainType);
  		out.writeObject(m_chainTypeOrigin);
  		out.writeObject(m_sBICValue);
  		out.writeObject(m_sBICFieldName);
  		out.writeObject(m_sIBANValue);
  		out.writeObject(m_sIBANFieldName);
  		out.writeObject(m_sAccountNumberValue);
  		out.writeObject(m_sAccountNumberFieldName);
  		out.writeObject(m_sNCCCodeValue);
  		out.writeObject(m_sNCCCodeFieldName);
  		out.writeObject(m_sNCCProprietaryValue);
  		out.writeObject(m_sNCCProprietaryFieldName);
  		out.writeObject(m_sNCCMemberIDValue);
  		out.writeObject(m_sNCCMemberIDFieldName);
  		out.writeObject(m_sNameValue);
  		out.writeObject(m_sNameFieldName);
  		out.writeObject(m_sAddressValue);
  		out.writeObject(m_sAddressFieldName);
  		out.writeObject(m_creditorAgentChainType);
  		out.writeObject(m_creditorAgentChainTypeOrigin);
  		out.writeObject(m_sCreditorAgentFieldValue);
  		out.writeObject(m_sCreditorAgentFieldName);
  		out.writeObject(m_sCustCode);
  		out.writeObject(m_sCountryCode);
  	}
  }
}
