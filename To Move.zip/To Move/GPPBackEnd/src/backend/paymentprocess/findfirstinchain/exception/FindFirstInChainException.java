package backend.paymentprocess.findfirstinchain.exception;

import com.fundtech.core.paymentprocess.errorhandling.BusinessException;

/**
 * Title:       FindFirstInChainException
 * Description: Class for all finding first in chain exceptions
 * Company:     Fundtech Israel
 * Author:      Asaf Levy
 * Date:        06/09/2008
 * @version     1.0
 */
public class FindFirstInChainException extends BusinessException
{
  private static final long serialVersionUID = -463673756708464723L;
  
  public FindFirstInChainException()
  {
    super();
  }
  
  public FindFirstInChainException(String string, Throwable e)
  {
    super(string, e);
  }
}
