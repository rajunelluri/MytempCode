package backend.paymentprocess.findfirstinchain.ejbinterfaces;

import javax.ejb.Local;

/**
 * Local interface for FindFirstInChain.
 */
@Local
public interface FindFirstInChainLocal extends FindFirstInChain{} ; 