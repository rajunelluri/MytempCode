package backend.paymentprocess.findfirstinchain.ejbinterfaces;

import javax.ejb.Remote;
import com.fundtech.core.security.Admin;

/**
 * Remote interface for FindFirstInChain.
 */
@Remote
public interface FindFirstInChain{

	public static final String REMOTE_JNDI_NAME="ejb/FindFirstInChainBean";
	
	
	/** 
	 * Finds the first in chain of either credit or debit side for the passed MID.
	 */
	public com.fundtech.datacomponent.response.Feedback findFirstInChain(final Admin admin, java.lang.String sMID ) throws backend.paymentprocess.findfirstinchain.exception.FindFirstInChainException ;

}//EOI  