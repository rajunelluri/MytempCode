package backend.paymentprocess.findfirstinchain.ejb;

import javax.ejb.Stateless;
import backend.core.SuperSLSB;
import com.fundtech.core.security.Admin;
import backend.businessobject.proxies.interceptors.InterceptorSetType;
import backend.paymentprocess.findfirstinchain.businessobjects.BOFindFirstInChain;
import backend.paymentprocess.findfirstinchain.ejbinterfaces.FindFirstInChainLocal;
import backend.paymentprocess.findfirstinchain.ejbinterfaces.FindFirstInChain;

@Stateless
public class FindFirstInChainBean extends SuperSLSB<FindFirstInChain> implements FindFirstInChainLocal, FindFirstInChain{
	
	public FindFirstInChainBean() { super(backend.paymentprocess.findfirstinchain.businessobjects.BOFindFirstInChain.class, InterceptorSetType.PdoHandling) ; }//EOM
	
	
	/** 
	 * Finds the first in chain of either credit or debit side for the passed MID.
	 */
	public com.fundtech.datacomponent.response.Feedback findFirstInChain(final Admin admin, java.lang.String sMID ) throws backend.paymentprocess.findfirstinchain.exception.FindFirstInChainException {
		return this.m_bo.findFirstInChain(admin, sMID ) ;
	}//EOM

}//EOC