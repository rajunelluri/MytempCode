package backend.paymentprocess.compliance.ejbinterfaces;

import javax.ejb.Remote;

import com.fundtech.core.security.Admin;

/**
 * Remote interface for Compliance.
 */
@Remote
public interface Compliance{

	public static final String REMOTE_JNDI_NAME="ejb/ComplianceBean";
	
	
	public com.fundtech.datacomponent.response.Feedback performComplianceCheck(final Admin admin, java.lang.String sMID, boolean isSync );
	
	public com.fundtech.datacomponent.response.Feedback responseTransmission(String externalServiceResults);
	
	/** 
	 * @param mid
	 * @param sListName
	 * @return
	 * @throws Exception
	 */
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent performExternalComplianceCheck(final Admin admin, java.lang.String mid, java.lang.String sListName ) throws java.lang.Throwable ;

}//EOI  