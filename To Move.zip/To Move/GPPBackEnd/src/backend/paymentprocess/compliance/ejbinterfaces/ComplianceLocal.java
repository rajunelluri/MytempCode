package backend.paymentprocess.compliance.ejbinterfaces;

import javax.ejb.Local;

/**
 * Local interface for Compliance.
 */
@Local
public interface ComplianceLocal extends Compliance{} ; 