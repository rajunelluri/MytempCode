package backend.paymentprocess.compliance.businessobjects;

import static com.fundtech.util.GlobalUtils.isListNullOrEmpty;
import static com.fundtech.util.GlobalUtils.isNullOrEmpty;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.namespace.QName;

import org.apache.xmlbeans.impl.values.XmlObjectBase;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.businessobject.BOBasic;
import backend.businessobject.BOProxies;
import backend.core.module.MessageConstantsInterface;
import backend.paymentprocess.compliance.dao.DAOCompliance;
import backend.paymentprocess.erroraudit.ErrorAuditUtils;
import backend.util.ServerConstants;

import com.fundtech.annotations.Expose;
import com.fundtech.annotations.Wrap;
import com.fundtech.cache.entities.InterfaceTypes;
import com.fundtech.cache.entities.Journalmessages;
import com.fundtech.cache.entities.LogicalFields;
import com.fundtech.cache.entities.Newjournal;
import com.fundtech.cache.entities.RuleResult;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.core.paymentprocess.data.fields.FieldType;
import com.fundtech.core.paymentprocess.errorhandling.ProcessError;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.datacomponent.response.SimpleResponseDataComponent;
import com.fundtech.errors.ProcessErrorConstants;
import com.fundtech.scl.commonTypes.MsgTableEntryBaseType;
import com.fundtech.scl.commonTypes.MsgTableType;
import com.fundtech.scl.commonTypes.MtableDocument;
import com.fundtech.scl.commonTypes.RecordType;
import com.fundtech.util.ErrorAuditInputData;
import com.fundtech.util.ExceptionController;


@Wrap(tx = "Bean")

public class BOCompliance extends BOBasic implements PDOConstantFieldsInterface, MessageConstantsInterface 
{

	private static final Logger logger = LoggerFactory.getLogger(BOCompliance.class);
	
	
	private static final ProcessError m_pErrorComplianceValidationFailure = new ProcessError(ProcessErrorConstants.ComplianceValidationFailure);
	private static final ProcessError m_pErrorIllegalSetupMissingComplianceValidationRule = new ProcessError(ProcessErrorConstants.IllegalSetupMissingComplianceValidationRule);

	private static final long ERROR_CODE_COMPLIANCE_HITS_WERE_FOUND = Long.valueOf(ProcessErrorConstants.ComplianceHitsWereFound);
	private static final long ERROR_CODE_FRAUD_HITS_WERE_FOUND = Long.valueOf(ProcessErrorConstants.FraudHitsWereFound);
	private static final long ERROR_CODE_COMPLIANCE_AND_FRAUD_HITS_WERE_FOUND = Long.valueOf(ProcessErrorConstants.ComplianceAndFraudHitsWereFound);

	private static final String LAST_STEP = "Last step: ";
	private static final String STEP_COMPLIANCE_VALIDATION_RULE = "Compliance validation rule";
	private static final String STEP_EXTERNAL_COMPLIANCE_CHECK_SERVICE = "External compliance check service";
	private static final String STEP_COMPLIANCE_SERVICE_RESULTS_ANALYZE = "External compliance service results analyze";
	private static final String STEP_POST_COMPLIANCE_SERVICE_RESULTS_ANALYZE = "Post external compliance service results analyze";
	private static final String STEP_ADDING_NEWJOURNAL_ENTRIES = "Adding NEWJOURNAL entries";
	private static final String FIELD_FIELD_LOGICAL_ID = "FIELD_LOGICAL_ID";
	private static DAOCompliance m_dao = new DAOCompliance();
	private static List<String> m_giLogicalFieldsList;
	
	private static Set<String> m_setKnownHitTypes;
	
	@Expose
	public Feedback performComplianceCheck(String sMID, boolean isSync) 
	{
		final String TRACE_PERFORM_COMPLIANCE_CHECK_PROCESS_INPUT = "BOCompliance.performComplianceCheck input - MID: {}.";
		final String TRACE_NO_COMPLIANCE_VALIDATION_RULE = "Illegal setup - no definition of compliance validation rule; sets message status to REPAIR.";
		final String TRACE_COMPLIANCE_VALIDATION_BYPASS = "Compliance validation rule has returned BYPASS; sets 'MF_COMPLIANCE_VALIDATION_STS' to 'B' and exits the service.";
		final String TRACE_RESULTS_NO_HIT = "No hit; sets 'MF_COMPLIANCE_VALIDATION_STS' to 'N'.";

		final String SERVICE_COMPLIANCE = "Compliance";

		
		
		if(m_setKnownHitTypes == null) initKnownHitTypesSet(); 

		Feedback feedback = new Feedback();
		PDO pdo = null;
		String sLastStep = null;

		try
		{
			pdo = PaymentDataFactory.load(sMID);
			Admin admin = Admin.getContextAdmin();

			logger.info(TRACE_PERFORM_COMPLIANCE_CHECK_PROCESS_INPUT, sMID);

			// Invokes the compliance validation rule.
			sLastStep = STEP_COMPLIANCE_VALIDATION_RULE;
			String sRuleResult = invokeComplianceValidationRule();

			// If no rule was defined, sends message to REAPIR.
			if (isNullOrEmpty(sRuleResult))
			{
				logger.info(TRACE_NO_COMPLIANCE_VALIDATION_RULE);

				// Adds error message entry.
				ErrorAuditUtils.setErrors(m_pErrorComplianceValidationFailure,pdo.getIsHistory());
				pdo.set(P_MSG_STS, MESSAGE_STATUS_REPAIR);

				configureErrorFeedback(m_pErrorIllegalSetupMissingComplianceValidationRule.getErrorCode(),
						m_pErrorIllegalSetupMissingComplianceValidationRule.getDescription(), feedback);
			}

			// No need to continue if rule result is 'BYPASS'.
			else if (sRuleResult.equals(SYS_RULE_ACTION_BYPASS))
			{
				logger.info(TRACE_COMPLIANCE_VALIDATION_BYPASS);
				pdo.set(MF_COMPLIANCE_VALIDATION_STS, MONITOR_FLAG_COMPLIANCE_BYPASSED);
			}

			// Got back an OFAC list as the rule result.
			else
			{
				// Invokes an external compliance check service.
				sLastStep = STEP_EXTERNAL_COMPLIANCE_CHECK_SERVICE;
				String externalServiceResults = performExternalComplianceCheck(pdo, sRuleResult);
				if (isSync){
					responseTransmission(externalServiceResults);
				}
			}
		}
		catch (Throwable e)
		{
			logger.info(LAST_STEP + sLastStep);
			ExceptionController.getInstance().handleException(e, this);
			feedback = new Feedback();
			ProcessError pError = new ProcessError(ProcessErrorConstants.ServiceFailureWithLastStep, new Object[] { SERVICE_COMPLIANCE, sLastStep });
			configureErrorFeedback(pError.getErrorCode(), pError.getDescription(), feedback);
			ErrorAuditUtils.setErrors(pError,pdo.getIsHistory());
		}
		
		return feedback;
	}		
				
	@Expose			
	public 	Feedback responseTransmission(String externalServiceResults)
	{		
		final String TRACE_RESULTS_NO_HIT = "No hit; sets 'MF_COMPLIANCE_VALIDATION_STS' to 'N'.";
		final String SERVICE_COMPLIANCE = "Compliance";
		
		PDO pdo = Admin.getContextPDO();
		Feedback feedback = new Feedback();
		String sLastStep = null;		
				
		try
		{		
				// No hit.
				if (isNullOrEmpty(externalServiceResults))
				{
					logger.info(TRACE_RESULTS_NO_HIT);
					pdo.set(MF_COMPLIANCE_VALIDATION_STS, MONITOR_FLAG_COMPLIANCE_NO_HIT);
				}

				// Hits were found.
				else
				{
					sLastStep = STEP_COMPLIANCE_SERVICE_RESULTS_ANALYZE;
					Map<String, Map<String, String>> mapHitTypeToRelatedFields = analyzeExternalComplianceCheckServiceResults(externalServiceResults);

					// We have NEW hits, (either for the first time or after a force action).
					// If there are no new hits, service exists with success.
					if (!mapHitTypeToRelatedFields.isEmpty())
					{
						sLastStep = STEP_POST_COMPLIANCE_SERVICE_RESULTS_ANALYZE;

						// Clears the user monitor.
						pdo.set(MU_COMPLIANCE_FORCE_STS, MONITOR_FLAG_X);

						// Sets service monitor to 'H'.
						pdo.set(MF_COMPLIANCE_VALIDATION_STS, MONITOR_FLAG_COMPLIANCE_HIT);

						// Adds error message entry.
						ErrorAuditUtils.setErrors(m_pErrorComplianceValidationFailure,pdo.getIsHistory());

						// Adds NEWJOURNAL entries.
						sLastStep = STEP_ADDING_NEWJOURNAL_ENTRIES;
						if (mapHitTypeToRelatedFields.get(HIT_TYPE_COMPLIANCE) != null) addNewJournalEntry(HIT_TYPE_COMPLIANCE,
								ERROR_CODE_COMPLIANCE_HITS_WERE_FOUND, mapHitTypeToRelatedFields.get(HIT_TYPE_COMPLIANCE));
						if (mapHitTypeToRelatedFields.get(HIT_TYPE_FRAUD) != null) addNewJournalEntry(HIT_TYPE_FRAUD,
								ERROR_CODE_FRAUD_HITS_WERE_FOUND, mapHitTypeToRelatedFields.get(HIT_TYPE_FRAUD));
						if (mapHitTypeToRelatedFields.get(HIT_TYPE_BOTH) != null) addNewJournalEntry(HIT_TYPE_BOTH,
								ERROR_CODE_COMPLIANCE_AND_FRAUD_HITS_WERE_FOUND, mapHitTypeToRelatedFields.get(HIT_TYPE_BOTH));

						// Configures returned feedback.
						configureErrorFeedback(m_pErrorComplianceValidationFailure.getErrorCode(), m_pErrorComplianceValidationFailure
								.getDescription(), feedback);
					}
				}
		}

		catch (Throwable e)
		{
			logger.info(LAST_STEP + sLastStep);
			ExceptionController.getInstance().handleException(e, this);
			feedback = new Feedback();
			ProcessError pError = new ProcessError(ProcessErrorConstants.ServiceFailureWithLastStep, new Object[] { SERVICE_COMPLIANCE, sLastStep });
			configureErrorFeedback(pError.getErrorCode(), pError.getDescription(), feedback);
			ErrorAuditUtils.setErrors(pError,pdo.getIsHistory());
		}
		return feedback;
	}

	/**
	 * 
	 */
	private String performExternalComplianceCheck(PDO pdo, String sListName) throws Throwable 
	{
		
		
		String response = null;
		pdo.setTransient(PDOConstantFieldsInterface.D_OFAC_LIST_NAME, sListName);
		
				
		final SimpleResponseDataComponent interfaceResponse = 
			BOProxies.m_internalInterfacesLogging.performOutgoingRequestHandler(Admin.getContextAdmin(), pdo.getMID(), InterfaceTypes.INTERFACE_TYPE_OFAC, (String)null);
		
		
		InterfaceTypes interfaceTypes = CacheKeys.interfaceTypesKey.getSingle(pdo.getString(P_OFFICE), InterfaceTypes.INTERFACE_TYPE_OFAC, null);
		if (interfaceTypes.getInterfaceStatus().equals("NOT_ACTIVE")){
			
			//Set monitor to D in case interface is not active
			pdo.set(MF_COMPLIANCE_VALIDATION_STS, MONITOR_FLAG_COMPLIANCE_INTERFACE_DOWN);
			logger.debug("Request to {} interface was not sent, interface is not active", InterfaceTypes.INTERFACE_TYPE_OFAC);
			return response;
		}
		
		if (interfaceResponse.getFeedback().isSuccessful())
		{
			response = (String)pdo.getTransient(PDOConstantFieldsInterface.D_OFAC_RESPONSE);
		}
		
		return response;
	}

	/**
	 * @param mid
	 * @param sListName
	 * @return
	 * @throws Exception
	 */
	@Expose
	public SimpleResponseDataComponent performExternalComplianceCheck(String mid, String sListName) throws Throwable 
	{
		PDO pdo = PaymentDataFactory.load(mid);
		String performExternalComplianceCheck = performExternalComplianceCheck(pdo, sListName);
		SimpleResponseDataComponent simpleResponseDataComponent = new SimpleResponseDataComponent();
		simpleResponseDataComponent.setDataArray(new Object[] { performExternalComplianceCheck });
		Feedback feedback = new Feedback();
		feedback.setErrorText(performExternalComplianceCheck);
		simpleResponseDataComponent.setFeedback(feedback);
		return simpleResponseDataComponent;
	}

	/**
	 * @return
	 * @throws Exception
	 */
	private String invokeComplianceValidationRule() throws Exception 
	{
		final String TRACE_METHOD_OUTPUT = "Compliance validation rule result: ";

		

		String sRuleResult = ServerConstants.EMPTY_STRING;

		PDO pdo = Admin.getContextPDO();
		String[] arrObjectIDs = new String[] { pdo.getString(P_OFFICE) };

		List<RuleResult> listRuleResults = BOProxies.m_internalRuleExecutionLogging.executeRule(Admin.getContextAdmin(), RULE_TYPE_ID_COMPLIANCE_VALIDATION, null,
				pdo.getMID(), arrObjectIDs).getResults();

		if (!listRuleResults.isEmpty()) sRuleResult = listRuleResults.get(0).getAction();

		logger.info(TRACE_METHOD_OUTPUT + sRuleResult);
		

		return sRuleResult;
	}

	/**
   * 
   */
	private Map<String, Map<String, String>> analyzeExternalComplianceCheckServiceResults(String sExternalServiceResults) 
	{
		final String TRACE_METHOD_INPUT = "External compliance check service results: ";

		
		logger.info(TRACE_METHOD_INPUT + sExternalServiceResults);

		// Will hold all hits that need to be saved into NEWJOURNAL !!!
		// Map in which:
		// Key - Hit type.
		// Value - Map in which: key - field ID.
		// value - hit info.
		Map<String, Map<String, String>> mapFinalHitTypeToRelatedFields = new HashMap<String, Map<String, String>>();

		PDO pdo = Admin.getContextPDO();

		// Parses the external service results.
		Object[] arrExternalServiceResults = new Object[2];
		parseExternalServiceResults(sExternalServiceResults, arrExternalServiceResults);

		// Map in which:
		// Key - Field ID.
		// Value - Delimited string in following format: 'HIT_INFO~HIT_TYPE'.
		Map<String, String> mapFieldIDToHitInfoAndType = (Map<String, String>) arrExternalServiceResults[0];

		// Map in which:
		// Key - Hit type.
		// Value - Map in which: key - field ID.
		// value - hit info.
		Map<String, Map<String, String>> mapHitTypeToRelatedFields = (Map<String, Map<String, String>>) arrExternalServiceResults[1];

		// Gets the related usre moniotr field value.
		String sMU_COMPLIANCE_FORCE_STS = pdo.getString(MU_COMPLIANCE_FORCE_STS);
		boolean bComplianceAlreadyForced = sMU_COMPLIANCE_FORCE_STS != null && MONITOR_FLAG_FORCE.equals(sMU_COMPLIANCE_FORCE_STS);

		// If compliance was already forced by the user, then need to make sure that the received hits results
		// were not already included in the forced ones; that is done by loading data from NEWJOURNAL table
		// which keeps the previous hits data and comparing it with the new hit data.
		if (bComplianceAlreadyForced)
		{
			Map<String, String> mapPreviousHitsData = getPreviousHitsData();

			// Loops the received hits info and decides whether this is a new hit info or not.
			Iterator<String> iterKeys = mapFieldIDToHitInfoAndType.keySet().iterator();

			while (iterKeys.hasNext())
			{
				String sFieldID = iterKeys.next();
				String sHitInfoAndType = mapFieldIDToHitInfoAndType.get(sFieldID);

				String sHitInfoAndTypeFromPreviousData = mapPreviousHitsData.get(sFieldID);

				// A hit is considered as new if:
				// 1) Its related field ID didn't exist yet in the previous hits data.
				// OR 2) Its related field ID exists in the previous hits data but the hit info and type of it
				// don't equal the received hit info and type.
				boolean bNewHit = sHitInfoAndTypeFromPreviousData == null
						              || (sHitInfoAndTypeFromPreviousData != null && !sHitInfoAndTypeFromPreviousData.equals(sHitInfoAndType));

				// New hit; updates the 'mapFinalHitTypeToRelatedFields' map.
				if (bNewHit)
				{
					String[] arrHitInfoAndType = sHitInfoAndType.split(ServerConstants.TILDA);

					String sHitInfo = arrHitInfoAndType[0];
					String sHitType = arrHitInfoAndType[1];

					if (mapFinalHitTypeToRelatedFields.get(sHitType) == null)
					{
						mapFinalHitTypeToRelatedFields.put(sHitType, new HashMap<String, String>());
					}
					mapFinalHitTypeToRelatedFields.get(sHitType).put(sFieldID, sHitInfo);
					
					// If the hit type is not one of the known types, (i.e. C, F or B), then writes notification into the trace file.
					// Value is still added into the returned HashMap, but no NEWJOURNAL entry be added for it as done for the
					// known hit types, (see the end of the 'performComplianceCheck' method).
					if(!m_setKnownHitTypes.contains(sHitType))
					{
						final String TRACE_INVALID_HIT_TYPE = "WARNING: Invalid hit type ({}) was found for field {} with hit info {}; NEWJOURNAL entry won't be added for this hit !!!";
						logger.info(TRACE_INVALID_HIT_TYPE,  new Object[]{sHitType, sFieldID, sHitInfo});
					}
				}
			}
		}

		// No compliance override was done yet; all hits are considered as new and should be entered into NEWJOURNAL.
		else
		{
			mapFinalHitTypeToRelatedFields = mapHitTypeToRelatedFields;
		}

		

		return mapFinalHitTypeToRelatedFields;
	}
	
	/**
	 * 
	 */
	private static void initKnownHitTypesSet()
	{
		m_setKnownHitTypes = new HashSet<String>();
		m_setKnownHitTypes.add(HIT_TYPE_COMPLIANCE);
		m_setKnownHitTypes.add(HIT_TYPE_FRAUD);
		m_setKnownHitTypes.add(HIT_TYPE_BOTH);
	}

	/**
   * 
   */
	private void parseExternalServiceResults(String sExternalServiceResults, Object[] arrExternalServiceResults)
	{
		

		// Map in which:
		// Key - Field ID.
		// Value - Delimited string in following format: 'HIT_INFO~HIT_TYPE'.
		Map<String, String> mapFieldIDToHitInfoAndType = new HashMap<String, String>();

		// Map in which:
		// Key - Hit type.
		// Value - Map in which: key - field ID.
		// value - hit info.
		Map<String, Map<String, String>> mapHitTypeToRelatedFields = new HashMap<String, Map<String, String>>();

		String[] arrHits = sExternalServiceResults.split(ServerConstants.COMMA);

		for (int i = 0; i < arrHits.length; i++)
		{
			String[] arrSingleHit = arrHits[i].split(ServerConstants.TILDA);

			String sFieldID = arrSingleHit[0].trim();
			String sHitInfo = arrSingleHit[1].trim();
			String sHitType = arrSingleHit[2].trim();

			// Updates the 'mapFieldIDToHitInfoAndType' map.
			String sHitValueAndType = new StringBuilder(sHitInfo).append(ServerConstants.TILDA).append(sHitType).toString();
			mapFieldIDToHitInfoAndType.put(sFieldID, sHitValueAndType);

			// Upadtes the 'mapHitTypeToRelatedFields' map.
			if (mapHitTypeToRelatedFields.get(sHitType) == null)
			{
				mapHitTypeToRelatedFields.put(sHitType, new HashMap<String, String>());
			}
			mapHitTypeToRelatedFields.get(sHitType).put(sFieldID, sHitInfo);
		}

		arrExternalServiceResults[0] = mapFieldIDToHitInfoAndType;
		arrExternalServiceResults[1] = mapHitTypeToRelatedFields;

		
	}

	/**
   * 
   */
	private Map<String, String> getPreviousHitsData() 
	{
		final QName NEW_VALUE_QNAME = new QName("http://fundtech.com/SCL/CommonTypes", "NEW_VALUE");
		final QName OLD_VALUE_QNAME = new QName("http://fundtech.com/SCL/CommonTypes", "OLD_VALUE");

		

		// Map in which:
		// Key - Field ID.
		// Value - Delimited string in following format: 'HIT_INFO~HIT_TYPE'.
		Map<String, String> mapPreviousHitsData = new HashMap<String, String>();

		PDO pdo = Admin.getContextPDO();
		List<Newjournal> listNewjournal = pdo.getNSetListNEWJOURNAL(true);

		if (!isListNullOrEmpty(listNewjournal))
		{
			int iSize = listNewjournal.size();

			// Reversed 'for' loop !!!
			// NEWJOURNAL list is ordered by descending time stamp and thus the reversed 'for' loop.
			for (int i = iSize - 1; i >= 0; i--)
			{
				Newjournal newjournal = listNewjournal.get(i);

				long shTypeFieldsChangeVerify = newjournal.getTypeFieldsChangeVerify() != null ? newjournal.getTypeFieldsChangeVerify() : 0;

				if (Journalmessages.TYPE_FIELDS_CHANGE_VERIFY_COMPLIANCE == shTypeFieldsChangeVerify
						|| Journalmessages.TYPE_FIELDS_CHANGE_VERIFY_FRAUD == shTypeFieldsChangeVerify
						|| Journalmessages.TYPE_FIELDS_CHANGE_VERIFY_BOTH_COMPLIANCE_AND_FRAUD == shTypeFieldsChangeVerify)
				{
					MtableDocument mTableDocument = newjournal.getRelatedFieldsDataXml();

					if (mTableDocument != null)
					{
						RecordType[] arrRecords = mTableDocument.getMtable().getRecordArray();

						for (RecordType recordType : arrRecords)
						{
							MsgTableEntryBaseType[] arrMsgEntryBaseTypeEntry = recordType.getColumnArray();

							for (MsgTableEntryBaseType msgTableEntryBaseType : arrMsgEntryBaseTypeEntry)
							{
								String sFieldID = msgTableEntryBaseType.getId();

								// The OLD_VALUE tag holds the full value of the field.
								// String sFullFieldValue =
								// ((XmlObjectBase)((XmlObjectBase)msgTableEntryBaseType).selectChildren(OLD_VALUE_QNAME)[0]).getStringValue();

								// The NEW_VALUE tag holds the partial value of the field which is actually the found hit.
								String sHitInfo = ((XmlObjectBase) ((XmlObjectBase) msgTableEntryBaseType).selectChildren(NEW_VALUE_QNAME)[0])
										.getStringValue();

								// Replaces the numeric value with a char value, (C=Compliance, F=Fraud, B=Both).
								String sHitType = null;
								if (shTypeFieldsChangeVerify == 5) sHitType = HIT_TYPE_COMPLIANCE;
								else if (shTypeFieldsChangeVerify == 6) sHitType = HIT_TYPE_FRAUD;
								else if (shTypeFieldsChangeVerify == 7) sHitType = HIT_TYPE_BOTH;

								// Updates the returned map; if the field ID already exists, then it will be overriden with a value that is newer
								// then the existing value.
								String sHitInfoAndType = new StringBuilder(sHitInfo).append(ServerConstants.TILDA).append(sHitType).toString();
								mapPreviousHitsData.put(sFieldID, sHitInfoAndType);
							}
						}
					}
				}
			}
		}

		

		return mapPreviousHitsData;
	}

	/**
   * 
   */
	private void addNewJournalEntry(String sHitType, long lErrorCode, Map<String, String> mapHitTypeRelatedFieldsInfo)
	{
		final String TRACE_METHOD_INPUT = "Method input - hit type: {}, Error code: {}";
		final String TRACE_FIELDS_AND_HITS_DATA = "Fields and hits data: {}";
		final String TRACE_ERROR_MESSAGE_NULL_NEWJOURNAL_ENTRY = "ERROR: Null NEWJOURNAL record was returned from the call to 'ErrorAuditUtils.handleErrorAndAudit' !!!";
		final String WRONG_HIT_VALUE = "WRONG_HIT_VALUE";

		
		logger.info(TRACE_METHOD_INPUT, sHitType, lErrorCode);

		PDO pdo = Admin.getContextPDO();
		String sOffice = pdo.getString(P_OFFICE);

		// Prepares the ErrorAuditInputData object.
		ErrorAuditInputData eaInputData = new ErrorAuditInputData(false, Admin.getContextAdmin().getSessionID(), getModuleID(), null,
				sOffice, ServerConstants.EMPTY_STRING, ServerConstants.EMPTY_STRING, Admin.getContextAdmin().getClientRemoteAddress());

		eaInputData.setErrorCode(lErrorCode);
		eaInputData.setMid(pdo.getMID());
		eaInputData.setHitInfo(ServerConstants.ONE_VALUE);
		eaInputData.setPartitionID(pdo.getIsHistory());

		// Delimited string to be used as the binding paarmeter for the NEWJOURNAL displayed message.
		// StringBuilder sbFieldsAndHitsData = new StringBuilder();

		// MtableDocument for the NEWJOURNAL.XML_RELATED_FIELDS_DATA column.
		MtableDocument mtableDocument = MtableDocument.Factory.newInstance();
		MsgTableType msgTableType = mtableDocument.addNewMtable();

		Iterator<String> iterKeys = mapHitTypeRelatedFieldsInfo.keySet().iterator();

		while (iterKeys.hasNext())
		{
			String sFieldID = iterKeys.next();
			LogicalFields logicalFields = CacheKeys.LogicalFieldsIdKey.getSingle(sFieldID);
			String sHitInfo = mapHitTypeRelatedFieldsInfo.get(sFieldID);

			String sFieldFullValue = logicalFields.getFieldType() == FieldType.XML_MULTI ? pdo.getString(sFieldID, 0) : pdo.getString(sFieldID);
			sFieldFullValue = sFieldFullValue != null ? sFieldFullValue : WRONG_HIT_VALUE;

			// sbFieldsAndHitsData.append(sFieldID).append(ServerConstants.TILDA).append(sHitInfo).append(ServerConstants.COMMA);

			ErrorAuditUtils.addMsgTableRecord(msgTableType, sFieldID, logicalFields.getDataType(), sFieldFullValue, sHitInfo);
		}

		// Sets the binding parameter.
		// String sFieldsAndHitsData = sbFieldsAndHitsData.substring(0, sbFieldsAndHitsData.length()-1);
		// logger.info(TRACE_FIELDS_AND_HITS_DATA, sFieldsAndHitsData));
		// eaInputData.setNonPaymentsFields(new Object[]{sFieldsAndHitsData});

		// Sets the NEWJOURNAL entry into the PDO.
		List<Object> listErrorAuditObjects = ErrorAuditUtils.handleErrorAndAudit(eaInputData, pdo);

		// Gets the created NEWJOURNAL entry and updates its XML_RELATED_FIELDS_DATA column data.
		Newjournal newjournal = (Newjournal) listErrorAuditObjects.get(0);
		if (newjournal != null) newjournal.setXmlRelatedFieldsData(mtableDocument);
		else logger.info(TRACE_ERROR_MESSAGE_NULL_NEWJOURNAL_ENTRY);

		
	}

	// Build only once the list of fields that should be part of the GI check
	private String buildConcatenatedGiLogicalFieldsValues(PDO pdo) 
	{
		StringBuilder sb = new StringBuilder();

		for (String logicalField : m_giLogicalFieldsList)
		{
			if (pdo.get(logicalField) != null)
			{
				sb.append(pdo.get(logicalField));

			}

		}

		return sb.toString();
	}
	

	
}
