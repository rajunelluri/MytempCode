package backend.paymentprocess.compliance.ejb;

import javax.ejb.Stateless;

import backend.businessobject.proxies.interceptors.InterceptorSetType;
import backend.core.SuperSLSB;
import backend.paymentprocess.compliance.ejbinterfaces.Compliance;
import backend.paymentprocess.compliance.ejbinterfaces.ComplianceLocal;

import com.fundtech.core.security.Admin;

@Stateless
public class ComplianceBean extends SuperSLSB<Compliance> implements ComplianceLocal, Compliance{
	
	public ComplianceBean() { super(backend.paymentprocess.compliance.businessobjects.BOCompliance.class, InterceptorSetType.Complete) ; }//EOM
	
	
	public com.fundtech.datacomponent.response.Feedback performComplianceCheck(final Admin admin, java.lang.String sMID, boolean isSync ) {
		return this.m_bo.performComplianceCheck(admin, sMID,isSync ) ;
	}//EOM
	
	
	public com.fundtech.datacomponent.response.Feedback responseTransmission(String externalServiceResults) {
		return this.m_bo.responseTransmission(externalServiceResults) ;
	}//EOM

	/** 
	 * @param mid
	 * @param sListName
	 * @return
	 * @throws Exception
	 */
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent performExternalComplianceCheck(final Admin admin, java.lang.String mid, java.lang.String sListName ) throws java.lang.Throwable {
		return this.m_bo.performExternalComplianceCheck(admin, mid, sListName ) ;
	}//EOM

}//EOC