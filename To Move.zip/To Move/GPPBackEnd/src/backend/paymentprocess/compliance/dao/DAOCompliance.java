package backend.paymentprocess.compliance.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import backend.dataaccess.dao.DAOBasic;
import backend.dataaccess.dao.DBType;

public class DAOCompliance extends DAOBasic {

	public PreparedStatement getGiList(Connection conn) throws Exception {
		PreparedStatement statement = null;

		String query = "Select  l.field_logical_id from logical_fields l where l.gi_check <> 0";
		statement = conn.prepareStatement(query);

		return statement;

	}

	public PreparedStatement getConcatenatedComplinceCheckResult(Connection conn, String concatenatedLogicalFields, String ofacList, String office,
			PreparedStatement statement) throws Exception {
		String queryOracle = "Select  o.pk_ofac_base "
				+ "from ofac_base o  "
				+ "Where   "
				+ "UPPER(REPLACE (TRANSLATE(?,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') )  LIKE  "
				+ "'%' || UPPER(REPLACE (TRANSLATE( main_1,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') )   || '%'  "
				+ " and  o.ofac_list = ? and office in (?, '***') and rownum <2 and  "
				+ "( (  "
				+ "(UPPER(REPLACE (TRANSLATE(?,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') )  LIKE  "
				+ "'%' || UPPER(REPLACE (TRANSLATE( o.sub_b1,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') )   || '%'  "
				+ "and o.sub_b1 is not null )  "
				+ "OR  "
				+ "(UPPER(REPLACE (TRANSLATE(?,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') )  LIKE  "
				+ "'%' || UPPER(REPLACE (TRANSLATE( o.sub_c1,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') )   || '%'  "
				+ "and o.sub_c1 is not null )  "
				+ "OR  "
				+ "(UPPER(REPLACE (TRANSLATE(?,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') )  LIKE  "
				+ "'%' || UPPER(REPLACE (TRANSLATE( o.sub_d1,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') )   || '%'  "
				+ "and o.sub_d1 is not null )  "
				+ "OR  "
				+ "(UPPER(REPLACE (TRANSLATE(?,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') )  LIKE  "
				+ "'%' || UPPER(REPLACE (TRANSLATE( o.sub_e1,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') )   || '%'  "
				+ "and o.sub_e1 is not null )  "
				+ "OR  "
				+ "(UPPER(REPLACE (TRANSLATE(?,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') )  LIKE  "
				+ "'%' || UPPER(REPLACE (TRANSLATE( o.sub_f1,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') )   || '%'  "
				+ "and o.sub_f1 is not null )  " + ")  "
				+ "OR  (o.sub_b1 is null and o.sub_c1 is null and o.sub_d1 is null and o.sub_b1 is null and o.sub_f1 is null)  " + ")  ";

		String queryDB2 = "Select o.pk_ofac_base from ofac_base o Where INSTR "
				+ "(UPPER(REPLACE (TRANSLATE(?,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') ) , UPPER(REPLACE (TRANSLATE( o.main_1,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') ) , 1 "
				+ ")> 0 and o.ofac_list = ? and office in (?, '***') and rownum <2 and (((INSTR "
				+ "(UPPER(REPLACE (TRANSLATE(?,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') ) , UPPER(REPLACE (TRANSLATE( o.sub_b1,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') ) , 1 "
				+ ")> 0 and o.sub_b1 is not null ) OR ( INSTR "
				+ "(UPPER(REPLACE (TRANSLATE(?,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') ) , UPPER(REPLACE (TRANSLATE( o.sub_c1,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') ) , 1 "
				+ ") > 0  and o.sub_c1 is not null) OR (INSTR "
				+ "(UPPER(REPLACE (TRANSLATE(?,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') ) , UPPER(REPLACE (TRANSLATE( o.sub_d1,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') ) ,1 "
				+ ")> 0 and o.sub_d1 is not null) OR(INSTR "
				+ "(UPPER(REPLACE (TRANSLATE(?,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') ) , UPPER(REPLACE (TRANSLATE( o.sub_e1,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') ) ,1 "
				+ ")> 0 and o.sub_e1 is not null) OR (INSTR "
				+ "(UPPER(REPLACE (TRANSLATE(?,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') ) , UPPER(REPLACE (TRANSLATE( o.sub_f1,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') ) ,1 "
				+ ")> 0 and o.sub_f1 is not null) OR  (o.sub_b1 is null and o.sub_c1 is null and o.sub_d1 is null and o.sub_b1 is null and o.sub_f1 is null) ))";

		
		if (statement == null)
		{
			statement = conn.prepareStatement(ms_DBType == DBType.DB2 ?  queryDB2 :queryOracle);
		}

		com.fundtech.util.GlobalUtils.setObject(statement, 1, concatenatedLogicalFields);
		com.fundtech.util.GlobalUtils.setObject(statement, 2, ofacList);
		com.fundtech.util.GlobalUtils.setObject(statement, 3, office);
		com.fundtech.util.GlobalUtils.setObject(statement, 4, concatenatedLogicalFields);
		com.fundtech.util.GlobalUtils.setObject(statement, 5, concatenatedLogicalFields);
		com.fundtech.util.GlobalUtils.setObject(statement, 6, concatenatedLogicalFields);
		com.fundtech.util.GlobalUtils.setObject(statement, 7, concatenatedLogicalFields);
		com.fundtech.util.GlobalUtils.setObject(statement, 8, concatenatedLogicalFields);

		return statement;

	}

	public PreparedStatement getComplinceCheckResult(Connection conn, String concatenatedLogicalFields, String pkOfacBase, PreparedStatement statement)
			throws Exception {
		String queryOracle = "Select  o.ofac_list, o.ofac_type,  "
				+ "CASE WHEN UPPER(REPLACE (TRANSLATE(?,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') )  LIKE "
				+ "'%' || UPPER(REPLACE (TRANSLATE( main_1,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') )   || '%' "
				+ "THEN o.main_1 || ' ' "
				+ "ELSE '' END || "
				+ "CASE  "
				+ "WHEN sub_b1 is not null and UPPER(REPLACE (TRANSLATE(?,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') )  LIKE "
				+ "'%' || UPPER(REPLACE (TRANSLATE( sub_b1,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') )   || '%' "
				+ "THEN sub_b1 "
				+ "WHEN sub_c1 is not null and UPPER(REPLACE (TRANSLATE(?,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') )  LIKE "
				+ "'%' || UPPER(REPLACE (TRANSLATE( sub_c1,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') )   || '%' "
				+ "THEN sub_c1 "
				+ "WHEN sub_d1 is not null and UPPER(REPLACE (TRANSLATE(?,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') )  LIKE "
				+ "'%' || UPPER(REPLACE (TRANSLATE( sub_d1,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') )   || '%' "
				+ "THEN sub_d1 "
				+ "WHEN sub_e1 is not null and UPPER(REPLACE (TRANSLATE(?,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') )  LIKE "
				+ "'%' || UPPER(REPLACE (TRANSLATE( sub_e1,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') )   || '%' "
				+ "THEN sub_e1 "
				+ "WHEN sub_f1 is not null and UPPER(REPLACE (TRANSLATE(?,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') )  LIKE "
				+ "'%' || UPPER(REPLACE (TRANSLATE( sub_f1,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') )   || '%' "
				+ "THEN sub_f1 "
				+ "ELSE '' END HIT "
				+ "from ofac_base o "
				+ "Where o.pk_ofac_base = ? and rownum <2 and  "
				+ "( "
				+ "UPPER(REPLACE (TRANSLATE(?,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') )  LIKE "
				+ "'%' || UPPER(REPLACE (TRANSLATE( main_1,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') )   || '%' "
				+ "OR "
				+ "(UPPER(REPLACE (TRANSLATE(?,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') )  LIKE "
				+ "'%' || UPPER(REPLACE (TRANSLATE( o.sub_b1,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') )   || '%' "
				+ "and o.sub_b1 is not null ) "
				+ "OR "
				+ "(UPPER(REPLACE (TRANSLATE(?,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') )  LIKE "
				+ "'%' || UPPER(REPLACE (TRANSLATE( o.sub_c1,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') )   || '%' "
				+ "and o.sub_c1 is not null ) "
				+ "OR "
				+ "(UPPER(REPLACE (TRANSLATE(?,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') )  LIKE "
				+ "'%' || UPPER(REPLACE (TRANSLATE( o.sub_d1,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') )   || '%' "
				+ "and o.sub_d1 is not null ) "
				+ "OR "
				+ "(UPPER(REPLACE (TRANSLATE(?,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') )  LIKE "
				+ "'%' || UPPER(REPLACE (TRANSLATE( o.sub_e1,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') )   || '%' "
				+ "and o.sub_e1 is not null ) "
				+ "OR "
				+ "(UPPER(REPLACE (TRANSLATE(?,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') )  LIKE "
				+ "'%' || UPPER(REPLACE (TRANSLATE( o.sub_f1,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') )   || '%' "
				+ "and o.sub_f1 is not null ) " + ") ";

		String queryDB2 = "Select  o.ofac_list, o.ofac_type, "
				+ "CASE WHEN  INSTR(UPPER(REPLACE (TRANSLATE(?,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') ) ,  "
				+ " UPPER(REPLACE (TRANSLATE( main_1,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') ) , 1) > 0 "
				+ "THEN o.main_1 || ' ' "
				+ "ELSE '' END || "
				+ "CASE  "
				+ "WHEN sub_b1 is not null and INSTR(UPPER(REPLACE (TRANSLATE(?,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') ) , "
				+ " UPPER(REPLACE (TRANSLATE( sub_b1,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') ) , 1) > 0 "
				+ "THEN sub_b1 "
				+ "WHEN sub_c1 is not null and INSTR(UPPER(REPLACE (TRANSLATE(?,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') ) , "
				+ " UPPER(REPLACE (TRANSLATE( sub_c1,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') ) , 1) > 0 "
				+ "THEN sub_c1 "
				+ "WHEN sub_d1 is not null and INSTR(UPPER(REPLACE (TRANSLATE(?,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') ) , "
				+ " UPPER(REPLACE (TRANSLATE( sub_d1,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') ) , 1) > 0 "
				+ "THEN sub_d1 "
				+ "WHEN sub_e1 is not null and INSTR(UPPER(REPLACE (TRANSLATE(?,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') ) , "
				+ " UPPER(REPLACE (TRANSLATE( sub_e1,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') ) , 1) > 0 "
				+ "THEN sub_e1 "
				+ "WHEN sub_f1 is not null and INSTR(UPPER(REPLACE (TRANSLATE(?,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') ) , "
				+ " UPPER(REPLACE (TRANSLATE( sub_f1,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') ) , 1) > 0 "
				+ "THEN sub_f1 "
				+ "ELSE '' END HIT "
				+ "from ofac_base o "
				+ "Where o.pk_ofac_base = ?  and rownum <2 and "
				+ "( "
				+ "INSTR(UPPER(REPLACE (TRANSLATE(?,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') ) , "
				+ " UPPER(REPLACE (TRANSLATE( o.main_1,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') ) , 1) > 0 "
				+ "OR "
				+ "(INSTR(UPPER(REPLACE (TRANSLATE(?,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') ) , "
				+ " UPPER(REPLACE (TRANSLATE( o.sub_b1,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') ) , 1) > 0 "
				+ "and o.sub_b1 is not null ) "
				+ "OR "
				+ "(INSTR(UPPER(REPLACE (TRANSLATE(?,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') ) , "
				+ " UPPER(REPLACE (TRANSLATE( o.sub_c1,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') ) , 1) > 0 "
				+ "and o.sub_c1 is not null ) "
				+ "OR "
				+ "(INSTR(UPPER(REPLACE (TRANSLATE(?,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') ) , "
				+ " UPPER(REPLACE (TRANSLATE( o.sub_d1,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') ) , 1) > 0 "
				+ "and o.sub_d1 is not null ) "
				+ "OR "
				+ "(INSTR(UPPER(REPLACE (TRANSLATE(?,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') ) , "
				+ " UPPER(REPLACE (TRANSLATE( o.sub_e1,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') ) , 1) > 0 "
				+ "and o.sub_e1 is not null ) "
				+ "OR "
				+ "(INSTR(UPPER(REPLACE (TRANSLATE(?,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') ) ,  "
				+ " UPPER(REPLACE (TRANSLATE( o.sub_f1,' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?', Rpad(' ', length(' ~`!@#$%^&*()_-+=/.,[{]}\\|:;\"<>''?') - 1, ' ')) , ' ', '') ) , 1) > 0 "
				+ "and o.sub_f1 is not null ) " + ")";
		
		if (statement == null)
		{
			statement = conn.prepareStatement(ms_DBType == DBType.DB2 ?  queryDB2 :queryOracle);
		}

		com.fundtech.util.GlobalUtils.setObject(statement, 1, concatenatedLogicalFields);
		com.fundtech.util.GlobalUtils.setObject(statement, 2, concatenatedLogicalFields);
		com.fundtech.util.GlobalUtils.setObject(statement, 3, concatenatedLogicalFields);
		com.fundtech.util.GlobalUtils.setObject(statement, 4, concatenatedLogicalFields);
		com.fundtech.util.GlobalUtils.setObject(statement, 5, concatenatedLogicalFields);
		com.fundtech.util.GlobalUtils.setObject(statement, 6, concatenatedLogicalFields);
		com.fundtech.util.GlobalUtils.setObject(statement, 7, pkOfacBase);
		com.fundtech.util.GlobalUtils.setObject(statement, 8, concatenatedLogicalFields);
		com.fundtech.util.GlobalUtils.setObject(statement, 9, concatenatedLogicalFields);
		com.fundtech.util.GlobalUtils.setObject(statement, 10, concatenatedLogicalFields);
		com.fundtech.util.GlobalUtils.setObject(statement, 11, concatenatedLogicalFields);
		com.fundtech.util.GlobalUtils.setObject(statement, 12, concatenatedLogicalFields);
		com.fundtech.util.GlobalUtils.setObject(statement, 13, concatenatedLogicalFields);

		return statement;

	}

}
