package backend.paymentprocess.baseprocess.ejb;

import javax.ejb.Stateless;
import backend.core.SuperSLSB;
import com.fundtech.core.security.Admin;
import backend.businessobject.proxies.interceptors.InterceptorSetType;
import backend.paymentprocess.baseprocess.businessobjects.BOBaseProcess;
import backend.paymentprocess.baseprocess.ejbinterfaces.BaseProcessLocal;
import backend.paymentprocess.baseprocess.ejbinterfaces.BaseProcess;

@Stateless
public class BaseProcessBean extends SuperSLSB<BaseProcess> implements BaseProcessLocal, BaseProcess{
	
	public BaseProcessBean() { super(backend.paymentprocess.baseprocess.businessobjects.BOBaseProcess.class, InterceptorSetType.Complete) ; }//EOM
	
	
	public com.fundtech.datacomponent.response.Feedback performAfterPostingASAP(final Admin admin, java.lang.String sMID ) throws java.lang.Throwable {
		return this.m_bo.performAfterPostingASAP(admin, sMID ) ;
	}//EOM

	/** 
	 */
	public com.fundtech.datacomponent.response.Feedback performReturnAfterPostingASAP(final Admin admin, java.lang.String sMID ) throws java.lang.Throwable {
		return this.m_bo.performReturnAfterPostingASAP(admin, sMID ) ;
	}//EOM

}//EOC