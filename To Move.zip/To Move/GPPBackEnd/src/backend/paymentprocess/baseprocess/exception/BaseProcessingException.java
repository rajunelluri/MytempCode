package backend.paymentprocess.baseprocess.exception;

import com.fundtech.core.paymentprocess.errorhandling.BusinessException;

/**
 * Title:       BaseProcessingException
 * Description: Class for all base processing exceptions
 * Company:     Fundtech Israel
 * Author:      Asaf Levy
 * Date:        05/04/2009
 * @version     1.0
 */
public class BaseProcessingException extends BusinessException
{
  private static final long serialVersionUID = -463673756708464723L;
  
  public BaseProcessingException()
  {
    super();
  }
  
  public BaseProcessingException(String string, Throwable e)
  {
    super(string, e);
  }
}
