package backend.paymentprocess.baseprocess.ejbinterfaces;

import javax.ejb.Local;

/**
 * Local interface for BaseProcess.
 */
@Local
public interface BaseProcessLocal extends BaseProcess{} ; 