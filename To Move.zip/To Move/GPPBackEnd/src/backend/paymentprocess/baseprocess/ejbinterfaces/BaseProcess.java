package backend.paymentprocess.baseprocess.ejbinterfaces;

import javax.ejb.Remote;
import com.fundtech.core.security.Admin;

/**
 * Remote interface for BaseProcess.
 */
@Remote
public interface BaseProcess{

	public static final String REMOTE_JNDI_NAME="ejb/BaseProcessBean";
	
	
	public com.fundtech.datacomponent.response.Feedback performAfterPostingASAP(final Admin admin, java.lang.String sMID ) throws java.lang.Throwable ;
	
	/** 
	 */
	public com.fundtech.datacomponent.response.Feedback performReturnAfterPostingASAP(final Admin admin, java.lang.String sMID ) throws java.lang.Throwable ;

}//EOI  