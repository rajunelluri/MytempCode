package backend.paymentprocess.baseprocess.businessobjects;

import com.fundtech.core.security.Admin;

/**
 * internal interface for BOBaseProcess.
 */
public interface BOBaseProcessInterface{

	
	
	/** 
	 * Performs base processing for a single payment.
	 */
	public com.fundtech.datacomponent.response.Feedback performBaseProcessing(final Admin admin, java.lang.String sMID ) throws backend.paymentprocess.baseprocess.exception.BaseProcessingException ;

}//EOI  