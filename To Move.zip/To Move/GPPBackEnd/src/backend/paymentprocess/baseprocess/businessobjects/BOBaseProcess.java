package backend.paymentprocess.baseprocess.businessobjects;

import static backend.businessobject.BOProxies.m_anticipatedFundsLogging;
import static backend.businessobject.BOProxies.m_bankRoutLogging;
import static backend.businessobject.BOProxies.m_complianceLogging;
import static backend.businessobject.BOProxies.m_currencyConversionLogging;
import static backend.businessobject.BOProxies.m_enrichmentLogging;
import static backend.businessobject.BOProxies.m_glmProcessingLogging;
import static backend.businessobject.BOProxies.m_internalPartyProcessingLogging;
import static backend.businessobject.BOProxies.m_ledgerConfirmationLogging;
import static backend.businessobject.BOProxies.m_matchingCheckLogging;
import static backend.businessobject.BOProxies.m_mopSelectionLogging;
import static backend.businessobject.BOProxies.m_outboundDirectsCoversLogging;
import static backend.businessobject.BOProxies.m_outgoingRequestForChargesLogging;
import static backend.businessobject.BOProxies.m_pisnMatchingLogging;
import static backend.businessobject.BOProxies.m_settlementConfirmationLogging;
import static backend.businessobject.BOProxies.m_settlementNoticeLogging;
import static backend.businessobject.BOProxies.m_specialInstructionLogging;
import static backend.businessobject.BOProxies.m_stpRulesComplete;
import static backend.core.module.MessageConstantsInterface.TX_CATEGORY_DRI;
import static com.fundtech.interfaces.InterfaceTypeConstants.INTERFACE_TYPE_CDB;
import static com.fundtech.util.GlobalConstants.getErrorAuditUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.businessobject.BOBasic;
import backend.businessobject.BOProxies;
import backend.businessobject.proxies.LoadPDO;
import backend.core.module.MessageConstantsInterface;
import backend.paymentprocess.accountderivation.businessobjects.BOAccountDerivation;
import backend.paymentprocess.accountderivation.common.AccountDerivationConstants.AccountLookupType;
import backend.paymentprocess.currencyconversion.common.CurrencyConversionConstants.ConversionType;
import backend.paymentprocess.erroraudit.ErrorAuditUtils;
import backend.paymentprocess.highvalueprocess.businessobjects.BOHighValueProcess;
import backend.paymentprocess.interfaces.common.WaitBehaviourType;
import backend.paymentprocess.mappaymentinfo.businessobjects.BOMapPaymentInfoUsingRules;
import backend.paymentprocess.mappaymentinfo.output.MapPaymentInfoUsingRulesOutputData;
import backend.paymentprocess.mopselection.common.MsgClassType;
import backend.paymentprocess.mopselection.output.MopSelectionOutputData;
import backend.paymentprocess.partyprocessing.businessobjects.BOPartyProcessing;
import backend.paymentprocess.pisnmatching.output.PISNMatchingOutputData;
import backend.paymentprocess.specialinstruction.output.SpecialInstructionOutputData;
import backend.util.ServerConstants;

import com.fundtech.annotations.Expose;
import com.fundtech.annotations.Wrap;
import com.fundtech.cache.entities.InterfaceTypes;
import com.fundtech.cache.entities.Mop;
import com.fundtech.cache.entities.MsgRuleLog;
import com.fundtech.cache.entities.MsgSpecialInstructions;
import com.fundtech.cache.entities.Msgerr;
import com.fundtech.cache.entities.Newjournal;
import com.fundtech.cache.entities.PreventStp;
import com.fundtech.cache.entities.RuleResult;
import com.fundtech.cache.entities.RuleResults;
import com.fundtech.cache.entities.SystPar;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.cache.syspar.SystemParametersInterface;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.core.paymentprocess.data.fields.DataType;
import com.fundtech.core.paymentprocess.errorhandling.ProcessError;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.datacomponent.response.GlobalAbstractResponseDataComponent;
import com.fundtech.datacomponent.response.UserDialog;
import com.fundtech.errors.ProcessErrorConstants;
import com.fundtech.util.BindingParameter;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalUtils;


/**
 * Title:       BOBaseProcess
 * Description: Business object for a single message base processing
 * Company:     Fundtech Israel
 * Author:      Asaf Levy
 * Date:        05/04/2009
 * @version     1.0
 */

@Wrap 
public class BOBaseProcess extends BOBasic implements PDOConstantFieldsInterface, MessageConstantsInterface
{

	private static final Logger logger = LoggerFactory.getLogger(BOBaseProcess.class);

	private static final String EXECUTE_STEP_STP_VALIDATION = "STP Validation";
	private static final String EXECUTE_STEP_DEPARTMENT_RULE_SELECTION = "Department rule selection";
	private static final String EXECUTE_STEP_BUSINESS_AREA_RULE_SELECTION = "Business area rule selection";
	private static final String EXECUTE_STEP_PRODUCT_RULE_SELECTION = "Product rule selection";
	private static final String EXECUTE_STEP_BASE_CURRENCY_CONVERSION = "Base currency conversion";
	private static final String EXECUTE_STEP_MESSAGE_FILTER_RULE_SELECTION = "Message filter rule selection";
	private static final String EXECUTE_STEP_COMPLIANCE_VALIDATION = "Compliance validation";
	private static final String EXECUTE_STEP_REPAIR_AND_ENRICHEMENT = "Repair and enrichment";
	private static final String EXECUTE_STEP_DUPLICATE_CHECK = "Duplicate check";
	private static final String EXECUTE_STEP_OFFICE_GENERIC_SLA = "Office generic SLA rule";
	private static final String EXECUTE_STEP_DEBIT_SLA = "Debit SLA rule";
	private static final String EXECUTE_STEP_CREDIT_SLA = "Credit SLA rule";
	private static final String EXECUTE_STEP_PAYMENT_CLASSIFICATION_RULE_SELECTION = "Payment classification rule selection";
	private static final String EXECUTE_STEP_ACCOUNT_OWNER_VALIDATION = "Account owner validation";
	private static final String EXECUTE_STEP_PAYMENT_PARTY_IDENTIFIER_ENRICHMENT_DEBIT = "Debit roles party identifiers enrichment";
	private static final String EXECUTE_STEP_SETTLEMENT_NOTICE_MATCHING_PROCESS = "Settlement Notice matching process";
	private static final String EXECUTE_STEP_LEDGER_CONFIRMATION_MATCHING_PROCESS = "LC matching process";
	private static final String EXECUTE_STEP_AF_MATCHING_PROCESS = "AF matching process";    
	private static final String EXECUTE_STEP_AF_MATCHING_PROCESS_POST_CREDIT = "AF matching process (post credit side processing)";
	private static final String EXECUTE_STEP_SETTLEMENT_CONFIRMATION_MATCHING_PROCESS = "SC matching process";
	private static final String EXECUTE_STEP_OPI_OSN_MATCHING_PROCESS = "OPI OSN matching process";
	private static final String EXECUTE_STEP_DEBIT_PARTY_PROCESSING = "Debit party processing";
	private static final String EXECUTE_STEP_CREDIT_PARTY_PROCESSING = "Credit party processing";
	private static final String EXECUTE_STEP_POL_REPLENISHMENT = "POL Replenishment";
	private static final String EXECUTE_STEP_TRANSFER_METHOD = "Transfer method identification";
	private static final String EXECUTE_STEP_POL_PROCESSING = "POL processing";
	private static final String EXECUTE_STEP_PRIORITY_RULE_SELECTION = "Priority rule selection";
	private static final String EXECUTE_STEP_MOP_SELECTION = "MOP selection";
	private static final String EXECUTE_STEP_PAYMENT_PARTY_IDENTIFIER_ENRICHMENT_CREDIT = "Credit roles party identifiers enrichment";
	private static final String EXECUTE_STEP_BANK_ROUT_RETRIEVE_CORRESPONDENT = "Bank rout retrieve correspondent";
	private static final String EXECUTE_STEP_BENEFICIARY_ACCOUNT_VALIDATION = "Beneficiary account validation";
	private static final String EXECUTE_STEP_SPECIAL_INSTRUCTION = "Special instruction";
	private static final String EXECUTE_STEP_VALIDATION_RULE_SELECTION = "validation rule selection";
	private static final String EXECUTE_STEP_CREDIT_CURRENCY_CONVERSION_AFTER_MOP_SELECTION = "Credit currency conversion after MOP selection";
	private static final String EXECUTE_STEP_PARTY_LIMIT_CHECK = "Party limits check";

	public static final String MESSAGE_FILTER_MODULE = "Message filter rule";
	public static final String COMPLIANCE_MODULE = "Compliance check";
	public static final String DUPLICATE_CHECK_MODULE = "Duplicate check";
	public static final String PISN_MATCHING_MODULE = "PISN Matching";
	public static final String SN_MATCHING_MODULE = "SN Matching";
	public static final String LC_MATCHING_MODULE = "LC Matching";
	public static final String PARTY_LIMIT_MODULE = "Party limits check";


	private static final String MATCH_INCOMING_TO_OUTGOING_MODULE = "Match incoming to outgoing request for charges";
	private static final String POL_CHECKING_AND_BLOCKING_MODULE = "POL Checking And Blocking";
	private static final String BENEFICIARY_ACCOUNT_VALIDATION_MODULE = "Beneficiary account validation";
	private static final String VALIDATION_RULE = "Validation rule";

	public static final String ASAP = "1";
	public static final String NET_SETTLEMENT = "3";

	/**
	 * 
	 */
	public BOBaseProcess()
	{
	}

	/**
	 * Performs base processing for a single payment.
	 */
	@LoadPDO
	public Feedback performBaseProcessing(final String sMID) throws Throwable
	{
		final String EXCEPTION_MESSAGE = "Exception has occured in 'BOBaseProcess.performBaseProcessing'.";
		final String INPUT_DATA = "Party processing type: ";
		final String LAST_STEP = "Last step: ";

		logger.info("Start performBaseProcessing() for MID: {}", sMID);
		
		Feedback feedback = new Feedback();

		Admin admin = Admin.getContextAdmin();
		PDO pdo = PaymentDataFactory.load(sMID);
		String sOffice = pdo.getString(P_OFFICE);

		final SystPar enrichMsgParties =  CacheKeys.SystParKey.getSingle(GlobalConstants.DEFAULT_SERVER_OFFICE_NAME, SystemParametersInterface.SYS_PAR_ENRICH_MSG_PARTIES) ;    
		String enrichMsgPartiesSysParValue = enrichMsgParties != null ? enrichMsgParties.getParmValue() : ServerConstants.NO;
		String sLastStep = null;
		String sOldStatus = null;

		boolean bStopProcess = false;

		// Clean old message parties (if exist) from pdo
		m_enrichmentLogging.cleanExistingMessageParties(admin);
		
		// Executes department selection rule.      
		sLastStep = EXECUTE_STEP_DEPARTMENT_RULE_SELECTION;
		feedback = executeMapPaymentInfoUsingRules(sMID, RULE_TYPE_ID_DEPARTMENT, null);

		// Executes business area selection rule.
		if(feedback.isSuccessful())
		{
			sLastStep = EXECUTE_STEP_BUSINESS_AREA_RULE_SELECTION;
			feedback = executeMapPaymentInfoUsingRules(sMID, RULE_TYPE_ID_BUSINESS_AREA, null);
		}

		// Executes product selection rule.
		if(feedback.isSuccessful())
		{
			sLastStep = EXECUTE_STEP_PRODUCT_RULE_SELECTION;
			feedback = executeMapPaymentInfoUsingRules(sMID, RULE_TYPE_ID_PRODUCT, null);
		}

		// Executes repair & enrichment.
		if(feedback.isSuccessful())
		{
			sLastStep = EXECUTE_STEP_REPAIR_AND_ENRICHEMENT;
			pdo.set(D_RULE_TYPE_ID, RULE_TYPE_ID_REPAIR_AND_ENRICHMENT_SELECTION);

			feedback = m_enrichmentLogging.repairAndEnrich(admin);	       
		}

		// Executes STP rules.
		boolean isSupportStpRule = CacheKeys.SystParKey.getSingleParmValue(pdo.getString(PDOConstantFieldsInterface.P_OFFICE), 
				SystemParametersInterface.SYS_PAR_SUPPORT_STP_RULE).equals(GlobalConstants.Yes) ;
		if(isSupportStpRule && feedback.isSuccessful())
		{
			sLastStep = EXECUTE_STEP_STP_VALIDATION;
			feedback = m_stpRulesComplete.validateSTPRules(admin, sMID);
		}

		// Executes base currency conversion.
		if(feedback.isSuccessful())
		{
			sLastStep = EXECUTE_STEP_BASE_CURRENCY_CONVERSION;
			pdo.set(D_CURRENCY_CONVERSION_TYPE, ConversionType.Base.toString());
			feedback = m_currencyConversionLogging.performCurrencyConversion(admin, sMID);
		}

		// Executes message filter rule.
		if(feedback.isSuccessful())
		{
			sLastStep = EXECUTE_STEP_MESSAGE_FILTER_RULE_SELECTION;
			sOldStatus = pdo.getString(P_MSG_STS);
			String[] arrOutput = new String[1];
			feedback = executeMapPaymentInfoUsingRules(sMID, RULE_TYPE_ID_MSG_FILTER, arrOutput);
			compareMessageStatusBeforeAfter(sOldStatus, pdo, MESSAGE_FILTER_MODULE, feedback);
		}

		// Compliance.
		if(feedback.isSuccessful() && MONITOR_FLAG_X.equals(pdo.getString(MF_COMPLIANCE_VALIDATION_STS)))
		{
			sLastStep = EXECUTE_STEP_COMPLIANCE_VALIDATION;
			sOldStatus = pdo.getString(P_MSG_STS);
			feedback = m_complianceLogging.performComplianceCheck(admin, sMID,true);

			String sMF_COMPLIANCE_VALIDATION_STS = pdo.getString(MF_COMPLIANCE_VALIDATION_STS);
			String sMU_COMPLIANCE_OVERRIDE_STS = pdo.getString(MU_COMPLIANCE_FORCE_STS);

			if(   (MONITOR_FLAG_COMPLIANCE_HIT.equals(sMF_COMPLIANCE_VALIDATION_STS) && !MONITOR_FLAG_FORCE.equals(sMU_COMPLIANCE_OVERRIDE_STS))
					|| MONITOR_FLAG_COMPLIANCE_WAIT.equals(sMF_COMPLIANCE_VALIDATION_STS))
			{
				pdo.set(P_MSG_STS, MESSAGE_STATUS_COMPEX);
			}

			// The message status could have been set also to REPAIR in case no compliance validation rule was found.
			bStopProcess = compareMessageStatusBeforeAfter(sOldStatus, pdo, COMPLIANCE_MODULE, null);
		}

		if(!bStopProcess)
		{
			// Executes duplicate check.
			if(feedback.isSuccessful() && pdo.isNew())
			{
				sLastStep = EXECUTE_STEP_DUPLICATE_CHECK;
				sOldStatus = pdo.getString(P_MSG_STS);
				GlobalAbstractResponseDataComponent response = m_matchingCheckLogging.performDuplicateCheck(admin, sMID);
				feedback = response.getFeedback();
				bStopProcess = compareMessageStatusBeforeAfter(sOldStatus, pdo, DUPLICATE_CHECK_MODULE, null);
			}  
		}

		// Executes office generic SLA rule.      
		if(feedback.isSuccessful())
		{
			sLastStep = EXECUTE_STEP_OFFICE_GENERIC_SLA;
			feedback = executeMapPaymentInfoUsingRules(sMID, RULE_TYPE_ID_OFFICE_GENERIC_SLA, null);
		}

		if(!bStopProcess)
		{
			// Executes DEBIT party processing.
			if(feedback.isSuccessful())
			{
				sLastStep = EXECUTE_STEP_DEBIT_PARTY_PROCESSING;
				feedback = m_internalPartyProcessingLogging.performPartyProcessing(admin, sMID, BOPartyProcessing.PROCESSING_TYPE_DEBIT);
			}

			// Executes debit SLA rule.      
			if(feedback.isSuccessful())
			{
				sLastStep = EXECUTE_STEP_DEBIT_SLA;
				feedback = executeMapPaymentInfoUsingRules(sMID, RULE_TYPE_ID_DEBIT_SLA, null);
			}

			// Executes payment classification rule.
			if(feedback.isSuccessful())
			{
				sLastStep = EXECUTE_STEP_PAYMENT_CLASSIFICATION_RULE_SELECTION;
				feedback = executeMapPaymentInfoUsingRules(sMID, RULE_TYPE_ID_PAYMENT_CLASSIFICATION, null);
			}

			// Executes validation on account's owner.
			if (feedback.isSuccessful()){
				sLastStep = EXECUTE_STEP_ACCOUNT_OWNER_VALIDATION;
				feedback = executeAccountOwnerValidation(sMID);
			}

			// Derive Debit Msg Parties
			if(feedback.isSuccessful() && enrichMsgPartiesSysParValue.equalsIgnoreCase(GlobalConstants.YES))
			{
				sLastStep = EXECUTE_STEP_PAYMENT_PARTY_IDENTIFIER_ENRICHMENT_DEBIT;
				feedback = m_enrichmentLogging.derivePartyIdentifier(admin, false);
			}

			// Accumulate PartyLimit
			if(feedback.isSuccessful()) {
				sLastStep = EXECUTE_STEP_PARTY_LIMIT_CHECK;
				feedback = m_glmProcessingLogging.applyGLMOnProcessing(Admin.getContextAdmin(), pdo.getMID()); //performIncomingMessagePartyLimitCheck(pdo);
			}

			// Settlement notice
			if(feedback.isSuccessful()){
				sLastStep = EXECUTE_STEP_SETTLEMENT_NOTICE_MATCHING_PROCESS;
				sOldStatus = pdo.getString(P_MSG_STS);
				feedback = m_settlementNoticeLogging.handleSettlementNotice(admin,sMID);
				compareMessageStatusBeforeAfter(sOldStatus, pdo, SN_MATCHING_MODULE, feedback);
			}

			// Executes POL replenishment.
			// Inside the POL replenishment service a check will be done if the action is relevant and if not, the service
			// will clean the related fields, (see there).
			if(feedback.isSuccessful())
			{
				sLastStep = EXECUTE_STEP_POL_REPLENISHMENT;
				PISNMatchingOutputData pisnMatchingOutputData = m_pisnMatchingLogging.performPOLReplenishBlocking(admin, sMID);
				feedback = pisnMatchingOutputData.getFeedback();
			}

			// handle AF (note: SN would not get it, it stops after matching to PI)
			if(feedback.isSuccessful() && !MSG_CLASS_SC.equals(pdo.getString(P_MSG_CLASS))) {
				sLastStep = EXECUTE_STEP_AF_MATCHING_PROCESS;
				feedback = m_anticipatedFundsLogging.matchToAnticipatedFund(admin, sMID);
			}

			// handle SettlementConfirmation, if message is SC, the flow would stop after this point
			if(feedback.isSuccessful()) {
				sLastStep = EXECUTE_STEP_SETTLEMENT_CONFIRMATION_MATCHING_PROCESS;
				feedback = m_settlementConfirmationLogging.handleSettlementConfirmation(admin,sMID);
			}

			// Handle Ledger confirmation
			if (feedback.isSuccessful()){
				sLastStep = EXECUTE_STEP_LEDGER_CONFIRMATION_MATCHING_PROCESS;
				sOldStatus = pdo.getString(P_MSG_STS); 
				feedback = m_ledgerConfirmationLogging.handleLedgerConfirmation(admin,sMID);
				compareMessageStatusBeforeAfter(sOldStatus, pdo, LC_MATCHING_MODULE, feedback);
			}

			// Executes priority selection rule.
			if(feedback.isSuccessful())
			{
				sLastStep = EXECUTE_STEP_PRIORITY_RULE_SELECTION;
				pdo.set(D_MOP_SELECTION_TYPE, "SELECTION");
				feedback = executeMapPaymentInfoUsingRules(sMID, RULE_TYPE_ID_PRIORITIZATION, null);
			}

			boolean isMopSelectionFinishedSuccessfully = false;

			boolean bAgentBICIsUsed = false;

			// save the original list values to overwrite them each loop rotation until correspondent chain build successful
			List<Msgerr> origMsgErrorList = pdo.getListMSGERR();
			List<Newjournal> origNewJournalList = pdo.getListNEWJOURNAL();
			List<MsgSpecialInstructions> origMsgSpecialInstructionList = pdo.getListMSG_SPECIAL_INSTRUCTIONS();
			List<MsgRuleLog> msgRuleLogList = pdo.getListMSG_RULE_LOG();

			// Will keep an account derivation error, (if such one has occurred), and will be set back into the
			// PDO's list of errors in case NOP selection or bank rout 'retrieveCorrespondent' have failed.
			// This is done so the user will see this error in the GUI for cases where the setup was wrong
			// and there was actually no intention to send the message through a MOP with settlement account.
			Msgerr accountDerivationMsgerr = null;
			UserDialog feedbackUserDialog = null;

			// Build correspondent chain, the loop will be executed until successful MOP selection or the correspondent chain is full
			// If correspondent chain is full then retrieve correspondent service will return error feedback and payment will be routed to repair. 
			while (!isMopSelectionFinishedSuccessfully && feedback.isSuccessful())
			{
				// Rewrite the error lists, the loop rotation failed, return the error lists to original state. 
				pdo.setListMSGERR(origMsgErrorList != null ? (List)((ArrayList)origMsgErrorList).clone() : null);
				pdo.setListNEWJOURNAL( origNewJournalList != null ? (List)((ArrayList)origNewJournalList).clone() : null);
				pdo.setMsgSpecialInstructionList(origMsgSpecialInstructionList != null ? (List)((ArrayList)origMsgSpecialInstructionList).clone() : null);
				pdo.setListMSG_RULE_LOG(msgRuleLogList != null ? (List)((ArrayList)msgRuleLogList).clone() : null);

				// Executes CREDIT party processing.
				sLastStep = EXECUTE_STEP_CREDIT_PARTY_PROCESSING;
				feedback = m_internalPartyProcessingLogging.performPartyProcessing(admin, sMID, BOPartyProcessing.PROCESSING_TYPE_CREDIT);

				// If CREDIT party processing has failed during account derivation, (i.e. CREDIT customer was loaded successfully
				// during the 'load customer' step), then no need to stop the flow; the credit account number itself will be
				// assigned during MOP selection.
				if(!feedback.isSuccessful())
				{
					// Load customer has succedd & account derivation has failed.
					if(pdo.getCREDIT_CUSTOMER() != null && pdo.getCREDIT_ACCOUNT() == null)
					{
						// In case of account derivation error, removes it from the message errors list as account derivation might succeed
						// during the MOP selection stage of the current loop or during one of the next loops.
						accountDerivationMsgerr = removeProcessError(BOAccountDerivation.getOptionalErrorCodesSet());
						ArrayList<UserDialog> userDialogs = feedback.getDialogs().getDialogs();
				        for(UserDialog userDialog : userDialogs) {
				            if(BOAccountDerivation.getOptionalErrorCodesSet().contains(userDialog.getErrorCode())){ 
				            	feedbackUserDialog = userDialog;
				            	userDialogs.remove(userDialog);
				            	break;
				            }
				        }
					}
				}

				// handle OPI/OSN after credit side processing but before MOP selection 
				// OPI might have a failed feedback because of credit account derivation - we want it to continue anyway,
				// OSN is expected to succeed deriving the credit account and enter this block because feedback is successful.
				if (feedback.isSuccessful() ||
						( pdo.getCREDIT_CUSTOMER() != null 
								&& feedback.getErrorCode() != ProcessErrorConstants.SettlementCurrencyDoesntEqualDebitOrCreditCurrency
								&& feedback.getErrorCode() != ProcessErrorConstants.ThresholdErrorForInstructionAmount)){

					sLastStep = EXECUTE_STEP_OPI_OSN_MATCHING_PROCESS;
					sOldStatus = pdo.getString(P_MSG_STS); 
					Feedback opiosnFeedback = m_outboundDirectsCoversLogging.handleOutboundDirectsCovers(admin,sMID);
					compareMessageStatusBeforeAfter(sOldStatus, pdo, "", opiosnFeedback);//changes opiosnFeedback to failure if matching succeeds

					//if opiosnFeedback is unsuccessful because msg status has changed or because of a process failure - we don't want to continue
					//with the rest of the flow so its OK to override the existing feedback with failure.
					//if opiosnFeedback is successful - then if feedback was successful then the flow continues as usual, but if feedback was unsuccessful,
					//then we want it to remain unsuccessful and not to lose the errorcodes on it, so we don't set it.
					if (!opiosnFeedback.isSuccessful()){
						feedback = opiosnFeedback;
					}
				}


				// Executes MOP selection.
				// Continues to MOP selection in case of success or in case of failure if CREDIT customer was already loaded.
				if(   feedback.isSuccessful()
						||	(   !feedback.isSuccessful() && pdo.getCREDIT_CUSTOMER() != null 
								&& feedback.getErrorCode() != ProcessErrorConstants.SettlementCurrencyDoesntEqualDebitOrCreditCurrency
								&& feedback.getErrorCode() != ProcessErrorConstants.ThresholdErrorForInstructionAmount))
				{
					sLastStep = EXECUTE_STEP_MOP_SELECTION;
					MopSelectionOutputData mopSelectionOutputData = m_mopSelectionLogging.performMopSelection(admin, sMID);

					// If MOP selection feedback is failure --> Set the service monitor MF_MOP_SELECTION_STS to F.
					// Bank routing will be executed only in case MF_MOP_SELECTION_STS = F.
					if (pdo.getString(PDOConstantFieldsInterface.MF_MOP_SELECTION_STS).equals(MessageConstantsInterface.MONITOR_FLAG_FAILURE))
						feedback = mopSelectionOutputData.getFeedback();
					else 
					{
						feedback.setSuccess();
					}
				}


				// If the first in credit chain is the Creditor (Beneficiary) and MOP selection fails then the payment should be sent to Repair (i.e. the Bank Routing service should not be invoked).
				// The above is true only when cust_type = CU
				// If cust_type = BK then you should invoke bank routing
				boolean isFirstInChainCreditorAndCU =   (!feedback.isSuccessful() && pdo.getCREDIT_CUSTOMER() != null &&  
														 "CU".equals(pdo.getCREDIT_CUSTOMER().getCustType()) 			) ? true : false;

				String mopSelectionMonitorField = pdo.getString(PDOConstantFieldsInterface.MF_MOP_SELECTION_STS);

				// Bank routing.
				// Will be executed in case: 
				//     1) MOP selection has failed
				// AND 2) CREDIT customer was already loaded, (i.e. only account derivation has failed during the credit party processing).
				if (   !isFirstInChainCreditorAndCU 
						&& !feedback.isSuccessful() && pdo.getCREDIT_CUSTOMER() != null 
						&& feedback.getErrorCode() != ProcessErrorConstants.SettlementCurrencyDoesntEqualDebitOrCreditCurrency
						&& feedback.getErrorCode() != ProcessErrorConstants.ThresholdErrorForInstructionAmount
						&& feedback.getErrorCode() != ProcessErrorConstants.PassedCuttof)	   
					
				{
					bAgentBICIsUsed = true;
					sLastStep = EXECUTE_STEP_BANK_ROUT_RETRIEVE_CORRESPONDENT;
					feedback = m_bankRoutLogging.retrieveCorrespondent(admin,sMID);
				}

				// if associate member found, then need to loop one more time. 
				else if(feedback.isSuccessful() && !MessageConstantsInterface.MONITOR_FLAG_ASSOCIATE.equals(mopSelectionMonitorField))
				{
					isMopSelectionFinishedSuccessfully = true;
				}

				// If missed cutoff or future value date or value date should be advanced, however, syst par doesn't allow so,then sent payment to Repair	
				if (feedback.isSuccessful() && (   MessageConstantsInterface.MONITOR_FLAG_MISSED_CUTOFF.equals(mopSelectionMonitorField)
												|| MessageConstantsInterface.MONITOR_FLAG_FUTURE_VALUE_DATE.equals(mopSelectionMonitorField)
												|| MessageConstantsInterface.MONITOR_FLAG_ASSOCIATE_INVALID.equals(mopSelectionMonitorField)
												|| MessageConstantsInterface.MONITOR_FLAG_CUTOFF_ERROR.equals(mopSelectionMonitorField)))
				{
					feedback.setFailure();
					logger.warn("Mop selection monitor is {}. [M = Missed cutoff  F = Future value date  I = Associate invalid  E = Cutoff error]", mopSelectionMonitorField);
				}

			}//end while (!isMopSelectionFinishedSuccessfully && feedback.isSuccessful())


			// Derive Credit Msg Parties		// QC#16482: Yael morag: do the MsgParty derivation only after the last iteration of the MOP selection
			if(feedback.isSuccessful() && enrichMsgPartiesSysParValue.equalsIgnoreCase(GlobalConstants.YES) )
			{
				sLastStep = EXECUTE_STEP_PAYMENT_PARTY_IDENTIFIER_ENRICHMENT_CREDIT;
				feedback = m_enrichmentLogging.derivePartyIdentifier(admin, true);
			}
			
			
			// Failure in either MOP selection or bank rout 'retrieveCorrespondent' method; in case an account derivation error
			// has occured during the process and was removed in a previous step, adds it back for GUI clarity.
			if(!feedback.isSuccessful() && accountDerivationMsgerr != null && GlobalUtils.isNullOrEmpty(pdo.getString(P_CDT_ACCT_NB))){
				pdo.getListMSGERR().add(0, accountDerivationMsgerr);
				if (feedbackUserDialog!= null){
					ProcessError processError = new ProcessError(feedbackUserDialog.getErrorCode());
					configureErrorFeedback(processError.getErrorCode(),	processError.getDescription(), feedback);
				}
			}

			// handle AF after credit side, Note: SC and SN Flows stops after matching and won't get to this point.      
			if(feedback.isSuccessful()) {
				sLastStep = EXECUTE_STEP_AF_MATCHING_PROCESS_POST_CREDIT;
				feedback = m_anticipatedFundsLogging.matchToAnticipatedFund(admin, sMID);
			}

			//check if posting is required ASAP
			String accByMOP = CacheKeys.SystParKey.getSingleParmValue(pdo.getString(PDOConstantFieldsInterface.P_OFFICE), SystemParametersInterface.SYST_PAR_ACC_BY_MOP);
			Mop debitMop = pdo.getNSetDEBIT_MOP();
			String initStatus = pdo.getString(P_MSG_STS);
			boolean isSendPosting = GlobalConstants.Yes.equalsIgnoreCase(accByMOP) && 
			ASAP.equals(debitMop.getIncomingAcctngPoint()) &&
			!NET_SETTLEMENT.equals(debitMop.getSttlmAcctngMethod());
			if (feedback.isSuccessful() && isSendPosting) {
				feedback = BOHighValueProcess.performPostingInfo(pdo);	
			}
			//if current status <> init status --> posting was not sent and therefore
			//the flow should be continued
			String currentStatus = pdo.getString(P_MSG_STS);
			if (feedback.isSuccessful()&& currentStatus.equals(initStatus)) {
				feedback = performAfterPostingASAP(pdo, sMID, bAgentBICIsUsed, false);   
			}

		}//end if(!bStopProcess)

		// Process wasn't completed successfully.
		if(!feedback.isSuccessful())
		{
			// Ensure non-zero error code.
			if(feedback.getErrorCode() == 0)
			{
				feedback.setErrorCode(1);
			}
		}

		logger.info("End performBaseProcessing() for MID: {}", sMID);


		return feedback;
	}

	@Expose  
	public Feedback performAfterPostingASAP(String sMID) throws Throwable {
		PDO pdo = PaymentDataFactory.load(sMID);
		String initialProcessStatus =pdo.getString(PDOConstantFieldsInterface.P_MSG_STS);
		Feedback feedback = performAfterPostingASAP(pdo,sMID, false, false);
		BOHighValueProcess.finalizeTheFlow(pdo, initialProcessStatus, feedback);
		return feedback;
	}

	/**
	 * 
	 */
	public static Feedback performAfterPostingASAP( PDO pdo, String sMID, boolean bAgentBICIsUsed, boolean bSkipBeneficiaryAccountValidation) throws Throwable 
	{
		final String LAST_STEP = "Last step: ";



		String sLastStep = null;
		String sOldStatus = null;       
		Admin admin = Admin.getContextAdmin();
		Feedback feedback = new Feedback();

		//in case ASAP of flow and if D_SUCCESS_CDT_CUST_DERIV is empty --> set it to true
		if (pdo.get(D_SUCCESS_CDT_CUST_DERIV)== null) {
			pdo.set(D_SUCCESS_CDT_CUST_DERIV, ServerConstants.BOOL_TRUE);
		}

		// Executes beneficiary account validation, only if it wasn't processed yet, (MI_CDB_STS = 'P').
		// 2 other options: 
		// 1) MI_CDB_STS = 'X' --> Beneficiary account validation wasn't processed yet at all.									
		// 2) MI_CDB_STS = 'W' --> Beneficiary account validation was processed once; recieved response caused message to go to REPAIR; user
		//                         has fixed it and now we need to re-execute the validation.
		// In addition, the 'bSkipBeneficiaryAccountValidation' should be false, where example for a case that we want to skip the
		// process is when this method is called for a return message, (see 'performAfterReturnPostingASAP' method).
		if(!MONITOR_FLAG_PROCESSED.equals(pdo.getString(MI_CDB_STS)) && !bSkipBeneficiaryAccountValidation)
		{
			sLastStep = EXECUTE_STEP_BENEFICIARY_ACCOUNT_VALIDATION;
			feedback = executeBeneficiaryAccountValidation();
		}
		// Outgoing request for charges.
		if (feedback.isSuccessful() && pdo.getString(PDOConstantFieldsInterface.P_CDT_MOP).equals(MOP_BOOK))
		{
			feedback = m_outgoingRequestForChargesLogging.matchIncomingPaymentToOutgoingRequestForCharges(admin, sMID);

			if (feedback.isSuccessful() && pdo.getString(PDOConstantFieldsInterface.MF_OUT_REQ_FOR_CHRG_MATCH_STS).equals(MessageConstantsInterface.MONITOR_FLAG_MATCH))
			{
				feedback = BOProxies.m_feeCalculationLogging.setDerivedFeeAmountLogicalFields(admin);

				if (feedback.isSuccessful())
				{
					feedback = BOHighValueProcess.performPostingInfo(pdo);

					if (feedback.isSuccessful())
					{
						String initialProcessStatus = pdo.getString(PDOConstantFieldsInterface.P_MSG_STS);
						pdo.set(PDOConstantFieldsInterface.P_MSG_STS, MessageConstantsInterface.MESSAGE_STATUS_COMPLETE);

						compareMessageStatusBeforeAfter(initialProcessStatus, pdo, MATCH_INCOMING_TO_OUTGOING_MODULE, feedback);
					}
				}
			}
		}

		// Executes credit SLA rule.      
		if(feedback.isSuccessful())
		{
			sLastStep = EXECUTE_STEP_CREDIT_SLA;
			feedback = executeMapPaymentInfoUsingRules(sMID, RULE_TYPE_ID_CREDIT_SLA, null);
		}

		// Transfer method identification.
		if(feedback.isSuccessful())
		{
			String sP_MSG_CLASS = pdo.getString(P_MSG_CLASS);
			String cdtMop = pdo.getString(P_CDT_MOP);
			// No need when we're in outgoing reject/return.
			if(!MSG_CLASS_ORJ.equals(sP_MSG_CLASS) && !MSG_CLASS_ORT.equals(sP_MSG_CLASS) 
					//QC # 16471-15526 202 being sent in 103 body.
					&& !MSG_CLASS_OPI.equals(sP_MSG_CLASS)&& !MSG_CLASS_OSN.equals(sP_MSG_CLASS)
					&& !(MSG_CLASS_PI.equals(sP_MSG_CLASS) && cdtMop.equals(MOP_DOWNST)))
			{
				sLastStep = EXECUTE_STEP_TRANSFER_METHOD;
				feedback = m_bankRoutLogging.performTransferMethodIdentification(admin, sMID, bAgentBICIsUsed);
			}
		}
		// If required, executes CREDIT currency conversion.
		if(feedback.isSuccessful() && pdo.get(PDOConstantFieldsInterface.P_CDT_AMT) == null)
		{
			sLastStep = EXECUTE_STEP_CREDIT_CURRENCY_CONVERSION_AFTER_MOP_SELECTION;
			pdo.set(D_CURRENCY_CONVERSION_TYPE, ConversionType.Credit.toString());
			feedback = m_currencyConversionLogging.performCurrencyConversion(admin, sMID);
		}

		// Executes POL processing.
		if(feedback.isSuccessful())
		{
			sLastStep = EXECUTE_STEP_POL_PROCESSING;
			sOldStatus = pdo.getString(P_MSG_STS);
			PISNMatchingOutputData pisnMatchingOutputData = m_pisnMatchingLogging.performPOLCheckingAndBlocking(admin, sMID);
			feedback = pisnMatchingOutputData.getFeedback();
			compareMessageStatusBeforeAfter(sOldStatus, pdo, POL_CHECKING_AND_BLOCKING_MODULE, feedback);
		}


		// Executes special instruction.
		if(feedback.isSuccessful())
		{
			sLastStep = EXECUTE_STEP_SPECIAL_INSTRUCTION;
			SpecialInstructionOutputData specialInstructionOutputData = m_specialInstructionLogging.performSpecialInstruction(admin, sMID);
			feedback = specialInstructionOutputData.getFeedback();
		}

		// Executes validation selection rule.
		if(feedback.isSuccessful())
		{
			sLastStep = EXECUTE_STEP_VALIDATION_RULE_SELECTION;
			feedback = executeValidationSelectionRule(pdo, sOldStatus);
		}

		logger.info(LAST_STEP + sLastStep);

		// Process wasn't completed successfully.
		if(!feedback.isSuccessful())
		{
			// Ensure non-zero error code.
			if(feedback.getErrorCode() == 0)
			{
				feedback.setErrorCode(1);
			}
		}



		return feedback;
	}

	/**
	 * 
	 */
	@Expose
	public static Feedback performReturnAfterPostingASAP(String sMID) throws Throwable
	{


		Feedback feedback = new Feedback();

		try
		{
			PDO pdo = PaymentDataFactory.load(sMID);
			feedback = performAfterPostingASAP(pdo, sMID, false, true /* Skip beneficiary account validation */);

			if(feedback.isSuccessful())
			{
				BOHighValueProcess.executeProcessCompletion(pdo, feedback, pdo.getString(P_MSG_STS));
			}
		}
		finally
		{ 

		}

		return feedback;
	}

	/**
	 * 
	 */
	public static Msgerr removeProcessError(Set<Integer> setOptionalErrorCodes)
	{


		Msgerr removedMsgerr = null;
		PDO pdo = Admin.getContextPDO();
		List<Msgerr> listMsgerr = pdo.getListMSGERR();
		int iSize = listMsgerr.size();
		boolean bFound = false;

		for(int i=0; i<iSize && !bFound; i++)
		{
			Msgerr msgerr = listMsgerr.get(i);
			if(msgerr.getIsNew() && setOptionalErrorCodes.contains(msgerr.getErrorCode().intValue()))
			{
				listMsgerr.remove(i);
				removedMsgerr = msgerr;
				bFound = true;
			}
		}



		return removedMsgerr;
	}

	/**
	 * 
	 */
	private static Feedback executeBeneficiaryAccountValidation() throws Throwable
	{


		Feedback feedback = new Feedback();

		Admin admin = Admin.getContextAdmin();
		PDO pdo = admin.getContextPDO();
		String sP_OFFICE = pdo.getString(P_OFFICE);

		String[] arrObjectIDs = new String[]{sP_OFFICE};
		List<RuleResult> listRuleResults = BOProxies.m_internalRuleExecutionLogging.executeRule(admin, RULE_TYPE_ID_ACCOUNT_LOOKUP, null, pdo.getMID(), arrObjectIDs).getResults();

		if(!listRuleResults.isEmpty())
		{
			// Either 'External' or 'Internal'.
			String sAccountLookupType = listRuleResults.get(0).getAction();

			// 'External' account lookup is required.
			if(AccountLookupType.External.toString().equalsIgnoreCase(sAccountLookupType))
			{
				String sOldStatus = pdo.getString(P_MSG_STS);
				feedback.setFeedback(BOProxies.m_internalInterfacesLogging.performOutgoingRequestHandler(admin, pdo.getMID(), INTERFACE_TYPE_CDB, InterfaceTypes.INTERFACE_SUB_TYPE_CR)) ; 
				compareMessageStatusBeforeAfter(sOldStatus, pdo, BENEFICIARY_ACCOUNT_VALIDATION_MODULE, feedback);
			}
		}



		return feedback;
	}

	/**
	 * 
	 */
	public static Feedback executeValidationSelectionRule(PDO pdo, String sOldStatus) throws Exception
	{


		String sMID = pdo.getMID();

		String[] arrOutput = new String[1];
		Feedback feedback = executeMapPaymentInfoUsingRules(sMID, RULE_TYPE_ID_VALIDATION, arrOutput);
		compareMessageStatusBeforeAfter(sOldStatus, pdo, VALIDATION_RULE, feedback);

		// Message status was changed due to validation rule failure; adds error message to the PDO.
		if(!feedback.isSuccessful())
		{
			String sRuleAction = arrOutput[0]; // Stands for the PREVENT_STP record.
			PreventStp preventStp = CacheKeys.preventStpKey.getSingle(sRuleAction);
			Object[] arrNonPaymentFields = null;
		    String sErrorDescription = null;
		    Long errorCode = preventStp.getErrorCode();
		      
			if(errorCode!=null){
			    arrNonPaymentFields = new String[] { pdo.getString(X_TX_ID),pdo.getString(F_UMR),pdo.getString(F_CREDITOR_ID)};
			    ErrorAuditUtils.setError(errorCode.intValue(), pdo.getMID(), feedback, null, arrNonPaymentFields);
			    sErrorDescription = preventStp.getDescription();
			}else{
				// Error code 40111: 'Validation rule |1 (|2) found'.
				arrNonPaymentFields = new Object[]{preventStp.getName(), preventStp.getDescription()};
				ProcessError processError = new ProcessError(ProcessErrorConstants.ValidationRuleFailure, arrNonPaymentFields);
				ErrorAuditUtils.setErrors(processError,pdo.getIsHistory());
				sErrorDescription = processError.getDescription();
			}

			// Updates the feedback that will be displayed to the user.
			feedback.setErrorText(sErrorDescription);
			feedback.setUserErrorText(sErrorDescription);
		}



		return feedback;
	}

	/**
	 * 
	 */
	public static boolean compareMessageStatusBeforeAfter(String sOldStatus, PDO pdo, String sRelatedModule, Feedback feedback)
	{
		final String MESSAGE = " result - old status: %s, new status: %s.";

		boolean bStopProcess = false;



		String sNewStatus = pdo.getString(P_MSG_STS);

		if (!sNewStatus.equals(sOldStatus))
		{
			logger.info(String.format(sRelatedModule + MESSAGE, sOldStatus, sNewStatus));
			bStopProcess = true;

			// Error code 1001: 'Message status changed from |1 to |2'.
			// Note that this is only for feedback sake and not being added to the PDO's errors.
			// In addition, this feedback may be overridden by another feedback according to the business step that has called
			// this method, (e.g. validation selection rule from within this class).
			String sD_BUTTON_ID = pdo.getString(D_BUTTON_ID);
			if (feedback != null && sD_BUTTON_ID != null && 
					(sD_BUTTON_ID.startsWith(MESSAGE_BUTTON_MATCH_SN_ANY)
							|| sD_BUTTON_ID.startsWith(MESSAGE_BUTTON_MATCH_SC_ANY)
							|| sD_BUTTON_ID.startsWith(MESSAGE_BUTTON_MATCH_LC_ANY)
							|| sD_BUTTON_ID.startsWith(MESSAGE_BUTTON_MATCH_AF_ANY)
							|| sD_BUTTON_ID.startsWith(MESSAGE_BUTTON_MATCH_DIRECT_ANY)
							|| sD_BUTTON_ID.startsWith(MESSAGE_BUTTON_MATCH_COVER_ANY)))
			{
				feedback.setFailure();
				String sOperationID = pdo.getString(PDOConstantFieldsInterface.D_BUTTON_ID);
				String sMessageError = getErrorAuditUtils().loadErrorAuditText((long) ProcessErrorConstants.MessageOperationCompletedSuccesssfully,
						pdo.getMID(), new Object[] { sOperationID });
				// feedback.getDialogs().getLast().setButtons(UserDialog.DIALOG_BUTTON_CLOSE_MSG);// close/next message
				feedback.setErrorText(sMessageError);
				feedback.setUserErrorText(sMessageError);
			}

			else if (feedback != null)
			{
				// CR 112827 Redundant message popup displayed when trying to perform force posting on the message.
				feedback.setFailure();
				feedback.setErrorCode(ProcessErrorConstants.MessageStatusChanged);
				String sMessageError = getErrorAuditUtils().loadErrorAuditText((long) ProcessErrorConstants.MessageStatusChanged,
						pdo.getMID(), new Object[] { sOldStatus, sNewStatus });
				feedback.setErrorText(sMessageError);
				feedback.setUserErrorText(sMessageError);
				feedback.setErrorVariables(new BindingParameter[] {new BindingParameter(sOldStatus, DataType.STRING),new BindingParameter(sNewStatus, DataType.STRING)});
			}
		}



		return bStopProcess;
}
	
	public static boolean compareMessageStatusBeforeAfter(String sOldStatus, PDO pdo, String sRelatedModule, Feedback feedback, String interfaceName)
	{
		final String MESSAGE = " result - old status: %s, new status: %s.";

		boolean bStopProcess = false;



		String sNewStatus = pdo.getString(P_MSG_STS);

		if (!sNewStatus.equals(sOldStatus))
		{
			logger.info(String.format(sRelatedModule + MESSAGE, sOldStatus, sNewStatus));
			bStopProcess = true;

			// Error code 1001: 'Message status changed from |1 to |2'.
			// Note that this is only for feedback sake and not being added to the PDO's errors.
			// In addition, this feedback may be overridden by another feedback according to the business step that has called
			// this method, (e.g. validation selection rule from within this class).
			String sD_BUTTON_ID = pdo.getString(D_BUTTON_ID);
			if (feedback != null && sD_BUTTON_ID != null && 
					(sD_BUTTON_ID.startsWith(MESSAGE_BUTTON_MATCH_SN_ANY)
							|| sD_BUTTON_ID.startsWith(MESSAGE_BUTTON_MATCH_SC_ANY)
							|| sD_BUTTON_ID.startsWith(MESSAGE_BUTTON_MATCH_LC_ANY)
							|| sD_BUTTON_ID.startsWith(MESSAGE_BUTTON_MATCH_AF_ANY)
							|| sD_BUTTON_ID.startsWith(MESSAGE_BUTTON_MATCH_DIRECT_ANY)
							|| sD_BUTTON_ID.startsWith(MESSAGE_BUTTON_MATCH_COVER_ANY)))
			{
				feedback.setFailure();
				String sOperationID = pdo.getString(PDOConstantFieldsInterface.D_BUTTON_ID);
				String sMessageError = getErrorAuditUtils().loadErrorAuditText((long) ProcessErrorConstants.MessageOperationCompletedSuccesssfully,
						pdo.getMID(), new Object[] { sOperationID });
				// feedback.getDialogs().getLast().setButtons(UserDialog.DIALOG_BUTTON_CLOSE_MSG);// close/next message
				feedback.setErrorText(sMessageError);
				feedback.setUserErrorText(sMessageError);
			}

			else if (feedback != null)
			{
				// CR 112827 Redundant message popup displayed when trying to perform force posting on the message.
				feedback.setFailure();
				feedback.setErrorCode(ProcessErrorConstants.MessageStatusChanged);
				String sMessageError = getErrorAuditUtils().loadErrorAuditText((long) ProcessErrorConstants.MessageStatusChangedDueToInterfaceInactive,
						pdo.getMID(), new Object[] { sOldStatus, sNewStatus, interfaceName });
				feedback.setErrorText(sMessageError);
				feedback.setUserErrorText(sMessageError);
				feedback.setErrorVariables(new BindingParameter[] {new BindingParameter(sOldStatus, DataType.STRING),
						new BindingParameter(sNewStatus, DataType.STRING)});
			}
		}



		return bStopProcess;
	}

	/**
	 * 
	 */
	public static Feedback executeMapPaymentInfoUsingRules(String sMID, String sRuleTypeID, String[] arrOutput) throws Exception
	{



		Feedback feedback = new Feedback();

		logger.info("Rule type ID: {}", sRuleTypeID);

		PDO pdo = PaymentDataFactory.load(sMID);

		pdo.set(D_RULE_TYPE_ID, sRuleTypeID);
		MapPaymentInfoUsingRulesOutputData mapPaymentInfoUsingRulesOutputData = BOMapPaymentInfoUsingRules.handleRuleExecutionAndMappingToPDO(sMID);

		feedback = mapPaymentInfoUsingRulesOutputData.getFeedback();

		if(feedback.isSuccessful())
		{
			RuleResults ruleResults = mapPaymentInfoUsingRulesOutputData.getRuleResults();

			// Rule has returned no results.
			if(ruleResults == null || ruleResults.getResults().isEmpty())
			{
				if(   (RULE_TYPE_ID_DEPARTMENT.equals(sRuleTypeID) && GlobalUtils.isNullOrEmpty(pdo.getString(PDOConstantFieldsInterface.P_DEPARTMENT))) //in case of department rule, verify that department field is empty (department can be entered manually)
						|| (RULE_TYPE_ID_BUSINESS_AREA.equals(sRuleTypeID) && GlobalUtils.isNullOrEmpty(pdo.getString(PDOConstantFieldsInterface.P_BA_CD))) //in case of business area rule, verify that business area field is empty
						|| RULE_TYPE_ID_PRODUCT.equals(sRuleTypeID)
						|| RULE_TYPE_ID_DR_TRANSACTION_CODE.equals(sRuleTypeID)
						|| RULE_TYPE_ID_CR_TRANSACTION_CODE.equals(sRuleTypeID)
						//           || RULE_TYPE_ID_PAYMENT_CLASSIFICATION.equals(sRuleTypeID) && GlobalUtils.isNullOrEmpty(pdo.getString(PDOConstantFieldsInterface.P_MSG_CLASS)))
						|| RULE_TYPE_ID_PAYMENT_CLASSIFICATION.equals(sRuleTypeID) )
				{
					String sRuleTypeName = CacheKeys.PRulesTypeKey.getSingle(sRuleTypeID).getRuleTypeName();

					Object[] arrNonPaymentFields = new Object[]{sRuleTypeID, sRuleTypeName};

					// Error code 40104: 'Rule type ID |1 - |2 - wasn't found'.
					ProcessError processError = new ProcessError(ProcessErrorConstants.MandatoryRuleTypeIDWasntFound, arrNonPaymentFields);
					configureErrorFeedback(processError.getErrorCode(), processError.getDescription(), feedback);
					logger.info(processError.getDescription());
					ErrorAuditUtils.setErrors(processError,pdo.getIsHistory());
				}
			}

			// Rule has returned results; checks cases for special rule types.
			else
			{
				// Will be checked in the caller method; success/failure will be determined there.
				if(   RULE_TYPE_ID_MSG_FILTER.equals(sRuleTypeID)
						|| RULE_TYPE_ID_VALIDATION.equals(sRuleTypeID))
				{
					arrOutput[0] = ruleResults.getResults().get(0).getAction();
				}
			}
		}

		return feedback;
	}  


	/**
	 * prerequisite : Message Classification was already performed.
	 * 
	 * Performs validation on the account - verifies that sender of the message is the account's owner.
	 * The validation will be performed only for: msg_types in (900,910,298_011,298_012) && msg_class is SC or SN (Not LC).
	 * If validation fails, an appropriate error is set and msg_status is changed to REPAIR.
	 * 
	 * @param mid
	 * @return feedback
	 */
	public static Feedback executeAccountOwnerValidation(String mid){
		Feedback feedback = new Feedback();
		PDO pdo = PaymentDataFactory.load(mid);	
		String msgClass = pdo.getString(P_MSG_CLASS);
		String msgType = pdo.getString(P_MSG_TYPE);
		boolean isSC = MSG_CLASS_SC.equals(msgClass);
		boolean isSN = MSG_CLASS_SN.equals(msgClass);

		if ((isSC || isSN)&&
				(MESSAGE_TYPE_SWIFT_900.equals(msgType) || MESSAGE_TYPE_SWIFT_910.equals(msgType) || MESSAGE_TYPE_SWIFT_298_011.equals(msgType) || MESSAGE_TYPE_SWIFT_298_012.equals(msgType))){
			logger.info("Performing account validation for MID={} (MsgType={}, MsgClass={}), to verify that sender of the message is account's owner.",new Object[]{mid,msgClass,msgType});


			if (pdo.getString(X_INSTG_AGT_BIC_2AND)!=null && pdo.getSTMT_ACCT_OWNR()!=null && (!pdo.getString(X_INSTG_AGT_BIC_2AND).equals(pdo.getSTMT_ACCT_OWNR().getSwiftId()))){
				logger.error("Failed in account validation. Sender {} is not the owner of the account. The account's owner is {}.",pdo.getString(X_INSTG_AGT_BIC_2AND),pdo.getSTMT_ACCT_OWNR().getSwiftId());
				ProcessError processError = new ProcessError(ProcessErrorConstants.AccountValidationFailureSenderNotOwner, new Object[0]);
				configureErrorFeedback(processError.getErrorCode(), processError.getDescription(), feedback);
				ErrorAuditUtils.setErrors(processError,pdo.getIsHistory());
				pdo.set(P_MSG_STS, MESSAGE_STATUS_REPAIR);	
			}else if (pdo.getSTMT_ACCT_OWNR()==null){
				logger.error("Failure in account validation - WRONG CONFIGURATION. Settlement Account Owner is missing");
			}

		}
		return feedback;
	}

  //mass payment retrofit
	  public static String getSourceMopLogicalField(PDO pdo)
	  {
		  return isDD(pdo) ? PDOConstantFieldsInterface.P_CDT_MOP : PDOConstantFieldsInterface.P_DBT_MOP;
	  }

  public static boolean isDD(PDO pdo)
  {
	  String msgClass = pdo.getString(PDOConstantFieldsInterface.P_MSG_CLASS);
	  String txCtgy = pdo.getString(PDOConstantFieldsInterface.P_TX_CTGY);
	  return (msgClass != null && msgClass.indexOf("DD") > -1 ? true : false) || 
			  (TX_CATEGORY_DRO.equals(txCtgy)? true: false) || (TX_CATEGORY_DDO.equals(txCtgy)) || (TX_CATEGORY_DRI.equals(txCtgy) ? true : false);//add support for outgoing pacs004 which always has msgClass=ORT wither for Debit or for Credit
  }
  public static String getDestinationMopLogicalField(PDO pdo)
  {
	  return !isDD(pdo) ? PDOConstantFieldsInterface.P_CDT_MOP : PDOConstantFieldsInterface.P_DBT_MOP;
  }

  public static Mop getDestinationMop(PDO pdo)
  {
	  return !isDD(pdo) ? pdo.getNSetCREDIT_MOP(): pdo.getNSetDEBIT_MOP();
  }


  public static Mop getSourceMop(PDO pdo)
  {
	  return isDD(pdo) ? pdo.getNSetCREDIT_MOP(): pdo.getNSetDEBIT_MOP();
  }

  public static void executePreventSTPRule(PDO pdo, String sOldStatus, Feedback feedback) throws Exception
  {
  	
		if(feedback.isSuccessful())
		{
	    String[] arrOutput = new String[1];
	    feedback = executeMapPaymentInfoUsingRules(pdo.getMID(), RULE_TYPE_ID_VALIDATION, arrOutput);
	    compareMessageStatusBeforeAfter(sOldStatus, pdo, VALIDATION_RULE, feedback);
	    
	    // Message status was changed due to validation rule failure; adds error message to the PDO.
	    if(!feedback.isSuccessful())
	    {
	      String sRuleAction = arrOutput[0]; // Stands for the PREVENT_STP record.
	      PreventStp preventStp = CacheKeys.preventStpKey.getSingle(sRuleAction);
	      Object[] arrNonPaymentFields = null;
	      String sErrorDescription = null;
	      Long errorCode = preventStp.getErrorCode();
	      
		  if(errorCode!=null){
		    	arrNonPaymentFields = new String[] { pdo.getString(X_TX_ID),pdo.getString(F_UMR),pdo.getString(F_CREDITOR_ID)};
		    	ErrorAuditUtils.setError(errorCode.intValue(), pdo.getMID(), feedback, null, arrNonPaymentFields);
		    	sErrorDescription = preventStp.getDescription();
		  }else{
		    	// Error code 40111: 'Validation rule |1 (|2) found'.
		    	arrNonPaymentFields = new Object[]{preventStp.getName(), preventStp.getDescription()};
		    	ProcessError processError = new ProcessError(ProcessErrorConstants.ValidationRuleFailure, arrNonPaymentFields);
		    	ErrorAuditUtils.setErrors(processError,pdo.getIsHistory());
		    	sErrorDescription = processError.getDescription();
		  }
	      
	      // Updates the feedback that will be displayed to the user.
	      feedback.setErrorText(sErrorDescription);
	      feedback.setUserErrorText(sErrorDescription);
	    }
		}
  }
  
	public static Feedback executeMOP_STP_Validation(String sMID) throws Exception{
		PDO pdo = PaymentDataFactory.load(sMID);
		return executeMOP_STP_Validation(pdo);
	}
	
  /**
   * 
   */
  public static Feedback executeMOP_STP_Validation(PDO pdo) throws Exception
  {
  	final String TRACE_RULE_RESULT = "Rule result, (MESSAGE_STP_RULES.MESSAGE_STP_RULES_NAME): %s.";
  	final String TRACE_NO_RULES_WERE_FOUND = "No rules were found !";
  	final String TRACE_INVALID_MESSAGE_STP_RULES_RECORD = "No MESSAGE_STP_RULES record was found for MESSAGE_STP_RULES name %s !";
  	
  	
  	Feedback feedback = new Feedback();
  	
  	MsgClassType msgClass = isDD(pdo) ? MsgClassType.DD : MsgClassType.CT;
  	Mop mop = msgClass.getDestMop(pdo);
  	
  	String sMopName = mop.getMop();
  	
  	// To be used in BOSTPRules.
  	pdo.setTransient(D_EXECUTE_STP_RULES_USING_MOP, mop.getUidMop());
  	
  	// Will execute MOP STP profile selection rule, (192).
  	feedback = m_stpRulesComplete.validateSTPRules(Admin.getContextAdmin(), pdo.getMID());
  	
  	// STP failure.
  	if(!feedback.isSuccessful())
  	{
  		// This transient field was set during the STP validation process.
  		String sMOPRelatedMessageSTPRulesProfileName = (String)pdo.getWithTransientLookup(D_MOP_RELATED_STP_PROFILE_NAME);
  		
  		// Error code 77904: 'STP validation failure for MOP '|1' using STP profile '|2''.
  		Object[] arrNonPaymentFields = new Object[]{sMopName, sMOPRelatedMessageSTPRulesProfileName};
  		ProcessError processError = new ProcessError(ProcessErrorConstants.MOP_STP_PROFILE_RULES_FAILURE, arrNonPaymentFields);
  		ErrorAuditUtils.setErrors(processError,pdo.getIsHistory());
  		
  		// Configures the error feedback object.
  		configureErrorFeedback(processError.getErrorCode(), processError.getDescription(), feedback);
  	}
  	
  	pdo.removeTransientField(D_EXECUTE_STP_RULES_USING_MOP);
  	pdo.removeTransientField(D_MOP_RELATED_STP_PROFILE_NAME); // This field might have been set in BOSTPRules. 
  		
   	return feedback;
  }

  public static void handleWaitBehaviour(PDO pdo){
	   List<InterfaceTypes> invokedInterfaces = pdo.getInvokedOutgoingInterfaces();
	   if (invokedInterfaces != null){
		   for (InterfaceTypes interfaceTypes : invokedInterfaces) {
			   String waitBehav = interfaceTypes.getWaitBehaviour();
			   WaitBehaviourType.reverseValueOf(waitBehav).executeAtHandoff(pdo.getMID(), interfaceTypes, null);
		   }
	   }
	}
//mass payment retrofit
}
