package backend.paymentprocess.approverefusecancel.businessobjects;

import static com.fundtech.errors.ProcessErrorConstants.MessageStatusChanged;
import static com.fundtech.util.GlobalUtils.isNullOrEmpty;


import com.fundtech.annotations.Expose;
import com.fundtech.annotations.Wrap;
import com.fundtech.cache.entities.InterfaceTypes;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.core.paymentprocess.errorhandling.ProcessError;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.datacomponent.response.SimpleResponseDataComponent;
import com.fundtech.errors.ProcessErrorConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import backend.businessobject.BOBasic;
import backend.businessobject.BOProxies;
import backend.core.module.MessageConstantsInterface;
import backend.paymentprocess.SubBatchProcessInterface;
import backend.paymentprocess.erroraudit.ErrorAuditUtils;
import backend.paymentprocess.highvalueprocess.businessobjects.BOHighValueProcess;
import backend.paymentprocess.loadpostinginfo.common.PostingRequestType;
import backend.util.ServerUtils;


/**
 * Title:       BOApproveRefuseCancel
 * Description: Business object for approval/refusal process of a cancel message
 * Company:     Fundtech Israel
 * Author:      Asaf Levy
 * Date:        27/09/2009
 * @version     1.0
 */
@Wrap(tx="Bean")

public class BOApproveRefuseCancel extends BOBasic implements SubBatchProcessInterface, PDOConstantFieldsInterface, MessageConstantsInterface
{

	private static final Logger logger = LoggerFactory.getLogger(BOApproveRefuseCancel.class);
	private static final String LAST_STEP = "Last step: ";
	private static final String STEP_POSTING = "Posting, (with D_POSTING_REQUEST = REVERSE)";
	private static final String STEP_FIELDS_CLEANING = "Cleaning index fields and related monitor fields";
	private static final String STEP_GENERATE_TRANSACTION = "Generate Transaction for the incoming cancellation request";
	private static final String STEP_FORMATTING_AND_TRANSMISSION = "Formatting & Transmission for the incoming cancellation request";
	
  // Used when the cancellation is being refused by the user; see call to 'BOHighValue.updateMFAMILY_ForCancelOrRefusalAction' method
	// within this class.
  private static Object[] ARR_SECONDARY_RELATION_TYPES_FOR_REFUSED_CANCELLATION_REQUEST = 
  															 {new String[]{RELATION_TYPE_INCOMING_CANCELLATION_REQUEST, RELATION_TYPE_INCOMING_CANCELLATION_REQUEST_REFUSED},
  															  new String[]{RELATION_TYPE_OUTGOING_CANCELLATION_REQUEST, RELATION_TYPE_OUTGOING_CANCELLATION_REQUEST_REFUSED}};	
	
  /**
   * Handles 'Approve' or 'Refuse' action for a cancellation request that was performed for the passed MID
   * which is in 'APPROVE_CANCEL' status; the cancellation could have been caused because of:
   * 1) Either an incoming or an outgoing cancellation request for the passed MID.
   * OR
   * 2) Cancel action was initiated directly by the user by pressing the 'Cancel' button in the original payment.
   */
  @Expose
  public Feedback handleApproveRefuseCancel(String sMID) throws Throwable
  {
  	final String TRACE_METHOD_INPUT = "BOApproveRefuseCancel.handleApproveRefuseCancel - MID: {}, Action ID: {}, P_MSG_STS: {}, MF_POSTING_STS: {}, Only generate answer message: {}.";
  	final String TRACE_PERFORM_REVERSE_POSTING = "Perform reverse posting: {}.";
  	final String TRACE_STATUSES_COMPARISON = "Statuses comparison - Before reverse posting: {}, After reverse posting: {}.";
  	final String TRACE_POSTING_FAILURE = "Posting failure for MID {}. {}";
  	final String TRACE_STATUS_WAS_CHANGED_NO_INCOMING_CANCELLATION_REQ_HANDLING = "Status was changed from {} to {}; if incoming cancellation request exists, no answer will be generated for it till posting response is received !";
  	final String TRACE_STATUS_WAS_CHANGED = "Status was changed from {} to {}; no approval process will be executed till posting response is received !";
  	final String TRACE_INCOMING_CANCELLATION_REQUEST = "Existing incoming cancellation request for this Approve/Refuse cancel request - MID: {}.";
  	final String TRACE_NULL_GENERATED_ANSWER_MID = "Got back empty/null MID from the call for generating the 'Answer' message; probably, missing rule type ID 150 for {} and {}, for offices {} and '***'.";
  	final String TRACE_NO_INCOMING_CANCELLATION_REQUEST = "No INCOMING cancellation request for this Approve/Refuse cancel request !";
  	final String TRACE_GENERATED_ANSWER_MID = "Generated 'Answer' message MID: {}."; 
  	final String TRACE_APPROVE_REFUSE_FAILURE_MESSAGE = "Failure during Approve/Refuse Cancel request = MID: {}, 'Answer' message was generated and cleared: {}.";
  	final String TRACE_SUCCESSFULL_APPROVE_REFUSE_PROCESS = "Successful Approve/Refuse cancel request for MID {}; continues with setting payment statuses and save process...";
  	final String TRACE_ADDS_ANSWER_MESSAGE_TO_ORIG_PAYMENT_RELATION_MAP = "Adds the generated 'Answer' message to the original payment's relations map for future save"; 
  	
    

    Feedback feedback = new Feedback();
    String sLastStep = null;
    //PDO pdo = null;
    
    Admin admin = Admin.getContextAdmin();

    PDO pdo = PaymentDataFactory.load(sMID);
    String sActionID = pdo.getString(D_BUTTON_ID);
    String sP_MSG_STS = pdo.getString(P_MSG_STS);
    String sMF_POSTING_STS = pdo.getString(MF_POSTING_STS);
    
    // Will be set into the PDO when an INCOMING cancellation request has been received for the payment and the payment is already
    // in CANCELED status as a result of an OUTGOING cancellation request that was already approved by the user.
    // The set to this field is done in 'BONMessagesHandling.performNMessageHandling'.
    Object oD_ONLY_GENERATE_ANSWER_MSG = pdo.getWithTransientLookup(D_ONLY_GENERATE_ANSWER_MSG);
    boolean bOnlyGenerateAnswerMessage = oD_ONLY_GENERATE_ANSWER_MSG != null && ((Boolean)oD_ONLY_GENERATE_ANSWER_MSG).booleanValue();
    
    logger.info(TRACE_METHOD_INPUT,  new Object[]{ sMID, sActionID, sP_MSG_STS, sMF_POSTING_STS, bOnlyGenerateAnswerMessage});
    
    boolean bIsInterfaceTypePosting = InterfaceTypes.INTERFACE_TYPE_POSTING.equals(pdo.getString(D_INTERFACE_RESPONSE));
    boolean bApproveAction = MESSAGE_BUTTON_APPROVE.equals(sActionID) ;
    String sGracefulTerminationStatus = null;
    PDO pdoIncomingCancellationRequest = null;
    boolean bValidIncomingCancellationPDO = false;
    
    PDO pdoAnswer = null;

    
  	boolean bPerformReversePosting = !MESSAGE_STATUS_CANCELED.equals(sP_MSG_STS) && !MONITOR_FLAG_REVERSE.equals(sMF_POSTING_STS);
  	logger.info(TRACE_PERFORM_REVERSE_POSTING, bPerformReversePosting);

  	// Reverse posting; will be executed only if:
  	// 1) This is an approve action.
  	// 2) We didn't arrive here from the posting interface handler. 
  	// 3) Payment status isn't CANCELED and its MF_POSTING_STS isn't 'R'. 
  	// 4) Call for this method wasn't from the 'BONMessagesHandling.performNMessageHandling' that requires only generation of answer message for an
  	//    INCOMING cancellation request.
    if(bApproveAction && !bIsInterfaceTypePosting && bPerformReversePosting && !bOnlyGenerateAnswerMessage)
    {

      sLastStep = STEP_POSTING;
      pdo.set(D_POSTING_REQUEST, PostingRequestType.REVERSE.name());
      feedback = BOHighValueProcess.performPostingInfo(pdo);
      
      // Fields cleaning.
      sLastStep = STEP_FIELDS_CLEANING;
      //PISN
      pdo.set(P_PISN_INDEX, (String)null);
      pdo.set(MF_PISN_MATCH_STS, MONITOR_FLAG_NONE);
      //OPI_OSN
      pdo.set(MF_OPIOSN_MATCH_STS, MONITOR_FLAG_NONE);
      //SC
      pdo.set(P_SC_INDEX, (String)null);
      pdo.set(MF_SC_MATCH_STS, MONITOR_FLAG_NONE);
      //AF
      pdo.set(P_AF_INDEX, (String)null);
      pdo.set(MF_AF_MATCH_STS, MONITOR_FLAG_NONE);
      //LC
      pdo.set(P_LC_INDEX, (String)null);
      pdo.set(MF_LC_MATCH_STS, MONITOR_FLAG_NONE);
    }
    
    String sLatestP_MSG_STS = pdo.getString(P_MSG_STS);
    logger.info(TRACE_STATUSES_COMPARISON, sP_MSG_STS, sLatestP_MSG_STS);
    boolean bStatusWasChanged = !sP_MSG_STS.equals(sLatestP_MSG_STS);

    // Generates answer message for the INCOMING cancellation request, (if such one exists; the cancellation request might also be
    // an OUTGOING one for which there is no need to generate an answer message).
    //
    // Will be performed if:
    // 1) Refuse action.
    // 2) As a result of received posting response which will eventually execute this class' related flow;
    //    In case reverse posting was done above and some failure has occurred or in case the reverse posting has changed the message status,
    //    (e.g. MP_WAIT, MP_STOP etc), then no need to continue.
    //    If status was indeed changed, then this class will be called again after the posting response will return,
    //    (see 'PostingInterfaceHandler.handlePosting' method for PostingStatusType 'OK' enum).
    // 3) Call was from the 'BONMessagesHandling.performNMessageHandling' that requires only generation of answer message for an
  	//    INCOMING cancellation request.
    if(feedback.isSuccessful() && !bStatusWasChanged /* && bOnlyGenerateAnswerMessage */)
    {
      // Checks if there is an existing INCOMING cancellation request for this MID.
      pdoIncomingCancellationRequest = pdo.getLinkedMsg(MessageConstantsInterface.RELATION_TYPE_INCOMING_CANCELLATION_REQUEST);
      bValidIncomingCancellationPDO = pdoIncomingCancellationRequest != null;

      if(bValidIncomingCancellationPDO)
      {
      	String sCancellationMID = pdoIncomingCancellationRequest.getMID();
      	
      	// Handles the PREVIOUS message status; always set it to the one with which we entered the flow,
      	// (probably SERVICE_WAIT), as the next line will always update the message status to either COMPLETE
      	// or to REJECTED.
      	String sCancellationOrigPREVIOUS_MSG_STS = pdoIncomingCancellationRequest.getString(P_PREVIOUS_MSG_STS);
      	String sOldStatus = pdoIncomingCancellationRequest.getString(P_MSG_STS);
      	
        pdoIncomingCancellationRequest.set(P_PREVIOUS_MSG_STS, sOldStatus);
        
        // NOTE: DO NOT MOVE THIS SET AFTER THE AHEAD GENERATE TRANSACTION RULE AS THE RULE ITSELF TAKES IN CONSIDER
        //       THE UPDATED 192 STATUS !!!
        String sNewCancellationStatus = bApproveAction ? MESSAGE_STATUS_COMPLETE : MESSAGE_STATUS_REJECTED;
        pdoIncomingCancellationRequest.set(P_MSG_STS, sNewCancellationStatus);

        // Incoming cancellation request.
        if(pdoIncomingCancellationRequest.isIncomingMessage())
        {
        	logger.info(TRACE_INCOMING_CANCELLATION_REQUEST, sCancellationMID);
        	
          // Calls the 'Generate Transaction' BO, for getting back the 'Answer' message for the incoming cancellation N92 message.
        	sLastStep = STEP_GENERATE_TRANSACTION;
        	
        	pdoIncomingCancellationRequest.promoteToPrimary();
        	
          SimpleResponseDataComponent generateTransactionResponse = BOProxies.m_generateTransactionLogging.generateRelatedTransaction(admin, sCancellationMID, RELATION_TYPE_INCOMING_CANCELLATION_REQUEST, RELATION_TYPE_ANSWER);
          feedback = generateTransactionResponse.getFeedback();

          Object[] arrData = generateTransactionResponse.getDataArray();
          boolean bValidGeneratedMID = ServerUtils.isArrayNotNullAndNotEmpty(arrData); 
          
          String sAnswerGeneratedMID = null;
          
          // Executes formatting and transmission for the answer MID.
          if(feedback.isSuccessful())
          {
          	// Valid generated MID.
          	if(bValidGeneratedMID)
          	{
              sAnswerGeneratedMID = generateTransactionResponse.getDataArray()[0].toString();
              logger.info(TRACE_GENERATED_ANSWER_MID, sAnswerGeneratedMID);
              pdoAnswer = pdoIncomingCancellationRequest.getLinkedMsg(RELATION_TYPE_ANSWER);

              sLastStep = STEP_FORMATTING_AND_TRANSMISSION;
              feedback = BOHighValueProcess.performFormatOutAndTransmission(pdoAnswer, feedback);
	
	            // Success.
	            if(feedback.isSuccessful())
	            {
	            	// Handles the 'Answer' message.
	              BOHighValueProcess.performTerminationSubFlow(pdoAnswer, MESSAGE_STATUS_COMPLETE);
	              
	              // Handles the INCOMING cancellation request message, only if the call wasn't originated from the
	              // 'BONMessagesHandling.performNMessageHandling' that requires only generation of answer message.
	              if(!bOnlyGenerateAnswerMessage)
	              {
		              pdoIncomingCancellationRequest.promoteToPrimary();
		              BOHighValueProcess.performTerminationSubFlow(pdoIncomingCancellationRequest, sNewCancellationStatus);
	              }
	            }
          	}
          	
          	// Writes notification to trace file.
          	else
          	{
          		logger.info(TRACE_NULL_GENERATED_ANSWER_MID, new Object[]{RELATION_TYPE_INCOMING_CANCELLATION_REQUEST, RELATION_TYPE_ANSWER, pdoIncomingCancellationRequest.getString(P_OFFICE)});
          	}
          }

          // Some failure.
          else
          {
          	logger.info(TRACE_APPROVE_REFUSE_FAILURE_MESSAGE, sMID, (pdoAnswer != null));
          	
            // In case the failure was after the transaction generation, then removes the created 'Answer' PDO
            // from the incoming cancellation N92 message.
            if(pdoAnswer != null)
            {
              pdoIncomingCancellationRequest.clearLinkedMsg(RELATION_TYPE_ANSWER);
            }

            // Verifies that the status of the original payment will remain APPROVE_CANCEL.
            // This is done only if 'bOnlyGenerateAnswerMessage' is false, (which means that the original payment status was not CANCELED when we entered this flow). 
            if(!bOnlyGenerateAnswerMessage) sGracefulTerminationStatus = MessageConstantsInterface.MESSAGE_STATUS_APPROVE_CANCEL;
            
            // Rollback to the cancellation message statuses.
            pdoIncomingCancellationRequest.set(P_PREVIOUS_MSG_STS, sCancellationOrigPREVIOUS_MSG_STS);              
            pdoIncomingCancellationRequest.set(P_MSG_STS, sOldStatus);

            // Sets back the 'Original Payment' PDO to be the primary PDO for rest of the process.
            pdo.promoteToPrimary();            

            // Updates the PDO with an error message.
            // Error code 40103: 'Approve/Refuse action has failed due to error in generating answer message to the related incoming cancellation request'.
            ProcessError processError = new ProcessError(ProcessErrorConstants.ApproveRefuseActionFailureForCancellationRequest);
            ErrorAuditUtils.setErrors(processError,pdo.getIsHistory());
          }
        }
      }
      
      // There is no cancellation request for this MID.
      else
      {
      	logger.info(TRACE_NO_INCOMING_CANCELLATION_REQUEST);
      }
    }

    // Either posting failure or status was changed.
    else
    {
    	// Posting failure.
    	if(!feedback.isSuccessful()) 
    	{
    		logger.info(TRACE_POSTING_FAILURE, sMID, ServerUtils.getFeedbackString(feedback));
        sGracefulTerminationStatus = MESSAGE_STATUS_REPAIR;
    	}
    	
      // Status was changed by the reverse posting call.
    	else logger.info(TRACE_STATUS_WAS_CHANGED_NO_INCOMING_CANCELLATION_REQ_HANDLING, sP_MSG_STS, sLatestP_MSG_STS); 
    }
    
    // Sets back the 'Original Payment' PDO to be the primary PDO for rest of the process.
    pdo.promoteToPrimary();            

    // In case reverse posting was done and some failure has occurred or in case the posting has changed the message status,
    // (e.g. MP_WAIT, MP_STOP etc), then no need to continue.
    // If status was indeed changed, then this class will be called again after the posting response will return,
    // (see 'PostingInterfaceHandler.handlePosting' method for PostingStatusType 'OK' enum).
    //
    // Performs actual approval/refusal process in case of:
    // 1) Refuse action.
    // 2) As a result of received posting response which will eventually execute this class' related flow as explained above.
    // 3) Call WASN'T from the 'BONMessagesHandling.performNMessageHandling' that requires only generation of answer message for an
  	//    INCOMING cancellation request; if this boolean is true, then it means that the message was already canceled by an OUTGOING cancellation
    //    request that was already approved by the user.
    if(feedback.isSuccessful() && !bStatusWasChanged && !bOnlyGenerateAnswerMessage)
    {
    	logger.info(TRACE_SUCCESSFULL_APPROVE_REFUSE_PROCESS, sMID);
    	
      if(bApproveAction)
      {
      	ProcessError processError = new ProcessError(MessageStatusChanged, new Object []{pdo.getString(P_MSG_STS),MESSAGE_STATUS_CANCELED});
  	    ErrorAuditUtils.setErrors(processError,pdo);
        pdo.set(P_MSG_STS, MESSAGE_STATUS_CANCELED);
      }
      else // Refuse
      {
      	String sPREVIOUS_MSG_STS = pdo.getString(P_PREVIOUS_MSG_STS);
      	
      	// Previous status is set to be the current message status.
      	pdo.set(P_PREVIOUS_MSG_STS, pdo.get(P_MSG_STS));

      	// Message status is set to be the base message status, (i.e. message status and BASE message status are actually the same),
      	// unless P_BASE_MSG_STS is empty in which case the P_PREVIOUS_MSG_STS will be used.
      	final String ERROR_MESSAGE_EMPTY_P_BASE_MSG_STS = "ERROR: Refuse action - empty/null P_BASE_MSG_STS value; sets P_PREVIOUS_MSG_STS into P_MSG_STS !!!";
      	String sBASE_MSG_STS = pdo.getString(P_BASE_MSG_STS);
      	//
      	if(isNullOrEmpty(sBASE_MSG_STS))
      	{
      		logger.info(ERROR_MESSAGE_EMPTY_P_BASE_MSG_STS);
      		pdo.set(P_MSG_STS, sPREVIOUS_MSG_STS);
      	}
      	else
      	{
      		pdo.set(P_MSG_STS, sBASE_MSG_STS);
      	}
      	
      	// MFAMILY update to allow a new incoming/outgoing cancellation request for this MID.
      	BOHighValueProcess.updateMFAMILY_ForCancelOrRefusalAction(pdo, RELATION_TYPE_ORIGINAL_PAYMENT, ARR_SECONDARY_RELATION_TYPES_FOR_REFUSED_CANCELLATION_REQUEST);
      }
    }

    BOHighValueProcess.performTerminationSubFlow(pdo, sGracefulTerminationStatus);

    // If an 'Answer' message was generated, adds it as a transient PDO to the map "related" messages of the original payment;
    // This is done for the latter save process of the original payment which will be done in the 'BOMessageHandle.submitMessage' method,
    // and that as a result of it the 'Answer' messge will be saved as well.
    if(pdoAnswer != null)
    {
    	logger.info(TRACE_ADDS_ANSWER_MESSAGE_TO_ORIG_PAYMENT_RELATION_MAP);
    	pdo.addTransientLinkMsg(pdoAnswer, null, RELATION_TYPE_ANSWER);
    }

    //if message was canceled successfully, and it is an OPI/OSN - check if there is a matched message that should also be canceled
    boolean isOPI = MSG_CLASS_OPI.equals(pdo.getString(P_MSG_CLASS));
    boolean isOSN = MSG_CLASS_OSN.equals(pdo.getString(P_MSG_CLASS));
    
    if (MESSAGE_STATUS_CANCELED.equals(pdo.getString(P_MSG_STS))&& (isOPI || isOSN)){
    	
    	PDO matchedPdoToCancel = pdo.getLinkedMsg(isOPI?RELATION_TYPE_COVER:RELATION_TYPE_DIRECT);
    	
    	if ((matchedPdoToCancel!=null)&&(!MESSAGE_STATUS_CANCELED.equals(matchedPdoToCancel.getString(P_MSG_STS)))){

    		if (isOSN && (MESSAGE_STATUS_WAIT_ACK.equals(matchedPdoToCancel.getString(P_MSG_STS)) || MESSAGE_STATUS_COMPLETE.equals(matchedPdoToCancel.getString(P_MSG_STS)))){

    			//do not cancel matched message, show a message to the user
    			logger.info("Message {} was canceled successfully, but there is a linked direct msg {}, which is in {} status, and it will not be canceled automatically. A pop-up message will be displayed to user.",new Object[]{pdo.getMID(),matchedPdoToCancel.getMID(),matchedPdoToCancel.getString(P_MSG_STS)});

    			ProcessError processError = new ProcessError(ProcessErrorConstants.CannotCancelMatchedOPI, new Object[]{});
    			ErrorAuditUtils.setErrors(processError,matchedPdoToCancel.getIsHistory());

    			// Updates the feedback that will be displayed to the user.
    			feedback.setFailure();
    			feedback.setErrorCode(processError.getErrorCode());
    			feedback.setErrorText(processError.getDescription());

    		}else{//cancel matched message

    			logger.info("Message {} was canceled successfully. There is a linked msg {}, which is in {} status and is about to be canceled automatically too.",new Object[]{pdo.getMID(),matchedPdoToCancel.getMID(),matchedPdoToCancel.getString(P_MSG_STS)});
	    		//promote linked pdo to primary and start cancellation flow for it
	        	matchedPdoToCancel.promoteToPrimary();
	        	matchedPdoToCancel.set(D_BUTTON_ID,MESSAGE_BUTTON_APPROVE);
	        	handleApproveRefuseCancel(matchedPdoToCancel.getMID());
	        	//promote original PDO back to primary
	        	pdo.promoteToPrimary();
	        	
    		}
        }
    }

    return feedback;
  }

}
