package backend.paymentprocess.approverefusecancel.ejb;

import javax.ejb.Stateless;
import backend.core.SuperSLSB;
import com.fundtech.core.security.Admin;
import backend.businessobject.proxies.interceptors.InterceptorSetType;
import backend.paymentprocess.approverefusecancel.businessobjects.BOApproveRefuseCancel;
import backend.paymentprocess.approverefusecancel.ejbinterfaces.ApproveRefuseCancelLocal;
import backend.paymentprocess.approverefusecancel.ejbinterfaces.ApproveRefuseCancel;

@Stateless
public class ApproveRefuseCancelBean extends SuperSLSB<ApproveRefuseCancel> implements ApproveRefuseCancelLocal, ApproveRefuseCancel{
	
	public ApproveRefuseCancelBean() { super(backend.paymentprocess.approverefusecancel.businessobjects.BOApproveRefuseCancel.class, InterceptorSetType.Complete) ; }//EOM
	
	
	/** 
	 * Handles 'Approve' or 'Refuse' action for a cancellation request that was performed for the passed MID
	 * which is in 'APPROVE_CANCEL' status; the cancellation could have been caused because of:
	 * 1) Either an incoming or an outgoing cancellation request for the passed MID.
	 * OR
	 * 2) Cancel action was initiated directly by the user by pressing the 'Cancel' button in the original payment.
	 */
	public com.fundtech.datacomponent.response.Feedback handleApproveRefuseCancel(final Admin admin, java.lang.String sMID ) throws java.lang.Throwable {
		return this.m_bo.handleApproveRefuseCancel(admin, sMID ) ;
	}//EOM

}//EOC