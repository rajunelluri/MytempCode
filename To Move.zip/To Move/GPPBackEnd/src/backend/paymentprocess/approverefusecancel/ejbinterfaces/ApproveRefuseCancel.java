package backend.paymentprocess.approverefusecancel.ejbinterfaces;

import javax.ejb.Remote;
import com.fundtech.core.security.Admin;

/**
 * Remote interface for ApproveRefuseCancel.
 */
@Remote
public interface ApproveRefuseCancel{

	public static final String REMOTE_JNDI_NAME="ejb/ApproveRefuseCancelBean";
	
	
	/** 
	 * Handles 'Approve' or 'Refuse' action for a cancellation request that was performed for the passed MID
	 * which is in 'APPROVE_CANCEL' status; the cancellation could have been caused because of:
	 * 1) Either an incoming or an outgoing cancellation request for the passed MID.
	 * OR
	 * 2) Cancel action was initiated directly by the user by pressing the 'Cancel' button in the original payment.
	 */
	public com.fundtech.datacomponent.response.Feedback handleApproveRefuseCancel(final Admin admin, java.lang.String sMID ) throws java.lang.Throwable ;

}//EOI  