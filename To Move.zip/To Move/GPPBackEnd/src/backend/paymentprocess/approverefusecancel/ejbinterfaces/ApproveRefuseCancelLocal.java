package backend.paymentprocess.approverefusecancel.ejbinterfaces;

import javax.ejb.Local;

/**
 * Local interface for ApproveRefuseCancel.
 */
@Local
public interface ApproveRefuseCancelLocal extends ApproveRefuseCancel{} ; 