/**
 * Mar 9, 2008
 * BOFeesCalculation.java
 * @author Vadim Koremblum
 */

package backend.paymentprocess.feescalculation.businessobjects;

import static backend.businessobject.BOProxies.m_internalRuleExecutionLogging;
import static com.fundtech.cache.infrastructure.regions.CacheKeys.SystParKey;
import static com.fundtech.cache.infrastructure.regions.CacheKeys.feeFormulaKey;
import static com.fundtech.cache.infrastructure.regions.CacheKeys.feeTypesKey;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.businessobject.BOBasic;
import backend.businessobject.BOProxies;
import backend.businessobject.proxies.LoadPDO;
import backend.core.module.MessageConstantsInterface;
import backend.paymentprocess.SubBatchProcessInterface;
import backend.paymentprocess.currencyconversion.businessobjects.BOCurrencyConversion;
import backend.paymentprocess.currencyconversion.common.CurrencyConversionConstants.ConversionType;
import backend.paymentprocess.currencyconversion.input.CurrencyConversionInputData;
import backend.paymentprocess.currencyconversion.output.CurrencyConversionOutputData;
import backend.paymentprocess.erroraudit.ErrorAuditUtils;
import backend.paymentprocess.feescalculation.common.ApplyFee;
import backend.paymentprocess.feescalculation.common.ChargeBearer;
import backend.paymentprocess.feescalculation.common.DeductFromType;
import backend.paymentprocess.feescalculation.common.FeesCalculationType;
import backend.paymentprocess.feescalculation.common.FixedFeeMethodType;
import backend.paymentprocess.feescalculation.common.MethodType;
import backend.paymentprocess.feescalculation.common.TierType;
import backend.paymentprocess.feescalculation.common.UnwindMethodType;
import backend.paymentprocess.feescalculation.exception.FeesCalculationException;
import backend.paymentprocess.feescalculation.output.BasicFeesCalculationData;
import backend.paymentprocess.feescalculation.output.FeesCalculationOutputData;
import backend.paymentprocess.memopost.dao.DAOMemoPost;
import backend.staticdata.profilehandler.message.dataaccess.dao.DAOFILE_SUMMARY;

import com.fundtech.annotations.DataSource;
import com.fundtech.annotations.Expose;
import com.fundtech.annotations.Wrap;
import com.fundtech.cache.entities.Accounts;
import com.fundtech.cache.entities.BatchSubset;
import com.fundtech.cache.entities.Customrs;
import com.fundtech.cache.entities.FeeFormula;
import com.fundtech.cache.entities.FeeFormulaTiers;
import com.fundtech.cache.entities.FeeTypes;
import com.fundtech.cache.entities.Mop;
import com.fundtech.cache.entities.MsgFees;
import com.fundtech.cache.entities.MsgTypes;
import com.fundtech.cache.entities.RuleResult;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.cache.syspar.SystemParametersInterface;
import com.fundtech.core.paymentprocess.data.MemoPostEntry;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.core.paymentprocess.errorhandling.ErrorSeverity;
import com.fundtech.core.paymentprocess.errorhandling.ProcessError;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.errors.ProcessErrorConstants;
import com.fundtech.spring.SpringApplicationContext;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalUtils;


@Wrap(datasources={@DataSource(datasourceJndiKey="active")}) 

public class BOFeesCalculation extends BOBasic
{

	private static final Logger logger = LoggerFactory.getLogger(BOFeesCalculation.class);
    private static final String BYPASS_ACTION_ID = "BYPASS";
    private static int MANUAL_FEE = 1;
    private static int CDB_FEE = 2;
    private final DAOMemoPost daoMemoPost = (DAOMemoPost) SpringApplicationContext.getBean("DAOMemoPost");
    
    /**
     * Wrapper method to keep backward compatibility. 
     * @param feesCalculationType - indicates debit/credit/agent
     * @param sMID - unique MID, (=Message ID) refers to the original ISO payment data as it was kept in our database
     * @return FeesCalculationOutputData - output for the flow
     *
     */
    @Expose
    @LoadPDO
    public FeesCalculationOutputData performFeesCalculation(final String sMID) 
                                            throws FeesCalculationException{
    	return performFeesCalculation(sMID, false);
    }
    
    

    /**
     * This method will be used when we require debit/credit fees calculation during the payment flow.
     * @param feesCalculationType - indicates debit/credit/agent
     * @param sMID - unique MID, (=Message ID) refers to the original ISO payment data as it was kept in our database
     * @return FeesCalculationOutputData - output for the flow
     *
     */
    @Expose
    @LoadPDO
    public FeesCalculationOutputData performFeesCalculation(final String sMID,boolean isDummyCalculation) 
                                            throws FeesCalculationException{

    	FeesCalculationOutputData fcOutputData=new FeesCalculationOutputData();
        PDO pdo = PaymentDataFactory.load(sMID);
        String feeCalcType = pdo.getString(PDOConstantFieldsInterface.D_FEE_CALCULATION_TYPE);
        FeesCalculationType feesCalculationType  = null;
        updateMsgFeesPostedStatus(pdo);
        if (!GlobalUtils.isNullOrEmpty(feeCalcType))
        {
        	
            feesCalculationType = FeesCalculationType.valueOf(feeCalcType.toUpperCase());
            
            
//            reset the D_MT191AUTOGEN derived logical field
        	if (feesCalculationType  == FeesCalculationType.DEBIT)
        		pdo.set(PDOConstantFieldsInterface.D_MT191AUTOGEN, false);
        	
                        
            performFeesCalculation(pdo, feesCalculationType,fcOutputData,isDummyCalculation);
            if (fcOutputData.getFeedback().isSuccessful())
            {
            	fcOutputData.reset();
            	adjustMsgFees(sMID, fcOutputData);
            }
                       
        }else
        {
//        	reset the D_MT191AUTOGEN derived logical field
        	pdo.set(PDOConstantFieldsInterface.D_MT191AUTOGEN, false);
            performFeesCalculation(pdo, FeesCalculationType.DEBIT,fcOutputData,isDummyCalculation);
            //GlobalConstants.listForSysout.add("FC: 	performFeesCalculation Debit = "+((System.nanoTime() - time)/1000000));
            
            if (fcOutputData.getFeedback().isSuccessful())
            {
                fcOutputData.reset();
                performFeesCalculation(pdo, FeesCalculationType.CREDIT,fcOutputData,isDummyCalculation);
            }
            //GlobalConstants.listForSysout.add("FC: 	performFeesCalculation Credit = "+((System.nanoTime() - time)/1000000));
            if (fcOutputData.getFeedback().isSuccessful())
            {
                fcOutputData.reset();
                performFeesCalculation(pdo, FeesCalculationType.AGENT,fcOutputData,isDummyCalculation);
            }
            //GlobalConstants.listForSysout.add("FC: 	performFeesCalculation Agent = "+((System.nanoTime() - time)/1000000));
            if (fcOutputData.getFeedback().isSuccessful())
            {
            	fcOutputData.reset();
            	adjustMsgFees(sMID, fcOutputData);
            }
            //GlobalConstants.listForSysout.add("FC: 	adjustMsgFees = "+((System.nanoTime() - time)/1000000));
        }
        
        
//        if fee account not found, then fee calculation should complete and return failure.
        if (fcOutputData.getFeedback().isSuccessful() && fcOutputData.isFeeAccountNotFoundFailure())
        {
            ProcessError pError=new ProcessError(ProcessErrorConstants.FeeAccountNotFound);
            configureErrorFeedback(pError.getErrorCode(),pError.getDescription(),fcOutputData.getFeedback());
            ErrorAuditUtils.setErrors(pError,pdo.getIsHistory());
        	
        }
        
        
        return fcOutputData;
    }

    private void updateMsgFeesPostedStatus(PDO pdo)
    {
    	String sMID=pdo.getMID();
        List<MsgFees> listMsgFees=pdo.isNew() ? pdo.getListMSG_FEES() : pdo.getNSetListMSG_FEES();
        if (null!=listMsgFees)
        {
            List<MemoPostEntry> memoPosts = daoMemoPost.getMemoPosts(sMID, pdo.getIsHistory());
            if (null!=memoPosts)
            {
                String str;
                Set<String> postedEntryIDs=new HashSet<String>();
                for(MemoPostEntry mpe:memoPosts)
                {
                    str=mpe.getPostingStatus();
                    if (null!=str && null!=mpe.getUId() && (str.equals(MessageConstantsInterface.MONITOR_FLAG_SUCCESS) || str.equals(MessageConstantsInterface.MONITOR_FLAG_WAITING)))
                    {
                        postedEntryIDs.add(mpe.getUId());
                    }
                }
                for(MsgFees mf:listMsgFees)
                {
                    str=mf.getFeePostingEntryId();
                    if (null!=str)
                    {
                        mf.setIsPosted(postedEntryIDs.contains(str));
                    }
                }
            }
        }
    }
    
//    public void setFeeAmountDerivedFields()
    
    
    private void performFeesCalculation(PDO pdo, FeesCalculationType feesCalculationType, FeesCalculationOutputData fcOutputData,boolean isDummyCalculation)throws FeesCalculationException
    {
      //  //BackendTracer GlobalTracer=GlobalTracer;
/*
        ProcessError pError=new ProcessError(ProcessErrorConstants.AppendManualFeeTypeExists,new Object[] {"YONIG1","YONIG2"});
        pError.setSeverity(ErrorSeverity.critical);
        configureErrorFeedback(pError.getErrorCode(),pError.getDescription(),fcOutputData.getFeedback());
        ErrorAuditUtils.setErrors(pError);
        
*/        
        logger.debug("FC - Start Perform Fees Calculation : Fees Calculation Type={} MID={}" , feesCalculationType.name(), pdo.getMID());
        long time=System.nanoTime();
        BasicFeesCalculationData basicFeesCalculationData=getBasicFeeCalculationData(feesCalculationType,pdo);
        //GlobalConstants.listForSysout.add("FC: 		getBasicFeeCalculationData = "+((System.nanoTime() - time)/1000000));
        if (!basicFeesCalculationData.getSkipFeeCalculation())
        {
        	time=System.nanoTime();
            executeFeesCalculation(feesCalculationType,pdo,fcOutputData,basicFeesCalculationData,isDummyCalculation);            
            //GlobalConstants.listForSysout.add("FC: 		executeFeesCalculation = "+((System.nanoTime() - time)/1000000));
            if (! fcOutputData.getFeedback().isSuccessful()) {
            	return;
            }
        }
        logger.debug("FC - Finished Perform Fees Calculation - "+((System.currentTimeMillis()-time)/1000000)+"ms");
        
        pdo.set(PDOConstantFieldsInterface.MF_FEE_PROC_STS,MessageConstantsInterface.MONITOR_FLAG_PROCESSED);
    }
                                            
                                            
    
    /**
     * This method executes the main steps in the actual fees calculation process 
     * @param feesCalculationType
     * @param minf
     * @param fcOutputData
     * @param basicFeeCalcData 
     *
     */
    private void executeFeesCalculation(FeesCalculationType feesCalculationType, PDO pdo
                    ,FeesCalculationOutputData fcOutputData,BasicFeesCalculationData basicFeeCalcData,boolean isDummyCalculation) throws FeesCalculationException 
    {
       // //BackendTracer GlobalTracer=GlobalTracer;
        
        logger.debug("FC - Execute fees calculation");
        
        List<RuleResult> listRequiredFeeTypesUIDs=deriveRequiredFeeTypesUIDs(pdo,feesCalculationType, basicFeeCalcData);
        
        List<MsgFees> persistentOtherPayingPartyList = new ArrayList<MsgFees>();
        List<FeeTypeUIDMsgFees> listRequestedManual=new ArrayList<FeeTypeUIDMsgFees>();
        applyCalculationModeRestrictions(pdo,feesCalculationType,listRequestedManual,persistentOtherPayingPartyList,listRequiredFeeTypesUIDs,fcOutputData.getFeedback());
        if (fcOutputData.getFeedback().isSuccessful())
        {
            List<FeeTypeUIDMsgFees> listRequiredMissingNonManual=createMissingFeeTypesList(listRequiredFeeTypesUIDs,listRequestedManual,pdo.getIsHistory());
            
            List<FeeTypeUIDMsgFees> listRequiredFeeTypes=new ArrayList<FeeTypeUIDMsgFees>();
            listRequiredFeeTypes.addAll(listRequestedManual); //first in line are the MANUAL FeeTypesUIDS, then CDB FeeTypesUIDS
            listRequiredFeeTypes.addAll(listRequiredMissingNonManual); //and last in list are the required and missing FeeTypesUIDS
            
            iterateOnFeeTypesFound(listRequiredFeeTypes,feesCalculationType,pdo,fcOutputData,basicFeeCalcData,persistentOtherPayingPartyList,isDummyCalculation);
        }
    }
    
    
    
    
    private void iterateOnFeeTypesFound(List<FeeTypeUIDMsgFees> listRequiredFeeTypes,FeesCalculationType feesCalculationType
                                         ,PDO pdo,FeesCalculationOutputData fcOutputData
                                         , BasicFeesCalculationData basicFeeCalcData, List<MsgFees> persistentMsgFeesList,boolean isDummyCalculation) throws FeesCalculationException
    {
        List<MsgFees> listMsgFees=new ArrayList<MsgFees>();
        FeeTypeUIDMsgFees feeTypeUIDMsgFees;
        FeeFormula feeFormulaRecord;
        FeeTypes feeType = null;
        ApplyFee applyFeeFlag;
        Accounts accountPandL;
        MsgFees msgFee;
        double dFeeAmount;
        String sBaseOfficeCurrency=CacheKeys.banksKey.getSingle(pdo.getString(PDOConstantFieldsInterface.P_OFFICE)).getCurrency();
        Map<String, Double> mapCurrencyConversion=new HashMap<String, Double>();
        
        
        //boolean flags for Max and Floor validations
        Double[] arrPrincipalAmount=new Double[]{null};
        int iSize=listRequiredFeeTypes.size();
        Accounts feesAccount=new Accounts();
       // //BackendTracer GlobalTracer=GlobalTracer;
        
        Set<String> msgTypesSet = new HashSet<String>();
        logger.info("FC - Starting iteration on fee types found");
//        long time = System.nanoTime();
        Feedback feedback = fcOutputData.getFeedback();
        for (int i=0;i<iSize && feedback.isSuccessful();i++)
        {//reset principal amount before each iteration.
            arrPrincipalAmount[0]=null;
            // listRequiredFeeTypes "linked list" is made in the following order:
            // 1) First in the list: all the requested Manual, followed by all requested CDB. FeeTypeUIDMsgFees has full msg_fees (from DB)
            // 2) Afterwards we have required missing FeeTypeUIDMsgFees with empty msg_fees
            feeTypeUIDMsgFees=listRequiredFeeTypes.get(i);
//            verify the the following fee type not executed yet.
            
//            long t = System.nanoTime();
            //since listNeededPayingPartyFeeTypesUIDs are ordered, if we already processed a manual fees with same FeeTypeUID, we will skip and not add another record
            if (!msgTypesSet.contains(feeTypeUIDMsgFees.getFeeTypeUid()) && feeTypesKey.getSingle(feeTypeUIDMsgFees.getFeeTypeUid()) != null)
            {
            	//GlobalConstants.listForSysout.add("FC:					condition = "+((System.nanoTime() - t)/1000000));
            	msgTypesSet.add(feeTypeUIDMsgFees.getFeeTypeUid());
            	
//            	 t = System.nanoTime();
	            feeType= feeTypesKey.getSingle(feeTypeUIDMsgFees.getFeeTypeUid());
	            //GlobalConstants.listForSysout.add("FC:					feeTypesKey = "+((System.nanoTime() - t)/1000000));
	            
	            logger.debug("FC - Iteration on fee type "+feeTypeUIDMsgFees.getFeeTypeUid());
	            msgFee=feeTypeUIDMsgFees.getMsgFee();
	            if (msgFee.getIsPosted())
	            {
	            	continue;
	            }
	            //check if non manual method
//	            t = System.nanoTime();
	            feeFormulaRecord = getFeeFormula(pdo, msgFee, feeType, basicFeeCalcData);
	            //There is a possibility that after above steps, we won't find a fee formula for a specific fee type; 
	            //this means that the customer won't be charged for this fee type.
//	            t = System.nanoTime();
	            if (feeFormulaRecord!=null)
	            {
	                feeFormulaRecord = performDeductFromChanges(pdo, feeFormulaRecord,feesCalculationType, fcOutputData, feesAccount, basicFeeCalcData.getChargeBearer());
	                //GlobalConstants.listForSysout.add("FC:					performDeductFromChanges = "+((System.nanoTime() - t)/1000000));
	                
	                //if deduct from account and fee calculation type credit and no fee account and processing syst par enables to continue
	                //set fee formula deduct from payment
	                
//	                t = System.nanoTime();
	                logger.debug("FC - Fee Formula found " + feeFormulaRecord.getUidFeeFormula());
	                
	                applyFeeFlag=getApplyFeeFlag(feesCalculationType,pdo,feeFormulaRecord,msgFee.getId().getApply());
	                //GlobalConstants.listForSysout.add("FC:					getApplyFeeFlag = "+((System.nanoTime() - t)/1000000));
	                
//	                t = System.nanoTime();
	                accountPandL=loadPandLaccount(feeFormulaRecord,feeTypeUIDMsgFees.getFeeTypeUid(),pdo,applyFeeFlag,fcOutputData, feesCalculationType);
	                dFeeAmount = 0;
	                //GlobalConstants.listForSysout.add("FC:					loadPandLaccount = "+((System.nanoTime() - t)/1000000));
	                
//	                t = System.nanoTime();
//	                fee amount should remain 0 if apply fee = 'WAIVE'
	                if (applyFeeFlag != ApplyFee.WAIVE)
	                {
		                dFeeAmount=calculateFeeAccordingToFeeFormula(msgFee.getFeeAmount(),feeFormulaRecord,feesCalculationType,pdo
		                                                                ,sBaseOfficeCurrency,arrPrincipalAmount,mapCurrencyConversion
		                                                                ,fcOutputData); 
		                //GlobalConstants.listForSysout.add("FC:					calculateFeeAccordingToFeeFormula = "+((System.nanoTime() - t)/1000000));
		                
//		                t = System.nanoTime();
		                if (feedback.isSuccessful()) 
		                {
		                	dFeeAmount=getMinMaxValidationForFeeFormula(dFeeAmount,feeFormulaRecord);
		                	//GlobalConstants.listForSysout.add("FC:					getMinMaxValidationForFeeFormula = "+((System.nanoTime() - t)/1000000));
		                }
	                }
//	                t = System.nanoTime();
	                if (feedback.isSuccessful())
	                {
		                setOriginalFeeAmount(dFeeAmount,feeTypeUIDMsgFees,pdo.getIsHistory());
		                //GlobalConstants.listForSysout.add("FC:					setOriginalFeeAmountToMsgFeesTable = "+((System.nanoTime() - t)/1000000));
		                
//		                t = System.nanoTime();
		                setAdditionalMessageFeesFields(dFeeAmount,feeTypeUIDMsgFees,feeFormulaRecord,pdo,feesCalculationType,accountPandL
		                                                , fcOutputData,sBaseOfficeCurrency,mapCurrencyConversion,feesAccount, basicFeeCalcData.getChargeBearer());
		                //GlobalConstants.listForSysout.add("FC:					setAdditionalMessageFeesFields = "+((System.nanoTime() - t)/1000000));
		                
//		                t = System.nanoTime();
		                if (feedback.isSuccessful()) 
		                {
			                buildMsgFeesRecoredForCurrentHandledFeeType(msgFee,feeFormulaRecord,pdo,dFeeAmount,accountPandL,feeTypeUIDMsgFees.getManualFee()
			                                                            ,feeTypeUIDMsgFees.getFeeTypeUid(),basicFeeCalcData);
			                msgFee.setDeductFrom(feeFormulaRecord.getDeductFrom());
			                listMsgFees.add(msgFee);
			                //GlobalConstants.listForSysout.add("FC:					buildMsgFeesRecoredForCurrentHandledFeeType = "+((System.nanoTime() - t)/1000000));
		                }
	                }
	            }
	            else
	            {
	                logger.info("FC - no fee formula for fee type "+feeTypeUIDMsgFees.getFeeTypeUid());
	            }
            }
        }
        
        //GlobalConstants.listForSysout.add("FC:				iteration = "+((System.nanoTime() - time)/1000000));
        logger.debug("FC - Finished iteration on fee types the status is "+(fcOutputData.getFeedback().isSuccessful()
                ? " successful " : " unsuccessful"));
        if (fcOutputData.getFeedback().isSuccessful())
        {
        	System.nanoTime();
//            checkMaxAndFloorAndUpdateLogicalFields(pdo,listMsgFees, basicFeeCalcData, feesCalculationType, mapCurrencyConversion, fcOutputData);            
        	persistentMsgFeesList.addAll(listMsgFees);
            if (!isDummyCalculation) {
				setPDOMsgFees(persistentMsgFeesList, pdo);
			}else{
				addDummyFees(persistentMsgFeesList,pdo);
			}
			if (feesAccount.getAccNo()!=null&&feesAccount.getAccNo().length()>0
                    &&feesAccount.getCurrency()!=null&&feesAccount.getCurrency().length()>0
                    &&feesAccount.getOffice()!=null&&feesAccount.getOffice().length()>0)
            {
                logger.debug("FC - Set fee account");
                fcOutputData.setFeeAccountCurrency(feesAccount.getCurrency());
                fcOutputData.setFeeAccountNum(feesAccount.getAccNo());
                fcOutputData.setFeeAccountOffice(feesAccount.getOffice());
                if (feesCalculationType.equals(FeesCalculationType.CREDIT))
                {
                    pdo.set(PDOConstantFieldsInterface.P_CDT_FEE_ACCT_NB,feesAccount.getAccNo());
                    pdo.set(PDOConstantFieldsInterface.P_CDT_FEE_ACCT_CCY,feesAccount.getCurrency());
                    pdo.set(PDOConstantFieldsInterface.P_CDT_FEE_ACCT_OFFICE,feesAccount.getOffice());
                    pdo.set(PDOConstantFieldsInterface.D_CDT_FEE_TYPE_GROUP, feeType == null ? null : feeType.getFeeTypeGroup());
                }else //Debit or Agent. 
                {
                    pdo.set(PDOConstantFieldsInterface.P_DBT_FEE_ACCT_NB,feesAccount.getAccNo());
                    pdo.set(PDOConstantFieldsInterface.P_DBT_FEE_ACCT_CCY,feesAccount.getCurrency());
                    pdo.set(PDOConstantFieldsInterface.P_DBT_FEE_ACCT_OFFICE,feesAccount.getOffice());
                    pdo.set(PDOConstantFieldsInterface.D_DBT_FEE_TYPE_GROUP, feeType == null ? null : feeType.getFeeTypeGroup());
                }
            }
            
            
            //pdo.cacheMemberState(PDOConstantFieldsInterface.M_MSG_FEES_LINE, null, PaymentFieldInterface.ModificationType.Auto);
            
            if (listMsgFees.size() > 0)
            	pdo.setAdditionalData(PDOConstantFieldsInterface.M_MSG_FEES_LINE, PDOConstantFieldsInterface.M_MSG_FEES_LINE);
            
            //GlobalConstants.listForSysout.add("FC:				finalize = "+((System.nanoTime() - t)/1000000));
        }
    }
    
    
    private void addDummyFees(List<MsgFees> otherPayingPartyList, PDO pdo) {
		double feeAmount=0;
    	for (MsgFees msgFees : otherPayingPartyList) {
			feeAmount+=msgFees.getFeeAmount();
		}
    	pdo.set(PDOConstantFieldsInterface.D_DUMMY_DBT_FEE_POST_AMT,feeAmount);
	}



	private FeeFormula getFeeFormula(PDO pdo, MsgFees msgFee, FeeTypes feeType, BasicFeesCalculationData basicFeeCalcData)
    {
       // //BackendTracer GlobalTracer=GlobalTracer;
        

    	FeeFormula feeFormulaRecord = null;
    	if (msgFee != null && msgFee.getManualFee() != null && msgFee.getManualFee() == CDB_FEE)
    	{
            logger.debug("FC - CDB Msg fee, create dummy fee formula");
            feeFormulaRecord=createDummyFeeFormula(pdo, msgFee);
    	}
    	else if (msgFee==null||msgFee.getId() ==null || msgFee.getId().getFeeFormulaUid()==null||msgFee.getId().getFeeFormulaUid().length()==0)
        {
            logger.debug("FC - Deriving fee formula by executing fee formula rule");
            feeFormulaRecord=getFeeFormulaByExecutingFeeFormulaRule(feeType,basicFeeCalcData.getCustomer(),pdo);
        }
        else
        {//retrieve fee formula according to MSG_FEES table (Manual)
//        	t = System.nanoTime();
            logger.debug("FC - Deriving fee formula from MSG_FEES");
            feeFormulaRecord= feeFormulaKey.getSingle(msgFee.getId().getFeeFormulaUid()) ; 
        }
        
        return feeFormulaRecord;

    }
    
    
    private FeeFormula createDummyFeeFormula(PDO pdo, MsgFees msgFee)
    {
    	FeeFormula feeFormula = new FeeFormula();
    	String office = pdo.getString(PDOConstantFieldsInterface.P_OFFICE);
    	String feeTypeName = msgFee.getFeeTypeUid().split(GlobalConstants.REGEX_POWER_SIGN)[1];
    	
    	feeFormula.setFeeFormulaName("CDB");
    	feeFormula.setFixedFee(msgFee.getFeeAmount());
    	feeFormula.setApplyFee(msgFee.getApply());
    	feeFormula.setOffice(office);
    	feeFormula.setDepartment(pdo.getString(PDOConstantFieldsInterface.P_DEPARTMENT));
    	feeFormula.setRecStatus(GlobalConstants.REC_STATUS_ACTIVE);
    	feeFormula.setMethod(MethodType.Regular.name());
    	feeFormula.setFeeCurrency(msgFee.getFeeCurrency());
    	feeFormula.setDeductFrom(msgFee.getDeductFrom());
    	feeFormula.setFixedFeeMethod(FixedFeeMethodType.M.name());
    	feeFormula.setFeeFormulaDescription("CDB");
    	feeFormula.setUidFeeFormula(office + GlobalConstants.POWER_SIGN + "CDB");
    	feeFormula.setFeeTypeName(feeTypeName);
    	feeFormula.setPercentageFee(0d);
    	feeFormula.setFeesSuspAccNo(msgFee.getFeePnlAccNo());
    	feeFormula.setFeesSuspAccCcy(msgFee.getFeePnlAccountCurrency());
    	feeFormula.setFeesSuspAccOffice(msgFee.getFeePnlAccOffice());
    	
    	return feeFormula;
    }
    
    
    private FeeFormula performDeductFromChanges(PDO pdo, FeeFormula feeFormulaRecord, FeesCalculationType feesCalculationType, FeesCalculationOutputData fcOutputData
    		, Accounts feesAccount, ChargeBearer chrgBr) throws FeesCalculationException
    {
    //	//BackendTracer GlobalTracer=GlobalTracer;
        if (DeductFromType.A.name().equals(feeFormulaRecord.getDeductFrom()) 
                && feesCalculationType==FeesCalculationType.CREDIT)
        {
            if (!setFeesAccount(feesCalculationType,pdo,fcOutputData,feesAccount, chrgBr)
                    && fcOutputData.getFeedback().isSuccessful() && !fcOutputData.isFeeAccountNotFoundFailure())
            {
//            	clone the record because this modification should not effect other processes in the system
            	feeFormulaRecord = feeFormulaRecord.clone();
            	
                feeFormulaRecord.setDeductFrom(DeductFromType.P.name());
                logger.debug("FC - Deduct from account, payment type is credit, no fee account " +
                        "and processing syst par enables to continue - then set deduct from payment");
            }
        }
//         should check at the beginning of the pricing logic if debit fees and deduct from account and OX 71G exists and apply fee = NOW then change it to deduct from payment since the incoming
//        agent fees are included with the original payment amount (OX_STLLM_AMT)
//        else if( DeductFromType.A.name().equals(feeFormulaRecord.getDeductFrom()) 
//                && feesCalculationType==FeesCalculationType.DEBIT && pdo.getDecimal(PDOConstantFieldsInterface.OX_RCVR_CHRGS_INF,1,PDOConstantFieldsInterface.OX_RCVR_CHRGS_INF_AMT) != null 
//                && feeFormulaRecord.getApplyFee().equals(ApplyFee.NOW.name()))
        else if( DeductFromType.A.name().equals(feeFormulaRecord.getDeductFrom()) 
                && feesCalculationType==FeesCalculationType.DEBIT && getReciverCharges(pdo) != null 
                && feeFormulaRecord.getApplyFee().equals(ApplyFee.NOW.name()))
        {
//        	clone the record because this modification should not effect other processes in the system
        	feeFormulaRecord = feeFormulaRecord.clone();
        	
        	feeFormulaRecord.setDeductFrom(DeductFromType.P.name());
        	
        }else if (feesCalculationType==FeesCalculationType.AGENT
                && DeductFromType.P.name().equals(feeFormulaRecord.getDeductFrom()))
        {
//        	in this case the record should not be cloned because it is wrong setup.
            feeFormulaRecord.setDeductFrom(DeductFromType.A.name());
            feeFormulaRecord.setApplyFee(ApplyFee.NOW.name());
        }
    	
        return feeFormulaRecord;
    }
    
    
    
    private void setPDOMsgFees(List<MsgFees> listMsgFees, PDO pdo)
    {
      //  //BackendTracer GlobalTracer=GlobalTracer;
        
        logger.debug("FC - Set message fees list to PDO");
        pdo.setListMSG_FEES(listMsgFees);
    }
    /**
     * This method maps all data from previous steps for each iteration into a single record in the MSG_FEES table
     * @param msgFee
     * @param feeFormula
     * @param minf
     * @param dFeeAmount
     * @param accountPandL
     * @param bIsManualFee
     * @param sFeeTypeUID
     * @param basicFeeCalcData void
     *
     */
    private void buildMsgFeesRecoredForCurrentHandledFeeType(MsgFees msgFee,FeeFormula feeFormula,PDO pdo,double dFeeAmount
                                                             ,Accounts accountPandL,int manualfee,String sFeeTypeUID
                                                             ,BasicFeesCalculationData basicFeeCalcData)
    {
     //   //BackendTracer GlobalTracer=GlobalTracer;
        
        logger.debug("FC - Build MSG_FEES record for current handled fee type");
        long lTime=System.currentTimeMillis();
        msgFee.getId().setMid(pdo.getString(PDOConstantFieldsInterface.P_MID));
        msgFee.getId().setApply(feeFormula.getApplyFee());
        msgFee.setFeeCurrency(feeFormula.getFeeCurrency());
        msgFee.setFeeAmount(dFeeAmount);
        msgFee.setFeeMonitor(null);
        msgFee.setDeductFrom(DeductFromType.A.name().equals(feeFormula.getDeductFrom())?0+"":1+"");
        msgFee.setManualFee(manualfee);
        //FEE_ACC_AMOUNT calculated in setAdditionalMessageFeesFields method
        msgFee.getId().setPayingParty(feeTypesKey.getSingle(sFeeTypeUID).getPayingParty());
        msgFee.getId().setFeeFormulaUid(feeFormula.getUidFeeFormula());
        msgFee.getId().setFeeTypeUid(sFeeTypeUID);
        //msgFee.setFeePostingEntryId("YONIGFEE1");
        //msgFee.setPnlPostingEntryId("YONIGPNL1");
        //ORIG_FEE_AMOUNT calculated in setOriginalFeeAmountToMsgFeesTable
        logger.debug("FC - Finished Build MSG_FEES record for current handled fee type - "+(System.currentTimeMillis()-lTime)+"ms");
    }
    
    
    
    /**
     * Method which sets fee amount values in varios currencies 
     * @param dFeeAmount
     * @param feeTypeUIDMsgFees
     * @param feeFormula
     * @param minf
     * @param feeCalcType
     * @param pAndLaccount
     * @param fcOutputData
     *
     */
    private void  setAdditionalMessageFeesFields(double dFeeAmount, FeeTypeUIDMsgFees feeTypeUIDMsgFees
            , FeeFormula feeFormula, PDO pdo,FeesCalculationType feeCalcType
            ,Accounts pAndLaccount, FeesCalculationOutputData fcOutputData,String sBaseOfficeCurrency
            ,Map<String,Double>mapCurrencyConversion,Accounts feesAccount, ChargeBearer chrgBr) throws FeesCalculationException
    {
    	    		   
     //   //BackendTracer GlobalTracer=GlobalTracer;
        
        logger.debug("FC - Set additional MSG_FEES fields");
        long lTime=System.currentTimeMillis();
        //convert to base currency and set fee base amount
        MsgFees msgFees=feeTypeUIDMsgFees.getMsgFee();
        String toCurrency=null;
        double amount = 0;
        Double cdbPnlAmount = null;
        String cdbPnlCcy = "";
        
        Feedback feedback = new Feedback();
        
//        check if CDB msg fee has PnL account amount
        if (msgFees.getManualFee() != null && msgFees.getManualFee() == CDB_FEE && msgFees.getFeePnlAmount() != null)
        {
        	cdbPnlAmount = msgFees.getFeePnlAmount();
        	cdbPnlCcy = msgFees.getFeePnlAccountCurrency();
        	
        	logger.debug("FC - CDB Msg Fee, CDB PnL amount ={} {}", cdbPnlAmount,cdbPnlCcy);
        }	
        if (DeductFromType.P.name().equals(feeFormula.getDeductFrom()))
        {
            logger.debug("FC - Fee account exist");
            toCurrency=pdo.getString(PDOConstantFieldsInterface.P_CDT_ACCT_CCY);
            
//            if P_CDT_ACCT_CCY equals CDB PnL account currency, then use CDB PnL account amount
            
            if (toCurrency.equals(cdbPnlCcy) && cdbPnlAmount != null)
            {
            	amount = cdbPnlAmount;
            	
            	logger.debug("FC - CDB Msg Fee, P_CDT_ACCT_CCY = CDB PnL ccy, using CDB PnL amount");
            }else
            {
//            long time = System.nanoTime();
	            amount = convertCurrency(feeFormula.getFeeCurrency()
	                    ,toCurrency,dFeeAmount,feeCalcType,pdo,true,sBaseOfficeCurrency,mapCurrencyConversion, feedback);
            //GlobalConstants.listForSysout.add("FC: 						convertCurrency = "+((System.nanoTime() - time)/1000000));
            }
            fcOutputData.setFeedback(feedback);
            
            if (feedback.isSuccessful()) 
            {
//            'fee amount in payment currency' also calculated in case of deduct from ACCOUNT and calculation type 'AGENT' (few lines down)
//            	time = System.nanoTime();
	            amount = GlobalUtils.adjustPrecision(amount, toCurrency);
	            //GlobalConstants.listForSysout.add("FC: 						adjustPrecision = "+((System.nanoTime() - time)/1000000));
	            msgFees.setFeeAmountInPmtCcy(amount);
            }
            

        }
        else //Deduct From Account
        {
            logger.debug("FC - Get fee account");
            if (setFeesAccount(feeCalcType,pdo,fcOutputData,feesAccount,chrgBr))
            {
                toCurrency=feesAccount.getCurrency();
            }
            else
            {
                
                if (feeCalcType.equals(FeesCalculationType.DEBIT) || feeCalcType.equals(FeesCalculationType.AGENT))
                    toCurrency=pdo.getString(PDOConstantFieldsInterface.P_DBT_ACCT_CCY);
                if (feeCalcType.equals(FeesCalculationType.CREDIT))
                    toCurrency=pdo.getString(PDOConstantFieldsInterface.P_CDT_ACCT_CCY);
            }
            double feeAccAmt = 0;
            
//            if account ccy equals CDB PnL account currency, then use CDB PnL account amount
            if (null != toCurrency && toCurrency.equals(cdbPnlCcy) && cdbPnlAmount != null)
            {
            	feeAccAmt = cdbPnlAmount;
            	logger.debug("FC - CDB Msg Fee, account ccy = CDB PnL ccy, using CDB PnL amount as fee account amount");
            }else
            {

            	feeAccAmt = convertCurrency(feeFormula.getFeeCurrency()
            			,toCurrency,dFeeAmount,feeCalcType,pdo,true,sBaseOfficeCurrency,mapCurrencyConversion, feedback);
            }
            fcOutputData.setFeedback(feedback);                
            if (fcOutputData.getFeedback().isSuccessful()) 
            {
                                        
	            feeAccAmt = GlobalUtils.adjustPrecision(feeAccAmt, toCurrency);
	            
	            msgFees.setFeeAccAmount(feeAccAmt);       
	            
	            
	            
	            if (feeCalcType.equals(FeesCalculationType.AGENT))
	            {                	
	            	amount = convertCurrency(feeFormula.getFeeCurrency()
	                  ,pdo.getString(PDOConstantFieldsInterface.P_CDT_ACCT_CCY),dFeeAmount,feeCalcType,pdo,true,sBaseOfficeCurrency,mapCurrencyConversion, feedback);
	              
	               fcOutputData.setFeedback(feedback);                   
	               if (fcOutputData.getFeedback().isSuccessful())
	               {
	            	   msgFees.setFeeAmountInPmtCcy(amount);
	               }
	           }
            }
        }
        if (fcOutputData.getFeedback().isSuccessful())
        {
	        logger.debug("FC - convert to "+toCurrency+" currency");
	        //convert to Fee/Debit/Credit account currency and update fee account amount
	        
	        
//	        if base ccy equals CDB PnL account currency, then use CDB PnL account amount
	        if (sBaseOfficeCurrency.equals(cdbPnlCcy) && cdbPnlAmount != null)
            {
            	amount = cdbPnlAmount;
            	logger.debug("FC - CDB Msg Fee, base ccy = CDB PnL ccy, using CDB PnL amount as base amount");
            }else
            {
		        amount = convertCurrency(feeFormula.getFeeCurrency()
		                ,sBaseOfficeCurrency,dFeeAmount,feeCalcType,pdo,false,sBaseOfficeCurrency,mapCurrencyConversion, feedback);
            }
	        //GlobalConstants.listForSysout.add("FC: 						convertCurrency = "+((System.nanoTime() - time)/1000000));
	        
	        fcOutputData.setFeedback(feedback);           
	        if (fcOutputData.getFeedback().isSuccessful()) 
	        {
		        msgFees.setFeeBaseAmount(amount);
		        //convert to P&L account currency and set fee P&L account amount in case its found
		        
//		        if it is CDB msg fee and PnL account and amount is set, the skip this step.
		        if (cdbPnlAmount == null)
		        {
			        if (pAndLaccount!=null)
			        {
			            logger.info("FC - P and L account exists");
			            
	//		            time = System.nanoTime();
			            amount = convertCurrency(feeFormula.getFeeCurrency()
			                    ,pAndLaccount.getCurrency(),dFeeAmount,feeCalcType,pdo,false,sBaseOfficeCurrency,mapCurrencyConversion, feedback);
			            //GlobalConstants.listForSysout.add("FC: 						convertCurrency = "+((System.nanoTime() - time)/1000000));
			            
			            fcOutputData.setFeedback(feedback);            
			            if (fcOutputData.getFeedback().isSuccessful()) 
			            {
			                        
				            msgFees.setFeePnlAmount(amount);
				            
				            msgFees.setFeePnlAccountCurrency(pAndLaccount.getCurrency());
				            msgFees.setFeePnlAccNo(pAndLaccount.getAccNo());
				            msgFees.setFeePnlAccOffice(pAndLaccount.getOffice());
				            feeTypeUIDMsgFees.setPnLAccountCurrency(pAndLaccount.getCurrency());
			            }
			        }else
			            logger.debug("FC - P and L account doesn't exist");
		        }else
		        {
		        	logger.debug("FC - CDB Msg Fee, PnL account and amount alredy have been set");
		        }
		        
		        feeTypeUIDMsgFees.setFeeAccountOrPaymentCurrency(toCurrency);
		        msgFees.setFeeAccOrPmtCcy(toCurrency);
		        logger.debug("FC - Finished Set additional MSG_FEES fields - "+(System.currentTimeMillis()-lTime)+"ms");
	        }
        }
    }
    
    
    private void setFeeAccOrPmtCcy(PDO pdo, MsgFees msgFee)
    {
    	String currency = null;
    	
    	if (msgFee.getDeductFrom().equals(DeductFromType.P.name()))//deduct from payment
    	{
    		currency = pdo.getString(PDOConstantFieldsInterface.P_CDT_ACCT_CCY);
    	}else // deduct from account
    	{
    		if (msgFee.getId().getPayingParty().equals(FeesCalculationType.DR.name()) || msgFee.getId().getPayingParty().equals(FeesCalculationType.AF.name()))
    		{
    			currency = GlobalUtils.isNullOrEmpty(pdo.getString(PDOConstantFieldsInterface.P_DBT_FEE_ACCT_CCY)) ? pdo.getString(PDOConstantFieldsInterface.P_DBT_ACCT_CCY)
    					: pdo.getString(PDOConstantFieldsInterface.P_DBT_FEE_ACCT_CCY);
    		}else
    		{
    			currency = GlobalUtils.isNullOrEmpty(pdo.getString(PDOConstantFieldsInterface.P_CDT_FEE_ACCT_CCY)) ? pdo.getString(PDOConstantFieldsInterface.P_CDT_ACCT_CCY)
    					: pdo.getString(PDOConstantFieldsInterface.P_CDT_FEE_ACCT_CCY);

    		}
    	}
    	msgFee.setFeeAccOrPmtCcy(currency);
    }
    /**
     * Method which maps the original fee amount (before it was adjusted) to MSG_FEES record 
     * @param dFeeAmount
     * @param feeTypeUIDMsgFees
     *
     */
    private void setOriginalFeeAmount(double dFeeAmount,FeeTypeUIDMsgFees feeTypeUIDMsgFees, Integer partitionID)
    {
      //  //BackendTracer GlobalTracer=GlobalTracer;
        
        logger.debug("FC - Set original fee amount to MSG_FEES table");
        long lTime=System.currentTimeMillis();
        MsgFees msgFee;
        if (feeTypeUIDMsgFees.getMsgFee()==null)
        {
            msgFee=new MsgFees(partitionID);
            feeTypeUIDMsgFees.setMsgFee(msgFee);
        }
        else
        {
            msgFee=feeTypeUIDMsgFees.getMsgFee();
        }
        msgFee.setOrigFeeAmount(dFeeAmount);
        logger.debug("FC - Finished Set original fee amount to MSG_FEES table - "+(System.currentTimeMillis()-lTime)+"ms");
    }
    
    /**
     * Method which verifies that fee amount do not exceed Minimum and Maximum limits defined in Fee Formula
     * @param dFeeAmount
     * @param feeFormula
     * @return adjusted fee amount
     *
     */
    private double getMinMaxValidationForFeeFormula(double dFeeAmount, FeeFormula feeFormula)
    {
       // //BackendTracer GlobalTracer=GlobalTracer;
        
        logger.info("FC - Adjust fee amount according to Min/Max validations for fee formula");
        long lTime=System.currentTimeMillis();
        boolean bIsFixedFeeExist=feeFormula.getPercentageFee().doubleValue()>0?false:true;
//        This validation should be performed only if fees are being calculated using percentage or as tiered
        if (feeFormula.getMethod().equals(MethodType.Tiered.name())||(feeFormula.getMethod().equals(MethodType.Regular.name())
                &&!bIsFixedFeeExist))
        {
            Double dMinFee=feeFormula.getMinFee();
            Double dMaxFee=feeFormula.getMaxFee();
            logger.info("FC - min fee ="+dMinFee+" max fee ="+dMaxFee+" dFeeAmount ="+dFeeAmount);
            //check if Min limit exist and greater then fee amount. 
            if (dMinFee!=null&&dMinFee>0&&dMinFee>dFeeAmount)
            {
                logger.info("FC - Min limit exist and greater then fee amount");
                dFeeAmount=dMinFee;
            }
            //check if Max limit exist and less then fee amount.
            if (dMaxFee!=null&&dMaxFee>0&&dMaxFee<dFeeAmount)
            {
                logger.info("FC - Max limit exist and less then fee amount");
                dFeeAmount=dMaxFee;
            }
        }
        logger.info("FC - Fee Amount = "+dFeeAmount+" "+feeFormula.getFeeCurrency()+" in - "+(System.currentTimeMillis()-lTime)+"ms");
        return dFeeAmount;
    }
    
    /**
     * Method which calculates the fee amount to be deducted.
     *
     */
    private double calculateFeeAccordingToFeeFormula(Double dMsgFeesFeeAmount, FeeFormula feeFormula
                              ,FeesCalculationType feesCalculationType,PDO pdo
                              , String sBaseOfficeCurrency, Double[] arrPrincipalAmount
                              , Map<String,Double>mapCurrencyConversion, FeesCalculationOutputData fcOutput) throws FeesCalculationException
    {
      //  //BackendTracer GlobalTracer=GlobalTracer;
        
        logger.info("FC - Calculate fee according to fee formula or take manual");
        long lTime=System.currentTimeMillis();
        double dFeeAmount;
        //check if manual fee amount exist, the use it
        if (dMsgFeesFeeAmount!=null)
        {
            logger.info("FC - Manual fee was found");
            dFeeAmount=dMsgFeesFeeAmount;
        }
        else //calculate the fee amount according to fee formula
        {
            logger.info("FC - Calculate fee according to fee formula");
            if (feeFormula.getMethod().equals(MethodType.Regular.name())) {
            	dFeeAmount = calculateFeeAmountRegular(feeFormula,pdo,arrPrincipalAmount, feesCalculationType, sBaseOfficeCurrency, mapCurrencyConversion, fcOutput);
            }
            else if (feeFormula.getMethod().equals(MethodType.Tiered.name()))
            {
            	dFeeAmount = calculateFeeAmountTiered (feeFormula,pdo,arrPrincipalAmount, feesCalculationType, sBaseOfficeCurrency, mapCurrencyConversion, fcOutput);             	
            }
            else 
            {
            	dFeeAmount=calculateFeeAmountItemInBulk(feeFormula, pdo, arrPrincipalAmount, feesCalculationType, sBaseOfficeCurrency, mapCurrencyConversion, fcOutput);
            }
            
        }
                        
        logger.info("FC - Fee amount = "+dFeeAmount+" "+feeFormula.getFeeCurrency()+" in - "+(System.currentTimeMillis()-lTime)+"ms");
        return dFeeAmount;
    }
    
    /**
     * Method which retrieves the fee amount from fee formula where the Method Type was Regular
     * @param dPrincipalAmount
     * @param feeFormula
     * @param minf
     * @param feeCalcType
     * @return fee amount
     * @throws FeesCalculationException 
     *
     */
    private double calculateFeeAmountRegular(FeeFormula feeFormula, PDO pdo,Double[] arrPrincipalAmount, FeesCalculationType feeCalcType, String baseCcy
            , Map<String, Double> ccyConvMap, FeesCalculationOutputData output)
                                                    throws FeesCalculationException 
    {
       // //BackendTracer GlobalTracer=GlobalTracer;
        
        logger.info("FC - Fee amount regular");
        double dFeeAmount=0;
        boolean bIsFixedFeeExist=feeFormula.getPercentageFee().doubleValue()>0?false:true;
        if (bIsFixedFeeExist)
        {
            if (feeFormula.getFixedFeeMethod().equals(FixedFeeMethodType.A))//per Advice
            {
//                TODO
            }
            else //per Message
            {
                dFeeAmount=feeFormula.getFixedFee();
                dFeeAmount=GlobalUtils.adjustPrecision(dFeeAmount,(feeFormula.getFeeCurrency()));
            }
        }
        else//Percentage
        {
            Double dPrincipalAmount=calculatePrincipalAmount(feeFormula.getFeeCurrency(),pdo,arrPrincipalAmount);
            logger.info("FC - Principal amount = "+dPrincipalAmount);
            dFeeAmount=dPrincipalAmount*(feeFormula.getPercentageFee()/100);
            
            Feedback feedback = new Feedback();
            dFeeAmount = convertCurrency(pdo.getString(PDOConstantFieldsInterface.OX_STTLM_CCY),feeFormula.getFeeCurrency(),
            		dFeeAmount,feeCalcType,pdo,false,baseCcy,ccyConvMap, feedback);
            
            output.setFeedback(feedback);
            if (! output.getFeedback().isSuccessful()) {
            	return dFeeAmount;  
            } 
            
        }
        logger.info("FC - Fee amount = "+dFeeAmount);
        return dFeeAmount;
    }

    /**
     * Method which retrieves the fee amount from fee formula where the Method Type was ItemInBulk
     * @param dPrincipalAmount
     * @param feeFormula
     * @param minf
     * @param feeCalcType
     * @return fee amount
     * @throws FeesCalculationException 
     *
     */
    private double calculateFeeAmountItemInBulk(FeeFormula feeFormula, PDO pdo,Double[] arrPrincipalAmount, FeesCalculationType feeCalcType, String baseCcy
            , Map<String, Double> ccyConvMap, FeesCalculationOutputData output) throws FeesCalculationException 
    {
        logger.info("calculateFeeAmountItemInBulk(Method={},FixedFeeMethod={},FixedFee={},FeeCurrency={})",new Object[]{feeFormula.getMethod(),feeFormula.getFixedFeeMethod(),feeFormula.getFixedFee(),feeFormula.getFeeCurrency()});
        double dFeeAmount=0;
        long lNoOfPayments=1;
    	String sP_BATCH_MSG_TP=pdo.getString(PDOConstantFieldsInterface.P_BATCH_MSG_TP);
    	if (SubBatchProcessInterface.BATCH_MESSAGE_TYPE_SUB.equals(sP_BATCH_MSG_TP))
    	{
    		BatchSubset batchSubset=pdo.getNSetBatchSubset();
    		if (null!=batchSubset && null!=batchSubset.getTotalMsgCountNb() && 
    			null != DAOFILE_SUMMARY.getInstance() && null != DAOFILE_SUMMARY.getInstance().getNumOfRejs(batchSubset.getInternalFileId()))
    		{
    			lNoOfPayments=batchSubset.getTotalMsgCountNb().longValue() - DAOFILE_SUMMARY.getInstance().getNumOfRejs(batchSubset.getInternalFileId());
    			if (lNoOfPayments == 0)
    				lNoOfPayments =1;
    		}
    	}
        dFeeAmount=lNoOfPayments*feeFormula.getFixedFee();

    	Double dItemFeeMaxAmt = (null == feeFormula.getMaxFee()) ? 0 : feeFormula.getMaxFee();
    	Double dItemFeeMinAmt = (null == feeFormula.getMinFee()) ? 0 : feeFormula.getMinFee();
        
    	if((dItemFeeMaxAmt > 0) && (dItemFeeMaxAmt < dFeeAmount))
    	{
    		dFeeAmount = dItemFeeMaxAmt;
    	}
    	
    	if((dItemFeeMinAmt > 0) && (dItemFeeMinAmt > dFeeAmount))
    	{
    		dFeeAmount = dItemFeeMinAmt;
    	}

    	dFeeAmount=GlobalUtils.adjustPrecision(dFeeAmount,(feeFormula.getFeeCurrency()));
        logger.info("calculateFeeAmountItemInBulk(dFeeAmount={},lNoOfPayments={},sP_BATCH_MSG_TP={})",new Object[]{dFeeAmount,lNoOfPayments,sP_BATCH_MSG_TP});
        return dFeeAmount;
    }

    
    /**
     * Method which retrieves the fee amount from fee formula where the Method Type was Tiered
     * If the tier type defined FIXED then finds only one suitable tier and returns its value.
     * If the tier type defined VOLUREM then the fee amount is the sum of all tiers which are suitable for principal amount    
     * @param feeFormula
     * @param minf
     * @param feeCalcType
     * @return fee amount
     */
    private double calculateFeeAmountTiered(FeeFormula feeFormula, PDO pdo,Double[] arrPrincipalAmount,
            FeesCalculationType feeCalcType, String baseCcy, Map<String, Double> ccyConvMap, FeesCalculationOutputData output) throws FeesCalculationException
    {
       // //BackendTracer GlobalTracer=GlobalTracer;
        
        logger.info("FC - Fee amount tiered");
        double dFeeAmount=0;
        double dTierRelation;

        //list of tiers for this fee formula
//        List<FeeFormulaTiers> listFeeFormulaTier=getFeeFormulaTiersFromCache(feeFormula.getUidFeeFormula());
//        Collections.sort(listFeeFormulaTier);
        Collection<FeeFormulaTiers> listFeeFormulaTiers=feeFormula.getListFeeFormulaTiers();
        Iterator<FeeFormulaTiers> iter=listFeeFormulaTiers.iterator();
        boolean[] arrEndLoop=new boolean[]{false}; 
        //loop over all tiers all or till the right tier was found(bIsStop == true)
        while(iter.hasNext()&&!arrEndLoop[0])
        {
            FeeFormulaTiers feeFormulaTier=iter.next();
            //in case of the last tier, the to amount should be infinity, therefore, I set it to be the base amount.
            if(!iter.hasNext())
            {
                feeFormulaTier.setToAmount(pdo.getDecimal(PDOConstantFieldsInterface.P_BASE_AMT).doubleValue());
            }
            
            boolean bIsFixedFeeExist=(feeFormulaTier.getPercentage()!=null)&&(feeFormulaTier.getPercentage()>0)?false:true;
            logger.info("FC - tier from "+ feeFormulaTier.getId().getFromAmount()+" tier to "
                    +feeFormulaTier.getToAmount()+" and " + (bIsFixedFeeExist ? "fixed":"percentage"));
            dTierRelation=getTierRelation(feeFormula,feeFormulaTier,pdo,arrEndLoop);
            //check if the right tier gap was found
            if (dTierRelation>0)
            {
                if (bIsFixedFeeExist)
                {
                    dFeeAmount+=feeFormulaTier.getFixedFee();
                }
                else //percentage
                {
                    double dPrincipalAmount=calculatePrincipalAmount(feeFormula.getFeeCurrency(),pdo,arrPrincipalAmount);
                    double dTierAmount=dPrincipalAmount/dTierRelation;
                    dFeeAmount+=dTierAmount*(feeFormulaTier.getPercentage()/100);
                    
                    Feedback feedback = new Feedback();
                    dFeeAmount = convertCurrency(pdo.getString(PDOConstantFieldsInterface.OX_STTLM_CCY),feeFormula.getFeeCurrency(),
                    		dFeeAmount,feeCalcType,pdo,false,baseCcy,ccyConvMap, feedback);
                    
                    output.setFeedback(feedback);
                    if (! feedback.isSuccessful()) {
                    	return dFeeAmount; 
                    }
                }
            }
        }
        dFeeAmount=GlobalUtils.adjustPrecision(dFeeAmount,(feeFormula.getFeeCurrency()));
        logger.info("FC - Fee amount = "+dFeeAmount);
        return dFeeAmount;        
    }
    
    /**
     * Method which decides if the tier is suitable for principal amount 
     * @param feeFormula
     * @param feeFormulaTier
     * @param minf
     * @return tier amount
     *
     */
    private double getTierRelation(FeeFormula feeFormula, FeeFormulaTiers feeFormulaTier, PDO pdo
                                    ,boolean[] arrEndLoop) throws FeesCalculationException
    {
        double dBaseCurrencyPrincipalAmount=pdo.getDecimal(PDOConstantFieldsInterface.P_BASE_AMT).doubleValue();
        double dTierAmount=0;
        double dTierRelation=0;
       // //BackendTracer GlobalTracer=GlobalTracer;
        
        
        if (dBaseCurrencyPrincipalAmount > feeFormulaTier.getId().getFromAmount())
        {
            if (feeFormula.getTierType().equals(TierType.VOLUREM.name()))
            {   //decides if next tier also should be included
                logger.info("FC - Tier Type = VOLUREM");
                if (dBaseCurrencyPrincipalAmount > feeFormulaTier.getToAmount())
                {
                    dTierAmount=feeFormulaTier.getToAmount() - feeFormulaTier.getId().getFromAmount(); 
                }
                else
                {
                    dTierAmount=dBaseCurrencyPrincipalAmount - feeFormulaTier.getId().getFromAmount();
                    arrEndLoop[0]=true;
                    logger.info("FC - Tier with to amount "+feeFormulaTier.getToAmount()+" is last one");
                }
                logger.info("FC - Tier amount is "+dTierAmount);
                dTierRelation=dBaseCurrencyPrincipalAmount/dTierAmount;
            }
            else //Tier Type = Fixed
            {
                logger.info("FC - Tier Type = FIXED");
                if (dBaseCurrencyPrincipalAmount <= feeFormulaTier.getToAmount())
                {
                    
                    dTierRelation=1;
                    arrEndLoop[0]=true;
                    logger.info("FC - Tier with to amount "+feeFormulaTier.getToAmount()+" is found ");
                }else
                    logger.info("FC - Principal amount in base currency "+dBaseCurrencyPrincipalAmount
                            +" is higher then tier to amount "+feeFormulaTier.getToAmount()+", try next one... ");
            }
            if (dTierAmount>0)
            {
                
                
            }
        }else
            logger.info("FC - base amount "+dBaseCurrencyPrincipalAmount+" less then tier from amount "
                    +feeFormulaTier.getId().getFromAmount());

        
        return dTierRelation;
    }
    
    /**
     * Method which calculates the principal amount for fee currency.
     * Principal amount returned in fee formula currency, therefore, it should be calculated for each iteration
     * @param sFeeCurrency
     * @param minf
     * @param feesCalculationType
     * @return principal amount
     *
     */
    private Double calculatePrincipalAmount(String sFeeCurrency, PDO pdo,Double[] arrPrincipalAmount) throws FeesCalculationException
    {
        ////BackendTracer GlobalTracer=GlobalTracer;
        if (arrPrincipalAmount[0]==null)
        {
            
            logger.info("FC - Calculating principle amount for currency " + sFeeCurrency);
    
            
            arrPrincipalAmount[0]= pdo.getDecimal(PDOConstantFieldsInterface.OX_STTLM_AMT).doubleValue();
        }
        else
        {
            logger.info("FC - Principle amount already calculated");
        }
        return arrPrincipalAmount[0];
    }
    
    
    
    /**
     * Method which calls currency conversion process
     * @param sFromCurrency
     * @param sToCurrency
     * @param dAmount
     * @param feesCalcType
     * @param minf
     * @return converted amount
     *
     */
    private double convertCurrency(String sFromCurrency, String sToCurrency, double dAmount, FeesCalculationType feesCalcType
                                    , PDO pdo, boolean bIsToCalculateEqv,String sBaseOfficeCurrency
                                    , Map<String, Double> mapCurrencyConversion, Feedback feedback)
    {
    	
        Double dConvertedAmount=dAmount;
       // //BackendTracer GlobalTracer=GlobalTracer;
        
                
        if (!sFromCurrency.equals(sToCurrency))
        {
            
            logger.info("FC - Currency conversion from " +dAmount + " "+sFromCurrency + " to "+sToCurrency);
            dConvertedAmount=null;
            
            if (mapCurrencyConversion != null && mapCurrencyConversion.containsKey(sFromCurrency+sToCurrency))
            {
                logger.info("FC - Currency conversion found in local cache");
                dConvertedAmount=dAmount/mapCurrencyConversion.get(sFromCurrency+sToCurrency);
                //if equivalent amount also need to be calculated, then check if this rate conversion already in map, then 
                //no need to perform equivalent amount calculation
            }
            if (bIsToCalculateEqv)
            {
                if (mapCurrencyConversion != null && mapCurrencyConversion.containsKey(sFromCurrency+sBaseOfficeCurrency))
                {
                    bIsToCalculateEqv=false;
                }
            }
            //if conversion amount found in local cache but no eqv. amount then run the conversion only for eqv. amount and update the cache
            if (dConvertedAmount!=null&&bIsToCalculateEqv)
            {
            	CurrencyConversionOutputData ccOutputData = executeCurrencyConversion(sFromCurrency,sBaseOfficeCurrency,dAmount,feesCalcType,pdo,bIsToCalculateEqv, feedback);          		
          		
          		if (feedback.isSuccessful() && ccOutputData.getConvertedAmount() != 0) {
          			mapCurrencyConversion.put(sFromCurrency+sBaseOfficeCurrency,dAmount/ccOutputData.getConvertedAmount());
          			bIsToCalculateEqv=false;
          		}
            }
            //if conversion amount not found in local cache the run currency conversion
            if (dConvertedAmount==null)
            {
            	CurrencyConversionOutputData ccOutputData = executeCurrencyConversion(sFromCurrency,sToCurrency,dAmount,feesCalcType,pdo,bIsToCalculateEqv, feedback);
          		
          		if (! feedback.isSuccessful()) {
          			return 0;
          		}
            		
                dConvertedAmount=ccOutputData.getConvertedAmount();
                if (mapCurrencyConversion != null && dConvertedAmount!=0)
                {
                    mapCurrencyConversion.put(sFromCurrency+sToCurrency,dAmount/dConvertedAmount);
                }
                //update the local cache with eqv. amount from output parameter 
                if (bIsToCalculateEqv)
                {
                    if (mapCurrencyConversion != null && ccOutputData.getEquivalentAmount()!=null&&ccOutputData.getEquivalentAmount()!=0)
                    {
                        mapCurrencyConversion.put(sFromCurrency+sBaseOfficeCurrency,dAmount/ccOutputData.getEquivalentAmount());
                        logger.info("FC - Currency conversion equivalent= "
                                +ccOutputData.getEquivalentAmount()+" "+sBaseOfficeCurrency);
                    }
                }
                
            }
        }
        logger.info("FC - Currency conversion ="+dConvertedAmount+" "+sToCurrency);
        return GlobalUtils.adjustPrecision(dConvertedAmount,(sToCurrency));       
    }
    
    private CurrencyConversionOutputData  executeCurrencyConversion(String sFromCurrency, String sToCurrency, double dAmount, FeesCalculationType feesCalcType, 
    		PDO pdo, boolean bIsToCalculateEqv,  Feedback feedback)
                                                                       
    {    	
        ////BackendTracer GlobalTracer=GlobalTracer;
        

        CurrencyConversionInputData input=new CurrencyConversionInputData();
                
        if (feesCalcType == null)
        {
        	input.setConversionType(ConversionType.Base);
            pdo.set(PDOConstantFieldsInterface.D_CURRENCY_CONVERSION_TYPE,ConversionType.Base.name());
        }
        else if (feesCalcType.equals(FeesCalculationType.DEBIT) || feesCalcType.equals(FeesCalculationType.AGENT))
        {
            input.setConversionType(ConversionType.Debit);
            pdo.set(PDOConstantFieldsInterface.D_CURRENCY_CONVERSION_TYPE,ConversionType.Debit.name());
        }
        else if (feesCalcType.equals(FeesCalculationType.CREDIT))
        {
            input.setConversionType(ConversionType.Credit);
            pdo.set(PDOConstantFieldsInterface.D_CURRENCY_CONVERSION_TYPE,ConversionType.Credit.name());
        } 
        
        logger.info("FC - Currency conversion with "+pdo.getString(PDOConstantFieldsInterface.D_CURRENCY_CONVERSION_TYPE)+" Rate Usage");
        input.setAmountToConvert(dAmount);
        input.setCurrency1(sFromCurrency);
        input.setCurrency2(sToCurrency);
        input.setOffice(pdo.getString(PDOConstantFieldsInterface.P_OFFICE));
        input.setApplySpread(true);
        input.setCalculateEquivalentAmount(bIsToCalculateEqv);
        input.setIsToAdjustPrecision(false);
        input.setPerformThresholdValidation(false);
        //pdo.set(PDOConstantFieldsInterface.P_FC_INFO_IND,0l);
        CurrencyConversionOutputData ccOutputData = null;

        // Performs currency conversion.
        // ASAF - CR #79477 - calls currency conversion only ONE time as opposed
        // to the below remarked code in which a failure in CREDIT/DEBIT conversion
        // lead to performing BASE conversion.
        try
        {
        	ccOutputData = BOProxies.m_internalCurrencyConversionLogging.performCurrencyConversion(Admin.getContextAdmin(),input);
          
        	BOCurrencyConversion.isCompletedSuccessfully(feedback, ccOutputData.getErrors());
          
        }
        catch(Exception e)
        {
          logger.info("FC - Currency conversion failed");
          feedback.setFailure();
        }
        
        return ccOutputData;
        
    }
    /**
     * Method which loads P&L account from fee formula, if not defined, load from FEE_TYPE.
     * @param feeFormulaRecord
     * @param sFeeTypeUID
     * @param minf
     * @param applyFeeFlag
     * @return P&L account
     * @param fcOutputData
     */
    private Accounts loadPandLaccount(FeeFormula feeFormulaRecord, String sFeeTypeUID, PDO pdo, ApplyFee applyFeeFlag
                                        ,FeesCalculationOutputData fcOutputData, FeesCalculationType feeCalcType)
    {
       // //BackendTracer GlobalTracer=GlobalTracer;
        
        logger.info("FC - Load P&L account");
        long lTime=System.currentTimeMillis();
        Accounts account=null;
        if (!feeCalcType.equals(FeesCalculationType.AGENT))
        {
            if (feeFormulaRecord.getFeesSuspAccNo()!=null&&feeFormulaRecord.getFeesSuspAccNo().length()>0
                    &&feeFormulaRecord.getFeesSuspAccOffice()!=null&&feeFormulaRecord.getFeesSuspAccOffice().length()>0
                    &&feeFormulaRecord.getFeesSuspAccCcy()!=null&&feeFormulaRecord.getFeesSuspAccCcy().length()>0) //load from fee formula
            {
                account=  CacheKeys.accountsKey.getSingle(feeFormulaRecord
                        	.getFeesSuspAccNo(),feeFormulaRecord.getFeesSuspAccCcy(),
                        						feeFormulaRecord.getFeesSuspAccOffice());
            }
            if (account==null) //load from fee type if from fee formula failed
            {
                FeeTypes feeType= feeTypesKey.getSingle(sFeeTypeUID);
                
                account= CacheKeys.accountsKey.getSingle(feeType.getFeesSuspAccNo(),feeType.getFeesSuspAccCcy(),feeType.getFeesSuspAccOffice()) ;
            }
            
            if (account==null && !applyFeeFlag.equals(ApplyFee.WAIVE)) 
            {
                logger.info("FC - P&L account not found set error...");
                ProcessError pError=new ProcessError(ProcessErrorConstants.PL_AccountNotFound);
                // pError.setErrorCode(P_AND_L_ACCOUNT_NOT_FOUND_ERROR_CODE);
                pError.setSeverity(ErrorSeverity.informative);
                configureErrorFeedback(pError.getErrorCode(),pError.getDescription(),fcOutputData.getFeedback());
                ErrorAuditUtils.setErrors(pError,pdo.getIsHistory());
            }
            
            logger.info("FC - Finished Load P&L account - "+(System.currentTimeMillis()-lTime)+"ms");
        }
        return account;
    }
    
    /**
     * Method which setting the Apply Fee Type: LATER,NOW or WAIVE
     * - If the user didn't enter apply fee in the payment information, then the apply fee from the fee formula profile will be used.
     *   
     * - If user did enter apply fee in the payment information, then this value will be used for all fees except in the following cases:
     * *** If fee formula profile is set with apply fee WAIVE, then this value will be used regardless to the user selection.
     * *** If user set apply fee as WAIVE on the message fee information, then this value will be used regardless to the user selection
     *     
     * @param feesCalculationType
     * @param minf
     * @param feeFormulaRecord
     * @param sApplyFeeFromMsgFee
     * @return ApplyFee
     *
     */
    private ApplyFee getApplyFeeFlag(FeesCalculationType feesCalculationType ,PDO pdo, FeeFormula feeFormulaRecord
                                        ,String sApplyFeeFromMsgFee)
    {
        //BackendTracer GlobalTracer=GlobalTracer;
        
        logger.info("FC - Get apply fee flag");
        long lTime=System.currentTimeMillis();
        ApplyFee applyFee=null;
        if ((feesCalculationType.equals(FeesCalculationType.DEBIT)&&pdo.getString(PDOConstantFieldsInterface.P_DBT_APPLY_FEE)!=null
                                &&pdo.getString(PDOConstantFieldsInterface.P_DBT_APPLY_FEE).length()>0)
                ||(feesCalculationType.equals(FeesCalculationType.CREDIT)&&pdo.getString(PDOConstantFieldsInterface.P_CDT_APPLY_FEE)!=null
                                &&pdo.getString(PDOConstantFieldsInterface.P_CDT_APPLY_FEE).length()>0))
        {
            if ((sApplyFeeFromMsgFee!=null&&sApplyFeeFromMsgFee.equals(ApplyFee.WAIVE.name()))
                    ||feeFormulaRecord.getApplyFee().equals(ApplyFee.WAIVE.name()))
            {
                applyFee=ApplyFee.WAIVE;
            }
            else
            {
                applyFee=ApplyFee.valueOf(feesCalculationType.equals(FeesCalculationType.DEBIT)?pdo.getString(PDOConstantFieldsInterface.P_DBT_APPLY_FEE)
                                                                                                        :pdo.getString(PDOConstantFieldsInterface.P_CDT_APPLY_FEE));
            }
        }
        else
        {
            applyFee=ApplyFee.valueOf(feeFormulaRecord.getApplyFee());
        }
        logger.info("FC - Finished Get apply fee flag - "+(System.currentTimeMillis()-lTime)+"ms");
        return applyFee;
    }
    
    /**
     *  Method which retrieves fee formula by executing rule engine
     * @param feeType
     * @param feesCalculationType
     * @param minf
     * @return FeeFormula
     *
     */
    
    private FeeFormula getFeeFormulaByExecutingFeeFormulaRule(FeeTypes feeType,Customrs customer
                                                                ,PDO pdo)
    {
        FeeFormula feeFormula=null;
        try
        {
            String[] arr;
            if (customer!=null && customer.getCustCode()!=null)
                arr=new String[]{customer.getCustCode(),pdo.getNSetOffice().getCustCode()};
            else
                arr=new String[]{pdo.getNSetOffice().getCustCode()};
            List<RuleResult> list=m_internalRuleExecutionLogging.executeRule(Admin.getContextAdmin(), MessageConstantsInterface.RULE_TYPE_ID_FEE_FORMULA_SELECTION,feeType.getFeeTypeName()
                                    ,pdo.getString(PDOConstantFieldsInterface.P_MID),arr).getResults() ; 
            if (list!=null && list.size()>0)
            {
                feeFormula= feeFormulaKey.getSingle(list.get(0).getAction());
            }
        }
        catch(Exception e)
        {
            // TODO Auto-generated catch block
        	logger.error(e.getMessage());
        }
        return feeFormula;
    }

    
    
    
    
    
    /**
     * Method which creates non manual fee type list.
     * Loops over all Fee Type UIDs created in previous step and checks if specific uid already contained in manual list,
     * if not, then this fee type not manual and should be added to non manual uid list.  
     * @param listFeeTypesUIDs
     * @param listManualUIDs
     * @return List<FeeTypeUIDMsgFees>
     *
     */
    private List<FeeTypeUIDMsgFees> createMissingFeeTypesList(List<RuleResult> listFeeTypes, List<FeeTypeUIDMsgFees> listManualUIDs, Integer partitionID)
    {
        //BackendTracer GlobalTracer=GlobalTracer;
        
        logger.info("FC - Creating non manual fee types");
        List<FeeTypeUIDMsgFees> listNonManual=new ArrayList<FeeTypeUIDMsgFees>();
        Set<String> setFeeTypeUIDs=new HashSet<String>();
        int iSize=listManualUIDs.size();
        //transfer all manual fee types to Set in order to make the validation with better performance.
        for (int i=0;i<iSize;i++)
        {
            setFeeTypeUIDs.add(listManualUIDs.get(i).getFeeTypeUid());
        }
        iSize=listFeeTypes.size();
        for (int i=0;i<iSize;i++)
        {
            String sUID=listFeeTypes.get(i).getAction();
            if (!setFeeTypeUIDs.contains(sUID))
            {
                listNonManual.add(new FeeTypeUIDMsgFees(sUID, partitionID));
            }
        }
        return listNonManual;
    }
    /**
     * 
     * @param minf
     * @return List<String>
     *
     */
    private List<RuleResult> deriveRequiredFeeTypesUIDs(PDO pdo, FeesCalculationType feeCalcType, BasicFeesCalculationData basicFeeCalcData)
    {
        //BackendTracer GlobalTracer=GlobalTracer;
        String sFeeCalcType=null;
        
        logger.info("FC - Deriving fee types");
        List<RuleResult> list=null;
        //run rule engine to retrieve all UID_FEE_TYPES from FEE_TYPES Table.
        try
        {
            String[] arr;
            Customrs customer=null;
            if (feeCalcType.equals(FeesCalculationType.DEBIT))
            {
                sFeeCalcType=FeesCalculationType.DR.name();
            }
            else if (feeCalcType.equals(FeesCalculationType.CREDIT))
            {
                sFeeCalcType=FeesCalculationType.CR.name();
            }
            else 
                sFeeCalcType=FeesCalculationType.AF.name();
            
            customer = basicFeeCalcData.getCustomer();
            
            if (customer!=null && customer.getCustCode()!=null)
                arr=new String[]{customer.getCustCode(), pdo.getNSetOffice().getCustCode()};
            else
                arr=new String[]{pdo.getNSetOffice().getCustCode()};
            
            list=m_internalRuleExecutionLogging.executeRule(Admin.getContextAdmin(), MessageConstantsInterface.RULE_TYPE_ID_FEE_TYPE_SELECTION,sFeeCalcType,pdo.getString(PDOConstantFieldsInterface.P_MID),arr).getResults();
//            list=m_internalRuleExecutionLogging.executeRule(MessageConstantsInterface.RULE_TYPE_ID_FEE_TYPE_SELECTION,"CR",pdo.getString(PDOConstantFieldsInterface.P_MID),arr).getResults();
//            list.addAll(m_internalRuleExecutionLogging.executeRule(MessageConstantsInterface.RULE_TYPE_ID_FEE_TYPE_SELECTION,"DR",pdo.getString(PDOConstantFieldsInterface.P_MID),arr).getResults());            
        }
        catch(Exception e)
        {
        	logger.error(e.getMessage());
        }
        return list;
    }
    
    private List<String> retrieveActionFromRuleResultList(List<RuleResult> listRuleResult)
    {
        List<String> listStringResult=new ArrayList<String>();
        if (listRuleResult!=null)
        {
            int iSize=listRuleResult.size();
            for (int i=0;i<iSize;i++)
            {
                listStringResult.add(listRuleResult.get(i).getAction());
            }
        }
        return listStringResult;
    }
    
    /**
     * Method which retrieves all manual entered fees located in MSG_FEES table
     * @param minf
     * @param feesCalcType
     * @return list of manual fees
     *
     */
    private void applyCalculationModeRestrictions(PDO pdo, FeesCalculationType feesCalcType, List<FeeTypeUIDMsgFees> manualyRequestedFeeTypeUIDMsgFees,
    		List<MsgFees> persistantMsgFeesList,List<RuleResult> requiredFeeTypesUIDs,Feedback feedback)
    {
        //BackendTracer GlobalTracer=GlobalTracer;

        List<FeeTypeUIDMsgFees> cdbListFeeTypeUIDMsgFees=new ArrayList<FeeTypeUIDMsgFees>();
        String str=pdo.getString(PDOConstantFieldsInterface.D_FEE_CALC_MODE);
        boolean bIsAppend=(str!=null && str.trim().toUpperCase().startsWith("A"));
        logger.info("FC - applyCalculationModeRestrictions(bIsAppend="+bIsAppend+",feesCalcType="+feesCalcType+")");
        List<MsgFees> listMsgFees=pdo.isNew() ? pdo.getListMSG_FEES() : pdo.getNSetListMSG_FEES();
        
        if (listMsgFees != null)
        {
        	Set<String> setFeeTypeUIDs=new HashSet<String>();
	        if (requiredFeeTypesUIDs != null){
	            for (RuleResult feeTypeUIDEntry: requiredFeeTypesUIDs )
	            {
	                setFeeTypeUIDs.add(feeTypeUIDEntry.getAction());
	            }
	        }
	        
        	String payingParty=null;
	        if (feesCalcType.equals(FeesCalculationType.DEBIT))
	            payingParty=FeesCalculationType.DR.name();
	        else if (feesCalcType.equals(FeesCalculationType.CREDIT))
	            payingParty=FeesCalculationType.CR.name();
	        else //Agent
	            payingParty=FeesCalculationType.AF.name();
	        int iSize=listMsgFees.size();
	        for (int i=0;i<iSize;i++)
	        {
	            MsgFees msgFee=listMsgFees.get(i);
	            if (msgFee.getId().getPayingParty().equals(payingParty))
	            {
	            	boolean bIsManual=(msgFee.getManualFee()!= null && msgFee.getManualFee() == MANUAL_FEE);
	            	boolean bIsCDB=(msgFee.getManualFee()!= null && msgFee.getManualFee() == CDB_FEE);
	            	boolean bIsAprocessedMsgFeeRecord=(null!=msgFee.getDeductFrom() && null!=msgFee.getOrigFeeAmount());
	            	Integer partitionID = pdo.getIsHistory();
	            	if (!bIsAppend && msgFee.getIsPosted() &&
            			null!=msgFee.getId() && null!=msgFee.getId().getFeeTypeUid() &&
            			setFeeTypeUIDs.contains(msgFee.getId().getFeeTypeUid()))
	            	{
            			//error "Fee entry of |1 |2 (type |3, paying party |4) was already posted successfully to the account posting Interface."
	                    ProcessError pError=new ProcessError(ProcessErrorConstants.FeeEntryAlreadyPosted,new Object[] {msgFee.getFeeAmount(),msgFee.getFeeCurrency(),msgFee.getId().getFeeTypeUid(),payingParty});
	                    pError.setSeverity(ErrorSeverity.critical);
	                    configureErrorFeedback(pError.getErrorCode(),pError.getDescription(),feedback);
	                    ErrorAuditUtils.setErrors(pError,partitionID);
	                    return;
	            		
	                }
	            	else if (bIsAppend && bIsAprocessedMsgFeeRecord && null!=setFeeTypeUIDs && !setFeeTypeUIDs.isEmpty() && 
	            			null!=msgFee.getId() && null!=msgFee.getId().getFeeTypeUid() &&
	            			setFeeTypeUIDs.contains(msgFee.getId().getFeeTypeUid()))
        			{
	            		if (bIsManual || bIsCDB)
	            		{
	            			//error "Existing fee |1 |2 (type |3) for the same paying party |4 was already provided manually or from account lookup. Cannot be re-selected when calculating fees in an Append mode.
	                        ProcessError pError=new ProcessError(ProcessErrorConstants.AppendManualFeeTypeExists,new Object[] {msgFee.getFeeAmount(),msgFee.getFeeCurrency(),msgFee.getId().getFeeTypeUid(),payingParty});
	                        pError.setSeverity(ErrorSeverity.critical);
	                        configureErrorFeedback(pError.getErrorCode(),pError.getDescription(),feedback);
	                        ErrorAuditUtils.setErrors(pError,partitionID);
	                        return;
	                    }
	            		else
	            		{
	            			//error "Existing fee |1 |2 (type |3) for the same paying party |4 cannot be re-selected when calculating fees in an Append mode."
	                        ProcessError pError=new ProcessError(ProcessErrorConstants.AppendFeeTypeExists,new Object[] {msgFee.getFeeAmount(),msgFee.getFeeCurrency(),msgFee.getId().getFeeTypeUid(),payingParty});
	                        pError.setSeverity(ErrorSeverity.critical);
	                        configureErrorFeedback(pError.getErrorCode(),pError.getDescription(),feedback);
	                        ErrorAuditUtils.setErrors(pError,partitionID);
	                        return;
	                    }
        			}
                    else if (bIsAppend && (bIsAprocessedMsgFeeRecord || msgFee.getIsPosted())) 
                    {
    	                persistantMsgFeesList.add(msgFee);
                    }
	            	else if (bIsManual)
	            	{
                        manualyRequestedFeeTypeUIDMsgFees.add(new FeeTypeUIDMsgFees(msgFee.getId().getFeeTypeUid(),msgFee));
	            	}
                    else if (bIsCDB)
                    {
                    	cdbListFeeTypeUIDMsgFees.add(new FeeTypeUIDMsgFees(msgFee.getId().getFeeTypeUid(),msgFee));
                    }
	            	// if we got here this Msg_Fee record will be skipped and deleted from DB.
	            }else
	            {
	                persistantMsgFeesList.add(msgFee);
	            }
	            
	        }
	        manualyRequestedFeeTypeUIDMsgFees.addAll(cdbListFeeTypeUIDMsgFees); //add CDB after the MANUAL
        }
    }
    
    /**
     * Method which retrieves basic fee calculation data
     * @param feeCalculationType
     * @param minf
     * @return BasicFeeCalculationData
     *
     */
    private BasicFeesCalculationData getBasicFeeCalculationData(FeesCalculationType feeCalculationType
                                               , PDO pdo) throws FeesCalculationException
                                                        
    {
       // //BackendTracer GlobalTracer=GlobalTracer;
        
        logger.info("FC - Get Basic Fee Calculation Data");
        long lTime=System.currentTimeMillis();
        BasicFeesCalculationData basicFeeCalcData=new BasicFeesCalculationData();
        basicFeeCalcData.setCustomer(setSkipCalculationProcess(basicFeeCalcData,feeCalculationType,pdo));
        long tempTime=System.currentTimeMillis();
        logger.info("FC - Finished Setting Skip Calculation Process - "+(System.currentTimeMillis()-tempTime)+"ms");
        if (!basicFeeCalcData.getSkipFeeCalculation())
        {
            setChargeBearer(basicFeeCalcData,pdo);
            tempTime=System.currentTimeMillis();
            logger.info("FC - Finished Setting Charge Bearer - "+(System.currentTimeMillis()-tempTime)+"ms");
            tempTime=System.currentTimeMillis();
            setFeesLimit(basicFeeCalcData,pdo);
            logger.info("FC - Finished Setting Fees Limit - "+(System.currentTimeMillis()-tempTime)+"ms");
            tempTime=System.currentTimeMillis();
            setUnwindMethod(basicFeeCalcData,pdo);
            logger.info("FC - Finished Setting Unwind Method - "+(System.currentTimeMillis()-tempTime)+"ms");
            tempTime=System.currentTimeMillis();
//            basicFeeCalcData.setFeeAcount(getFeesAccount(feeCalculationType,minf));
            //cleanCurrentFeeInfo(feeCalculationType,pdo);
            logger.info("FC - Finished cleaning Current fee info - "+(System.currentTimeMillis()-tempTime)+"ms");
            
            pdo.set(PDOConstantFieldsInterface.X_CHRG_BR,basicFeeCalcData.getChargeBearer().name());
        }
        else
        {
            logger.info("FC - Skipping Fees Calculation");
        }
      logger.info("FC - Finished Get Basic Fee Calculation Data - "+(System.currentTimeMillis()-lTime)+"ms");
      return basicFeeCalcData;
    }
    
    /**
     * The fee account will be derived the same way for agent fee, debit fee and credit fee.
     * We need to get the account number, office and currency and then get related record from ACCOUNTS table
     * If account was found in one of the steps, than no need proceeding to the next step.
     * Steps: 
     * 1) The account was entered manually by the user in the message GUI screen; i.e. we need to check relevant 
     *    MINF fields and if they aren't empty, use the values there.
     * 2) The account should be derived from executing the fee account selection rule, (rule type ID 57).
     * 3) The account should be derived from the account profile or from the customer profile.
     * @param feeCalculationType
     * @param minf
     * @param fcOutputData
     * @return Accounts
     *
     */
    public boolean setFeesAccount(FeesCalculationType feeCalculationType, PDO pdo, FeesCalculationOutputData fcOutputData
                                    ,Accounts account, ChargeBearer chrgBr) throws FeesCalculationException
    {
        boolean flag = false;
        //BackendTracer GlobalTracer=GlobalTracer;
        
        logger.info("FC - Set Fees Account");
            
        if (!account.getAlreadySearched())    
        {
            Accounts tempAccount=null;
            for (int i=0;i<3&&tempAccount==null;i++)
            {
                switch(i)
                {
                	//For G3 immediate outgoing flows, if X_CHRGS_ACCT_ID is not empty, it is mapped to P_CDT_FEE_ACCT_NB/P_DBT_FEE_ACCT_NB
                    case 0:tempAccount=setAccountCurrencyOfficeFromMinf(feeCalculationType,pdo);
                            break;
                    case 1:tempAccount=setAccountCurrencyOfficeFromFeeAccountSelectionRule(feeCalculationType,pdo);
                            break;
                    case 2:tempAccount=getAccountFromAccountOrCustomerProfile(pdo,feeCalculationType,fcOutputData, chrgBr);
                            break;
                }
            }
            if (tempAccount!=null)
            {
                account.setCurrency(tempAccount.getCurrency());
                account.setAccNo(tempAccount.getAccNo());
                account.setOffice(tempAccount.getOffice());
                account.setUidAccounts(tempAccount.getUidAccounts());
                logger.info("FC - Fee Account found: "+tempAccount.getUidAccounts());
                flag = true;
            }
            account.setAlreadySearched(true);
        }
        else if (account.getCurrency()==null||account.getCurrency().length()==0
                ||account.getAccNo()==null||account.getAccNo().length()==0
                ||account.getOffice()==null||account.getOffice().length()==0)
        {
            logger.info("FC - Fee Account already searched and not found");
        }
        else
        {
            logger.info("FC - Fee Account already found: "+account.getUidAccounts());
            flag = true;
        }
        fcOutputData.setFeeAccountExist(flag);
        //GlobalConstants.listForSysout.add("FC:						setFeeAccount = "+((System.nanoTime() - t)/1000000));
        return flag;
    }
    
    /**
     * Method which derives the account from the account profile or from the customer profile.
     * @param minf
     * @param feeCalculationType
     * @return Accounts
     *
     */
    private Accounts getAccountFromAccountOrCustomerProfile(PDO pdo, FeesCalculationType feeCalculationType
                            ,FeesCalculationOutputData fcOutputData, ChargeBearer chrgBr)
    {
        Accounts account=null;
        StringBuffer sError=new StringBuffer();
        if (feeCalculationType.equals(FeesCalculationType.DEBIT) || feeCalculationType.equals(FeesCalculationType.AGENT))
        {
            account=debitFeeAccountDerivation(pdo, sError, chrgBr);
        }
        else if (feeCalculationType.equals(FeesCalculationType.CREDIT))
        {
            account=creditFeeAccountDerivation(pdo, sError);
        } 
        if (account==null && sError.length() > 0)
        {
            fcOutputData.setFeeAccountNotFoundFailure(true);
        }
        
        return account;
    }
    
    /**
     * Method which derives the account from Debit account
     * @param minf
     * @param sError
     * @return Accounts
     *
     */
    private Accounts debitFeeAccountDerivation(PDO pdo, StringBuffer sError, ChargeBearer chrgBr)
    {
        Accounts account=null;
        Accounts accountDebit=pdo.getNSetDEBIT_ACCOUNT();
        //BackendTracer GlobalTracer=GlobalTracer;
        
        if (accountDebit!=null)
        {
            if (accountDebit.getFeeAccountNo()!=null&&accountDebit.getFeeAccountNo().length()>0)//if debit account holds a fee account
            {
                account= CacheKeys.accountsKey.getSingle(accountDebit.getFeeAccountNo(),
                				accountDebit.getFeeAccountCcy(),accountDebit.getFeeAccountOffice());
                if (account==null)
                {
                    sError.append("Debit fee account not found [acc.no="+accountDebit.getFeeAccountNo()
                                +", office="+accountDebit.getOffice()+"]");
                    logger.info("Debit fee account not found [acc.no="+accountDebit.getFeeAccountNo()
                                    +", office="+accountDebit.getOffice()+"]");
                }
                else
                    logger.info("FC - Fees Account derived from debit account");

            }else if((account = loadRelatedFeeAccount(accountDebit)) != null){
	        	//Loading fee debit account using the debit account retrived from cache
            	logger.info("FC - Fees Account "+account.getAccNo()+" derived from debit account cache");
            }else if (pdo.getNSetDEBIT_CUSTOMER()!=null&&pdo.getNSetDEBIT_CUSTOMER().getFeeAccountNo()!=null
                    &&pdo.getNSetDEBIT_CUSTOMER().getFeeAccountNo().length()>0) //if debit customer holds a fee account
            {
                account= CacheKeys.accountsKey.getSingle(pdo.getNSetDEBIT_CUSTOMER().getFeeAccountNo()
                        ,pdo.getNSetDEBIT_CUSTOMER().getFeeAccountCcy(),pdo.getNSetDEBIT_CUSTOMER()
                        .getFeeAccountOffice());
                if (account==null)
                {
                    sError.append("Debit fee account not found [acc.no="+pdo.getNSetDEBIT_CUSTOMER().getFeeAccountNo()
                                +", office="+pdo.getNSetDEBIT_CUSTOMER().getFeeAccountOffice()+"]");
                    logger.info("Debit fee account not found [acc.no="+pdo.getNSetDEBIT_CUSTOMER().getFeeAccountNo()
                                +", office="+pdo.getNSetDEBIT_CUSTOMER().getFeeAccountOffice()+"]");
                }
                else
                    logger.info("FC - Fees Account derived from debit customer");
                
            }
            else // No fee account at account level and at customer level
            {
            	if (accountDebit.getAsset()==null || accountDebit.getAsset()==0) //Debit account is non asset (Vostro)
            	{
	            	if(SystParKey.getSingle(pdo.getString(PDOConstantFieldsInterface.P_OFFICE), 
	            					SystemParametersInterface.SYS_PAR_REPNOFEEACVOS).getParmValue().equalsIgnoreCase(GlobalConstants.YES))
	                {
	                    sError.append("Fee Account can not be derived");
	                    logger.info("FC - Fee Account can not be derived - No Fee Account and account and customer debit level");
	                }
	                else
	                {
	                	account=accountDebit;
	               		logger.info("FC - Fees Account equals to debit account");
	                }
            	}else // Debit account is asset (Nostro)
            	{
            		String repNoFeeAccNostro =SystParKey.getSingleParmValue(pdo.getString(PDOConstantFieldsInterface.P_OFFICE),SystemParametersInterface.SYS_PAR_REPNOFEEACNOS);
            		
//            		continue with the pricing calculation but at the end move the payment to REPAIR with a proper message error
                	if(SystemParametersInterface.SYST_PARAM_VALUE_REPAIR.equalsIgnoreCase(repNoFeeAccNostro))
		            {
		                sError.append("Fee Account can not be derived");
		                logger.info("FC - Fee Account can not be derived - No Fee Account and account and customer debit level");
		            }
//                	When 'FEEACCONLY' , 'FEEACCFIRST'
		            else if (SystemParametersInterface.SYST_PARAM_VALUE_FEEACCFIRST.equalsIgnoreCase(repNoFeeAccNostro) || SystemParametersInterface.SYST_PARAM_VALUE_FEEACCONLY.equalsIgnoreCase(repNoFeeAccNostro))
		            {
		            	Mop debitMop = CacheKeys.mopKey.getSingle(pdo.getString(PDOConstantFieldsInterface.P_OFFICE), pdo.getString(PDOConstantFieldsInterface.P_DBT_MOP));
//		            	Try to get the account from the original sender - 
//		            	If debit account is a clearing account (P_DBT_MOP.SETT_ACC_EXISTS = true) 
		            	if (debitMop != null && debitMop.getSettAccExists() != null && debitMop.getSettAccExists())
		            	{
		            		Customrs originalSender = pdo.getNSetOriginalSender();
		            		
		            		if (originalSender != null && !GlobalUtils.isNullOrEmpty(originalSender.getFeeAccountNo()))
		            		{
		                        account= CacheKeys.accountsKey.getSingle(originalSender.getFeeAccountNo()
		                                ,originalSender.getFeeAccountCcy(),originalSender.getFeeAccountOffice());
		                        
		            		}
		            	}
		            	
//		            	IF we failed with the getting the account then 
//		            	IF 'FEEACCONLY' then act as in the case of REPAIR I.e adds message error (can be different than above) continue with the fee 
//		            		logic and at the end send the message to REPAIR. 
//		            	ELSE continue as it was MT191AUTOGEN
		            	
		            	if (account == null)
		            	{
		            		if (SystemParametersInterface.SYST_PARAM_VALUE_FEEACCONLY.equalsIgnoreCase(repNoFeeAccNostro))
		            		{
				                sError.append("Fee Account can not be derived");
				                logger.info("FC - Fee Account can not be derived - No Fee Account in original sender level");
		            			
		            		}else
		            		{
		            			repNoFeeAccNostro = SystemParametersInterface.SYST_PARAM_VALUE_MT191AUTOGEN;
		            		}
		            	}
		            	
		            }
            		
                	
                	if (SystemParametersInterface.SYST_PARAM_VALUE_MT191AUTOGEN.equalsIgnoreCase(repNoFeeAccNostro) && (chrgBr == ChargeBearer.OUR || chrgBr == ChargeBearer.DEBT))
                	{
                		pdo.set(PDOConstantFieldsInterface.D_MT191AUTOGEN, true);
                	}
            	}
            }
        }
        return account;
    }
    
    private Accounts loadRelatedFeeAccount(Accounts account){
    	Accounts feeAccount = null;
    	Accounts accountProfile = CacheKeys.accountsKey.getSingle(account.getAccNo(),account.getCurrency(),account.getOffice()); 
    	if(accountProfile!=null)
    		feeAccount = CacheKeys.accountsKey.getSingle(accountProfile.getFeeAccountNo(),accountProfile.getFeeAccountCcy(),accountProfile.getFeeAccountOffice()); 
    	return feeAccount;
    }
    
    /**
     * Method which derives the account from Credit account
     * @param minf
     * @param sError
     * @return Accounts
     *
     */
    private Accounts creditFeeAccountDerivation(PDO pdo, StringBuffer sError)
    {
        Accounts account=null;
        Accounts accountCredit=pdo.getNSetCREDIT_ACCOUNT();
        //BackendTracer GlobalTracer=GlobalTracer;
        
        //if credit account holds a fee account
        if (accountCredit != null && (accountCredit.getAsset()==null || accountCredit.getAsset()==0)) //Credit account is non asset (Vostro)
        {
	        if (accountCredit.getFeeAccountNo()!=null&&accountCredit.getFeeAccountNo().length()>0)
	        {
	            account= CacheKeys.accountsKey.getSingle(accountCredit.getFeeAccountNo(),
	            					accountCredit.getFeeAccountCcy(),accountCredit.getFeeAccountOffice()); 
	            if (account==null)
	            {
	                sError.append("Credit fee account not found [acc.no="+accountCredit.getFeeAccountNo()
	                            +", office="+accountCredit.getOffice()+"]");
	                logger.info("FC - Credit fee account not found [acc.no="+accountCredit.getFeeAccountNo()
	                            +", office="+accountCredit.getOffice()+"]");
	            }
	            else
	                logger.info("FC - Fees Account derived from credit account");
	        }else if((account = loadRelatedFeeAccount(accountCredit)) != null){
	        	//Loading fee credit account using the credit account retrived from cache
	        	logger.info("FC - Fees Account "+account.getAccNo()+" derived from credit account cache");
	        }else if (pdo.getNSetCREDIT_CUSTOMER()!=null&&pdo.getNSetCREDIT_CUSTOMER().getFeeAccountNo()!=null
	                &&pdo.getNSetCREDIT_CUSTOMER().getFeeAccountNo().length()>0) //if credit customer holds a fee account
	        {
	            account=  CacheKeys.accountsKey.getSingle(pdo.getNSetCREDIT_CUSTOMER().getFeeAccountNo(),
	            								pdo.getNSetCREDIT_CUSTOMER().getFeeAccountCcy(),
	            										pdo.getNSetCREDIT_CUSTOMER().getFeeAccountOffice());
	            if (account==null)
	            {
	                sError.append("Credit fee account not found [acc.no="+pdo.getNSetCREDIT_CUSTOMER().getFeeAccountNo()
	                            +", office="+pdo.getNSetCREDIT_CUSTOMER().getFeeAccountOffice()+"]");
	                logger.info("FC - Credit fee account not found [acc.no="+pdo.getNSetCREDIT_CUSTOMER().getFeeAccountNo()
	                            +", office="+pdo.getNSetCREDIT_CUSTOMER().getFeeAccountOffice()+"]");
	            }
	            else
	                logger.info("FC - Fees Account derived from credit customer");
	            
	        }
	        else // No fee account at account level and at customer level
	        {
	        	if(SystParKey.equalsIgnoreCase(pdo.getString(PDOConstantFieldsInterface.P_OFFICE), 
	        			SystemParametersInterface.SYS_PAR_REPNOFEEACVOS, GlobalConstants.YES))
	            {
	                sError.append("Fee Account can not be derived");
	                logger.info("FC - Fee Account can not be derived; No fee account at account level and at customer level");
	            }
	            else
	            {
	            		account = accountCredit;
	            		logger.info("FC - Fees Account equals to credit account");
	            }
	        }
        }
        return account;
    }

    /**
     * Method which derive the account from executing the fee account selection rule, (rule type ID 57).
     * @param feeCalculationType
     * @return Accounts
     *
     */
    private Accounts setAccountCurrencyOfficeFromFeeAccountSelectionRule(FeesCalculationType feeCalculationType, PDO pdo)
                                    throws FeesCalculationException
    {
        Accounts accounts=null;
        try
        {
            Customrs customer;
            String[] arr;
            if (feeCalculationType.equals(FeesCalculationType.DEBIT)||feeCalculationType.equals(FeesCalculationType.AGENT))
                customer=pdo.getNSetDEBIT_CUSTOMER();
            else //credit
                customer=pdo.getNSetCREDIT_CUSTOMER();
            
            if (customer!=null && customer.getCustCode()!=null)
                    arr=new String[]{customer.getCustCode(),pdo.getNSetOffice().getCustCode()};
                else
                    arr=new String[]{pdo.getNSetOffice().getCustCode()};
            
            List<RuleResult> list = m_internalRuleExecutionLogging.executeRule(Admin.getContextAdmin(), MessageConstantsInterface.RULE_TYPE_ID_FEE_ACCOUNT_SELECTION,null,pdo.getString(PDOConstantFieldsInterface.P_MID),arr).getResults() ;
            if (list!=null && list.size()>0)
            {
                accounts= CacheKeys.accountsKey.getSingle(list.get(0).getAction()) ; 
                if (accounts!=null)
                {
                    //BackendTracer GlobalTracer=GlobalTracer;
                    
                    logger.info("FC - Fees Account derived from rule engine");
                }
            }
        }catch(Exception e)
        {
            throw new FeesCalculationException("Rule Engine Exception for Fee Account Selection Rule", e);
        }
        return accounts;
    }
    
    /**
     * Method which derives the account that was entered manually by the user in the message GUI screen; i.e. we need to check relevant 
     * MINF fields and if they aren't empty, use the values there.
     * @param feeCalculationType
     * @param minf
     * @return Accounts
     *
     */
    
    private Accounts setAccountCurrencyOfficeFromMinf(FeesCalculationType feeCalculationType, PDO pdo)
    {
        Accounts accounts=null;
        String sAccount=null;
        String sCurrency=null;
        String sOffice=null;
        if (feeCalculationType.equals(FeesCalculationType.DEBIT) || feeCalculationType.equals(FeesCalculationType.AGENT))
        {
            sAccount=pdo.getString(PDOConstantFieldsInterface.P_DBT_FEE_ACCT_NB);
            sCurrency=pdo.getString(PDOConstantFieldsInterface.P_DBT_FEE_ACCT_CCY);
            sOffice=pdo.getString(PDOConstantFieldsInterface.P_DBT_FEE_ACCT_OFFICE);
        }
        else if (feeCalculationType.equals(FeesCalculationType.CREDIT))
        {
            sAccount=pdo.getString(PDOConstantFieldsInterface.P_CDT_FEE_ACCT_NB);
            sCurrency=pdo.getString(PDOConstantFieldsInterface.P_CDT_ACCT_CCY);
            sOffice=pdo.getString(PDOConstantFieldsInterface.P_CDT_FEE_ACCT_OFFICE);
        }
        
        if (sAccount!=null&&sCurrency!=null&&sOffice!=null
                &&sAccount.length()>0&&sCurrency.length()>0&&sOffice.length()>0)
        {
            accounts= CacheKeys.accountsKey.getSingle(sAccount, sCurrency, sOffice) ;      
            if (accounts!=null)
            {
                //BackendTracer GlobalTracer=GlobalTracer;
                
                logger.info("FC - Fees Account derived from PDO object");
            }else{
            	
            	// in G3 immediate flow the account may not be found in the cache
            	accounts = new Accounts();
            	accounts.setAccNo(sAccount);
            	accounts.setCurrency(sCurrency);
            	accounts.setOffice(sOffice);
            	accounts.setAccType("ACC");
            }
        }
        return accounts;
    }
    
    /**
     * Method which obtaining the Charge Bearer Flag
     * @param basicFeeCalcData
     * @param minf
     *
     */
    private void setChargeBearer(BasicFeesCalculationData basicFeeCalcData, PDO pdo)
    {
        //BackendTracer GlobalTracer=GlobalTracer;
        
        logger.info("FC - Setting Charge Bearer");
        String sChargeBearer = null ; 
        
        if (pdo.getString(PDOConstantFieldsInterface.X_CHRG_BR)==null||pdo.getString(PDOConstantFieldsInterface.X_CHRG_BR).equals(""))
        {
        	MsgTypes msgTypes = pdo.getNSetMsgTypes();
        	if(msgTypes == null) msgTypes = pdo.getNSetOrigMsgTypes();
        	Boolean boolCustPayment = msgTypes.getCustPayment();
        	
        	// Bank payment.
        	if(boolCustPayment != null && boolCustPayment)
           {
              /* basicFeeCalcData.setChargeBearer(ChargeBearer.valueOf(((SystPar)Cache.getInstance().getSingle(CacheKeys.SystParKey
                      ,CacheKeys.SystParKey.prepareCacheEntryKey(pdo.getString(PDOConstantFieldsInterface.P_OFFICE)
                              ,SystemParametersInterface.SYS_PAR_DEFCHGCUS))).getParmValue()));*/ 
        	   
        	   sChargeBearer = SystParKey.getSingleParmValue(PDOConstantFieldsInterface.P_OFFICE, SystemParametersInterface.SYS_PAR_DEFCHGNCUS) ; 
        	   basicFeeCalcData.setChargeBearer(ChargeBearer.valueOf(sChargeBearer)) ; 
           }
           else 
           {
        	   /*
               basicFeeCalcData.setChargeBearer(ChargeBearer.valueOf(((SystPar)Cache.getInstance().getSingle(CacheKeys.SystParKey
                      ,CacheKeys.SystParKey.prepareCacheEntryKey(pdo.getString(PDOConstantFieldsInterface.P_OFFICE)
                              ,SystemParametersInterface.SYS_PAR_DEFCHGNCUS))).getParmValue()));
               */ 
        	   
        	   basicFeeCalcData.setChargeBearer(ChargeBearer.valueOf(
        			   SystParKey.getSingleParmValue(pdo.getString(PDOConstantFieldsInterface.P_OFFICE)
                               ,SystemParametersInterface.SYS_PAR_DEFCHGCUS)));
           }
        }
        else
        {
            if (pdo.getString(PDOConstantFieldsInterface.X_CHRG_BR).equals(ChargeBearer.CRED.name())
                    ||pdo.getString(PDOConstantFieldsInterface.X_CHRG_BR).equals(ChargeBearer.DEBT.name()))
            {
                basicFeeCalcData.setChargeBearer(ChargeBearer.valueOf(pdo.getString(PDOConstantFieldsInterface.X_CHRG_BR)));    
            }
            else //SHAR
            {
                // TODO: need to check what with P Original Message Type....
//                if (pdo.get(PDOConstantFieldsInterface.P_ORIG_MSG_TYPE).equals(ORIGINAL_MESSAGE_TYPE_101))
                if (false)
                {
                    basicFeeCalcData.setChargeBearer(ChargeBearer.CRED);
                }
                else
                {
                    basicFeeCalcData.setChargeBearer(ChargeBearer.valueOf(pdo.getString(PDOConstantFieldsInterface.X_CHRG_BR)));
                }
            }
        }
    }
    
    /**
     * Method which setting the boolean flag (skip fee calculation) in BasicFeeCalculationData to true if:
     * 1) If we're in debit fee calculation, and MINF.P_DBT_APPLY_FEE is 'WAIVE'
     *    or if we're in credit fee calculation, and MINF.P_CDT_APPLY_FEE is 'WAIVE'.
     * 2) If we're in debit fee calculation, and MINF.P_DBT_AMT is empty 
     *    or if we're in credit fee calculation and MINF.P_CDT_AMT is empty.
     * 3) Payment does not include receiver charges   
     * 4) Executing the 'Bypass Fee' rule, (rule type ID 50)
     *  
     * @param basicFeeCalcData
     * @param feesCalculationType
     * @param minf
     *
     */
    private Customrs setSkipCalculationProcess(BasicFeesCalculationData basicFeeCalcData, FeesCalculationType feesCalculationType,
            PDO pdo) throws FeesCalculationException
    {
        Customrs customer=null;
        //BackendTracer GlobalTracer=GlobalTracer;
        
        logger.info("FC - Check if to skip fee calculation");
        if ((feesCalculationType.equals(FeesCalculationType.DEBIT)&&pdo.getString(PDOConstantFieldsInterface.P_DBT_APPLY_FEE)!= null
        		&&pdo.getString(PDOConstantFieldsInterface.P_DBT_APPLY_FEE).equals(ApplyFee.WAIVE.name()))
                ||(feesCalculationType.equals(FeesCalculationType.CREDIT)&&pdo.getString(PDOConstantFieldsInterface.P_CDT_APPLY_FEE)!=null
                        &&pdo.getString(PDOConstantFieldsInterface.P_CDT_APPLY_FEE).equals(ApplyFee.WAIVE.name())))
        {
            basicFeeCalcData.setSkipFeeCalculation(true);
//            m_daoFeeCalculation.deleteFromMSG_FEES(minf.getMID(),feesCalculationType);
            if (feesCalculationType.equals(FeesCalculationType.DEBIT))
                logger.info(String.format("FC - Skip fee calculation: calculation type=Debit,  debit apply fee={}"
                                ,pdo.getString(PDOConstantFieldsInterface.P_DBT_APPLY_FEE)));
            else if (feesCalculationType.equals(FeesCalculationType.CREDIT))
                logger.info(String.format("FC - Skip fee calculation: calculation type=Credit,  credit apply fee={}"
                                ,pdo.getString(PDOConstantFieldsInterface.P_CDT_APPLY_FEE)));
        }
        else if ((feesCalculationType.equals(FeesCalculationType.DEBIT)&&pdo.getDecimal(PDOConstantFieldsInterface.P_DBT_AMT)==null)
                ||(feesCalculationType.equals(FeesCalculationType.CREDIT)&&pdo.getDecimal(PDOConstantFieldsInterface.P_CDT_AMT)==null)
                ||(feesCalculationType.equals(FeesCalculationType.AGENT)&&(pdo.getDecimal(PDOConstantFieldsInterface.P_CDT_AMT)==null||pdo.getDecimal(PDOConstantFieldsInterface.P_DBT_AMT)==null)))
        {
            basicFeeCalcData.setSkipFeeCalculation(true);
            if (feesCalculationType.equals(FeesCalculationType.DEBIT))
                logger.info(String.format("FC - Skip fee calculation: calculation type=Debit,  debit amount={}"
                                ,pdo.getString(PDOConstantFieldsInterface.P_DBT_AMT)));
            else if (feesCalculationType.equals(FeesCalculationType.CREDIT))
                logger.info(String.format("FC - Skip fee calculation: calculation type=Credit,  credit amount={}"
                                ,pdo.getString(PDOConstantFieldsInterface.P_CDT_AMT)));
            
        }
        else
        {
            try
            {
                List<RuleResult> list;
                String sFeeCalcType=null;
                String[] arr;
                
                String drAgentFee ="";
                
                if (feesCalculationType.equals(FeesCalculationType.AGENT))
                {
                    drAgentFee = CacheKeys.SystParKey.getSingleParmValue(SystemParametersInterface.SYS_PAR_DRAGENTFEE);
                    drAgentFee = GlobalUtils.isNullOrEmpty(drAgentFee) ? GlobalConstants.No : drAgentFee;
                    
                    sFeeCalcType=FeesCalculationType.AF.name();
                    
                    customer = drAgentFee.equals(GlobalConstants.Yes) ? pdo.getNSetDEBIT_CUSTOMER() : pdo.getNSetCREDIT_CUSTOMER();  
                }
                
                else if (feesCalculationType.equals(FeesCalculationType.DEBIT))
                {
                    sFeeCalcType=FeesCalculationType.DR.name();
                    customer=pdo.getNSetDEBIT_CUSTOMER();
                }
                else if (feesCalculationType.equals(FeesCalculationType.CREDIT))
                {
                    sFeeCalcType=FeesCalculationType.CR.name();
                    customer=pdo.getNSetCREDIT_CUSTOMER();
                }
                
                if (customer!=null && customer.getCustCode()!=null)
                    arr=new String[]{customer.getCustCode(), pdo.getNSetOffice().getCustCode()};
                else
                    arr=new String[]{pdo.getNSetOffice().getCustCode()};
                
                logger.info("Going to RULE_TYPE_ID_FEE_BYPASS with : {} and {}.",arr[0],arr[1] );
                
                list=m_internalRuleExecutionLogging.executeRule(Admin.getContextAdmin(), MessageConstantsInterface.RULE_TYPE_ID_FEE_BYPASS
                                        ,sFeeCalcType,pdo.getString(PDOConstantFieldsInterface.P_MID),arr).getResults() ;
                if (list!=null && !list.isEmpty() && list.get(0).getAction().equals(BYPASS_ACTION_ID))
                {
                    basicFeeCalcData.setSkipFeeCalculation(true);
                    logger.info("FC - Skip fee calculation: Rule - BYPASS");
                }
               
            }
            catch(Exception e)
            {
            	logger.error(e.getMessage());
            }
        }
        return customer;
    }
    /**
     * Method which sets the Min/Max fee limits to BasicFeeCalculationFata according to CREDIT/DEBIT customer if exist
     * if not, then according to system parameters. 
     * @param basicFeeCalcData
     * @param feeCalculationType
     * @param minf
     *
     */
    private void setFeesLimit(BasicFeesCalculationData basicFeeCalcData,PDO pdo)
    {
        //BackendTracer GlobalTracer=GlobalTracer;
        
        logger.info("FC - Set Fees Limit");
        Customrs customers=basicFeeCalcData.getCustomer();

        if (customers != null && customers.getMinFloorAmt()!=null&&customers.getMinFloorAmt()>0)
        {
            basicFeeCalcData.setFloorAmnt(customers.getMinFloorAmt().floatValue());
        }
        else
        {
            System.currentTimeMillis();   
            String sValue= SystParKey.getSingleParmValue(pdo.getString(PDOConstantFieldsInterface.P_OFFICE)
                            		,SystemParametersInterface.SYS_PAR_FLOORAMT) ; 
            
            //System.out.println("FC - Fees Limit Floor Amount from cache "+(System.currentTimeMillis()-lTime)+"ms");
            Float fValue=sValue!=null&&sValue.length()>0?Float.valueOf(sValue):null;
            basicFeeCalcData.setFloorAmnt(fValue);
        }
        
        if (customers != null && customers.getMaxFeeAmount()!=null&&customers.getMaxFeeAmount()>0)
        {
            basicFeeCalcData.setMaxFee(customers.getMaxFeeAmount().floatValue());
        }
        else
        {
            System.currentTimeMillis();
            String sValue= SystParKey.getSingleParmValue(pdo.getString(PDOConstantFieldsInterface.P_OFFICE)
                            ,SystemParametersInterface.SYS_PAR_MAXFEEAMT) ; 
            
            //System.out.println("FC - Fees Limit Max Amount from cache "+(System.currentTimeMillis()-lTime)+"ms");
            Float fValue=sValue!=null&&sValue.length()>0?Float.valueOf(sValue):null;
            basicFeeCalcData.setMaxFee(fValue);
        }
        
    }
    /**
     * Method which sets the Unwind method to BasicFeeCalculationData according to system parameters
     * @param basicFeeCalcData
     * @param minf
     *
     */
    private void setUnwindMethod(BasicFeesCalculationData basicFeeCalcData,PDO pdo)
    {
        //BackendTracer GlobalTracer=GlobalTracer;
        
        
        /*
        UnwindMethodType unwindMethod=UnwindMethodType.valueOf(((SystPar)Cache.getInstance().getSingle(CacheKeys.SystParKey
                ,CacheKeys.SystParKey.prepareCacheEntryKey(pdo.getString(PDOConstantFieldsInterface.P_OFFICE)
                        ,SystemParametersInterface.SYS_PAR_FEEUNWINDMETHOD))).getParmValue());
        */ 
        
        UnwindMethodType unwindMethod=UnwindMethodType.valueOf(
        			SystParKey.getSingleParmValue(pdo.getString(PDOConstantFieldsInterface.P_OFFICE)
                        ,SystemParametersInterface.SYS_PAR_FEEUNWINDMETHOD)) ; 

        basicFeeCalcData.setUnwindMethodType(unwindMethod);
        logger.info("FC - Set Unwind method "+unwindMethod.name());
    }
    
    /**
     * Method which cleans the fee information from Message Information
     * @param feeCalcType
     * @param minf void
     *
     */
    private void cleanCurrentFeeInfo(FeesCalculationType feeCalcType,PDO pdo)
    {
//        m_daoFeeCalculation.deleteFromMSG_FEEnotManual(minf.getMID(),feeCalcType);
        //BackendTracer GlobalTracer=GlobalTracer;
        
        logger.info("FC - Clean Current Fee Info");
        if (feeCalcType.equals(FeesCalculationType.DEBIT))
        {
            pdo.set(PDOConstantFieldsInterface.D_DBT_FEE_ACCT_AMT,(Object)null);
            pdo.set(PDOConstantFieldsInterface.P_DBT_FEE_ACCT_NB,(Object)null);
            pdo.set(PDOConstantFieldsInterface.D_DBT_FEE_ACCT_CCY,(Object)null);
            pdo.set(PDOConstantFieldsInterface.P_DBT_FEE_ACCT_OFFICE,(Object)null);
            pdo.set(PDOConstantFieldsInterface.D_DBT_FEE_PMT_DEDUCT_AMT,(Object)null);
            pdo.set(PDOConstantFieldsInterface.D_DBT_FEE_PMT_CCY,(Object)null);
            pdo.set(PDOConstantFieldsInterface.D_DBT_FEE_PMT_DEDUCT_BASEEQVT,(Object)null);
        }
        else if (feeCalcType.equals(FeesCalculationType.CREDIT))
        {
            pdo.set(PDOConstantFieldsInterface.D_CDT_FEE_ACCT_AMT,(Object)null);
            pdo.set(PDOConstantFieldsInterface.P_CDT_FEE_ACCT_NB,(Object)null);
            pdo.set(PDOConstantFieldsInterface.P_CDT_FEE_ACCT_CCY,(Object)null);
            pdo.set(PDOConstantFieldsInterface.P_CDT_FEE_ACCT_OFFICE,(Object)null);
            pdo.set(PDOConstantFieldsInterface.D_CDT_FEE_PMT_DEDUCT_AMT,(Object)null);
            pdo.set(PDOConstantFieldsInterface.D_CDT_FEE_PMT_CCY,(Object)null);
            pdo.set(PDOConstantFieldsInterface.D_CDT_FEE_ACCT_BASEEQVT,(Object)null);
            pdo.set(PDOConstantFieldsInterface.D_CDT_FEE_PMT_DEDUCT_BASEEQVT,(Object)null);
        }
        else
        {
//            pdo.set(PDOConstantFieldsInterface.P_AGENT_FEE_AMT,(Object)null);
//            pdo.set(PDOConstantFieldsInterface.P_AGENT_FEE_CCY,(Object)null);
        }
    }
    
    
    @Expose
    @LoadPDO
    public FeesCalculationOutputData adjustMsgFees(String mid) throws FeesCalculationException
    {
    	FeesCalculationOutputData output = new FeesCalculationOutputData();
    	return adjustMsgFees(mid, output);

    }
    
    @Expose
    @LoadPDO    
    public FeesCalculationOutputData perform71gUnwind(String mid) throws FeesCalculationException
    {
    	FeesCalculationOutputData output = new FeesCalculationOutputData();
    	PDO pdo = PaymentDataFactory.load(mid);
    	
        String feeProcSts = pdo.getString(PDOConstantFieldsInterface.MF_FEE_PROC_STS) ;
        
//      if fee calculation service was processed...
        if (feeProcSts != null && feeProcSts.equals(MessageConstantsInterface.MONITOR_FLAG_PROCESSED))
	    {
    	
	    	BasicFeesCalculationData basicFeeCalcData = new BasicFeesCalculationData();
	    	
	    	
	    	setUnwindMethod(basicFeeCalcData, pdo);
    	
	    	List<MsgFees> msgFees = pdo.isNew() ? pdo.getListMSG_FEES() : pdo.getNSetListMSG_FEES();
	    	if (pdo.getNSetListMSG_FEES() != null)
	    	{
	//	    	derived logical fields accumulation. 
		    	setDerivedFeeAmountLogicalFields(msgFees, output.getFeedback());
		    	if (output.getFeedback().isSuccessful())
		    	{
			        boolean shouldAdjustDerivedFields = isMsgFeesAdjustedAccordingToIncomingAgentFees(pdo,msgFees,null, output, basicFeeCalcData, output.getFeedback());
			        
			//        After the unwinding of the incoming agent fees need to recalculate the totals all over again.		        
			        if (output.getFeedback().isSuccessful() && shouldAdjustDerivedFields) 
			        {
			            setDerivedFeeAmountLogicalFields(msgFees,output.getFeedback());
			        }
		    	}
	    	}
	    }    	
    	return output;
    }
    
    private FeesCalculationOutputData adjustMsgFees(String mid, FeesCalculationOutputData output) throws FeesCalculationException
    {
    	
    	PDO pdo = PaymentDataFactory.load(mid);
    	
        String feeProcSts = pdo.getString(PDOConstantFieldsInterface.MF_FEE_PROC_STS) ;
        
//      if fee calculation service was processed...
        if (feeProcSts != null && feeProcSts.equals(MessageConstantsInterface.MONITOR_FLAG_PROCESSED))
	    {
    	
        	
	    	List<MsgFees> msgFees = pdo.isNew() ? pdo.getListMSG_FEES() : pdo.getNSetListMSG_FEES();
	    	
	    	if (msgFees != null && msgFees.size() > 0)
	    	{
		    	BasicFeesCalculationData basicFeeCalcData = new BasicFeesCalculationData();
		    	
		    	basicFeeCalcData.setCustomer(createFinalCustomerWithMaxFeeAndFloorAmtAccordingToDebitAndCreditCustomers(pdo));
		    	
		    	setUnwindMethod(basicFeeCalcData, pdo);
		    	
		    	setFeesLimit(basicFeeCalcData, pdo); 
//		    	long time = System.nanoTime();
		        setDerivedFeeAmountLogicalFields(msgFees, output.getFeedback()); 
		        //GlobalConstants.listForSysout.add("FC: 		step1 = "+((System.nanoTime() - time)/1000000));
//		        time = System.nanoTime();
		        if (output.getFeedback().isSuccessful())
		        {
		        	
			        isMaxAndFloorValidationAndAdjustmentOccured(pdo, msgFees, basicFeeCalcData, null, output.getFeedback());
			        
			        if (output.getFeedback().isSuccessful())
			        {
				        boolean shouldAdjustDerivedFields = isMsgFeesAdjustedAccordingToIncomingAgentFees(pdo,msgFees,null, output, basicFeeCalcData, output.getFeedback());
				        
		//	            After the unwinding of the incoming agent fees need to recalculate the totals all over again.		        
				        if (output.getFeedback().isSuccessful() && shouldAdjustDerivedFields) 
				        {
				            setDerivedFeeAmountLogicalFields(msgFees, output.getFeedback());
				            //GlobalConstants.listForSysout.add("FC: 		step 2 = "+((System.nanoTime() - time)/1000000));
				        }
			        }
		        }
	    	}else
	    	{
	    		setDerivedFeeAmountLogicalFields(msgFees, output.getFeedback());
	    	}
	    }    	
        return output;    
    }
    
    
    
    private Customrs createFinalCustomerWithMaxFeeAndFloorAmtAccordingToDebitAndCreditCustomers(PDO pdo)
    {
    	Customrs debitCustomer = pdo.getNSetDEBIT_CUSTOMER();
    	Customrs creditCustomer = pdo.getNSetCREDIT_CUSTOMER();
    	
    	Customrs customer = null;
//    	if debit customer is null, use credit customer
    	if (debitCustomer == null)
    		customer = creditCustomer;
//    	if credit customer is null, use debit customer
    	else if (creditCustomer == null)
    		customer = debitCustomer;
    	else
    	{
//    		fee limit should be minimum between debit and credit customers.
    		customer = new Customrs();
    		Double maxAmount =null;
    		
    		if (debitCustomer.getMaxFeeAmount() != null && creditCustomer.getMaxFeeAmount() != null)
    		{
    			maxAmount = creditCustomer.getMaxFeeAmount() < debitCustomer.getMaxFeeAmount() ? creditCustomer.getMaxFeeAmount() : debitCustomer.getMaxFeeAmount();
    		}else if (debitCustomer.getMaxFeeAmount() != null)
    		{
    			maxAmount = debitCustomer.getMaxFeeAmount();
    		}else 
    		{
    			maxAmount = creditCustomer.getMaxFeeAmount();
    		}
    		
    		Double floorAmount = null;
    		
    		if (debitCustomer.getMinFloorAmt() != null && creditCustomer.getMinFloorAmt() != null)
    		{
    			floorAmount = creditCustomer.getMinFloorAmt() > debitCustomer.getMinFloorAmt() ? creditCustomer.getMinFloorAmt() : debitCustomer.getMinFloorAmt();
    		}else if (debitCustomer.getMinFloorAmt() != null)
    		{
    			floorAmount = debitCustomer.getMinFloorAmt();
    		}else
    		{
    			floorAmount = creditCustomer.getMinFloorAmt();
    		}
    		
    		customer.setMaxFeeAmount(maxAmount);
    		customer.setMinFloorAmt(floorAmount);
    		
    	}
    	
    	return customer;
    	
    }
    
    
    
    
    
    private boolean isMsgFeesAdjustedAccordingToIncomingAgentFees(PDO pdo, List<MsgFees> msgFeesList, Map currencyConvMap
                                                                    , FeesCalculationOutputData output, BasicFeesCalculationData basicFeeCalcData,
                                                                    Feedback feedback)throws FeesCalculationException
    {
        boolean is71gExist = false;
        boolean is71gGreaterThenCalculatedOrWithinTolarance = false;
        
//        if 71G amount is greater the calculated amount, then both of this 
        boolean isAboveTolarance = false;
        
//        if (pdo.getDecimal(PDOConstantFieldsInterface.OX_RCVR_CHRGS_INF,1,PDOConstantFieldsInterface.OX_RCVR_CHRGS_INF_AMT) != null)
      //  if (pdo.getDecimal(PDOConstantFieldsInterface.OX_RCVR_CHRGS_INF_AMT) != null)
           if (getReciverCharges(pdo) != null)
        {
//            String fromCcy = pdo.getString(PDOConstantFieldsInterface.OX_RCVR_CHRGS_INF,1,PDOConstantFieldsInterface.OX_RCVR_CHRGS_INF_CCY);
        	String fromCcy = (String) pdo.get(new Object[] {PDOConstantFieldsInterface.OX_CHRGS_INF, 0, PDOConstantFieldsInterface.OX_CHRGS_INF_CCY});
            
            if (!GlobalUtils.isNullOrEmpty(fromCcy))
            {
            	is71gExist = true;
            	
            	double inAgentFeesCdtAccAmt = pdo.getDecimal(PDOConstantFieldsInterface.D_IN_AF_CDT_ACCT_AMT).doubleValue();
            	
                double  dbtFeePmtDeductAmt = pdo.getDecimal(PDOConstantFieldsInterface.D_DBT_FEE_PMT_DEDUCT_AMT).doubleValue();
                
//                    if 71G amount is less then calculated, check tolerance section below. 
                if (inAgentFeesCdtAccAmt < dbtFeePmtDeductAmt)
                {
                    double feeTolerancePrcnt=Double.valueOf(CacheKeys.SystParKey.getSingleParmValue(pdo.getString(PDOConstantFieldsInterface.P_OFFICE)
                            , SystemParametersInterface.SYS_PAR_FEETOLERANCE_PRCNT));
                    
                    double amount = (dbtFeePmtDeductAmt *(100 - feeTolerancePrcnt))/100;
    //            check if above tolerance                
                    if (amount > inAgentFeesCdtAccAmt)
                    {
                    	isAboveTolarance = true;
                        ProcessError pError=new ProcessError(ProcessErrorConstants.DifferenceBetweenTheReceiverCharges,new Object[] {feeTolerancePrcnt});
                        ErrorAuditUtils.setErrors(pError,pdo.getIsHistory());
                    }else //amount within the tolerance.
                    {
                    	is71gGreaterThenCalculatedOrWithinTolarance = true;
                    }
                }else
                {
                	is71gGreaterThenCalculatedOrWithinTolarance = true;
                }
            }
        }
        int[] numberOfUnwindExecuted = new int[1];
        boolean flag = performMsgFeesAdjustedAccordingToIncomingAgentFees(pdo, basicFeeCalcData,msgFeesList, is71gExist, isAboveTolarance
        		, is71gGreaterThenCalculatedOrWithinTolarance,numberOfUnwindExecuted,feedback);

        
//		error - cannot find P&L account for the incoming 71G
//        if (feedback.isSuccessful() && numberOfUnwindExecuted[0] == 0 && pdo.getDecimal(PDOConstantFieldsInterface.OX_RCVR_CHRGS_INF,1,PDOConstantFieldsInterface.OX_RCVR_CHRGS_INF_AMT) !=null 
//        		&& pdo.getDecimal(PDOConstantFieldsInterface.OX_RCVR_CHRGS_INF,1,PDOConstantFieldsInterface.OX_RCVR_CHRGS_INF_AMT).doubleValue() > 0)
        BigDecimal reciverCharges  =  getReciverCharges(pdo);
        if (feedback.isSuccessful() && numberOfUnwindExecuted[0] == 0 && reciverCharges !=null 
        		&& reciverCharges.doubleValue() > 0)

    	{
            ProcessError pError=new ProcessError(ProcessErrorConstants.PL_AccountNotFoundFor71G);
            configureErrorFeedback(pError.getErrorCode(),pError.getDescription(),feedback);
            ErrorAuditUtils.setErrors(pError,pdo.getIsHistory());

    	}
        
        
        return flag;
    }
    
    private BigDecimal getReciverCharges(PDO pdo) {
    	BigDecimal reciverCharges = null;
    	if (pdo.countOccurrences(PDOConstantFieldsInterface.OX_CHRGS_INF) > 0) {
	    	if ("DEBT".equals(pdo.getString(PDOConstantFieldsInterface.OX_CHRG_BR))) {
	    		//reciverCharges = new BigDecimal((String) pdo.get(new Object[] {PDOConstantFieldsInterface.OX_CHRGS_INF, 0, PDOConstantFieldsInterface.OX_CHRGS_INF_AMT}));
	    		reciverCharges =  (BigDecimal) pdo.get(new Object[] {PDOConstantFieldsInterface.OX_CHRGS_INF, 0, PDOConstantFieldsInterface.OX_CHRGS_INF_AMT});
	    	}
    	}
    	return reciverCharges;    	
    }
    
    private boolean performMsgFeesAdjustedAccordingToIncomingAgentFees(PDO pdo, BasicFeesCalculationData basicFeeCalcData, List<MsgFees> msgFeesList
    																		, boolean is71gExist, boolean isAboveTolarance
    																		, boolean is71gGreaterThenCalculatedOrWithinTolarance,
    																		int[] numberOfUnwindExecuted, Feedback feedback) throws FeesCalculationException
    {
        String handle71gGapValue = pdo.getString(PDOConstantFieldsInterface.MU_HANDLE_71G_GAP);
        boolean isMT191AutoGen = pdo.getBoolean(PDOConstantFieldsInterface.D_MT191AUTOGEN) != null ? pdo.getBoolean(PDOConstantFieldsInterface.D_MT191AUTOGEN) : false;
        boolean handle71gGapValueIsForce = handle71gGapValue.equals(MessageConstantsInterface.MONITOR_FLAG_FORCE);
        boolean handle71gGapValueIsGenerate191 = handle71gGapValue.equals(MessageConstantsInterface.MONITOR_FLAG_GENERATE_191);
    	List<MsgFees> requestMsgFeesList=null;
    	
    	boolean flag = false;
    	
//    	IF 71G doesn't exists and D_MT191AUTOGEN = false Then
//    		Skip the unwinding process  

    	if (is71gExist || isMT191AutoGen)
    	{
//     		IF 71G exists and above tolerance when comparing it against the total calculated fees   
//    			AND MU_HANDLE_71G_GAP not in ('F' - force accept, 'G' - generate a 191) - the message was not released from INCOMING71G' queue then 
//    				Send the message to 'INCOMING71G' (i.e. set P_MSG_STS = 'INCOMING71G').
//    				Skip the unwinding process

	        if (is71gExist && isAboveTolarance && !handle71gGapValueIsForce && !handle71gGapValueIsGenerate191)
	        {
	        	pdo.set(PDOConstantFieldsInterface.P_MSG_STS, MessageConstantsInterface.MESSAGE_STATUS_INCOMING71G);
	        } 
//	        IF 71G exists and within tolerance or 71G converted to payment currency is greater or equal than the calculated DR fee amount in payment currency (as is done today) 
//		        OR 
//	    	    D_MT191AUTOGEN = true 
//	        	OR 
//	        	MU_HANDLE_71G_GAP in ('F' - force accept, 'G' - generate a 191) 
	
	        else if ((is71gExist && is71gGreaterThenCalculatedOrWithinTolarance) || isMT191AutoGen 
	        		|| handle71gGapValueIsForce || handle71gGapValueIsGenerate191)
	        {
	//          We are going to support 2 methods of adjustment - Related by percent and Related by amount
	//        	even if we don't have at all 71G - in this case the unwind Adjustment Ratio should be 100% => all the fee amounts should be zero, therefore,
	//        	use unwind by percentage with adjustment percentage zero.
	        	
	//          by percentage 
	          if (pdo.getDecimal(PDOConstantFieldsInterface.D_DBT_FEE_PMT_DEDUCT_AMT).doubleValue() != 0 
	        		  && (!is71gExist || basicFeeCalcData.getUnwindMethodType().equals(UnwindMethodType.ALL_REL_PCT)))
	          {
	        	  double adjustmentPercentage = 0;
	        	  
	        	  if (is71gExist)
	        	  {
		//              IF by percent then the adjustment ratio should be D_IN_AF_CDT_ACCT_AMT / D_DBT_FEE_PMT_DEDUCT_AMT (which can be bigger then 1).
		              adjustmentPercentage = pdo.getDecimal(PDOConstantFieldsInterface.D_IN_AF_CDT_ACCT_AMT).doubleValue() / 
		                                                  pdo.getDecimal(PDOConstantFieldsInterface.D_DBT_FEE_PMT_DEDUCT_AMT).doubleValue();
	        	  }
	              
	//              In this case we'll scan all the message fees Debit Entries with MSG_FEES.FEE_ACC_AMOUNT_PRE_IN_AF <> 0 and change the 
	//              FEE_AMOUNT according to the following formula - MSG_FEES.FEE_AMOUNT = MSG_FEES.FEE_AMOUNT * Adjustment Ratio.  
	//              In addition need to update accordingly all the amount fields except the new MSG_FEES filed (FEE_ACC_AMOUNT_PRE_IN_AF) which should remain unchanged.
	        	  requestMsgFeesList = unwindIncomingAgentFeesByPercentage(pdo, msgFeesList,adjustmentPercentage, handle71gGapValueIsGenerate191, isMT191AutoGen,numberOfUnwindExecuted,feedback);
	              
	          }else //by amount
	          {
	//              IF by Amount then the adjustment amount should be D_DBT_FEE_PMT_DEDUCT_AMT minus D_IN_AF_CDT_ACCT_AMT 
	//              (which can be negative in case we received a bigger gent fee amount than our calculation) 
	
	
	              double amount = pdo.getDecimal(PDOConstantFieldsInterface.D_DBT_FEE_PMT_DEDUCT_AMT).doubleValue() 
	                                  - pdo.getDecimal(PDOConstantFieldsInterface.D_IN_AF_CDT_ACCT_AMT).doubleValue();
	              
	              
	              requestMsgFeesList = unwindIncomingAgentFeesByAmount(pdo, msgFeesList,amount, handle71gGapValueIsGenerate191, isMT191AutoGen, numberOfUnwindExecuted, feedback);
	              
	          }
        	  if (feedback.isSuccessful() && requestMsgFeesList != null && requestMsgFeesList.size() > 0)
        	  {
        		  msgFeesList.addAll(requestMsgFeesList);
        	  }
	          
	          flag = true;
	        	
	        }
    	}        
        return flag;       
    	
    }
    
    @Expose
    public Feedback unwindIncomingAgentFeesByPercentage(String mid, Double percentage)
    {
    	Feedback feedback = new Feedback();
    	
    	PDO pdo = PaymentDataFactory.load(mid);
    	
        String handle71gGapValue = pdo.getString(PDOConstantFieldsInterface.MU_HANDLE_71G_GAP);
        boolean isMT191AutoGen = pdo.getBoolean(PDOConstantFieldsInterface.D_MT191AUTOGEN) != null ? pdo.getBoolean(PDOConstantFieldsInterface.D_MT191AUTOGEN) : false;
        boolean handle71gGapValueIsGenerate191 = handle71gGapValue.equals(MessageConstantsInterface.MONITOR_FLAG_GENERATE_191);
    	
        List<MsgFees> msgFeesList = pdo.isNew() ? pdo.getListMSG_FEES() : pdo.getNSetListMSG_FEES();
    	int[] numberOfUnwindExecuted = new int[1];
    	
    	if (msgFeesList != null)
    	{
    		List<MsgFees> requestMsgFees = unwindIncomingAgentFeesByPercentage(pdo, msgFeesList, percentage ,handle71gGapValueIsGenerate191,isMT191AutoGen,numberOfUnwindExecuted, feedback);
    		msgFeesList.addAll(requestMsgFees);
    	}
    	return feedback;
    }
    
    
    private List<MsgFees> unwindIncomingAgentFeesByPercentage(PDO pdo, List<MsgFees> msgFeesList, double percentage, boolean handle71gGapValueIsGenerate191
    		, boolean isMT191AutoGen, int[] numberOfUnwindExecuted, Feedback feedback)
    {
        int iSize=msgFeesList.size();
        //BackendTracer GlobalTracer=GlobalTracer;
        
        
        List<MsgFees> requestMsgFees = new ArrayList<MsgFees>();
        for (int i=0;i<iSize;i++)
        {
            MsgFees msgFee=msgFeesList.get(i);
            
            logger.info(String.format("FC - Fee unwind Incoming Agent Fees By Percentage, number: ",(i+1)));
            if (msgFee.getPayingParty().equals(FeesCalculationType.DR.name()) && msgFee.getId().getApply().equals(ApplyFee.NOW.name()))
            {
                if (msgFee.getIsPosted())
                {
                    //error "Agent fees |1 |2 (fee type |3) were already posted, cannot unwind fees."
                    ProcessError pError=new ProcessError(ProcessErrorConstants.AgentFeesAlreadyPosted,new Object[] {msgFee.getFeeAmount(),msgFee.getFeeCurrency(),msgFee.getId().getFeeTypeUid()});
                    pError.setSeverity(ErrorSeverity.critical);
                    configureErrorFeedback(pError.getErrorCode(),pError.getDescription(),feedback);
                    ErrorAuditUtils.setErrors(pError,pdo.getIsHistory());
                    continue;
                }
        		if (isMT191AutoGen)
        		{

        			msgFee.getId().setApply(ApplyFee.REQUEST.name());
        			
//        			it is possible that msg fee is deducted from account, therefore, fee amount in payment currency should be set.
        			if (msgFee.getFeeAmountInPmtCcy() == null)
        			{
        				
                    	double amount = convertCurrency(msgFee.getFeeCurrency()
                                ,pdo.getString(PDOConstantFieldsInterface.P_CDT_ACCT_CCY),msgFee.getFeeAmount(),FeesCalculationType.DEBIT,pdo,true
                                ,pdo.getString(PDOConstantFieldsInterface.P_BASE_CCY),null, feedback);
                            
                        if (feedback.isSuccessful())
                        {
                        	msgFee.setFeeAmountInPmtCcy(amount);
                        }
        				
        			}

        		}else 
        		{
        	        msgFee.setFeeAmountPmtCcyPreInAf(msgFee.getFeeAmountInPmtCcy());
        	        
        	        numberOfUnwindExecuted[0]++;
        	        updateMsgFeeRecordByPercentage(pdo, msgFee, percentage, true);
        	        if (handle71gGapValueIsGenerate191)
        	        {
//                    	this method will create new msg fee record with apply fee = 'REQUEST'
                    	createRequestMsgFees(pdo, msgFee, requestMsgFees);

        	        }

        		}
        	}
        }
        
        return requestMsgFees;
    }
    
    private void updateMsgFeeRecordByPercentage(PDO pdo, MsgFees msgFee, double percentage, boolean shouldUpdatefeeAmountInPmtCcy)
    {
	        //BackendTracer GlobalTracer=GlobalTracer;
	        
	    	String sBaseOfficeCurrency = pdo.getString(PDOConstantFieldsInterface.P_BASE_CCY);
	    	
	    	if(logger.isInfoEnabled()){
	    		logger.info(String.format("FC - Fee amount {} {} changed to {} {}"
	    				,msgFee.getFeeAmount(),msgFee.getFeeCurrency(),(msgFee.getFeeAmount()*percentage),msgFee.getFeeCurrency()));
	    	}
	        msgFee.setFeeAmount(GlobalUtils.adjustPrecision((msgFee.getFeeAmount()*percentage)
	                ,(msgFee.getFeeCurrency())));
	        
	        if(logger.isInfoEnabled()){       
	        	logger.info(String.format("FC - Fee base amount {} {} reduced to {} {}"
	        			,msgFee.getFeeBaseAmount(),sBaseOfficeCurrency,(msgFee.getFeeBaseAmount()*percentage),sBaseOfficeCurrency));
	        }
	        msgFee.setFeeBaseAmount(GlobalUtils.adjustPrecision((msgFee.getFeeBaseAmount()*percentage)
	                ,(sBaseOfficeCurrency)));
	        if (msgFee.getFeePnlAccountCurrency()!=null && msgFee.getFeePnlAccountCurrency().length()>0)
	        {
	        	
	        	logger.info(String.format("FC - Fee PnL amount {} {} reduced to {} {}"
	        			,msgFee.getFeePnlAmount(),msgFee.getFeePnlAccountCurrency()
	        			,(msgFee.getFeePnlAmount()*percentage),msgFee.getFeePnlAccountCurrency()));
	        
	            msgFee.setFeePnlAmount(GlobalUtils.adjustPrecision(msgFee.getFeePnlAmount()*percentage
	                    ,(msgFee.getFeePnlAccountCurrency())));
	        }
	        if (msgFee.getFeeAccAmount() != null)
	        {
	        	if (msgFee.getFeeAccOrPmtCcy() == null) setFeeAccOrPmtCcy(pdo,msgFee);
	        	logger.info(String.format("FC - Fee account amount {} {} reduced to {} %s"
			                ,msgFee.getFeeAccAmount(),msgFee.getFeeAccOrPmtCcy()
			                ,(msgFee.getFeeAccAmount()*percentage),msgFee.getFeeAccOrPmtCcy()));
	        	
		        double feeAccAmt = GlobalUtils.adjustPrecision(msgFee.getFeeAccAmount()*percentage
		                ,(msgFee.getFeeAccOrPmtCcy()));
		        
		        msgFee.setFeeAccAmount(feeAccAmt);
	        }
	        
	            
	        if (shouldUpdatefeeAmountInPmtCcy && msgFee.getFeeAmountInPmtCcy()!= null )
	        {
	        	if (msgFee.getFeeAccOrPmtCcy() == null) setFeeAccOrPmtCcy(pdo,msgFee);
	        	logger.info(String.format("FC - Fee amount in payment currency {} {} reduced to {} {}"
	        				,msgFee.getFeeAmountInPmtCcy(),msgFee.getFeeAccOrPmtCcy()
	        				,(msgFee.getFeeAmountInPmtCcy()*percentage)
	        				,msgFee.getFeeAccOrPmtCcy()));
	        	
	            msgFee.setFeeAmountInPmtCcy(GlobalUtils.adjustPrecision(msgFee.getFeeAmountInPmtCcy()*percentage
	                    ,(msgFee.getFeeAccOrPmtCcy())));
	        }
	        
    }
    
    
    private List<MsgFees> unwindIncomingAgentFeesByAmount(PDO pdo, List<MsgFees> msgFeesList, double feeAmountInPmtCcyToUnwind,boolean handle71gGapValueIsGenerate191
    		, boolean isMT191AutoGen,int[] numberOfUnwindExecuted, Feedback feedback) throws FeesCalculationException
    {
        double totalAgentAccAmt=0;
        boolean isAgentAccAmtGreaterThenTotal = false;
        boolean shouldContinueWithCalculations = true;
        MsgFees msgFee;
        //BackendTracer GlobalTracer=GlobalTracer;
        
        String baseCcy = pdo.getString(PDOConstantFieldsInterface.P_BASE_CCY);
        List<MsgFees> requestMsgFees = new ArrayList<MsgFees>();
        
        int length = msgFeesList.size();
        
        for (int i=0;i< length; i++)
        {
            msgFee=msgFeesList.get(i);
            
            if (msgFee.getFeeAccOrPmtCcy() == null) setFeeAccOrPmtCcy(pdo,msgFee);
            
            logger.info(String.format("FC - Fee unwind Incoming Agent Fees By Amount, number: ",(i+1)));
            if (msgFee.getPayingParty().equals(FeesCalculationType.DR.name()) && msgFee.getId().getApply().equals(ApplyFee.NOW.name()))
            {
                if (msgFee.getIsPosted())
                {
                    //error "Agent fees |1 |2 (fee type |3) were already posted, cannot unwind fees."
                    ProcessError pError=new ProcessError(ProcessErrorConstants.AgentFeesAlreadyPosted,new Object[] {msgFee.getFeeAmount(),msgFee.getFeeCurrency(),msgFee.getId().getFeeTypeUid()});
                    pError.setSeverity(ErrorSeverity.critical);
                    configureErrorFeedback(pError.getErrorCode(),pError.getDescription(),feedback);
                    ErrorAuditUtils.setErrors(pError,pdo.getIsHistory());
                    continue;
                }
            	if (isMT191AutoGen)
            	{
            		msgFee.getId().setApply(ApplyFee.REQUEST.name());
            		
//        			it is possible that msg fee is deducted from account, therefore, fee amount in payment currency should be set.
        			if (msgFee.getFeeAmountInPmtCcy() == null)
        			{
        				
                    	double amount = convertCurrency(msgFee.getFeeCurrency()
                                ,pdo.getString(PDOConstantFieldsInterface.P_CDT_ACCT_CCY),msgFee.getFeeAmount(),FeesCalculationType.DEBIT,pdo,true
                                ,pdo.getString(PDOConstantFieldsInterface.P_BASE_CCY),null, feedback);
                            
                        if (feedback.isSuccessful())
                        {
                        	msgFee.setFeeAmountInPmtCcy(amount);
                        }
        				
        			}
            		
            	}
            		
            	else
            	{
            		numberOfUnwindExecuted[0]++;
            		msgFee.setFeeAmountPmtCcyPreInAf(msgFee.getFeeAmountInPmtCcy());

//	            	IF the Adjustment amount is negative then adjust the first fee line by subtracting (subtract of minus = increasing) the Adjustment amount and continue with
//	            	the loop for ignoring all the calculation except the request msg fees check.
	            	
	            	if (shouldContinueWithCalculations)
	            	{
//		                totalAgentAccAmt += msgFee.getFeeAmountPmtCcyPreInAf();
		                if (feeAmountInPmtCcyToUnwind > 0)
		                {
		                    
//		                    IF it is positive then need to leave all the entries that their accumulation is still less than the D_IN_AF_ACCT_AMT, change the 
//		                    first one that with its amount it exceed the D_IN_AF_ACCT_AMT  to accommodate the left amount, and set to zero all the other entries. 
//		                    In this case we'll also need to update accordingly all the amount fields except the FEE_ACC_AMOUNT_PMT_CCY_PRE_IN_AF field which should remain unchanged.
		
		                    if (isAgentAccAmtGreaterThenTotal)
		                    {
		                        msgFee.setFeeAccAmount(0d);
		                        msgFee.setFeeAmount(0d);
		                        msgFee.setFeeAmountInPmtCcy(0d);
		                        msgFee.setFeeBaseAmount(0d);
		                        msgFee.setFeePnlAmount(0d);
		                    }else
		                    {
		                        totalAgentAccAmt+=msgFee.getFeeAmountPmtCcyPreInAf();
		                        
		                        
		                        if (totalAgentAccAmt >= pdo.getDecimal(PDOConstantFieldsInterface.D_IN_AF_CDT_ACCT_AMT).doubleValue() )
		                        {
		                        	double amountToUnwind = totalAgentAccAmt -  pdo.getDecimal(PDOConstantFieldsInterface.D_IN_AF_CDT_ACCT_AMT).doubleValue();
		                        	isAgentAccAmtGreaterThenTotal = true;
		                            unwindIncomingAgentFeesByAmount(msgFee,amountToUnwind, baseCcy);
		                        }

		                        
//		                        if (totalAgentAccAmt >= pdo.getDecimal(PDOConstantFieldsInterface.D_IN_AF_CDT_ACCT_AMT).doubleValue() )
//		                        {
//		                        	if (totalAgentAccAmt > pdo.getDecimal(PDOConstantFieldsInterface.D_IN_AF_CDT_ACCT_AMT).doubleValue()) isAgentAccAmtGreaterThenTotal = true;
//		                        	double amountToUnwind = feeAmountInPmtCcyToUnwind;
//		                        	
//		                        	if (feeAmountInPmtCcyToUnwind > msgFee.getFeeAmountPmtCcyPreInAf()) amountToUnwind  = msgFee.getFeeAmountPmtCcyPreInAf();
//		                            unwindIncomingAgentFeesByAmount(msgFee,amountToUnwind, baseCcy);
//		                        }
		                    }
		                }
		                else  // feeAmountInPmtOrAccCcy < 0 (which can be negative in case we received a bigger agent fee amount than our calculation)
		                {
		//                    IF the Adjustment amount is negative then adjust the first fee line by subtracting (subtract of minus = increasing) the Adjustment amount and exit the loop. 
		                    unwindIncomingAgentFeesByAmount(msgFee,feeAmountInPmtCcyToUnwind, baseCcy);
		                    shouldContinueWithCalculations = false;
		                }
	            	}
                
            	
	            	if (handle71gGapValueIsGenerate191)
	            	{
//            			this method will create new msg fee record with apply fee = 'REQUEST'
	            		createRequestMsgFees(pdo, msgFee, requestMsgFees);
	            	}
            	}
                
            }
        }
        
        return requestMsgFees;
    }
    
    
    
    private void createRequestMsgFees(PDO pdo, MsgFees currenctMsgFee, List<MsgFees> requestMsgFees)
    {
//    	i.	Add a new entry of MSG_FEES with 
//    	ii.	Set in new entry FEE_AMOUNT_IN_PMT_CCY = FEE_AMOUNT_PMT_CCY_PRE_IN_AF minus FEE_AMOUNT_IN_PMT_CCY
//    	iii.	Set in new entry FEE_AMOUNT_PMT_CCY_PRE_IN_AF = 0
//    	iv.	Set in new entry APPLY_FEE = 'REQUEST'
//    	v.	Adjust accordingly from the above calculated FEE_AMOUNT_IN_PMT_CCY all the other amount fields according to the ratio between 
//    	the new FEE_AMOUNT_IN_PMT_CCY divided by the orig FEE_AMOUNT_IN_PMT_CCY
//    	vi.	Copy from the orig P&L account
//    	vii.	Copy from the orig the Paying Party field etc

    	
    	MsgFees newMsgFee;
    	
		newMsgFee = new MsgFees(currenctMsgFee);
		double oldFeeAmountInPaymentCcy = newMsgFee.getFeeAmountInPmtCcy();
		
		newMsgFee.setFeeAmountInPmtCcy(newMsgFee.getFeeAmountPmtCcyPreInAf()- newMsgFee.getFeeAmountInPmtCcy());
		newMsgFee.setFeeAmountPmtCcyPreInAf(0d);
		newMsgFee.getId().setApply(ApplyFee.REQUEST.name());
		double percentage = oldFeeAmountInPaymentCcy != 0 ?  newMsgFee.getFeeAmountInPmtCcy()/oldFeeAmountInPaymentCcy : 0;
		updateMsgFeeRecordByPercentage(pdo, newMsgFee, percentage, false);
		
		requestMsgFees.add(newMsgFee);
    			
    	
    }
    
    private void unwindIncomingAgentFeesByAmount(MsgFees msgFee, double feeAmountInPmtOrAccCcy, String baseCcy) throws FeesCalculationException
    {
        double relation;
        //BackendTracer GlobalTracer=GlobalTracer;
        
        relation = ((msgFee.getFeeAmountPmtCcyPreInAf() - feeAmountInPmtOrAccCcy) / msgFee.getFeeAmountPmtCcyPreInAf()  );
        PDO pdo = Admin.getContextPDO();
        updateMsgFeeRecordByPercentage(pdo, msgFee, relation, true); 
//        dFeeAmountInBaseCurrencyToDeduct=msgFee.getFeeBaseAmount() != null ? msgFee.getFeeBaseAmount()/relation : 0;
//        dFeeAmountInPnlCurrencyToDeduct = msgFee.getFeePnlAmount() != null ? msgFee.getFeePnlAmount()/relation : 0;
//        dFeeAmountInAccountCurrencyToDeduct=msgFee.getFeeAccAmount() != null ? msgFee.getFeeAccAmount()/relation : 0;
//        dFeeAmountInPaymentCurrencyToDeduct = msgFee.getFeeAmountInPmtCcy() != null ? msgFee.getFeeAmountInPmtCcy()/relation : 0;
//        
//        
//        logger.info("FC - Fee amount in fee account ccy to deduct {}",dFeeAmountInAccountCurrencyToDeduct);
//        
//        
//        double feeAccAmt = adjustPrecision(((msgFee.getFeeAccAmount()!=null ? msgFee.getFeeAccAmount() : 0)
//                        -dFeeAmountInAccountCurrencyToDeduct),(msgFee.getFeeAccOrPmtCcy()));
//        
//        msgFee.setFeeAccAmount(feeAccAmt);
//        
//        
//        logger.info("FC - Deduct from payment");
//        
//        logger.info("FC - Fee Amount In Payment Currency To Deduct {}",dFeeAmountInPaymentCurrencyToDeduct);
//        msgFee.setFeeAmountInPmtCcy(adjustPrecision(((msgFee.getFeeAmountInPmtCcy()!=null ? msgFee.getFeeAmountInPmtCcy() : 0)
//                        -dFeeAmountInPaymentCurrencyToDeduct),(msgFee.getFeeAccOrPmtCcy())));
//        
//        msgFee.setFeeBaseAmount(adjustPrecision((msgFee.getFeeBaseAmount()-dFeeAmountInBaseCurrencyToDeduct),(baseCcy)));
//        if (dFeeAmountInPnlCurrencyToDeduct > 0)
//            msgFee.setFeePnlAmount(adjustPrecision((msgFee.getFeePnlAmount()-dFeeAmountInPnlCurrencyToDeduct),(msgFee.getFeePnlAccountCurrency())));
                            
        
    }
    
    /**
     * Method which validates if Unwind method should be activated and calculates the fee final amount.
     * This validation is valid only if Unwind Method Type equals FIRST_AMT or FIRST_REL_AMT
     * o/w if Unwind Method Type equals ALL_REL_PCT the method will return the original fee amount
     * @param arrMaxUnwindOccured
     * @param arrFloorUnwindOccured
     * @param fcOutputData
     * @param basicFeeCalcData
     * @param feeFormula
     * @param dFeeAmount
     * @param dPrincipalAmount
     * @param minf
     * @param feeCalcType
     * @param basicfeeCalcData
     * @return Final amount after Maximum and Floor validations
     *
     */
    
    private boolean isMaxAndFloorValidationAndAdjustmentOccured(PDO pdo, List<MsgFees> msgFeesList, BasicFeesCalculationData basicFeeCalcData
    		, Map<String, Double> mapCurrencyConversion, Feedback feedback) throws FeesCalculationException
    {
        //BackendTracer GlobalTracer=GlobalTracer;
        boolean flag = false;
        
        logger.info("FC - Max And Floor validation and adjustment");
//        long lTime=System.currentTimeMillis();
        
        flag = maxAmountLimitValidationAndAdjustment(pdo, msgFeesList, basicFeeCalcData, mapCurrencyConversion, feedback);
        
//        if max unwind occurred then all global logical fields should be recalculated according to new fee amounts.
        if (flag)
        	setDerivedFeeAmountLogicalFields(msgFeesList,feedback);
        
        if (feedback.isSuccessful())
        {
	        boolean res = floorAmountLimitValidationAndAdjustment(pdo, msgFeesList, basicFeeCalcData, mapCurrencyConversion, feedback);
	        
	        if (feedback.isSuccessful())
	        {
	               
		        if (res)
		        {
		        	setDerivedFeeAmountLogicalFields(msgFeesList,feedback);
		        	flag=true;
		        }
	        }
        }        	
        return flag;
    }
    
    private boolean floorAmountLimitValidationAndAdjustment(PDO pdo, List<MsgFees> listMsgFees,BasicFeesCalculationData basicFeeCalcData
    		, Map<String, Double> mapCurrencyConversion, Feedback feedback) throws FeesCalculationException
    {
        //BackendTracer GlobalTracer=GlobalTracer;
        

        
        String baseOfficeCurrency = pdo.getString(PDOConstantFieldsInterface.P_BASE_CCY);    
        Float dFloorAmount=basicFeeCalcData.getFloorAmnt();
        boolean flag = false;
        if (dFloorAmount != null)
        {
        
	        double cdtInAfFeeAmt = pdo.getDecimal(PDOConstantFieldsInterface.D_IN_AF_CDT_ACCT_AMT)!=null ? pdo.getDecimal(PDOConstantFieldsInterface.D_IN_AF_CDT_ACCT_AMT).doubleValue():0;
	        double settlmentAmt = pdo.getDecimal(PDOConstantFieldsInterface.X_STTLM_AMT)!=null ? pdo.getDecimal(PDOConstantFieldsInterface.X_STTLM_AMT).doubleValue():0;
	        double dbtFeePmtDeductAmt = pdo.getDecimal(PDOConstantFieldsInterface.D_DBT_FEE_PMT_DEDUCT_AMT)!=null ? 
	        		pdo.getDecimal(PDOConstantFieldsInterface.D_DBT_FEE_PMT_DEDUCT_AMT).doubleValue():0;
	        double cdtFeePmtDeductAmt = pdo.getDecimal(PDOConstantFieldsInterface.D_CDT_FEE_PMT_DEDUCT_AMT)!=null ? 
	        		pdo.getDecimal(PDOConstantFieldsInterface.D_CDT_FEE_PMT_DEDUCT_AMT).doubleValue():0;
	        		
//			2. The amount to be compared against (1) is the 33B which is the settlement amount minus the out agent fee in the settlement currency	        		
	        double settlAmtWithoutAgentFees = settlmentAmt - cdtInAfFeeAmt;
	        
//	        1. Convert the floor amount to the settlement currency
	        double floorAmtInSettCcy = convertCurrency(baseOfficeCurrency, pdo.getString(PDOConstantFieldsInterface.X_STTLM_CCY), dFloorAmount, null
	        		, pdo, false, baseOfficeCurrency, mapCurrencyConversion, feedback);
	        
	        if (! feedback.isSuccessful()) {
	        	return false;
	        }
	        
//            4. = [cr fee deduct from payment plus dr fee deduct from payment]
          double totalCreditAndDebitFeesFromPayment = dbtFeePmtDeductAmt+cdtFeePmtDeductAmt;
            
          int length = 0;//listMsgFees.size();
          MsgFees msgFee=null;
          int i;
          double dTotalPostedFees=0;
          for(i=0;i<listMsgFees.size();i++)
          {
              msgFee=listMsgFees.get(i);
              if (msgFee.getIsPosted() && msgFee.getDeductFrom().equals(DeductFromType.P.name()))
              {
                  dTotalPostedFees+=msgFee.getFeeAmountInPmtCcy();
              }
              else
              {
                  //length should be the last non posted msg_fee record
                  length=i+1;
              }
          }
	        
//            if debit plus credit fees deducted from payment exist and settlement amount without agent fees less then floor amount 
	        if ((totalCreditAndDebitFeesFromPayment-dTotalPostedFees) > 0 && settlAmtWithoutAgentFees<floorAmtInSettCcy)
	        {
	        	flag = true;
//	            5. The amount to unwind Is the minimum between [(1) minus (2)] and (4)
	            double exceedAmt = Math.min(totalCreditAndDebitFeesFromPayment,(floorAmtInSettCcy - settlAmtWithoutAgentFees));
	            
	            double portionToMultiply = 1 - (exceedAmt / (totalCreditAndDebitFeesFromPayment-dTotalPostedFees));
	            
	            i=0;
	            totalCreditAndDebitFeesFromPayment -=exceedAmt ; 
	            while (i<length)
	            {
	                msgFee = listMsgFees.get(i++);
	                if (msgFee.getDeductFrom().equals(DeductFromType.P.name()))
	                {
	                    if (msgFee.getIsPosted())
	                    {
	                        totalCreditAndDebitFeesFromPayment -= msgFee.getFeeAmountInPmtCcy() ; 
	                        continue;
	                    }
//	                	if the unwind method is 'ALL_REL_PCT' then portionToMultiply should not be changed.
	                	if (!basicFeeCalcData.getUnwindMethodType().equals(UnwindMethodType.ALL_REL_PCT))
	                	{
//	                		if the total reached 0, all the fees should be 0
	                		if (totalCreditAndDebitFeesFromPayment<=0)
	                		{
	                			portionToMultiply = 0;
	                		}
//	                		if the total greater then fee amount in payment ccy, then the fee amount should remain as it was.
	                		else if (totalCreditAndDebitFeesFromPayment >= msgFee.getFeeAmountInPmtCcy())
		                	{
		                		portionToMultiply = 1;

//		                		deduct fee amount in payment ccy from total amount.
		                		totalCreditAndDebitFeesFromPayment -= msgFee.getFeeAmountInPmtCcy() ;
		                		continue;
		                	}else // the total less then fee amount in payment ccy -> fee amount should be adjusted 
		                	{// if unwind method is 'FIRST_AMT' then fee amount should be 0
		                		if (basicFeeCalcData.getUnwindMethodType().equals(UnwindMethodType.FIRST_AMT))
		                		{
		                			portionToMultiply = 0;
		                		}else // if unwind method is 'FIRST_REL_AMT' then fee amount should be relative
		                		{
		                			portionToMultiply = (totalCreditAndDebitFeesFromPayment/msgFee.getFeeAmountInPmtCcy());
		                		}
		                		
		                		totalCreditAndDebitFeesFromPayment = 0;
		                	}
	                	}
	                	
	                	if(logger.isInfoEnabled()){
	                        logger.info(String.format("FC - Fee amount {} {} reduced to {} {}"
	                                ,msgFee.getFeeAmount(),msgFee.getFeeCurrency(),(msgFee.getFeeAmount()*portionToMultiply),msgFee.getFeeCurrency()));
	                	}
                        msgFee.setFeeAmount(GlobalUtils.adjustPrecision((msgFee.getFeeAmount()*portionToMultiply),(msgFee.getFeeCurrency())));
                        
                        if(logger.isInfoEnabled()){
                        logger.info(String.format("FC - Fee base amount {} {} reduced to {} {}"
                                ,msgFee.getFeeBaseAmount(),baseOfficeCurrency,(msgFee.getFeeBaseAmount()*portionToMultiply),baseOfficeCurrency));
                        }
                        msgFee.setFeeBaseAmount(GlobalUtils.adjustPrecision((msgFee.getFeeBaseAmount()*portionToMultiply)
                                ,(baseOfficeCurrency)));
                        if (msgFee.getFeePnlAccountCurrency()!=null && msgFee.getFeePnlAccountCurrency().length()>0)
                        {
                        	if(logger.isInfoEnabled()){
                        		logger.info(String.format("FC - Fee PnL amount {} {} reduced to {} {}"                        				
                        				,msgFee.getFeePnlAmount(),msgFee.getFeePnlAccountCurrency(),(msgFee.getFeePnlAmount()*portionToMultiply),msgFee.getFeePnlAccountCurrency()));
                        	}
                            msgFee.setFeePnlAmount(GlobalUtils.adjustPrecision(msgFee.getFeePnlAmount()*portionToMultiply,(msgFee.getFeePnlAccountCurrency())));
                        }
                        if (msgFee.getFeeAmountInPmtCcy() != null)
                        {
                        	if (msgFee.getFeeAccOrPmtCcy() == null) setFeeAccOrPmtCcy(pdo,msgFee);
                        	
                        	if(logger.isInfoEnabled()){
                        		logger.info(String.format("FC - Fee amount in payment currency {} {} reduced to {} {}"                        				
                        				,msgFee.getFeeAmountInPmtCcy(),msgFee.getFeeAccOrPmtCcy(),(msgFee.getFeeAmountInPmtCcy()*portionToMultiply),msgFee.getFeeAccOrPmtCcy()));
                        	}
                            msgFee.setFeeAmountInPmtCcy(GlobalUtils.adjustPrecision(msgFee.getFeeAmountInPmtCcy()*portionToMultiply,(msgFee.getFeeAccOrPmtCcy())));
                        }
	                	
	                    
	                }
	            }
	            
	        }
        } 
        return flag;
    }
    
    
    private boolean maxAmountLimitValidationAndAdjustment(PDO pdo, List<MsgFees> listMsgFees,BasicFeesCalculationData basicFeeCalcData
    		, Map<String, Double> mapCurrencyConversion, Feedback feedback) throws FeesCalculationException
    {
        //BackendTracer GlobalTracer=GlobalTracer;
        

        boolean flag = false;
        logger.info("FC - Adjust total fees");
        double feeAccEqvt = 0;
        double feePmtEqvt = 0;
        String baseOfficeCurrency = pdo.getString(PDOConstantFieldsInterface.P_BASE_CCY);
        
        feeAccEqvt = (pdo.getDecimal(PDOConstantFieldsInterface.D_DBT_FEE_ACCT_BASEEQVT) != null ? pdo.getDecimal(PDOConstantFieldsInterface.D_DBT_FEE_ACCT_BASEEQVT).doubleValue() : 0)
        			+ (pdo.getDecimal(PDOConstantFieldsInterface.D_CDT_FEE_ACCT_BASEEQVT) != null ? pdo.getDecimal(PDOConstantFieldsInterface.D_CDT_FEE_ACCT_BASEEQVT).doubleValue() : 0);
        feePmtEqvt = (pdo.getDecimal(PDOConstantFieldsInterface.D_DBT_FEE_PMT_DEDUCT_BASEEQVT) != null ? pdo.getDecimal(PDOConstantFieldsInterface.D_DBT_FEE_PMT_DEDUCT_BASEEQVT).doubleValue() : 0)
        			+ (pdo.getDecimal(PDOConstantFieldsInterface.D_CDT_FEE_PMT_DEDUCT_BASEEQVT) != null ? pdo.getDecimal(PDOConstantFieldsInterface.D_CDT_FEE_PMT_DEDUCT_BASEEQVT).doubleValue() : 0);
        
        double dTotalFeesInBaseCcy = feeAccEqvt + feePmtEqvt;

        logger.info("FC - Total fee amount = "+dTotalFeesInBaseCcy+" "+baseOfficeCurrency+" greater then max limit = " 
                + basicFeeCalcData.getMaxFee() + " "+baseOfficeCurrency);

        int length=0;// listMsgFees.size();
        int i=0;
        double dTotalPostedFees=0;
        MsgFees msgFee=null;
        for(i=0;i<listMsgFees.size();i++)
        {
            msgFee=listMsgFees.get(i);
            if (msgFee.getIsPosted())
            {
                dTotalPostedFees+=msgFee.getFeeBaseAmount();
            }
            else
            {
                //length should be the last non posted msg_fee record
                length=i+1;
            }
        }
        
        //if total fee amount greater then max limit then adjust the fee amount and set the Max Flag to true
        //in order not to enter this validation again.
         if (basicFeeCalcData.getMaxFee()!=null && dTotalFeesInBaseCcy > basicFeeCalcData.getMaxFee() && 
                 dTotalFeesInBaseCcy>dTotalPostedFees && 
                 basicFeeCalcData.getMaxFee()>=dTotalPostedFees)
        {
        	flag = true;
            i=0;
//	            5. The amount to unwind Is the minimum between [(1) minus (2)] and (4)
            double exceedAmt = dTotalFeesInBaseCcy - basicFeeCalcData.getMaxFee();
            
            double portionToMultiply = 1 - (exceedAmt / (dTotalFeesInBaseCcy-dTotalPostedFees));
            
            double totalBaseFeesAfterdeduction=0;
            double maxFees =basicFeeCalcData.getMaxFee() ; 
            while (i<length)
            {
                msgFee = listMsgFees.get(i++);
                if (msgFee.getIsPosted())
                {
                    totalBaseFeesAfterdeduction+=msgFee.getFeeBaseAmount();
                    if (!basicFeeCalcData.getUnwindMethodType().equals(UnwindMethodType.ALL_REL_PCT))
                    {
                        maxFees-=msgFee.getFeeBaseAmount() ;
                    }
                    continue;
                }
//	               	if the unwind method is 'ALL_REL_PCT' then portionToMultiply should not be changed
//	                except the last rotation, because of precision adjustment, the last fee should be a little bit higher the expected.
//	                for example:
//	                max fee = 4
//	                fee1 = 5 -> 1.33
//	                fee2 = 5 -> 1.33
//	                fee3 = 5 -> 1.34
            	if (basicFeeCalcData.getUnwindMethodType().equals(UnwindMethodType.ALL_REL_PCT))
            	{
            		if (i == (length))
            		{
            			double lastFeeAmount = maxFees - totalBaseFeesAfterdeduction;
            			portionToMultiply = lastFeeAmount/msgFee.getFeeBaseAmount();
            		}
            		
            	}else
            	{
//	                		if the total reached 0, all the fees should be 0
            		if (maxFees<=0)
            		{
            			portionToMultiply = 0;
            		}
//	                		if the total greater then fee amount in payment ccy, then the fee amount should remain as it was.
            		else if (maxFees >= msgFee.getFeeBaseAmount())
                	{
                		portionToMultiply = 1;

//		                		deduct fee amount in payment ccy from total amount.
                		maxFees -= msgFee.getFeeBaseAmount() ; 
                		continue;
                	}else // the total less then fee amount in payment ccy -> fee amount should be adjusted 
                	{// if unwind method is 'FIRST_AMT' then fee amount should be 0
                		if (basicFeeCalcData.getUnwindMethodType().equals(UnwindMethodType.FIRST_AMT))
                		{
                			portionToMultiply = 0; //make msg_fees.FeeBaseAmount=0
                		}else // if unwind method is 'FIRST_REL_AMT' then fee amount should be relative
                		{
                			portionToMultiply = (maxFees/msgFee.getFeeBaseAmount()); //make msg_fees.FeeBaseAmount = maxFees
                		}
                		
                		maxFees = 0; //from now on set all fee amounts to 0
                	}
            	}
                	
            	if(logger.isInfoEnabled()){	
                logger.info(String.format("FC - Fee amount {} {} reduced to {} {}"
                        ,msgFee.getFeeAmount(),msgFee.getFeeCurrency(),(msgFee.getFeeAmount()*portionToMultiply),msgFee.getFeeCurrency()));
            	}
                msgFee.setFeeAmount(GlobalUtils.adjustPrecision((msgFee.getFeeAmount()*portionToMultiply)
                        ,(msgFee.getFeeCurrency())));
                
                if(logger.isInfoEnabled()){
                	logger.info(String.format("FC - Fee base amount {} {} reduced to {} {}"
                			,msgFee.getFeeBaseAmount(),baseOfficeCurrency,(msgFee.getFeeBaseAmount()*portionToMultiply),baseOfficeCurrency));
                }
                msgFee.setFeeBaseAmount(GlobalUtils.adjustPrecision((msgFee.getFeeBaseAmount()*portionToMultiply)
                        ,(baseOfficeCurrency)));
                
                
                totalBaseFeesAfterdeduction+=msgFee.getFeeBaseAmount();

                if (msgFee.getFeePnlAccountCurrency()!=null && msgFee.getFeePnlAccountCurrency().length()>0)
                {
                	if(logger.isInfoEnabled()){
                		logger.info(String.format("FC - Fee PnL amount {} {} reduced to {} {}"
                				,msgFee.getFeePnlAmount(),msgFee.getFeePnlAccountCurrency()
                				,(msgFee.getFeePnlAmount()*portionToMultiply),msgFee.getFeePnlAccountCurrency()));
                	}
                    msgFee.setFeePnlAmount(GlobalUtils.adjustPrecision(msgFee.getFeePnlAmount()*portionToMultiply
                            ,(msgFee.getFeePnlAccountCurrency())));
                }

                
                if (msgFee.getDeductFrom().equals(DeductFromType.A.name()))//account
                {
                    
                	if(logger.isInfoEnabled()){
                		logger.info(String.format("FC - Fee account amount {} {} reduced to {} {}"                	
                				,msgFee.getFeeAccAmount(),msgFee.getFeeAccOrPmtCcy()
                				,(msgFee.getFeeAccAmount()*portionToMultiply),msgFee.getFeeAccOrPmtCcy()));
                	}
                    double feeAccAmt = GlobalUtils.adjustPrecision(msgFee.getFeeAccAmount()*portionToMultiply
                            ,(msgFee.getFeeAccOrPmtCcy()));
                    
                    msgFee.setFeeAccAmount(feeAccAmt);
                    
                        
                    msgFee.setUnwindFee(true);
                }
                else //Payment
                {
                    if (msgFee.getFeeAccOrPmtCcy()!=null 
                            && msgFee.getFeeAccOrPmtCcy().length()>0)
                    {
                    	if(logger.isInfoEnabled()){
                    		logger.info(String.format("FC - Fee amount in payment currency {} {} reduced to {} {}"                    				
                    				,msgFee.getFeeAmountInPmtCcy(),msgFee.getFeeAccOrPmtCcy()
                    				,(msgFee.getFeeAmountInPmtCcy()*portionToMultiply)
                    				,msgFee.getFeeAccOrPmtCcy()));
                    	}
                        double feeAmtInPmtCcy = GlobalUtils.adjustPrecision(msgFee.getFeeAmountInPmtCcy()*portionToMultiply
                                ,(msgFee.getFeeAccOrPmtCcy()));
                        
                        msgFee.setFeeAmountInPmtCcy(feeAmtInPmtCcy);
                        
//                        this fields should be updated only if it is not empty because of incoming agent fees 
                        if (msgFee.getFeeAmountPmtCcyPreInAf() != null)
                            msgFee.setFeeAmountPmtCcyPreInAf(feeAmtInPmtCcy);

                    }
                    msgFee.setUnwindFee(true);
                }
            }
        }
	                	
        return flag;
    }
    
    
/*    
    private void resetMsgFeesList(List<MsgFees> msgFeesList, int fromIdx, boolean shouldResetFeeAmountPreInAf)
    {
        int length = msgFeesList.size();
        int i = fromIdx;
        MsgFees msgFee = null; 
        for (;i<length;i++)
        {
            msgFee = msgFeesList.get(i);
            msgFee.setFeeAccAmount(0d);
            msgFee.setFeeAmount(0d);
            msgFee.setFeeAmountInPmtCcy(0d);
            msgFee.setFeeBaseAmount(0d);
            msgFee.setFeePnlAmount(0d);
            if (shouldResetFeeAmountPreInAf) msgFee.setFeeAmountPmtCcyPreInAf(0d);
            msgFee.setUnwindFee(true);
        }
        
    }
*/
    
    
    private void setDerivedFeeAmountLogicalFields(List<MsgFees> msgFees, Feedback feedback)
    {
        PDO pdo = Admin.getContextPDO();
        
        double dbtFeeAccAmt=0;
        double dbtFeeAccBaseEqvt=0;
        String dbtFeeAccCcy=null;
        String cdtFeeAccCcy=null;
        double dbtFeePmtDeductAmt=0;
        double dbtFeePmtDeductBaseEqv=0;
        double dbtFeePostingAmt=0;
        double dbtFeeAccAmtLater=0;
        double dbtFeeAccAmtNow=0;
        double dbtFeePmtAmtRequest=0;
        double dbtFeeAmountPmtCcyPreInAf=0;
        double agentAmtInCdtFeeAccCcy = 0;
        
        
        double dbtAfFeeAccAmt=0;
        double cdtAfFeePmtAmt=0;
        
        double cdtFeeAccAmt=0;
        double cdtFeeAccBaseEqvt=0;
        double cdtFeePmtDeductAmt =0d;
        double cdtFeePmtDeductBaseEqv=0;
        double cdtFeeAccAmtLater=0;
        double cdtFeeAccAmtNow=0;
        
        boolean isDebitUpdated = false;
        boolean isCreditUpdated = false;
        boolean isAgentUpdated = false;
        
        
        double dbtMainPostingAmt = pdo.getDecimal(PDOConstantFieldsInterface.P_DBT_AMT) != null
        						? pdo.getDecimal(PDOConstantFieldsInterface.P_DBT_AMT).doubleValue() : 0;

//      if fee account currency exist (fee account) take the fee account currency, else, take debit account currency.
	    dbtFeeAccCcy = GlobalUtils.isNullOrEmpty(pdo.getString(PDOConstantFieldsInterface.P_DBT_FEE_ACCT_CCY)) ? pdo.getString(PDOConstantFieldsInterface.P_DBT_ACCT_CCY)
	            : pdo.getString(PDOConstantFieldsInterface.P_DBT_FEE_ACCT_CCY);
	    
//      if fee account currency exist (fee account) take the fee account currency, else, take credit account currency.
	    cdtFeeAccCcy = GlobalUtils.isNullOrEmpty(pdo.getString(PDOConstantFieldsInterface.P_CDT_FEE_ACCT_CCY)) ? pdo.getString(PDOConstantFieldsInterface.P_CDT_ACCT_CCY)
	            : pdo.getString(PDOConstantFieldsInterface.P_CDT_FEE_ACCT_CCY);
	    
	    String cdtAccCcy = pdo.getString(PDOConstantFieldsInterface.P_CDT_ACCT_CCY);
	    
	    String baseCcy=CacheKeys.banksKey.getSingle(pdo.getString(PDOConstantFieldsInterface.P_OFFICE)).getCurrency();
	    
	    if (msgFees!=null) {
			for (MsgFees msgFee : msgFees) {
			    //no need to check msg_fees.isPosted - all the set function calls on MsgFes are transient.
				//                Debit
				if (FeesCalculationType.DR.name().equals(
						msgFee.getPayingParty())) {
					isDebitUpdated = true;

					if (!ApplyFee.REQUEST.name().equals(
							msgFee.getId().getApply())) {
						if (DeductFromType.A.name().equals(
								msgFee.getDeductFrom())) //deduct from account
						{
							double tempAmount = msgFee.getFeeAccAmount() != null ? msgFee
									.getFeeAccAmount() : 0;
							dbtFeeAccAmt += tempAmount; //D_DBT_FEE_ACCT_AMT

							if (ApplyFee.NOW.name().equals(
									msgFee.getId().getApply())) {
								dbtFeeAccAmtNow += tempAmount; // D_DBT_FEE_ACCT_AMT_NOW
							} else if (ApplyFee.LATER.name().equals(
									msgFee.getId().getApply())) {
								dbtFeeAccAmtLater += tempAmount; //D_DBT_FEE_ACCT_AMT_LATER
							}

							dbtFeeAccBaseEqvt += msgFee.getFeeBaseAmount() != null ? msgFee
									.getFeeBaseAmount() : 0; //D_DBT_FEE_ACCT_BASEEQVT

							msgFee.setFeeAccOrPmtCcy(dbtFeeAccCcy); //Transient function

						} else //deduct from payment
						{
							dbtFeePmtDeductAmt += msgFee.getFeeAmountInPmtCcy() != null ? msgFee
									.getFeeAmountInPmtCcy() : 0; //D_DBT_FEE_PMT_DEDUCT_AMT
							dbtFeePmtDeductBaseEqv += msgFee.getFeeBaseAmount() != null ? msgFee
									.getFeeBaseAmount() : 0; // D_DBT_FEE_PMT_DEDUCT_BASEEQVT
							msgFee.setFeeAccOrPmtCcy(cdtAccCcy); //Transient function

							if (msgFee.getFeeAmountPmtCcyPreInAf() != null)
								dbtFeeAmountPmtCcyPreInAf += msgFee
										.getFeeAmountPmtCcyPreInAf(); // D_DBT_FEE_AMT_PRE_IN_AF

						}
					} else {
						dbtFeePmtAmtRequest += msgFee.getFeeAmountInPmtCcy(); // D_DBT_FEE_PMT_AMT_REQUEST
					}

				} else if (msgFee.getPayingParty().equals(
						FeesCalculationType.CR.name())) {
					isCreditUpdated = true;
					if (DeductFromType.A.name().equals(msgFee.getDeductFrom())) //deduct from account
					{
						double tempAmount = msgFee.getFeeAccAmount() != null ? msgFee
								.getFeeAccAmount() : 0;

						cdtFeeAccAmt += tempAmount; //D_CDT_FEE_ACCT_AMT
						cdtFeeAccBaseEqvt += msgFee.getFeeBaseAmount() != null ? msgFee
								.getFeeBaseAmount() : 0; //D_CDT_FEE_ACCT_BASEEQVT

						if (msgFee.getId().getApply()
								.equals(ApplyFee.NOW.name())) {
							cdtFeeAccAmtNow += tempAmount;//D_CDT_FEE_ACCT_AMT_NOW
						} else {
							cdtFeeAccAmtLater += tempAmount;//D_CDT_FEE_ACCT_AMT_LATER
						}
						msgFee.setFeeAccOrPmtCcy(cdtFeeAccCcy); //Transient function

					} else //deduct from payment
					{
						cdtFeePmtDeductAmt += msgFee.getFeeAmountInPmtCcy() != null ? msgFee
								.getFeeAmountInPmtCcy() : 0; //D_CDT_FEE_PMT_DEDUCT_AMT
						cdtFeePmtDeductBaseEqv += msgFee.getFeeBaseAmount() != null ? msgFee
								.getFeeBaseAmount() : 0; //D_CDT_FEE_PMT_DEDUCT_BASEEQVT

						msgFee.setFeeAccOrPmtCcy(cdtAccCcy); //Transient function
					}

				} else //Agent - in agent no deduct from payment, only account.
				{
					isAgentUpdated = true;
					dbtAfFeeAccAmt += msgFee.getFeeAccAmount() != null ? msgFee
							.getFeeAccAmount() : 0;//D_DBT_AF_FEE_ACCT_AMT
					cdtAfFeePmtAmt += msgFee.getFeeAmountInPmtCcy() != null ? msgFee
							.getFeeAmountInPmtCcy() : 0;//D_CDT_AF_FEE_PMT_AMT
					msgFee.setFeeAccOrPmtCcy(dbtFeeAccCcy); //Transient function
				}

			}
		}
		//        update debit side logical fields only if Debit msg fees exist
        if (isDebitUpdated)
        {
            pdo.set(PDOConstantFieldsInterface.D_DBT_FEE_ACCT_AMT,adjustPrecisionBD(dbtFeeAccAmt,(dbtFeeAccCcy)));
            pdo.set(PDOConstantFieldsInterface.D_DBT_FEE_ACCT_BASEEQVT,adjustPrecisionBD(dbtFeeAccBaseEqvt,(baseCcy)));
        	pdo.set(PDOConstantFieldsInterface.D_DBT_FEE_PMT_DEDUCT_AMT,adjustPrecisionBD(dbtFeePmtDeductAmt,(cdtAccCcy)));
            pdo.set(PDOConstantFieldsInterface.D_DBT_FEE_PMT_DEDUCT_BASEEQVT,adjustPrecisionBD(dbtFeePmtDeductBaseEqv,(baseCcy)));
            pdo.set(PDOConstantFieldsInterface.D_DBT_FEE_ACCT_AMT_NOW,adjustPrecisionBD(dbtFeeAccAmtNow,(dbtFeeAccCcy)));
            pdo.set(PDOConstantFieldsInterface.D_DBT_FEE_PMT_AMT_REQUEST,adjustPrecisionBD(dbtFeePmtAmtRequest,(cdtAccCcy)));
            pdo.set(PDOConstantFieldsInterface.D_DBT_FEE_ACCT_AMT_LATER,adjustPrecisionBD(dbtFeeAccAmtLater,(dbtFeeAccCcy)));
            pdo.set(PDOConstantFieldsInterface.D_DBT_FEE_AMT_PMT_PRE_IN_AF,adjustPrecisionBD(dbtFeeAmountPmtCcyPreInAf,(cdtAccCcy)));
            
        }
        
//      update credit side logical fields only if Credit msg fees exist        
        if (isCreditUpdated)
        {
            pdo.set(PDOConstantFieldsInterface.D_CDT_FEE_ACCT_AMT,adjustPrecisionBD(cdtFeeAccAmt,(cdtFeeAccCcy)));
            pdo.set(PDOConstantFieldsInterface.D_CDT_FEE_ACCT_BASEEQVT,adjustPrecisionBD(cdtFeeAccBaseEqvt,(baseCcy)));
            pdo.set(PDOConstantFieldsInterface.D_CDT_FEE_PMT_DEDUCT_AMT,adjustPrecisionBD(cdtFeePmtDeductAmt,(cdtAccCcy)));
            pdo.set(PDOConstantFieldsInterface.D_CDT_FEE_PMT_DEDUCT_BASEEQVT,adjustPrecisionBD(cdtFeePmtDeductBaseEqv,(baseCcy)));
            pdo.set(PDOConstantFieldsInterface.D_CDT_FEE_ACCT_AMT_NOW,adjustPrecisionBD(cdtFeeAccAmtNow,(cdtFeeAccCcy)));
            pdo.set(PDOConstantFieldsInterface.D_CDT_FEE_ACCT_AMT_LATER,adjustPrecisionBD(cdtFeeAccAmtLater,(cdtFeeAccCcy)));
        	
        }
        
//      update agent side logical fields only if Agent msg fees exist
        if (isAgentUpdated)
        {
            pdo.set(PDOConstantFieldsInterface.D_DBT_AF_FEE_ACCT_AMT, adjustPrecisionBD(dbtAfFeeAccAmt,dbtFeeAccCcy));
            pdo.set(PDOConstantFieldsInterface.D_CDT_AF_FEE_PMT_AMT, adjustPrecisionBD(cdtAfFeePmtAmt,cdtAccCcy));
        }
//        long time = System.nanoTime();
        if (dbtFeePmtDeductAmt == 0) dbtFeePmtDeductAmt = pdo.getDecimal(PDOConstantFieldsInterface.D_DBT_FEE_PMT_DEDUCT_AMT)!=null ? pdo.getDecimal(PDOConstantFieldsInterface.D_DBT_FEE_PMT_DEDUCT_AMT).doubleValue():0;
        if (cdtFeePmtDeductAmt == 0) cdtFeePmtDeductAmt = pdo.getDecimal(PDOConstantFieldsInterface.D_CDT_FEE_PMT_DEDUCT_AMT)!=null ? pdo.getDecimal(PDOConstantFieldsInterface.D_CDT_FEE_PMT_DEDUCT_AMT).doubleValue():0;
        
        pdo.set(PDOConstantFieldsInterface.D_TOT_FEE_PMT_DEDUCT_AMT,adjustPrecisionBD(dbtFeePmtDeductAmt+cdtFeePmtDeductAmt, cdtAccCcy));
        
//        if (dbtFeePmtDeductBaseEqv == 0) dbtFeePmtDeductBaseEqv = pdo.getDecimal(PDOConstantFieldsInterface.D_DBT_FEE_PMT_DEDUCT_BASEEQVT)!=null 
//        											? pdo.getDecimal(PDOConstantFieldsInterface.D_DBT_FEE_PMT_DEDUCT_BASEEQVT).doubleValue():0;
//        if (cdtFeePmtDeductBaseEqv == 0) cdtFeePmtDeductBaseEqv = pdo.getDecimal(PDOConstantFieldsInterface.D_CDT_FEE_PMT_DEDUCT_BASEEQVT)!=null 
//        											? pdo.getDecimal(PDOConstantFieldsInterface.D_CDT_FEE_PMT_DEDUCT_BASEEQVT).doubleValue():0;
        											
        pdo.set(PDOConstantFieldsInterface.D_TOT_FEE_PMT_DEDUCT_BASEEQVT,adjustPrecisionBD(dbtFeePmtDeductBaseEqv+cdtFeePmtDeductBaseEqv,baseCcy));
        
//        if (cdtAfFeePmtAmt == 0) cdtAfFeePmtAmt = pdo.getDecimal(PDOConstantFieldsInterface.D_CDT_AF_FEE_PMT_AMT)!=null 
//        											? pdo.getDecimal(PDOConstantFieldsInterface.D_CDT_AF_FEE_PMT_AMT).doubleValue() : 0;
        
        											
        double cdtAmount = pdo.getDecimal(PDOConstantFieldsInterface.P_CDT_AMT)!=null ? pdo.getDecimal(PDOConstantFieldsInterface.P_CDT_AMT).doubleValue() : 0;
        if (overrideX_Sttlm_Amt(pdo))
        {	
        	pdo.set(PDOConstantFieldsInterface.X_STTLM_AMT,adjustPrecisionBD((cdtAmount+ cdtAfFeePmtAmt - (dbtFeePmtDeductAmt+cdtFeePmtDeductAmt)),cdtAccCcy));
        }

      //the posting service should decide whether to accumulate the fee and debit amount or send them separately  (Yoni S. and Oren R, 13/9/2012)     
        dbtFeePostingAmt = dbtFeeAccAmtNow + dbtAfFeeAccAmt; //D_DBT_FEE_POST_AMT
        
                  
       /* if (GlobalUtils.isNullOrEmpty(pdo.getString(PDOConstantFieldsInterface.P_DBT_FEE_ACCT_NB)) 
	      ||(pdo.getString(PDOConstantFieldsInterface.P_DBT_FEE_ACCT_NB).equals(pdo.getString(PDOConstantFieldsInterface.P_DBT_ACCT_NB))
	         && pdo.getString(PDOConstantFieldsInterface.P_DBT_FEE_ACCT_OFFICE).equals(pdo.getString(PDOConstantFieldsInterface.P_DBT_ACCT_OFFICE))
	         && pdo.getString(PDOConstantFieldsInterface.P_DBT_FEE_ACCT_CCY).equals(pdo.getString(PDOConstantFieldsInterface.P_DBT_ACCT_CCY))))
        {
        	dbtMainPostingAmt+=(dbtFeeAccAmtNow + dbtAfFeeAccAmt); //D_DBT_MAIN_POST_AMT
        	
        }
        else
        {
        	dbtFeePostingAmt = dbtFeeAccAmtNow + dbtAfFeeAccAmt; //D_DBT_FEE_POST_AMT
        }*/
        
        
        pdo.set(PDOConstantFieldsInterface.D_DBT_MAIN_POST_AMT,adjustPrecisionBD(dbtMainPostingAmt, dbtFeeAccCcy));
        pdo.set(PDOConstantFieldsInterface.D_DBT_FEE_POST_AMT,adjustPrecisionBD(dbtFeePostingAmt, dbtFeeAccCcy));
        pdo.set(PDOConstantFieldsInterface.D_DBT_FEE_ACCT_CCY,dbtFeeAccCcy);
        
//        BigDecimal rcvrChrgsInf= pdo.getDecimal(PDOConstantFieldsInterface.OX_RCVR_CHRGS_INF,1,PDOConstantFieldsInterface.OX_RCVR_CHRGS_INF_AMT); 
        
        BigDecimal rcvrChrgsInf= getReciverCharges(pdo);
        if (rcvrChrgsInf != null)
        {
        	
//        	String fromCcy = pdo.getString(PDOConstantFieldsInterface.OX_RCVR_CHRGS_INF,1,PDOConstantFieldsInterface.OX_RCVR_CHRGS_INF_CCY);
//        	String fromCcy = pdo.getString(PDOConstantFieldsInterface.OX_CHRGS_INF_CCY);
        	String fromCcy = (String) pdo.get(new Object[] {PDOConstantFieldsInterface.OX_CHRGS_INF, 0, PDOConstantFieldsInterface.OX_CHRGS_INF_CCY});
    	
	        agentAmtInCdtFeeAccCcy = convertCurrency(fromCcy, cdtAccCcy, rcvrChrgsInf.doubleValue(),FeesCalculationType.DEBIT
	        		,pdo,false,pdo.getString(PDOConstantFieldsInterface.P_BASE_CCY),null, feedback);
	        
	        //GlobalConstants.listForSysout.add("FC:			step 1 = "+((System.nanoTime() - time)/1000000));
        }
        
        pdo.set(PDOConstantFieldsInterface.D_IN_AF_CDT_ACCT_AMT, BigDecimal.valueOf(agentAmtInCdtFeeAccCcy));
                
        
    }
    private boolean overrideX_Sttlm_Amt(PDO pdo)
    {//Should not override X_STTLM_AMT in created DD BOOK payment.
    	boolean bOverride= true;
        if ((GlobalConstants.CREATE.equals(pdo.get(PDOConstantFieldsInterface.P_PMNT_SRC)) &&
            	(MessageConstantsInterface.TX_CATEGORY_DDO.equals(pdo.get(PDOConstantFieldsInterface.P_TX_CTGY))
            			|| MessageConstantsInterface.TX_CATEGORY_CTO.equals(pdo.get(PDOConstantFieldsInterface.P_TX_CTGY))) 	&&
            	MessageConstantsInterface.MOP_BOOK.equals(pdo.get(PDOConstantFieldsInterface.P_CDT_MOP))))
        {
        	if (MessageConstantsInterface.MESSAGE_STATUS_REPAIR.equals(pdo.get(PDOConstantFieldsInterface.P_MSG_STS)) ||
        		MessageConstantsInterface.MESSAGE_STATUS_VERIFY.equals(pdo.get(PDOConstantFieldsInterface.P_MSG_STS)) ||
        		MessageConstantsInterface.MESSAGE_STATUS_COMPLETE.equals(pdo.get(PDOConstantFieldsInterface.P_MSG_STS)))
        	{
        		bOverride = false;
        	}
        }

    	
    	return bOverride;
    }
    

    private BigDecimal adjustPrecisionBD(double amount, String ccy)
    {
    	BigDecimal value = null;
    	if (amount != 0 && ccy != null)
    		value = GlobalUtils.adjustPrecisionBD(amount, GlobalUtils.getPrecision(ccy)); 
    	else
    		value = BigDecimal.valueOf(amount);
    			
    	return value;
    	
    }

    @Expose
    public Feedback setDerivedFeeAmountLogicalFields()
    {
        PDO pdo = Admin.getContextPDO();
        Feedback feedback = new Feedback();
        String feeProcSts = pdo.getString(PDOConstantFieldsInterface.MF_FEE_PROC_STS) ;
        
//        if fee calculation service was processed...
        if (feeProcSts != null && feeProcSts.equals(MessageConstantsInterface.MONITOR_FLAG_PROCESSED))
        {
            List<MsgFees> msgFees = pdo.isNew() ? pdo.getListMSG_FEES() : pdo.getNSetListMSG_FEES();
            
            if (msgFees != null)
            	setDerivedFeeAmountLogicalFields(msgFees,feedback);
            
        }
        
        return feedback;
    }
    
    /**
     * inner class for Fee Types and Message Fees.
     */
    class FeeTypeUIDMsgFees
    {
        private final String m_sFeeTypeUid;
        private MsgFees m_msgFee;
        private int m_manualFee;
        private String m_sPnLAccountCurrency;
        private String m_sFeeAccountOrPaymentCurrency;

        public FeeTypeUIDMsgFees(String feeTypeUid, Integer partitionID)
        {
            m_sFeeTypeUid = feeTypeUid;
            m_msgFee=new MsgFees(partitionID);
            m_manualFee=0;
        }

        public FeeTypeUIDMsgFees(String sFeeTypeUid, MsgFees msgFee)
        {
            m_sFeeTypeUid = sFeeTypeUid;
            m_msgFee=msgFee;
            m_manualFee=msgFee.getManualFee();
        }
        public String getFeeTypeUid()
        {
            return m_sFeeTypeUid;
        }

        public MsgFees getMsgFee()
        {
            return m_msgFee;
        }

        public void setMsgFee(MsgFees fee)
        {
            m_msgFee = fee;
        }

        public int getManualFee()
        {
            return m_manualFee;
        }

        public void setManualFee(int manualFee)
        {
            m_manualFee = manualFee;
        }

        public String getPnLAccountCurrency()
        {
            return m_sPnLAccountCurrency;
        }

        public String getFeeAccountOrPaymentCurrency()
        {
            return m_sFeeAccountOrPaymentCurrency;
        }

        public void setPnLAccountCurrency(String pnLAccountCurrency)
        {
            m_sPnLAccountCurrency = pnLAccountCurrency;
        }

        public void setFeeAccountOrPaymentCurrency(String accountCurrency)
        {
            m_sFeeAccountOrPaymentCurrency = accountCurrency;
        }
    }
    
/*
    private void generateRequesMsgFees(PDO pdo, ChargeBearer chargeBearer)
    {
    	List<MsgFees> msgFees = pdo.getNSetListMSG_FEES();
    	List<MsgFees> newMsgFees = new ArrayList<MsgFees>();
    	MsgFees newMsgFee;
    	Accounts accountDebit=pdo.getNSetDEBIT_ACCOUNT();
    	for (MsgFees msgFee : msgFees) 
    	{
    		if (msgFee.getIsPosted())
    		{
    			continue;
    		}
//    		If 71G exist on the payment, insert new lines into message fees table as follows
//        	if (pdo.getDecimal(PDOConstantFieldsInterface.OX_RCVR_CHRGS_INF, 1, PDOConstantFieldsInterface.OX_RCVR_CHRGS_INF_AMT) != null)
    		//if (pdo.getDecimal(PDOConstantFieldsInterface.OX_RCVR_CHRGS_INF_AMT) != null)
    		if (getReciverCharges(pdo) != null)	    			
        	{
//        		For each debit fee (where 'deduct from' = Account and 'Apply fee' = NOW) a line with the same fee type and fee formula
        		if (msgFee.getPayingParty().equals(FeesCalculationType.DR.name()) 
        				&& msgFee.getDeductFrom().equals(DeductFromType.A.name())
        				&& msgFee.getId().getApply().equals(ApplyFee.NOW.name()))
        		{
        			newMsgFee = new MsgFees(msgFee);
        			newMsgFee.getId().setApply(ApplyFee.REQUEST.name());
        			newMsgFees.add(newMsgFee);
//        			Amount = Difference between the amount that needs to be charged and the actual amount.
//        			newMsgFee.setFeeAmount(feeAmount);
        			
//        			sumDebitFeesRequest+=feeAmount;
        		}
        	}
        	
//        	If debit account = Asset account and Charge Code = DEBT/OUR
        	if (accountDebit.getAsset() != null && accountDebit.getAsset() != 0 && (chargeBearer == ChargeBearer.DEBT || chargeBearer == ChargeBearer.OUR))
        	{
//        		Change the debit fees (where 'deduct from' = Account and 'Apply fee' = NOW) to 'Apply fee' = REQUEST
        		if (msgFee.getPayingParty().equals(FeesCalculationType.DR.name()) 
        				&& msgFee.getDeductFrom().equals(DeductFromType.A.name())
        				&& msgFee.getId().getApply().equals(ApplyFee.NOW.name()))
        		{
        			msgFee.getId().setApply(ApplyFee.REQUEST.name());
        		}
        		
        	}
        	
//        	Sum the debit fees where 'Apply fee' = REQUEST
        	if (msgFee.getPayingParty().equals(FeesCalculationType.DR.name()) && msgFee.getId().getApply().equals(ApplyFee.REQUEST.name()))
        	{
        		msgFee.getFeeAmount();
        	}
			
		}
    	
    	msgFees.addAll(newMsgFees);
    }
*/    
    
    
    
//    private MessageInformation getMinfForSkip()
//    {
//        PDO pdo=new MessageInformation();
//        minf.setMID("1");
//        minf.setOffice("BC1");
//        minf.setPDebitApplyFee("WAIVE");
//        
//        return minf;
//    }
//    

    
        
    /**
     * Method that loops on all found fee types and performs on each fee type some steps that will eventually 
     * produce data that should be inserted into a single record in the MSG_FEES table, 
     * (i.e. the iteration will result in 0 or more MSG_FEES records data, where these data will be set into 
     * a parallel member in the transaction information object)
     * @param listAllFeeTypes
     * @param feesCalculationType
     * @param minf
     * @param fcOutputData
     * @param basicFeeCalcData void
     *
     */
//    private void iterateOnFeeTypesFound(List<FeeTypeUIDMsgFees> listAllFeeTypes,FeesCalculationType feesCalculationType
//                                         ,PDO pdo,FeesCalculationOutputData fcOutputData
//                                         , BasicFeesCalculationData basicFeeCalcData, List<MsgFees> otherPayingPartyList) throws FeesCalculationException
//    {
//        List<FeeFormula> listFeeFormula=new ArrayList<FeeFormula>();
//        List<MsgFees> listMsgFees=new ArrayList<MsgFees>();
//        FeeTypeUIDMsgFees feeTypeUIDMsgFees;
//        FeeFormula feeFormulaRecord;
//        FeeTypes feeType;
//        ApplyFee applyFeeFlag;
//        Accounts accountPandL;
//        MsgFees msgFee;
//        double dFeeAmount;
//        String sBaseOfficeCurrency=m_daoStaticData.getCurrency(pdo.getString(PDOConstantFieldsInterface.P_OFFICE)).getValue();
//        Map<String, Double> mapCurrencyConversion=new HashMap<String, Double>();
//        
//        
//        //boolean flags for Max and Floor validations
//        boolean[] arrMaxUnwindOccured=new boolean[]{false};
//        boolean[] arrFloorUnwindOccured=new boolean[]{false};
//        Double[] arrPrincipalAmount=new Double[]{null};
//        long lTime;
//        int iSize=listAllFeeTypes.size();
//        Accounts feesAccount=new Accounts();
//        //BackendTracer GlobalTracer=GlobalTracer;
//        
//        logger.info("FC - Starting iteration on fee types found");
//        for (int i=0;i<iSize && fcOutputData.getFeedback().isSuccessful();i++)
//        {//reset principal amount before each iteration.
//            arrPrincipalAmount[0]=null;
//            feeTypeUIDMsgFees=listAllFeeTypes.get(i);
//            
//            feeType= feeTypesKey.getSingle(feeTypeUIDMsgFees.getFeeTypeUid());
//            
//            logger.info("FC - Iteration on fee type "+feeTypeUIDMsgFees.getFeeTypeUid());
//            msgFee=feeTypeUIDMsgFees.getMsgFee();
//            //check if non manual method
//            if (msgFee==null||msgFee.getId() ==null || msgFee.getId().getFeeFormulaUid()==null||msgFee.getId().getFeeFormulaUid().length()==0)
//            {
//                logger.info("FC - Deriving fee formula by executing fee formula rule");
//                lTime=System.currentTimeMillis();
//                feeFormulaRecord=getFeeFormulaByExecutingFeeFormulaRule(feeType,basicFeeCalcData.getCustomer(),pdo);
//                logger.info("FC - Finished Deriving fee formula by executing fee formula rule - "+(System.currentTimeMillis()-lTime)+"ms");
//            }
//            else
//            {//retrieve fee formula according to MSG_FEES table (Manual)
//                logger.info("FC - Deriving fee formula from MSG_FEES");
//                lTime=System.currentTimeMillis();
//                feeFormulaRecord= feeFormulaKey.getSingle(msgFee.getId().getFeeFormulaUid()) ; 
//                logger.info("FC - Finished Deriving fee formula from MSG_FEES - "+(System.currentTimeMillis()-lTime)+"ms");
//            }
//            //There is a possibility that after above steps, we won't find a fee formula for a specific fee type; 
//            //this means that the customer won't be charged for this fee type.
//            if (feeFormulaRecord!=null)
//            {
//                
//                boolean deductFromConvertedToPayment = false;
//                //if deduct from account and fee calculation type credit and no fee account and processing syst par enables to continue
//                //set fee formula deduct from payment
//                if (feeFormulaRecord.getDeductFrom().equals(DeductFromType.A.name()) 
//                        && feesCalculationType==FeesCalculationType.CREDIT)
//                {
//                    if (!setFeesAccount(feesCalculationType,pdo,fcOutputData,feesAccount)
//                            && fcOutputData.getFeedback().isSuccessful())
//                    {
//                        feeFormulaRecord.setDeductFrom(DeductFromType.P.name());
//                        logger.info("FC - Deduct from account, payment type is credit, no fee account " +
/*@@__ SLF Migrator manual fix __@@@ remove closing parentheses in next line*/
//                              "and processing syst par enables to continue - then set deduct from payment"));
//                        deductFromConvertedToPayment=true;
//                    }
//                }else if (feesCalculationType==FeesCalculationType.AGENT
//                        && feeFormulaRecord.getDeductFrom().equals(DeductFromType.P.name()))
//                {
//                    feeFormulaRecord.setDeductFrom(DeductFromType.A.name());
//                    feeFormulaRecord.setApplyFee(ApplyFee.NOW.name());
//                }
//                logger.info("FC - Fee Formula found " + feeFormulaRecord.getUidFeeFormula());
//                applyFeeFlag=getApplyFeeFlag(feesCalculationType,pdo,feeFormulaRecord,msgFee.getApply());
//                accountPandL=loadPandLaccount(feeFormulaRecord,feeTypeUIDMsgFees.getFeeTypeUid(),pdo,applyFeeFlag,fcOutputData, feesCalculationType);
//                dFeeAmount=calculateFeeAccordingToFeeFormula(msgFee.getFeeAmount(),feeFormulaRecord,feesCalculationType,pdo
//                                                                ,sBaseOfficeCurrency,arrPrincipalAmount,mapCurrencyConversion
//                                                                ,fcOutputData);   
//                dFeeAmount=getMinMaxValidationForFeeFormula(dFeeAmount,feeFormulaRecord);
//                setOriginalFeeAmountToMsgFeesTable(dFeeAmount,feeTypeUIDMsgFees);
//                
//                
////                calculateTotalFees(dFeeAmount,feeFormulaRecord,fcOutputData,pdo,feesCalculationType,arrMaxUnwindOccured,arrFloorUnwindOccured
////                                    ,sBaseOfficeCurrency,mapCurrencyConversion,feesAccount);
//                
//                
//                setAdditionalMessageFeesFields(dFeeAmount,feeTypeUIDMsgFees,feeFormulaRecord,pdo,feesCalculationType,accountPandL
//                                                , fcOutputData,sBaseOfficeCurrency,mapCurrencyConversion,feesAccount,arrMaxUnwindOccured,arrFloorUnwindOccured);
//                
////                dFeeAmount=MaxAndFloorValidationAndAdjustment(arrMaxUnwindOccured,arrFloorUnwindOccured,fcOutputData,basicFeeCalcData
////                        ,feeFormulaRecord,dFeeAmount,pdo,basicFeeCalcData,sBaseOfficeCurrency,arrPrincipalAmount
////                        ,mapCurrencyConversion,msgFee);
//                
//                buildMsgFeesRecoredForCurrentHandledFeeType(msgFee,feeFormulaRecord,pdo,dFeeAmount,accountPandL,feeTypeUIDMsgFees.isManualFee()
//                                                            ,feeTypeUIDMsgFees.getFeeTypeUid(),basicFeeCalcData);
//                msgFee.setDeductFrom(feeFormulaRecord.getDeductFrom());
//                listMsgFees.add(msgFee);
//                //return the deduct from type as it was.
//                if (deductFromConvertedToPayment)
//                    feeFormulaRecord.setDeductFrom(DeductFromType.A.name());
//            }
//            else
//            {
//                logger.info("FC - no fee formula for fee type "+feeTypeUIDMsgFees.getFeeTypeUid());
//            }
//        }
//        logger.info("FC - Finished iteration on fee types the status is "+(fcOutputData.getFeedback().isSuccessful()
/*@@__ SLF Migrator manual fix __@@@ remove closing parentheses in next line*/
//                ? " successful " : " unsuccessful")));
//        if (fcOutputData.getFeedback().isSuccessful())
//        {
//            checkMaxAndFloorAndUpdateLogicalFields(pdo,listMsgFees, basicFeeCalcData, feesCalculationType);            
//            otherPayingPartyList.addAll(listMsgFees);
//            updateMsgFeesListToMinf(otherPayingPartyList,pdo);
//
//            if (feesAccount.getAccNo()!=null&&feesAccount.getAccNo().length()>0
//                    &&feesAccount.getCurrency()!=null&&feesAccount.getCurrency().length()>0
//                    &&feesAccount.getOffice()!=null&&feesAccount.getOffice().length()>0)
//            {
//                logger.info("FC - Set fee account");
//                fcOutputData.setFeeAccountCurrency(feesAccount.getCurrency());
//                fcOutputData.setFeeAccountNum(feesAccount.getAccNo());
//                fcOutputData.setFeeAccountOffice(feesAccount.getOffice());
//                if (feesCalculationType.equals(FeesCalculationType.CREDIT))
//                {
//                    pdo.set(PDOConstantFieldsInterface.P_CDT_FEE_ACCT_NB,feesAccount.getAccNo());
//                    pdo.set(PDOConstantFieldsInterface.P_CDT_FEE_ACCT_CCY,feesAccount.getCurrency());
//                    pdo.set(PDOConstantFieldsInterface.P_CDT_FEE_ACCT_OFFICE,feesAccount.getOffice());
//                }else //Debit or Agent. 
//                {
//                    pdo.set(PDOConstantFieldsInterface.P_DBT_FEE_ACCT_NB,feesAccount.getAccNo());
//                    pdo.set(PDOConstantFieldsInterface.P_DBT_FEE_ACCT_CCY,feesAccount.getCurrency());
//                    pdo.set(PDOConstantFieldsInterface.P_DBT_FEE_ACCT_OFFICE,feesAccount.getOffice());
//                }
//            }
//            
//        // If no fees were processed, skips this step.
////            if (!GlobalUtils.isNullOrEmpty(fcOutputData.getFeeAccountCurrency()) 
////                    || !GlobalUtils.isNullOrEmpty(fcOutputData.getPaymentCurrency()))
////            {          
////              setMessageInformationFromFcOutputData(feesCalculationType,fcOutputData,pdo,sBaseOfficeCurrency,mapCurrencyConversion,basicFeeCalcData);
////            }
//
//        }
//    }
    
//    private void updateOutputDataPresision(FeesCalculationOutputData fcOutputData, String sBaseCurrency)
//    {
//        if (fcOutputData.getAccountFeeAmount()>0)
//            fcOutputData.setAccountFeeAmount(adjustPrecision(fcOutputData.getAccountFeeAmount()
//                    ,(fcOutputData.getAccountFeeCurrency())));
//        if (fcOutputData.getAccountFeeEquivalentAmount()>0)
//            fcOutputData.setAccountFeeEquivalentAmount(adjustPrecision(fcOutputData.getAccountFeeEquivalentAmount()
//                    ,(sBaseCurrency)));
//        if (fcOutputData.getPaymentFeeAmount()>0)
//            fcOutputData.setPaymentFeeAmount(adjustPrecision(fcOutputData.getPaymentFeeAmount()
//                    ,(fcOutputData.getPaymentCurrency())));
//        if (fcOutputData.getPaymentFeeEquivalentAmount()>0)
//            fcOutputData.setPaymentFeeEquivalentAmount(adjustPrecision(fcOutputData.getPaymentFeeEquivalentAmount()
//                    ,(sBaseCurrency)));
//
//        
//    }
    
    /**
     * Method which checks if Unwind Method Type is ALL_REL_PCT.
     * If so, then calculates the percentage to be reduced from fee amount in each MSG_FEES record 
     * @param basicFeeCalcData
     * @param listAllFeeTypes
     * @param fcOutputData
     * @param feeCalcType
     * @param minf
     *
     */
//    private void checkForUnwindInCaseOfALL_REL_PCT(BasicFeesCalculationData basicFeeCalcData, List<FeeTypeUIDMsgFees> listAllFeeTypes
//            ,FeesCalculationOutputData fcOutputData, PDO pdo
//            ,String sBaseOfficeCurrency) throws FeesCalculationException
//    {
//        if (basicFeeCalcData.getUnwindMethodType().equals(UnwindMethodType.ALL_REL_PCT))
//        {
//            //BackendTracer GlobalTracer=GlobalTracer;
//            
//            logger.info("FC - Unwind method type ALL_REL_PCT found");
//            long lTime=System.currentTimeMillis();
//            double dMaxPercentage=1;
//            double dFloorPercentage=1;
//            if (basicFeeCalcData.getMaxFee()!=null
//                    &&(basicFeeCalcData.getMaxFee()<(fcOutputData.getPaymentFeeEquivalentAmount())
//                            +fcOutputData.getAccountFeeEquivalentAmount()))
//            {
//                logger.info("FC - Total fee amount greater then max limit");
//                dMaxPercentage=basicFeeCalcData.getMaxFee()/
//                            ((fcOutputData.getPaymentFeeEquivalentAmount())+fcOutputData.getAccountFeeEquivalentAmount());
//                
//                fcOutputData.setPaymentFeeAmount((fcOutputData.getPaymentFeeAmount()*dMaxPercentage));
//                fcOutputData.setPaymentFeeEquivalentAmount(fcOutputData.getPaymentFeeEquivalentAmount()*dMaxPercentage);
//                fcOutputData.setAccountFeeAmount(fcOutputData.getAccountFeeAmount()*dMaxPercentage);
//                fcOutputData.setAccountFeeEquivalentAmount(fcOutputData.getAccountFeeEquivalentAmount()*dMaxPercentage);
//            }
//
//            if (basicFeeCalcData.getFloorAmnt()!=null
//                    &&fcOutputData.getPaymentFeeEquivalentAmount()>0
//                    &&(basicFeeCalcData.getFloorAmnt()>pdo.getDecimal(PDOConstantFieldsInterface.P_BASE_AMT).doubleValue()
//                            -(fcOutputData.getPaymentFeeEquivalentAmount())))
//            {
//                logger.info("FC - Net amount exceed under floor amount");
//                dFloorPercentage=(pdo.getDecimal(PDOConstantFieldsInterface.P_BASE_AMT).doubleValue()-basicFeeCalcData.getFloorAmnt())
//                                                /(fcOutputData.getPaymentFeeEquivalentAmount());
//                if (dFloorPercentage>0)
//                {
//                    fcOutputData.setPaymentFeeAmount(fcOutputData.getPaymentFeeAmount()*dFloorPercentage);
//                    fcOutputData.setPaymentFeeEquivalentAmount(fcOutputData.getPaymentFeeEquivalentAmount()*dFloorPercentage);
//                }
//                else
//                {
//                    dFloorPercentage=1;
//                }
//            }
//            if (dMaxPercentage<1 || dFloorPercentage<1)
//            {
//                updatePercentageToAllMsgFeesAmounts(listAllFeeTypes,dFloorPercentage,dMaxPercentage,pdo,sBaseOfficeCurrency);
//            }
//            logger.info("FC - Finished Unwind method type ALL_REL_PCT found - "+(System.currentTimeMillis()-lTime)+"ms"); 
//        }
//    }
    
    /**
     * Method which validates if Unwind method should be activated and calculates the fee final amount.
     * This validation is valid only if Unwind Method Type equals FIRST_AMT or FIRST_REL_AMT
     * o/w if Unwind Method Type equals ALL_REL_PCT the method will return the original fee amount
     * @param arrMaxUnwindOccured
     * @param arrFloorUnwindOccured
     * @param fcOutputData
     * @param basicFeeCalcData
     * @param feeFormula
     * @param dFeeAmount
     * @param dPrincipalAmount
     * @param minf
     * @param feeCalcType
     * @param basicfeeCalcData
     * @return Final amount after Maximum and Floor validations
     *
     */
//    private double maxAndFloorValidationAndAdjustment(boolean[] arrMaxUnwindOccured,boolean[] arrFloorUnwindOccured
//            ,FeesCalculationOutputData fcOutputData,BasicFeesCalculationData basicFeeCalcData, FeeFormula feeFormula, double dFeeAmount
//            , PDO pdo, BasicFeesCalculationData basicfeeCalcData, String sBaseOfficeCurrency,Double[] arrPrincipalAmount
//            ,Map<String,Double>mapCurrencyConversion,MsgFees msgFees) throws FeesCalculationException
//    {
//        //BackendTracer GlobalTracer=GlobalTracer;
//        
//        logger.info("FC - Max And Floor validation and adjustment");
//        long lTime=System.currentTimeMillis();
//        double dFinalAmount=0;
//        //case Unwind Method Type equals FIRST_AMT or FIRST_REL_AMT.
//        //if total fee amount exceeded Maximum Fee Amount, return fee amount 0.
//        //o/w if total fee amount exceeded Floor Fee Amount but the Deduct From Type is Account then Max Fee Amount should be validated
//        if (!arrMaxUnwindOccured[0]
//           &&(!arrFloorUnwindOccured[0]||(arrFloorUnwindOccured[0]&&feeFormula.getDeductFrom().equals(DeductFromType.A.name()))))
//        {
//            dFinalAmount=maxAmountLimitValidationAndAdjustment(arrMaxUnwindOccured,fcOutputData,basicFeeCalcData,feeFormula,dFeeAmount,pdo
//                                                                ,sBaseOfficeCurrency,arrPrincipalAmount,mapCurrencyConversion
//                                                                ,msgFees);
//            //if total fee amount exceeded Floor Fee Amount the no need of validating the floor fee amount 
//            if (!arrFloorUnwindOccured[0])
//            {
//                dFinalAmount=floorAmountLimitValidationAndAdjustment(arrFloorUnwindOccured,fcOutputData,basicFeeCalcData,feeFormula
//                                                                    ,dFinalAmount,pdo,basicFeeCalcData,sBaseOfficeCurrency
//                                                                    ,arrPrincipalAmount,mapCurrencyConversion
//                                                                    ,msgFees);
//            }
//            else
//            {
//                logger.info("FC - Floor unwind already occured");
//            }
//        }
//        else
//        {
//            logger.info("FC - Max unwind already occured");
//        }
//        logger.info("FC - Fee amount = "+dFinalAmount + " "+feeFormula.getFeeCurrency()+" in - "+(System.currentTimeMillis()-lTime)+"ms");
//        return dFinalAmount;
//    }
//
    
    /**
     * Method which verifies if total fee amount exceeded max fee limit, if so, adjusting the fee amount according to 
     * unwind method type and updates the total fee amounts in FeeCalculationOutputData. 
     * @param arrMaxUnwindOccured
     * @param fcOutputData
     * @param basicfeeCalcData
     * @param feeFormula
     * @param dFeeAmount
     * @param minf
     * @param feeCalcType
     * @return final fee amount
     *
     */
//    private double maxAmountLimitValidationAndAdjustment(boolean[] arrMaxUnwindOccured, FeesCalculationOutputData fcOutputData
//            ,BasicFeesCalculationData basicFeeCalcData, FeeFormula feeFormula, double dFeeAmount, PDO pdo
//            , String sBaseOfficeCurrency,Double[] arrPrincipalAmount
//            , Map<String, Double>mapCurrencyConversion,MsgFees msgFees) throws FeesCalculationException
//    {
//        double dFinalFee=dFeeAmount;
//        //BackendTracer GlobalTracer=GlobalTracer;
//        
//        //The validation should be only for FIRST_AMT and FIRST_REL_AMT Unwind Method Types
//        if (!arrMaxUnwindOccured[0]&&!basicFeeCalcData.getUnwindMethodType().equals(UnwindMethodType.ALL_REL_PCT))
//        {
//            Float dMaxFee=basicFeeCalcData.getMaxFee();
//            double dTotalFees=fcOutputData.getPaymentFeeEquivalentAmount()+fcOutputData.getAccountFeeEquivalentAmount();
//            //if total fee amount greater then max limit then adjust the fee amount and set the Max Flag to true
//            //in order not to enter this validation again.
//            if (dMaxFee!=null&&dTotalFees > dMaxFee)
//            {
//                logger.info("FC - Total fee amount = "+dTotalFees+" "+sBaseOfficeCurrency+" greater then max limit = " 
/*@@__ SLF Migrator manual fix __@@@ remove closing parentheses in next line*/
//                        + dMaxFee + " "+sBaseOfficeCurrency));
//                arrMaxUnwindOccured[0]=true;
//                dFinalFee=basicFeeCalcData.getUnwindMethodType().equals(UnwindMethodType.FIRST_AMT)?0:dTotalFees-dMaxFee;
//                //subtract the exceeded fee amount from total fee amount   
//                logger.info("FC - Adjust total fees");
//                dFinalFee=adjustTotalFees(dFeeAmount,dFinalFee,pdo,feeFormula,fcOutputData,sBaseOfficeCurrency,arrPrincipalAmount
//                                            ,mapCurrencyConversion,msgFees);
//            }
//            else
//                logger.info("FC - Total fee amount = "+dTotalFees+" "+sBaseOfficeCurrency+" less then max limit = " 
/*@@__ SLF Migrator manual fix __@@@ remove closing parentheses in next line*/
//                        + dMaxFee + " "+sBaseOfficeCurrency));
//                
//        }
//        return dFinalFee;
//    }
    
    /**
     * Method which verifies if total fee amount from payment exceeded floor limit amount, if so, adjusting the fee amount according to 
     * unwind method type and updates the total fee amounts in FeeCalculationOutputData.
     * @param arrFloorUnwindOccured
     * @param fcOutputData
     * @param basicFeeCalcData
     * @param feeFormula
     * @param dFeeAmount
     * @param minf
     * @param feeCalcType
     * @param basicfeeCalcData
     * @return final fee amount
     *
     */
//    private double floorAmountLimitValidationAndAdjustment(boolean[] arrFloorUnwindOccured,FeesCalculationOutputData fcOutputData
//            ,BasicFeesCalculationData basicFeeCalcData, FeeFormula feeFormula, double dFeeAmount
//            , PDO pdo, BasicFeesCalculationData basicfeeCalcData,String sBaseOfficeCurrency,Double[] arrPrincipalAmount
//            ,Map<String,Double>mapCurrencyConversion, MsgFees msgFees) throws FeesCalculationException
//    {
//        double dFinalFee=dFeeAmount;
//        //The validation should be only for fees deducted from payment and for FIRST_AMT and FIRST_REL_AMT Unwind Method Types
//        if (!arrFloorUnwindOccured[0]&&feeFormula.getDeductFrom().equals(DeductFromType.P.name())
//                &&!basicfeeCalcData.getUnwindMethodType().equals(UnwindMethodType.ALL_REL_PCT))
//        {
//            Float dFloorAmount=basicFeeCalcData.getFloorAmnt();
//            double dNetAmount=pdo.getDecimal(PDOConstantFieldsInterface.P_BASE_AMT).doubleValue()-fcOutputData.getPaymentFeeEquivalentAmount();
//            //check if base amount minus total fee from payment exceed under floor amount. 
//            if (dFloorAmount!=null&&dNetAmount<dFloorAmount)
//            {
//                //BackendTracer GlobalTracer=GlobalTracer;
//                
//                logger.info("FC - Net amount = "+dNetAmount+" "+sBaseOfficeCurrency+" exceed under floor limit - "
/*@@__ SLF Migrator manual fix __@@@ remove closing parentheses in next line*/
//                        +dFloorAmount + " "+sBaseOfficeCurrency));
//                arrFloorUnwindOccured[0]=true;
//                dFinalFee=basicFeeCalcData.getUnwindMethodType().equals(UnwindMethodType.FIRST_AMT)?0:dFloorAmount-dNetAmount;
//                //adjust the total fee from payment.
//                logger.info("FC - Adjust the total fee from payment");
//                dFinalFee=adjustTotalFees(dFeeAmount,dFinalFee,pdo,feeFormula,fcOutputData,sBaseOfficeCurrency,arrPrincipalAmount
//                                            ,mapCurrencyConversion,msgFees);
//            }
//        }
//        return dFinalFee;
//    }
    
    /**
     * Method which adjust the total fees, subtract the exceeded fee amount from total fee amount  
     * 
     * @param dFeeAmount
     * @param dFinalFee
     * @param minf
     * @param feeFormula
     * @param fcOutputData
     * @param feeCalcType void
     *
     */
//    private double adjustTotalFees(double dFeeAmount, double dFinalFee, PDO pdo, FeeFormula feeFormula
//                                ,FeesCalculationOutputData fcOutputData
//                                ,String sBaseOfficeCurrency,Double[] arrPrincipalAmount
//                                ,Map<String,Double>mapCurrencyConversion, MsgFees msgFees) throws FeesCalculationException
//    {
//        double dFeeAmountInBaseCurrencyToDeduct;
//        double dFeeAmountInAccountCurrencyToDeduct;
//        double dFeeAmountInPaymentCurrencyToDeduct;
//        double dValueToReturn;
////        double dPrincipleAmount=calculatePrincipalAmount(feeFormula.getFeeCurrency(),pdo,feeCalcType,sBaseOfficeCurrency,arrPrincipalAmount
////                                                            ,mapCurrencyConversion,fcOutputData);
//        //BackendTracer GlobalTracer=GlobalTracer;
//        
//        
//        if (dFinalFee==0)
//        {
//            dValueToReturn=0;
//            dFeeAmountInBaseCurrencyToDeduct=msgFees.getFeeBaseAmount() != null ? msgFees.getFeeBaseAmount() : 0;
//            logger.info("FC - Fee amount in base ccy to deduct {}",dFeeAmountInBaseCurrencyToDeduct);
//            if (feeFormula.getDeductFrom().equals(DeductFromType.A.name()))
//            {
//                logger.info("FC - Deduct from account");
//                dFeeAmountInAccountCurrencyToDeduct=msgFees.getFeeAccAmount() != null ? msgFees.getFeeAccAmount() : 0;
//                
//                
//                logger.info("FC - Fee amount in fee account ccy to deduct {}",dFeeAmountInAccountCurrencyToDeduct);
//                double amount = fcOutputData.getAccountFeeEquivalentAmount()-dFeeAmountInBaseCurrencyToDeduct;
//                fcOutputData.setAccountFeeEquivalentAmount(amount);
//                logger.info("FC - Account Fee Equivalent Amount {}",amount);
//                
//                amount = fcOutputData.getAccountFeeAmount()-dFeeAmountInAccountCurrencyToDeduct;
//                fcOutputData.setAccountFeeAmount(amount);
//                logger.info("FC - Account Fee Amount {}",amount);
//                
//                msgFees.setFeeAccAmount(adjustPrecision(((msgFees.getFeeAccAmount()!=null ? msgFees.getFeeAccAmount() : 0)
//                                -dFeeAmountInAccountCurrencyToDeduct),(fcOutputData.getAccountFeeCurrency())));
//            }else //deduct from payment.
//            {
//                logger.info("FC - Deduct from payment");
//                dFeeAmountInPaymentCurrencyToDeduct = msgFees.getFeeAmountInPmtCcy() != null ? msgFees.getFeeAmountInPmtCcy() : 0;
//                logger.info("FC - Fee Amount In Payment Currency To Deduct {}",dFeeAmountInPaymentCurrencyToDeduct);
//                
//                double amount = fcOutputData.getPaymentFeeEquivalentAmount()-dFeeAmountInBaseCurrencyToDeduct;
//                fcOutputData.setPaymentFeeEquivalentAmount(amount);
//                logger.info("FC - Payment Fee Equivalent Amount {}",amount);
//                
//                amount = fcOutputData.getPaymentFeeAmount()-dFeeAmountInPaymentCurrencyToDeduct;
//                fcOutputData.setPaymentFeeAmount(amount);
//                logger.info("FC - Payment Fee Amount {}",amount);
//                
//                msgFees.setFeeAmountInPmtCcy(adjustPrecision(((msgFees.getFeeAmountInPmtCcy()!=null ? msgFees.getFeeAmountInPmtCcy() : 0)
//                                -dFeeAmountInPaymentCurrencyToDeduct),(fcOutputData.getPaymentCurrency())));
//            }
//            
//             
//        }
//        else
//        {
//        
//            if (feeFormula.getDeductFrom().equals(DeductFromType.A.name()))
//            {
//                logger.info("FC - Deduct from account");
//                dFeeAmountInBaseCurrencyToDeduct=dFinalFee;
//                logger.info("FC - Fee Amount In Base Currency To Deduct {}",dFeeAmountInBaseCurrencyToDeduct);
//                
//                double dRelation=msgFees.getFeeBaseAmount()/dFeeAmountInBaseCurrencyToDeduct;
//                dFeeAmountInAccountCurrencyToDeduct=(msgFees.getFeeAccAmount()!=null ? msgFees.getFeeAccAmount() : 0)/dRelation;
//                dValueToReturn=adjustPrecision((dFeeAmount-(dFeeAmount/dRelation)),(feeFormula.getFeeCurrency()));   
//    
//                double amount = fcOutputData.getAccountFeeEquivalentAmount()-dFeeAmountInBaseCurrencyToDeduct;
//                fcOutputData.setAccountFeeEquivalentAmount(amount);
//                logger.info("FC - Account Fee Equivalent Amount {}",amount);
//                
//                amount = fcOutputData.getAccountFeeAmount()-dFeeAmountInAccountCurrencyToDeduct;
//                fcOutputData.setAccountFeeAmount(amount);
//                logger.info("FC - Account Fee Amount {}",amount);
//                
//                msgFees.setFeeAccAmount(adjustPrecision(((msgFees.getFeeAccAmount()!=null ? msgFees.getFeeAccAmount() : 0)
//                                -dFeeAmountInAccountCurrencyToDeduct),(fcOutputData.getAccountFeeCurrency())));
//            }
//            else //deduct from payment.
//            {
//                logger.info("FC - Deduct from payment");
//                
//                dFeeAmountInBaseCurrencyToDeduct=dFinalFee;
//                logger.info("FC - Fee Amount In Base Currency To Deduct {}",dFeeAmountInBaseCurrencyToDeduct);
//                
//                double dRelation=msgFees.getFeeBaseAmount()/dFeeAmountInBaseCurrencyToDeduct;
//                dFeeAmountInPaymentCurrencyToDeduct=(msgFees.getFeeAmountInPmtCcy()!=null ? msgFees.getFeeAmountInPmtCcy() : 0)/dRelation;
//                dValueToReturn=adjustPrecision((dFeeAmount - (dFeeAmount/dRelation)),(feeFormula.getFeeCurrency()));   
//
//                double amount = fcOutputData.getPaymentFeeEquivalentAmount()-dFeeAmountInBaseCurrencyToDeduct;
//                fcOutputData.setPaymentFeeEquivalentAmount(amount);
//                logger.info("FC - Payment Fee Equivalent Amount {}",amount);
//                
//                amount = fcOutputData.getPaymentFeeAmount()-dFeeAmountInPaymentCurrencyToDeduct;
//                fcOutputData.setPaymentFeeAmount(amount);
//                logger.info("FC - Payment Fee Amount {}",amount);
//                
//                
//                msgFees.setFeeAmountInPmtCcy(adjustPrecision(((msgFees.getFeeAmountInPmtCcy()!=null ? msgFees.getFeeAmountInPmtCcy() : 0)
//                                -dFeeAmountInPaymentCurrencyToDeduct),(fcOutputData.getPaymentCurrency())));
//            }
//        }
//        msgFees.setFeeBaseAmount(adjustPrecision((msgFees.getFeeBaseAmount()-dFeeAmountInBaseCurrencyToDeduct)
//                                        ,(sBaseOfficeCurrency)));
//        return dValueToReturn;        
//    }

    
//    /**
//     * Methods which receives fee amount from new iteration and updates the total fees amount  
//     * @param dFeeAmount
//     * @param feeFormula
//     * @param fcOutputData
//     * @param minf
//     * @param feeCalculationType
//     * @param arrMaxUnwindOccured
//     * @param arrFloorUnwindOccured
//     *
//     */
//    private void calculateTotalFees(double dFeeAmount,FeeFormula feeFormula, FeesCalculationOutputData fcOutputData, PDO pdo
//            ,FeesCalculationType feeCalculationType, boolean[] arrMaxUnwindOccured
//            , boolean[] arrFloorUnwindOccured,String sBaseOfficeCurrency
//            ,Map<String,Double>mapCurrencyConversion, Accounts feesAccount) throws FeesCalculationException
//    {
//        //BackendTracer GlobalTracer=GlobalTracer;
//        
//        logger.info("FC - Calculating total fees");
//        long lTime=System.currentTimeMillis();
//        if (feeFormula.getDeductFrom().equals(DeductFromType.A.name()))
//        {
//            calculateTotalFeesDeductFromAccount(dFeeAmount,feeFormula,fcOutputData,pdo,feeCalculationType,arrMaxUnwindOccured
//                    ,arrFloorUnwindOccured,sBaseOfficeCurrency,mapCurrencyConversion,feesAccount);
//        }
//        else //payment
//        {
//            calculateTotalFeesDeductFromPayment(dFeeAmount,feeFormula,fcOutputData,pdo,feeCalculationType,arrMaxUnwindOccured
//                    ,arrFloorUnwindOccured,sBaseOfficeCurrency,mapCurrencyConversion);
//        }
//        logger.info("FC - Finished Calculating total fees - "+(System.currentTimeMillis()-lTime)+"ms");
//    }

    
    
//    /**
//     * Methods which receives fee amount from new iteration and updates the total fees amount where Deduct From equals Account
//     * @param dFeeAmount
//     * @param feeFormula
//     * @param fcOutputData
//     * @param minf
//     * @param feeCalculationType
//     * @param arrMaxUnwindOccured
//     * @param arrFloorUnwindOccured void
//     *
//     */
//    private void calculateTotalFeesDeductFromAccount(double dFeeAmount,FeeFormula feeFormula, FeesCalculationOutputData fcOutputData
//            , PDO pdo,FeesCalculationType feeCalculationType, boolean[] arrMaxUnwindOccured
//            , boolean[] arrFloorUnwindOccured,String sBaseOfficeCurrency
//            ,Map<String,Double>mapCurrencyConversion, Accounts feesAccount) throws FeesCalculationException
//    {
//        //if the total fees already exceeded the max fee amount then the fee amount will be zero, therefore, no need to add them
//        //to total fee amount.
//        //BackendTracer GlobalTracer=GlobalTracer;
//        
//        logger.info("FC - Calcualting total fees - Deduct from account");
//        if (!arrMaxUnwindOccured[0])
//        {
//            logger.info("FC - Max unwind not occured");
//            double dConvertedAmount;
//            String sCurrency=null;
//            if (setFeesAccount(feeCalculationType,pdo,fcOutputData,feesAccount))
//            {
//                logger.info("FC - Fee account exists");
//                sCurrency=feesAccount.getCurrency();
//            }
//            else
//            {
//                logger.info("FC - Fee account doesn't exist");
//                
//                if (feeCalculationType.equals(FeesCalculationType.DEBIT) || feeCalculationType.equals(FeesCalculationType.AGENT))
//                    sCurrency=pdo.getString(PDOConstantFieldsInterface.P_DBT_ACCT_CCY);
//                if (feeCalculationType.equals(FeesCalculationType.CREDIT))
//                    sCurrency=pdo.getString(PDOConstantFieldsInterface.P_CDT_ACCT_CCY);
//            }
//            if (sCurrency!=null&&sCurrency.length()>0)
//            {
//                logger.info("FC - Convert to "+sCurrency+" currency");
//                dConvertedAmount=convertCurrency(feeFormula.getFeeCurrency(),sCurrency,dFeeAmount
//                        ,feeCalculationType,pdo,true,sBaseOfficeCurrency,mapCurrencyConversion,fcOutputData);
//                fcOutputData.setAccountFeeAmount(fcOutputData.getAccountFeeAmount()+dConvertedAmount);
//                //convert to base currency
//                dConvertedAmount=convertCurrency(feeFormula.getFeeCurrency(),sBaseOfficeCurrency,dFeeAmount
//                        ,feeCalculationType,pdo,false,sBaseOfficeCurrency,mapCurrencyConversion,fcOutputData);
//                fcOutputData.setAccountFeeEquivalentAmount(fcOutputData.getAccountFeeEquivalentAmount()+dConvertedAmount);
//                fcOutputData.setAccountFeeCurrency(sCurrency);
//            }
//        }
//    }
    
    
    
//    /**
//     * Methods which receives fee amount from new iteration and updates the total fees amount where Deduct From equals Payment
//     * @param dFeeAmount
//     * @param feeFormula
//     * @param fcOutputData
//     * @param minf
//     * @param feeCalculationType
//     * @param arrMaxUnwindOccured
//     * @param arrFloorUnwindOccured void
//     *
//     */
//    private void calculateTotalFeesDeductFromPayment(double dFeeAmount,FeeFormula feeFormula, FeesCalculationOutputData fcOutputData
//            , PDO pdo,FeesCalculationType feeCalculationType, boolean[] arrMaxUnwindOccured
//            , boolean[] arrFloorUnwindOccured,String sBaseOfficeCurrency
//            ,Map<String,Double>mapCurrencyConversion) throws FeesCalculationException
//    {
//        //if the total fees already exceeded the max fee amount then the fee amount will be zero, therefore, no need to add them
//        //to total fee amount.
//        //if the max limit hasn't been reached and deduct from type is payment then check the floor amount flag.
//        //BackendTracer GlobalTracer=GlobalTracer;
//        
//        logger.info("FC - Calcualting total fees - Deduct from payment");
//        if (!arrMaxUnwindOccured[0]&&!arrFloorUnwindOccured[0])
//        {
//            logger.info("FC - Max and Floor unwind not occured");
//            double dConvertedAmount;
//
//            dConvertedAmount=convertCurrency(feeFormula.getFeeCurrency(),pdo.getString(PDOConstantFieldsInterface.P_CDT_ACCT_CCY),dFeeAmount
//                    ,feeCalculationType,pdo,true,sBaseOfficeCurrency,mapCurrencyConversion,fcOutputData);
//            
//            fcOutputData.setPaymentFeeAmount(fcOutputData.getPaymentFeeAmount()+dConvertedAmount);
//            dConvertedAmount=convertCurrency(feeFormula.getFeeCurrency(),sBaseOfficeCurrency,dFeeAmount
//                    ,feeCalculationType,pdo,false,sBaseOfficeCurrency,mapCurrencyConversion,fcOutputData);
//            fcOutputData.setPaymentFeeEquivalentAmount(fcOutputData.getPaymentFeeEquivalentAmount()+dConvertedAmount);
//        }
//    }
//
    
//    /**
//     * Method which finds Rate Usage according to Debit/Credit calculation type
//     * @param minf
//     * @param feeCalculationType
//     * @return RateUsage
//     *
//     */
//    private RateUsage getRateUsage(PDO pdo, FeesCalculationType feeCalculationType)
//    {
//        String sRateUsageNM="";
//        if (feeCalculationType.equals(FeesCalculationType.DEBIT))
//        {
//            sRateUsageNM=pdo.getString(PDOConstantFieldsInterface.P_DBT_RATE_USAGE_NM);
//        }
//        else if (feeCalculationType.equals(FeesCalculationType.CREDIT))
//        {
//            sRateUsageNM=pdo.getString(PDOConstantFieldsInterface.P_CDT_RATE_USAGE_NM);
//        }
//        return (RateUsage) CacheKeys.rateUsageKey.getSingle(sRateUsageNM) ;
//    }
//    
//    
//    private double getPrincipalAmountInBaseCurrency(String sFromCurrency, double dAmount, PDO pdo
//            , FeesCalculationType feesCalcType,String sBaseOfficeCurrency) throws FeeCalculationException
//    {
//        if (m_dPrincipalAmountInBaseCurrency==null)
//        {
//            m_dPrincipalAmountInBaseCurrency=
//                convertCurrency(sFromCurrency,sBaseOfficeCurrency,dAmount,feesCalcType,minf,false,sBaseOfficeCurrency);
//        }
//        return m_dPrincipalAmountInBaseCurrency;
//    }
    
    /**
     * Method which verifies if Min fee amount greater then payment amount
     * @param basicFeeCalcData
     * @param minf
     * @param feeCalculationType
     * @return true if Min fee amount > payment amount, false o/w
     *
     */
//    private boolean isMinFeeAmountGreaterThenPaymentAmount(BasicFeesCalculationData basicFeeCalcData,PDO pdo
//                                                            , FeesCalculationType feesCalculationType
//                                                            , String sBaseOfficeCurrency,Map<String,Double>mapCurrencyConversion
//                                                            , FeesCalculationOutputData fcOutput) throws FeesCalculationException
//    {
//        boolean flag=false;
//        double dPaymentAmount=pdo.getDecimal(PDOConstantFieldsInterface.X_STTLM_AMT).doubleValue();
//        String sPaymentCurrency=pdo.getString(PDOConstantFieldsInterface.X_STTLM_CCY);
//        
//        double dMinFeeAmount=Double.valueOf(
//                  SystParKey.getSingleParmValue(pdo.getString(PDOConstantFieldsInterface.P_OFFICE)
//                            ,SystemParametersInterface.SYS_PAR_FLOORAMT))  ;
//                  
//        String sMinFeeCurrency=  SystParKey.getSingleParmValue(pdo.getString(PDOConstantFieldsInterface.P_OFFICE)
//                            ,SystemParametersInterface.SYS_PAR_MINFEECUR) ; 
//        
//        //convert Payment Amount to Min Fee Currency amount
//        dPaymentAmount=convertCurrency(sPaymentCurrency,sMinFeeCurrency,dPaymentAmount,feesCalculationType
//                ,pdo,false,sBaseOfficeCurrency,mapCurrencyConversion,fcOutput);
//        if (dMinFeeAmount>dPaymentAmount)
//        {
//            flag=true; 
//        }
//        return flag;
//    }
//    
    
//    private void checkForUnwindInCaseOfALL_REL_PCT(BasicFeesCalculationData basicFeeCalcData, List<FeeTypeUIDMsgFees> listAllFeeTypes
//            ,FeesCalculationOutputData fcOutputData, PDO pdo
//            ,String sBaseOfficeCurrency) throws FeesCalculationException
//    {
//        if (basicFeeCalcData.getUnwindMethodType().equals(UnwindMethodType.ALL_REL_PCT))
//        {
//            //BackendTracer GlobalTracer=GlobalTracer;
//            
//            logger.info("FC - Unwind method type ALL_REL_PCT found");
//            long lTime=System.currentTimeMillis();
//            double dMaxPercentage=1;
//            double dFloorPercentage=1;
//            if (basicFeeCalcData.getMaxFee()!=null
//                    &&(basicFeeCalcData.getMaxFee()<(fcOutputData.getPaymentFeeEquivalentAmount())
//                            +fcOutputData.getAccountFeeEquivalentAmount()))
//            {
//                logger.info("FC - Total fee amount greater then max limit");
//                dMaxPercentage=basicFeeCalcData.getMaxFee()/
//                            ((fcOutputData.getPaymentFeeEquivalentAmount())+fcOutputData.getAccountFeeEquivalentAmount());
//                
//                fcOutputData.setPaymentFeeAmount((fcOutputData.getPaymentFeeAmount()*dMaxPercentage));
//                fcOutputData.setPaymentFeeEquivalentAmount(fcOutputData.getPaymentFeeEquivalentAmount()*dMaxPercentage);
//                fcOutputData.setAccountFeeAmount(fcOutputData.getAccountFeeAmount()*dMaxPercentage);
//                fcOutputData.setAccountFeeEquivalentAmount(fcOutputData.getAccountFeeEquivalentAmount()*dMaxPercentage);
//            }
//
//            if (basicFeeCalcData.getFloorAmnt()!=null
//                    &&fcOutputData.getPaymentFeeEquivalentAmount()>0
//                    &&(basicFeeCalcData.getFloorAmnt()>pdo.getDecimal(PDOConstantFieldsInterface.P_BASE_AMT).doubleValue()
//                            -(fcOutputData.getPaymentFeeEquivalentAmount())))
//            {
//                logger.info("FC - Net amount exceed under floor amount");
//                dFloorPercentage=(pdo.getDecimal(PDOConstantFieldsInterface.P_BASE_AMT).doubleValue()-basicFeeCalcData.getFloorAmnt())
//                                                /(fcOutputData.getPaymentFeeEquivalentAmount());
//                if (dFloorPercentage>0)
//                {
//                    fcOutputData.setPaymentFeeAmount(fcOutputData.getPaymentFeeAmount()*dFloorPercentage);
//                    fcOutputData.setPaymentFeeEquivalentAmount(fcOutputData.getPaymentFeeEquivalentAmount()*dFloorPercentage);
//                }
//                else
//                {
//                    dFloorPercentage=1;
//                }
//            }
//            if (dMaxPercentage<1 || dFloorPercentage<1)
//            {
//                updatePercentageToAllMsgFeesAmounts(listAllFeeTypes,dFloorPercentage,dMaxPercentage,pdo,sBaseOfficeCurrency);
//            }
//            logger.info("FC - Finished Unwind method type ALL_REL_PCT found - "+(System.currentTimeMillis()-lTime)+"ms"); 
//        }
//    }
    
//    public void setMessageInformationFromFcOutputData(FeesCalculationType feesCalculationType, FeesCalculationOutputData fcOutputData
//                                                        ,PDO pdo, String sBaseCurrency, Map mapCurrencyConversion, BasicFeesCalculationData basicFeeCalculation) throws FeesCalculationException
//    {
//        //BackendTracer GlobalTracer=GlobalTracer;
//        
//        
//        if (feesCalculationType.equals(FeesCalculationType.DEBIT))
//        {   
//            pdo.set(PDOConstantFieldsInterface.D_DBT_FEE_ACCT_AMT,BigDecimal.valueOf(fcOutputData.getAccountFeeAmount()));
//            pdo.set(PDOConstantFieldsInterface.D_DBT_FEE_ACCT_BASEEQVT,BigDecimal.valueOf(fcOutputData.getAccountFeeEquivalentAmount()));
//            pdo.set(PDOConstantFieldsInterface.D_DBT_FEE_ACCT_CCY,fcOutputData.getAccountFeeCurrency());
//            pdo.set(PDOConstantFieldsInterface.D_DBT_FEE_PMT_DEDUCT_AMT,BigDecimal.valueOf(fcOutputData.getPaymentFeeAmount()));
//            pdo.set(PDOConstantFieldsInterface.D_DBT_FEE_PMT_DEDUCT_BASEEQVT,BigDecimal.valueOf(fcOutputData.getPaymentFeeEquivalentAmount()));            
//
//            
////          set to D_DBT_MAIN_POST_AMT logical field P_DBT_AMT (+ P_DBT_FEE_ACCT_AMT in case there is no fee account)                               
//            
//            double dbtAmount = pdo.getDecimal(PDOConstantFieldsInterface.P_DBT_AMT) != null
//                                ? pdo.getDecimal(PDOConstantFieldsInterface.P_DBT_AMT).doubleValue() : 0;
//          
//            if (!fcOutputData.isFeeAccountExist())
//                dbtAmount+=fcOutputData.getAccountFeeAmount();
//                                
//            pdo.set(PDOConstantFieldsInterface.D_DBT_MAIN_POST_AMT,dbtAmount );
//                                
//                                
//            logger.info("FC - Map debit side logical fields");
//        } else if (feesCalculationType.equals(FeesCalculationType.CREDIT))
//        {
//            pdo.set(PDOConstantFieldsInterface.D_CDT_FEE_ACCT_AMT,BigDecimal.valueOf(fcOutputData.getAccountFeeAmount()));
//            pdo.set(PDOConstantFieldsInterface.D_CDT_FEE_ACCT_BASEEQVT,BigDecimal.valueOf(fcOutputData.getAccountFeeEquivalentAmount()));
//            pdo.set(PDOConstantFieldsInterface.D_CDT_FEE_PMT_DEDUCT_AMT,BigDecimal.valueOf(fcOutputData.getPaymentFeeAmount()));
//            pdo.set(PDOConstantFieldsInterface.D_CDT_FEE_PMT_DEDUCT_BASEEQVT,BigDecimal.valueOf(fcOutputData.getPaymentFeeEquivalentAmount()));
//            
//            logger.info("FC - Map credit side logical fields");
//        }
//        
//        double dbtAmount = pdo.getDecimal(PDOConstantFieldsInterface.D_DBT_FEE_PMT_DEDUCT_AMT) != null 
//                            ? pdo.getDecimal(PDOConstantFieldsInterface.D_DBT_FEE_PMT_DEDUCT_AMT).doubleValue() : 0;
//                            
//        double cdtAmount = pdo.getDecimal(PDOConstantFieldsInterface.D_CDT_FEE_PMT_DEDUCT_AMT) != null 
//                            ? pdo.getDecimal(PDOConstantFieldsInterface.D_CDT_FEE_PMT_DEDUCT_AMT).doubleValue() : 0;
//        
//        
//                            
//        pdo.set(PDOConstantFieldsInterface.D_TOT_FEE_PMT_DEDUCT_AMT,dbtAmount+cdtAmount );
//        
//        double dbtBaseAmount = pdo.getDecimal(PDOConstantFieldsInterface.D_DBT_FEE_PMT_DEDUCT_BASEEQVT) != null 
//                            ? pdo.getDecimal(PDOConstantFieldsInterface.D_DBT_FEE_PMT_DEDUCT_BASEEQVT).doubleValue() : 0;
//                            
//        double cdtBaseAmount = pdo.getDecimal(PDOConstantFieldsInterface.D_CDT_FEE_PMT_DEDUCT_BASEEQVT) != null 
//                            ? pdo.getDecimal(PDOConstantFieldsInterface.D_CDT_FEE_PMT_DEDUCT_BASEEQVT).doubleValue() : 0;
//                            
//        
//        pdo.set(PDOConstantFieldsInterface.D_TOT_FEE_PMT_DEDUCT_BASEEQVT,dbtBaseAmount+cdtBaseAmount);
//        
//
//        pdo.set(PDOConstantFieldsInterface.X_STTLM_AMT,pdo.getDecimal(PDOConstantFieldsInterface.P_CDT_AMT).doubleValue() - (dbtAmount+cdtAmount));  
//        
//        
//        if (basicFeeCalculation.getChargeBearer() != null)
//        {
//            pdo.set(PDOConstantFieldsInterface.P_CHRG_BR,basicFeeCalculation.getChargeBearer().name());
//            pdo.set(PDOConstantFieldsInterface.X_CHRG_BR,basicFeeCalculation.getChargeBearer().name());
//        }
//        
//        
//        
//        pdo.set(PDOConstantFieldsInterface.MF_FEE_PROC_STS,"P");
//        
//    }
    
//    private boolean maxAmountLimitValidationAndAdjustment(PDO pdo, List<MsgFees> listMsgFees,BasicFeesCalculationData basicFeeCalcData) 
//    throws FeesCalculationException
//{
////BackendTracer GlobalTracer=GlobalTracer;
//
//double dTotalFees = 0;
//boolean flag = false;
//String baseOfficeCurrency = pdo.getString(PDOConstantFieldsInterface.P_BASE_CCY);
//
//
//logger.info("FC - Adjust total fees");
//double feeAccEqvt = 0;
//double feePmtEqvt = 0;
//feeAccEqvt = (pdo.getDecimal(PDOConstantFieldsInterface.D_DBT_FEE_ACCT_BASEEQVT) != null ? pdo.getDecimal(PDOConstantFieldsInterface.D_DBT_FEE_ACCT_BASEEQVT).doubleValue() : 0)
//+ (pdo.getDecimal(PDOConstantFieldsInterface.D_CDT_FEE_ACCT_BASEEQVT) != null ? pdo.getDecimal(PDOConstantFieldsInterface.D_CDT_FEE_ACCT_BASEEQVT).doubleValue() : 0);
//feePmtEqvt = (pdo.getDecimal(PDOConstantFieldsInterface.D_DBT_FEE_PMT_DEDUCT_BASEEQVT) != null ? pdo.getDecimal(PDOConstantFieldsInterface.D_DBT_FEE_PMT_DEDUCT_BASEEQVT).doubleValue() : 0)
//+ (pdo.getDecimal(PDOConstantFieldsInterface.D_CDT_FEE_PMT_DEDUCT_BASEEQVT) != null ? pdo.getDecimal(PDOConstantFieldsInterface.D_CDT_FEE_PMT_DEDUCT_BASEEQVT).doubleValue() : 0);
//
//dTotalFees = feeAccEqvt + feePmtEqvt;
//
//logger.info("FC - Total fee amount = "+dTotalFees+" "+baseOfficeCurrency+" greater then max limit = " 
/*@@__ SLF Migrator manual fix __@@@ remove closing parentheses in next line*/
//+ basicFeeCalcData.getMaxFee() + " "+baseOfficeCurrency));
//
//
//
//
//
//
////if total fee amount greater then max limit then adjust the fee amount and set the Max Flag to true
////in order not to enter this validation again.
//if (basicFeeCalcData.getMaxFee()!=null&&dTotalFees > basicFeeCalcData.getMaxFee())
//{
//
//
//double maxFee = basicFeeCalcData.getMaxFee();
//double totalFee = 0;
//int i=0;
//int msgFeeToAdjustIdx=-1;
//int length = listMsgFees.size();
////        find the message fee which exceed the max fee
//while (i<length && maxFee >= totalFee)
//{
//totalFee+=listMsgFees.get(i++).getFeeBaseAmount();
//}
//
////        set the location of the msg. fee that should be unwind
//if (totalFee > maxFee) msgFeeToAdjustIdx = i-1;
//
////        set to 0 next msg fees 
//resetMsgFeesList(listMsgFees, i, true);
//
//if (msgFeeToAdjustIdx > -1)
//{
//logger.info("FC - performing the unwind according to {} unwind method on record number {}",basicFeeCalcData.getUnwindMethodType().name(), msgFeeToAdjustIdx);
//adjustMsgFee(listMsgFees.get(msgFeeToAdjustIdx), (basicFeeCalcData.getUnwindMethodType() == UnwindMethodType.FIRST_REL_AMT ? (totalFee - maxFee) : 0d),baseOfficeCurrency);
//flag = true;
//}
//}
//
//return flag;
//}
//
//    
//
//    
//    /**
//     * Method which checks if Unwind Method Type is ALL_REL_PCT.
//     * If so, then calculates the percentage to be reduced from fee amount in each MSG_FEES record 
//     * @param basicFeeCalcData
//     * @param listAllFeeTypes
//     * @param fcOutputData
//     * @param feeCalcType
//     * @param minf
//     *
//     */
//    private boolean checkForUnwindInCaseOfALL_REL_PCT(PDO pdo, List<MsgFees> msgFeesList, BasicFeesCalculationData basicFeeCalcData) throws FeesCalculationException
//    {
//        //BackendTracer GlobalTracer=GlobalTracer;
//        
//        logger.info("FC - Unwind method type ALL_REL_PCT found");
//        long lTime=System.currentTimeMillis();
//        double dMaxPercentage=1;
//        double dTotalFees = 0;
//        double feeAccEqvt = 0;
//        double feePmtEqvt = 0;
//        boolean flag = false;
//        feeAccEqvt = (pdo.getDecimal(PDOConstantFieldsInterface.D_DBT_FEE_ACCT_BASEEQVT) != null ? pdo.getDecimal(PDOConstantFieldsInterface.D_DBT_FEE_ACCT_BASEEQVT).doubleValue() : 0)
//        			+	(pdo.getDecimal(PDOConstantFieldsInterface.D_CDT_FEE_ACCT_BASEEQVT) != null ? pdo.getDecimal(PDOConstantFieldsInterface.D_CDT_FEE_ACCT_BASEEQVT).doubleValue() : 0);
//        feePmtEqvt = (pdo.getDecimal(PDOConstantFieldsInterface.D_DBT_FEE_PMT_DEDUCT_BASEEQVT) != null ? pdo.getDecimal(PDOConstantFieldsInterface.D_DBT_FEE_PMT_DEDUCT_BASEEQVT).doubleValue() : 0)
//        			+ (pdo.getDecimal(PDOConstantFieldsInterface.D_CDT_FEE_PMT_DEDUCT_BASEEQVT) != null ? pdo.getDecimal(PDOConstantFieldsInterface.D_CDT_FEE_PMT_DEDUCT_BASEEQVT).doubleValue() : 0);
//            
//        
//        dTotalFees = feeAccEqvt + feePmtEqvt;
//        
//        if (basicFeeCalcData.getMaxFee()!=null &&(basicFeeCalcData.getMaxFee()<dTotalFees))
//        {
//            logger.info("FC - Total fee amount greater then max limit");
//            dMaxPercentage=basicFeeCalcData.getMaxFee()/dTotalFees;
//            
//        }
//
//        if (dMaxPercentage<1)
//        {
//            updatePercentageToAllMsgFeesAmounts(msgFeesList,dMaxPercentage,pdo);
//            flag = true;
//        }
//        logger.info("FC - Finished Unwind method type ALL_REL_PCT found - "+(System.currentTimeMillis()-lTime)+"ms"); 
//        
//        return flag;
//    }
//    
//    private void updatePercentageToAllMsgFeesAmounts(List<MsgFees> msgFeesList,double dMaxPercentage, PDO pdo)
//    {
//        String sBaseOfficeCurrency = pdo.getString(PDOConstantFieldsInterface.P_BASE_CCY);
//        int iSize=msgFeesList.size();
//        //BackendTracer GlobalTracer=GlobalTracer;
//        
//       
//        for (int i=0;i<iSize;i++)
//        {
//            MsgFees msgFee=msgFeesList.get(i);
//            logger.info(String.format("FC - Fee unwind number: {}",(i+1)));
//            if (msgFee.getDeductFrom() != null)
//            {
//                if (msgFee.getDeductFrom().equals(DeductFromType.A.name()))//account
//                {
//                    logger.info(String.format("FC - Fee amount {} {} reduced to {} {}"
/*@@__ SLF Migrator manual fix __@@@ remove closing parentheses in next line*/
//                            ,msgFee.getFeeAmount(),msgFee.getFeeCurrency(),(msgFee.getFeeAmount()*dMaxPercentage),msgFee.getFeeCurrency())));
//                    msgFee.setFeeAmount(adjustPrecision((msgFee.getFeeAmount()*dMaxPercentage)
//                            ,(msgFee.getFeeCurrency())));
//                    
//                    
//                    logger.info(String.format("FC - Fee base amount {} {} reduced to {} {}"
/*@@__ SLF Migrator manual fix __@@@ remove closing parentheses in next line*/
//                            ,msgFee.getFeeBaseAmount(),sBaseOfficeCurrency,(msgFee.getFeeBaseAmount()*dMaxPercentage),sBaseOfficeCurrency)));
//                    msgFee.setFeeBaseAmount(adjustPrecision((msgFee.getFeeBaseAmount()*dMaxPercentage)
//                            ,(sBaseOfficeCurrency)));
//                    if (msgFee.getFeePnlAccountCurrency()!=null && msgFee.getFeePnlAccountCurrency().length()>0)
//                    {
//                        logger.info(String.format("FC - Fee PnL amount {} {} reduced to {} {}"
/*@@__ SLF Migrator manual fix __@@@ remove closing parentheses in next line*/
//                                ,msgFee.getFeePnlAmount(),msgFee.getFeePnlAccountCurrency()
//                                ,(msgFee.getFeePnlAmount()*dMaxPercentage),msgFee.getFeePnlAccountCurrency())));
//                        msgFee.setFeePnlAmount(adjustPrecision(msgFee.getFeePnlAmount()*dMaxPercentage
//                                ,(msgFee.getFeePnlAccountCurrency())));
//                    }
//                    logger.info(String.format("FC - Fee account amount {} {} reduced to {} {}"
/*@@__ SLF Migrator manual fix __@@@ remove closing parentheses in next line*/
//                            ,msgFee.getFeeAccAmount(),msgFee.getFeeAccOrPmtCcy()
//                            ,(msgFee.getFeeAccAmount()*dMaxPercentage),msgFee.getFeeAccOrPmtCcy())));
//                    
//                    double feeAccAmt = adjustPrecision(msgFee.getFeeAccAmount()*dMaxPercentage
//                            ,(msgFee.getFeeAccOrPmtCcy()));
//                    
//                    msgFee.setFeeAccAmount(feeAccAmt);
//                    
////                    this fields should be updated only if it is not empty because of incoming agent fees 
//                    if (msgFee.getFeeAmountPreInAf() != null)
//                        msgFee.setFeeAmountPreInAf(feeAccAmt);
//                        
//                    msgFee.setUnwindFee(true);
//                }
//                else //Payment
//                {
//                    logger.info(String.format("FC - Fee amount {} {} reduced to {} {}"
/*@@__ SLF Migrator manual fix __@@@ remove closing parentheses in next line*/
//                            ,msgFee.getFeeAmount(),msgFee.getFeeCurrency()
//                            ,(msgFee.getFeeAmount()*dMaxPercentage),msgFee.getFeeCurrency())));
//                    msgFee.setFeeAmount(adjustPrecision((msgFee.getFeeAmount()*dMaxPercentage)
//                            ,(msgFee.getFeeCurrency())));
//                    logger.info(String.format("FC - Fee base amount {} {} reduced to {} {}"
/*@@__ SLF Migrator manual fix __@@@ remove closing parentheses in next line*/
//                            ,msgFee.getFeeBaseAmount(),sBaseOfficeCurrency,(msgFee.getFeeBaseAmount()*dMaxPercentage)
//                            ,sBaseOfficeCurrency)));
//                    msgFee.setFeeBaseAmount(adjustPrecision((msgFee.getFeeBaseAmount()*dMaxPercentage)
//                            ,(sBaseOfficeCurrency)));
//                    if (msgFee.getFeePnlAccountCurrency()!=null && msgFee.getFeePnlAccountCurrency().length()>0)
//                    {
//                        logger.info(String.format("FC - Fee PnL amount {} {} reduced to {} {}"
/*@@__ SLF Migrator manual fix __@@@ remove closing parentheses in next line*/
//                                ,msgFee.getFeePnlAmount(),msgFee.getFeePnlAccountCurrency()
//                                ,(msgFee.getFeePnlAmount()*dMaxPercentage),msgFee.getFeePnlAccountCurrency())));
//                        msgFee.setFeePnlAmount(adjustPrecision(msgFee.getFeePnlAmount()*dMaxPercentage
//                                ,(msgFee.getFeePnlAccountCurrency())));
//                    }
//                    if (msgFee.getFeeAccOrPmtCcy()!=null 
//                            && msgFee.getFeeAccOrPmtCcy().length()>0)
//                    {
//                        logger.info(String.format("FC - Fee amount in payment currency {} {} reduced to {} {}"
/*@@__ SLF Migrator manual fix __@@@ remove closing parentheses in next line*/
//                                ,msgFee.getFeeAmountInPmtCcy(),msgFee.getFeeAccOrPmtCcy()
//                                ,(msgFee.getFeeAmountInPmtCcy()*dMaxPercentage)
//                                ,msgFee.getFeeAccOrPmtCcy())));
//                        msgFee.setFeeAmountInPmtCcy(adjustPrecision(msgFee.getFeeAmountInPmtCcy()*dMaxPercentage
//                                ,(msgFee.getFeeAccOrPmtCcy())));
//                    }
//                    msgFee.setUnwindFee(true);
//                }
//            }
//        }
//        
//    }
//    
    
}
