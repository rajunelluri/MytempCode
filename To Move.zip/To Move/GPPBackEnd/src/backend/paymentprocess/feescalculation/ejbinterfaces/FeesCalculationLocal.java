package backend.paymentprocess.feescalculation.ejbinterfaces;

import javax.ejb.Local;

/**
 * Local interface for FeesCalculation.
 */
@Local
public interface FeesCalculationLocal extends FeesCalculation{} ; 