package backend.paymentprocess.feescalculation.ejbinterfaces;

import javax.ejb.Remote;
import com.fundtech.core.security.Admin;

/**
 * Remote interface for FeesCalculation.
 */
@Remote
public interface FeesCalculation{

	public static final String REMOTE_JNDI_NAME="ejb/FeesCalculationBean";
	
	
	/** 
	 * This method will be used when we require debit/credit fees calculation during the payment flow.
	 * @param feesCalculationType - indicates debit/credit/agent
	 * @param sMID - unique MID, (=Message ID) refers to the original ISO payment data as it was kept in our database
	 * @return FeesCalculationOutputData - output for the flow
	 */
	public backend.paymentprocess.feescalculation.output.FeesCalculationOutputData performFeesCalculation(final Admin admin, java.lang.String sMID ) throws backend.paymentprocess.feescalculation.exception.FeesCalculationException ;
	
	public backend.paymentprocess.feescalculation.output.FeesCalculationOutputData performFeesCalculation(final Admin admin, java.lang.String sMID ,boolean isDummyCalculation) throws backend.paymentprocess.feescalculation.exception.FeesCalculationException ;
	
	public backend.paymentprocess.feescalculation.output.FeesCalculationOutputData adjustMsgFees(final Admin admin, java.lang.String mid ) throws backend.paymentprocess.feescalculation.exception.FeesCalculationException ;
	
	public backend.paymentprocess.feescalculation.output.FeesCalculationOutputData perform71gUnwind(final Admin admin, java.lang.String mid ) throws backend.paymentprocess.feescalculation.exception.FeesCalculationException ;
	
	public com.fundtech.datacomponent.response.Feedback unwindIncomingAgentFeesByPercentage(final Admin admin, java.lang.String mid, java.lang.Double percentage ) ;
	
	public com.fundtech.datacomponent.response.Feedback setDerivedFeeAmountLogicalFields(final Admin admin ) ;

}//EOI  