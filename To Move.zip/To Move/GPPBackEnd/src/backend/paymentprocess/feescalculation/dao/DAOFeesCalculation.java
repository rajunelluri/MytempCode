/**
 * Mar 9, 2008
 * DAOFeesCalculation.java
 * @author Vadim Koremblum
 */

package backend.paymentprocess.feescalculation.dao;

import java.sql.Types;
import java.util.List;

import com.fundtech.cache.entities.Accounts;
import com.fundtech.cache.entities.Customrs;
import com.fundtech.cache.entities.MsgFees;
import com.fundtech.core.general.StatementParameter;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.util.GlobalUtils;

import backend.dataaccess.dao.DAOBasic;
import backend.paymentprocess.feescalculation.common.FeesCalculationType;

public class DAOFeesCalculation extends DAOBasic
{
//    private final String DELETE_FROM_MSG_FEES_QUERY="DELETE FROM MSG_FEES WHERE MSG_FEES.MID=? AND MSG_FEES.PAYING_PARTY=?";
    private final String SELECT_FROM_MSG_FEES_QUERY="SELECT * FROM MSG_FEES WHERE MSG_FEES.MID = ? AND MSG_FEES.MANUAL_FEE <> 0 " +
    		                                              "AND MSG_FEES.PAYING_PARTY = ? AND MSG_FEES.PARTITION_ID IN (0,1,?) ";
//    private final String DELETE_FROM_MSG_FEES_NOT_MANUAL_QUERY="DELETE FROM MSG_FEES WHERE MSG_FEES.MID=? AND MSG_FEES.PAYING_PARTY=? " +
//    		                                                          "AND MSG_FEES.MANUAL_FEE=0";
//    private final String SELECT_TIER_LINES="SELECT * FROM FEE_FORMULA_TIERS WHERE FEE_FORMULA_UID = ? ORDER BY FROM_AMOUNT";
//    private final String SELECT_FEE_FORMULA="SELECT * FROM FEE_FORMULA";
//    private final String SELECT_FEE_TYPES="SELECT * FROM FEE_TYPES";
    private final String SELECT_ACCOUNTS="SELECT * FROM ACCOUNTS WHERE TRIM(ACCOUNTS.OFFICE)=?";
    private final String UPDATE_SYST_PAR_TABLE="UPDATE SYST_PAR SET SYST_PAR.PARM_VALUE=? WHERE SYST_PAR.PARAM_NAME='FEEUNWINDMETHOD'";
//    private final String SELECT_RATE_USAGE="SELECT * FROM RATE_USAGE WHERE RATE_USAGE_NAME=?";
    private final String SELECT_CUSTOMERS="SELECT * FROM CUSTOMRS WHERE CUSTOMRS.UID_CUSTOMRS=?";
    
    
//    public Feedback deleteFromMSG_FEES(String sMID, FeesCalculationType feesCalculationType)
//    {
//        StatementParameter[] arrParameters = new StatementParameter[2];
//        arrParameters[0] = new StatementParameter(sMID, java.sql.Types.VARCHAR);
//        arrParameters[1] = new StatementParameter(feesCalculationType.equals(FeesCalculationType.CREDIT)?"CR":"DB", java.sql.Types.VARCHAR);
//        
//        return super.doDelete(DELETE_FROM_MSG_FEES_QUERY,arrParameters,null,null);
//    }
    
//    public Feedback deleteFromMSG_FEEnotManual(String sMID, FeesCalculationType feesCalculationType)
//    {
//        StatementParameter[] arrParameters = new StatementParameter[2];
//        arrParameters[0] = new StatementParameter(sMID, java.sql.Types.VARCHAR);
//        arrParameters[1] = new StatementParameter(feesCalculationType.equals(FeesCalculationType.CREDIT)?"CR":"DB", java.sql.Types.VARCHAR);
//        
//        return super.doDelete(DELETE_FROM_MSG_FEES_NOT_MANUAL_QUERY,arrParameters,null,null);
//    }
    
    public List<MsgFees> getFromMSG_FEESTable(String sMID, FeesCalculationType feesCalculationType)
    {
        
    	int iPartitionID = GlobalUtils.getPartitionIDByMID(sMID);
        List<MsgFees> list=getDataRows(SELECT_FROM_MSG_FEES_QUERY,MsgFees.class ,0,new StatementParameter(sMID,Types.CHAR)
                                        ,new StatementParameter(getPayingParty(feesCalculationType),Types.CHAR), new StatementParameter(iPartitionID,Types.INTEGER));
        return list; 
    }

//    public List<RateUsage> getFromRATE_USAGE(String sRateUsageName)
//    {
//        
//        List<RateUsage> list=getDataRows(SELECT_RATE_USAGE,RateUsage.class ,0,new StatementParameter(sRateUsageName,Types.VARCHAR));
//        return list;
//    }
    
//    public List<FeeTypes> getFromFEE_TYPESList()
//    {
//        
//        List<FeeTypes> list=getDataRows(SELECT_FEE_TYPES,FeeTypes.class ,0,null);
//        return list;
//    }

//    public List<FeeFormula> getFeeFormula()
//    {
//        List<FeeFormula> list=getDataRows(SELECT_FEE_FORMULA,FeeFormula.class ,0,null);
//        return list;
//    }

    
    public Customrs getCustomer(String sUID)
    {
        Customrs customer=null;
        List<Customrs> list=getDataRows(SELECT_CUSTOMERS,Customrs.class ,0,new StatementParameter(sUID,Types.VARCHAR));
        if (list.size()>0)
        {
            customer=list.get(0);
        }
        return customer;
    }
    
    private String getPayingParty(FeesCalculationType feesCalculationType)
    {
        String sPayingParty;
        if (feesCalculationType.equals(FeesCalculationType.CREDIT))
        {
            sPayingParty="CR";
        }
        else if (feesCalculationType.equals(FeesCalculationType.DEBIT))
        {
            sPayingParty="DR";
        }
        else
        {
            sPayingParty="AF";
        }
        return sPayingParty;
    }
//    public List<FeeFormulaTiers> getTierLines(String sFeeFormulaUID)
//    {
//        List<FeeFormulaTiers> list=getDataRows(SELECT_TIER_LINES,FeeFormulaTiers.class ,0,new StatementParameter(sFeeFormulaUID,Types.VARCHAR));
//        return list;
//    }

    public List<Accounts> getFromAccounts(String sOffice)
    {
        
        List<Accounts> list=getDataRows(SELECT_ACCOUNTS,Accounts.class ,0,new StatementParameter(sOffice,Types.CHAR));
        return list;
    }
    
    public Feedback updateSYST_PAR(String sValue)
    {
        StatementParameter[] arrParameters = new StatementParameter[1];
        arrParameters[0] = new StatementParameter(sValue, java.sql.Types.VARCHAR);
        
        return doUpdate(UPDATE_SYST_PAR_TABLE,arrParameters,null,null);
    }
    

}
