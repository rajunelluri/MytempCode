/**
 * Mar 10, 2008
 * FeesCalculationOutputData.java
 * @author Vadim Koremblum
 */
package backend.paymentprocess.feescalculation.output;

import com.fundtech.datacomponent.response.GlobalAbstractResponseDataComponent;

/**
 * 
 */
public class FeesCalculationOutputData extends GlobalAbstractResponseDataComponent
{
    /**
     * 
     */
    private static final long serialVersionUID = 816218246602236043L;
//    private double m_dAccountFeeAmount;
//    private double m_dAccountFeeEquivalentAmount;
//    private String m_sAccountFeeCurrency;
//    private double m_dPaymentFeeAmount;
//    private double m_dPaymentFeeEquivalentAmount;
//    private String m_sPaymentCurrency;
    private String m_sFeeAccountNum;
    private String m_sFeeAccountOffice;
    private String m_sFeeAccountCurrency;
    private boolean m_feeAccountExist; 
    private boolean m_feeAccountNotFoundFailure;
    
    public FeesCalculationOutputData()
    {
    }
    
    public String getFeeAccountNum()
    {
        return m_sFeeAccountNum;
    }
    public String getFeeAccountOffice()
    {
        return m_sFeeAccountOffice;
    }
    public String getFeeAccountCurrency()
    {
        return m_sFeeAccountCurrency;
    }
    public void setFeeAccountNum(String feeAccountNum)
    {
        m_sFeeAccountNum = feeAccountNum;
    }
    public void setFeeAccountOffice(String feeAccountOffice)
    {
        m_sFeeAccountOffice = feeAccountOffice;
    }
    public void setFeeAccountCurrency(String feeAccountCurrency)
    {
        m_sFeeAccountCurrency = feeAccountCurrency;
    }    
    
    public void setFeeAccountExist(boolean flag)
    {
        m_feeAccountExist = flag;
    }
    
    public boolean isFeeAccountExist()
    {
        return m_feeAccountExist;
    }

    public void setFeeAccountNotFoundFailure(boolean flag)
    {
        m_feeAccountNotFoundFailure = flag;
    }
    
    public boolean isFeeAccountNotFoundFailure()
    {
        return m_feeAccountNotFoundFailure;
    }
    
    
    public void reset()
    {
        this.m_feeAccountExist = false;
        this.m_sFeeAccountCurrency=null;
        this.m_sFeeAccountNum=null;
        this.m_sFeeAccountOffice=null;
    }
    
//    public double getAccountFeeAmount()
//    {
//        return m_dAccountFeeAmount;
//    }
//    public double getAccountFeeEquivalentAmount()
//    {
//        return m_dAccountFeeEquivalentAmount;
//    }
//    public double getPaymentFeeAmount()
//    {
//        return m_dPaymentFeeAmount;
//    }
//    public double getPaymentFeeEquivalentAmount()
//    {
//        return m_dPaymentFeeEquivalentAmount;
//    }
//    public void setAccountFeeAmount(double debitFeeAmount)
//    {
//        m_dAccountFeeAmount = debitFeeAmount;
//    }
//    public void setAccountFeeEquivalentAmount(double debitFeeEquivalentAmount)
//    {
//        m_dAccountFeeEquivalentAmount = debitFeeEquivalentAmount;
//    }
//    public void setPaymentFeeAmount(double creditFeeAmount)
//    {
//        m_dPaymentFeeAmount = creditFeeAmount;
//    }
//    public void setPaymentFeeEquivalentAmount(double creditFeeEquivalentAmount)
//    {
//        m_dPaymentFeeEquivalentAmount = creditFeeEquivalentAmount;
//    }

//    public String getAccountFeeCurrency()
//    {
//        return m_sAccountFeeCurrency;
//    }
//    public String getPaymentCurrency()
//    {
//        return m_sPaymentCurrency;
//    }
//    public void setAccountFeeCurrency(String accountFeeCurrency)
//    {
//        m_sAccountFeeCurrency = accountFeeCurrency;
//    }
//    public void setPaymentCurrency(String paymentCurrency)
//    {
//        m_sPaymentCurrency = paymentCurrency;
//    }
//
    
//    public String toString()
//    {
//        StringBuffer str=new StringBuffer(); 
//        str.append("Account Fee Amount=").append(getAccountFeeAmount()).append(ServerConstants.NEWLINE)
//                   .append("Account Fee Currency=").append(getAccountFeeCurrency()).append(ServerConstants.NEWLINE)
//                   .append("Account Fee Equivalent Amount=").append(getAccountFeeEquivalentAmount()).append(ServerConstants.NEWLINE)
//                   .append("Payment Fee Amount=").append(getPaymentFeeAmount()).append(ServerConstants.NEWLINE)
//                   .append("Payment Account Currency=").append(getPaymentCurrency()).append(ServerConstants.NEWLINE)
//                   .append("Payment Fee Equivalent Amount=").append(getPaymentFeeEquivalentAmount()).append(ServerConstants.NEWLINE)
//                   .append("Fee Account Num: ").append(getFeeAccountNum()).append(ServerConstants.NEWLINE)
//                   .append("Fee Account Office: ").append(getFeeAccountOffice()).append(ServerConstants.NEWLINE)
//                   .append("Fee Account Currency: ").append(getFeeAccountCurrency()).append(ServerConstants.NEWLINE);
////                   .append("Errors: ").append(getProcessErrorHolder().toString()).append(ServerConstants.NEWLINE);
//                   
//        return str.toString();
//    }
//
}
