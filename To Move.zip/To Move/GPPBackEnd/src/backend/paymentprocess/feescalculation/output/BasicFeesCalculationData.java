/**
 * Mar 9, 2008
 * BasicFeesCalculationData.java
 * @author Vadim Koremblum
 */
package backend.paymentprocess.feescalculation.output;

import com.fundtech.cache.entities.Accounts;
import com.fundtech.cache.entities.Customrs;

import backend.paymentprocess.feescalculation.common.ChargeBearer;
import backend.paymentprocess.feescalculation.common.UnwindMethodType;

public class BasicFeesCalculationData
{
    private ChargeBearer m_chargeBearer;
    private UnwindMethodType m_unwindMethodType;
    private boolean m_bSkipFeeCalculation;
    private Float m_fFloorAmnt;
    private Float m_fMaxFee;
    private Accounts m_feeAccount;
    private Customrs m_customer;
    /**
     * @return the m_chargeBearer
     */
    public ChargeBearer getChargeBearer()
    {
      return m_chargeBearer;
    }
    /**
     * @return the m_bSkipFeeCalculation
     */
    public boolean getSkipFeeCalculation()
    {
      return m_bSkipFeeCalculation;
    }
    /**
     * @return the m_fMinFee
     */
    public Float getFloorAmnt()
    {
      return m_fFloorAmnt;
    }
    /**
     * @return the m_fMaxFee
     */
    public Float getMaxFee()
    {
      return m_fMaxFee;
    }
    /**
     * @param bearer the m_chargeBearer to set
     */
    public void setChargeBearer(ChargeBearer bearer)
    {
        m_chargeBearer = bearer;
    }
    /**
     * @param skipFeeCalculation the m_bSkipFeeCalculation to set
     */
    public void setSkipFeeCalculation(boolean skipFeeCalculation)
    {
        m_bSkipFeeCalculation = skipFeeCalculation;
    }
    /**
     * @param minFee the m_fMinFee to set
     */
    public void setFloorAmnt(Float minFee)
    {
        m_fFloorAmnt = minFee;
    }
    /**
     * @param maxFee the m_fMaxFee to set
     */
    public void setMaxFee(Float maxFee)
    {
      m_fMaxFee = maxFee;
    }
    /**
     * @return the m_unwindMethodType
     */
    public UnwindMethodType getUnwindMethodType()
    {
        return m_unwindMethodType;
    }
    /**
     * @param methodType the m_unwindMethodType to set
     */
    public void setUnwindMethodType(UnwindMethodType methodType)
    {
        m_unwindMethodType = methodType;
    }
    public Accounts getFeeAccount()
    {
        return m_feeAccount;
    }
    public void setFeeAccount(Accounts acount)
    {
        m_feeAccount = acount;
    }

    public Customrs getCustomer()
    {
        return m_customer;
    }

    public void setCustomer(Customrs cust)
    {
        m_customer = cust;
    }
    
}
