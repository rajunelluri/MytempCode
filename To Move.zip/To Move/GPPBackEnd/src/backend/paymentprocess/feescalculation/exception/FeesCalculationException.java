/**
 * Mar 18, 2008
 * FeesCalculationException.java
 * @author Vadim Koremblum
 */
package backend.paymentprocess.feescalculation.exception;

import com.fundtech.core.paymentprocess.errorhandling.BusinessException;

/**
 * 
 */
public class FeesCalculationException extends BusinessException
{
    public FeesCalculationException(int iErrorCode)
    {
        super(iErrorCode);
    }

    public FeesCalculationException(String string, Throwable e)
    {
        super(string, e);
    }

    public FeesCalculationException()
    {
        super();
    }


    public FeesCalculationException(String sErrorDescription)
    {
        super(sErrorDescription);
    }
}
