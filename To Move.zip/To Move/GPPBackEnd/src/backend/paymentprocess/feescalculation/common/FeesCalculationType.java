/**
 * Mar 9, 2008
 * FeesCalculationType.java
 * @author Vadim Koremblum
 */

package backend.paymentprocess.feescalculation.common;

public enum FeesCalculationType
{
    DEBIT,CREDIT,AGENT,CR,DR,AF;
}
