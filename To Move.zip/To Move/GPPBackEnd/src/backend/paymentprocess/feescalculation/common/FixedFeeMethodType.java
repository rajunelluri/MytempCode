/**
 * Mar 11, 2008
 * FixedFeeMethodType.java
 * @author Vadim Koremblum
 */
package backend.paymentprocess.feescalculation.common;

/**
 * 
 */
public enum FixedFeeMethodType 
{
    A,M;    
}
