/**
 * Mar 11, 2008
 * TierType.java
 * @author Vadim Koremblum
 */
package backend.paymentprocess.feescalculation.common;

/**
 * 
 */
public enum TierType 
{
    VOLUREM,FIXED;
}
