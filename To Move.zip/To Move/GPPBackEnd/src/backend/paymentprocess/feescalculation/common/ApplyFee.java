/**
 * Mar 9, 2008
 * ApplyFee.java
 * @author Vadim Koremblum
 */
package backend.paymentprocess.feescalculation.common;

/**
 * 
 */
public enum ApplyFee 
{
    LATER,NOW,WAIVE,REQUEST,PAID;

}
