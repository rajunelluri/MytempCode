/**
 * Mar 11, 2008
 * DeductFromType.java
 * @author Vadim Koremblum
 */
package backend.paymentprocess.feescalculation.common;

/**
 * 
 */
public enum DeductFromType 
{
    A,P;
}
