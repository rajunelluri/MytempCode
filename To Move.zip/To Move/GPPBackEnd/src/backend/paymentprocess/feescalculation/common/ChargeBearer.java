/**
 * Mar 9, 2008
 * ChargeBearer.java
 * @author Vadim Koremblum
 */

package backend.paymentprocess.feescalculation.common;

public enum ChargeBearer 
{
  CRED,DEBT,SHAR,OUR, SLEV;
}
