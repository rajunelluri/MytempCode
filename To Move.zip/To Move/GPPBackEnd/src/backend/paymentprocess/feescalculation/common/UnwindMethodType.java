/**
 * Mar 10, 2008
 * UnwindMethodType.java
 * @author Vadim Koremblum
 */
package backend.paymentprocess.feescalculation.common;

/**
 * 
 */
public enum UnwindMethodType 
{
    FIRST_AMT,FIRST_REL_AMT,ALL_REL_PCT;
}
