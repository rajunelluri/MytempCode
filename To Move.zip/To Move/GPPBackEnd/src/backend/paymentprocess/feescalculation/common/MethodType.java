/**
 * Mar 11, 2008
 * MethodType.java
 * @author Vadim Koremblum
 */
package backend.paymentprocess.feescalculation.common;

/**
 * 
 */
public enum MethodType 
{
    Regular,Tiered;
}
