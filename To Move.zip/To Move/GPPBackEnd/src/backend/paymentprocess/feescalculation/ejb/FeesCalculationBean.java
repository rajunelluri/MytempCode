package backend.paymentprocess.feescalculation.ejb;

import javax.ejb.Stateless;
import backend.core.SuperSLSB;
import com.fundtech.core.security.Admin;
import backend.businessobject.proxies.interceptors.InterceptorSetType;
import backend.paymentprocess.feescalculation.businessobjects.BOFeesCalculation;
import backend.paymentprocess.feescalculation.ejbinterfaces.FeesCalculationLocal;
import backend.paymentprocess.feescalculation.ejbinterfaces.FeesCalculation;

@Stateless
public class FeesCalculationBean extends SuperSLSB<FeesCalculation> implements FeesCalculationLocal, FeesCalculation{
	
	public FeesCalculationBean() { super(backend.paymentprocess.feescalculation.businessobjects.BOFeesCalculation.class, InterceptorSetType.Complete) ; }//EOM
	
	
	/** 
	 * This method will be used when we require debit/credit fees calculation during the payment flow.
	 * @param feesCalculationType - indicates debit/credit/agent
	 * @param sMID - unique MID, (=Message ID) refers to the original ISO payment data as it was kept in our database
	 * @return FeesCalculationOutputData - output for the flow
	 */
	public backend.paymentprocess.feescalculation.output.FeesCalculationOutputData performFeesCalculation(final Admin admin, java.lang.String sMID ) throws backend.paymentprocess.feescalculation.exception.FeesCalculationException {
		return this.m_bo.performFeesCalculation(admin, sMID ) ;
	}//EOM

	public backend.paymentprocess.feescalculation.output.FeesCalculationOutputData performFeesCalculation(final Admin admin, java.lang.String sMID ,boolean isDummyCalculation) throws backend.paymentprocess.feescalculation.exception.FeesCalculationException {
		return this.m_bo.performFeesCalculation(admin, sMID ,isDummyCalculation) ;
	}
	
	public backend.paymentprocess.feescalculation.output.FeesCalculationOutputData adjustMsgFees(final Admin admin, java.lang.String mid ) throws backend.paymentprocess.feescalculation.exception.FeesCalculationException {
		return this.m_bo.adjustMsgFees(admin, mid ) ;
	}//EOM

	public backend.paymentprocess.feescalculation.output.FeesCalculationOutputData perform71gUnwind(final Admin admin, java.lang.String mid ) throws backend.paymentprocess.feescalculation.exception.FeesCalculationException {
		return this.m_bo.perform71gUnwind(admin, mid ) ;
	}//EOM

	public com.fundtech.datacomponent.response.Feedback unwindIncomingAgentFeesByPercentage(final Admin admin, java.lang.String mid, java.lang.Double percentage ) {
		return this.m_bo.unwindIncomingAgentFeesByPercentage(admin, mid, percentage ) ;
	}//EOM

	public com.fundtech.datacomponent.response.Feedback setDerivedFeeAmountLogicalFields(final Admin admin ) {
		return this.m_bo.setDerivedFeeAmountLogicalFields(admin ) ;
	}//EOM

}//EOC