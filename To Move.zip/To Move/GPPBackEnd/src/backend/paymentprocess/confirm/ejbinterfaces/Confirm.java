package backend.paymentprocess.confirm.ejbinterfaces;

import javax.ejb.Remote;
import com.fundtech.core.security.Admin;

/**
 * Remote interface for Confirm.
 */
@Remote
public interface Confirm{

	public static final String REMOTE_JNDI_NAME="ejb/ConfirmBean";
	
	
	/** 
	 * Handles 'Confirm' action for a request that was performed for the passed MID.
	 */
	public com.fundtech.datacomponent.response.Feedback handleConfirm(final Admin admin, java.lang.String sMID ) throws java.lang.Throwable ;

}//EOI  