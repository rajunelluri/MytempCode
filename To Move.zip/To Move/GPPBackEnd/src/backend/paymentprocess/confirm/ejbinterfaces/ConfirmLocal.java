package backend.paymentprocess.confirm.ejbinterfaces;

import javax.ejb.Local;

/**
 * Local interface for Confirm.
 */
@Local
public interface ConfirmLocal extends Confirm{} ; 