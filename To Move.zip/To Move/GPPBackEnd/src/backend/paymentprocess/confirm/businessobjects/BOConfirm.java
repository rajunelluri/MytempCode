package backend.paymentprocess.confirm.businessobjects;

import static com.fundtech.util.GlobalUtils.isNullOrEmpty;


import com.fundtech.annotations.Expose;
import com.fundtech.annotations.Wrap;
import com.fundtech.cache.entities.InterfaceTypes;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.core.paymentprocess.errorhandling.ProcessError;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.datacomponent.response.SimpleResponseDataComponent;
import com.fundtech.errors.ProcessErrorConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import backend.businessobject.BOBasic;
import backend.businessobject.BOProxies;
import backend.core.module.MessageConstantsInterface;
import backend.paymentprocess.SubBatchProcessInterface;
import backend.paymentprocess.erroraudit.ErrorAuditUtils;
import backend.paymentprocess.highvalueprocess.businessobjects.BOHighValueProcess;
import backend.paymentprocess.loadpostinginfo.common.PostingRequestType;
import backend.util.ServerUtils;


/**
 * Title:       BOConfirm
 * Description: Business object for confirmation process of a message
 * Company:     Fundtech Israel
 * Author:      Galit Zilberman
 * Date:        12/12/2011
 * @version     1.0
 */
@Wrap(tx="Bean")

public class BOConfirm extends BOBasic implements SubBatchProcessInterface, PDOConstantFieldsInterface, MessageConstantsInterface
{

	private static final Logger logger = LoggerFactory.getLogger(BOConfirm.class);
	private static final String STEP_FIELDS_CLEANING = "Cleaning index fields and related monitor fields";

	/**
	 * Handles 'Confirm' action for a request that was performed for the passed MID.
	 */
	@Expose
	public Feedback handleConfirm(String sMID) throws Throwable
	{
		final String TRACE_METHOD_INPUT = "BOConfirm.handleConfirm - MID: {}, Action ID: {}, P_MSG_STS: {}.";
		
		
		Feedback feedback = new Feedback();
		Admin admin = (Admin) Admin.getContextAdmin();
		PDO pdo = PaymentDataFactory.load(sMID);
		
		
		String sActionID = pdo.getString(D_BUTTON_ID);
		
		String msgSts = pdo.getString(P_MSG_STS);
		
		logger.info(TRACE_METHOD_INPUT,  new Object[]{ sMID, sActionID, msgSts});
		
		// Fields cleaning.
		logger.info("Cleaning index fields and related monitor fields");
		//PISN
		pdo.set(P_PISN_INDEX, (String)null);
		pdo.set(MF_PISN_MATCH_STS, MONITOR_FLAG_NONE);
		//OPI_OSN
		pdo.set(MF_OPIOSN_MATCH_STS, MONITOR_FLAG_NONE);
		//SC
		pdo.set(P_SC_INDEX, (String)null);
		pdo.set(MF_SC_MATCH_STS, MONITOR_FLAG_NONE);
		//AF
		pdo.set(P_AF_INDEX, (String)null);
		pdo.set(MF_AF_MATCH_STS, MONITOR_FLAG_NONE);
		//LC
		pdo.set(P_LC_INDEX, (String)null);
		pdo.set(MF_LC_MATCH_STS, MONITOR_FLAG_NONE);
	
		String gracefulTerminationStatus = MESSAGE_STATUS_CONFIRMED;
		logger.info("Call TerminationFlow on message with MID={} and terminationStatus={}",pdo.getMID(),gracefulTerminationStatus);
		BOHighValueProcess.performTerminationSubFlow(pdo, gracefulTerminationStatus);

		return feedback;
	}
}
