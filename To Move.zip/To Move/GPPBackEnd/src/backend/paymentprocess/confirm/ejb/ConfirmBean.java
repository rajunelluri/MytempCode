package backend.paymentprocess.confirm.ejb;

import javax.ejb.Stateless;
import backend.core.SuperSLSB;
import com.fundtech.core.security.Admin;
import backend.businessobject.proxies.interceptors.InterceptorSetType;
import backend.paymentprocess.confirm.ejbinterfaces.ConfirmLocal;
import backend.paymentprocess.confirm.ejbinterfaces.Confirm;

@Stateless
public class ConfirmBean extends SuperSLSB<Confirm> implements ConfirmLocal, Confirm{
	
	public ConfirmBean() { super(backend.paymentprocess.confirm.businessobjects.BOConfirm.class, InterceptorSetType.Complete) ; }//EOM
	
	
	/** 
	 * Handles 'Confirm' action for a request that was performed for the passed MID.
	 */
	public com.fundtech.datacomponent.response.Feedback handleConfirm(final Admin admin, java.lang.String sMID ) throws java.lang.Throwable {
		return this.m_bo.handleConfirm(admin, sMID ) ;
	}//EOM

}//EOC