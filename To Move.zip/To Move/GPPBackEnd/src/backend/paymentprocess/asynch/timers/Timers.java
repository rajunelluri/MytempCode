package backend.paymentprocess.asynch.timers;

import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;

public interface Timers {
	
	Feedback onCloseOpenNewOutFilesTimeOut(Admin admin) ;
	Feedback onDebulkPreProcessingTimeOut(Admin admin) ;
	Feedback onIncomingFileCancellationTimeOut(Admin admin) ;
	Feedback onRetryNSFTimeOut(Admin admin) ;
	Feedback onSendOutFileTimer(Admin admin) ;
	Feedback onSubBatchCancellationTimeOut(Admin admin) ;
	Feedback onSubBatchCompletionTimeOut(Admin admin) ;
	Feedback onSubBatchGenerationTimeOut(Admin admin) ;
	Feedback onQueueExplorerTimeOut(Admin admin) ;
	Feedback performPutTest(Admin admin) ;
	Feedback onFileApprovalTimeOut(Admin admin) ;
	Feedback onFileCancellationTimeOut(Admin admin) ;
	
}//EOI 
