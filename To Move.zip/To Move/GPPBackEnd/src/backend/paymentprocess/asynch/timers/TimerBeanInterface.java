package backend.paymentprocess.asynch.timers;

import javax.ejb.Remote;

import com.fundtech.core.security.Admin;

@Remote
public interface TimerBeanInterface {

	void initTimer(Admin admin, final String sServiceName) ;  
	void cancelTimer(Admin admin) ; 
}//EOC 
