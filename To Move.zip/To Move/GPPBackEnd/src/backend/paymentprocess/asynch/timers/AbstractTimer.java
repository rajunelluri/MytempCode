package backend.paymentprocess.asynch.timers;



import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

import javax.annotation.Resource;
import javax.ejb.SessionContext;
import javax.ejb.Timeout;
import javax.ejb.Timer;
import javax.transaction.Status;
import javax.transaction.UserTransaction;

import backend.businessobject.BOInterface;
import backend.businessobject.proxies.BOProxy;
import backend.paymentprocess.SubBatchProcessInterface;
import backend.paymentprocess.erroraudit.ErrorAuditUtils;

import com.fundtech.cache.entities.SystPar;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.paymentprocess.errorhandling.ProcessError;
import com.fundtech.core.security.Admin;
import com.fundtech.core.security.Admin.CallSource;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.errors.ProcessErrorConstants;
import com.fundtech.util.ExceptionController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class AbstractTimer<T> { 

	private static final Logger logger = LoggerFactory.getLogger(AbstractTimer.class);

	static final long serialVersionUID = 3206093459760846163L;
	
	private static final int FAILURE_THRESHOLD = 5 ; 
	private static AtomicBoolean bSystemInitialised = new AtomicBoolean(false) ; 
	
	@Resource
	protected SessionContext context ; 
		
	private T m_bo ;
	private Timers m_boTimer ; 
	protected Class<T> m_boInterfaceType ; 
	protected Class<?> m_boClassType ; 
	private String m_sMethodName  ; 
	private Method m_timeoutMethod ; 
	private Admin m_admin ;
	private int m_iNumberOfFailures ;
	
	private static final Map<String, Boolean> m_mapDisposedServices = new ConcurrentHashMap<String, Boolean>() ;  
	
    public static final void setSystemInitialised(final boolean bSystemInitialized) { bSystemInitialised.set(bSystemInitialized) ; }//EOM 
	
	public AbstractTimer(final Class<?> boClassType, final Class<T> boInterfaceType, final String sMethodName) {
  
	  this.m_boClassType = boClassType ;
      this.m_sMethodName = sMethodName ; 
      this.m_boInterfaceType = boInterfaceType ;
       
      if(bSystemInitialised.get()) { 
          this.m_bo = BOProxy.completeDecoration(boClassType, boInterfaceType) ;
          this.initTimerResources() ; 
      }//EO if the system was not yet initialized
           
      this.m_admin = new Admin(boClassType.getSimpleName()+"_"+Thread.currentThread().getId(), CallSource.System) ; 
      this.m_iNumberOfFailures = 0 ; 
	}//EOM 
		
	private final void initTimerResources() { 
		try{ 
			//initialise the bo timers first 
			//this.m_boTimer = BOProxy.completeDecoration(BOTimers.class, Timers.class) ; 
			this.m_timeoutMethod = m_boTimer.getClass().getDeclaredMethod(this.m_sMethodName, Admin.class) ; 
		}catch(Throwable t) { 
			ExceptionController.getInstance().handleException(t, this) ; 
		}//EO catch block 
	}//EOM 
	
	protected final T getBOInstance(){ 
	    if(this.m_bo == null) this.m_bo = BOProxy.completeDecoration(this.m_boClassType, this.m_boInterfaceType) ; 
	    return this.m_bo ; 
	}//EOM 
	
	public javax.ejb.SessionContext getSessionContext() { return this.context; }//EOM 
	
	public void setSessionContext(javax.ejb.SessionContext ctx) { context = ctx; }//EOM 
	
	public void ejbCreate() throws javax.ejb.CreateException {}//EOM 
	
	public void ejbActivate() { ((BOInterface)this.m_bo).businessObjectActivate() ; }//EOM 
	
	public void ejbPassivate() { ((BOInterface)this.m_bo).businessObjectPassivate()  ; }//EOM 

	public void ejbRemove() { ((BOInterface)this.m_bo).businessObjectRemove() ; }//EOM 
	
	public void initTimer(Admin admin, final String sServiceName) { 
		final SystPar timerIntervalSys = CacheKeys.SystParKey.getSingle(sServiceName) ; 
		final String sInterval = timerIntervalSys.getParmValue() ; 
		long lInterval = 0 ; 
		try{ 
			lInterval = Long.valueOf(sInterval) ; 
		}catch(Exception e) { 
			ExceptionController.getInstance().handleException(e, this) ;
			lInterval = 30000 ; 
		}//EO catch blcok 
		this.context.getTimerService().createTimer(1000, lInterval , sServiceName) ;
	}//EOM 
	
	public void cancelTimer(Admin admin) 
	{ 
	    m_mapDisposedServices.put(this.getClass().getName(), true) ; 
	}//EOM  
	public final boolean isDisposed() {  return m_mapDisposedServices.get(this.getClass().getName()) != null ; }//EOM 
		
	@Timeout
	public void ejbTimeout(Timer timerHandle) {
		
		try{  
//		    System.out.println(this);
			//if the m_bDispose is set to true, dispose of the timer and abort
			if(this.isDisposed() || !bSystemInitialised.get()) {
				if(bSystemInitialised.get()) timerHandle.cancel() ;
				return ; 
			}//EO if the dispose flag was set to true 
			if(this.m_timeoutMethod == null) this.initTimerResources() ; 
			
			this.m_admin.setSessionId(this.m_boInterfaceType.getSimpleName() + '_' + Thread.currentThread().getId()) ;
			
			final Feedback feedback = (Feedback) this.m_timeoutMethod.invoke(this.m_boTimer, this.m_admin) ;
			
			//if the feedback indicates a failure and the error code != SubBatchProcessInterface.INT_RETURN_CODE_NO_WORK_TO_PERFORM
			//increment the number of failure and if the number had breached the FAILURE_THRESHOLD cancel the timer with an error message 
			if(!feedback.isSuccessful() && feedback.getErrorCode() != SubBatchProcessInterface.INT_RETURN_CODE_NO_WORK_TO_PERFORM) { 
				this.handleError(timerHandle) ; 
			}//EO if there was a failure
		}catch(Throwable t) { 
			ExceptionController.getInstance().handleException(t, this) ;
			
			//invoke the handle error
			this.handleError(timerHandle) ; 
		}finally{ 
		    
			Admin.removeContextAdmin() ; 
		}//EO catch block 
	}//EOM 
	
	private final void handleError(final Timer timerHandle) { 
//		if(this.m_iNumberOfFailures++ > FAILURE_THRESHOLD) {
	
		/*
  	    if(false) {
 
			
			final ProcessError pError = 
				ProcessError.getError(ProcessErrorConstants.TimerCancelled, 
						new String[]{ this.m_boInterfaceType.getSimpleName(), "" +this.m_iNumberOfFailures }, 
					null);
			
              logger.error(pError.getDescription());
              
              // persist the error
              ErrorAuditUtils.setErrors(pError);
			
              this.cancelTimer(null) ; 
              
              //if a user transaction was left opened, roll it back 
              
             // timerHandle.cancel() ; 
		}//EO if the number of failures had breached the acceptable threshold
  	    */
          try{
              final UserTransaction tx = this.context.getUserTransaction() ; 
              if(this.context.getUserTransaction().getStatus() == Status.STATUS_ACTIVE) tx.rollback() ; 
          }catch(Throwable t) { 
              ExceptionController.getInstance().handleException(t, this) ; 
          }//EO catch block 
		
	}//EOM 
	

}//EOC 
