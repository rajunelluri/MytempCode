package backend.paymentprocess.businessflowselector.dao;

import backend.dataaccess.dao.DAOBasic;
import backend.dataaccess.dto.DTODataHolder;

/**
 * Title:       DAOBusinessFlowSelector
 * Description: DAO object business flow selector
 * Company:     Fundtech Israel
 * Author:      Asaf Levy
 * Date:        09/07/2009
 * @version     1.0
 */
public class DAOBusinessFlowSelector extends DAOBasic
{
  private static DAOBusinessFlowSelector m_daoBusinessFlowSelector = new DAOBusinessFlowSelector();

  /**
   * Private constructor.
   */
  private DAOBusinessFlowSelector()
  {
  }

  public static DAOBusinessFlowSelector getInstance()
  {
  	return m_daoBusinessFlowSelector;
  }
  
  /**
   * 
   */
  public DTODataHolder getBUSINESS_FLOW_DEFINITION_Table()
  {
    final String SELECT_STATEMENT = "SELECT * FROM BUSINESS_FLOW_DEFINITION";

    return getData(SELECT_STATEMENT, 0);
  }
}