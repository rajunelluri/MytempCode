package backend.paymentprocess.businessflowselector.ejbinterfaces;

import javax.ejb.Local;

/**
 * Local interface for BusinessFlowSelector.
 */
@Local
public interface BusinessFlowSelectorLocal extends BusinessFlowSelector{} ; 