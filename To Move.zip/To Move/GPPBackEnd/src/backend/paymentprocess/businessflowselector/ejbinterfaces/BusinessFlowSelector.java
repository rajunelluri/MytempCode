package backend.paymentprocess.businessflowselector.ejbinterfaces;

import javax.ejb.Remote;
import com.fundtech.core.security.Admin;

/**
 * Remote interface for BusinessFlowSelector.
 */
@Remote
public interface BusinessFlowSelector{

	public static final String REMOTE_JNDI_NAME="ejb/BusinessFlowSelectorBean";
	
	
	public com.fundtech.datacomponent.response.Feedback executeBusinessFlow(final Admin admin, java.lang.String sMessage, java.lang.String sInMsgContext, java.lang.String sOffice ) throws java.lang.Exception ;
	
	/** 
	 * Executes a business flow according to the result returned from execution of rule type
	 * 158 - Business flow selection - for the passed MID.
	 */
	public com.fundtech.datacomponent.response.Feedback executeFlow(final Admin admin, java.lang.String sMID, java.lang.Boolean bSavePDO, java.lang.Object[] arrAdditionalInput ) ;
	
	public com.fundtech.datacomponent.response.Feedback executeBPELBusinessFlowSelector(final Admin admin, java.lang.String sMessage, java.lang.String sInMsgContext, java.lang.String sOffice ) throws java.lang.Exception ;
	
	public com.fundtech.datacomponent.response.Feedback executeMamboBusinessFlowSelector(final Admin admin, java.lang.String sMessage, java.lang.String sInMsgContext, java.lang.String sOffice ) throws java.lang.Exception ;
	
	/** 
	 */
	public void performFailurePaymentCompensation(final Admin admin ) throws java.lang.Exception ;

}//EOI  