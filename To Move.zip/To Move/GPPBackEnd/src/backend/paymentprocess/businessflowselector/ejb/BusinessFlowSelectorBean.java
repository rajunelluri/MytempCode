package backend.paymentprocess.businessflowselector.ejb;

import javax.ejb.Stateless;

import backend.businessobject.proxies.interceptors.InterceptorSetType;
import backend.core.SuperSLSB;
import backend.paymentprocess.businessflowselector.businessobjects.BOBusinessFlowSelector;
import backend.paymentprocess.businessflowselector.ejbinterfaces.BusinessFlowSelector;
import backend.paymentprocess.businessflowselector.ejbinterfaces.BusinessFlowSelectorLocal;

import com.fundtech.annotations.EJBRef;
import com.fundtech.annotations.Expose;
import com.fundtech.annotations.JMS;
import com.fundtech.annotations.Wrap;
import com.fundtech.annotations.EJBRef.EJBRefType;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;
  
@Wrap(tx="Bean",
		EJBRefs={   
			@EJBRef(type=EJBRefType.Local, jndi="ejb/DebulkFileBeanLocal", 
            interfaceClass="backend.paymentprocess.debulkingprocess.ejbinterfaces.DebulkFileLocal", 
            targetEJB="DebulkFile")},
            jmsResources={@JMS(conFactoryJmsResourceKey="interfaces")}
			) 
@Stateless 
public class BusinessFlowSelectorBean extends SuperSLSB<BusinessFlowSelector> implements BusinessFlowSelectorLocal, BusinessFlowSelector{
	
	public BusinessFlowSelectorBean() { super(BOBusinessFlowSelector.class, InterceptorSetType.None) ; }//EOM
	
	@Expose
	public com.fundtech.datacomponent.response.Feedback executeBusinessFlow(final Admin admin, java.lang.String sMessage, java.lang.String sInMsgContext, java.lang.String sOffice ) throws java.lang.Exception {
		return this.m_bo.executeBusinessFlow(admin, sMessage, sInMsgContext, sOffice ) ;
	}//EOM
	
	@Expose
	public com.fundtech.datacomponent.response.Feedback executeMamboBusinessFlowSelector(final Admin admin, java.lang.String sMessage, java.lang.String sInMsgContext, java.lang.String sOffice ) throws java.lang.Exception {
		return this.m_bo.executeMamboBusinessFlowSelector(admin, sMessage, sInMsgContext, sOffice ) ;
	}//EOM

	/** 
	 * Executes a business flow according to the result returned from execution of rule type
	 * 158 - Business flow selection - for the passed MID.
	 */
	@Expose
	public com.fundtech.datacomponent.response.Feedback executeFlow(final Admin admin, java.lang.String sMID, java.lang.Boolean bSavePDO, java.lang.Object[] arrAdditionalInput ) {
		return this.m_bo.executeFlow(admin, sMID, bSavePDO, arrAdditionalInput ) ;
	}//EOM
	
  @Expose
  public Feedback executeBPELBusinessFlowSelector(final Admin admin, final java.lang.String sMessage, final java.lang.String sInMsgContext, final java.lang.String sOffice) throws Exception
  {
  	return this.m_bo.executeBPELBusinessFlowSelector(admin, sMessage, sInMsgContext, sOffice ) ;
	}
  
  /**
   * 
   */
  @Expose
  public void performFailurePaymentCompensation(final Admin admin) throws Exception
  {
  	this.m_bo.performFailurePaymentCompensation(admin) ;
  }
  
}//EOC