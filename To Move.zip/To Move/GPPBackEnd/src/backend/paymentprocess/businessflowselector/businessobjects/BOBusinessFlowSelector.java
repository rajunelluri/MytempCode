package backend.paymentprocess.businessflowselector.businessobjects;

import static com.fundtech.core.paymentprocess.data.paymenttypes.PaymentType.PT_NOMT;
import static com.fundtech.util.GlobalUtils.isNullOrEmpty;

import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.businessobject.BOBasic;
import backend.businessobject.BOProxies;
import backend.businessobject.proxies.BOProxy;
import backend.businessobject.tx.RemoveDupexFromCacheLastResourceHandler;
import backend.businessobject.tx.SpringTransactionProxy;
import backend.core.module.MessageConstantsInterface;
import backend.dataaccess.dto.DTODataHolder;
import backend.mambo.businessobjects.BOMamboSetBasicProperties;
import backend.paymentprocess.businessflowselector.dao.DAOBusinessFlowSelector;
import backend.paymentprocess.contingency.ContingencyLogLastResource;
import backend.paymentprocess.erroraudit.ErrorAuditUtils;
import backend.paymentprocess.flow.base.AbstractFlow;
import backend.paymentprocess.flow.base.Flow;
import backend.paymentprocess.interfaces.handlers.FeederInterfaceHandler;
import backend.paymentprocess.interfaces.handlers.helpers.InterfaceTypesFactory;
import backend.paymentprocess.mappaymentinfo.businessobjects.BOMapPaymentInfoUsingRules;
import backend.paymentprocess.ocbc.g3adminmessages.businessobjects.AbstractBOAdmin;
import backend.util.ServerConstants;

import com.fundtech.annotations.Expose;
import com.fundtech.annotations.Expose.ExposureType;
import com.fundtech.annotations.Wrap;
import com.fundtech.cache.entities.RuleResults;
import com.fundtech.cache.infrastructure.CacheServiceInterface;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.general.flows.FlowException;
import com.fundtech.core.general.tx.LastResourceInterface;
import com.fundtech.core.paymentprocess.PDOException;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.core.paymentprocess.errorhandling.ProcessError;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.errors.ProcessErrorConstants;
import com.fundtech.interfaces.handlers.InterfaceTypeInHandler;
import com.fundtech.util.ExceptionController;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalUtils;
import com.fundtech.util.Monitors;


/**
 * Title:       BOBusinessFlowSelector
 * Description: Business object for business flow selection
 * Company:     Fundtech Israel
 * Author:      Asaf Levy
 * Date:        09/07/2009
 * @version     1.0
 */
@Wrap

public class BOBusinessFlowSelector extends BOBasic implements MessageConstantsInterface, PDOConstantFieldsInterface{

  private static final Logger logger = LoggerFactory.getLogger(BOBusinessFlowSelector.class);
	
  private static DAOBusinessFlowSelector m_daoBusinessFlowSelector = DAOBusinessFlowSelector.getInstance();
  private Map<String, Object[]> m_mapBusinessFlowIDtoMethod;
  
  private static final String NULL_OBJECT_IN_MSG_HANDLER_KEY = "GENERIC_XML_MSG" ; 
  
  private static Feedback m_errorFeedback;
  private static ProcessError m_errorNoBusinessFlowSelectionRuleDefinition;
  
  private static Method executeBusinessFlowInner ;
  private static Method executeMamboFlowInner ;
  private static Method executeFlowInner ; 
  
  private final boolean m_bDisposed = false ; 
  
  static{
	  
    String sRuleTypeName = CacheKeys.PRulesTypeKey.getSingle(RULE_TYPE_ID_BUSINESS_FLOW_SELECTION).getRuleTypeName();
    Object[] arrNonPaymentFields = new Object[]{RULE_TYPE_ID_BUSINESS_FLOW_SELECTION, sRuleTypeName};

    // Error code 40104: 'Rule type ID |1 - |2 - wasn't found'.
    m_errorNoBusinessFlowSelectionRuleDefinition = new ProcessError(ProcessErrorConstants.MandatoryRuleTypeIDWasntFound, arrNonPaymentFields);
    
    m_errorFeedback = new Feedback(ProcessErrorConstants.MandatoryRuleTypeIDWasntFound, m_errorNoBusinessFlowSelectionRuleDefinition.getDescription());
    m_errorFeedback.setFailure();
    
    try{ 
    	executeBusinessFlowInner = BOBusinessFlowSelector.class.getDeclaredMethod("executeBusinessFlowInner", String.class, String.class, String.class) ;
    	executeMamboFlowInner = BOBusinessFlowSelector.class.getDeclaredMethod("executeMamboFlowInner", String.class, String.class, String.class) ;
    	executeFlowInner = BOBusinessFlowSelector.class.getDeclaredMethod("executeFlowInner", String.class, Boolean.class , Object[].class) ;
    }catch(Exception e) { 
    	logger.error(e.getMessage());
    }//EO catch block 
    
  }//EO static block    
    
  public final Feedback executeBusinessFlow(final String sMessage, final String sInMsgContext, final String sOffice) throws FlowException{
	  return (Feedback) super.executeInProtectedBoundaries(executeBusinessFlowInner, sMessage, sInMsgContext, sOffice) ;
  }//EOM
  
  public final Feedback executeFlow(String sMID, final Boolean bSavePDO, final Object...arrAdditionalInput) throws FlowException {
	   return (Feedback) super.executeInProtectedBoundaries(executeFlowInner, sMID, bSavePDO, arrAdditionalInput) ; 
  }//EOM 
   
  public final Feedback executeMamboBusinessFlowSelector(final String sMessage, final String sInMsgContext, final String sOffice) throws FlowException{
	  return (Feedback) super.executeInProtectedBoundaries(executeMamboFlowInner, sMessage, sInMsgContext, sOffice) ;
  }
  
  private final Feedback executeMamboFlowInner(final String sMessage, final String sInMsgContext, final String sOffice) throws Throwable{
	  Feedback feedback = new Feedback();
	  PDO pdo = null;


	  final InterfaceTypeInHandler interfaceInHandler = 
		  InterfaceTypesFactory.getInHandlerForContext(sInMsgContext, sMessage, FeederInterfaceHandler.class) ;
	  long startTime = System.currentTimeMillis();

	  pdo = interfaceInHandler.parseMsg(sMessage, sInMsgContext, sOffice) ;
	  
	  Monitors.FLOWS.stepEnd(System.currentTimeMillis()-startTime,sInMsgContext+".InterfaceHandler.parseMsg","BOBusinessFlowSelector");
	  
	  if(pdo == null) {
		  feedback.setFailure();
		  feedback.setErrorText("Failed to create PDO from incoming message");
		  return feedback ; 
	  }

	  final String TRACE_NO_BUSINESS_FLOW_SELECTION_RULE_WAS_FOUND = "ERROR: No business flow selection was found !";
	  final String TRACE_BUSINESS_FLOW_SELECTION_RESULTS = "Business flow selection results - Business object: {}, Method: {}.";

	  final String TRACE_BUSINESS_FLOW_ID = "Returned business flow ID: {}.";
	  final String TRACE_STOP_ACTION_DATA = "STOP action was found for business flow selection - MID: {}, P_MSG_STS: {}, D_BUTTON_ID: {}, D_CONFIRMATION_FLOW: {}.";

	  final Admin admin = Admin.getContextAdmin();
	  String mid = pdo.getMID() ; 

	  logger.debug("About to set Mambo Basic Properties to PDO");
	  feedback = new BOMamboSetBasicProperties().setMamboBasicProperties(mid);
	  if(feedback.isSuccessful()){
		  
		  // Gets the business flow ID to execute by executing rule type 158 - Business flow selection - for the passed MID.
		  final RuleResults ruleResults = BOProxies.m_internalRuleExecutionLogging.executeRule(admin, RULE_TYPE_ID_BUSINESS_FLOW_SELECTION, 
				  null, pdo.getMID(), new String[]{ServerConstants.DEFAULT_SERVER_OFFICE_NAME/*rule is attached to '***' */, ServerConstants.DEFAULT_SERVER_OFFICE_NAME}) ; 

		  String sBusinessFlowID = null;
		  boolean bSTOPAction = ruleResults.getCompletionCode() == RuleResults.CompletionCode.STOP;

		  // Valid business flow ID.
		  if(!bSTOPAction && !ruleResults.getResults().isEmpty()) { 
			  sBusinessFlowID =  ruleResults.getResults().get(0).getAction();
		  }

		  // No STOP action & we have a valid business flow ID.
		  if(!bSTOPAction && !isNullOrEmpty(sBusinessFlowID)){
			  logger.info(TRACE_BUSINESS_FLOW_ID, sBusinessFlowID);
			  Object[] arrAdditionalInput = new Object[0];
			  Object[] arrBusinessFlowIDRelatedData = getBusinessFlowMethod(sBusinessFlowID, arrAdditionalInput);

			  // Invokes the business object method.
			  final Object oBusinessObject = arrBusinessFlowIDRelatedData[0];
			  Method businessFlowMethod = (Method)arrBusinessFlowIDRelatedData[1];
			  logger.info(TRACE_BUSINESS_FLOW_SELECTION_RESULTS, oBusinessObject, businessFlowMethod.getName());

			  // Prepares the formal arguments array.  
			  Object[] arrFormalArgs = new Object[2] ;		
			  arrFormalArgs[0] = admin;
			  arrFormalArgs[1] = mid;
			  for (int i=0; i<arrFormalArgs.length; i++){
				  if(arrFormalArgs[i] instanceof Class) arrFormalArgs[i] = null;
			  }

			  logger.info("About to call businessFlow method");
			  feedback = (Feedback)businessFlowMethod.invoke(oBusinessObject, arrFormalArgs);

			  if (feedback.isSuccessful()){
				  logger.info("Returned from businessFlow method with successful feedback, will save pdo to MINF");
				  this.performSaveProcess(pdo);
			  }else{
				  logger.info("Returned from businessFlow method with unsuccessful feedback, will NOT save pdo to MINF");
			  }

		  }
		  
		  // Rule wasn't defined for this message.
		  else{
			  // STOP action; does nothing except for traces.
			  if(bSTOPAction){
				  String sP_MSG_STS = pdo.getString(P_MSG_STS);
				  String sActionID = pdo.getString(D_BUTTON_ID);
				  String sD_CONFIRMATION_FLOW   = pdo.getString(D_CONFIRMATION_FLOW);
				  logger.info(TRACE_STOP_ACTION_DATA,  new Object[]{ mid, sP_MSG_STS, sActionID, sD_CONFIRMATION_FLOW});
			  }

			  // Null business flow ID.
			  else{
				  logger.info(TRACE_NO_BUSINESS_FLOW_SELECTION_RULE_WAS_FOUND);
				  pdo.set(P_MSG_STS, MESSAGE_STATUS_REPAIR);
				  feedback = m_errorFeedback;
				  ErrorAuditUtils.setErrors(m_errorNoBusinessFlowSelectionRuleDefinition,pdo.getIsHistory());
			  }
		  }
	  }
	  // Set basic properties service has failed. 
	  else { 
		  logger.error(feedback.getErrorText());
	  }
	  
	  return feedback ; 
  }//EOM


 //Method is invoked in reflection
  @SuppressWarnings("unused")
private final Feedback executeBusinessFlowInner(final String sMessage, final String sInMsgContext, final String sOffice) throws Throwable{
	  	  
   
	  Feedback feedback = new Feedback();
	  PDO pdo = null;


	  try{
		    
		   //use the context to retrieve the corresponding interface type from cache. 
		   //if no instance was found use the feeder as the null object
		  //from the interface type retrieve the handler class and use it to parse the message
		  //or map a response into an existing pdo. 
		  //TODO: deal with the office key issue. For now use default office 
		  final InterfaceTypeInHandler interfaceInHandler = 
			  InterfaceTypesFactory.getInHandlerForContext(sInMsgContext, sMessage, FeederInterfaceHandler.class) ; 
		  
		  pdo = interfaceInHandler.parseMsg(sMessage, sInMsgContext, sOffice) ;
		  if(pdo == null) return feedback ; 
		  
		  try{
			  Admin.getContextAdmin().registerLastResourcesHandler(SpringTransactionProxy.m_txWrapper.get(), false/*bFailIfHandlerAlreadyExists*/);
			  Admin.getContextAdmin().registerLastResource(new ContingencyLogLastResource());
		  }catch (Throwable e) {
			  logger.error("Failed to register last resource",e);
		  }
		  logger.info("## ## ## START BUSINESS FLOW FOR MID: {} ## ## ##", pdo.getMID());		  
		   //else 
		   
		  // If an actual office value was passed, use it; otherwise, in case an office was passed in the extension,
		   // use it.
		   /*if(!isNullOrEmpty(sOffice)) pdo.set(P_OFFICE, sOffice);*/
		   
		   //if PDO is not a valid payment type, persist and abort flow
		   //Note: such pdo's shall contain a FreeFormText element encapsulating the raw message as the fndtmsg pmnt child. 
		   //Note: the related process error would have already been persisted and stored in the pdo's message errors list  
		   if(pdo.get(P_MSG_TYPE).equals(PT_NOMT) || pdo.getString(P_MSG_STS).equals(MESSAGE_STATUS_AUTHEX)) { 
			   throw new PDOException(pdo);
		   }else if(!pdo.isContinueFlow()){
		          performSaveProcess(pdo);
		   }//EO if the pdo contained an invalid message
		   else { 
			  feedback = this.executeFlowInner(pdo.getMID(), true /*bSavePDO*/) ;

			  logger.info("## ## ## END BUSINESS FLOW FOR MID: {} ## ## ##", pdo.getMID());		 			  
		   }//EO else if the pdo was created successfully 
	   }catch(PDOException pdoE){
		   
		   pdo = pdoE.getPdo();
	   
		   
		   //ensure that in all scenarios the where the pdo exists, it shall contain the office, department and create date as a bare minimum 
		   if(pdo != null){ 
		   	   String mid = pdo.getMID();
		   	   BOProxies.m_setBasicPropertiesLogging.setBasicProperties(Admin.getContextAdmin(), mid) ;
			   
			   // Run the department rule in order to set it
			   pdo.set(D_RULE_TYPE_ID, RULE_TYPE_ID_DEPARTMENT);
			   BOMapPaymentInfoUsingRules.handleRuleExecutionAndMappingToPDO(mid);
			    ErrorAuditUtils.onError(ProcessErrorConstants.InvalidInputFlowTermination, feedback, new Object[]{pdo.getMID(), pdo.getString(PDOConstantFieldsInterface.P_MSG_STS)}) ; 
			   logger.error(feedback.getErrorText());   
			   this.performSaveProcess(pdo);
		   }//EO if there was a pdo associated with the exception 
		   
	   }//EO pdoException catch block 
	   
	   return feedback ; 
  }//EOM 
  
 
  private final Feedback executeFlowInner(String sMID, final Boolean bSavePDO, final Object...arrAdditionalInput) throws Throwable {
    final String TRACE_NO_BUSINESS_FLOW_SELECTION_RULE_WAS_FOUND = "ERROR: No business flow selection was found !";
    final String TRACE_BUSINESS_FLOW_SELECTION_RESULTS = "Business flow selection results - Business object: {}, Method: {}.";
    
    final String TRACE_BUSINESS_FLOW_ID = "Returned business flow ID: {}.";
    final String TRACE_STOP_ACTION_DATA = "STOP action was found for business flow selection - MID: {}, P_MSG_STS: {}, D_BUTTON_ID: {}, D_CONFIRMATION_FLOW: {}.";
    

    long startTime = System.currentTimeMillis();
    
    Feedback feedback = new Feedback();
    
    PDO pdo = PaymentDataFactory.load(sMID);
    final Admin admin = Admin.getContextAdmin();
    sMID = pdo.getMID() ; 
    Boolean isAdminMessage = false;
	   try
	   {
	    feedback = BOProxies.m_setBasicPropertiesLogging.setBasicProperties(admin, sMID);
	      
	    // All basic properties, (office, debit MOP etc), were mapped with no problems.
	    if(feedback.isSuccessful()){
		   
	    	// Gets the business flow ID to execute by executing rule type 158 - Business flow selection - for the passed MID.
		    final RuleResults ruleResults = BOProxies.m_internalRuleExecutionLogging.executeRule(Admin.getContextAdmin(), 
			            RULE_TYPE_ID_BUSINESS_FLOW_SELECTION, 
			            null, pdo.getMID(), new String[]{pdo.getString(P_OFFICE), ServerConstants.DEFAULT_SERVER_OFFICE_NAME}) ; 
		
		    String sBusinessFlowID = null;
		    boolean bSTOPAction = ruleResults.getCompletionCode() == RuleResults.CompletionCode.STOP;
		
		    // Valid business flow ID.
		    if(!bSTOPAction && !ruleResults.getResults().isEmpty()) 
		    { 
		      sBusinessFlowID = ruleResults.getResults().get(0).getAction();
		    }
		
		    // No STOP action & we have a valid business flow ID.
		    if(!bSTOPAction && !isNullOrEmpty(sBusinessFlowID))
		    {
	        	logger.info(TRACE_BUSINESS_FLOW_ID, sBusinessFlowID);
	        	
	          Object[] arrBusinessFlowIDRelatedData = getBusinessFlowMethod(sBusinessFlowID, arrAdditionalInput);
	          
	          // Invokes the business object method.
	          final Object oBusinessObject = arrBusinessFlowIDRelatedData[0];
	          Method businessFlowMethod = (Method)arrBusinessFlowIDRelatedData[1];
	          logger.info(TRACE_BUSINESS_FLOW_SELECTION_RESULTS, oBusinessObject, businessFlowMethod.getName());
	          //
	          isAdminMessage = AbstractBOAdmin.class.isAssignableFrom(oBusinessObject.getClass());
	          // Prepares the formal arguments array.
	          
	          int iFormalArgsLength = arrAdditionalInput.length;
	          Object[] arrFormalArgs;
	          //check that the class is AbstractBOAdmin or BOBasic or extends it.
	          if (Flow.class.isAssignableFrom(oBusinessObject.getClass()) || 
	        	  AbstractBOAdmin.class.isAssignableFrom(oBusinessObject.getClass())){
	        	  arrFormalArgs = new Object[1] ;
	        	  System.arraycopy(arrAdditionalInput, 0, arrFormalArgs, 1, iFormalArgsLength) ;
	        	  arrFormalArgs[0] = sMID;
	          }
	          else
	          {
	          
	          arrFormalArgs = new Object[iFormalArgsLength+2] ;
	          System.arraycopy(arrAdditionalInput, 0, arrFormalArgs, 2, iFormalArgsLength) ; 
	          arrFormalArgs[0] = admin;
	          arrFormalArgs[1] = sMID;
	          
	          }
	          // 
	          for (int i=0; i<arrFormalArgs.length; i++)
	          {
	            if(arrFormalArgs[i] instanceof Class) arrFormalArgs[i] = null;
	          }
	          //System.out.println("FLOW SELECTOR BEFORE ----> " + ((float)(System.nanoTime()-lBefore)/GlobalConstants.NANOS_TO_MS_DIVIDER));
	          
	          setFlowName(oBusinessObject,pdo);
	          Monitors.FLOWS.flowStart(pdo);
	          feedback = (Feedback)businessFlowMethod.invoke(oBusinessObject, arrFormalArgs);
	          
	        }
	        // Rule wasn't defined for this message.
	        else
	        {
	        	// STOP action; does nothing except for traces.
	        	if(bSTOPAction)
	        	{
		          String sP_MSG_STS = pdo.getString(P_MSG_STS);
		          String sActionID = pdo.getString(D_BUTTON_ID);
		          String sD_CONFIRMATION_FLOW   = pdo.getString(D_CONFIRMATION_FLOW);
		          logger.info(TRACE_STOP_ACTION_DATA,  new Object[]{ sMID, sP_MSG_STS, sActionID, sD_CONFIRMATION_FLOW});
	        	}
	        	
	        	// Null business flow ID.
	        	else
	        	{
		          logger.info(TRACE_NO_BUSINESS_FLOW_SELECTION_RULE_WAS_FOUND);
		          pdo.set(P_MSG_STS, MESSAGE_STATUS_REPAIR);
		          feedback = m_errorFeedback;
		          ErrorAuditUtils.setErrors(m_errorNoBusinessFlowSelectionRuleDefinition,pdo.getIsHistory());
	        	}
	        }
	      }
	      // Set basic properties service has failed. 
	      else 
	      { 
	    	  logger.error(feedback.getErrorText());
	      }
	      
	      long lBeforeSave = System.nanoTime() ;
	
	      //      if this flag is true, then remove the PDO from local and remote cache without save
	      //boolean skipSave = pdo.getBoolean(PDOConstantFieldsInterface.D_SKIP_PERSIST_ON_ERROR) != null && pdo.getBoolean(PDOConstantFieldsInterface.D_SKIP_PERSIST_ON_ERROR);
	      // Save process.
	      //if (bSavePDO && skipSave) CacheKeys.ProcessPDOKey.removeFromLocalAndRemote(pdo);
	      //else if(bSavePDO) this.performSaveProcess(pdo);
	      if(bSavePDO && !isAdminMessage) this.performSaveProcess(pdo);
	    	  Monitors.FLOWS.flowEnd((System.currentTimeMillis()-startTime),pdo);//.getString("D_FLOW_NAME"),pdo.getStatus());
	    	  
		  } 
	   	  finally 
	   	  {
	      // Store the list of dupex key`s at LastResourcesManager in order to
	      // remove them from cache after commit transaction ( CAll at
	      // SpringTransactionProxy.afterCommit )
	      List<String> dupexKeys = admin.getContextDupexKeys();
	      if (dupexKeys != null && !dupexKeys.isEmpty()) {
	            LastResourceInterface removeDupexFromCacheLastResourceHandler = new RemoveDupexFromCacheLastResourceHandler(
	                        dupexKeys);
	            try{
	                  admin.registerLastResource(removeDupexFromCacheLastResourceHandler);
	            }catch(Exception e){
	                  System.err.println(e.getMessage());
	            }
	      }
	}



      //System.out.println("FLOW SELECTOR SAVE ----> " + ((float)(System.nanoTime()-lBeforeSave)/GlobalConstants.NANOS_TO_MS_DIVIDER));
 
    //FOR DEBUG
      //if(pdo.getMID().equals("10616C3416CF2413")) throw new RuntimeException("DEBUG EXCEPTION AFTER FLOW SELECTOR") ;
    //FOR DEBUG
      
      return feedback;
  }//EOM 
  
  private void setFlowName(Object oBusinessObject, PDO pdo) {
	String flowName = oBusinessObject.getClass().getSimpleName();  
	if (oBusinessObject instanceof Flow)
		flowName = ((AbstractFlow)oBusinessObject).getFlowName().name();
	else if (Proxy.isProxyClass(oBusinessObject.getClass())) { //flowName.startsWith("$Proxy")) {	//Proxy.isProxy didn't work, why ?!
		try {
			String boproxyToString = oBusinessObject.toString();
			flowName = boproxyToString.substring(boproxyToString.lastIndexOf(".")+1,boproxyToString.indexOf("@"));
		} catch (Exception ignore) {			
		}
	}
	pdo.set("D_FLOW_NAME",flowName);	
  }
  /**
   * 
   */
  private Feedback handleValidBusinessFlowID(String sMID, boolean bSTOPAction, String sBusinessFlowID, long lBefore, final Object...arrAdditionalInput) throws Throwable
  {
    final String TRACE_BUSINESS_FLOW_ID = "Returned business flow ID: {}.";
    final String TRACE_BUSINESS_FLOW_SELECTION_RESULTS = "Business flow selection results - Business object: {}, Method: {}.";
    final String TRACE_STOP_ACTION_DATA = "STOP action was found for business flow selection - MID: {}, P_MSG_STS: {}, D_BUTTON_ID: {}, D_CONFIRMATION_FLOW: {}.";
    final String TRACE_NO_BUSINESS_FLOW_SELECTION_RULE_WAS_FOUND = "ERROR: No business flow selection was found !";
  	
  	Feedback feedback = new Feedback();
  	
  	Admin admin = Admin.getContextAdmin();
  	PDO pdo = PaymentDataFactory.load(sMID);
  	
    // No STOP action & we have a valid business flow ID.
    if(!bSTOPAction && !isNullOrEmpty(sBusinessFlowID))
    {
    	logger.info(TRACE_BUSINESS_FLOW_ID, sBusinessFlowID);
    	
      Object[] arrBusinessFlowIDRelatedData = getBusinessFlowMethod(sBusinessFlowID, arrAdditionalInput);
      
      // Invokes the business object method.
      final Object oBusinessObject = arrBusinessFlowIDRelatedData[0];
      Method businessFlowMethod = (Method)arrBusinessFlowIDRelatedData[1];
      logger.info(TRACE_BUSINESS_FLOW_SELECTION_RESULTS, oBusinessObject, businessFlowMethod.getName());
      //
      // Prepares the formal arguments array.  
      int iFormalArgsLength = arrAdditionalInput.length;
      Object[] arrFormalArgs = new Object[iFormalArgsLength+2] ;
      System.arraycopy(arrAdditionalInput, 0, arrFormalArgs, 2, iFormalArgsLength) ; 
      arrFormalArgs[0] = admin;
      arrFormalArgs[1] = sMID;
      // 
      for (int i=0; i<arrFormalArgs.length; i++)
      {
        if(arrFormalArgs[i] instanceof Class) arrFormalArgs[i] = null;
      }
      //System.out.println("FLOW SELECTOR BEFORE ----> " + ((float)(System.nanoTime()-lBefore)/GlobalConstants.NANOS_TO_MS_DIVIDER));
      
      feedback = (Feedback)businessFlowMethod.invoke(oBusinessObject, arrFormalArgs);
    }

    // Rule wasn't defined for this message.
    else
    {
    	// STOP action; does nothing except for traces.
    	if(bSTOPAction)
    	{
        String sP_MSG_STS = pdo.getString(P_MSG_STS);
        String sActionID = pdo.getString(D_BUTTON_ID);
        String sD_CONFIRMATION_FLOW   = pdo.getString(D_CONFIRMATION_FLOW);
        logger.info(TRACE_STOP_ACTION_DATA,  new Object[]{ sMID, sP_MSG_STS, sActionID, sD_CONFIRMATION_FLOW});
    	}
    	
    	// Null business flow ID.
    	else
    	{
        logger.info(TRACE_NO_BUSINESS_FLOW_SELECTION_RULE_WAS_FOUND);
        pdo.set(P_MSG_STS, MESSAGE_STATUS_REPAIR);
        feedback = m_errorFeedback;
        ErrorAuditUtils.setErrors(m_errorNoBusinessFlowSelectionRuleDefinition,pdo.getIsHistory());
    	}
    }
  
    return feedback;
  }
  
  /**
   * 
   */
  @Expose(type = ExposureType.InternalInterface)
  public void performSaveProcess(PDO pdo) throws Throwable
  {
	 long startTime = System.currentTimeMillis();
  	final String MESSAGE_EXPLICIT_LINKED_MSG_TO_SAVE = "Explicit linked message to save: %s.";
  	final String MESSAGE_NO_EXPLICIT_LINKED_MSG_TO_SAVE = "There are no explicit linked messages to save; will save only the main PDO";
  	
  	
  	
  	PDO pdoExplicitLinkedPDOToSave = null;
  	
  	Object oD_EXPLICIT_LINKED_MSG_TO_SAVE = pdo.getAdditionalData(D_EXPLICIT_LINKED_MSG_TO_SAVE);
  	if(oD_EXPLICIT_LINKED_MSG_TO_SAVE != null && oD_EXPLICIT_LINKED_MSG_TO_SAVE instanceof String)
  	{
  		logger.info(String.format(MESSAGE_EXPLICIT_LINKED_MSG_TO_SAVE, oD_EXPLICIT_LINKED_MSG_TO_SAVE));
  		pdoExplicitLinkedPDOToSave = pdo.getLinkedMsg((String)oD_EXPLICIT_LINKED_MSG_TO_SAVE);
  	}
  	else
  	{
  		logger.info(MESSAGE_NO_EXPLICIT_LINKED_MSG_TO_SAVE);
  	}
  	
  	PDO[] arrPDOsToSave = pdoExplicitLinkedPDOToSave != null ? new PDO[]{pdo, pdoExplicitLinkedPDOToSave} : new PDO[]{pdo};
  	PaymentDataFactory.batchSave(true, arrPDOsToSave);
  	
  	Monitors.FLOWS.stepEnd((System.currentTimeMillis()-startTime),"BOBusinessFlowSelector.SavePDO",pdo.getString("D_FLOW_NAME"));
  	  	
  }
  
  /**
   * 
   */
  private final Object[] getBusinessFlowMethod(final String sBusinessFlowID, final Object...arrAdditionalInput)
  {
    
    
    if(m_mapBusinessFlowIDtoMethod == null)
    {
      initializeBusinessFlowIDtoMethodMap();
    }
    
    Object[] arrBusinessFlowIDRelatedData = m_mapBusinessFlowIDtoMethod.get(sBusinessFlowID);
    
    try
    {
      // Business class object & related 'Method' object haven't been instantiated yet.
      if(arrBusinessFlowIDRelatedData[0] instanceof String)
      {
        final String sBusinessObjectClassName = (String)arrBusinessFlowIDRelatedData[0];
        Object businessFlowMethod = arrBusinessFlowIDRelatedData[1];
        Class cls = Class.forName(sBusinessObjectClassName);
        AbstractBOAdmin AdminSignCls = null ;
        
        //backend.paymentprocess.flow.base.Flow Notes:
        // 1. we are not going through BOProxy for it
        // 2. we do not share Flow between transaction, instead we use new instance for each transaction
        //check that the class is AbstractBOAdmin or BOBasic or extends it.
        if (Flow.class.isAssignableFrom(cls) || AbstractBOAdmin.class.isAssignableFrom(cls)) {
        	if (businessFlowMethod instanceof String) {
        		Class[] params = new Class[1];
            	params[0] = java.lang.String.class;
            	businessFlowMethod = org.springframework.util.ReflectionUtils.findMethod(cls, (String)businessFlowMethod, params);
            	arrBusinessFlowIDRelatedData[1] = businessFlowMethod;  //avoid reflecting the method again              
        	}      
        	
        	Object[] concreteBusinessFlowIDRelatedData  = new Object[arrBusinessFlowIDRelatedData.length];
        	System.arraycopy(arrBusinessFlowIDRelatedData, 0, concreteBusinessFlowIDRelatedData, 0, concreteBusinessFlowIDRelatedData.length);        	
        	
        	concreteBusinessFlowIDRelatedData[0] =  cls.newInstance(); 
        	
        	arrBusinessFlowIDRelatedData = concreteBusinessFlowIDRelatedData;
        } 
       
        else
        {
        
            // Gets the business object related class.
	    final Object oBusinessObject = BOProxy.loggingDecoration(Class.forName(sBusinessObjectClassName));
        
        
        
        // Gets the Method object, where:
        // 1) 1st method parameter is always an Admin object.
        // 2) 2nd method parameter is always a String object for the MID.
        // 3) Additional parameters are optional according to the passed 'arrAdditionalInput' varargs.
        int iFormalArgsLength = arrAdditionalInput.length;
        Class[] arrFormalArgTypes = new Class[iFormalArgsLength+2]; 
        arrFormalArgTypes[0] = Admin.class;
        arrFormalArgTypes[1] = String.class;
        
        for(int i=0; i<iFormalArgsLength; i++)
        { 
          if(arrAdditionalInput[i] instanceof Class) 
          {
            arrFormalArgTypes[i+2] = (Class)arrAdditionalInput[i];
          }
          else
          {
            arrFormalArgTypes[i+2] = arrAdditionalInput[i].getClass(); 
          }
        }          
        
        //Method businessFlowMethod = oBusinessObject.getClass().getDeclaredMethod(sBusinessFlowMethod, Admin.class, String.class);
        businessFlowMethod = oBusinessObject.getClass().getDeclaredMethod((String)businessFlowMethod, arrFormalArgTypes);
        
        // Updates the map for next time.
        arrBusinessFlowIDRelatedData[0] = oBusinessObject;
        arrBusinessFlowIDRelatedData[1] = businessFlowMethod;
      }
      }
    }
    catch(Exception e)
    {
      ExceptionController.getInstance().handleException(e, this);
    }
    
    
    
    return arrBusinessFlowIDRelatedData;
  }
  

  /**
   * 
   */
  private synchronized void initializeBusinessFlowIDtoMethodMap()
  {
	if (m_mapBusinessFlowIDtoMethod != null)
	  return;

	HashMap<String, Object[]> businessMethods = new HashMap<String, Object[]>();
	  
	final String COLUMN_BUSINESS_FLOW_ID = "BUSINESS_FLOW_ID";
	final String COLUMN_BUSINESS_OBJECT_CLASS_NAME = "BUSINESS_OBJECT_CLASS_NAME";
	final String COLUMN_BUSINESS_METHOD = "BUSINESS_METHOD";
	final String COLUMN_IMPLEMENTED_BY_BPEL = "IMPLEMENTED_BY_BPEL";
    
    DTODataHolder dto = m_daoBusinessFlowSelector.getInstance().getBUSINESS_FLOW_DEFINITION_Table();
      
    if(dto.isFeedBackSuccess() && !dto.isEmpty())
    {
      String sBusinessFlowID, sBusinessObjectClassName, sBusinessMethod, sImplementedByBPEL;
      
      ArrayList alData = dto.getDataAL();
      int iSize = alData.size();
      
      for(int i=0; i<iSize; i++)
      {
        HashMap hmData = (HashMap)alData.get(i);
        
        sBusinessFlowID = (String)hmData.get(COLUMN_BUSINESS_FLOW_ID);
        sBusinessObjectClassName = (String)hmData.get(COLUMN_BUSINESS_OBJECT_CLASS_NAME);
        sBusinessMethod = (String)hmData.get(COLUMN_BUSINESS_METHOD);
        
        sImplementedByBPEL = (String)hmData.get(COLUMN_IMPLEMENTED_BY_BPEL);
        Boolean boolImplementedByBPEL = new Boolean(!GlobalUtils.isNullOrEmpty(sImplementedByBPEL) && !GlobalConstants.ZERO_VALUE.equals(sImplementedByBPEL)) ; 
                
        businessMethods.put(sBusinessFlowID, new Object[]{sBusinessObjectClassName, sBusinessMethod, boolImplementedByBPEL});
      }
      
      m_mapBusinessFlowIDtoMethod = businessMethods;
      
    }
    
    
  }
  
  /**
   * 
   */
  public Feedback executeBPELBusinessFlowSelector(final String sMessage, final String sInMsgContext, final String sOffice) throws Throwable
  {
	 // final BackendTracer GlobalTracer = BackendTracer.getInstance() ;
	  
	  long lBefore = System.nanoTime() ;
	   
	  Feedback feedback = new Feedback();
	  PDO pdo = null;
	  String sMID = null;
	  Admin admin = Admin.getContextAdmin();
	   
	  try
	  {
		  final InterfaceTypeInHandler interfaceInHandler = InterfaceTypesFactory.getInHandlerForContext(sInMsgContext, sMessage, FeederInterfaceHandler.class) ; 
		  
		  pdo = interfaceInHandler.parseMsg(sMessage, sInMsgContext, sOffice) ;
		  if(pdo == null) return feedback ; 

		  if(pdo.getString(P_MSG_STS).equals(MESSAGE_STATUS_AUTHEX)) 
		  {
		  	throw new PDOException(pdo);
		  }
		  
		  // Executes business flow selector rule for getting the business flow ID.
		  else
		  {
		  	sMID = pdo.getMID();
		    feedback = BOProxies.m_setBasicPropertiesLogging.setBasicProperties(admin, sMID);
	      
		    // All basic properties, (office, debit MOP etc), were mapped with no problems.
		    if(feedback.isSuccessful())
		    {
		    	// Gets the business flow ID to execute by executing rule type 158 - Business flow selection - for the passed MID.
			    final RuleResults ruleResults = BOProxies.m_internalRuleExecutionLogging.executeRule(Admin.getContextAdmin(), RULE_TYPE_ID_BUSINESS_FLOW_SELECTION, 
				                                                                                       null, sMID, new String[]{pdo.getString(P_OFFICE), ServerConstants.DEFAULT_SERVER_OFFICE_NAME}) ; 
			
			    String sBusinessFlowID = null;
			    boolean bSTOPAction = ruleResults.getCompletionCode() == RuleResults.CompletionCode.STOP;
			    
          if(m_mapBusinessFlowIDtoMethod == null)
          {  
            initializeBusinessFlowIDtoMethodMap();
          }
			
			    // Valid business flow ID.
			    if(!bSTOPAction && !ruleResults.getResults().isEmpty()) 
			    { 
			      sBusinessFlowID = ruleResults.getResults().get(0).getAction();
			      
			      Object[] arrBusinessFlowIDRelatedData = m_mapBusinessFlowIDtoMethod.get(sBusinessFlowID);
			      Boolean boolImplementedByBPEL = (Boolean)arrBusinessFlowIDRelatedData[2];
			      
			      // Flow, (including save), should be implemented by BPEL.
			      if(boolImplementedByBPEL != null && boolImplementedByBPEL)
			      {
			      	pdo.set(D_BPEL_BUSINESS_FLOW_ID, sBusinessFlowID);
			      }
			      
			      // Flow should be implemented within this class, while the BPEL should stop and do nothing.
			      else
			      {
			      	FlowException raisedException = null;
			      	
			      	try
			      	{
		              //remove the orchestration context flag from the admin session data as the pdo would be persisted here 
		              admin.getSessionData(Admin.CONTEXT_ORCHESTRATION_IND, true/*bRemoveFromSessionCache*/) ; 
		
		              // Opens ExtreamScale transaction for performance.  
		              CacheServiceInterface.eINSTANCE.beginTx(CacheKeys.SystParKey, false /*bOkToJoinActiveTx*/) ;
		              
		              //invoke the getBusinessFlowMethod so as to convert the method name string into reflection method in the cache 
		              getBusinessFlowMethod(sBusinessFlowID);
				      
				      	handleValidBusinessFlowID(sMID, bSTOPAction, sBusinessFlowID, lBefore);
				      	
				        long lBeforeSave = System.nanoTime() ;
				        this.performSaveProcess(pdo);
				        pdo.set(D_BPEL_BUSINESS_FLOW_ID, RuleResults.CompletionCode.STOP.toString());
				        //System.out.println("FLOW SELECTOR SAVE ----> " + ((float)(System.nanoTime()-lBeforeSave)/GlobalConstants.NANOS_TO_MS_DIVIDER));
			      	}
			      	catch(Throwable t)
			      	{
			      		raisedException = this.onFlowFailure(t, raisedException, false/*bThrow*/, null) ;
			      	}
			      	finally
			      	{
			      		// Commits or rollback the above ExtreamScale transaction.
			      		CacheServiceInterface.eINSTANCE.closeTx(CacheKeys.SystParKey, (raisedException == null)/*bCommit*/, true /*forceClose*/) ;
			      	}
			      }
			    }
		    }
		  } 
	  }
		 
	  catch(PDOException pdoE)
	  {
	  	pdo = pdoE.getPdo();
	 
	    //ensure that in all scenarios the where the pdo exists, it shall contain the office, department and create date as a bare minimum 
	    if(pdo != null)
	    { 
	    	sMID = pdo.getMID();
	   	  BOProxies.m_setBasicPropertiesLogging.setBasicProperties(admin, sMID) ;
	
	   	  // Run the department rule in order to set it
			  pdo.set(D_RULE_TYPE_ID, RULE_TYPE_ID_DEPARTMENT);
			  BOMapPaymentInfoUsingRules.handleRuleExecutionAndMappingToPDO(sMID);
		   
		    ErrorAuditUtils.onError(ProcessErrorConstants.InvalidInputFlowTermination, feedback, new Object[]{pdo.getMID(), pdo.getString(PDOConstantFieldsInterface.P_MSG_STS)}) ; 
		    logger.error(feedback.getErrorText());   
		    this.performSaveProcess(pdo);
		    pdo.set(D_BPEL_BUSINESS_FLOW_ID, RuleResults.CompletionCode.STOP.toString());
	    }
	  }
	   
	  return feedback ;  	
  }
  
  /**
   * 
   */
  public void performFailurePaymentCompensation() throws Exception
  {
  	
  	
  	PDO pdo = Admin.getContextPDO();
  	FlowException raisedException = null;
  	
  	// Balance inquiry rollback.
//  	try
//  	{
//  		Boolean boolD_BI_UNBLOCK_EXECUTED = pdo.getBoolean(D_BI_UNBLOCK_EXECUTED);
//
//  		// The "exceptional" case:
//  		// We had message expiration, (i.e. message was sent out but was not taken from the queue and thus rollback is performed),
//  		// and thus the BOBalanceInquiry was called from the BOMemberBlocking class with 'Unblock' mode; then,
//  		// we arrived here as a result of an exception that has occured during the rollback. 
//  		// In that case, we need to perform 'Block' action to the above 'Unblock' action.
//  		if(boolD_BI_UNBLOCK_EXECUTED != null && boolD_BI_UNBLOCK_EXECUTED.booleanValue()) pdo.set(D_BI_MODE, BOBalanceInquiry.BI_MODE.Block);
//  		
//  		// The "common" case: we'll arrive here as a result of an execption that has occurred during the process, during which
//  		// block action was done, (or not, depending where the exception has occurred; before/after balance inquiry logic), and
//  		// we need to perform unblock.
//  		else pdo.set(D_BI_MODE, BOBalanceInquiry.BI_MODE.Unblock);
//  		
//			Feedback feedback = BOProxies.m_balanceInquiryLogging.handleBalanceInquiry(Admin.getContextAdmin(), pdo.getMID());
//			if(!feedback.isSuccessful()) logger.info(ServerUtils.getFeedbackString(feedback));
//  	}
//  	catch(Throwable t)
//  	{
//  		raisedException = this.onFlowFailure(t, raisedException, false/*bThrow*/, null) ;
//  	}
  	
  	// Removal from cache.
  	try
  	{
  		final Admin admin = Admin.getContextAdmin();
  		PaymentDataFactory.performFailureCompensation(admin.getContextPDOs()) ;
  	}
  	catch(Throwable t)
  	{
  		raisedException = this.onFlowFailure(t, raisedException, false/*bThrow*/, null) ;
  	}
  	
  	
  	if(raisedException != null) throw raisedException;
  }
}
