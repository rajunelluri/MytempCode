package backend.paymentprocess.businessflowselector.businessobjects;

import com.fundtech.core.security.Admin;

/**
 * internal interface for BOBusinessFlowSelector.
 */
public interface BOBusinessFlowSelectorInterface{

	
	
	/** 
	 */
	public void performSaveProcess(final Admin admin, com.fundtech.core.paymentprocess.data.PDO pdo ) throws java.lang.Throwable ;

}//EOI  