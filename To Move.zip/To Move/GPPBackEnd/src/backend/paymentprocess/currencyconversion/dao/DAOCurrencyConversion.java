package backend.paymentprocess.currencyconversion.dao;

import java.sql.Types;
import java.util.List;

import com.fundtech.core.general.StatementParameter;
import com.fundtech.core.paymentprocess.currencyconversion.MessageRatesInputData;
import com.fundtech.scl.commonTypes.ForwardContractLineType;

import backend.dataaccess.dao.DAOBasic;
import backend.paymentprocess.currencyconversion.businessobjects.BOCurrencyConversion;
import backend.paymentprocess.currencyconversion.common.CurrencyConversionConstants.ConversionType;

/**
 * Title:       DAOCurrencyConversion
 * Description: DAO object for currency conversion
 * Company:     Fundtech Israel
 * Author:      Asaf Levy
 * Date:        30/04/2008
 * @version     1.0
 */
public class DAOCurrencyConversion extends DAOBasic
{
  private static DAOCurrencyConversion m_daoCurrencyConversion = new DAOCurrencyConversion();
  
  /**
   * Private constructor. 
   */
  private DAOCurrencyConversion()
  {
  }
  
  public static DAOCurrencyConversion getInstance()
  {
  	return m_daoCurrencyConversion;
  }
  
  /**
   * Returns List of MessageRates objects for the passed input parameters.
   */
  public List<ForwardContractLineType> getMessageRates(MessageRatesInputData messageRatesInputData)
  {
    String sMID = messageRatesInputData.getMID();
    Integer iPartitionID = messageRatesInputData.getPartitionID();
    String sConversionType = messageRatesInputData.getConversionType();
    String sCurrency1 = messageRatesInputData.getCurrency1();
    String sCurrency2 = messageRatesInputData.getCurrency2();
    boolean bCrossCurrencyUsed = messageRatesInputData.isCrossCurrencyUsed();
    String sTriangulationCurrency = messageRatesInputData.getTriangulationCurrency();    
    
    // NOTE: 
    // For both used queries, the first part includes a search for records with 
    // relevant MID & conversion type but also with "illegal" currencies; i.e.
    // currencies which are not relevant to the process; if such records will be
    // found, then the forward contract flow will be stopped; see in the caller method.
    
    // In case the original conversion which was performed at the beginning of 
    // the forward contract flow was a DIRECT one, we need to look only 
    // for records which include currency 1* & currency 2.
    final String SELECT_STATEMENT_FOR_DIRECT_CONVERSION = 
                                    "SELECT * FROM MESSAGERATES WHERE MID = ? AND PARTITION_ID = ? AND CONVERSION_TYPE = ? AND (CCY1, CCY2) " +
                                    "NOT IN " +
                                    "(SELECT CCY1, CCY2 FROM MESSAGERATES WHERE MID = ? AND PARTITION_ID = ? AND CONVERSION_TYPE = ? " +
                                    "AND (CCY1 = ? AND CCY2 = ?)) " +
                                    "UNION ALL " +
                                    "SELECT * FROM MESSAGERATES WHERE MID = ? AND PARTITION_ID = ? AND CONVERSION_TYPE = ? " +
                                    "AND CCY1 = ? AND CCY2 = ?";
    
    // In case CROSS CURRENCY was performed in the original conversion which was
    // performed at the beginning of the forward contract flow, we need to look also
    // for records which include the triangulation currency as well.
    final String SELECT_STATEMENT_FOR_CROSS_CURRENCY_CONVERSION = 
                                    "SELECT * FROM MESSAGERATES WHERE MID = ?  AND PARTITION_ID = ? AND CONVERSION_TYPE = ? AND (CCY1, CCY2) " +
                                    "NOT IN " +
                                    "(SELECT CCY1, CCY2 FROM MESSAGERATES WHERE MID = ?  AND PARTITION_ID = ? AND CONVERSION_TYPE = ? " +
                                    "AND (CCY1 = ? AND CCY2 = ?) OR (CCY1 = ? AND CCY2 = ?) OR (CCY1 = ? AND CCY2 = ?)) " +
                                    "UNION ALL " +
                                    "SELECT * FROM MESSAGERATES WHERE MID = ?  AND PARTITION_ID = ? AND CONVERSION_TYPE = ? " +
                                    "AND CCY1 = ? AND CCY2 = ? " +
                                    "UNION ALL " +
                                    "SELECT * FROM MESSAGERATES WHERE MID = ?  AND PARTITION_ID = ? AND CONVERSION_TYPE = ? " +
                                    "AND CCY1 = ? AND CCY2 = ? " +
                                    "UNION ALL " +
                                    "SELECT * FROM MESSAGERATES WHERE MID = ?  AND PARTITION_ID = ? AND CONVERSION_TYPE = ? " +
                                    "AND CCY1 = ? AND CCY2 = ?";
    
    StatementParameter spMID = new StatementParameter(sMID, Types.CHAR);
    StatementParameter spPartitionID = new StatementParameter(iPartitionID, Types.INTEGER);
    
    
    
    String sFinalConversionType = sConversionType.equalsIgnoreCase(ConversionType.Debit.toString()) ? 
                                  BOCurrencyConversion.MESSAGERATES_CONVERSION_TYPE_DR : BOCurrencyConversion.MESSAGERATES_CONVERSION_TYPE_CR;
    StatementParameter spConversionType = new StatementParameter(sFinalConversionType, Types.CHAR);
    
    StatementParameter spCurrency1 = new StatementParameter(sCurrency1, Types.CHAR);
    StatementParameter spCurrency2 = new StatementParameter(sCurrency2, Types.CHAR);
    
    StatementParameter[] arrStatementParameters = null;
    
    if(bCrossCurrencyUsed)
    {
      arrStatementParameters = new StatementParameter[27];
      StatementParameter spTriangulationCurrency = new StatementParameter(sTriangulationCurrency, Types.CHAR);
    
      arrStatementParameters[0] = spMID;
      arrStatementParameters[1] = spPartitionID;
      arrStatementParameters[2] = spConversionType;
  
      arrStatementParameters[3] = spMID;
      arrStatementParameters[4] = spPartitionID;
      arrStatementParameters[5] = spConversionType;
      
      arrStatementParameters[6] = spCurrency1;
      arrStatementParameters[7] = spCurrency2;
      arrStatementParameters[8] = spCurrency1;
      arrStatementParameters[9] = spTriangulationCurrency;
      arrStatementParameters[10] = spTriangulationCurrency;
      arrStatementParameters[11] = spCurrency2;

      arrStatementParameters[12] = spMID;
      arrStatementParameters[13] = spPartitionID;
      arrStatementParameters[14] = spConversionType;
      arrStatementParameters[15] = spCurrency1;
      arrStatementParameters[16] = spCurrency2;
      
      arrStatementParameters[17] = spMID;
      arrStatementParameters[18] = spPartitionID;
      arrStatementParameters[19] = spConversionType;
      arrStatementParameters[20] = spCurrency1;
      arrStatementParameters[21] = spTriangulationCurrency;
  
      arrStatementParameters[22] = spMID;
      arrStatementParameters[23] = spPartitionID;
      arrStatementParameters[24] = spConversionType;
      arrStatementParameters[25] = spTriangulationCurrency;
      arrStatementParameters[26] = spCurrency2;
    }
    
    else
    {
      arrStatementParameters = new StatementParameter[13];
    
      arrStatementParameters[0] = spMID;
      arrStatementParameters[1] = spPartitionID;
      arrStatementParameters[2] = spConversionType;
      
      arrStatementParameters[3] = spMID;
      arrStatementParameters[4] = spPartitionID;
      arrStatementParameters[5] = spConversionType;
      arrStatementParameters[6] = spCurrency1;
      arrStatementParameters[7] = spCurrency2;

      arrStatementParameters[8] = spMID;
      arrStatementParameters[9] = spPartitionID;
      arrStatementParameters[10] = spConversionType;
      arrStatementParameters[11] = spCurrency1;
      arrStatementParameters[12] = spCurrency2;
      
    }
    
    return getXmlObjectDataRows(bCrossCurrencyUsed ? SELECT_STATEMENT_FOR_CROSS_CURRENCY_CONVERSION : SELECT_STATEMENT_FOR_DIRECT_CONVERSION, 
                                ForwardContractLineType.class, 0, arrStatementParameters);
  }
}