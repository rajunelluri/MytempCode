package backend.paymentprocess.currencyconversion.common;


/**
 * Title:       CurrencyConversionConstants
 * Description: Class for holding currency conversion constants
 * Company:     Fundtech Israel
 * Author:      Asaf Levy
 * Date:        30/04/2008
 * @version     1.0
 */
public class CurrencyConversionConstants
{
  // Conversion types.
  public enum ConversionType
  {
    Base,Debit,Credit,Mid;
    
    public String toString() 
    {
      return name();
    }
  };
  
  // Action types.
  public enum ActionType
  {
    Buy,Sell,Mid;
  };
}