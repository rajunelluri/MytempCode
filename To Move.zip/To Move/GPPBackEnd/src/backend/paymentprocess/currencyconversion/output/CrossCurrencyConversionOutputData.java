package backend.paymentprocess.currencyconversion.output;

import com.fundtech.cache.entities.ExchrateCfg;
import com.fundtech.core.paymentprocess.errorhandling.ProcessErrorHolder;

import backend.paymentprocess.currencyconversion.input.CrossCurrencyConversionInputData;
import backend.paymentprocess.currencyconversion.input.CurrencyConversionInputData;
import backend.util.ServerConstants;

/**
 * Title:       CrossCurrencyConversionOutputData
 * Description: Class for cross currency conversion output data
 * Company:     Fundtech Israel
 * Author:      Asaf Levy
 * Date:        30/04/2008
 * @version     1.0
 */
public class CrossCurrencyConversionOutputData extends CurrencyConversionOutputData
{
  // This memebr will be set and will hold a valid value, when we perform cross
  // currency conversion after failure of exchange rate calculation in which 
  // EXCHRATE_CFG record was found, but EXCHRATE_BU record wasn't found.
  // In that case, we keep the EXCHRATE_CFG object between the 2 original currencies;
  // see its use during the forward contract flow.
  private ExchrateCfg m_ExchrateCfgForOriginalCurrenciesPair;
  
  /**
   * Empty constructor.
   */
  public CrossCurrencyConversionOutputData()
  {
    setCrossCurrencyUsed(true);
  }

  public final ExchrateCfg getExchrateCfgForOriginalCurrenciesPair()
  {
    return m_ExchrateCfgForOriginalCurrenciesPair;
  }
  
  public final void setExchrateCfgForOriginalCurrenciesPair(ExchrateCfg ExchrateCfgForOriginalCurrenciesPair) 
  {
    m_ExchrateCfgForOriginalCurrenciesPair = ExchrateCfgForOriginalCurrenciesPair;
  }

  public String toString() 
  {
    StringBuilder sb = new StringBuilder(super.toString());
    
    final String STEP_2 = "Step 2 ";
    sb.append(ServerConstants.NEWLINE).append(STEP_2).append(getExchangeRateOutputDataStep2());
    
    return sb.toString();
  }
}