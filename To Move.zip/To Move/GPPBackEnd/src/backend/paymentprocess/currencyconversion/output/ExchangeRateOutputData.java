package backend.paymentprocess.currencyconversion.output;

import com.fundtech.cache.entities.ExchrateBu;
import com.fundtech.cache.entities.ExchrateCfg;

import backend.paymentprocess.output.PaymentProcessOutputData;

/**
 * Title:       ExchangeRateOutputData
 * Description: Class for exchange rate output data
 * Company:     Fundtech Israel
 * Author:      Asaf Levy
 * Date:        30/04/2008
 * @version     1.0
 */
public class ExchangeRateOutputData extends PaymentProcessOutputData
{
  // These 2 members are used as a pair for DIRECT conversion.
  private ExchrateCfg m_exchrateCfg;
  private ExchrateBu m_exchrateBu;
  
  private boolean m_bDirectConversion;
  private Double m_dRate;
  private Double m_dMidRate;
  private Double m_dSpread;
  private int m_iCurrency1Units;
  private int m_iCurrency2Units;
  private boolean m_bValidExchangeRateData = true;
  
  private static final String EXCHANGE_RATE_OUTPUT_DATA = 
          "Exchange rate output data:" +
          "\n         Direct conversion = %s \n " +
          "\n         Rate = %s \n         Mid rate = %s " +
          "\n         Spread = %s \n         Currency 1 units = %s " +
          "\n         Currency 2 units = %s \n         Return code = %s";

  public ExchangeRateOutputData()
  {
    super();
  }

  public ExchrateCfg getExchrateCfg()
  {
    return m_exchrateCfg;
  }
  
  public void setExchrateCfg(ExchrateCfg exchrateCfg)
  {
    m_exchrateCfg = exchrateCfg;
  }
  
  public ExchrateBu getExchrateBu()
  {
    return m_exchrateBu;
  }
  
  public void setExchrateBu(ExchrateBu exchrateBu)
  {
    m_exchrateBu = exchrateBu;
  }

  public boolean isDirectConversion()
  {
  	return m_bDirectConversion;
  }
  
  public void setDirectConversion(boolean bDirectConversion)
  {
  	m_bDirectConversion = bDirectConversion;
  }
  
  public Double getRate()
  {
    return m_dRate;
  }
  
  public void setRate(Double dRate)
  {
    m_dRate = dRate;
  }

  public int getCurrency1Units()
  {
  	return m_iCurrency1Units;
  }
  
  public void setCurrency1Units(int iCurrency1Units)
  {
  	m_iCurrency1Units = iCurrency1Units;
  }
  
  public int getCurrency2Units()
  {
    return m_iCurrency2Units;
  }
  
  public void setCurrency2Units(int iCurrency2Units)
  {
    m_iCurrency2Units = iCurrency2Units;
  }

  public Double getMidRate()
  {
  	return m_dMidRate;
  }
  
  public void setMidRate(Double dMidRate)
  {
  	m_dMidRate = dMidRate;
  }
  
  public Double getSpread()
  {
  	return m_dSpread;
  }
  
  public void setSpread(Double dSpread)
  {
  	m_dSpread = dSpread;
  }
  
  public boolean isValidExchangeRateData()
  {
    return m_bValidExchangeRateData;
  }
  
  public void setValidExchangeRateData(boolean bValidExchangeRateData)
  {
    m_bValidExchangeRateData = bValidExchangeRateData;
  }
  
  public String toString()
  {
    StringBuilder sb = new StringBuilder();
    
    Object[] arrExchangeRateOutputData = new Object[]{m_bDirectConversion, m_dRate, m_dMidRate, 
                                                      m_dSpread, m_iCurrency1Units, m_iCurrency2Units, m_bValidExchangeRateData};
    
    sb.append(String.format(EXCHANGE_RATE_OUTPUT_DATA, arrExchangeRateOutputData));
    
    return sb.toString();
  }
}