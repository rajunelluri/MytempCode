package backend.paymentprocess.currencyconversion.output;

import java.util.ArrayList;
import java.util.List;

import com.fundtech.scl.commonTypes.ForwardContractLineType;

import backend.util.ServerConstants;

/**
 * Title:       ForwardContractDealerRateOutputData
 * Description: Class for forward contract & dealer rate output data
 * Company:     Fundtech Israel
 * Author:      Asaf Levy
 * Date:        30/04/2008
 * @version     1.0
 */
public class ForwardContractDealerRateOutputData extends CurrencyConversionOutputData
{
  private List<ForwardContractLineType> m_listMessageRates;
  
  // Stands for how many residual records were added during the forward contract
  // process, which has resulted in the creation of this ForwardContractDealerRateOutputData
  // instance.
  private int m_iNumOfAddedResidualRecords;
  
  /**
   * Empty constructor.
   */
  public ForwardContractDealerRateOutputData()
  {
    super();
    m_listMessageRates = new ArrayList<ForwardContractLineType>();
  }

  public List<ForwardContractLineType> getMessageRates()
  {
  	return m_listMessageRates;
  }
  
  public void increaseNumOfAddedResidualRecords()
  {
  	m_iNumOfAddedResidualRecords++;
  }
  
  public int getNumOfAddedResidualRecords()
  {
    return m_iNumOfAddedResidualRecords;
  }
  
  public void setMessageRates(List<ForwardContractLineType> listMessageRates)
  {
    m_listMessageRates = listMessageRates;
  }

  public String toString()
  {
    final String STEP_2 = "Step 2 ";
    final String RESIDUAL_RECORDS_NUMBER = "\n\nNumber of added RESIDUAL records: ";
    final String MESSAGE_RATES_DATA_PREFIX = "\nMessage Rates:\n";
    
    StringBuilder sb = new StringBuilder(super.toString());
    
    if(m_bCrossCurrencyUsed)
    {
      sb.append(ServerConstants.NEWLINE).append(STEP_2).append(m_exchangeRateOutputDataStep2);
    }
    
    sb.append(RESIDUAL_RECORDS_NUMBER).append(m_iNumOfAddedResidualRecords);
    
    // Handles the MessageRates objects.
    List<ForwardContractLineType> listMessageRates = m_listMessageRates;
    sb.append(MESSAGE_RATES_DATA_PREFIX);
    for(ForwardContractLineType fcLine : listMessageRates)
    {
      sb.append(getForwardContractLineData(fcLine)).append(ServerConstants.NEWLINE);
    }
    
    return sb.toString();
  }
  
  /**
   * Returns string representation for the passed ForwardContractLineType parameter.
   */
  private String getForwardContractLineData(ForwardContractLineType fcLine)
  {
    final String MESSAGE_RATES = 
        "MESSAGERATES data: MID = %s, Conversion type = %s, Currency 1 = %s, Currency 2 = %s" +
        "\n                   Amount = %s, Rate = %s, Forward contract flag = %s, Contract = %s" +
        "\n                   Spread = %s, Manual spread = %s";
    
    final String MESSAGE_FOR_RESIDUAL_AMOUNT_CONVERSION = "\n                   Residual amount conversion message = %s";
        
    StringBuilder sb = new StringBuilder(String.format(MESSAGE_RATES, fcLine.getFFCMID(), fcLine.getFFCCONVERSIONTYPE(), 
            fcLine.getFFCCURRENCY1(), fcLine.getFFCCURRENCY2(), fcLine.getFFCAMOUNT(), 
            fcLine.getFFCRATE(), fcLine.getFFCFORWARDCONTRACT(), fcLine.getFFCCONTRACT(), 
            fcLine.getFFCSPREAD(), fcLine.getFFCMANUALSPREAD()));
    
    // If this is a residual line, then it has a non-empty 'message for residual amount conversion',
    // which was added during the 'BOCurrencuConversion.handleOneStepMessageRatesRecords' method.
    String sMessageForResidualAmountConversion = fcLine.getMessageResidualAmountAfterConversion();
    if(sMessageForResidualAmountConversion != null)
    {
      sb.append(String.format(MESSAGE_FOR_RESIDUAL_AMOUNT_CONVERSION, sMessageForResidualAmountConversion));
    }
    
    return sb.toString();
  }
}