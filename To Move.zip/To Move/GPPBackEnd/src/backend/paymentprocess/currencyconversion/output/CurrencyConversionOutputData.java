package backend.paymentprocess.currencyconversion.output;

import com.fundtech.core.paymentprocess.errorhandling.ProcessErrorHolder;

import backend.paymentprocess.output.PaymentProcessOutputData;
import backend.util.ServerConstants;

/**
 * Title:       CurrencyConversionOutputData
 * Description: Class for currency conversion output data
 * Company:     Fundtech Israel
 * Author:      Asaf Levy
 * Date:        30/04/2008
 * @version     1.0
 */
public class CurrencyConversionOutputData extends PaymentProcessOutputData
{
  // - When DIRECT conversion is used with no cross currency, this member will be set
  // with the ExchangeRateOutputData object for the original currencies pair.
  // - When CROSS CURRENCY is performed, this member will be set with the
  // ExchangeRateOutputData object of step 1; see 'BOCurrencyConversion.performCrossCurrency'.
  private ExchangeRateOutputData m_exchangeRateOutputData;
  
  // - When DIRECT conversion is used with no cross currency, this member remains null.
  // - When CROSS CURRENCY is performed, this member will be set with the
  // ExchangeRateOutputData object of step 2; see 'BOCurrencyConversion.performCrossCurrency'.
  protected ExchangeRateOutputData m_exchangeRateOutputDataStep2;
  
  private Double m_dConvertedAmount;
  private Double m_dRate;
  private int m_iRateAccuracy;
  protected boolean m_bCrossCurrencyUsed;
  
  // Will be initialized only during cross currency flow.
  private Double m_dConvertedAmountStep1;
  private Double m_dRateStep1;
  private String m_sTriangulationCurrency;
  
  private Double m_dEquivalentAmount;
  
  private static final String CURRENCY_CONVERSION_OUTPUT_DATA = 
          "Currency conversion output data - " +
          "\n         Converted amount: %s \n         Rate: %s" +
          "\n         Rate accuracy: %s \n         Cross currency used: %s" +
          "\n         Converted amount step 1: %s \n         Rate step 1: %s" +
          "\n         Triangulation currency: %s \n         Equivalent amount: %s " +
          "\n         Process has completed: %s";
  
  /**
   * Empty constructor.
   */
  public CurrencyConversionOutputData()
  {
    super();
  }
  
  /**
   * Constructor.
   */
  public CurrencyConversionOutputData(CurrencyConversionOutputData ccOutputData)
  {
    m_dConvertedAmount = ccOutputData.getConvertedAmount();
    m_dRate = ccOutputData.getRate();
    m_iRateAccuracy = ccOutputData.getRateAccuracy();
    m_bCrossCurrencyUsed = ccOutputData.isCrossCurrencyUsed();
    m_dConvertedAmountStep1 = ccOutputData.getConvertedAmountStep1();
    m_dRateStep1 = ccOutputData.getRateStep1();
    m_sTriangulationCurrency = ccOutputData.getTriangulationCurrency();
    m_dEquivalentAmount = ccOutputData.getEquivalentAmount();
    m_exchangeRateOutputData = ccOutputData.m_exchangeRateOutputData;
    m_exchangeRateOutputDataStep2 = ccOutputData.getExchangeRateOutputDataStep2();
  }
  
  public ExchangeRateOutputData getExchangeRateOutputData()
  {
    return m_exchangeRateOutputData;
  }
  
  public void setExchangeRateOutputData(ExchangeRateOutputData exchangeRateOutputData)
  {
    m_exchangeRateOutputData = exchangeRateOutputData;
  }
  
  public ExchangeRateOutputData getExchangeRateOutputDataStep2() 
  {
    return m_exchangeRateOutputDataStep2;
  }
  
  public void setExchangeRateOutputDataStep2(ExchangeRateOutputData exchangeRateOutputDataStep2)
  {
    m_exchangeRateOutputDataStep2 = exchangeRateOutputDataStep2;
  }
  
  public Double getConvertedAmount()
  {
    return m_dConvertedAmount;
  }
  
  public void setConvertedAmount(Double dConvertedAmount)
  {
    m_dConvertedAmount = dConvertedAmount;
  }

  public Double getRate()
  {
    return m_dRate;
  }
  
  public void setRate(Double dRate)
  {
    m_dRate = dRate;
  }
  
  public boolean isCrossCurrencyUsed()
  {
  	return m_bCrossCurrencyUsed;
  }
  
  public void setCrossCurrencyUsed(boolean bCrossCurrencyUsed)
  {
  	m_bCrossCurrencyUsed = bCrossCurrencyUsed;
  }
  
  public int getRateAccuracy()
  {
  	return m_iRateAccuracy;
  }
  
  public void setRateAccuracy(int iRateAccuracy)
  {
  	m_iRateAccuracy = iRateAccuracy;
  }
  
  public Double getEquivalentAmount()
  {
  	return m_dEquivalentAmount;
  }
  
  public void setEquivalentAmount(Double dEquivalentAmount)
  {
  	m_dEquivalentAmount = dEquivalentAmount;
  }
  
  public Double getConvertedAmountStep1()
  {
  	return m_dConvertedAmountStep1;
  }
  
  public void setConvertedAmountStep1(Double dConvertedAmountStep1)
  {
  	m_dConvertedAmountStep1 = dConvertedAmountStep1;
  }
  
  public Double getRateStep1()
  {
  	return m_dRateStep1;
  }
  
  public void setRateStep1(Double dRateStep1)
  {
  	m_dRateStep1 = dRateStep1;
  }
  
  public String getTriangulationCurrency()
  {
    return m_sTriangulationCurrency;
  }
  
  public void setTriangulationCurrency(String sTriangulationCurrency)
  {
    m_sTriangulationCurrency = sTriangulationCurrency;
  }
  
  public String toString()
  {
    StringBuilder sb = new StringBuilder();
    
    Object[] arrCurrencyConversionOutputData = new Object[]{m_dConvertedAmount, m_dRate, m_iRateAccuracy,
                                                            m_bCrossCurrencyUsed, m_dConvertedAmountStep1, m_dRateStep1,
                                                            m_sTriangulationCurrency, m_dEquivalentAmount, m_bProcessHasCompleted};
    sb.append(String.format(CURRENCY_CONVERSION_OUTPUT_DATA, arrCurrencyConversionOutputData));

    final String NULL_EXCHANGE_RATE_OUTPUT_DATA = "Exchange rate output data: null";
    sb.append(ServerConstants.NEWLINE).append(ServerConstants.NEWLINE)
                                      .append(m_exchangeRateOutputData != null ?  
                                              m_exchangeRateOutputData.toString() :
                                              NULL_EXCHANGE_RATE_OUTPUT_DATA);
    
    ProcessErrorHolder processErrorHolder = getProcessErrorHolder();
    if(!processErrorHolder.isEmpty())
    {
      sb.append(ServerConstants.NEWLINE);
      sb.append(processErrorHolder);
    }
    return sb.toString();
  }
}