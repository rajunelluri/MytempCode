package backend.paymentprocess.currencyconversion.ejbinterfaces;

import javax.ejb.Remote;

import com.fundtech.core.security.Admin;

/**
 * Remote interface for CurrencyConversion.
 */
@Remote
public interface CurrencyConversion{

	public static final String REMOTE_JNDI_NAME="ejb/CurrencyConversionBean";
	
	
	/** 
	 * Performs currency conversion according to the passed conversion type
	 * input parameter and according to the related PDO object.
	 * It will analyze the values within the PDO and will perform a call to the right
	 * conversion method.
	 * This is the method which will be exposed to the business flow, which will
	 * call 3 times for base, credit & debit, ('Mid' conversion type shouldn't be used
	 * in that case).
	 * @param sConversionType one of the following 3 options: Base, Credit & Debit,
	 * where 'Mid' conversion type shouldn't be used in that case
	 */
	public com.fundtech.datacomponent.response.Feedback performCurrencyConversion(final Admin admin, java.lang.String sMID ) throws backend.paymentprocess.currencyconversion.exception.CurrencyConversionException;
	
	/**
	 * Perform simple conversion based on minimal parameter and use STANDARD rate for this.
	 */
	public java.lang.Double simpleAmountConversion(java.lang.Double origAmount, java.lang.String office, java.lang.String ccy1, java.lang.String ccy2) throws backend.paymentprocess.currencyconversion.exception.CurrencyConversionException;
	

}//EOI  