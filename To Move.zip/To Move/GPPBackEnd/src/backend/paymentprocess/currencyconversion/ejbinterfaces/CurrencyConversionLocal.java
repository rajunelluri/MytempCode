package backend.paymentprocess.currencyconversion.ejbinterfaces;

import javax.ejb.Local;

/**
 * Local interface for CurrencyConversion.
 */
@Local
public interface CurrencyConversionLocal extends CurrencyConversion{} ; 