package backend.paymentprocess.currencyconversion.input;

import com.fundtech.cache.entities.ExchrateCfg;

/**
 * Title:       CrossCurrencyConversionInputData
 * Description: Class for cross currency conversion input data
 * Company:     Fundtech Israel
 * Author:      Asaf Levy
 * Date:        30/04/2008
 * @version     1.0
 */
public class CrossCurrencyConversionInputData extends CurrencyConversionInputData
{
  // This memebr will be set and will hold a valid value, when we perform cross
  // currency conversion after failure of exchange rate calculation in which 
  // EXCHRATE_CFG record was found, but EXCHRATE_BU record wasn't found.
  private ExchrateCfg m_ExchrateCfg;
  
  /**
   * Constructor.
   */
  public CrossCurrencyConversionInputData(CurrencyConversionInputData ccInputData)
  {
  	super(ccInputData);
  	
    if(ccInputData instanceof CrossCurrencyConversionInputData)
    {
      m_ExchrateCfg = ((CrossCurrencyConversionInputData)ccInputData).getExchrateCfg();
    }
  }
  
  public final ExchrateCfg getExchrateCfg()
  {
  	return m_ExchrateCfg;
  }
  
  public final void setExchrateCfg(ExchrateCfg exchrateCfg) 
  {
  	m_ExchrateCfg = exchrateCfg;
  }
  
  public String toString() 
  {
    final String EXCHRATE_CFG = "\nExchrateCfg = ";
    
    StringBuilder sb = new StringBuilder(super.toString());
    
    sb.append(EXCHRATE_CFG).append(m_ExchrateCfg);
    
    return sb.toString();
  }
}