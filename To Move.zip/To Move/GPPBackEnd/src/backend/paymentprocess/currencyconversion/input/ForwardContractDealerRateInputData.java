package backend.paymentprocess.currencyconversion.input;

import java.util.ArrayList;
import java.util.List;

import com.fundtech.scl.commonTypes.ForwardContractLineType;

/**
 * Title:       ForwardContractDealerRateInputData
 * Description: Class for forward contract & dealer rate input data
 * Company:     Fundtech Israel
 * Author:      Asaf Levy
 * Date:        30/04/2008
 * @version     1.0
 */
public class ForwardContractDealerRateInputData extends CurrencyConversionInputData
{
  private List<ForwardContractLineType> m_listMessageRates;
  
  /**
   * Empty constructor.
   */
  public ForwardContractDealerRateInputData() 
  {
  }

  public ForwardContractDealerRateInputData(CurrencyConversionInputData ccInputData) 
  {
    super(ccInputData);
    m_listMessageRates = new ArrayList<ForwardContractLineType>();
  }

  public final List<ForwardContractLineType> getMessageRates() 
  {
  	return m_listMessageRates;
  }
  
  public final void setMessageRates(List<ForwardContractLineType> listMessageRates) 
  {
  	m_listMessageRates = listMessageRates;
  }
}