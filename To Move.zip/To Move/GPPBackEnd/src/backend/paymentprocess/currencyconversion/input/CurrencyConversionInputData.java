package backend.paymentprocess.currencyconversion.input;

import com.fundtech.cache.entities.RateUsage;

import backend.paymentprocess.currencyconversion.common.CurrencyConversionConstants.ConversionType;

/**
 * Title:       CurrencyConversionInputData
 * Description: Class for currency conversion input data
 * Company:     Fundtech Israel
 * Author:      Asaf Levy
 * Date:        30/04/2008
 * @version     1.0
 */
public class CurrencyConversionInputData
{
  private ConversionType m_conversionType;
  private String m_sCurrency1;
  private String m_sCurrency2;
  private String m_sOffice; 
  private Double m_dAmountToConvert;
  private boolean m_bCalculateEquivalentAmount;
  private boolean m_bPerformValidations = true;
  private boolean m_bPerformThresholdValidation = true;
  private boolean m_isToAdjustPrecision = true;

  // Setting this flag to true. 
  // It will be used in the 'BOCurrencyConversion.calculateExchangeRate' method.
  // When this object will be created for cross currency, then a different value
  // will be used for the process, (see the 'BOCurrencyConversion.performCrossCurrency'
  // method).
  private boolean m_bApplySpread = true;

  // Holds the RateUsage JPA for either the CREDIT customer or the DEBIT customer;
  // the decision which is the one to set is done outside this class. 
  private RateUsage m_rateUsage;
  
  // Holds the RateUsage JPA for the office.
  // Will be used when the conversion type is 'Base'.
  private RateUsage m_baseRateUsage;
  
  // Determines whether to use the 'm_baseRateUsage' in case the 'm_rateUsage' is null.
  private boolean m_bUseBaseRateUsageAsFailover;
  
  // Stands for whether this object is created/used from the 'BOCurrencyConversion.validateThreshold'
  // method.
  private boolean m_bForThresholdValidation;
  
  // Stands for whether we need to skip the currency conversion process.
  // Will be set to true in case the 2 currencies are the same; in that case,
  // all process will be skipped, and only mapping of original amounts will be 
  // done into the right fields in the PDO, (see the 
  //'BOCurrencyConversion.mapCurrencyConversionOutputIntoPDO' method).
  private boolean m_bShouldSkipCurrencyConversion;
  
  // These 2 amounts are relevant only if 'm_bSkipCurrencyConversion' is set to true,
  // (which is done in the constructor); they will be set in the 
  // 'BOCurrencyConversion.getCurrencyConversionInputData' method.
  private Double m_dOriginalSettlementAmount;
  private Double m_dOriginalDebitAmount;
  
  // These are always being initilized.
  // - When cross currency is NOT used, then 'm_sOriginalCurrency1' ALWAYS equals 'm_sCurrency1'
  //   and 'm_sOriginalCurrency2' ALWAYS equals 'm_sCurrency2'.
  // - When cross currency IS used, then for the conversion between currency 1 to triangulation currency,
  //   currency 2 will hold the triangulation currency, (i.e. it will be different then 'm_sOriginalCurrency2'),
  //   and for the conversion between triangulation currency to currency 2, currency 1 will hold the triangulation 
  //   currency, (i.e. it will be different then 'm_sOriginalCurrency1).
  private String m_sOriginalCurrency1;
  private String m_sOriginalCurrency2;
  
  private static final String CURRENCY_CONVERSION_INPUT_DATA = 
          "Currency Conversion Input Data: Conversion type = %s, Rate usage = %s, Base rate usage = %s, " +
          "Currency 1 = %s, Currency 2 = %s, Original currency 1 = %s, Original currency 2 = %s, "+
          "Office = %s, Amount to convert = %s, " +
          "Calculate equivalent amount = %s, Perform validations = %s, Perform thershold validation: %s, Apply spread = %s, Use base rate usage as failover = %s.";
  
  /**
   * Empty constructor.
   */
  public CurrencyConversionInputData()
  {
  }

  /**
   * Constructor.
   */
  public CurrencyConversionInputData(String sOffice, Double dAmountToConvert, 
                                     String sCurrency1, String sCurrency2)
  {
    m_sOffice = sOffice;
    m_dAmountToConvert = dAmountToConvert;
    m_sCurrency1 = sCurrency1;
    m_sCurrency2 = sCurrency2;
    m_bShouldSkipCurrencyConversion = (sCurrency1 != null) ?sCurrency1.equals(sCurrency2): false;
    m_sOriginalCurrency1 = sCurrency1;
    m_sOriginalCurrency2 = sCurrency2;
  }
  
  /**
   * Constructor.
   */
  public CurrencyConversionInputData(String sConversionType, String sOffice, Double dAmountToConvert, 
                                     String sCurrency1, String sCurrency2)
  {
    this(sOffice, dAmountToConvert, sCurrency1, sCurrency2);
    m_conversionType = ConversionType.valueOf(sConversionType);
  }

  /**
   * Constructor.
   */
  public CurrencyConversionInputData(CurrencyConversionInputData ccInputData)
  {
    this(ccInputData.getOffice(), ccInputData.getAmountToConvert(), ccInputData.getCurrency1(), ccInputData.getCurrency2());
    
    setConversionType(ccInputData.getConversionType());
    setCalculateEquivalentAmount(ccInputData.calculateEquivalentAmount());
    setPerformValidations(shouldPerformValidations());
    setApplySpread(ccInputData.getApplySpread());
    setRateUsage(ccInputData.getRateUsageWithNoFailover());
    setBaseRateUsage(ccInputData.getBaseRateUsage());
    setUseBaseRateUsageAsFailover(ccInputData.useBaseRateUsageAsFailover());
    setOriginalSettlementAmount(ccInputData.getOriginalSettlementAmount());
  }
  
  public final ConversionType getConversionType() 
  {
    return m_conversionType;
  }
  
  public final void setConversionType(ConversionType conversionType)
  {
    m_conversionType = conversionType;
  }
  
  /**
   * Called from this class' constructor.
   * Returns the CREDIT or DEBIT RateUsage class member; returned value can be null.
   */
  public final RateUsage getRateUsageWithNoFailover()
  {
    return m_rateUsage;
  }

  /**
   * Returns the CREDIT or DEBIT RateUsage class member while considering the 'm_bUseBaseRateUsageAsFailover'
   * class member.
   */
  public final RateUsage getRateUsage()
  {
    RateUsage rateUsage = null;
    
    // If CREDIT or DEBIT rate usage was set, returns it.
    if(m_rateUsage != null)
    {
      rateUsage = m_rateUsage;
    }
    
    // CREDIT or DEBIT rate usage wasn't set and 'm_bUseBaseRateUsageAsFailover' is true;
    // returns the BASE rate usage.
    else if(m_bUseBaseRateUsageAsFailover)
    {
      rateUsage = m_baseRateUsage; 
    }
    
    return rateUsage;
  }

  public final void setRateUsage(RateUsage rateUsage)
  {
    m_rateUsage = rateUsage;
  }
  
  public final RateUsage getBaseRateUsage()
  {
    return m_baseRateUsage;
  }
  
  public final void setBaseRateUsage(RateUsage baseRateUsage)
  {
    m_baseRateUsage = baseRateUsage;
  }
  
  public final String getCurrency1()
  {
    return m_sCurrency1;
  }

  public final void setCurrency1(String sCurrency1)
  {
    m_sCurrency1 = sCurrency1;
  }

  public final String getCurrency2() 
  {
    return m_sCurrency2;
  }
  
  public final void setCurrency2(String sCurrency2)
  {
    m_sCurrency2 = sCurrency2;
  }
  
  public final String getOffice()
  {
    return m_sOffice;
  }
  
  public final void setOffice(String sOffice)
  {
    m_sOffice = sOffice;
  }
  
  public final Double getAmountToConvert() 
  {
    return m_dAmountToConvert;
  }
  
  public final void setAmountToConvert(Double dAmountToConvert)
  {
    m_dAmountToConvert = dAmountToConvert;
  }
  
  public final Double getOriginalSettlementAmount() 
  {
    return m_dOriginalSettlementAmount;
  }
  
  public final void setOriginalSettlementAmount(Double dOriginalSettlementAmount)
  {
    m_dOriginalSettlementAmount = dOriginalSettlementAmount;
  }

  public final Double getOriginalDebitAmount() 
  {
    return m_dOriginalDebitAmount;
  }
  
  public final void setOriginalDebitAmount(Double dOriginalDebitAmount)
  {
    m_dOriginalDebitAmount = dOriginalDebitAmount;
  }
  
  public final boolean calculateEquivalentAmount()
  {
    return m_bCalculateEquivalentAmount;
  }
  
  public final void setCalculateEquivalentAmount(boolean bCalculateEquivalentAmount) 
  {
    m_bCalculateEquivalentAmount = bCalculateEquivalentAmount;
  }
  
  public final boolean shouldPerformValidations()
  {
    return m_bPerformValidations;
  }
  
  public final void setPerformValidations(boolean bPerformValidations)
  {
    m_bPerformValidations = bPerformValidations;
  }
  
  public final boolean shouldPerformThresholdValidation()
  {
    return m_bPerformThresholdValidation;
  }
  
  public final void setPerformThresholdValidation(boolean bPerformThresholdValidation)
  {
  	m_bPerformThresholdValidation = bPerformThresholdValidation;
  }
  
  public final boolean shouldSkipCurrencyConversion()
  {
    return m_bShouldSkipCurrencyConversion;
  }

  public final void setShouldSkipCurrencyConversion()
  {
  	m_bShouldSkipCurrencyConversion = m_sCurrency1.equals(m_sCurrency2);
  }

  public final boolean getApplySpread() 
  {
  	return m_bApplySpread;
  }
  
  public final void setApplySpread(boolean bApplySpread) 
  {
  	m_bApplySpread = bApplySpread;
  }
  
  public final boolean isForThresholdValidation() 
  {
    return m_bForThresholdValidation;
  }
  
  public final void setIsForThresholdValidation(boolean bForThresholdValidation) 
  {
    m_bForThresholdValidation = bForThresholdValidation;
  }
  
  public final boolean useBaseRateUsageAsFailover() 
  {
    return m_bUseBaseRateUsageAsFailover;
  }
  
  public final void setUseBaseRateUsageAsFailover(boolean bUseBaseRateUsageAsFailover) 
  {
    m_bUseBaseRateUsageAsFailover = bUseBaseRateUsageAsFailover;
  }
  
  public boolean isToAdjustPrecision()
  {
    return m_isToAdjustPrecision;
  }

  public void setIsToAdjustPrecision(boolean toAdjustPrecision)
  {
    m_isToAdjustPrecision = toAdjustPrecision;
  }
  
  public final String getOriginalCurrency1()
  {
    return m_sOriginalCurrency1;
  }

  public final String getOriginalCurrency2()
  {
    return m_sOriginalCurrency2;
  }
  
  /*
   * Return lexicographical ordered concatenation of the two currencies.
   */
  public final String getOrderedCurrencyPair()
  {
    // NOTE: Don't keep a permanent class member for the ordered currency pair,
    //       as during the currency conversion flow, the used CurrencyConversionInputData,
    //       (i.e. this class), is sometimes being re-used while being upadted 
    //       with temporary currencies, (e.g. during 'BOCurrencyConversion.performCrossCurrency').
  	return m_sCurrency1.compareTo(m_sCurrency2) < 0 ? m_sCurrency1 + m_sCurrency2 :
                                                      m_sCurrency2 + m_sCurrency1;
  }
  
  public String toString()
  {
    StringBuilder sb = new StringBuilder();
    
    Object[] arrCurrencyConversionOutputData = 
                          new Object[]{m_conversionType, m_rateUsage, m_baseRateUsage,
                                       m_sCurrency1, m_sCurrency2, m_sOriginalCurrency1, m_sOriginalCurrency2, m_sOffice, m_dAmountToConvert,
                                       m_bCalculateEquivalentAmount, m_bPerformValidations, m_bPerformThresholdValidation, m_bApplySpread, m_bUseBaseRateUsageAsFailover};
    sb.append(String.format(CURRENCY_CONVERSION_INPUT_DATA, arrCurrencyConversionOutputData));
    
    return sb.toString();
  }
}