package backend.paymentprocess.currencyconversion.exception;

import com.fundtech.core.paymentprocess.errorhandling.BusinessException;

/**
 * Title:       CurrencyConversionException
 * Description: Class for all currency conversion exceptions
 * Company:     Fundtech Israel
 * Author:      Asaf Levy
 * Date:        30/04/2008
 * @version     1.0
 */
public class CurrencyConversionException extends BusinessException
{
  private static final long serialVersionUID = -463673756708464723L;
  
  public CurrencyConversionException()
  {
    super();
  }

  public CurrencyConversionException(String string, Throwable e)
  {
    super(string, e);
  }

  public CurrencyConversionException(final int iErrorCode)
  {
    super(iErrorCode);
  }

  public CurrencyConversionException(String sErrorDescription)
  {
    super(sErrorDescription);
  }
}
