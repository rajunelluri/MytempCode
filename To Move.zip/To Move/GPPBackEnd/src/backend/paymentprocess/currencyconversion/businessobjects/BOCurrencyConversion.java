package backend.paymentprocess.currencyconversion.businessobjects;

import static com.fundtech.util.GlobalUtils.isListNullOrEmpty;
import static com.fundtech.util.GlobalUtils.isNullOrEmpty;
import static com.fundtech.util.GlobalUtils.nullNumberOrZero;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.businessobject.BOBasic;
import backend.businessobject.proxies.BOProxy;
import backend.businessobject.proxies.LoadPDO;
import backend.core.module.MessageConstantsInterface;
import backend.paymentprocess.commons.MessageUtils;
import backend.paymentprocess.currencyconversion.common.CurrencyConversionConstants.ActionType;
import backend.paymentprocess.currencyconversion.common.CurrencyConversionConstants.ConversionType;
import backend.paymentprocess.currencyconversion.exception.CurrencyConversionException;
import backend.paymentprocess.currencyconversion.input.CrossCurrencyConversionInputData;
import backend.paymentprocess.currencyconversion.input.CurrencyConversionInputData;
import backend.paymentprocess.currencyconversion.input.ForwardContractDealerRateInputData;
import backend.paymentprocess.currencyconversion.output.CrossCurrencyConversionOutputData;
import backend.paymentprocess.currencyconversion.output.CurrencyConversionOutputData;
import backend.paymentprocess.currencyconversion.output.ExchangeRateOutputData;
import backend.paymentprocess.currencyconversion.output.ForwardContractDealerRateOutputData;
import backend.paymentprocess.erroraudit.ErrorAuditUtils;
import backend.paymentprocess.rtr.businessobjects.BORTR;
import backend.paymentprocess.ruleexecution.businessobjects.BORuleExecution;
import backend.paymentprocess.ruleexecution.businessobjects.BORuleExecutionInterface;
import backend.util.ServerConstants;
import com.fundtech.util.datetime.DateAndZone;
import com.fundtech.util.datetime.NewASDateTimeUtils;

import com.fundtech.annotations.Expose;
import com.fundtech.annotations.Wrap;
import com.fundtech.annotations.Expose.ExposureType;
import com.fundtech.cache.entities.Accounts;
import com.fundtech.cache.entities.Banks;
import com.fundtech.cache.entities.CurrencyCfg;
import com.fundtech.cache.entities.Customrs;
import com.fundtech.cache.entities.ExchrateBu;
import com.fundtech.cache.entities.ExchrateCfg;
import com.fundtech.cache.entities.RateUsage;
import com.fundtech.cache.entities.RuleResult;
import com.fundtech.cache.entities.SystPar;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.cache.syspar.SystemParametersInterface;
import com.fundtech.cacheproviders.CacheAdapterFactory;
import com.fundtech.cacheproviders.CacheInterface;
import com.fundtech.core.paymentprocess.currencyconversion.MessageRatesInputData;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.errorhandling.ProcessError;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.errors.ProcessErrorConstants;
import com.fundtech.scl.commonTypes.FCConversionType;
import com.fundtech.scl.commonTypes.ForwardContractLineType;
import com.fundtech.util.ExceptionController;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalDateTimeUtil;
import com.fundtech.util.GlobalUtils;


/**
 * Title:       BOCurrencyConversion
 * Description: Business object for currency conversion
 * Company:     Fundtech Israel
 * Author:      Asaf Levy
 * Date:        30/04/2008
 * @version     1.0
 */
@Wrap
public class BOCurrencyConversion extends BOBasic implements PDOConstantFieldsInterface
{

  private static final Logger logger = LoggerFactory.getLogger(BOCurrencyConversion.class);
  // Constants.
  private static final String CURRENCY_1 = "Currency 1 = ";
  private static final String CURRENCY_2 = ", Currency 2 = ";
  private static final String AMOUNT_TO_CONVERT = ", Amount to Convert = ";
  private static final String OFFICE = ", Office = ";
  private static final String BASIC_INPUT_DATA = CURRENCY_1 + "{}" + CURRENCY_2 + "{}" + AMOUNT_TO_CONVERT + "{}" + OFFICE + "{}"; 
  
  private static final Long LONG_ONE = Long.valueOf(1);
  
  public static final String MESSAGERATES_CONVERSION_TYPE_DR = "DR";
  public static final String MESSAGERATES_CONVERSION_TYPE_CR = "CR";
  
  // Process error types which might be raised during currency conversion, (with
  // no forward contract), and if so, then no need for mapping into the PDO after
  // the process is done.
  private static final int[] ARR_PROCESS_ERROR_TYPES_FOR_UN_COMPLETED_CURRENCY_CONVERSION_PROCESS = 
                                              {ProcessErrorConstants.IllegalStateEXCHRATE_BU_WithNo_EXCHRATE_CFG, 
                                               ProcessErrorConstants.TriangulationCurrencyEqualsCurrency1OrCurrency2,
                                               ProcessErrorConstants.MissingRateUsageSetup,
                                               ProcessErrorConstants.CurrencyPairNotDefine,
                                               ProcessErrorConstants.InvalidCurrency,
                                               ProcessErrorConstants.RTRManualTradeIsRequired,
                                               ProcessErrorConstants.RTRIllegalSetupRateUsageUsedForBaseConversionHoldsExtranalRateInterfaceName,
                                               ProcessErrorConstants.CurrencyConversionFailure};
  
  // Process error types which might be raised during the exchange rate calculation,
  // and if so, no cross currency should be done.
  private static final int[] ARR_PROCESS_ERROR_TYPES_FOR_UN_COMPLETED_EXCHANGE_RATE_CALC_PROCESS = 
                                              {ProcessErrorConstants.MissingRateUsageSetup,
	                                           ProcessErrorConstants.CurrencyPairNotDefine,
                                               ProcessErrorConstants.RTRManualTradeIsRequired,
                                               ProcessErrorConstants.RTRIllegalSetupRateUsageUsedForBaseConversionHoldsExtranalRateInterfaceName,
                                               ProcessErrorConstants.InvalidCurrency};

  // Process error types which might be raised during analyze of MESSAGERATES records,
  // and if so, then no need to continue the process.
  private static final int[] ARR_PROCESS_ERROR_TYPES_FOR_PROBLEMATIC_MESSAGERATES_RECORDS = 
                                              {ProcessErrorConstants.ForwardContractIndicatorExistsButNo_MESSAGERATES_RecordsWereFound, 
                                               ProcessErrorConstants.ForwardContractFoundIllegalRecords};

  // Process error types which might be raised during:
  //    1) Currency conversion with no forward contract.
  // OR 2) Forward contract.
  // , and if so, then no need for mapping into the PDO after the process is done.
  private static final int[] ARR_PROCESS_ERROR_TYPES_FOR_UN_COMPLETED_CURRENCY_CONVERSION_OR_FORWARD_CONTRACT_PROCESS = 
                                              {ProcessErrorConstants.SettlementCurrencyDoesntEqualDebitOrCreditCurrency,
                                               ProcessErrorConstants.IllegalStateEXCHRATE_BU_WithNo_EXCHRATE_CFG, 
                                               ProcessErrorConstants.TriangulationCurrencyEqualsCurrency1OrCurrency2,
                                               ProcessErrorConstants.ForwardContractEmpty_MESSAGERATES_AMOUNT, 
                                               ProcessErrorConstants.ForwardContractEmpty_MESSAGERATES_RATE,
                                               ProcessErrorConstants.ForwardContractTotalAmountExceedsAmountToConvert,
                                               ProcessErrorConstants.ForwardContractIndicatorExistsButNo_MESSAGERATES_RecordsWereFound,
                                               ProcessErrorConstants.ForwardContractFoundIllegalRecords,
                                               ProcessErrorConstants.RTRManualTradeIsRequired,
                                               ProcessErrorConstants.RTRIllegalSetupRateUsageUsedForBaseConversionHoldsExtranalRateInterfaceName};
  private static final int NUM_OF_ERRORS_FOR_UN_COMPLETED_CURRENCY_CONVERSION_PROCESS = ARR_PROCESS_ERROR_TYPES_FOR_UN_COMPLETED_CURRENCY_CONVERSION_OR_FORWARD_CONTRACT_PROCESS.length;
  
  // Currently includes only the Non-Overridable tolerance error.
  private static final int[] ARR_PROCESS_ERROR_TYPES_TO_SET_INTO_FEEDBACK = 
                                              {ProcessErrorConstants.ThresholdErrorForInstructionAmount,
                                               ProcessErrorConstants.ThresholdErrorForResidualAmount,
                                               ProcessErrorConstants.ToleranceError_RateInputIsBelowOrAboveRateTolerance,
                                               ProcessErrorConstants.MissingRateUsageSetup,
                                               ProcessErrorConstants.CurrencyPairNotDefine,
                                               ProcessErrorConstants.InvalidCurrency,
                                               ProcessErrorConstants.SettlementCurrencyDoesntEqualDebitOrCreditCurrency,
                                               ProcessErrorConstants.ExpiryDate,
                                               ProcessErrorConstants.CurrencyConversionFailure};

  // MESSAGERATES.FORWARD_CONTRACT possible values.
  private static final Long MESSAGERATES_FORWARD_CONTRACT_VALUE_FORWARD_CONTRACT = Long.valueOf(0);
  private static final Long MESSAGERATES_FORWARD_CONTRACT_VALUE_DEALER_RATE = Long.valueOf(1);
  private static final Long MESSAGERATES_FORWARD_CONTRACT_VALUE_RESIDUAL = Long.valueOf(2);
  
  // Error messages.
  private static final String ERROR_MESSAGE_NO_EXCHRATE_CFG_RECORD = "ERROR: No EXCHRATE_CFG record for currency {}, currency {} and rate usage type %s under office {}.";
  private static final String ERROR_MESSAGE_NO_EXCHRATE_BU_RECORD = "ERROR: EXCHRATE_CFG record was found for currency pair %s and office %s, but no definition of currency pair in EXCHRATE_BU table for currency pair %s, office %s & rate usage type %s.";
  private static final String ERROR_MESSAGE_CURRENCY_PAIR_NOT_DEFINE="EROR:Currency pair not defined in Exchange Rate Info for {} and {}";
  private static final String ERROR_MESSAGE_MANUAL_TRADE_IS_REQUIRED = "ERROR: Manual trade is required.";
  private static final String ERROR_MESSAGE_ILLEGAL_SETUP_BASE_CONVERSION_WITH_INTERFACE_NAME = "ERROR: Illegal setup - Rate usage used for BASE conversion cannot hold external rate interface name, (%s).";
  private static final String ERROR_MESSAGE_INDICATIVE_CC_CALCULATION_WITH_EXTERNAL_RATE_INTERFACE_NAME = "ERROR: Illegal setup - Indicative currency conversion calculation should be done with a standard sheet rate with no external rate interface name, (%s).";
  private static final String ERROR_MESSAGE_NULL_RATE_USAGE = "ERROR: 'calculateExchangeRate' - no {} rate usage is defined for {} {}. Call was for threshold validation = {}.";
  private static final String ERROR_MESSAGE_TRIANGULATION_CURRENCY_EQUALITY = "ERROR: Triangulation currency %s which was determined according to %s equals currency 1: %s or currency 2: %s, under office %s.";
  private static final String ERROR_MESSAGE_EXPIRY_DATE = "ERROR: Expiry date validation failure, (message status will be set to WAITRATE) - exchange rate date %s is earlier than current %s date %s.";
  private static final String ERROR_MESSAGE_FORWARD_CONTRACT_TOTAL_AMOUNT_EXCEEDS_AMOUNT_TO_CONVERT = "ERROR: Forward contract step %s: total amount entered %s for currency %s exceeds the amount to convert %s %s.";
  private static final String ERROR_MESSAGE_FORWARD_CONTRACT_FOUND_ILLEGAL_RECORDS = "ERROR: Forward contract - for MID %s and conversion type %s, found record(s) with currencies pair which don't match the allowed combinations according to following input data: currency 1 = %s, currency 2 = %s, cross currency used = %s, triangulation currency = %s.";
  private static final String ERROR_MESSAGE_FORWARD_CONTRACT_INDIACTOR_EXISTS_WITH_NO_MESSAGERATES_RECORDS = "ERROR: Tries to perform forward contract For MID %s, (new message = %s), and conversion type %s, but no forward contract data was found.";
  private static final String ERROR_MESSAGE_RATE_INPUT_EXCEEDS_SHEET_RATE = "ERROR: The rate input %s exceeds %s percent of the sheet rate %s.";
  
  // Process errors.
  private static final ProcessError PROCESS_ERROR_ILLEGAL_STATE_EXCHRATE_BU_WITH_NO_EXCHRATE_CFG = new ProcessError(ProcessErrorConstants.IllegalStateEXCHRATE_BU_WithNo_EXCHRATE_CFG);
  private static final ProcessError PROCESS_ERROR_THRESHOLD_FOR_INSTRUCTION_AMOUNT = new ProcessError(ProcessErrorConstants.ThresholdErrorForInstructionAmount);
  private static final ProcessError PROCESS_ERROR_THRESHOLD_FOR_RESIDUAL_AMOUNT = new ProcessError(ProcessErrorConstants.ThresholdErrorForResidualAmount);
  private static final ProcessError PROCESS_ERROR_FORWARD_CONTRACT_EMPTY_MESSAGERATES_AMOUNT = new ProcessError(ProcessErrorConstants.ForwardContractEmpty_MESSAGERATES_AMOUNT);
  private static final ProcessError PROCESS_ERROR_FORWARD_CONTRACT_EMPTY_MESSAGERATES_CONTRACT = new ProcessError(ProcessErrorConstants.ForwardContractEmpty_MESSAGERATES_CONTRACT);
  private static final ProcessError PROCESS_ERROR_FORWARD_CONTRACT_EMPTY_MESSAGERATES_RATE = new ProcessError(ProcessErrorConstants.ForwardContractEmpty_MESSAGERATES_RATE);
  private static final ProcessError PROCESS_ERROR_STTLM_CURR_DOESNT_EQUAL_DBT_OR_CDT_CURR = new ProcessError(ProcessErrorConstants.SettlementCurrencyDoesntEqualDebitOrCreditCurrency);
  private static final ProcessError PROCESS_ERROR_RTR_MANUAL_TRADE_IS_REQUIRED = new ProcessError(ProcessErrorConstants.RTRManualTradeIsRequired);
  private static final ProcessError PROCESS_ERROR_CURRENCY_CONVERSION_FAILURE = new ProcessError(ProcessErrorConstants.CurrencyConversionFailure);
  
  private static final BORuleExecutionInterface m_ruleEngine = BOProxy.loggingDecoration(BORuleExecution.class, BORuleExecutionInterface.class) ;
  
  public static final String FC_INFO_IND_RTR = "R";    // Real time rate.
  public static final String FC_INFO_IND_MANUAL = "M"; // Forward contract or dealer rate.
  public static final String FC_INFO_IND_BLIND_RATE = "B"; // Blind rate.
  
  /**
   * Performs currency conversion according to the passed conversion type
   * input parameter and according to the related PDO object.
   * It will analyze the values within the PDO and will perform a call to the right
   * conversion method.
   * This is the method which will be exposed to the business flow, which will
   * call 3 times for base, credit & debit, ('Mid' conversion type shouldn't be used
   * in that case).
   * @param sConversionType one of the following 3 options: Base, Credit & Debit,
   *                        where 'Mid' conversion type shouldn't be used in that case
   */
  @Expose
  @LoadPDO
  public Feedback performCurrencyConversion(final String sMID) throws CurrencyConversionException
  {
    final String MESSAGE_METHOD_START = "BOCurrencyConversion.performCurrencyConversion - method params: MID.";
    final String EXCEPTION_MESSAGE = "Exception has occured in 'BOCurrencyConversion.performCurrencyConversion'.";
    final String EXCEPTION_MESSAGE_UNSUPPORTED_CONVERSION_TYPE = "Exception has occured in 'BOCurrencyConversion.performCurrencyConversion' - unsupported conversion type: %s.";
    final String MESSAGE_SHOULD_SKIP_PROCESS_FLAGS = "Should skip currency conversion flags - Skip currency conversion: {}, Should convert to orig initiating customer currency, (CUSTOMRS.CUST_BASE_CCY): {}.";
    final String CONVERSION_TYPE = "Conversion type = {}.";
    
    
    logger.info(MESSAGE_METHOD_START);
    
    PDO pdo = Admin.getContextPDO();
    
    final String sConversionType = pdo.getString(D_CURRENCY_CONVERSION_TYPE);
    logger.info(CONVERSION_TYPE, sConversionType);
    
    pdo.set(P_BASE_CCY, pdo.getNSetOffice().getCurrency());
    
    // Conversion type wasn't provided.
    if(sConversionType == null)
    {
      final String MISSING_INPUT_PARAMETER = "Conversion Type";
      return ErrorAuditUtils.onError(ProcessErrorConstants.MissingInput, (Feedback)null, MISSING_INPUT_PARAMETER) ; 
    } 
    
    if(sConversionType.equals(ConversionType.Base.toString())) handleEquivalentFieldsMapping();
    
    boolean bForwardContract = shouldProcessForwardContract(pdo);
    CurrencyConversionInputData ccInputData = getCurrencyConversionInputData(sConversionType, bForwardContract);
    
    boolean bShouldSkipCurrencyConversion = ccInputData.shouldSkipCurrencyConversion();
    
    //Attempt to add protection against NPE in case of Mambo tests
    if (ccInputData.getCurrency1() == null || ccInputData.getCurrency2() == null)
    {
    	logger.warn("No conversion performed and skipped, possibly mambo flow");
    	bShouldSkipCurrencyConversion = true;
    }
    
    ProcessError[] arrRTRProcessErrorHolder = new ProcessError[1];
    boolean bWaitForRTR = false;
    if(!bShouldSkipCurrencyConversion)
    {
    	bWaitForRTR = checkRTRConditions(ccInputData, arrRTRProcessErrorHolder);
    }
    
    
    if(bWaitForRTR || arrRTRProcessErrorHolder[0] != null) bShouldSkipCurrencyConversion = true;
    
    // Determines whether we need to perform conversion of the settlment amount to the currency of
    // the orig initiating customer, (according to CUSTOMRS.BASE_CUST_CCY).
    // NOTE: Even if the BASE conversion itself is skipped we might need to still perform the above conversion;
    //       see conditions in the 'shouldConvertToOrigInitiatingCustomerCurrency' method.
    boolean bShouldConvertToOrigInitiatingCustomerCurrency = false;
    if(sConversionType.equals(ConversionType.Base.toString()))
    {
    	bShouldConvertToOrigInitiatingCustomerCurrency = shouldConvertToOrigInitiatingCustomerCurrency();
    }
    
    logger.info(MESSAGE_SHOULD_SKIP_PROCESS_FLAGS, bShouldSkipCurrencyConversion, bShouldConvertToOrigInitiatingCustomerCurrency);
    
    CurrencyConversionOutputData ccOutputData = null;
    
  	// Will be initialized only if we need to convert the currency of the orig initiating customer, 
    // (according to CUSTOMRS.BASE_CUST_CCY).
  	CurrencyConversionOutputData ccOutputDataForOrigInitiatingCustomer = null;
    
    try
    {
      // Continues process if:
      //    1) Need to perform full currency conversion process; i.e. the 2 currencies in the CurrencyConversionInputData 
      //       object are not the same.
      // OR 2) Currency conversion process SHOULD BE SKIPPED, but we need to perform conversion of the settlement amount to 
      //       the currency of the orig initiating customer, (according to CUSTOMRS.BASE_CUST_CCY).
      if(   !bShouldSkipCurrencyConversion
      	 || (bShouldSkipCurrencyConversion && bShouldConvertToOrigInitiatingCustomerCurrency)	)
      {
		    setRateUsageFields(pdo, sConversionType);
		    
        // In case we're not in BASE conversion and both DEBIT and CREDIT side derivation was performed and 
        // the instruction currency doesn't equal currency 1 or currency 2, error should be raised,
        // and currency conversion process shouldn't be performed.
        if (    !sConversionType.equals(ConversionType.Base.toString()) 
            && pdo.getString(OX_STTLM_CCY) != null
            && pdo.getDEBIT_ACCOUNT() != null && pdo.getCREDIT_ACCOUNT() != null 
            && ! (   pdo.getString(OX_STTLM_CCY).equals(pdo.getString(P_DBT_ACCT_CCY))
                  || pdo.getString(OX_STTLM_CCY).equals(pdo.getString(P_CDT_ACCT_CCY))) )
        {
          ccOutputData = new CurrencyConversionOutputData();
          ErrorAuditUtils.setErrors(PROCESS_ERROR_STTLM_CURR_DOESNT_EQUAL_DBT_OR_CDT_CURR);
          ccOutputData.addError(ProcessError.getError(ProcessErrorConstants.SettlementCurrencyDoesntEqualDebitOrCreditCurrency, null, null));
        }
        
        // Conversion type is 'Base'.
        else if(sConversionType.equals(ConversionType.Base.toString()))
        {
        	// Executes BASE conversion.
        	if(!bShouldSkipCurrencyConversion)
        	{
        		ccOutputData = performCurrencyConversion(ccInputData);
        	}
        	
        	// Executes customer conversion.
        	if(bShouldConvertToOrigInitiatingCustomerCurrency)
        	{
          	// If we arrived here, then the D_CUST_BASE_CCY, should have been already set during the 'shouldConvertToOrigInitiatingCustomerCurrency' method.
        		String sD_CUST_BASE_CCY = pdo.getString(D_CUST_BASE_CCY);
        		
        		// If required, executes the conversion.
        		if(!ccInputData.getCurrency1().equals(sD_CUST_BASE_CCY))
        		{
        			CurrencyConversionInputData ccInputDataForOrigInitiatingCustomerConversion = new CurrencyConversionInputData(ccInputData);
        			
        			// Updates the input with the right currency to convert to.
        			ccInputDataForOrigInitiatingCustomerConversion.setCurrency2(sD_CUST_BASE_CCY);
        			
        			// Just in case that in the future, this boolean will be used later on.
        			ccInputDataForOrigInitiatingCustomerConversion.setShouldSkipCurrencyConversion();
        			
          		ccOutputDataForOrigInitiatingCustomer = performCurrencyConversion(ccInputDataForOrigInitiatingCustomerConversion);
          	}
        	}
        }
        
        // Conversion type is 'Debit' or 'Credit'
        else if(   sConversionType.equals(ConversionType.Debit.toString())
                || sConversionType.equals(ConversionType.Credit.toString()))
        {
          ccOutputData = !bForwardContract ? 
                         performCurrencyConversion(ccInputData) :
                         performForwardContractAndDealerRateConversion((ForwardContractDealerRateInputData)ccInputData);
        }
        
        // Unsupported conversion type.
        else
        {
          String sExceptionMessage = String.format(EXCEPTION_MESSAGE_UNSUPPORTED_CONVERSION_TYPE, sConversionType);
          throw new Exception(sExceptionMessage);
        }
      }
      
      // Performs mapping of output into the PDO; this should be done also if we 
      // have skipped the process itself.
      mapCurrencyConversionOutputIntoPDO(sConversionType, ccOutputData, ccOutputDataForOrigInitiatingCustomer, bShouldSkipCurrencyConversion, bShouldConvertToOrigInitiatingCustomerCurrency,
                                         ccInputData.getOriginalSettlementAmount(), ccInputData.getOriginalDebitAmount());
      
      // For SAVE tests only !!!
//      try
//      {
//        pdo.set("P_IS_HISTORY", "0");
//        new backend.paymentprocess.dao.DAS().batchSave(false, pdo);
//      }
//      catch(Throwable t)
//      {
//        ExceptionController.getInstance().handleException(t, this);
//      }
    }
    
    catch(Exception e)
    {
      ExceptionController.getInstance().handleException(e, this);
      
      String sOriginalExceptionMessage = e.getMessage();
      String sExceptionMessage = sOriginalExceptionMessage != null ? 
                                 sOriginalExceptionMessage : EXCEPTION_MESSAGE;
      throw new CurrencyConversionException(sExceptionMessage, e);
    }
    
    final Feedback feedback = new Feedback();
    
    // Traces all process errors, and sets the feedback with the first one which
    // is included in either the ARR_PROCESS_ERROR_TYPES_FOR_UN_COMPLETED_CURRENCY_CONVERSION_OR_FORWARD_CONTRACT_PROCESS
    // array or in the ARR_PROCESS_ERROR_TYPES_TO_SET_INTO_FEEDBACK array.
    //
    // Note: the 'ccOutputDataForOrigInitiatingCustomer' is relevant only for BASE conversion and even if we're in BASE
    //       conversion it might be null.
    if(   (ccOutputData != null && !ccOutputData.getErrors().isEmpty())
    	 ||	(ccOutputDataForOrigInitiatingCustomer != null && !ccOutputDataForOrigInitiatingCustomer.getErrors().isEmpty()) 
    	 || arrRTRProcessErrorHolder[0] != null)
    {
      List<ProcessError> listErrors = new ArrayList<ProcessError>();
      
      if(ccOutputData != null && !ccOutputData.getErrors().isEmpty())
      {
      	listErrors = ccOutputData.getErrors();
        isCompletedSuccessfully(feedback, listErrors);
      }
      
      if(   feedback.isSuccessful() 
      	 && (ccOutputDataForOrigInitiatingCustomer != null && !ccOutputDataForOrigInitiatingCustomer.getErrors().isEmpty()))
      {
      	listErrors.clear();
      	listErrors = ccOutputDataForOrigInitiatingCustomer.getErrors();
        isCompletedSuccessfully(feedback, listErrors);
      }
      
      if(   feedback.isSuccessful() 
       	 && arrRTRProcessErrorHolder[0] != null)
      {
      	listErrors.clear();
      	listErrors.add(arrRTRProcessErrorHolder[0]);
      	isCompletedSuccessfully(feedback, listErrors);
      }	 
    }
    
    
    
    return feedback; 
  }
  
  /**
   * 
   */
  private void handleEquivalentFieldsMapping()
  {
  	final String TRACE_EQUIVALENT_FIELDS_DATA = "OX_STTLM_AMT: {}, X_EQVT_AMT: {}, X_EQVT_AMT_CCY: {}, X_EQVT_CCY_OF_TRF: {}.";
  	final String TRACE_PERFORMS_MAPPING = "Maps X_EQVT_AMT to P_DBT_AMT, X_EQVT_AMT_CCY to P_DBT_ACCT_CCY, X_EQVT_CCY_OF_TRF to OX_STTLM_CCY, P_RVS_SELL to true.";
  	final String TRACE_ASSURES_P_RVS_SELL_IS_FALSE = "Assures that P_RVS_SELL is false !";

  	
  	
  	PDO pdo = Admin.getContextPDO();
  	
  	BigDecimal bdOX_STTLM_AMT = pdo.getDecimal(OX_STTLM_AMT);
  	BigDecimal bdX_EQVT_AMT = pdo.getDecimal(X_EQVT_AMT);
  	String sX_EQVT_AMT_CCY = pdo.getString(X_EQVT_AMT_CCY);
  	String sX_EQVT_CCY_OF_TRF = pdo.getString(X_EQVT_CCY_OF_TRF);
  	
  	boolean bEquivalentFieldsExist = bdX_EQVT_AMT != null && !isNullOrEmpty(sX_EQVT_AMT_CCY) && !isNullOrEmpty(sX_EQVT_CCY_OF_TRF);
  	
  	logger.info(TRACE_EQUIVALENT_FIELDS_DATA, new Object[] {bdOX_STTLM_AMT, bdX_EQVT_AMT, sX_EQVT_AMT_CCY, sX_EQVT_CCY_OF_TRF});
  	
  	// Maps the equivalent fields' values to their parallel non-equivalent fields in case ALL equivalent fields hold a valid value
  	// and in case OX_STTLM_AMT is null; if OX_STTLM_AMT is null, it means that we're in the first cycle of the message and thus setting of the
  	// fields is required and especially turning on the P_RVS_SELL flag.
  	// In case OX_STTLM_AMT isn't null, then it means that we're not in the first cycle of the message and in any case, the equivalent fields
  	// will hold a value, (whether there were originally sent in the message or whether they were set in the 'mapCurrencyConversionOutputIntoPDO'
  	// method); in any case, the P_RVS_SELL flag will hold its correct value.
  	if(bEquivalentFieldsExist && bdOX_STTLM_AMT == null)
  	{
  		logger.info(TRACE_PERFORMS_MAPPING);
  		pdo.set(P_DBT_AMT, bdX_EQVT_AMT);
  		pdo.set(P_DBT_ACCT_CCY, sX_EQVT_AMT_CCY);
  		pdo.set(OX_STTLM_CCY, sX_EQVT_CCY_OF_TRF);
  		pdo.set(X_STTLM_CCY, sX_EQVT_CCY_OF_TRF);
  		pdo.set(P_RVS_SELL, ServerConstants.BOOL_TRUE);
  	}
  	
  	// In general, when equivalent fields are not sent then settlement amount must exist; i.e. we'll always enter this 'if',
  	// since this is the COMMON case, (which will occur for clients that don't use the equivalent fields), and there is no need for that
  	// as P_RVS_SELL default value is false. 
  	// However, this is for assuring that P_RVS_SELL is false for the following case:
  	//  1) Settlement amount is empty, equivalent fields are valid --> P_RVS_SELL is set to true.
  	//  2) Message falls to REPAIR.
  	//  3) User decides to delete the equivalent fields and to enter the settlement amount --> P_RVS_SELL should be set to false !
  	if(!bEquivalentFieldsExist && bdOX_STTLM_AMT != null)
  	{
  		logger.info(TRACE_ASSURES_P_RVS_SELL_IS_FALSE);
  		pdo.set(P_RVS_SELL, ServerConstants.BOOL_FALSE);
  	}
  	
  	
  }
  
  /**
   * 
   */
  private boolean shouldConvertToOrigInitiatingCustomerCurrency()
  {
  	final String TRACE_CURRENCIES_DATA = "P_ORG_INITG_PTY_CUST_CD: {}, CUST_BASE_CCY: {}, P_BASE_CCY: {}.";
  	final String TRACE_NULL_ORIG_INITIATING_CUSTOMER = "Null CUSTOMRS record for P_ORG_INITG_PTY_CUST_CD '{}'.";
  	final String TRACE_NULL_P_ORG_INITG_PTY_CUST_CD = "Null P_ORG_INITG_PTY_CUST_CD value.";
  	final String TRACE_METHOD_RESULT = "Method result: {}.";
  		
  	
  	
  	boolean bShouldConvertToOrigInitiatingCustomerCurrency = false;
  	
  	PDO pdo = Admin.getContextPDO();
  	String sP_ORG_INITG_PTY_CUST_CD = pdo.getString(P_ORG_INITG_PTY_CUST_CD);
  	
  	if(!isNullOrEmpty(sP_ORG_INITG_PTY_CUST_CD))
  	{
  		Customrs origInitiatingCustomer = pdo.getNSetORIG_INITIATING_CUSTOMER();
  		
  		if(origInitiatingCustomer != null)
  		{
	  		String sCUST_BASE_CCY = origInitiatingCustomer.getCustBaseCcy();
	  		
	  		// Gets the office currency.
	  		String sP_BASE_CCY = pdo.getString(P_BASE_CCY);
	  		
	  		logger.info(TRACE_CURRENCIES_DATA, new Object[] {sP_ORG_INITG_PTY_CUST_CD, sCUST_BASE_CCY, sP_BASE_CCY});
	  		
	  		if(!isNullOrEmpty(sCUST_BASE_CCY))
	  		{
	      	// Conversion is required if CUSTOMRS.CUST_BASE_CCY holds a valid value and differs then P_BASE_CCY.
	    		// NOTE: It doesn't matter if the BASE currency conversion will be skipped or not.
	    		// Mapping to the final field - P_CUST_BASE_AMT - will be done in the 'mapCurrencyConversionOutputIntoPDO'. 
	  			bShouldConvertToOrigInitiatingCustomerCurrency = !sCUST_BASE_CCY.equals(sP_BASE_CCY);
	  			
	  			pdo.set(D_CUST_BASE_CCY, sCUST_BASE_CCY);
	  		}
  		}

  		else
    	{
    		logger.info(TRACE_NULL_ORIG_INITIATING_CUSTOMER, sP_ORG_INITG_PTY_CUST_CD);
    	}
  	}
  	
  	else
  	{
  		logger.info(TRACE_NULL_P_ORG_INITG_PTY_CUST_CD);
  	}
  	
  	logger.info(TRACE_METHOD_RESULT, bShouldConvertToOrigInitiatingCustomerCurrency);
  	
  	
  	return bShouldConvertToOrigInitiatingCustomerCurrency;
  }
  
  /**
   * 
   */
  public static Feedback isCompletedSuccessfully(Feedback feedback, List<ProcessError> listErrors)
  {
  	
  	
	  if (listErrors != null && listErrors.size() > 0)
	  {
		  final String TRACE_PROCESS_ERRORS = "Currency conversion process errors: {}";
		  feedback = feedback == null ? new Feedback() : feedback;
	      StringBuilder sb = new StringBuilder(ServerConstants.NEWLINE);
	      boolean bFeedbackWasAlreadySet = false;
	      
	      int iSize = listErrors.size();
	      for(int i=0; i<iSize && !bFeedbackWasAlreadySet; i++)
	      {
	        ProcessError processError = listErrors.get(i);
	        sb.append(processError.toString());
	        sb.append(ServerConstants.NEWLINE);
	        
	        if(!bFeedbackWasAlreadySet && processErrorsIncludeErrorToSetIntoFeedback(processError))
	        {
	          feedback.setFailure();
	          
	          int iErrorCode = processError.getErrorCode();
	          feedback.setErrorCode(iErrorCode);
	          
	          String sDescription = ServerConstants.getErrorAuditUtils().loadErrorAuditText(new Long(iErrorCode).longValue(), null, processError.getNonPaymentFields());
	          feedback.setErrorText(sDescription);
	          feedback.setUserErrorText(sDescription);
	          
	          bFeedbackWasAlreadySet = true;
	        }
	      }
	      
	      logger.info(TRACE_PROCESS_ERRORS, sb.toString());
	  }
	  
	  
	  
	  return feedback;
  }
  
  /**
   * Returns whether the passed ProcessError is included in either the 
   * ARR_PROCESS_ERROR_TYPES_FOR_UN_COMPLETED_CURRENCY_CONVERSION_OR_FORWARD_CONTRACT_PROCESS
   * array or in the ARR_PROCESS_ERROR_TYPES_TO_SET_INTO_FEEDBACK array.
   */
  public static boolean processErrorsIncludeErrorToSetIntoFeedback(ProcessError processError)
  {
  	
  	
    boolean bIncludesError = false;
    int iErrorCode = processError.getErrorCode();
    
    for(int i=0; i<NUM_OF_ERRORS_FOR_UN_COMPLETED_CURRENCY_CONVERSION_PROCESS && !bIncludesError; i++)
    {
      bIncludesError = ARR_PROCESS_ERROR_TYPES_FOR_UN_COMPLETED_CURRENCY_CONVERSION_OR_FORWARD_CONTRACT_PROCESS[i] == iErrorCode; 
    }
    
    if(!bIncludesError)
    {
      for(int i=0; i<ARR_PROCESS_ERROR_TYPES_TO_SET_INTO_FEEDBACK.length && !bIncludesError; i++)
      {
        bIncludesError = ARR_PROCESS_ERROR_TYPES_TO_SET_INTO_FEEDBACK[i] == iErrorCode;
      }
    }
    
    
    
    return bIncludesError;
  }
  
  /**
   * Performs mapping of output into the PDO.
   * @param dOriginalSettlementAmount original SETTLEMENT amount; can be null
   *                                  if 'bCurrencyConversionProcessWasSkipped'
   *                                  is false.
   * @param dOriginalDebitAmount original DEBIT amount; can be null
   *                             if 'bCurrencyConversionProcessWasSkipped' is false.
   */
  private void mapCurrencyConversionOutputIntoPDO(String sConversionType, 
                                                  CurrencyConversionOutputData ccOutputData,
                                                  CurrencyConversionOutputData ccOutputDataForOrigInitiatingCustomer,
                                                  boolean bCurrencyConversionProcessWasSkipped,
                                                  boolean bShouldConvertToOrigInitiatingCustomerCurrency,
                                                  Double dOriginalSettlementAmount, Double dOriginalDebitAmount)
  {
    final String INPUT_DATA = "Should skip currency conversion flag: {}, Should convert to orig initiating customer currency, (CUSTOMRS.CUST_BASE_CCY): {}, Original settlement amount: {}, Original debit amount: {}.";
    
    
    
    logger.info(INPUT_DATA, new Object[]{bCurrencyConversionProcessWasSkipped, bShouldConvertToOrigInitiatingCustomerCurrency, dOriginalSettlementAmount, dOriginalDebitAmount});
    
    PDO pdo = Admin.getContextPDO();
    boolean isDirectDebit = MessageUtils.isDirectDebit(pdo);
    
    // STEP 1 - 
    // Determines if mapping is required according to the process errors within the passed CurrencyConversionOutputData object,
    // and acc. to passed flags.
    boolean bPerformMapping = true;
    
    boolean bSTATUS_WAIT_RTR = MessageConstantsInterface.MESSAGE_STATUS_WAIT_RTR.equals(pdo.getString(D_PARKING_MSG_STS));
    
    // ASAF: DO NOT REMOVE THE SETTING OF THIS BOOLEAN !!!
    //
    // No need to perform mapping in case:
    //    1) 'ccOutputData' is null and currency conversion process wasn't skipped.
    // OR 2) Process errors which have stopped the process have been raised.
    if(   (ccOutputData == null && !bCurrencyConversionProcessWasSkipped)
       || (ccOutputData != null && ccOutputData.includesError(ARR_PROCESS_ERROR_TYPES_FOR_UN_COMPLETED_CURRENCY_CONVERSION_OR_FORWARD_CONTRACT_PROCESS)) )
    {
      bPerformMapping = false;
    }
    
    // STEP 2 - 
    // If required, performs actual mapping.
    if(bPerformMapping)
    {
      Boolean boolP_RVS_SELL = pdo.getBoolean(P_RVS_SELL);
      boolean bReverseSell = boolP_RVS_SELL != null ? boolP_RVS_SELL.booleanValue() : false;
      
      // Full currency conversion process was performed.
      if(!bCurrencyConversionProcessWasSkipped)
      {
        Double dConvertedAmount = ccOutputData.getConvertedAmount();
        BigDecimal bdConvertedAmount = dConvertedAmount != null ? BigDecimal.valueOf(dConvertedAmount) : (BigDecimal)null;

        Double dRate = ccOutputData.getRate();
        BigDecimal bdRate = dRate != null ? BigDecimal.valueOf(dRate) : (BigDecimal)null;

        BigDecimal bdMidRate = null, bdSpread = null;
        int iCurrency1Units = 0, iCurrency2Units = 0; 
        ExchangeRateOutputData exchangeRateOutputData = ccOutputData.getExchangeRateOutputData();
        if(exchangeRateOutputData != null)
        {
          bdMidRate = exchangeRateOutputData.getMidRate() != null ? BigDecimal.valueOf(exchangeRateOutputData.getMidRate()) : (BigDecimal)null;
          bdSpread = exchangeRateOutputData.getSpread() != null ? BigDecimal.valueOf(exchangeRateOutputData.getSpread()) : (BigDecimal)null;
          iCurrency1Units = exchangeRateOutputData.getCurrency1Units();
          iCurrency2Units = exchangeRateOutputData.getCurrency2Units();
        }
        BigDecimal bdConvertedAmountStep1 = ccOutputData.getConvertedAmountStep1() != null ? BigDecimal.valueOf(ccOutputData.getConvertedAmountStep1()) : (BigDecimal)null;
        
        boolean bCrossCurrencyUsed = ccOutputData.isCrossCurrencyUsed();
        BigDecimal bdRateStep1 = ccOutputData.getRateStep1() != null ? BigDecimal.valueOf(ccOutputData.getRateStep1()) : (BigDecimal)null;
        
        Double dRateStep2 = bCrossCurrencyUsed ? ccOutputData.getExchangeRateOutputDataStep2().getRate() : null;
        BigDecimal bdRateStep2 = dRateStep2 != null ? BigDecimal.valueOf(dRateStep2) : (BigDecimal)null;
        
        String sTriangulationCurrency = ccOutputData.getTriangulationCurrency() != null ? ccOutputData.getTriangulationCurrency() : GlobalConstants.EMPTY_STRING;
        
        // Rate type handling.
        // Currently, there will be no mapping of rate type for BASE conversion type, so it won't override
        // the debit or credit rate type that was set; we have only P_RATE_TYPE in MINF table !!! 
        String sRateType = null;
        RateUsage rateUsage = null;
        //  
        if(!sConversionType.equals(ConversionType.Base))
        {
          String sRateUsageName = sConversionType.equals(ConversionType.Credit.toString()) ?
                                  pdo.getString(P_CDT_RATE_USAGE_NM) :
                                  pdo.getString(P_DBT_RATE_USAGE_NM);
          
          if(!isNullOrEmpty(sRateUsageName))
          {
            rateUsage = CacheKeys.rateUsageKey.getSingle(sRateUsageName);
            if (rateUsage != null)
                sRateType = rateUsage.getRateType();
          }
        }
        
        // Conversion type is 'Base'.
        if(sConversionType.equals(ConversionType.Base.toString()))
        {
         	pdo.set(P_BASE_AMT, bdConvertedAmount);
         	mapCustomerBaseAmountField(ccOutputDataForOrigInitiatingCustomer, bShouldConvertToOrigInitiatingCustomerCurrency, dOriginalSettlementAmount, dOriginalDebitAmount);
        }
        
        // Conversion type is 'Debit'.
        else if(sConversionType.equals(ConversionType.Debit.toString()))
        {
          if(!bReverseSell)
          {
          	pdo.set(P_DBT_AMT, bdConvertedAmount);
          	pdo.set(X_EQVT_AMT, bdConvertedAmount);
          	pdo.set(X_EQVT_AMT_CCY, pdo.getString(P_DBT_ACCT_CCY));
          	pdo.set(X_EQVT_CCY_OF_TRF, pdo.getString(X_STTLM_CCY));
          }
          else pdo.set(OX_STTLM_AMT, bdConvertedAmount);
          
          pdo.set(P_DBT_RATE, bdRate);
          handleExchangeRateFieldMapping(rateUsage, bdRate);
          pdo.set(P_DBT_MID_RATE, bdMidRate);
          pdo.set(P_DBT_SPREAD, bdSpread);
          pdo.set(P_DBT_AMT_STEP1, bdConvertedAmountStep1);
          pdo.set(P_DBT_RATE_STEP1, bdRateStep1);
          pdo.set(P_DBT_RATE_STEP2, bdRateStep2);
          pdo.set(P_DBT_CROSS_CONV, bCrossCurrencyUsed);
          if(!isNullOrEmpty(sTriangulationCurrency)) pdo.set(P_DBT_TRIANGULATION_CCY, sTriangulationCurrency);
          pdo.set(D_DBT_CURR1_UNITS, iCurrency1Units);
          pdo.set(D_DBT_CURR2_UNITS, iCurrency2Units);
          pdo.set(P_CCY_CONV_TP, ConversionType.Debit.toString());
          if (sRateType != null) pdo.set(P_RATE_TYPE, sRateType);
        }
        
	      // Conversion type is 'Credit'.
	      else
        {
          pdo.set(P_CDT_AMT, bdConvertedAmount);
          pdo.set(X_STTLM_AMT, bdConvertedAmount); // Same as the P_CDT_AMT.
          if (!isDirectDebit)
        	  pdo.set(X_STTLM_CCY, pdo.get(P_CDT_ACCT_CCY));//the x_sttl_ccy shouldn't be change while it's DirectDebit 
          pdo.set(P_CDT_RATE, bdRate);
          handleExchangeRateFieldMapping(rateUsage, bdRate);
          pdo.set(X_XCHGRATEINF_XCHGRATE, bdRate);
          pdo.set(P_CDT_MID_RATE, bdMidRate);
          pdo.set(P_CDT_SPREAD, bdSpread);
          pdo.set(P_CDT_AMT_STEP1, bdConvertedAmountStep1);
          pdo.set(P_CDT_RATE_STEP1, bdRateStep1);
          pdo.set(P_CDT_RATE_STEP2, bdRateStep2);
          pdo.set(P_CDT_CROSS_CONV, bCrossCurrencyUsed); 
          if(!isNullOrEmpty(sTriangulationCurrency)) pdo.set(P_CDT_TRIANGULATION_CCY, sTriangulationCurrency);
          pdo.set(D_CDT_CURR1_UNITS, iCurrency1Units);
          pdo.set(D_CDT_CURR2_UNITS, iCurrency2Units);
          pdo.set(P_CCY_CONV_TP, ConversionType.Credit.toString());
          pdo.set(P_RATE_TYPE, sRateType);
        }
      }
      
      // Currency conversion process was skipped; we need to map only the original payment amounts to related amount fields in the PDO.
      else
      {
        BigDecimal bdOriginalSettlementAmount = dOriginalSettlementAmount != null ? BigDecimal.valueOf(dOriginalSettlementAmount) : (BigDecimal)null;
    		BigDecimal bdOriginalDebitAmount = dOriginalDebitAmount != null ? BigDecimal.valueOf(dOriginalDebitAmount) : (BigDecimal)null;
      	
        // Conversion type is 'Base'.
        if(sConversionType.equals(ConversionType.Base.toString()))
        {
          pdo.set(P_BASE_AMT, !bReverseSell ? bdOriginalSettlementAmount : bdOriginalDebitAmount);
          mapCustomerBaseAmountField(ccOutputDataForOrigInitiatingCustomer, bShouldConvertToOrigInitiatingCustomerCurrency, dOriginalSettlementAmount, dOriginalDebitAmount);
        }
        
        // No need to map if status will be set to WAIT_RTR, (not relevant to BASE conversion).
        else if(!bSTATUS_WAIT_RTR)
        {
	        // Conversion type is 'Debit'.
	        if(sConversionType.equals(ConversionType.Debit.toString()))
	        {
	          if(!bReverseSell)
	          {
	          	pdo.set(P_DBT_AMT, bdOriginalSettlementAmount);
	          	pdo.set(X_EQVT_AMT, bdOriginalSettlementAmount);
	          	pdo.set(X_EQVT_AMT_CCY, pdo.getString(P_DBT_ACCT_CCY));
	          	pdo.set(X_EQVT_CCY_OF_TRF, pdo.getString(X_STTLM_CCY));
	          }
	          else pdo.set(OX_STTLM_AMT, bdOriginalDebitAmount);
	        }
	        
	        // Conversion type is 'Credit'.
	        else
	        {
	          pdo.set(P_CDT_AMT, bdOriginalSettlementAmount);
	          if (pdo.get(P_CDT_AMT)!=null)//set X_STTLM_AMT according to P_CDT_AMT only if P_CDT_AMT is not NULL (Can be NULL for non-payments like OPI)
	        	  pdo.set(X_STTLM_AMT, pdo.get(P_CDT_AMT));
	          if (pdo.get(P_CDT_ACCT_CCY)!=null)//set X_STTLM_CCY according to P_CDT_ACCT_CCY only if P_CDT_ACCT_CCY is not NULL (Can be NULL for non-payments like OPI)
	          pdo.set(X_STTLM_CCY, pdo.get(P_CDT_ACCT_CCY));
	          
	          // Cleans these fields for the following scenario:
	          // 1) Credit currency conversion was executed once successfully; i.e. all fields were mapped and no skip process
	          //    was done --> intruction currency DOESN'T equal credit currency; in such case all below fields were mapped.
	          // 2) MOP selection determines a new credit account, and thus credit currency conversion was executed again;
	          //    In such case if the NEW credit account currency equals the instruction currency then the process is being skipped,
	          //    so we need to clean all following fields.
	          pdo.set(P_CDT_RATE, (BigDecimal)null);
	          pdo.set(P_CDT_MID_RATE, (BigDecimal)null);
	          pdo.set(P_CDT_SPREAD, (BigDecimal)null);
	          pdo.set(P_CDT_AMT_STEP1, (BigDecimal)null);
	          pdo.set(P_CDT_RATE_STEP1, (BigDecimal)null);
	          pdo.set(P_CDT_RATE_STEP2, (BigDecimal)null);
	          pdo.set(P_CDT_CROSS_CONV, false); 
	          pdo.set(P_CDT_TRIANGULATION_CCY, (String)null);
	          pdo.set(D_CDT_CURR1_UNITS, 0);
	          pdo.set(D_CDT_CURR2_UNITS, 0);
	          pdo.set(P_CCY_CONV_TP, (String)null);
	          pdo.set(P_RATE_TYPE, (String)null);     
	        }
        }
      } 
      
      List<ForwardContractLineType> listMessageRates = null;
      
      // In case forward contract was performed, maps the output message rates
      // record into the PDO. 
      if(ccOutputData instanceof ForwardContractDealerRateOutputData)
      {
        listMessageRates = ((ForwardContractDealerRateOutputData)ccOutputData).getMessageRates();
        //
        // Remarked the 'if' for now, because it seems like we always need to set the message rates into the CR or DR lists.
        //if(listMessageRates != null && !listMessageRates.isEmpty())
      }
      
      if(sConversionType.equals(ConversionType.Credit.toString()))
      {
        pdo.setCR_MESSAGERATESList(listMessageRates);
      }
      else
      {
        pdo.setDR_MESSAGERATESList(listMessageRates);
      }
    }
    
    // We're in BASE conversion which was skipped but we need to convert to the customer base currency. 
    else if(bShouldConvertToOrigInitiatingCustomerCurrency)
    {
    	final String TRACE_MESSAGE = "BASE conversion process was skipped and need to map the P_CUST_BASE_AMT field...";
    	logger.info(TRACE_MESSAGE);
    	
    	mapCustomerBaseAmountField(ccOutputDataForOrigInitiatingCustomer, bShouldConvertToOrigInitiatingCustomerCurrency, dOriginalSettlementAmount, dOriginalDebitAmount);
    }
    
    // Ensures setting into the P_CUST_BASE_AMT field.
    if(sConversionType.equals(ConversionType.Base.toString()) && pdo.getDecimal(P_CUST_BASE_AMT) == null)
    {
    	final String TRACE_P_CUST_BASE_AMT_SETTING = "P_CUST_BASE_AMT is still null; sets it to the P_BASE_AMT value: {}.";
			
    	BigDecimal bdP_BASE_AMT = pdo.getDecimal(P_BASE_AMT);
			logger.info(TRACE_P_CUST_BASE_AMT_SETTING, bdP_BASE_AMT);
			pdo.set(P_CUST_BASE_AMT, bdP_BASE_AMT);
    }
    
    
  }
  
  /**
   * 
   */
  private void handleExchangeRateFieldMapping(RateUsage rateUsage, BigDecimal bdRate)
  {
  	
  	
  	PDO pdo = Admin.getContextPDO();
  	
    if(rateUsage != null)
    {
    	Long longBlindOnShoreRate = rateUsage.getBlindOnShoreRate();
    	if(longBlindOnShoreRate != null && 0 != longBlindOnShoreRate)
    	{
    		pdo.set(P_FC_INFO_IND, FC_INFO_IND_BLIND_RATE);
    		pdo.set(X_XCHGRATEINF_XCHGRATE, (BigDecimal)null);
    	}
    	
    	else
    	{
    		pdo.set(X_XCHGRATEINF_XCHGRATE, bdRate);
    	}
    }
    
    
  }
  
  /**
   * 
   */
  private void mapCustomerBaseAmountField(CurrencyConversionOutputData ccOutputDataForOrigInitiatingCustomer,
  		                                    boolean bShouldConvertToOrigInitiatingCustomerCurrency,
  																				Double dOriginalSettlementAmount, Double dOriginalDebitAmount)
  {
  	final String TRACE_METHOD_INPUT = "Method input - Valid 'ccOutputDataForOrigInitiatingCustomer' object: {}, D_CUST_BASE_CCY: {}, P_BASE_CCY: {}.";
  	final String TRACE_CUST_CONVERSION_WAS_EXECUTED = "Conversion was executed for orig initiating customer currency; P_CUST_BASE_AMT gets the conversion result: {}.";
  	final String TRACE_CUST_CONVERSION_WAS_NOT_EXECUTED_1 = "Conversion wasn't executed for orig initiating customer currency which equals the base currency; P_CUST_BASE_AMT gets the P_BASE_AMT value: {}.";
  	final String TRACE_CUST_CONVERSION_WAS_NOT_EXECUTED_2 = "Conversion wasn't executed for orig initiating customer currency which doesn't equal the base currency and reverse sell flag is {}; P_CUST_BASE_AMT gets the value of {}: {}.";
  	
  	final String TRACE_PROCESS_ERRORS = "Customer currency conversion process errors, (found during BASE conversion):n {}";
  	
  	final String ORIG_SETTLEMENT_AMOUNT = "original settlement amount";
  	final String ORIG_DEBIT_AMOUNT = "original debit amount";

  	
  	
  	PDO pdo = Admin.getContextPDO();
  	
    // This value is taken from CUSTOMRS.CUST_BASE_CCY of the CUSTOMRS record for the orig initiating customer.
    // Might be null and if not, then it was set in the 'shouldConvertToOrigInitiatingCustomerCurrency' method.
    String sD_CUST_BASE_CCY = pdo.getString(D_CUST_BASE_CCY);
    
    String sP_BASE_CCY = pdo.getString(P_BASE_CCY);
    boolean bValidOutputDataObject = ccOutputDataForOrigInitiatingCustomer != null;
  	
    logger.info(TRACE_METHOD_INPUT, new Object[] {bValidOutputDataObject, sD_CUST_BASE_CCY, sP_BASE_CCY});
  	
  	// Conversion was done for the customer base currency.
  	if(bValidOutputDataObject)
  	{
  		// Process has been completed successfully.
      if(ccOutputDataForOrigInitiatingCustomer.getErrors().isEmpty())
      {
        Double dConvertedAmount = ccOutputDataForOrigInitiatingCustomer.getConvertedAmount();
        BigDecimal bdConvertedAmount = dConvertedAmount != null ? BigDecimal.valueOf(dConvertedAmount) : (BigDecimal)null;
        
        logger.info(TRACE_CUST_CONVERSION_WAS_EXECUTED, bdConvertedAmount);
        pdo.set(P_CUST_BASE_AMT, bdConvertedAmount);
      }

      // Errors were found during the process. 
      else
      {
        final List<ProcessError> listErrors = ccOutputDataForOrigInitiatingCustomer.getErrors();
  	    StringBuilder sb = new StringBuilder();
  	      
	      int iSize = listErrors.size();
	      for(int i=0; i<iSize; i++)
	      {
	        sb.append(listErrors.get(i).toString()).append(ServerConstants.NEWLINE);
	      }
  	      
  	    logger.info(TRACE_PROCESS_ERRORS, sb.toString());
      }
  	}
  	
  	// Base currency was set for the orig initiating customer, (CUSTOMRS.CUST_BASE_CCY), but the actual conversion was skipped.
  	else if(!bValidOutputDataObject && !isNullOrEmpty(sD_CUST_BASE_CCY))
  	{
      // CUSTOMRS.CUST_BASE_CCY equals the base currency.
  		if(sD_CUST_BASE_CCY.equals(sP_BASE_CCY))
  		{
  			BigDecimal bdP_BASE_AMT = pdo.getDecimal(P_BASE_AMT);
  			logger.info(TRACE_CUST_CONVERSION_WAS_NOT_EXECUTED_1, bdP_BASE_AMT);
  			pdo.set(P_CUST_BASE_AMT, bdP_BASE_AMT);
  		}
  		
  		// Actual conversion process was skipped because the 'sD_CUST_BASE_CCY' value equals either the
  		// original settlement currency or the original debit currency.
  		else
  		{
        Boolean boolP_RVS_SELL = pdo.getBoolean(P_RVS_SELL);
        boolean bReverseSell = boolP_RVS_SELL != null ? boolP_RVS_SELL.booleanValue() : false;
  			
        BigDecimal bdOriginalSettlementAmount = dOriginalSettlementAmount != null ? BigDecimal.valueOf(dOriginalSettlementAmount) : (BigDecimal)null;
    		BigDecimal bdOriginalDebitAmount = dOriginalDebitAmount != null ? BigDecimal.valueOf(dOriginalDebitAmount) : (BigDecimal)null;
    		
    		String sAmountOrigin;
    		BigDecimal bdAmountToSet;
    		
    		if(!bReverseSell)
    		{
    			sAmountOrigin = ORIG_SETTLEMENT_AMOUNT;
    			bdAmountToSet = bdOriginalSettlementAmount;
    		}
    		else
    		{
    			sAmountOrigin = ORIG_DEBIT_AMOUNT;
    			bdAmountToSet = bdOriginalDebitAmount;
    		}
    		
    		logger.info(TRACE_CUST_CONVERSION_WAS_NOT_EXECUTED_2, new Object[] {bReverseSell, sAmountOrigin, bdAmountToSet});
        
        pdo.set(P_CUST_BASE_AMT, bdAmountToSet);
  		}
  	}
  	
  	
  }
  
  /**
   * Returns CurrencyConversionInputData object for the passed conversion type.
   */
  private CurrencyConversionInputData getCurrencyConversionInputData(String sConversionType, boolean bForwardContract)
  {
    final String PDO_INPUT_DATA = "Input data from PDO - P_MID: {}, P_OFFICE: {}, P_RVS_SELL: {}, " +
                                  "OX_STTLM_AMT: {}, OX_STTLM_CCY: {}, C_STTLM_DT: {}, " +
                                  "P_BASE_CCY: {}, P_DBT_AMT: {}, P_DBT_ACCT_CCY: {}, P_CDT_ACCT_CCY: {}, " +
                                  "P_DBT_CROSS_CONV: {}, P_DBT_CROSS_CONV: {}, P_BASE_RATE_USAGE_NM: {}, " +
                                  "P_DBT_RATE_USAGE_NM: {}, P_CDT_RATE_USAGE_NM: {}, Should process forward contract: {}.";
    
    
    
    CurrencyConversionInputData ccInputData;
    ForwardContractDealerRateInputData fcdrInputData = null;
    
    PDO pdo = Admin.getContextPDO();
    
    // Extracts from the PDO all related fields.
    String sMID = pdo.getString(P_MID);
    
    Boolean boolP_RVS_SELL = pdo.getBoolean(P_RVS_SELL);
    boolean bReverseSell = boolP_RVS_SELL != null ? boolP_RVS_SELL.booleanValue() : false;
    
    String sPaymentOffice = pdo.getString(P_OFFICE);
    
    // ORIGINAL settelemnt amount.
    BigDecimal bdOrigSettlementAmount = pdo.getDecimal(OX_STTLM_AMT);
    Double dOrigSettlementAmount = bdOrigSettlementAmount != null ? bdOrigSettlementAmount.doubleValue() : ServerConstants.DOUBLE_ZERO;
    
    String sOrigSettlementCurrency = pdo.getString(OX_STTLM_CCY);
    
    Date dateSettlementDate = pdo.getDate(X_STTLM_DT_1B);
    String sSettlementDate = ServerConstants.EMPTY_STRING;
    if(dateSettlementDate != null)
    {
      SimpleDateFormat simpleDateFormat = GlobalDateTimeUtil.getSTATIC_DATA_DATE_TIME_SimpleDateFormat();
      sSettlementDate = simpleDateFormat.format(dateSettlementDate);
    }
    
    String sBaseCurrency =  pdo.getString(P_BASE_CCY);
    
    BigDecimal bdDebitAmount = pdo.getDecimal(P_DBT_AMT);
    Double dDebitAmount = bdDebitAmount != null ? bdDebitAmount.doubleValue() : ServerConstants.DOUBLE_ZERO;
    
    String sDebitCurrency =  pdo.getString(P_DBT_ACCT_CCY);
    String sCreditCurrency =  pdo.getString(P_CDT_ACCT_CCY);
    
    String sBaseRateUsageName = pdo.getString(P_BASE_RATE_USAGE_NM);
    String sDebitRateUsageName = pdo.getString(P_DBT_RATE_USAGE_NM);
    String sCreditRateUsageName = pdo.getString(P_CDT_RATE_USAGE_NM);
    
    String sDebitCrossConv = pdo.getString(P_DBT_CROSS_CONV);
    String sCreditCrossConv = pdo.getString(P_CDT_CROSS_CONV);
    
    Object[] arrInputData = new Object[]{sMID, sPaymentOffice, bReverseSell, dOrigSettlementAmount, sOrigSettlementCurrency, 
    		                                 sSettlementDate, sBaseCurrency, dDebitAmount, sDebitCurrency, sCreditCurrency, sDebitCrossConv, sCreditCrossConv,
                                         sBaseRateUsageName, sDebitRateUsageName, sCreditRateUsageName, bForwardContract};
    
    logger.info(PDO_INPUT_DATA, arrInputData);
    
    // Conversion type is 'Base'.
    if(sConversionType.equals(ConversionType.Base.toString()))
    {
      ccInputData = !bReverseSell ?
                    new CurrencyConversionInputData(sConversionType, sPaymentOffice, dOrigSettlementAmount, sOrigSettlementCurrency, sBaseCurrency) :
                    new CurrencyConversionInputData(sConversionType, sPaymentOffice, dDebitAmount, sDebitCurrency, sBaseCurrency);
      
      handleCCInputDataAccordingToSkipProcessFlag(ccInputData, sConversionType, dOrigSettlementAmount, dDebitAmount);
    }
    
    // Conversion type is 'Debit'.
    else if(sConversionType.equals(ConversionType.Debit.toString()))
    {
      // No forward contract data.
      if(!bForwardContract)
      {
        // Note that if there reverse sell, the conversion type is 'Credit' !!!
        ccInputData = !bReverseSell ?
                      new CurrencyConversionInputData(sConversionType, sPaymentOffice, dOrigSettlementAmount, sOrigSettlementCurrency, sDebitCurrency) : 
                      new CurrencyConversionInputData(ConversionType.Credit.toString(), sPaymentOffice, dDebitAmount, sDebitCurrency, sOrigSettlementCurrency);

        handleCCInputDataAccordingToSkipProcessFlag(ccInputData, sConversionType, dOrigSettlementAmount, dDebitAmount);
      }

      // There is forward contract data.
      else
      {
        // Note that if there is reverse sell, the conversion type is 'Credit' !!!
        ccInputData = !bReverseSell ?
                      new CurrencyConversionInputData(sConversionType, sPaymentOffice, dOrigSettlementAmount, sOrigSettlementCurrency, sDebitCurrency) :
                      new CurrencyConversionInputData(ConversionType.Credit.toString(), sPaymentOffice, dDebitAmount, sDebitCurrency, sOrigSettlementCurrency);
                      
        handleCCInputDataAccordingToSkipProcessFlag(ccInputData, sConversionType, dOrigSettlementAmount, dDebitAmount);
        
        fcdrInputData = new ForwardContractDealerRateInputData(ccInputData);
        fcdrInputData.setPerformValidations(false);
      }
    }
    
    // Conversion type is 'Credit'.
    else
    {
      ccInputData = new CurrencyConversionInputData(sConversionType, sPaymentOffice, dOrigSettlementAmount, sOrigSettlementCurrency, sCreditCurrency);
      handleCCInputDataAccordingToSkipProcessFlag(ccInputData, sConversionType, dOrigSettlementAmount, dDebitAmount);
      
      // There is forward contract data.
      if(bForwardContract)
      {
        fcdrInputData = new ForwardContractDealerRateInputData(ccInputData);
        fcdrInputData.setPerformValidations(false);
      }
    }
    
    return fcdrInputData != null ? fcdrInputData : ccInputData;
  }
  
  /**
   * Returns whether forward contract should be processed or not.
   */
  private boolean shouldProcessForwardContract(PDO pdo)
  {
  	final String TRACE_DATA_AND_METHOD_OUTPUT = "Valid list of MESSAGERATES: {}, P_FC_INFO_IND: {}. Method output: {}.";
  	
  	
  	
  	String sP_FC_INFO_IND = pdo.getString(P_FC_INFO_IND);
    List<ForwardContractLineType> listMESSAGERATES = pdo.getListMESSAGERATES();
    
    boolean bShouldProcessForwardContract = false;
    
    // - 1st condition will be true when we arrive from a new message, (from the GUI or from a web service submit request for a new message).
    // - 2nd condition will be true when we perform a process to an existing message, (i.e. the submit process is done when the message isn't
    //   considered as new anymore).
    if(   (listMESSAGERATES != null && !listMESSAGERATES.isEmpty())
    	 || FC_INFO_IND_MANUAL.equals(sP_FC_INFO_IND))
    {
    	bShouldProcessForwardContract = true;
    }
    
    logger.info(TRACE_DATA_AND_METHOD_OUTPUT, new Object[] {listMESSAGERATES != null, sP_FC_INFO_IND, bShouldProcessForwardContract});
    
    
    return bShouldProcessForwardContract;
  }
  
  /**
   * Gets CurrencyConversionInputData object and detrmines how to handle it using
   * the 'skip currency conversion' flag of it.
   */
  private void handleCCInputDataAccordingToSkipProcessFlag(CurrencyConversionInputData ccInputData,
                                                           String sConversionType, 
                                                           Double dSettlementAmount, Double dDebitAmount)
  {
    if(!ccInputData.shouldSkipCurrencyConversion())
    {
      enrichCurrencyConversionInputData(sConversionType, ccInputData);
    }

    // Always perform this set as they might be used when we need to set the P_CUST_BASE_AMT, (orig initiating
    // customer conversion), where the related currency, (CUSTOMRS.CUST_BASE_CCY of that customer), equals 
    // the original settlement currency or the original debit currency.
    ccInputData.setOriginalSettlementAmount(dSettlementAmount);
    ccInputData.setOriginalDebitAmount(dDebitAmount);
  }
  
  /**
   * Gets CurrencyConversionInputData object and adds to it additional data which
   * is based on the related PDO object.
   */
  private void enrichCurrencyConversionInputData(String sConversionType, CurrencyConversionInputData ccInputData)
  {
    PDO pdo = Admin.getContextPDO();
    
    // BASE rate usage.
    String sBaseRateUsageName = pdo.getString(P_BASE_RATE_USAGE_NM);
    if(!isNullOrEmpty(sBaseRateUsageName))
    {
      RateUsage baseRateUsage = CacheKeys.rateUsageKey.getSingle(sBaseRateUsageName);
      ccInputData.setBaseRateUsage(baseRateUsage);
    }
    
    // CREDIT/DEBIT rate usage.
    // NOTE: Always use the passed 'sConversionType' which stands for the original 
    //       currency conversion request type and not the one from the passed
    //       'CurrencyConversionInputData', because in case of reverse sell it gets
    //       a different value then the original request one.
    String sRateUsageName = sConversionType.equals(ConversionType.Credit.toString()) ?
                            pdo.getString(P_CDT_RATE_USAGE_NM) :
                            pdo.getString(P_DBT_RATE_USAGE_NM);
                            
    if(!isNullOrEmpty(sRateUsageName))
    {
      RateUsage rateUsage = CacheKeys.rateUsageKey.getSingle(sRateUsageName);
      ccInputData.setRateUsage(rateUsage);
    }
  }
  
  /**
   * This method should be called from outer classes, (e.g. BOFeesCalculation),
   * and not from the business flow; for the business flow use the same method with 
   * 'conversion type' as string input parameter.
   * Gets CurrencyConversionInputData and performs currency conversion between the
   * 2 currencies of the input.
   */
  @Expose(type = ExposureType.InternalInterface) 
  public CurrencyConversionOutputData performCurrencyConversion(CurrencyConversionInputData ccInputData) throws CurrencyConversionException
  {
    final String MESSAGE_METHOD_START = "BOCurrencyConversion.performCurrencyConversion - method params: CurrencyConversionInputData.";
    final String EXCEPTION_MESSAGE = "Exception has occured in 'BOCurrencyConversion.performCurrencyConversion'.";
    
    
    logger.info(MESSAGE_METHOD_START);
    
    String sConversionType = ccInputData.getConversionType().toString();
    String sCurrency1 = ccInputData.getCurrency1();
    String sCurrency2 = ccInputData.getCurrency2();
    
    	
    // Rate usage can be null if currency conversion was executed first time from independent services
    // (e.g. fees calculation or PISN).
    if(ccInputData.getRateUsage() == null && ccInputData.getBaseRateUsage() == null)
    {
      PDO pdo = Admin.getContextPDO();
      setRateUsageFields(pdo, sConversionType);
      enrichCurrencyConversionInputData(sConversionType, ccInputData);
    }
    
    logger.info(ccInputData.toString());
  
    CurrencyConversionOutputData ccOutputData = new CurrencyConversionOutputData();
    
    boolean bBaseConversion = sConversionType.equals(ConversionType.Base.toString());
    RateUsage rateUsage = bBaseConversion ? ccInputData.getBaseRateUsage() : ccInputData.getRateUsage();
    
    try
    {
      // Calculates the exchange rate. 
      ExchangeRateOutputData exchangeRateOutputData = calculateExchangeRate(ccInputData);

      // Calculates the converted amount if:
      //    1) No RTR and no cross currency.
      // OR 2) RTR. 
      if(exchangeRateOutputData.isValidExchangeRateData())
      {
        Double dConvertedAmount = calculateConvertedAmount(exchangeRateOutputData, ccInputData.getAmountToConvert(), 
                                                           sCurrency1, sCurrency2, null, ccInputData.isToAdjustPrecision());
        
        ccOutputData.setConvertedAmount(dConvertedAmount);
        ccOutputData.setExchangeRateOutputData(exchangeRateOutputData);
        ccOutputData.setRate(exchangeRateOutputData.getRate());
        
        ExchrateCfg oExchrateCfg = exchangeRateOutputData.getExchrateCfg();
        int iRateAccuracy = oExchrateCfg != null ? oExchrateCfg.getDecNo().intValue() : 1;
        ccOutputData.setRateAccuracy(iRateAccuracy);
      }
      
      // No exchange rate was found for the currency pair, and it WASN'T as a result of one of the following:
      //    1) Error that has stopped the process, according to related array, (ARR_PROCESS_ERROR_TYPES_FOR_UN_COMPLETED_EXCHANGE_RATE_CALC_PROCESS).
      // OR 2) BASE conversion failure for which the CurrencyConversionInputData input parameter doesn't
      //       have its 'm_bUseBaseRateUsageAsFailover' class member as true.
      //       In case it is true, we will continue to cross currency conversion and we'll use the BASE rate usage
      //       during the cross currency process; e.g. when the call is from PISN matching.
      // OR 3) EXCHARTE_BU was found, (either because it exists or because it was created as a dummy object in RTR case).
      // Continues to cross currency conversion.
      else if(   !exchangeRateOutputData.includesError(ARR_PROCESS_ERROR_TYPES_FOR_UN_COMPLETED_EXCHANGE_RATE_CALC_PROCESS)
              && !(sConversionType.equals(ConversionType.Base.toString()) && !ccInputData.useBaseRateUsageAsFailover())
              && exchangeRateOutputData.getExchrateBu() == null)
      {
        // Prepares the input data object for the 'performCrossCurrencyConversion' call.
        CrossCurrencyConversionInputData crossCCInputData = new CrossCurrencyConversionInputData(ccInputData);
        
        // This might be null.
        crossCCInputData.setExchrateCfg(exchangeRateOutputData.getExchrateCfg());
        
        // Returned object type is CrossCurrencyConversionOutputData.
        ccOutputData = performCrossCurrencyConversion(crossCCInputData);
        
        // During cross currency, we might have one process error, which can be: 
        // 1) Triangulation currency problem; see the 'getTriangulationCurrency' method.
        // OR
        // 2) An error which was raised during one of the 2 calls which are made
        //    to the 'calculateExchangeRate' method.
        boolean bCrossCurrencySuccess = ccOutputData.getProcessErrorHolder().getProcessError(0) == null;
        
        // Cross currency has failed; loops the errors which were raised during 
        // the 'calculateExchangeRate' method, which its failure has led to the 
        // cross currency process, and:
        // 1) Adds each error to the PDO, (this wasn't done there because the cross
        //    currency process might have succeed and thus these error wouldn't 
        //    have been relevant.
        // 2) Adds each error to the CurrencyConversionOutputData object, which
        //    currently includes only errors which were raised during the cross 
        //    currency process.
        if(!bCrossCurrencySuccess)
        {
          List<ProcessError> listExchangeRateOutputDataErrors = exchangeRateOutputData.getErrors();
          for(ProcessError processError : listExchangeRateOutputDataErrors)
          {
            ErrorAuditUtils.setErrors(processError);
            ccOutputData.addError(processError);
          }
        }
      }
      
      // The first error will be one of the errors in the ARR_PROCESS_ERROR_TYPES_FOR_UN_COMPLETED_EXCHANGE_RATE_CALC_PROCESS
      // array; adds this error to the CurrencyConversionOutputData object.
      else
      {
      	List<ProcessError> listErrors = exchangeRateOutputData.getErrors();
      	ProcessError processError = !isListNullOrEmpty(listErrors) ? listErrors.get(0) : PROCESS_ERROR_CURRENCY_CONVERSION_FAILURE;
        ccOutputData.addError(processError);
        ErrorAuditUtils.setErrors(processError);
      }

      // No process errors which have stopped the process have been raised.
      if(!ccOutputData.includesError(ARR_PROCESS_ERROR_TYPES_FOR_UN_COMPLETED_CURRENCY_CONVERSION_PROCESS))
      {
        // We need to calculate the equivalent amount; i.e. need to convert the 
        // input amount to the base currency, (which will be used as currency 2), 
        // and set the value into the 'CurrencyConversionOutputData ' output parameter.
        if(ccInputData.calculateEquivalentAmount())
        {
          Double dEquivalentAmount = calculateEquivalentAmount(ccInputData, ccOutputData.getConvertedAmount());
          ccOutputData.setEquivalentAmount(dEquivalentAmount);
        }
        
        // Performs validations.
        if(ccInputData.shouldPerformValidations())
        {
        	// Threshold should not be performed in base conversion. 
        	if(   sConversionType != ConversionType.Base.toString()
        		 && ccInputData.shouldPerformThresholdValidation()	)
        	{
        		validateThreshold(ccInputData, ccOutputData, true, null);
        	}
          validateExpiryDate(ccInputData, ccOutputData);
        }
      }
      
      // Sets the output data with a flag that notifies the caller method that
      // the process hasn't been completed, (e.g. for fees calculation).
      else
      {
        ccOutputData.setProcessHasCompleted(false);
      }
    }
    
    catch(Exception e)
    {
      ExceptionController.getInstance().handleException(e, this);
      throw new CurrencyConversionException(EXCEPTION_MESSAGE, e);
    }
    
    
    
    return ccOutputData;
  }
  
  /**
   * Returns ExchangeRateOutputData object for the passed CurrencyConversionInputData
   * input parameter.
   */
  private ExchangeRateOutputData calculateExchangeRate(CurrencyConversionInputData ccInputData) throws CurrencyConversionException
  {
    final String TRACE_MESSAGE_ACTION_TYPE_TO_PERFORM = "Action type to perform is {}.";
    final String TRACE_RATE_USAGE_INTERFACE_NAME = "Rate usage interface name: {}.";
    final String TRACE_CONDITION_DATA = "IF condition data - P_FC_INFO_IND: {}, Conversion type: {}, Rate (P_DBT_RATE or P_CDT_RATE): {}.";
    final String TRACE_WARNING_NULL_EXCHRATE_BU = "WARNING (might cause currency conversion failure): Null EXCHRATE_BU record for currency pair {}.";
    
    

    String sConversionType = ccInputData.getConversionType().toString();
    
    String sCurrency1 = ccInputData.getCurrency1();
    String sCurrency2 = ccInputData.getCurrency2();
    
    String sInputData = new StringBuilder(CURRENCY_1).append(sCurrency1)
                                  .append(CURRENCY_2).append(sCurrency2).toString();                       
    logger.info(sInputData);
  
    ExchangeRateOutputData exchangeRateOutputData = new ExchangeRateOutputData();

    String sCurrencyPair = ccInputData.getOrderedCurrencyPair();
    String sOffice = ccInputData.getOffice();
    
    boolean bBaseConversion = sConversionType.equals(ConversionType.Base.toString());
    RateUsage rateUsage = bBaseConversion ? ccInputData.getBaseRateUsage() : ccInputData.getRateUsage();
    
    ProcessError processError = null;
                          
    // Valid rate usage configuration.
    if(rateUsage != null)
    {
      String sRateUsageType = rateUsage.getRateType();
      
      PDO pdo = Admin.getContextPDO();
      String sP_FC_INFO_IND = pdo.getString(P_FC_INFO_IND);
  		boolean bDebitConversion = sConversionType.equals(ConversionType.Debit.toString());
  		BigDecimal bdRate = bDebitConversion ? pdo.getDecimal(P_DBT_RATE) : pdo.getDecimal(P_CDT_RATE);
  		
  		logger.info(TRACE_CONDITION_DATA,  new Object[]{ sP_FC_INFO_IND, sConversionType, bdRate});   
  		
      // No external rate; rate should be caclculated using application setup or only indactive rate is required.
    	if(!FC_INFO_IND_RTR.equals(sP_FC_INFO_IND) || bdRate == null || bBaseConversion)
    	{
        // Tries to get the EXCHRATE_BU data.
        ExchrateBu oExchrateBu = CacheKeys.exchrateBuKey.getSingle(sCurrencyPair, sOffice, sRateUsageType);
        if (oExchrateBu == null) {
        	//fall back in case the currencies are not set in  ExchrateBu using their lexicographical order
        	String fallbackCurrencyPair  = sCurrency1.compareTo(sCurrency2) < 0 ? sCurrency2 + sCurrency1 :
        		sCurrency1 + sCurrency2;
        	oExchrateBu = CacheKeys.exchrateBuKey.getSingle(fallbackCurrencyPair, sOffice, sRateUsageType);
        	if (oExchrateBu != null) {
        		logger.info("Found exchrateBu entry using fallback currency pairs: {}", fallbackCurrencyPair);
        		sCurrencyPair = fallbackCurrencyPair;
        	}
        }

        // Currency pair isn't defined in the EXCHRATE_BU table.
        if(oExchrateBu == null)
        {
        	// In case one of the currencies is invalid, adds an error message and process will be stopped
        	// in the caller method and WON'T continue to cross currency.
        	String sInvalidCurrency = null;
        	boolean bInvalidCurrency = CacheKeys.currencyCfgKey.getSingle(sCurrency1) == null;
        	//
        	if(bInvalidCurrency) sInvalidCurrency = sCurrency1;
        	else // Checks currency 2.
        	{
        		bInvalidCurrency = CacheKeys.currencyCfgKey.getSingle(sCurrency2) == null;
        		if(bInvalidCurrency) sInvalidCurrency = sCurrency2;
        	}
        	
        	if(bInvalidCurrency)
        	{
	          // Error code 60087: '|1 is an invalid currency'.
	          processError = new ProcessError(ProcessErrorConstants.InvalidCurrency, new Object[]{sInvalidCurrency});
	          exchangeRateOutputData.getProcessErrorHolder().addError(processError);
        	}
        	
        	
        	
        	else
        	{
          	 logger.info(ERROR_MESSAGE_CURRENCY_PAIR_NOT_DEFINE, new Object[] {sCurrency1, sCurrency2});
       		 processError = new ProcessError(ProcessErrorConstants.CurrencyPairNotDefine);
       		
                // Error code 40001 - Currency pair not defined in Exchange Rate Info.
                exchangeRateOutputData.getProcessErrorHolder().addError(processError);
            
 	        
        	}

        	// In general, process will continue to cross currency later on, (unless an invalid currency was found earlier).
        	// If in the caller method, the conditions for continuing to cross currency won't be fulfilled, then we'll
        	// have currency onversion failure, (error code 40264), which is actually caused by the above null oExchrateBu object.
        	exchangeRateOutputData.setValidExchangeRateData(false);
        }
        
        // Currency pair is defined in the EXCHRATE_BU table.
        else
        {
        	exchangeRateOutputData.setExchrateBu(oExchrateBu);
        	
          // Tries to get the EXCHRATE_CFG data.
          ExchrateCfg oExchrateCfg = CacheKeys.exchrateCfgKey.getSingle(sCurrencyPair, sOffice);
          
          // Currency pair isn't defined in the EXCHRATE_CFG table; shouldn't occur.
          
          if(oExchrateCfg == null)
          {
            exchangeRateOutputData.setValidExchangeRateData(false);
            
            logger.info(ERROR_MESSAGE_NO_EXCHRATE_CFG_RECORD, new Object[] {sCurrency1, sCurrency2, sRateUsageType, sOffice});
            
            // Error code 60075: 'Illegal state; EXCHRATE_BU record exists without related EXCHRATE_CFG record'.
            exchangeRateOutputData.getProcessErrorHolder().addError(PROCESS_ERROR_ILLEGAL_STATE_EXCHRATE_BU_WITH_NO_EXCHRATE_CFG);
          }
          
          // Currency pair is defined in the EXCHRATE_CFG table.
          else
          {
          	// Currency pair was found; i.e. this is a direct currency conversion.
          	exchangeRateOutputData.setExchrateCfg(oExchrateCfg);
          	
            exchangeRateOutputData.setDirectConversion(sCurrency1.equals(oExchrateBu.getCcy1()) ? true : false);
            
	          // Finds the action type we need to perform; value can be either 'Buy', 'Sell' or 'Mid'.
	          ActionType actionType = determineActionType(ccInputData.getConversionType(), exchangeRateOutputData.isDirectConversion());
	          logger.info(TRACE_MESSAGE_ACTION_TYPE_TO_PERFORM, actionType);
	  
	          // STEP 3 - 
	          // Calculates the rate itself.
	          determineFinalExchangeRate(rateUsage, ccInputData.getApplySpread(), actionType, exchangeRateOutputData);
          }
        }
    	}
    	
    	// RTR, (real time rate).
    	else
    	{
    		handleRealTimeRate(exchangeRateOutputData, sConversionType, rateUsage.getInterfaceName(), ccInputData, sRateUsageType);
    	}
    }
    
    // No rate usage was found - can't continue the process.
    else
    {
      exchangeRateOutputData.setValidExchangeRateData(false);
      
      final String OFFICE = "office";
      final String CUST_CODE = "customer code";
      
      String sGuiltyPartyLabel = null;
      String sGuiltyPartyValue = null;
        
      if(sConversionType.equals(ConversionType.Base.toString()))
      {
        sGuiltyPartyLabel = OFFICE;
        sGuiltyPartyValue = sOffice;
      }
      else
      {
        sGuiltyPartyLabel = CUST_CODE;
        
        PDO pdo = Admin.getContextPDO();
        
        if(sConversionType.equals(ConversionType.Debit.toString()))
        {
          Customrs debitCustomer = pdo.getNSetDEBIT_CUSTOMER();
          sGuiltyPartyValue = debitCustomer != null ? debitCustomer.getCustCode() : ServerConstants.EMPTY_STRING;
        }
        else // Credit
        {
          Customrs creditCustomer = pdo.getNSetCREDIT_CUSTOMER();
          sGuiltyPartyValue = creditCustomer != null ? creditCustomer.getCustCode() : ServerConstants.EMPTY_STRING;
        }
      }
      
      boolean bForThresholdValidation = ccInputData.isForThresholdValidation();
      
      // ERROR: 'calculateExchangeRate' - no %s rate usage is defined for %s %s. Call was for threshold validation = %s.
      logger.info(ERROR_MESSAGE_NULL_RATE_USAGE, new Object[] {sConversionType, sGuiltyPartyLabel, sGuiltyPartyValue, bForThresholdValidation});

      Object[] arrNonPaymentFields = new Object[]{sConversionType, sGuiltyPartyLabel, sGuiltyPartyValue};

      // Error code 40017: 'No |1 rate usage is defined for |2 |3'.
      processError = new ProcessError(ProcessErrorConstants.MissingRateUsageSetup, arrNonPaymentFields);
      exchangeRateOutputData.getProcessErrorHolder().addError(processError);
      ErrorAuditUtils.setErrors(processError);
    }
    
    
    
    return exchangeRateOutputData;
  }
  
  /**
   * 
   */
  private boolean checkRTRConditions(CurrencyConversionInputData ccInputData, ProcessError[] arrProcessErrorHolder)
  {
  	final String TRACE_CONDITION_DATA = "IF condition data - Rate usage interface name: {}, boolD_IS_CONT_FLOW_UNTIL_HANDOFF: {}, P_FC_INFO_IND: {}, Conversion type: {}, Rate (P_DBT_RATE or P_CDT_RATE): {}.";
  	final String TRACE_D_EVENT_RELEASE_INDEX_SETUP = "Sets D_EVENT_RELEASE_INDEX to {}";
  	
  	
  	
  	boolean bWaitForRTR = false;
  	
  	PDO pdo = Admin.getContextPDO();
  	Boolean boolD_IS_CONT_FLOW_UNTIL_HANDOFF = pdo.getBoolean(D_IS_CONT_FLOW_UNTIL_HANDOFF);
  	
  	String sConversionType = ccInputData.getConversionType().toString();

    if(ccInputData.getRateUsage() == null || ccInputData.getBaseRateUsage() == null)
    {
      setRateUsageFields(pdo, sConversionType);
      enrichCurrencyConversionInputData(sConversionType, ccInputData);
    }
    
    if (ccInputData.getRateUsage() == null)
    {
    	logger.warn("Rate Usage couldn't be derived. Invalid setup?");
    	return false;
    }

    boolean bBaseConversion = sConversionType.equals(ConversionType.Base.toString());
    RateUsage rateUsage = bBaseConversion ? ccInputData.getBaseRateUsage() : ccInputData.getRateUsage();
    String sRateUsageInterfaceName = rateUsage.getInterfaceName();
    
    String sP_FC_INFO_IND = pdo.getString(P_FC_INFO_IND);
		boolean bDebitConversion = sConversionType.equals(ConversionType.Debit.toString());
		BigDecimal bdRate = bDebitConversion ? pdo.getDecimal(P_DBT_RATE) : pdo.getDecimal(P_CDT_RATE);
		
		logger.info(TRACE_CONDITION_DATA,  new Object[]{ sRateUsageInterfaceName, boolD_IS_CONT_FLOW_UNTIL_HANDOFF, sP_FC_INFO_IND, sConversionType, bdRate});
		
    // We are in final approval stage of the message.
  	if(   sRateUsageInterfaceName != null
  		 && (boolD_IS_CONT_FLOW_UNTIL_HANDOFF == null || !boolD_IS_CONT_FLOW_UNTIL_HANDOFF)
  		 && (!FC_INFO_IND_RTR.equals(sP_FC_INFO_IND) || bdRate == null) )
  	{
  		String sP_RATE_REQ_STATUS = pdo.getString(P_RATE_REQ_STATUS);
  		
  		if(bBaseConversion)
  		{
  			// Illegal setup; rate usage that is used for BASE conversion can't hold an external rate interface name.
    		// Error code 60073: 'Rate usage used for BASE conversion cannot hold external rate interface name (|1)'. 
        Object[] arrNonPaymentFields = new Object[]{(sRateUsageInterfaceName)};
        arrProcessErrorHolder[0] = new ProcessError(ProcessErrorConstants.RTRIllegalSetupRateUsageUsedForBaseConversionHoldsExtranalRateInterfaceName, arrNonPaymentFields);
        ErrorAuditUtils.setErrors(arrProcessErrorHolder[0],pdo.getIsHistory());
  		}
  		
    	// Payment ISN'T part of manual acceptance process. 
  		else if(   !BORTR.REQ_STS_QUOTE_RECEIVED.equals(sP_RATE_REQ_STATUS)
  			      && !BORTR.REQ_STS_QUOTE_ACCEPTED.equals(sP_RATE_REQ_STATUS) 
  			      && !BORTR.REQ_STS_TRADE_BOOK_RECEIVED.equals(sP_RATE_REQ_STATUS) )
  		{
  			Customrs origInitiatingCustomer = pdo.getNSetORIG_INITIATING_CUSTOMER();
  			Customrs debitCustomer = pdo.getNSetDEBIT_CUSTOMER();
  			Long longP_CUST_BASE_AMT = pdo.getLong(P_CUST_BASE_AMT);
  			Long longP_BASE_AMT = pdo.getLong(P_BASE_AMT);
  			
  			final String TRACE_DATA = "Orig initiating customer: {}, {}Debit customer: {}, {}P_CUST_BASE_AMT: {}, P_BASE_AMT: {}.";
  			final String ORIG_INITIATING_CUSTOMER_TRADE_PREF = "Orig initiating customer trade pref: {}, ";
  			final String DEBIT_CUSTOMER_TRADE_PREF = "Debit customer trade pref: {}, ";
  			
  			String sOrigInitiatingCustomerTradePref = ServerConstants.EMPTY_STRING;
  			if(origInitiatingCustomer != null) sOrigInitiatingCustomerTradePref = String.format(ORIG_INITIATING_CUSTOMER_TRADE_PREF, origInitiatingCustomer.getTradePref());

  			String sDebitCustomerTradePref = ServerConstants.EMPTY_STRING;
  			if(debitCustomer != null) sDebitCustomerTradePref = String.format(DEBIT_CUSTOMER_TRADE_PREF, debitCustomer.getTradePref());
  			
  			logger.info(TRACE_DATA,  new Object[]{ origInitiatingCustomer, sOrigInitiatingCustomerTradePref, debitCustomer, sDebitCustomerTradePref, longP_CUST_BASE_AMT, longP_BASE_AMT});
  			
  			// If CUSTOMRS.TRADE_PREF is 1, then it means that we're in manual approval; i.e. payment
  			// needs to be handled in manual rate acceptance channel.
  			if(   (    origInitiatingCustomer != null 
  				     && ServerConstants.ONE_VALUE.equals(origInitiatingCustomer.getTradePref())
  				     && (origInitiatingCustomer.getTradeThresh() != null && longP_CUST_BASE_AMT != null && origInitiatingCustomer.getTradeThresh() < longP_CUST_BASE_AMT))
  				 || (   origInitiatingCustomer == null && debitCustomer != null
  				     && ServerConstants.ONE_VALUE.equals(debitCustomer.getTradePref())
  				     && (debitCustomer.getTradeThresh() != null && longP_BASE_AMT != null && debitCustomer.getTradeThresh() < longP_BASE_AMT))) 
  			{
          logger.info(ERROR_MESSAGE_MANUAL_TRADE_IS_REQUIRED);
  				
  				// Error code 60071: 'Manual trade is required'. 
          arrProcessErrorHolder[0] = PROCESS_ERROR_RTR_MANUAL_TRADE_IS_REQUIRED;
          ErrorAuditUtils.setErrors(PROCESS_ERROR_RTR_MANUAL_TRADE_IS_REQUIRED);
  			}
  			
  			// Manual trade ISN'T required.
  			else
  			{
  				bWaitForRTR = true;
  				
  				// In case of WAIT_RTR, we want the payment to pass full process except for the handoff & accounting stage.
  				// See logic of that field in the 'BOHighValueProcess.handoffAndAccountingSubFlow' method.
    			pdo.set(D_PARKING_MSG_STS, MessageConstantsInterface.MESSAGE_STATUS_WAIT_RTR);
    			
    			// This one shouldn't be null.
    			String sP_ORG_INITG_PTY_CUST_CD = pdo.getString(P_ORG_INITG_PTY_CUST_CD);
    			if(sP_ORG_INITG_PTY_CUST_CD == null) // Shouldn't occur.
    			{
    				final String NULL_ORG_INITG_PTY_CUST_CD = "ERROR: P_ORG_INITG_PTY_CUST_CD is null and won't be attched to D_EVENT_RELEASE_INDEX !";
    				sP_ORG_INITG_PTY_CUST_CD = ServerConstants.EMPTY_STRING;
    			}
    			
    			Boolean boolP_RVS_SELL = pdo.getBoolean(P_RVS_SELL);
    			String sP_RVS_SELL = boolP_RVS_SELL != null && boolP_RVS_SELL ? ServerConstants.ONE_VALUE : ServerConstants.ZERO_VALUE; 
    			
      		String sD_EVENT_RELEASE_INDEX = new StringBuilder(sP_ORG_INITG_PTY_CUST_CD).append(ServerConstants.POWER_SIGN)
      		                                          .append(pdo.getString(X_STTLM_DT_1B)).append(ServerConstants.POWER_SIGN)
      		                                          .append(pdo.getString(X_STTLM_CCY)).append(ServerConstants.POWER_SIGN)
      		                                          .append(pdo.getString(P_DBT_ACCT_CCY)).append(ServerConstants.POWER_SIGN)
      		                                          .append(sP_RVS_SELL).toString();
      		pdo.set(D_EVENT_RELEASE_INDEX, sD_EVENT_RELEASE_INDEX);
      		logger.info(TRACE_D_EVENT_RELEASE_INDEX_SETUP, sD_EVENT_RELEASE_INDEX);
  			}
  		}
  	}
  	
  	
  	
  	return bWaitForRTR;
  }
  
  /**
   * @param sOriginalCurrency1 currency 1 of the original pair of currencies that requires conversion.
   * @param sOriginalCurrency2 currency 2 of the original pair of currencies that requires conversion.
   */
  private void handleRealTimeRate(ExchangeRateOutputData exchangeRateOutputData, String sConversionType, String sRateUsageInterfaceName,
  		                            CurrencyConversionInputData ccInputData, String sRateUsageType)
  {
  	
  	
  	String sOriginalCurrency1 = ccInputData.getOriginalCurrency1();
  	String sOriginalCurrency2 = ccInputData.getOriginalCurrency2();
  	
  	String sCurrency1 = ccInputData.getCurrency1();
  	String sCurrency2 = ccInputData.getCurrency2();
  	
  	String sCurrencyPair = ccInputData.getOrderedCurrencyPair();
  	
  	PDO pdo = Admin.getContextPDO();
  	String sOffice = pdo.getString(P_OFFICE);
		String sP_RATE_REQ_STATUS = pdo.getString(P_RATE_REQ_STATUS);
		String sP_FC_INFO_IND = pdo.getString(P_FC_INFO_IND);
		
		final String TRACE_USED_RATE = "Final rate taken from {}: {}.";
		final String TRACE_NULL_RATE = "ERROR: {} holds null rate value; final rate can't be determined !";
		
		// Note that in case of BASE conversion, we shouldn't arrive here, as the interface name for such rate usage shouldn't be defined,
		// and process should have raised an error in an earlier stage.
		boolean bDebitConversion = sConversionType.equals(ConversionType.Debit.toString());
		BigDecimal bdRate = bDebitConversion ? pdo.getDecimal(P_DBT_RATE) : pdo.getDecimal(P_CDT_RATE);
		
		// Determines direct/indirect conversion; returned value can't be null.
		String[] arrOrderedCurrencies = determineCurrenciesOrder(pdo.getString(P_OFFICE), sOriginalCurrency1, sOriginalCurrency2);
		exchangeRateOutputData.setDirectConversion(arrOrderedCurrencies[0].equals(sOriginalCurrency1) ? true : false);
		
		Double dRate = bdRate.doubleValue();
		logger.info(TRACE_USED_RATE, (bDebitConversion ? P_DBT_RATE : P_CDT_RATE), dRate);
		exchangeRateOutputData.setRate(dRate);
		
		// If required, creates dummy objects for EXCHRATE_BU & EXCHRATE_CFG records.
    ExchrateBu oExchrateBu = CacheKeys.exchrateBuKey.getSingle(sCurrencyPair, sOffice, sRateUsageType);
    ExchrateCfg oExchrateCfg = CacheKeys.exchrateCfgKey.getSingle(sCurrencyPair, sOffice);
    
    if(oExchrateBu == null)
    {
    	oExchrateBu = new ExchrateBu();
    	
    	oExchrateBu.setCcy1(arrOrderedCurrencies[0]);
    	oExchrateBu.setCcy2(arrOrderedCurrencies[1]);
    	
    }
    exchangeRateOutputData.setExchrateBu(oExchrateBu);

    if(oExchrateCfg == null)
    {
    	oExchrateCfg = new ExchrateCfg();
    	
    	oExchrateCfg.setCcy1(arrOrderedCurrencies[0]);
    	oExchrateCfg.setCcy2(arrOrderedCurrencies[1]);
    	
    	oExchrateCfg.setCcy1Unit(LONG_ONE);
    	oExchrateCfg.setCcy2Unit(LONG_ONE);

    	String sRate = String.valueOf(dRate);
    	int iLastDotIndex = sRate.lastIndexOf(ServerConstants.DOT);
    	int iRateAccuracy = iLastDotIndex == -1 ? 0 : sRate.length() - iLastDotIndex - 1;
    	oExchrateCfg.setDecNo(Long.valueOf(iRateAccuracy));
    }
    exchangeRateOutputData.setExchrateCfg(oExchrateCfg);

  	
  }
  
  /**
   * 
   */
  public static String[] determineCurrenciesOrder(String sOffice, String sCurrency1, String sCurrency2)
  {
  	
  	
  	final String TRACE_METHOD_INPUT = "Method input - Currency 1: {}, Currency 2: {}.";
  	final String TRACE_METHOD_OUTPUT = "Method output - Currency 1: {}, Currency 2: {}.";
  	
  	final String TRACE_VALID_EXCHRATE_CFG = "Found valid EXCHRATE_CFG record for currency pair {}.";
  	final String TRACE_SET_DEFAULT_ORDER = "Can't determine currencies order according to EXCHRATE_CFG or CURRENCY_CFG.RANKING; order remains the same as sent to the method.";
  	
  	String[] arrOrderedCurrencies = null;
  	
  	logger.info(TRACE_METHOD_INPUT, sCurrency1, sCurrency2);
  	
  	// NOTE:
  	// No need to check if there is an entry in EXCHRATE_BU table for the passed currencies, as
  	// if it exists, then there is also EXCHRATE_CFG record that will be used later on.
  	
  	// STEP 1 - 
  	// Determine according to EXCHRATE_CFG setup.
  	//
  	// Creates CCY pair for cache needs.
  	if(sCurrency1 == null) sCurrency1 = ServerConstants.EMPTY_STRING;
  	if(sCurrency2 == null) sCurrency2 = ServerConstants.EMPTY_STRING;
  	String sCurrencyPair = sCurrency1.compareTo(sCurrency2) < 0 ? sCurrency1 + sCurrency2 : sCurrency2 + sCurrency1;
    ExchrateCfg oExchrateCfg = CacheKeys.exchrateCfgKey.getSingle(sCurrencyPair, sOffice);
    
    if(oExchrateCfg != null)
    {
    	logger.info(TRACE_VALID_EXCHRATE_CFG, sCurrencyPair);
    	arrOrderedCurrencies = new String[]{oExchrateCfg.getCcy1(), oExchrateCfg.getCcy2()};
    }
    
    // STEP 2 - 
  	// Determine according to CURRENCY_CFG.RANKING setup.
    if(arrOrderedCurrencies == null)
    {
    	arrOrderedCurrencies = determineCurrenciesOrderAccordingToRanking(sOffice, sCurrency1, sCurrency2);
    }
    
    // If value is still null, set order according to original order as sent to this method.
    if(arrOrderedCurrencies == null)
    {
    	logger.info(TRACE_SET_DEFAULT_ORDER);
    	arrOrderedCurrencies = new String[]{sCurrency1, sCurrency2};
    }
    
    logger.info(TRACE_METHOD_OUTPUT, arrOrderedCurrencies[0], arrOrderedCurrencies[1]);
  	
  	
  	
  	return arrOrderedCurrencies;
  }
  
  /**
   * 
   */
  private static String[] determineCurrenciesOrderAccordingToRanking(String sOffice, String sCurrency1, String sCurrency2)
  {
  	
  	
  	final String TRACE_METHOD_INPUT = "Method input - Office: {}, Currency 1: {}, Currency 2: {}.";
  	final String TRACE_RANKING_DATA = "Determines order according to ranking - Currency 1 ({}) ranking: {}, Currency 2 ({}) ranking: {}.";
  	final String TRACE_CANNOT_DETERMINE_ORDER = "Can't determine currencies order according to CURRENCY_CFG.RANKING.";
  	
  	String[] arrOrderedCurrencies = null;
  	
  	logger.info(TRACE_METHOD_INPUT, new Object[] {sOffice, sCurrency1, sCurrency2});
  	
  	// Both can't be null !!!
    CurrencyCfg currencyCfgCurrency1 = CacheKeys.currencyCfgKey.getSingle(sCurrency1);
    CurrencyCfg currencyCfgCurrency2 = CacheKeys.currencyCfgKey.getSingle(sCurrency2);
    
    if(   currencyCfgCurrency1 != null && currencyCfgCurrency2 != null
    	 && currencyCfgCurrency1.getRanking() != null && currencyCfgCurrency2.getRanking() != null)
    {
    	Long lCurrency1Ranking = currencyCfgCurrency1.getRanking();
    	Long lCurrency2Ranking = currencyCfgCurrency2.getRanking();
    	logger.info(TRACE_RANKING_DATA, new Object[] {sCurrency1, lCurrency1Ranking, sCurrency2, lCurrency2Ranking});
    	
    	arrOrderedCurrencies = lCurrency1Ranking < lCurrency2Ranking ? new String[]{sCurrency1, sCurrency2} : new String[]{sCurrency2, sCurrency1};
    }
    
    else
    {
    	logger.info(TRACE_CANNOT_DETERMINE_ORDER);
    }
    
  	
  	
  	return arrOrderedCurrencies;
  }
  
  /**
   * Determines the action type to perform for the 'calculateExchangeRate' method.
   * Value can be either 'Buy', 'Sell' or 'Mid'.
   */
  private ActionType determineActionType(ConversionType conversionType, boolean bDirectConversion)
  {
    
    
    ActionType actionType = null;
    
    if(conversionType == ConversionType.Mid)
    {
      actionType = ActionType.Mid;
    }
    //
    // Direct conversion.
    else if(bDirectConversion)
    {
      actionType = conversionType == ConversionType.Credit ? ActionType.Buy : ActionType.Sell;
    }
    //
    else // Indirect conversion.
    {
      actionType = conversionType == ConversionType.Credit ? ActionType.Sell : ActionType.Buy;
    }
    
    
    
    return actionType;
  }
  
  /**
   * Determines the final exchange rate for the 'calculateExchangeRate' method.
   */
  private void determineFinalExchangeRate(RateUsage rateUsage, boolean bApplySpread,
                                          ActionType actionType,
                                          ExchangeRateOutputData exchangeRateOutputData) throws CurrencyConversionException
  {
    final String EXCEPTION_MESSAGE_INVALID_POINTS_DISCOUNT = "ERROR: BOCurrencyConversion.determineFinalExchangeRate - invalid points discount; calculated rate after discount <= 0. Points discount = {}, Final rate = {}.";
    
    
    
    ExchrateBu oExchrateBu = exchangeRateOutputData.getExchrateBu();
    Double dMidRate = oExchrateBu.getMidRate();
    Double dHighRate = oExchrateBu.getHighRate();
    Double dLowRate = oExchrateBu.getLowRate();
    Double dSpreadUp = oExchrateBu.getSpreadUp();
    Double dSpreadDown = oExchrateBu.getSpreadDown();

    Double dRate = null;
    Double dFinalRate = null;
    
    Double dSpread = null;
    
    // STEP 1 - 
    // Initializes the basic rate value according to the action type.
    if(actionType.equals(ActionType.Mid))
    {
      dRate = dMidRate != null ? dMidRate : (dLowRate + dHighRate) / 2;
    }
    else 
    {
      if(actionType.equals(ActionType.Sell))
      {
        dRate = dHighRate;
        dSpread = dSpreadUp;
      }
      
      else // actionType is 'Buy'
      {
        dRate = dLowRate;
        dSpread = dSpreadDown;
      }
    }
    
    dFinalRate = dRate;
    
    // STEP 2 - 
    // Updates the basic rate from previous step according to points discount.
    Double dLowRateDiscountPoints = rateUsage.getLowRateDisPts() != null ? rateUsage.getLowRateDisPts() : 0;
    Double dHighRateDiscountPoints = rateUsage.getHighRateDisPts() != null ? rateUsage.getHighRateDisPts() : 0;

    //
    // Note: in case action type is 'Mid', no points discount from RATE_USAGE profile is applied.
    //
    // Action type 'Sell'.
    if(actionType.equals(ActionType.Sell))
    {
      if(bApplySpread)
      {
        dFinalRate = dRate - dHighRateDiscountPoints;
      }

      // If final rate after discount is 0 or negative, (i.e. discount equals the 
      // originial rate or higher then originial rate), throws an exception.
      if(dFinalRate <= 0)
      {
        String sExceptionMessage = String.format(EXCEPTION_MESSAGE_INVALID_POINTS_DISCOUNT, dHighRateDiscountPoints, dFinalRate);
        throw new CurrencyConversionException(sExceptionMessage);
      }
    }
    //
    // Action type 'Buy'.
    else if(actionType.equals(ActionType.Buy))
    {
      if(bApplySpread)
      {
        dFinalRate = dRate + dLowRateDiscountPoints;
      }
    }

    // STEP 3 - 
    // Determines the rate accuracy & applies it.
    Object[] arrRateAndAccuracy = adjustRateToPrecision(dFinalRate, exchangeRateOutputData.getExchrateCfg());
    dFinalRate = (Double)arrRateAndAccuracy[0];
    int iRateAccuracy = ((Integer)arrRateAndAccuracy[1]).intValue();

    exchangeRateOutputData.setRate(dFinalRate);
    exchangeRateOutputData.setMidRate(dMidRate);
    exchangeRateOutputData.setSpread(dSpread);

    logger.info(exchangeRateOutputData.toString());
    
    
  }
  
  /**
   * Gets a rate and an and an ExchrateCfg object and adjusts the rate 
   * according to the rate precision as defined in EXCHRATE_CFG table for
   * the related currency pair.
   */
  private Object[] adjustRateToPrecision(Double dOriginalRate, ExchrateCfg oExchrateCfg)
  {
    int iRateAccuracy = oExchrateCfg != null ? oExchrateCfg.getDecNo().intValue() : 1;
    BigDecimal bdFinalRate = new BigDecimal(dOriginalRate).setScale(iRateAccuracy, RoundingMode.HALF_UP);
    
    return new Object[]{new Double(bdFinalRate.doubleValue()), iRateAccuracy};
  }
  
  /**
   * Calculates converted amount according to the passed input parameters. 
   */
  private Double calculateConvertedAmount(ExchangeRateOutputData exchangeRateOutputData, 
                                          Double dAmountToConvert, 
                                          String sCurrency1, String sCurrency2, 
                                          Double dForwardContractRateToUse, boolean isToAdjustPrecision) throws CurrencyConversionException
  {
    final String INPUT_DATA = "Input data: Currency 1 = {}, Currency 2 = {}, Amount to convert = {}, Forward contract rate = {}, Direct conversion = {}."; 
    final String METHOD_RESULTS = "Method results: Converting rate = {}, Converted amount = {}, Currency 1 ({}) units = {}, Currency 2 ({}) units = {}.";
    final String MESSAGE_NON_VALID_EXCHRATE_CFG_OBJECT = "'BOCurrencyConversion.calculateConvertedAmount' - null ExchrateCfg object was received; can't perform amount conversion !!!";

    
    
    boolean bDirectConversion = exchangeRateOutputData.isDirectConversion();
      
    logger.info(INPUT_DATA, new Object[] {sCurrency1, sCurrency2, dAmountToConvert, dForwardContractRateToUse, bDirectConversion});
    
    Double dConvertedAmount = null;
    
    ExchrateCfg exchrateCfg = exchangeRateOutputData.getExchrateCfg();

    if(exchrateCfg != null)
    {
      // STEP 1 - 
      // Determines the currency 1 units & currency 2 units.
      Long lCurrency1Unit, lCurrency2Unit;
      
      // Since the GUI doesn't force a correlation between EXCHRATE_CFG.CCY1 to EXCHRATE_BU.CCY1, (and the same for CCY2 column),
      // then in order to determine the right units to use, we need to compare these values.
      if(exchrateCfg.getCcy1().equals(exchangeRateOutputData.getExchrateBu().getCcy1()))
      {
        lCurrency1Unit = exchrateCfg.getCcy1Unit();
        lCurrency2Unit = exchrateCfg.getCcy2Unit();
      }
      else
      {
        lCurrency1Unit = exchrateCfg.getCcy2Unit();
        lCurrency2Unit = exchrateCfg.getCcy1Unit();
      }
      
      exchangeRateOutputData.setCurrency1Units(lCurrency1Unit.intValue());
      exchangeRateOutputData.setCurrency2Units(lCurrency2Unit.intValue());
      
      // STEP 2 - 
      // Calculating the converted amount.
      boolean bEmptyForwardContractRate = nullNumberOrZero(dForwardContractRateToUse);
      double dConvertingRate = bEmptyForwardContractRate? exchangeRateOutputData.getRate() : dForwardContractRateToUse.doubleValue(); 
  
      // DIRECT conversion means that 'currency 1' of the message EQUALS the related EXCHRATE_BU.CCY1,
      // thus in the calculation:
      // 1) We need to MULTIPLY the original amount in the converting rate.
      // 2) The units ratio to use is 'Curr2 Units'/'Curr1 Units', where the ACTUAL units values are determined above. 
    	// Example:
    	//  Need to convert 1000 USD to GBP.
    	//  Rate: 1.5.
    	//  Units: USD = 2, GBP = 1.
    	//  Calculation = (1000 * 1.5) = 1500 USD, which need to be represented in GBP, where the ratio between
    	//                USD to GBP is (1/2) --> 1500 * 0.5 = 750 GBP.
      if(bDirectConversion)
      {
        dConvertedAmount = dAmountToConvert * dConvertingRate * (new Double(lCurrency2Unit) / new Double(lCurrency1Unit));
      }
      
      // INDIRECT conversion means that 'currency 1' of the message DOESN'T EQUAL the related EXCHRATE_BU.CCY1,
      // thus in the calculation:
      // 1) We need to DIVIDE the original amount in the converting rate.
      // 2) The units ratio to use is 'Curr1 Units'/'Curr2 Units', where the ACTUAL units values are determined above. 
    	// Example:
    	//  Need to convert 750 GBP to USD.
    	//  Rate: 1.5.
    	//  Units: USD = 2, GBP = 1.
    	//  Calculation = (750 / 1.5) = 500 GBP, which need to be represented in USD, where the ratio between
    	//                USD to GBP is (2/1) --> 500 * 2 = 1000 USD.
      else // Indirect conversion.
      {
        dConvertedAmount = (dAmountToConvert / dConvertingRate) * (new Double(lCurrency1Unit) / new Double(lCurrency2Unit)) ;
      }
      
      // STEP 3 - 
      // The final converted amount value should be finalized using the currency 2 
      // precision.
      dConvertedAmount = adjustAmountToPrecision(sCurrency2, dConvertedAmount,isToAdjustPrecision);
  
      logger.info(METHOD_RESULTS, new Object[] {dConvertingRate, dConvertedAmount, sCurrency1, lCurrency1Unit, sCurrency2, lCurrency2Unit});
    }
    
    // We should never get here, as the 'calculateConvertedAmount' method won't 
    // be called in case the pre-called 'calculateExchangeRate' doesn't return a
    // valid exchange rate data, (which includes a valid ExchrateCfg object).
    // However, we still write to the trace file a notification, and throw an exception
    // as there is no point to continue the process.
    else
    {
      logger.info(MESSAGE_NON_VALID_EXCHRATE_CFG_OBJECT);
      throw new CurrencyConversionException(MESSAGE_NON_VALID_EXCHRATE_CFG_OBJECT);
    }

    
    
    return dConvertedAmount;
  }
  
  /**
   * Gets a currency and an amount and returns an amount which is adjusted
   * according to the currency precision as defined in CURRENCY_CFG table for
   * that currency.
   */
  private Double adjustAmountToPrecision(String sCurrency, Double dOriginalAmount, boolean isToAdjustPrecision)
  {
    Double amount = dOriginalAmount;
    if (isToAdjustPrecision)
    {
        // Gets currency precision, which is required for the calculations.
        CurrencyCfg oCurrencyCfg = CacheKeys.currencyCfgKey.getSingle(sCurrency);
        Long lNoOfDecimal = oCurrencyCfg.getNoofdecimal();
        int iNoOfDecimal = lNoOfDecimal != null ? lNoOfDecimal.intValue() : 0;
        amount = GlobalUtils.adjustPrecision(dOriginalAmount, iNoOfDecimal);
    }
    
    return amount;
  }
  
  /**
   * Performs cross currency conversion.
   */
  private CrossCurrencyConversionOutputData performCrossCurrencyConversion(CrossCurrencyConversionInputData crossCCInputData) 
                                                                           throws CurrencyConversionException
  {
    final String METHOD_RESULTS = "Final convereted amount = {}, Final rate = {}, Rate accuracy = {}.";
    final String USE_BASE_RATE_USAGE_AS_FAILOVER = ", Use BASE rate usage as failover = ";
    final String APPLYSPREADONCE_VALUE_STEP1 = "STEP1";
    
    
    
    String sMessageExchangeRateCalculationFailure = null;
    
    String sCurrency1 = crossCCInputData.getCurrency1();
    String sCurrency2 = crossCCInputData.getCurrency2();
    String sOffice = crossCCInputData.getOffice();
    Double dAmountToConvert = crossCCInputData.getAmountToConvert();
        
    logger.info(BASIC_INPUT_DATA + USE_BASE_RATE_USAGE_AS_FAILOVER + crossCCInputData.useBaseRateUsageAsFailover(), new Object[] {sCurrency1, sCurrency2, dAmountToConvert, sOffice});
    
    CrossCurrencyConversionOutputData crossCCOutputData = new CrossCurrencyConversionOutputData();
    
    // Sets into the output data the ExchrateCfg object for the original currencies pair;
    // it might be null if we arrived to the cross currency process because no
    // EXCHRATE_CFG record was used.
    // The setting is required for forward contract flow; see the parallel 'get' method
    // for the use of it.
    crossCCOutputData.setExchrateCfgForOriginalCurrenciesPair(crossCCInputData.getExchrateCfg());

    // STEP 1 - 
    // Finds the triangulation currency.
    String sTriangulationCurrency = getTriangulationCurrency(crossCCInputData, crossCCOutputData);
    
    // In case we have a process error, it means that the found triangulation currency
    // equals currency 1 or currency 2; flow should be stopped, and this error 
    // will be returned to the caller method.
    if(crossCCOutputData.getProcessErrorHolder().getProcessError(0) == null)
    {
      crossCCOutputData.setTriangulationCurrency(sTriangulationCurrency);
      
      // STEP 2 - 
      // Determines the apply spread flag.
      boolean bApplySpreadStep1 = false;
      boolean bApplySpreadStep2 = false;
  
      boolean bApplySpreadOnce = crossCCInputData.getRateUsage().getApplySpreadOnce() != 0;
  
      // RATE_USAGE.APPLY_SPREAD_ONCE is false.
      // If the flag is false, it means that we want to give discount on both conversions.
      if(!bApplySpreadOnce)
      {
        bApplySpreadStep1 = true;
        bApplySpreadStep2 = true;
      }
      
      // RATE_USAGE.APPLY_SPREAD_ONCE is true.
      // The descision will be based on the APPLYSPREADONCE system parameter, and
      // discount will be given only on one conversion. 
      else // bApplySpreadOnce is 'true'.
      {
        String sSysPar_APPLYSPREADONCE = CacheKeys.SystParKey.getSingle(sOffice, 
						SystemParametersInterface.SYS_PAR_APPLYSPREADONCE).getParmValue() ; 
        
        if(APPLYSPREADONCE_VALUE_STEP1.equalsIgnoreCase(sSysPar_APPLYSPREADONCE))
        {
          bApplySpreadStep1 = true;
        }
        else
        {
          bApplySpreadStep2 = true;
        }
      }
      
      // STEP 3 - 
      // Calculates exchange rate for currency 1 and triangulation currency.
      CurrencyConversionInputData ccInputDataStep1 = new CurrencyConversionInputData(crossCCInputData);
      ccInputDataStep1.setCurrency2(sTriangulationCurrency);
      ccInputDataStep1.setApplySpread(bApplySpreadStep1);
      //
      ExchangeRateOutputData exchangeRateOutputDataStep1 = calculateExchangeRate(ccInputDataStep1);
      
      // No valid exchange rate for currency 1 and triangulation currency;
      // process will be stopped.
      if(!exchangeRateOutputDataStep1.isValidExchangeRateData())
      {
        ProcessError processError = exchangeRateOutputDataStep1.getProcessErrorHolder().getProcessError(0);
        handleExchangeRateCalculationFailureDuringCrossCurrency(processError, crossCCOutputData, 1, sCurrency1, sTriangulationCurrency, sOffice);
      }
      
      // We have a valid exchange rate for currency 1 and triangulation currency.
      else
      {
        crossCCOutputData.setExchangeRateOutputData(exchangeRateOutputDataStep1);
        crossCCOutputData.setRateStep1(exchangeRateOutputDataStep1.getRate());
        
        // STEP 4 - 
        // Calculates the converted amount according to 'exchangeRateOutputDataStep1' from step 3.
        // This converted amount is referred as 'converted amount step 1' and it will
        // will be used in STEP 6 as the amount to convert from the triangulation
        // currency to currency 2.
        Double dConvertedAmountStep1 = calculateConvertedAmount(exchangeRateOutputDataStep1, crossCCInputData.getAmountToConvert(), sCurrency1, sTriangulationCurrency, null,crossCCInputData.isToAdjustPrecision());
        crossCCOutputData.setConvertedAmountStep1(dConvertedAmountStep1); 
    
        // STEP 5 - 
        // Calculates exchange rate for the triangulation currency as currency 1 & currency 2.
        CurrencyConversionInputData ccInputDataStep2 = new CurrencyConversionInputData(crossCCInputData);
        ccInputDataStep2.setCurrency1(sTriangulationCurrency);
        ccInputDataStep2.setApplySpread(bApplySpreadStep2);
    
        ExchangeRateOutputData exchangeRateOutputDataStep2 = calculateExchangeRate(ccInputDataStep2);
        
        // No valid exchange rate for the triangulation currency as currency 1 & currency 2.
        // process will be stopped.
        if (!exchangeRateOutputDataStep2.isValidExchangeRateData())
        {
          ProcessError processError = exchangeRateOutputDataStep2.getProcessErrorHolder().getProcessError(0);
          handleExchangeRateCalculationFailureDuringCrossCurrency(processError, crossCCOutputData, 2, sTriangulationCurrency, ccInputDataStep2.getCurrency2(), sOffice);
        }
        
        // We have a valid exchange rate for the triangulation currency as currency 1 & currency 2.
        else
        {
          crossCCOutputData.setExchangeRateOutputDataStep2(exchangeRateOutputDataStep2);
          
          // STEP 6 - 
          // Calculates the FINAL converted amount according to 'dConvertedAmountStep1' from 
          // step 4, (which is expressed in the triangulation currency and could have 
          // been fetched by using 'crossCCOutputData.getConvertedAmountStep1' as well), 
          // and the 'exchangeRateOutputDataStep2' from the previous step, from which 
          // the final rate to use will be taken.
          Double dFinalConvertedAmount = calculateConvertedAmount(exchangeRateOutputDataStep2, dConvertedAmountStep1, sTriangulationCurrency, sCurrency2, null,crossCCInputData.isToAdjustPrecision());
      
          // STEP 7 - 
          // Calculates the cross rate & the rate accuracy.
          Object[] arrCrossRateAndRateAccuracy = calculateRateAndRateAccuracy(dAmountToConvert,
                                                                              dFinalConvertedAmount,
                                                                              sCurrency1, sCurrency2,
                                                                              crossCCInputData.getExchrateCfg(),
                                                                              exchangeRateOutputDataStep1,
                                                                              exchangeRateOutputDataStep2);
          
          Double dFinalRate = (Double)arrCrossRateAndRateAccuracy[0];
          crossCCOutputData.setRate(dFinalRate);
          
          int iRateAccuracy = (Integer)arrCrossRateAndRateAccuracy[1];
          crossCCOutputData.setRateAccuracy(iRateAccuracy);
          
          crossCCOutputData.setConvertedAmount(dFinalConvertedAmount);
          
          logger.info(METHOD_RESULTS, new Object[] {dFinalConvertedAmount, dFinalRate, iRateAccuracy});
        }
      }
    }
    
    

    return crossCCOutputData;
  }
  
  /**
   * Calculates rate & rate accuracy.
   * @param dOrigConvertedAmount the original amount to converted.
   * @param dFinalConvertedAmount the final converted amount.
   * @param sCurrency1 currency 1 between the 2 currencies which are involved in
   *                   the conversion process.
   * @param oExchrateCfg ExchrateCfg object for the 2 currencies which are involved in
   *                     the conversion process; might be null; see inside the method for
   *                     detailed explanation.
   */
  private Object[] calculateRateAndRateAccuracy(Double dAmountToConvert, Double dFinalConvertedAmount,
                                                String sCurrency1, String sCurrency2, 
                                                ExchrateCfg oExchrateCfg,
                                                ExchangeRateOutputData exchangeRateOutputDataStep1,
                                                ExchangeRateOutputData exchangeRateOutputDataStep2)
  {
    
    
    Double dRate;
    
    // STEP 1 - 
    // Determines the rate.
    //
    // - In case the call to this method was from the 'performCrossCurrency' method,
    // this object MIGHT hold a valid value; see the call to 'performCrossCurrency'
    // method in the 'performCurrencyConversion' method, where this object is being set.
    // - In case the call to this method was from the 'handleMessageRates' method
    // during the forward contract flow, then in case the initial conversion between
    // the original currencies pair, (see the 'performForwardContractAndDealerRateConversion' method),
    // included cross currency, then this object MIGHT hold a valid value.
    //
    // 'oExchrateCfg' isn't null, (i.e. currency pair was found in the EXCHRATE_CFG table),
    if(oExchrateCfg != null)
    {
      String sCCY1 = oExchrateCfg.getCcy1();
      
      if(sCCY1.equals(sCurrency1))
      {
        dRate = dFinalConvertedAmount / dAmountToConvert;
      }
      else // sCCY1 equals currency 2.
      {
        dRate = dAmountToConvert / dFinalConvertedAmount;
      }
    }
    //
    // Currency pair wasn't found in the EXCHRATE_CFG table.
    // In addition, there is no need to go and look for it in the cache as if it exists
    // there, the object wouldn't have been null.
    else
    {
    	// Sets initial value to 'true', but the boolean will be set with correct value later on.
    	boolean bDirectConversion = true;
    	
    	String sP_OFFICE = Admin.getContextPDO().getString(P_OFFICE);
    	String[] arrOrderedCurrenciesAccordingToRanking = determineCurrenciesOrderAccordingToRanking(sP_OFFICE, sCurrency1, sCurrency2);
    	
    	// Ranking data exists.
    	if(arrOrderedCurrenciesAccordingToRanking != null)
    	{
        if(arrOrderedCurrenciesAccordingToRanking[0].equals(sCurrency1))
        {
          dRate = dFinalConvertedAmount / dAmountToConvert;
          bDirectConversion = true;
        }
        else // 'arrOrderedCurrenciesAccordingToRanking[0]' equals currency 2.
        {
          dRate = dAmountToConvert / dFinalConvertedAmount;
          bDirectConversion = false;
        }    		
    	}
    	
    	// No ranking data:
    	// 1) Determines the 'bDirectConversion' boolean according to the amounts.
    	// 2) Determines rate according to 'bDirectConversion' boolean.
    	else
    	{
    		bDirectConversion = dFinalConvertedAmount > dAmountToConvert;
    	
	      dRate = bDirectConversion ? dFinalConvertedAmount / dAmountToConvert :
	                                  dAmountToConvert / dFinalConvertedAmount;
    	}
    	
      // Sets the related boolean in the 'exchangeRateOutputDataStep2' to be used later on during the 
      // 'getExchangeRateOutputDataObjectForStep1Records' method in case cross currency was used for the original
      // currency pair of forward contract lines.
      // See there for further explanation.
      exchangeRateOutputDataStep2.setDirectConversion(bDirectConversion);
    }
    
    // STEP 2 - 
    // Determines the rate accuracy & applies it.
    //
    // The rate precision/accuracy is always determined according to the value of the 
    // EXCHRATE_CFG.DEC_NO column; the question here is from which ExchrateCfg object to take it.
    int iRateAccuracy = 1;
    //
    // Valid ExchrateCfg object.
    if(oExchrateCfg != null)
    {
      iRateAccuracy = oExchrateCfg.getDecNo().intValue();
    }
    //
    // Invalid ExchrateCfg object; we need use the HIGHER value from the 2  
    // ExchangeRateOutputData objects which were retrieved during the cross
    // currency process, where the first one is for currency 1 & the triangulation currency,
    // and the second one is for the triangulation currency and currency 2.
    else
    {
      Long lDecNoStep1 = exchangeRateOutputDataStep1.getExchrateCfg().getDecNo();
      Long lDecNoStep2 = exchangeRateOutputDataStep2.getExchrateCfg().getDecNo();
      iRateAccuracy = lDecNoStep1 > lDecNoStep2 ? lDecNoStep1.intValue() : lDecNoStep2.intValue();
    }
    
    BigDecimal bdFinalRate = new BigDecimal(dRate).setScale(iRateAccuracy, RoundingMode.HALF_UP);
    Double dFinalRate = new Double(bdFinalRate.doubleValue());
    
    
    
    return new Object[]{dFinalRate, iRateAccuracy};
  }
  
  /**
   * Handles a failure of exchange rate calculation during cross currency.
   */
  private void handleExchangeRateCalculationFailureDuringCrossCurrency
                         (ProcessError processError, CrossCurrencyConversionOutputData crossCCOutputData,
                          int iCrossCurrencyStep, String sCurrency1, String sCurrency2, String sOffice)
  {
    final String MESSAGE_EXCHANGE_RATE_CALCULATION_FAILURE = "ERROR: 'BOCurrencyConversion.performCrossCurrencyConversion' - STEP {}, failure during the call to 'calculateExchangeRate' for currency {}, currency {}, and office {}.";
    
    // Sets into the output object the process error which was determined in the
    // 'calculateExchangeRate' method, and adds it into the PDO.
    crossCCOutputData.getProcessErrorHolder().addError(processError);
    ErrorAuditUtils.setErrors(processError);
    
    // Don't replace 'ccInputDataStep2.getCurrency2()' with currency 2 !!!
    String sMessageExchangeRateCalculationFailure = String.format(MESSAGE_EXCHANGE_RATE_CALCULATION_FAILURE, iCrossCurrencyStep, sCurrency1, sCurrency2, sOffice);
    logger.info(sMessageExchangeRateCalculationFailure);
  }
  
  /**
   * Returns triangulation currency for the passed CurrencyConversionInputData
   * input parameter.
   */
  private String getTriangulationCurrency(CurrencyConversionInputData ccInputData,
                                          CrossCurrencyConversionOutputData crossCCOutputData) 
  {
    final String METHOD_RESULT = "Triangulation currency = {}.";
    
    final String FROM_RATE_USAGE_PROFILE = "rate usage profile";
    final String FROM_BASE_CURRENCY = "base currency";
    
    
    
    String sOffice = ccInputData.getOffice();
    
    String sTriangulationCurrency = ccInputData.getRateUsage().getTriangulationCurrency();
    boolean bEmptyTriangulationCurrency = isNullOrEmpty(sTriangulationCurrency);
    
    // If the value is empty/null, then the base currency of the office will be used.
    if(bEmptyTriangulationCurrency)
    {
      sTriangulationCurrency = CacheKeys.banksKey.getSingle(sOffice).getCurrency();
    }
    
    String sCurrency1 = ccInputData.getCurrency1();
    String sCurrency2 = ccInputData.getCurrency2();
    
    if(   sTriangulationCurrency.equalsIgnoreCase(sCurrency1)
       || sTriangulationCurrency.equalsIgnoreCase(sCurrency2))
    {
      String sTriangulationCurrencySource = bEmptyTriangulationCurrency? FROM_BASE_CURRENCY : FROM_RATE_USAGE_PROFILE;
      Object[] arrNonPaymentFields = new Object[]{sTriangulationCurrency, sTriangulationCurrencySource, sCurrency1, sCurrency2, sOffice};
      String sErrorMessage = String.format(ERROR_MESSAGE_TRIANGULATION_CURRENCY_EQUALITY, arrNonPaymentFields);
      logger.info(sErrorMessage);

      // Error code 40009: 'Triangulation currency %s which was determined according to %s equals currency 1: %s or currency 2: %s, under office %s'.
      ProcessError processError = new ProcessError(ProcessErrorConstants.TriangulationCurrencyEqualsCurrency1OrCurrency2, 
                                                   sErrorMessage, arrNonPaymentFields);
      crossCCOutputData.getProcessErrorHolder().addError(processError);
      ErrorAuditUtils.setErrors(processError);
    }
    
    logger.info(METHOD_RESULT, sTriangulationCurrency);
    
    
    
    return sTriangulationCurrency;
  }
  
  /**
   * Calculates the equivalent amount; i.e. converts the input amount from the
   * 'ccInputData' input parameter into the base currency, (which will be used as currency 2).
   * @param dOrigConvertedAmount the converted amount which was calculated in the 
   *                             'performCurrencyConversion' method; if currency 2 
   *                             equals the base currency, then this is also the 
   *                             equivalent amount.
   */
  private Double calculateEquivalentAmount(CurrencyConversionInputData ccInputData, 
                                           Double dOrigConvertedAmount) throws CurrencyConversionException
  {
    final String BASE_CURRENCY = "Base currency = {}.";
    final String EQUIVALENT_AMOUNT = "Equivalent amount = {}.";
    
    
    
    String sCurrency1 = ccInputData.getCurrency1();
    String sCurrency2 = ccInputData.getCurrency2();
    String sOffice = ccInputData.getOffice();
    Double dAmountToConvert = ccInputData.getAmountToConvert();
    
    logger.info(BASIC_INPUT_DATA, new Object[] {sCurrency1, sCurrency2, dAmountToConvert, sOffice});
    
    Double dEquivalentAmount = null;
    
    // Gets the base currency.
    String sBaseCurrency = CacheKeys.banksKey.getSingle(sOffice).getCurrency();
    logger.info(BASE_CURRENCY, sBaseCurrency);
    //    
    // Base currency equals currency 1; equivalent amount will be the input amount
    // to convert from the 'ccInputData' input parameter.
    if(sBaseCurrency.equals(sCurrency1))
    {
      dEquivalentAmount = dAmountToConvert;
    }
    
    // Base currency equals currency 2; equivalent amount will be the passed
    // 'dOrigConvertedAmount' input parameter; see Javadoc for this parameter.
    else if (sBaseCurrency.equals(ccInputData.getCurrency2()))
    {
      dEquivalentAmount = dOrigConvertedAmount;
    }

    // Needs to convert the input amount from currency 1 to the base currency.
    else
    {
      // Preparations before calling the 'calculateExchangeRate' method.
      
      // Saves temporary the non-BASE RateUsage object.
      RateUsage origRateUsage = ccInputData.getRateUsage();
      //
      // Sets into the non-BASE RateUsage object the BASE RateUsage, (which was
      // set into the original CurrencyConversionInputData object during the 
      // 'enrichCurrencyConversionInputData' method).
      ccInputData.setRateUsage(ccInputData.getBaseRateUsage());
      
      // Sets currency 2 to be the base currency.
      ccInputData.setCurrency2(sBaseCurrency);
      
      // Calculates the exchange rate.
      ExchangeRateOutputData exchangeRateOutputData = calculateExchangeRate(ccInputData);
      
      // If we arrived here, the 'exchangeRateOutputData' can't be null !!!
      // We won't arrive here in case of exception in the 'calculateExchangeRate'
      // which will be thrown from here to the caller method.
      if(exchangeRateOutputData.isValidExchangeRateData())
      {
        // Don't replace 'ccInputData.getCurrency2()' with 'sCurrency2' !!!
        // The currency there is actually the base currency.
        dEquivalentAmount = calculateConvertedAmount(exchangeRateOutputData, dAmountToConvert, 
                                                     sCurrency1, ccInputData.getCurrency2(), null,ccInputData.isToAdjustPrecision());
      }
      
      else // No valid exchange rate data; performs cross currency.
      {
        ccInputData = new CrossCurrencyConversionInputData(ccInputData);
        
        CrossCurrencyConversionOutputData cccEquivalentOutputData = performCrossCurrencyConversion((CrossCurrencyConversionInputData)ccInputData);
        
        // No process errors were raised.
        if(cccEquivalentOutputData.getProcessErrorHolder().getProcessError(0) != null)
        {
          dEquivalentAmount = cccEquivalentOutputData.getConvertedAmount();
        }
      }
      
      // Sets back the CurrencyConversionInputData object with original rate usage and currency 2.
      ccInputData.setRateUsage(origRateUsage);
      ccInputData.setCurrency2(sCurrency2);
    }
    
    logger.info(EQUIVALENT_AMOUNT, dEquivalentAmount);
    
    
    
    return dEquivalentAmount;
  }
  
  /**
   * Performs threshold validation.
   * @param bValidationForInstructionAmount true - this method was called for validating the
   *                                               instruction amount.
   *                                        false - this method was called for validating the
   *                                                residual amount during forward contract flow.
   * @param dResidualAmount will be null in case 'bValidationForInstructionAmount' is true.   
   *                        otherwise, it must be with a valid value.
   */
  private void validateThreshold(CurrencyConversionInputData ccInputData, 
                                 CurrencyConversionOutputData ccOutputData, 
                                 Boolean bValidationForInstructAmount,
                                 Double dResidualAmount) throws CurrencyConversionException
  {
    final String INPUT_DATA_1 = "Validation for instruction amount = {}, Residual amount = {}.";
    final String INPUT_DATA_2 = "Currency 1 = {}, Base currency = {}, Amount to valid = {}.";
    
    final String MESSAGE_CURRENCY_1_EQUALS_BASE_CURRENCY = "Currency 1 {} equals the base currency {} - skips the call to 'performCurrencyConversion'.";
    final String MESSAGE_INVOKING_CURRENCY_CONVERSION_PROCESS = "Calls 'performCurrencyConversion' for converting the validated amount to the base currency.";
    
    final String COLUMN_RATE_USAGE_CROSSTHRESH = "RATE_USAGE.CROSSTHRESH";
    final String COLUMN_RATE_USAGE_DIRECTTHRESH = "RATE_USAGE.DIRECTTHRESH";
    
    final String USED_THRESHOLD_VALUE_AND_VALIADTION_COMAPRING_VALUES  = "Cross currency used = {}, Used threshold column = {}, Amount to valid = {}, Threshold value = {}, Need to perform validation = {}.";
    final String THRESHOLD_VALIDATION_FAILURE = "Threshold validation error !!!";
    
    
    
    logger.info(INPUT_DATA_1, bValidationForInstructAmount, dResidualAmount);
    
    // In case 'bValidationForInstructAmount' is true, then we need to convert the instruction amount to the base currency.
    // The instruction amount in base currency might have already been set into the PDO; if so, we'll use this value for 
    // the validation, otherwise we call the currency conversion process to get it.
    PDO pdo = Admin.getContextPDO();
    BigDecimal bdBaseAmount = pdo.getDecimal(P_BASE_AMT);
    Double dBaseAmount = bdBaseAmount != null ? bdBaseAmount.doubleValue() : ServerConstants.DOUBLE_ZERO;

    Double dAmountToValid = bValidationForInstructAmount ? dBaseAmount : dResidualAmount;
    
    Double dAmountToConvert = ccInputData.getAmountToConvert();

    String sBaseCurrency = CacheKeys.banksKey.getSingle(ccInputData.getOffice()).getCurrency();
    String sCurrency1 = ccInputData.getCurrency1();
    logger.info(INPUT_DATA_2, new Object[] {sCurrency1, sBaseCurrency, dAmountToConvert});
    
    // If currencies are equal, no need for the currency conversion to the base
    // conversion. 
    boolean bCurrenciesAreEqual = sCurrency1.equals(sBaseCurrency);
    if(bCurrenciesAreEqual)
    {
      dAmountToValid = bValidationForInstructAmount ? dAmountToConvert : dResidualAmount;
      logger.info(MESSAGE_CURRENCY_1_EQUALS_BASE_CURRENCY,sCurrency1, sBaseCurrency);
    }
    
    else
    {
      // Performs currency conversion if:
      //  1) 'bValidationForInstructAmount' is true; i.e. this method was called for 
      //     validating the instruction amount and the amount to vaild is null or 
      //     zero; i.e. we don't have yet the base amount, (instruction amount in base currency).
      // OR
      //  2) 'bValidationForInstructAmount' is false; i.e. this method was called for 
      //     validating the residual amount during forward contract flow; since
      //     'bCurrenciesAreEqual' is false, it means that the base currency doesn't
      //     equal currency 1 --> we need to convert the passed residual amount to 
      //     base currency.
      if(   (bValidationForInstructAmount && nullNumberOrZero(dAmountToValid)) 
         || !bValidationForInstructAmount)
      {
        logger.info(MESSAGE_INVOKING_CURRENCY_CONVERSION_PROCESS);
        
        // The call was made from the forward contract flow.
        // Keeps temporary the original amount to convert and sets it to be the
        // residual amount.
        Double dOrigAmountToConvert = ccInputData.getAmountToConvert();
        if(!bValidationForInstructAmount)
        {
          ccInputData.setAmountToConvert(dResidualAmount);
        }

        // Keeps temporary the non-BASE RateUsage object & sets the rate usage member
        // to be the one of the BASE rate usage; note that in case of wrong setup,
        // the 'ccInputData.getBaseRateUsage()' might be null; this will be identified
        // during the 'calculateExchangeRate' method.
        RateUsage origRateUsage = ccInputData.getConversionType().toString().equals(ConversionType.Base.toString())?
                                  ccInputData.getBaseRateUsage() : ccInputData.getRateUsage();
        ccInputData.setRateUsage(ccInputData.getBaseRateUsage()); 
        
        // Keeps temporary the conversion type and sets it to be 'Base.
        ConversionType origConversionType = ccInputData.getConversionType();  
        ccInputData.setConversionType(ConversionType.Base);

        // Keeps temporary the original currency 2, and sets it to be the base currency. 
        String sOrigCurrency2 = ccInputData.getCurrency2();
        ccInputData.setCurrency2(sBaseCurrency);
        
        // No need for validations.
        ccInputData.setPerformValidations(false);
        
        // Sets this flag to have a notification in the 'calculateExchangeRate'
        // in case we don't have a correct setup of the BASE rate usage. 
        ccInputData.setIsForThresholdValidation(true);
        
        // Calls the currency conversion process.
        CurrencyConversionOutputData ccOutputToBaseCurrency = performCurrencyConversion(ccInputData);
        dAmountToValid = ccOutputToBaseCurrency.getConvertedAmount();
        //
        // In case, base rate usage wasn't set, the 'calculateExchangeRate' method which
        // is called during the 'performCurrencyConversion' method, will write an error
        // into the trace file and conversion won't be performed, and in that case
        // the amount to valid will be null; the following line is to prevent
        // NullPointerException in the 'if(dAmountToValid > dThresholdAmount)'
        // condition later on.
        dAmountToValid = dAmountToValid != null ? dAmountToValid : ServerConstants.DOUBLE_ZERO;
        
        // Sets back the CurrencyConversionInputData object with original values.
        ccInputData.setConversionType(origConversionType);
        ccInputData.setRateUsage(origRateUsage);
        ccInputData.setCurrency2(sOrigCurrency2);
        //
        if(!bValidationForInstructAmount)
        {
          ccInputData.setAmountToConvert(dOrigAmountToConvert);
        }
        ccInputData.setIsForThresholdValidation(false);
      }
    }
    
    // STEP 2 - 
    // Performs the threshold validation itself against data from the RATE_USAGE 
    // profile, in which the related data is in BASE currency. 
    //
    // If cross currency was used during the process, then needs to compare the 
    // found amount from previous step against RATE_USAGE.CROSSTHRESH column;
    // otherwise, compare is against RATE_USAGE.DIRECTTHRESH column.
    RateUsage rateUsage = ccInputData.getConversionType().toString().equals(ConversionType.Base.toString())?
                          ccInputData.getBaseRateUsage() : ccInputData.getRateUsage();
    boolean bCrossCurrencyUsed = ccOutputData.isCrossCurrencyUsed();
    Object oThresholdAmount = bCrossCurrencyUsed ? rateUsage.getCrossThresh() :
                                                   rateUsage.getDirectThresh();
    Double dThresholdAmount = oThresholdAmount != null ?  (Double)oThresholdAmount : ServerConstants.DOUBLE_ZERO;
    boolean bPerformThresholdAmountValidation = dThresholdAmount > ServerConstants.DOUBLE_ZERO;
    
    String sRATE_USAGE_COLUMN = bCrossCurrencyUsed ? COLUMN_RATE_USAGE_CROSSTHRESH : COLUMN_RATE_USAGE_DIRECTTHRESH;
    logger.info(USED_THRESHOLD_VALUE_AND_VALIADTION_COMAPRING_VALUES, new Object[] {bCrossCurrencyUsed, sRATE_USAGE_COLUMN, dAmountToValid, dThresholdAmount, bPerformThresholdAmountValidation});
    
    // Need to perform threshold validation and amount to valid is bigger then threshold amount.
    if(bPerformThresholdAmountValidation && (dAmountToValid > dThresholdAmount))
    {
      logger.info(THRESHOLD_VALIDATION_FAILURE);
      ProcessError processError;
      
      if(bValidationForInstructAmount)
      {
        processError = PROCESS_ERROR_THRESHOLD_FOR_INSTRUCTION_AMOUNT;
      }
      else  
      {
        processError = PROCESS_ERROR_THRESHOLD_FOR_RESIDUAL_AMOUNT;
      }
      
      ccOutputData.getProcessErrorHolder().addError(processError); 
      ErrorAuditUtils.setErrors(processError);
    }
    
    
  }
  
  /**
   * Performs expiry date validation.
   */
  private void validateExpiryDate(CurrencyConversionInputData ccInputData, 
                                  CurrencyConversionOutputData ccOutputData)
  {
    final String INPUT_DATA = "Currency pair = {}, Office = {}, Rate usage type = {}, EXCHRATE_BU object = {}.";
    final String SKIP_VALIDATION_MESSAGE_NULL_EXCHRATE_BU_VALID_DATE_TIME = "Skips the validation, because EXCHRATE_BU.VALID_DATE_TIME is null.";
    final String SKIP_VALIDATION_MESSAGE_ZERO_EXCHRATE_BU_FIXED = "Skips the validation, because EXCHRATE_BU.FIXED is 0.";
    
    final String COLUMN_BANKS_BSNESSDATE = "BANKS.BSNESSDATE";
    final String FXVALUDATE_VALUE = "FXVALUDATE system parameter value = {}. Validation will be done against {}.";
    
    final String MESSAGE_DATE_VALUES = "EXCHRATE_BU valid date time is {} and will be compared to {}.";
    
    final String DATE_TYPE_VALUE_DATE = "Value";
    final String DATE_TYPE_BUSINESS_DATE = "Business";
    
    
    
    String[] arrCurrencyPairs = null;
    
    // Cross currency was used; need to perform the validation on the currency
    // pairs from both steps, (i.e. 'currency 1 & triangulation currency' and 
    // 'triangulation currency & currency 2'), and NOT on the original input 
    // data currency pair.
    if(ccOutputData.isCrossCurrencyUsed())
    {
      String sCurrencyPairStep1 = ccOutputData.getExchangeRateOutputData().getExchrateCfg().getCcyPair();
      String sCurrencyPairStep2 = ccOutputData.getExchangeRateOutputDataStep2().getExchrateCfg().getCcyPair();
      arrCurrencyPairs = new String[]{sCurrencyPairStep1, sCurrencyPairStep2};
    }
    
    // Cross currency wasn't used; need to perform the validation on the original 
    // input data currency pair.
    else
    {
      arrCurrencyPairs = new String[]{ccInputData.getOrderedCurrencyPair()};
    }
    
    for(int i=0; i<arrCurrencyPairs.length; i++)
    {
      String sOffice = ccInputData.getOffice();
      
      RateUsage rateUsage = ccInputData.getConversionType().toString().equals(ConversionType.Base.toString())?
                            ccInputData.getBaseRateUsage() : ccInputData.getRateUsage();    
      String sRateUsageType = rateUsage.getRateType();
      
      ExchrateBu oExchrateBu = CacheKeys.exchrateBuKey.getSingle(arrCurrencyPairs[i], sOffice, sRateUsageType);
      logger.info(INPUT_DATA, new Object[] {arrCurrencyPairs[i], sOffice, sRateUsageType, oExchrateBu});
      
      if(oExchrateBu != null)
      {
	      Date dateValidDateTime = oExchrateBu.getValidDateTime();
	      boolean bNullValidDateTime = dateValidDateTime == null;    
	      boolean bFixedValue = oExchrateBu.getFixed().longValue() != 0;
	           
	      // No need for validation in case:
	      //    1) EXCHRATE_BU.VALID_DATE_TIME is null.
	      // OR 2) EXCHRATE_BU.FIXED isn't 0.
	      if(bNullValidDateTime || bFixedValue)
	      {
	        if(bNullValidDateTime)
	        {
	          logger.info(SKIP_VALIDATION_MESSAGE_NULL_EXCHRATE_BU_VALID_DATE_TIME);
	        }
	        else
	        {
	          logger.info(SKIP_VALIDATION_MESSAGE_ZERO_EXCHRATE_BU_FIXED);
	        }
	      }
	      
	      // Performs validation.
	      else
	      {
	        // STEP 1 - 
	        // Gets the date value against which to perform the validation.
	        Date dateComapreTo = null;
	        
	        final SystPar oSystPar_FXVALUDATE =  CacheKeys.SystParKey.getSingle(sOffice, SystemParametersInterface.SYS_PAR_FXVALUDATE) ; 
	        
	        String sSysPar_FXVALUDATE = oSystPar_FXVALUDATE != null ? 
	                                    oSystPar_FXVALUDATE.getParmValue() : ServerConstants.NO;
	                                    
	        boolean bFXVALUDATE_isYes = sSysPar_FXVALUDATE.equalsIgnoreCase(GlobalConstants.YES);
	        String sComparedColumn = bFXVALUDATE_isYes ? X_STTLM_DT_1B : COLUMN_BANKS_BSNESSDATE; 
	        logger.info(FXVALUDATE_VALUE, new Object[] {sSysPar_FXVALUDATE, sComparedColumn});
	        
	        // Need to compare the date against the X_STTLM_DT_1B field.
	        if(bFXVALUDATE_isYes)
	        {
	          PDO pdo = Admin.getContextPDO();
	          dateComapreTo = pdo.getDate(X_STTLM_DT_1B);
	        }
	        
	        // Need to compare the date against the business date, (BANKS.BSNESSDATE).
	        else
	        {
	          // Gets the business date.
	          Banks banks = CacheKeys.banksKey.getSingle(sOffice);
	          dateComapreTo = banks.getBsnessdate();
	        }
	        
	        // STEP 2 - 
	        // Adjusts the 'dateComapreTo' to the office time zone.
	        DateAndZone dateAndZone = NewASDateTimeUtils.getDateAndZoneByOffice(dateComapreTo, sOffice);
	        dateComapreTo = dateAndZone.getDate();
	        
	        // STEP 3 - 
	        // Performs actual validation; compares between the 2 dates.
	        boolean bFailure = false;
	        
	        // Valid date time has expired.
	        if(GlobalDateTimeUtil.isDateBeforeDate(dateValidDateTime, dateComapreTo))
	        {
	          bFailure = true;
	        }
	        
	        // Valid date time EQUALS the compared date; needs to compare the time parts
	        // of the 2 dates.
	        else if(!GlobalDateTimeUtil.isDateAfterDate(dateValidDateTime,dateComapreTo))
	        {
	          // Gets the current date and time according to the office time zone.
	          dateAndZone = NewASDateTimeUtils.getCurrentDateAndZoneByOffice(sOffice);
	          dateComapreTo = dateAndZone.getDate();
	          Calendar cal = Calendar.getInstance(TimeZone.getTimeZone(dateAndZone.getZone()));
	          cal.setTime(dateValidDateTime);
	          
	          // The time of the 'dateValidDateTime' variable is already according to        
	          // the office time zone.
	          if((cal.get(Calendar.HOUR_OF_DAY)!=0 || cal.get(Calendar.MINUTE)!=0|| cal.get(Calendar.SECOND)!=0)
	                  &&GlobalDateTimeUtil.isTimeBeforeTime(dateValidDateTime, dateComapreTo))
	          {     
	            bFailure = true;
	          }
	        }   
	        
	        // Expiry date validation failure. 
	        if(bFailure)
	        {
	          SimpleDateFormat simpleDateFormat = GlobalDateTimeUtil.getSTATIC_DATA_DATE_TIME_SimpleDateFormat();
	          String sValidDateTime = simpleDateFormat.format(dateValidDateTime);
	          String sDateCompareTo = simpleDateFormat.format(dateComapreTo);
	  
	          String sDateType = bFXVALUDATE_isYes? DATE_TYPE_VALUE_DATE : DATE_TYPE_BUSINESS_DATE;
	          
	          // ERROR: Expiry date validation failure - exchange rate date %s is earlier than current %s date %s.
	          String sErrorMessage = String.format(ERROR_MESSAGE_EXPIRY_DATE, sValidDateTime, sDateType, sDateCompareTo);
	          logger.info(sErrorMessage);
	          
	          // Error code 12027: 'Exchange rate date |1 is earlier than current |2 date |3'.
	          Object[] arrNonPaymentFields = new Object[]{dateValidDateTime, sDateType, sDateCompareTo};
	          ProcessError processError = new ProcessError(ProcessErrorConstants.ExpiryDate, arrNonPaymentFields);
	          ccOutputData.getProcessErrorHolder().addError(processError);
	          ErrorAuditUtils.setErrors(processError);
	          
	          // Sets the message status to WAITRATE.
	          PDO pdo = Admin.getContextPDO();
	          pdo.set(P_MSG_STS, MessageConstantsInterface.MESSAGE_STATUS_WAITRATE);
	          pdo.set(PDOConstantFieldsInterface.P_RELEASE_INDEX, MessageConstantsInterface.EVENT_WAITRATE+GlobalConstants.POWER_SIGN+oExchrateBu.getUidExchrateBu());
	        }
	      }
      }
    }
    
    
  }
  
  /**
   * Performs forward contract & dealer rate conversion.
   */
  private ForwardContractDealerRateOutputData performForwardContractAndDealerRateConversion
                                                   (ForwardContractDealerRateInputData fcdrInputData)
                                                    throws CurrencyConversionException
  {
    
    
    String sCurrency1 = fcdrInputData.getCurrency1();
    String sCurrency2 = fcdrInputData.getCurrency2();
    Double dAmountToConvert = fcdrInputData.getAmountToConvert();
    String sOffice = fcdrInputData.getOffice();
    
    logger.info(BASIC_INPUT_DATA, new Object[] {sCurrency1, sCurrency2, dAmountToConvert, sOffice});
    
    ForwardContractDealerRateOutputData fcdrOutputData = new ForwardContractDealerRateOutputData();
    
    // STEP 1 - 
    // Calls 'performCurrencyConversion' between the original currencies pair.
    // The conversion between them can be a direct one or it might include cross currency.
    CurrencyConversionOutputData ccOutputDataForOriginalCurrenciesPair = performCurrencyConversion(fcdrInputData);
    
    // No process errors which have stopped the currency conversion process have 
    // been raised and we can continue with the forward contract flow.
    if(!ccOutputDataForOriginalCurrenciesPair.includesError(ARR_PROCESS_ERROR_TYPES_FOR_UN_COMPLETED_CURRENCY_CONVERSION_PROCESS))
    {
      // STEP 2 - 
      // 1) Gets records from MESSAGERATES table, (or in case of a new message,
      //    direct from the PDO object).
      // 2) Determines if the process can be continued.
      // 3) Sets the 'ForwardContractDealerRateOutputData' returned value with
      //    process errors, if such ones are required.
      Object[] arrMessageRates = getForwardContractMESSAGERATES_Records(fcdrInputData, ccOutputDataForOriginalCurrenciesPair, fcdrOutputData);
      
      // No process errors which should stop the forward conrtact flow, have been
      // raised during the retrieval of the MESSAGERATES records.
      // If such ones were raised, then they were set into the returned object
      // and this method and forward conrtact process should be stopped.
      if(!fcdrOutputData.includesError(ARR_PROCESS_ERROR_TYPES_FOR_PROBLEMATIC_MESSAGERATES_RECORDS))
      {
        // STEP 3 - 
        // Updates the returned object with the properties of the conversion
        // between the original currencies pair.
        fcdrOutputData.setCrossCurrencyUsed(ccOutputDataForOriginalCurrenciesPair.isCrossCurrencyUsed());
        fcdrOutputData.setTriangulationCurrency(ccOutputDataForOriginalCurrenciesPair.getTriangulationCurrency());
        fcdrOutputData.setExchangeRateOutputData(ccOutputDataForOriginalCurrenciesPair.getExchangeRateOutputData());
        fcdrOutputData.setExchangeRateOutputDataStep2(ccOutputDataForOriginalCurrenciesPair.getExchangeRateOutputDataStep2());
        
        // STEP 4 -
        // Continues with actual analyzing of the MESSAGERATES records.
        handleMessageRatesRecords(fcdrInputData, ccOutputDataForOriginalCurrenciesPair, fcdrOutputData, arrMessageRates);
      }
      
      else
      {
        fcdrOutputData.setProcessHasCompleted(false);
      }
    }
    
    // The initial call to 'performCurrencyConversion' between the original currencies pair
    // has raised process errors, which prevent from continuing the process.
    else
    {
      final String ERROR_MESSAGE = "ERROR: 'BOCurrencyConversion.performForwardContractAndDealerRateConversion' - 'performCurrencyConversion' between original currencies pair has failed; stops the forward contract process !!!";
      logger.info(ERROR_MESSAGE);
      
      // Sets into the returned object the process errors which were raised.
      fcdrOutputData.addErrors(ccOutputDataForOriginalCurrenciesPair.getErrors());
      
      fcdrOutputData.setProcessHasCompleted(false);
    }
    
    
    
    return fcdrOutputData;
  }

  /**
   * Handles all records recieved from the MESSAGERATES records.
   * @param fcdrInputData the ForwardContractDealerRateInputData object which
   *                      includes all input data for the entire forward contract flow.
   * @param ccOutputDataForOriginalCurrenciesPair the CurrencyConversionOutputData
   *                                              object for the original currencies pair
   *                                              of the forward contract flow. 
   * @param fcdrOutputData the ForwardContractDealerRateOutputData object which
   *                       will be the returned object for the entire forward contract flow.
   */
  private void handleMessageRatesRecords(ForwardContractDealerRateInputData fcdrInputData, 
                                         CurrencyConversionOutputData ccOutputDataForOriginalCurrenciesPair, 
                                         ForwardContractDealerRateOutputData fcdrOutputData,
                                         Object[] arrMessageRates)
                                         throws CurrencyConversionException
  {
    final String METHOD_RESULTS = "Final composite amount = {}, Final rate = {}, Rate accuracy = {}.";
    
    
    
    // This will be the composite amount in the original currency 2 value.
    // It will be passed in each step of the 3 steps and will be increased accordingly.
    Double[] arrCompositeAmount = new Double[]{ServerConstants.DOUBLE_ZERO};
    
    // Will be updated with the total amount of all AMOUNT columns for the current
    // dealt step and will be used for determining the 'amount to convert' for the
    // next step. 
    Double[] arrCurrentStepTotalMessageRatesAmount = new Double[]{ServerConstants.DOUBLE_ZERO};
    
    // Will hold the total converted amount for 'step 2' which is expressed in the
    // triangulation currency, and will be used as an input for 'step 3' records
    // calculation.
    Double[] arrStep2ConvertedAmount = new Double[]{ServerConstants.DOUBLE_ZERO};
    
    String sOffice = fcdrInputData.getOffice();
    ConversionType conversionType = fcdrInputData.getConversionType();
    
    Double dOriginalAmountToConvert = fcdrInputData.getAmountToConvert();
    Double dCurrentStepAmountToConvert = null;
    
    boolean bCrossCurrencyUsed = ccOutputDataForOriginalCurrenciesPair.isCrossCurrencyUsed();
    
    List<ForwardContractLineType> listMessageRatesStep1 = (List<ForwardContractLineType>)arrMessageRates[0];
    List<ForwardContractLineType> listMessageRatesStep2 = (List<ForwardContractLineType>)arrMessageRates[1];
    List<ForwardContractLineType> listMessageRatesStep3 = (List<ForwardContractLineType>)arrMessageRates[2];
    
    // Gets an array of ExchangeRateOutputData objects which is 3-size array
    // and holds ExchangeRateOutputData object for each specific step, respectively.
    ExchangeRateOutputData[] arrExchangeRateOutputDataObjects = getExchangeRateOutputDataObjects(fcdrInputData.getCurrency1(),
                                                                                                 fcdrInputData.getCurrency2(),
                                                                                                 ccOutputDataForOriginalCurrenciesPair);

    boolean bSuccess = true;
    
    // STEP 1 - 
    // Handles 'step 1' records, in which CCY1 = currency 1 & CCY2 = currency 2.
    //
    // The amount to convert is the original amount to convert of the entire
    // forward contract flow.
    dCurrentStepAmountToConvert = dOriginalAmountToConvert;
    //  
    // Calculate the composite amount & adds, if requires, residual records for step 1.
    // The value within 'arrCurrentStepTotalMessageRatesAmount' is expressed in 
    // the original currency 1.
    bSuccess = handleOneStepMessageRatesRecords(listMessageRatesStep1, fcdrInputData,
                                                ccOutputDataForOriginalCurrenciesPair,
                                                fcdrOutputData, arrExchangeRateOutputDataObjects,
                                                1, dCurrentStepAmountToConvert, 
                                                arrCurrentStepTotalMessageRatesAmount,
                                                arrStep2ConvertedAmount,
                                                arrCompositeAmount);
    
    // Need to continue to 'step 2' & 'step 3' records only if the conversion
    // for the original currencies pair included CROSS CURRENCY.
    //
  	// ASAF - 09/03/2010:
  	//   Remarked the execution of step 2 and step 3 logic as for now, we won't allow input of forward contract records
  	//   which are not from step 1 type.
  	//   In addition, see related remarked code in the 'handleOneStepMessageRatesRecords' method, (look for "//if(!bCrossCurrencyUsed)").
//    if(bSuccess && bCrossCurrencyUsed)
//    {
//      // STEP 2 - 
//      // Handles 'step 2' records, in which CCY1 = currency 1 & CCY2 = triangulation currency.
//      //
//      // The amount to convert depends on whether we had 'step 1' records or not:
//      // - If yes, then some of the original amount to convert was already converted 
//      //   using these records and we need to subtract this amount from the original
//      //   amount to convert.
//      // - If no, then the amount to convert is the original amount to convert of 
//      //   the entire forward contract flow.
//      // For both cases, we use the same line as in case of no step 1 records, the
//      // 'arrCurrentStepTotalMessageRatesAmount[0]' remains with its initial 0 value.
//      dCurrentStepAmountToConvert = dOriginalAmountToConvert - arrCurrentStepTotalMessageRatesAmount[0];
//      
//      // Resets this variable; the returned amount is expressed in the original currency 1.
//      arrCurrentStepTotalMessageRatesAmount[0] = new Double(0);
//      //
//      // Calculate the composite amount & adds, if requires, residual records for step 2.
//      bSuccess = handleOneStepMessageRatesRecords(listMessageRatesStep2, fcdrInputData,
//                                                  ccOutputDataForOriginalCurrenciesPair,
//                                                  fcdrOutputData, arrExchangeRateOutputDataObjects,
//                                                  2, dCurrentStepAmountToConvert, 
//                                                  arrCurrentStepTotalMessageRatesAmount,
//                                                  arrStep2ConvertedAmount,
//                                                  arrCompositeAmount);
//  
//      // STEP 3 - 
//      // Handles 'step 3' records, in which CCY1 = triangulation currency & CCY2 = currency 2.
//      //
//      // The amount to convert is the value in 'arrStep2ConvertedAmount[0]', which
//      // was updated during the 'handleOneStepMessageRatesRecords' when it was called
//      // for 'step 2' records.
//      if(bSuccess)
//      {
//        dCurrentStepAmountToConvert = arrStep2ConvertedAmount[0];
//        
//        // Resets this variable; the returned amount is expressed in the triangulation currency.
//        arrCurrentStepTotalMessageRatesAmount[0] = new Double(0);
//        //
//        // Calculate the composite amount & adds, if requires, residual records for step 3.
//        bSuccess = handleOneStepMessageRatesRecords(listMessageRatesStep3, fcdrInputData,
//                                                    ccOutputDataForOriginalCurrenciesPair,
//                                                    fcdrOutputData, arrExchangeRateOutputDataObjects,
//                                                    3, dCurrentStepAmountToConvert, 
//                                                    arrCurrentStepTotalMessageRatesAmount,
//                                                    arrStep2ConvertedAmount,
//                                                    arrCompositeAmount);
//      }
//    }
      
    if(bSuccess)
    {
      // STEP 4 - 
      // Updates the passed ForwardContractDealerRateOutputData object which is the output
      // object for the entire forward contract flow with all message rates records;
      // it will include the original ones as well as the residual ones, (if such ones
      // were added during the process).
      List<ForwardContractLineType> listMessageRates = fcdrOutputData.getMessageRates();
      listMessageRates.addAll((List<ForwardContractLineType>)arrMessageRates[0]);
      listMessageRates.addAll((List<ForwardContractLineType>)arrMessageRates[1]);
      listMessageRates.addAll((List<ForwardContractLineType>)arrMessageRates[2]);
      
      // STEP 5 -
      // Updates the output object with the composite amount which will be the 
      // final converted amount.
      Double dConvertedAmount = adjustAmountToPrecision(fcdrInputData.getCurrency2(), arrCompositeAmount[0],fcdrInputData.isToAdjustPrecision());
      fcdrOutputData.setConvertedAmount(dConvertedAmount);
  
      // STEP 6 -
      // Calculates the composite rate.
      ExchrateCfg oExchrateCfg = !bCrossCurrencyUsed ?
                                 ccOutputDataForOriginalCurrenciesPair.getExchangeRateOutputData().getExchrateCfg() :
                                 ((CrossCurrencyConversionOutputData)ccOutputDataForOriginalCurrenciesPair).getExchrateCfgForOriginalCurrenciesPair();
  
      Object[] arrRateAndRateAccuracy = calculateRateAndRateAccuracy(dOriginalAmountToConvert, arrCompositeAmount[0], 
                                                                     fcdrInputData.getCurrency1(),
                                                                     fcdrInputData.getCurrency2(),
                                                                     oExchrateCfg,
                                                                     ccOutputDataForOriginalCurrenciesPair.getExchangeRateOutputData(),
                                                                     ccOutputDataForOriginalCurrenciesPair.getExchangeRateOutputDataStep2());
  
      Double dFinalRate = (Double)arrRateAndRateAccuracy[0];
      fcdrOutputData.setRate(dFinalRate);
      
      int iRateAccuracy = (Integer)arrRateAndRateAccuracy[1];
      fcdrOutputData.setRateAccuracy(iRateAccuracy);
      
      logger.info(METHOD_RESULTS, new Object[] {arrCompositeAmount[0], dFinalRate, iRateAccuracy});
    }
    
    
  }
  
  /**
   * Handles one of the steps in the forward contract flow.
   * Gets a list of ForwardContractLineType objects for the dealt step, and calculates the 
   * composite amount for this step while adding it to the amount in the passed
   * 'arrCompositeAmount' parameter.
   * For 'step 2' the calculated converted amount is expressed in the triangulation
   * currency, and won't be added into the composite amount but into the passed
   * 'arrStep2ConvertedAmount' parameter, which will be later used as the input
   * amount for 'step 3' records.
   * The calculation includes all validations as well.
   * In addition, it will add residual record for the dealt step, if that is required.
   * @param listOneStepMessageRates list of ForwardContractLineType objects for the dealt step;
   *                                might be empty but it is never null, as it is
   *                                being initialized by the caller method.
   * @param fcdrInputData the ForwardContractDealerRateInputData object which
   *                      includes all input data for the entire forward contract flow.
   * @param ccOutputDataForOriginalCurrenciesPair the CurrencyConversionOutputData
   *                                              object for the original currencies pair
   *                                              of the forward contract flow. 
   * @param fcdrOutputData the ForwardContractDealerRateOutputData object which
   *                       will be the returned object for the entire forward contract flow.
   * @param arrExchangeRateOutputDataObjects 3-size array that holds ExchangeRateOutputData 
   *                                         object for each specific step, respectively.
   * @param iStep the step we're in: 1, 2 or 3.
   * @param dAmountToConvert the amount to convert in this step, where when 'iStep'
   *                         equals 1 or 2, then the amount is expressed in the original
   *                         currency 1, and when 'iStep' is 3, then the amount is
   *                         expressed in the triangulation currency.
   * @param arrCurrentStepTotalMessageRatesAmount will be updated with the total
   *                                              amount of all AMOUNT columns for
   *                                              the dealt step.
   * @param arrStep2ConvertedAmount will be updated when we deal with step 2 with
   *                                step 2's total converted amount; the amount in it  
   *                                is expressed in the triangulation currency.
   * @param arrCompositeAmount will be updated with the calculated composite amount
   *                           of this method, if update is required, (won't be done
   *                           when 'iStep' is 2, in which the calculated amount is 
   *                           expressed in the triangulation currency).
   * @return bSuccess true or false for successfull validations.                              
   */
  private boolean handleOneStepMessageRatesRecords(List<ForwardContractLineType> listOneStepMessageRates,
                                                   ForwardContractDealerRateInputData fcdrInputData,
                                                   CurrencyConversionOutputData ccOutputDataForOriginalCurrenciesPair,
                                                   ForwardContractDealerRateOutputData fcdrOutputData,
                                                   ExchangeRateOutputData[] arrExchangeRateOutputDataObjects,
                                                   int iStep,
                                                   Double dAmountToConvert,
                                                   Double[] arrCurrentStepTotalMessageRatesAmount,
                                                   Double[] arrStep2ConvertedAmount,
                                                   Double[] arrCompositeAmount)
                                                   throws CurrencyConversionException
  {
    
    
    boolean bSuccess = true;
    
    String sOffice = fcdrInputData.getOffice();
    ConversionType conversionType = fcdrInputData.getConversionType();
    RateUsage rateUsage = fcdrInputData.getRateUsage();
    boolean bCrossCurrencyUsed = ccOutputDataForOriginalCurrenciesPair.isCrossCurrencyUsed();
    String sOriginalCurrency1 = fcdrInputData.getCurrency1();
    String sOriginalCurrency2 = fcdrInputData.getCurrency2();
    String sTriangulationCurrency = ccOutputDataForOriginalCurrenciesPair.getTriangulationCurrency();
    
    // No need to perform validations if no records exist for the dealt step.
    if(!listOneStepMessageRates.isEmpty())
    {
      // STEP 1 - 
      // Performs validations & calculates the composite amount for the list of 
      // MessageRates objects which stand for one of the steps of optional forward contract
      // records within the MESSAGERATES table.
      // This method will also update the the total composite amount if the dealt
      // step's calculations should be added to the that amount.
      bSuccess = performOneStepForwardContractValidations(listOneStepMessageRates, 
                                                          ccOutputDataForOriginalCurrenciesPair,
                                                          fcdrInputData,
                                                          fcdrOutputData,
                                                          iStep, sOffice, dAmountToConvert,
                                                          rateUsage,
                                                          arrExchangeRateOutputDataObjects,
                                                          arrCurrentStepTotalMessageRatesAmount, 
                                                          arrStep2ConvertedAmount,
                                                          arrCompositeAmount);
    }
    
    // STEP 2 - 
    // Determines the right ExchangeRateOutputData object for each step.
    ExchangeRateOutputData exchangeRateOutputDataStep1Records = arrExchangeRateOutputDataObjects[0];
    ExchangeRateOutputData exchangeRateOutputDataStep2Records = arrExchangeRateOutputDataObjects[1];
    ExchangeRateOutputData exchangeRateOutputDataStep3Records = arrExchangeRateOutputDataObjects[2];
    
    // STEP 3 - 
    // No problems were found during validations; continues to check if there is
    // a need for a residual record.
    if(bSuccess)
    {
      // Gets the total amount from all AMOUNT columns of the message rates records
      // for the dealt step.
      double dCurrentStepTotalMessageRatesAmount = arrCurrentStepTotalMessageRatesAmount[0];
      Double dResidualAmount = null;
      
      // Residual records are required.
      if(dCurrentStepTotalMessageRatesAmount < dAmountToConvert)
      {
        String sConversionType = conversionType.toString().equals(ConversionType.Credit.toString()) ?
                                 MESSAGERATES_CONVERSION_TYPE_CR : MESSAGERATES_CONVERSION_TYPE_DR;
        
        PDO pdo = Admin.getContextPDO();
        String sMID = pdo.getString(P_MID);
        
        final String CURRENT_STEP_RESIDUAL_CONVERTED_AMOUNT_RESULT = "Step {} residual converted amount: {} {}.";
        Double dCurrentStepResidualConvertedAmount = null;
        
        // NOTE: 
        // Although the basic initialization of this record is the same for each step,
        // it should be done separatly in each step, because there are cases where
        // eventually a residual record WON'T BE ADDED !!! Could have collect all
        // the cases and perform the initialization here, but for the sake of readability
        // and clarity we leave it inside each step.
        ForwardContractLineType forwardContractLineCurrentStepResidualRecord = null;
        
        String sMessageForResidualConvertedAmount = null;
        
        // Finished with 'step 1' records.
        if(iStep == 1)
        {
          // In case DIRECT conversion was used during the conversion of the original
          // currencies pair, then it means that no other steps will be performed
          // and we need to add a residual record, which is between the 2 original currencies.
        	//
        	// ASAF - 09/03/2010:
        	//   Remarked the boolean condition as for now, we won't allow input of forward contract records
        	//   which are not from step 1 type; as a result, a residual line, if required, will be added while
        	//   handling step 1.
        	//   In addition, see related remarked code in the 'handleMessageRatesRecords' method.
        	//
          //if(!bCrossCurrencyUsed)
          {
            // Initializes the residual record with all basic data.
            // This record is between original currency 1 & the original currency 2.
            forwardContractLineCurrentStepResidualRecord = ForwardContractLineType.Factory.newInstance();
            forwardContractLineCurrentStepResidualRecord.pseudoConstrsuctor(sMID, MESSAGERATES_FORWARD_CONTRACT_VALUE_RESIDUAL);
            forwardContractLineCurrentStepResidualRecord.setFFCCONVERSIONTYPE(sConversionType.equals(MESSAGERATES_CONVERSION_TYPE_CR)? FCConversionType.CR : FCConversionType.DR);
            
            // Residual amount is expressed in the original currency 1 of the forward contract flow.
            dResidualAmount = dAmountToConvert - arrCurrentStepTotalMessageRatesAmount[0];
            dResidualAmount = adjustAmountToPrecision(sOriginalCurrency1, dResidualAmount,fcdrInputData.isToAdjustPrecision());
            forwardContractLineCurrentStepResidualRecord.setFFCAMOUNT(BigDecimal.valueOf(dResidualAmount));
            
            Object[] arrRateAndAccuracy = adjustRateToPrecision(ccOutputDataForOriginalCurrenciesPair.getRate(), exchangeRateOutputDataStep1Records.getExchrateCfg());
            forwardContractLineCurrentStepResidualRecord.setFFCRATE(BigDecimal.valueOf((Double)arrRateAndAccuracy[0]));
            
            forwardContractLineCurrentStepResidualRecord.setFFCCURRENCY1(sOriginalCurrency1);
            forwardContractLineCurrentStepResidualRecord.setFFCCURRENCY2(sOriginalCurrency2);
            
            // Composite amount handling:
            // - It already includes the sum of all 'step 1' records conversions,
            // which were calculated during the 'performOneStepForwardContractValidations'
            // method.
            // - Adds to the composite amount the result of converting the 'messageRatesSte13ResidualRecord'
            // data; i.e. we need to call 'calculateConvertedAmount' while passing it
            // the 'step 1' residual record's following attributes: AMOUNT, CCY1, CCY2.
            // In addition, the rate will be taken from the 'exchangeRateOutputDataStep1Records'
            // variable; alternatively, we could have sent the residual record's RATE
            // column value, which is the same.
            dCurrentStepResidualConvertedAmount = calculateConvertedAmount(exchangeRateOutputDataStep1Records, 
                                                                           dResidualAmount, sOriginalCurrency1, sOriginalCurrency2,
                                                                           null,fcdrInputData.isToAdjustPrecision());
            sMessageForResidualConvertedAmount = String.format(CURRENT_STEP_RESIDUAL_CONVERTED_AMOUNT_RESULT, iStep, dCurrentStepResidualConvertedAmount, sOriginalCurrency2); 

            arrCompositeAmount[0] += dCurrentStepResidualConvertedAmount;
            
            // Adds this residual record to the list of 'step 1' records. 
            listOneStepMessageRates.add(forwardContractLineCurrentStepResidualRecord);
          }
        }
        
        // Finished with 'step 2' records.
        else if(iStep == 2)
        {
          // We need to add a residual record only if CROSS CURRENCY was used during
          // the conversion of the original currencies pair.
          //
          // This residual record is between original currency 1 & the triangulation currency.
          if(bCrossCurrencyUsed)
          {
            // Initializes the residual record with all basic data.
            // This record is between original currency 1 & the triangulation currency.
            forwardContractLineCurrentStepResidualRecord = ForwardContractLineType.Factory.newInstance();
            forwardContractLineCurrentStepResidualRecord.pseudoConstrsuctor(sMID, MESSAGERATES_FORWARD_CONTRACT_VALUE_RESIDUAL);
            forwardContractLineCurrentStepResidualRecord.setFFCCONVERSIONTYPE(sConversionType.equals(MESSAGERATES_CONVERSION_TYPE_CR)? FCConversionType.CR : FCConversionType.DR);
            
            // Residual amount is expressed in the original currency 1 of the forward contract flow.
            dResidualAmount = dAmountToConvert - arrCurrentStepTotalMessageRatesAmount[0];
            dResidualAmount = adjustAmountToPrecision(sOriginalCurrency1, dResidualAmount,fcdrInputData.isToAdjustPrecision());
            forwardContractLineCurrentStepResidualRecord.setFFCAMOUNT(BigDecimal.valueOf(dResidualAmount));  
            
            // The rate is the one from the ExchangeRateOutputData used for 'step 2' records.
            // This is the same value as 'ccOutputDataForOriginalCurrenciesPair.getRateStep1'
            // as cross currency was surely performed during the conversion. 
            Object[] arrRateAndAccuracy = adjustRateToPrecision(exchangeRateOutputDataStep2Records.getRate(), exchangeRateOutputDataStep2Records.getExchrateCfg());
            forwardContractLineCurrentStepResidualRecord.setFFCRATE(BigDecimal.valueOf((Double)arrRateAndAccuracy[0]));
            
            forwardContractLineCurrentStepResidualRecord.setFFCCURRENCY1(sOriginalCurrency1);
            forwardContractLineCurrentStepResidualRecord.setFFCCURRENCY2(sTriangulationCurrency);
            
            // Updates 'step 2' TOTAL converted amount, which will be:
            // 1) Sum of all 'step 2' records conversions; that was calculated during the
            //    'performOneStepForwardContractValidations' method.
            //   PLUS
            // 2) The result of converting the 'messageRatesStep2ResidualRecord' data;
            //    i.e. we need to call 'calculateConvertedAmount' while passing it
            //    the 'step 2' residual record's following attributes: AMOUNT, CCY1, CCY2.
            //    In addition, the rate will be taken from the 'exchangeRateOutputDataStep2Records'
            //    variable; alternatively, we could have sent the residual record's RATE
            //    column value, which is the same.
            // This amount will be used in the 'handleMessageRates' method as the
            // input amount for 'step 3' records.
            dCurrentStepResidualConvertedAmount = calculateConvertedAmount(exchangeRateOutputDataStep2Records, 
                                                                           dResidualAmount, sOriginalCurrency1, sTriangulationCurrency,
                                                                           null,fcdrInputData.isToAdjustPrecision());
            sMessageForResidualConvertedAmount = String.format(CURRENT_STEP_RESIDUAL_CONVERTED_AMOUNT_RESULT, iStep, dCurrentStepResidualConvertedAmount, sTriangulationCurrency);

            arrStep2ConvertedAmount[0] += dCurrentStepResidualConvertedAmount;
            
            // Adds this residual record to the list of 'step 2' records. 
            listOneStepMessageRates.add(forwardContractLineCurrentStepResidualRecord);
          }
        }
        
        // Finished with 'step 3' records.
        else
        {
          // We need to add a residual record only if CROSS CURRENCY was used during
          // the conversion of the original currencies pair.
          //
          // This record is between the triangulation currency & the original currency 2.
          if(bCrossCurrencyUsed)
          {
            // Initializes the residual record with all basic data.
            // This record is between the triangulation currency & the original currency 2.
            forwardContractLineCurrentStepResidualRecord = ForwardContractLineType.Factory.newInstance();
            forwardContractLineCurrentStepResidualRecord.pseudoConstrsuctor(sMID, MESSAGERATES_FORWARD_CONTRACT_VALUE_RESIDUAL);
            forwardContractLineCurrentStepResidualRecord.setFFCCONVERSIONTYPE(sConversionType.equals(MESSAGERATES_CONVERSION_TYPE_CR)? FCConversionType.CR : FCConversionType.DR);
            
            // Residual amount is expressed in the original currency 1 of the forward contract flow.
            dResidualAmount = dAmountToConvert - arrCurrentStepTotalMessageRatesAmount[0];
            dResidualAmount = adjustAmountToPrecision(sTriangulationCurrency, dResidualAmount,fcdrInputData.isToAdjustPrecision());
            forwardContractLineCurrentStepResidualRecord.setFFCAMOUNT(BigDecimal.valueOf(dResidualAmount));  
            
            // The rate is the one from the ExchangeRateOutputData used for 'step 2' records.
            Object[] arrRateAndAccuracy = adjustRateToPrecision(exchangeRateOutputDataStep3Records.getRate(), exchangeRateOutputDataStep3Records.getExchrateCfg());
            forwardContractLineCurrentStepResidualRecord.setFFCRATE(BigDecimal.valueOf((Double)arrRateAndAccuracy[0]));
            
            forwardContractLineCurrentStepResidualRecord.setFFCCURRENCY1(sTriangulationCurrency);
            forwardContractLineCurrentStepResidualRecord.setFFCCURRENCY2(sOriginalCurrency2);
            
            // Composite amount handling:
            // - It already includes the sum of all 'step 3' records conversions,
            // which were calculated during the 'performOneStepForwardContractValidations'
            // method, (true only if we had actual 'step 3' records).
            // - Adds to the compoiste amount the result of converting the 'messageRatesStep3ResidualRecord'
            // data; i.e. we need to call 'calculateConvertedAmount' while passing it
            // the 'step 3' residual record's following attributes: AMOUNT, CCY1, CCY2.
            // In addition, the rate will be taken from the 'exchangeRateOutputDataStep3Records'
            // variable; alternatively, we could have sent the residual record's RATE
            // column value, which is the same.
            dCurrentStepResidualConvertedAmount = calculateConvertedAmount(exchangeRateOutputDataStep3Records, 
                                                                           dResidualAmount, sTriangulationCurrency, sOriginalCurrency2,
                                                                           null,fcdrInputData.isToAdjustPrecision());
            sMessageForResidualConvertedAmount = String.format(CURRENT_STEP_RESIDUAL_CONVERTED_AMOUNT_RESULT, iStep, dCurrentStepResidualConvertedAmount, sOriginalCurrency2); 

            arrCompositeAmount[0] += dCurrentStepResidualConvertedAmount;
            
            // Adds this residual record to the list of 'step 3' records. 
            listOneStepMessageRates.add(forwardContractLineCurrentStepResidualRecord);
          }
        }
        
        // A residual record was added.
        if(forwardContractLineCurrentStepResidualRecord != null)
        {
          if(sMessageForResidualConvertedAmount != null)
          {
            logger.info(sMessageForResidualConvertedAmount);
            //
            // Adds in runtime the residual message to the ForwardContractLineType object;
            // The 'addMessageResidualAmountAfterConversion' method was added into the
            // 'ForwardContractLineType' interface using the 'xbean_extensions.xsdconfig' file.
            // See there and also the 'New Generation - XML Beans Related Issues.doc'
            // document for full explanations how it is being done.
            forwardContractLineCurrentStepResidualRecord.addMessageResidualAmountAfterConversion(sMessageForResidualConvertedAmount);
          }
          
          // Increases number of added residual records, for tracing.
          fcdrOutputData.increaseNumOfAddedResidualRecords();
          
          // Performs validations on the residual record.
          validateThreshold(fcdrInputData, fcdrOutputData, false, forwardContractLineCurrentStepResidualRecord.getFFCAMOUNT().doubleValue());
          validateExpiryDate(fcdrInputData, fcdrOutputData);
        }
      }
    }
    
    
    
    return bSuccess;
  }  
  
  /**
   * Returns 3-size array of ExchangeRateOutputData objects to be used 
   * for step 1, step 2 & step 3 records, respectively.
   */
  private ExchangeRateOutputData[] getExchangeRateOutputDataObjects(String sCurrency1, String sCurrency2,
                                                                    CurrencyConversionOutputData ccOutputDataForOriginalCurrenciesPair)
  {
    
    
    ExchangeRateOutputData[] arrExchangeRateOutputData = new ExchangeRateOutputData[3];
    
    boolean bCrossCurrencyUsed = ccOutputDataForOriginalCurrenciesPair.isCrossCurrencyUsed();

    // In that case, indexes 1 & 2 remain null.
    if(!bCrossCurrencyUsed)
    {
      arrExchangeRateOutputData[0] = ccOutputDataForOriginalCurrenciesPair.getExchangeRateOutputData();
    }
    
    else // Cross currency.
    {
      // In case of cross currency, we need to prepare a special ExchangeRateOutputData
      // object for the 'step 1' records, with all data required for a future
      // call to the 'calculateConvertedAmount' method.
      arrExchangeRateOutputData[0] = getExchangeRateOutputDataObjectForStep1Records
                                           (sCurrency1, sCurrency2, (CrossCurrencyConversionOutputData)ccOutputDataForOriginalCurrenciesPair);
      
      // For 'step 2' records the used rate will be from the ExchangeRateOutputData
      // object which was used for the conversion between currency 1 & the triangulation currency.
      // This ExchangeRateOutputData is also known as 'ExchangeRateOutputData step 1'
      // where in this case, 'step 1' refers to step 1 in the cross currency process,
      // which was done for the original currencies pair.
      arrExchangeRateOutputData[1] = ccOutputDataForOriginalCurrenciesPair.getExchangeRateOutputData();
      
      // For 'step 3' records the used rate will be from the ExchangeRateOutputData
      // object which was used for the conversion between currency 1 & the triangulation currency.
      // This ExchangeRateOutputData is also known as 'ExchangeRateOutputData step 2'
      // where in this case, 'step 2' refers to step 2 in the cross currency process,
      // which was done for the original currencies pair.
      arrExchangeRateOutputData[2] = ccOutputDataForOriginalCurrenciesPair.getExchangeRateOutputDataStep2();
    }
    
    
    
    return arrExchangeRateOutputData;
  }
  
  /**
   * Returns ExchangeRateOutputData object to be used for calculation of converted
   * amount in all 'step 1' records when cross currency was involved during the 
   * forward contract flow.
   */
  private ExchangeRateOutputData getExchangeRateOutputDataObjectForStep1Records
                                       (String sCurrency1, String sCurrency2,
                                        CrossCurrencyConversionOutputData ccOutputDataForOriginalCurrenciesPair)
  {
    
    
    ExchangeRateOutputData exchangeRateOutputDataStep1Records = new ExchangeRateOutputData();

    // STEP 1 - 
    // Determines the ExchrateCfg to use which the units values within it will be used
    // during the 'calculateConvertedAmount' method.
    ExchrateCfg exchrateCfgForOriginalCurrenciesPair = ccOutputDataForOriginalCurrenciesPair.getExchrateCfgForOriginalCurrenciesPair();
    
    // Dummy ExchrateBu object; will be updated according to whether we have a valid ExchrateCfg object.
    ExchrateBu exchrateBu = new ExchrateBu();
    
    // There was an ExchrateCfg record for the original currencies pair; the values
    // within it should be used for the calculation of the converted amount of
    // all 'step 1' records.
    if(exchrateCfgForOriginalCurrenciesPair != null)
    {
      exchangeRateOutputDataStep1Records.setExchrateCfg(exchrateCfgForOriginalCurrenciesPair);
      
      // Dummy ExchrateBu object update.
      exchrateBu.setCcy1(exchrateCfgForOriginalCurrenciesPair.getCcy1());
      exchrateBu.setCcy2(exchrateCfgForOriginalCurrenciesPair.getCcy2());
    }
    //
    // Will use dummy ExchrateCfg object, in which the currencies' units are 1 & 1.
    else
    {
    	// Gets the ExchangeRateOutputData object that was used for step 2 of the cross currency that was performed
    	// between the original currencies pair.
    	// This object's direct/indirect conversion boolean was set during the 'calculateRateAndRateAccuracy' method
    	// and according to that boolean, we need to either:
    	//  - Direct: multiply the converted amount in the rate.
    	//  - Indirect: divide the converted amount in the rate.
    	// This will be done in the 'calculateConvertedAmount' method.
    	// The direction will also determines which currency will be used as currency 1 and which one will be used as 
    	// currency 2 in the constructed dummy ExchrateCfg object.
    	ExchangeRateOutputData exchangeRateOutputDataStep2 = ccOutputDataForOriginalCurrenciesPair.getExchangeRateOutputDataStep2();
    	
    	exchangeRateOutputDataStep1Records.setDirectConversion(exchangeRateOutputDataStep2.isDirectConversion());
    	
    	// Prepares dummy ExchrateCfg object.
      ExchrateCfg dummyExchrateCfg = new ExchrateCfg();
      
      // Determines which currency is currency 1 and which one is currency 2 according to the direct/indirect boolean.
      if(exchangeRateOutputDataStep1Records.isDirectConversion())
      {
	      dummyExchrateCfg.setCcy1(sCurrency1);
	      dummyExchrateCfg.setCcy2(sCurrency2);
      }
      else
      {
	      dummyExchrateCfg.setCcy1(sCurrency2);
	      dummyExchrateCfg.setCcy2(sCurrency1);
      }

      dummyExchrateCfg.setCcy1Unit(LONG_ONE);
      dummyExchrateCfg.setCcy2Unit(LONG_ONE);

      // This will be used for the rate accuracy; we take the one from the conversion
      // that was performed for the orignal currencies pair.
      // Because we reached here, it means that there is no EXCHRATE_CFG record
      // for the original currencies pair, cross currency was performed, an the used
      // rate accuracy is the one determined during that conversion.
      dummyExchrateCfg.setDecNo(Long.valueOf(ccOutputDataForOriginalCurrenciesPair.getRateAccuracy()));

      // Setting into returned object.
      exchangeRateOutputDataStep1Records.setExchrateCfg(dummyExchrateCfg);
      
      // Dummy ExchrateBu object update in which we currency 1 to be currency 1 of 'dummyExchrateCfg' and currency 2 to be currency 2
      // of 'dummyExchrateCfg'.
      // This object is required in the 'calculateConvertedAmount' method in which we need the ExchrateBu object to determine 
      // the units we'll use for the conversion action; we actually prepare this dummy object to prevent NullPointerException there; 
      // see there the following line code: "if(exchrateCfg.getCcy1().equals(exchangeRateOutputData.getExchrateBu().getCcy1()))".
      exchrateBu.setCcy1(dummyExchrateCfg.getCcy1());
      exchrateBu.setCcy2(dummyExchrateCfg.getCcy2());
    }
    
    // Setting into returned object.
    exchangeRateOutputDataStep1Records.setExchrateBu(exchrateBu);
    
    // STEP 2 - 
    // Sets the rate to be the rate of the conversion between the original currencies
    // pair and determines the direction according to that rate.
    Double dRateForOriginalCurrenciesPairConversion = ccOutputDataForOriginalCurrenciesPair.getRate();
    exchangeRateOutputDataStep1Records.setRate(dRateForOriginalCurrenciesPairConversion);
    
    
    
    return exchangeRateOutputDataStep1Records;
  }
  
  /**
   * Gets a list of ForwardContractLineType objects for one of the steps in the forward contract flow,
   * and performs forward contract validations on it while calculating the composite
   * amount for the dealt step, if it is relevant.
   * @param listOneStepMessageRates list of ForwardContractLineType objects which stand for one
   *                                of the steps in the forward contract flow.
   * @param ccOutputDataForOriginalCurrenciesPair the CurrencyConversionOutputData
   *                                              object for the original currencies pair
   *                                              of the forward contract flow. 
   * @param fcdrInputData the ForwardContractDealerRateInputData object which
   *                      includes all input data for the entire forward contract flow.
   * @param fcdrOutputData the ForwardContractDealerRateOutputData object which
   *                       will be the returned object for the entire forward contract flow.
   * @param dAmountToConvert the amount to convert in this step, where when 'iStep'
   *                         equals 1 or 2, then the amount is expressed in the original
   *                         currency 1, and when 'iStep' is 3, then the amount is
   *                         expressed in the triangulation currency.
   * @param rateUsage the RateUsage object which is the same for all steps and its 
   *                  origin is the input data for the entire forward contract flow.
   * @param arrExchangeRateOutputDataObjects 3-size array that holds ExchangeRateOutputData 
   *                                         object for each specific step, respectively.
   * @param arrTotalMessageRatesAmount will be updated with the total amount of all 
   *                                   AMOUNT columns for the dealt step and will be used
   *                                   for the validation of the total amount of 
   *                                   the message rates.
   *                                   Each amount in the MESSAGERATES.AMOUNT
   *                                   column is considered as in the same currency as the
   *                                   passed 'dAmountToConvert' parameter is expressed in.
   *                                   In addition, it will be used in the caller method
   *                                   to calculate the 'amount to convert' for the
   *                                   next step; see there.
   * @param arrStep2ConvertedAmount will be updated when we deal with step 2 with
   *                                step 2's total converted amount; the amount in it  
   *                                is expressed in the triangulation currency.
   * @param arrCompositeAmount will be updated with the calculated composite amount
   *                           of this method, if update is required, (won't be done
   *                           when 'iStep' is 2, in which the calculated amount is 
   *                           expressed in the triangulation currency).
   */
  private boolean performOneStepForwardContractValidations(List<ForwardContractLineType> listOneStepMessageRates,
                                                           CurrencyConversionOutputData ccOutputDataForOriginalCurrenciesPair,
                                                           ForwardContractDealerRateInputData fcdrInputData,
                                                           ForwardContractDealerRateOutputData fcdrOutputData,
                                                           int iStep, String sOffice,
                                                           Double dAmountToConvert, RateUsage rateUsage,
                                                           ExchangeRateOutputData[] arrExchangeRateOutputDataObjects,
                                                           Double[] arrTotalMessageRatesAmount,
                                                           Double[] arrStep2ConvertedAmount,
                                                           Double[] arrCompositeAmount) throws CurrencyConversionException
  {
    
    
    boolean bSuccess = true;
    
    boolean[] arrFoundEmptyFCAmount = new boolean[]{false};
    boolean[] arrFoundEmptyFCContract = new boolean[]{false};
    
    boolean bFoundEmptyRate = false;
    boolean bFoundToleranceError = false;
    boolean bTotalAmountExceedsAmountToConvert = false;
    
    boolean bContinue = true;
    
    Double[] arrExternalInterfaceRate = new Double[1];
    
    // Gets the RATETOLR system parameter value.
    final SystPar oSystPar_RATETOLR = CacheKeys.SystParKey.getSingle(sOffice, SystemParametersInterface.SYS_PAR_RATETOLR);
    
    Double dSysPar_RATETOLR = oSystPar_RATETOLR != null ? 
                              new Double(oSystPar_RATETOLR.getParmValue()) : ServerConstants.DOUBLE_ZERO;
    
    // Gets the RATETOLR system parameter value.
    final SystPar oSystPar_RATETOLRNO = CacheKeys.SystParKey.getSingle(sOffice, SystemParametersInterface.SYS_PAR_RATETOLRNO);
                                                                             
    Double dSysPar_RATETOLRNO = oSystPar_RATETOLRNO != null ? 
                                new Double(oSystPar_RATETOLRNO.getParmValue()) : ServerConstants.DOUBLE_ZERO;
    
    String sRateUsageName = rateUsage.getRateUsageName();
    boolean bCrossCurrencyUsed = ccOutputDataForOriginalCurrenciesPair.isCrossCurrencyUsed();

    // Determines currency 1 & currency 2, which are always the same in each 
    // SPECIFIC step of the forward contract flow.
    String sOriginalCurrency1 = fcdrInputData.getCurrency1();
    String sOriginalCurrency2 = fcdrInputData.getCurrency2();
    String sTriangulationCurrency = ccOutputDataForOriginalCurrenciesPair.getTriangulationCurrency();
    //
    String sCurrency1 = null, sCurrency2 = null;
    if(iStep == 1)
    {
      sCurrency1 = sOriginalCurrency1;
      sCurrency2 = sOriginalCurrency2;
    }
    else if(iStep == 2)
    {
      sCurrency1 = sOriginalCurrency1;
      sCurrency2 = sTriangulationCurrency;
    }
    else // Step 3
    {
      sCurrency1 = sTriangulationCurrency;
      sCurrency2 = sOriginalCurrency2;
    }
    
    // Determines what ExchangeRateOutputData will be used for tolerance validation.
    ExchangeRateOutputData exchangeRateOutputDataToUse = arrExchangeRateOutputDataObjects[iStep-1];
    Double dExchangeRate = exchangeRateOutputDataToUse.getRate();
    
    Double dLastCheckedRecordAmount = null;
    
    // STEP 1 - 
    // Loops all message rates lines and performs:
    // 1) Mandatory fields validation.
    // 2) Forward contract rate and external interface validation.
    // 3) Tolerance validation.
    // 4) Sums the total amount and validates that it doesn't exceed the amount 
    //    to convert, (that is the passed 'dAmountToConvert' parameter).
    int iSize = listOneStepMessageRates.size();
    for(int i=0; i<iSize && bContinue; i++)
    {
      ForwardContractLineType forwardContractLine = listOneStepMessageRates.get(i);
      
      // Mandatory fields validation.
      // No need to perform the validation if we already found cases of empty 
      // AMOUNT & CONTRACT columns.
      if(!(arrFoundEmptyFCAmount[0] && arrFoundEmptyFCContract[0]))
      {
        validateForwardContractMandatoryFields(forwardContractLine, fcdrOutputData, arrFoundEmptyFCAmount, arrFoundEmptyFCContract);
      }
      
      // Forward contrcat rate and external interface validation.
      // No need to perform the validation if we already found an empty RATE column. 
      if(!bFoundEmptyRate)
      {
        arrExternalInterfaceRate[0] = new Double(0);
        bFoundEmptyRate = !validateForwardContractRateAndExternalInterface(forwardContractLine.getFFCRATE().doubleValue(), rateUsage, 
                                                                           fcdrOutputData, arrExternalInterfaceRate);
      }
      
      // No need to perform tolerance validation if there is no rate.
      if (!bFoundEmptyRate)
      {      
          // Tolerance validation.
          // In case the tolerance validation has failed, but the conversion
          // between the original currencies pair was a DIRECT one and didn't include
          // CROSS CURRENCY, sets back this boolean to false.
          bFoundToleranceError = !validateTolerance(fcdrOutputData, dSysPar_RATETOLR, dSysPar_RATETOLRNO, dExchangeRate, 
                                                    forwardContractLine.getFFCRATE().doubleValue(), sRateUsageName);
          bFoundToleranceError = bFoundToleranceError && bCrossCurrencyUsed;
      }
      
      // No need to continue if we failed one of the above validations, as the 
      // results won't be used after we return from this method with a false 'bSuccess'.
      bContinue =    !arrFoundEmptyFCAmount[0] /*&& !arrFoundEmptyFCContract[0]*/ 
                  && !bFoundEmptyRate && !bFoundToleranceError
                  && !bTotalAmountExceedsAmountToConvert;
      
      if(bContinue)
      {
        Double dAmount = forwardContractLine.getFFCAMOUNT().doubleValue();
        dLastCheckedRecordAmount = dAmount;
        
        // Sums the total amount which shouldn't exceed the amount to convert.
        arrTotalMessageRatesAmount[0] += dAmount;
        
        // Validates that the total amount doesn't exceed the amount to convert, 
        // which was passed as an input to this method.
        // Regarding the amount to convert:
        // - For 'iStep = 1', this value is actually 'fcdrInputData.getAmountToConvert()'
        //   and will be in the original currency 1.
        // - For 'iStep = 2' this value is: 
        //   'fcdrInputData.getAmountToConvert() minus the amount that was converted in step 1',
        //   and will be in the original currency 1.
        // - For 'iStep = 3', this value is the total of all 'step 2' records' conversions,
        //   (including a residual record, if such one is required), and it will be in
        //   the triangulation currency.
        bTotalAmountExceedsAmountToConvert = arrTotalMessageRatesAmount[0] > dAmountToConvert;

        // Total amount didn't exceed the amount to convert.
        if(!bTotalAmountExceedsAmountToConvert)
        {
          // Determines what rate will be used; the rate from this record or an external rate.
          // In any case, the found rate isn't being adjusted according to any precision.
          Double dForwardContractRateToUse = !nullNumberOrZero(arrExternalInterfaceRate[0]) ? arrExternalInterfaceRate[0] : forwardContractLine.getFFCRATE().doubleValue();
          
          // Calculates the converted amount for this record.
          // The ExchangeRateOutputData object that is used is the correct one for the
          // step we currently in and was determined in the caller method.
          Double dOneRecordCalculatedAmount = calculateConvertedAmount(exchangeRateOutputDataToUse, dAmount, sCurrency1, sCurrency2, dForwardContractRateToUse,fcdrInputData.isToAdjustPrecision());
          
          // For steps 1 & 3, the calculated amount is expressed in the target currency,
          // which is the original currency 2 of the forward contract flow, and thus 
          // we add it to the total composite amount.
          if(iStep == 1 || iStep == 3)
          {
            arrCompositeAmount[0] += dOneRecordCalculatedAmount;
          }
          
          else // Step 2.
          {
            arrStep2ConvertedAmount[0] += dOneRecordCalculatedAmount;
          }
        }
        
        // Total amount has exceed the amount to convert.
        // Process will be stopped !!!
        else
        {
          // Determines the exceeded amount to convert.
          Double dExceededAmountToConvert = null;
          //
          // For step 1, the reason is obvious.
          // For step 2, we should also take the original amount to convert and
          // NOT the 'dAmountToConvert' for that step.
          if(iStep == 1 || iStep == 2)
          {
            dExceededAmountToConvert = fcdrInputData.getAmountToConvert();
          }
          else // Step 3.
          {
            dExceededAmountToConvert = dAmountToConvert;
          }
          
          // Determines the final total amount that exceeded the amount to convert.
          Double dFinalTotalAmount = null;
          //
          // For step 1 & 3, the final total amount is the actual amount that was
          // calculated during the step till the validation has failed.
          if(iStep == 1 || iStep == 3)
          {
            dFinalTotalAmount = arrTotalMessageRatesAmount[0];
          }
          //
          // For step 2, we should sum the amount that was converted in step 1
          // plus the actual amount that was calculated during step 2 till the
          // validation has failed.
          else // Step 2.
          {
            Double dStep1AlreadyConvertedAmount = fcdrInputData.getAmountToConvert() - dAmountToConvert;
            dFinalTotalAmount = dStep1AlreadyConvertedAmount + arrTotalMessageRatesAmount[0];
          }
          
          // ERROR: Forward contract step %s: total amount entered %s for currency %s exceeds the amount to convert %s %s.
          String sErrorMessage = String.format(ERROR_MESSAGE_FORWARD_CONTRACT_TOTAL_AMOUNT_EXCEEDS_AMOUNT_TO_CONVERT, iStep, dFinalTotalAmount, sCurrency1, dExceededAmountToConvert, sCurrency1);
          logger.info(sErrorMessage);
          
          // Error code '40013': 'Total amount entered |1 for currency |2 exceeds the amount to convert |3 |4'.
          ProcessError processError = new ProcessError(ProcessErrorConstants.ForwardContractTotalAmountExceedsAmountToConvert,
                                                       new Object[]{dFinalTotalAmount, sCurrency1, dExceededAmountToConvert, sCurrency1});
          fcdrOutputData.getProcessErrorHolder().addError(processError);
          ErrorAuditUtils.setErrors(processError);
        }
      }
    }
    
    bSuccess =  !arrFoundEmptyFCContract[0] && !bFoundToleranceError && !bTotalAmountExceedsAmountToConvert;
    
    
    
    return bSuccess;
  }
  
  /**
   * Validates some mandatory forward contract fields in the passed ForwardContractLineType
   * object and adds errros to the passed ForwardContractDealerRateOutputData object
   * accordingly.
   */
  private void validateForwardContractMandatoryFields(ForwardContractLineType forwardContractLine, ForwardContractDealerRateOutputData fcdrOutputData,
                                                      boolean[] arrFoundEmptyFCAmount, boolean[] arrFoundEmptyFCContract)
  {
    
    
    // No need to perform the validation if we already found one empty 
    // MESSAGERATES.AMOUNT column.
    if(!arrFoundEmptyFCAmount[0])
    {
      // MESSAGERATES.AMOUNT column can't be empty.
      BigDecimal bdAmount = forwardContractLine.getFFCAMOUNT();
      if(nullNumberOrZero(bdAmount))
      {
        arrFoundEmptyFCAmount[0] = true;
        
        // Error code '40010': Message rates data includes empty AMOUNT column.
        fcdrOutputData.getProcessErrorHolder().addError(PROCESS_ERROR_FORWARD_CONTRACT_EMPTY_MESSAGERATES_AMOUNT);
        ErrorAuditUtils.setErrors(PROCESS_ERROR_FORWARD_CONTRACT_EMPTY_MESSAGERATES_AMOUNT);
      }
    }

    // No need to perform the validation if we already found one record with
    // '0' MESSAGERATES.FORWARD_CONTRACT and empty MESSAGERATES.CONTRACT column.
    if(!arrFoundEmptyFCContract[0])
    {
      // In case MESSAGERATES.FORWARD_CONTRACT column value is 0, (i.e. there is 
      // a forward contract), than the MESSAGERATES.CONTRACT column, (which is a 
      // reference field to the forward contract deal), can't be empty.
      if(forwardContractLine.getFFCFORWARDCONTRACT() == MESSAGERATES_FORWARD_CONTRACT_VALUE_FORWARD_CONTRACT)
      {
        String sCONTRACT = forwardContractLine.getFFCCONTRACT();
        if(isNullOrEmpty(sCONTRACT))
        {
          arrFoundEmptyFCContract[0] = true;
          
          // Error code '40011': Message rates data includes a record with '0' FORWARD_CONTRACT column and empty CONTRACT column.
          fcdrOutputData.getProcessErrorHolder().addError(PROCESS_ERROR_FORWARD_CONTRACT_EMPTY_MESSAGERATES_CONTRACT);
          ErrorAuditUtils.setErrors(PROCESS_ERROR_FORWARD_CONTRACT_EMPTY_MESSAGERATES_CONTRACT);
        }
      }
    }
    
    
  }
  
  /**
   * Validates the passed rate value while checking if we need to get the rate from
   * external interface.
   * @param dRate the rate from the current MESSAGERATES record.
   * @param rateUsage the RateUsage object for the current step we're in during the
   *                  'performForwardContractValidations' method which has called this method.  
   * @param arrExternalRate will be filled with the external rate in case the
   *                        passed 'dRate' is null/zero and we succeed in getting the
   *                        rate from an external interface.
   */
  private boolean validateForwardContractRateAndExternalInterface(Double dRate, RateUsage rateUsage,
                                                                  ForwardContractDealerRateOutputData fcdrOutputData,
                                                                  Double[] arrExternalRate)
  {
    
    
    boolean bSuccess = true;
    
    // The passed rate, (which stands for a MESSAGERATES.RATE column value),
    // is null or zero.
    if(nullNumberOrZero(dRate))
    {
      if(rateUsage != null)
      {
        String sExternalInterfaceName = rateUsage.getInterfaceName();
        
        // Need to call the external interface for the rate value.
        // What needs to be done here is as follows: 
        //  1) Implement getting the rate from an external interface & fill the
        //     passed 'arrExternalRate' input parameter.
        //  2) Once section 1 was done, delete from the following 'if' clause all
        //     lines which are boundered between the 'START lines...' and 'END lines...' sections.
        if(!isNullOrEmpty(sExternalInterfaceName))
        {
          // START lines to delete after external interface implementation is done.
          final String MESSAGE_NO_EXTERNAL_INTERFACE_IMPLEMENTATION = "ERROR: There is no implementation yet for getting the rate from an external interface !!!";
          logger.info(MESSAGE_NO_EXTERNAL_INTERFACE_IMPLEMENTATION);
          fcdrOutputData.getProcessErrorHolder().addError(PROCESS_ERROR_FORWARD_CONTRACT_EMPTY_MESSAGERATES_RATE);
          ErrorAuditUtils.setErrors(PROCESS_ERROR_FORWARD_CONTRACT_EMPTY_MESSAGERATES_RATE);
          bSuccess = false;
          // END lines to delete after external interface implementation is done.
        }
        
        // Empty rate.
        else
        {
          bSuccess = false;
          
          // Error code '40012': Message rates data includes empty RATE column.
          fcdrOutputData.getProcessErrorHolder().addError(PROCESS_ERROR_FORWARD_CONTRACT_EMPTY_MESSAGERATES_RATE);
          ErrorAuditUtils.setErrors(PROCESS_ERROR_FORWARD_CONTRACT_EMPTY_MESSAGERATES_RATE);
        }
      }
    }
    
    
    
    return bSuccess;
  }
  
  /**
   * Performs tolerance validation.
   * @param fcdrOutputData ForwardContractDealerRateOutputData to be updated with
   *                       errors if necessary.
   * @param dSysPar_RATETOLR value of RATETOLR system parameter.
   * @param dSysPar_RATETOLRNO value of RATETOLRNO system parameter.
   * @param dExchangeRate exchange rate value.
   * @param dRate rate value from one of the MESSAGERATES records.
   */
  private boolean validateTolerance(ForwardContractDealerRateOutputData fcdrOutputData,
                                    Double dSysPar_RATETOLR, Double dSysPar_RATETOLRNO,
                                    Double dExchangeRate, double dRate,
                                    String sRateUsageName)
  {
    
    
    boolean bSuccess = true;
    
//    // Calculates the tolerance.
//    Double dToleranceRate = dExchangeRate > dRate ? (dExchangeRate / dRate) : dRate / dExchangeRate;
//    Double dToleranceInPercentage = (dToleranceRate - 1) * 100;
//
//    // Non-Overridable tolerance validation.
//    // RATETOLRNO = Specifies the maximum allowed, (NON-OVERRIDEABLE level), exchange rate
//    // tolerance, (in percents), between a manually entered rate and the rate from
//    // the exchange rate profile.
//    if(   dSysPar_RATETOLRNO != ServerConstants.DOUBLE_ZERO
//       && dToleranceInPercentage > dSysPar_RATETOLRNO)
//    {
//      final String ERROR_MESSAGE = "ERROR: Non-Overrideable tolerance validation failed - Original exchange rate: %s, MESSAGERATES.RATE: %s, Rate tolerance in percent: %s, RATETOLRNO system parameter in percent: %s.";
//      logger.info(ERROR_MESSAGE, dExchangeRate, dRate, dToleranceInPercentage, dSysPar_RATETOLRNO));
//      bSuccess = false;
//      
//      // Error code 12010: 'The rate input |1 exceeds |2% of the sheet rate |3'.
//      Object[] arrNonPaymentFields = new Object[]{dRate, dSysPar_RATETOLRNO, sRateUsageName};
//      ProcessError processError = new ProcessError(ProcessErrorConstants.ToleranceError_RateInputIsBelowOrAboveRateTolerance, arrNonPaymentFields);
//      fcdrOutputData.getProcessErrorHolder().addError(processError);
//      ErrorAuditUtils.setErrors(processError);
//    }
//    
//    if(bSuccess)
//    {
//      // Overridable tolerance validation.
//      // RATETOLR = Specifies the maximum allowed, (OVERRIDEABLE level), exchange rate
//      // tolerance, (in percents), between a manually entered rate and the rate from
//      // the exchange rate profile.
//      if(   dSysPar_RATETOLR != ServerConstants.DOUBLE_ZERO
//         && dToleranceInPercentage > dSysPar_RATETOLR)
//      {
//        final String ERROR_MESSAGE = "ERROR: Overrideable tolerance validation failed - Original exchange rate: %s, MESSAGERATES.RATE: %s, Rate tolerance in percent: %s, RATETOLR system parameter in percent: %s.";
//        logger.info(ERROR_MESSAGE, dExchangeRate, dRate, dToleranceInPercentage, dSysPar_RATETOLR));
//        bSuccess = false;
//        
//        // Error code 12010: 'The rate input |1 exceeds |2% of the sheet rate |3'.
//        Object[] arrNonPaymentFields = new Object[]{dRate, dSysPar_RATETOLR, sRateUsageName};
//        ProcessError processError = new ProcessError(ProcessErrorConstants.ToleranceError_RateInputIsBelowOrAboveRateTolerance, arrNonPaymentFields);
//        fcdrOutputData.getProcessErrorHolder().addError(processError);
//        ErrorAuditUtils.setErrors(processError);
//      }
//    }
//    
//    
    
    return bSuccess;
  }
  
  /**
   * Gets all MESSAGERATES records for the dealt MID, conversion type, currencies
   * pair and triangulation currency.
   * @param ccOutputDataForOriginalCurrenciesPair the CurrencyConversionOutputData 
   *                                              object for the original currencies pair.
   */
  private Object[] getForwardContractMESSAGERATES_Records(ForwardContractDealerRateInputData fcdrInputData, 
                                                          CurrencyConversionOutputData ccOutputDataForOriginalCurrenciesPair, 
                                                          ForwardContractDealerRateOutputData fcdrOutputData)
  {
    final String INPUT_DATA = "MID = {}, Conversion Type = {}, Currency 1 = {}, Currency 2 = {}, Cross currency used - {}, Triangulation currency = {}.";
    
    
    
    Object[] arrMessageRates = null;
    
    PDO pdo = Admin.getContextPDO();
    
    String sMID = pdo.getString(P_MID);
    String sConversionType = fcdrInputData.getConversionType().toString();
    String sCurrency1 = fcdrInputData.getCurrency1();
    String sCurrency2 = fcdrInputData.getCurrency2();
    boolean bCrossCurrencyUsed = ccOutputDataForOriginalCurrenciesPair.isCrossCurrencyUsed();
    
    String sTriangulationCurrency = ccOutputDataForOriginalCurrenciesPair.getTriangulationCurrency();
    sTriangulationCurrency = !isNullOrEmpty(sTriangulationCurrency) ? sTriangulationCurrency : ServerConstants.EMPTY_STRING;
    
    logger.info(INPUT_DATA, new Object[] {sMID, sConversionType, sCurrency1, sCurrency2, bCrossCurrencyUsed, sTriangulationCurrency});
    
    // Gets the messasge rates records for the handled conversion type; see the 'pdo.getNSetMESSAGERATESList' for full logic.
    MessageRatesInputData messageRatesInputData = new MessageRatesInputData(sMID, sConversionType, sCurrency1, sCurrency2, bCrossCurrencyUsed, sTriangulationCurrency, pdo.getIsHistory());
    
    // In case the PDO is new, no need to use the related 'getNSet' method as no data wasn't kept yet in the MESSAGERATES table.
    // For a new message that has arrived with message rates in it, the data will be kept in the PDO during the 'DAS.handleMEMBERTypeField' method
    // while pasring the related XML.
    List<ForwardContractLineType> listMessageRates = pdo.getNSetListMESSAGERATES(messageRatesInputData);
    
    // No MESSAGERATES records were found.
    //
    // 3rd condition is for case we had in the extension of the XML input the following:
    //  <FC_DATA>
    //    <M_FC_LINE>   
    //    </M_FC_LINE> 
    //  </FC_DATA>
    if(   listMessageRates == null 
       || (listMessageRates != null && listMessageRates.isEmpty())
       || (listMessageRates != null && (listMessageRates.get(0).getFFCCURRENCY1() == null || listMessageRates.get(0).getFFCCURRENCY2() == null ))   )
    {
      String sErrorMessage = String.format(ERROR_MESSAGE_FORWARD_CONTRACT_INDIACTOR_EXISTS_WITH_NO_MESSAGERATES_RECORDS, sMID, pdo.isNew(), sConversionType);
      logger.info(sErrorMessage);
      
      // Error code 40016: 'Tries to perform forward contract For MID |1, (new message = |2), and conversion type |3, but no forward contract data was found'.
      ProcessError processError = new ProcessError(ProcessErrorConstants.ForwardContractIndicatorExistsButNo_MESSAGERATES_RecordsWereFound,
                                                   sErrorMessage, new Object[]{sMID, pdo.isNew(), sConversionType}); 
      fcdrOutputData.addError(processError);
      ErrorAuditUtils.setErrors(processError);
    }
    
    // MESSAGERATES records exist.
    else
    {
      // Filters the message rates in case of non-new message, so only the ones that match the required
      // conversion type will be processed.
      // In case of a new message, (i.e. user creates a message and enters forward contract records), then all
      // records have the same conversion type and no need for teh filtering action.
      if(!pdo.isNew())
      {
        listMessageRates = filterMessageRatesRecords(listMessageRates, messageRatesInputData);
      }
      
      // Analyzes the records and prepares 3-size array in which:
      //     Index 0 - includes a list of ForwardContractLineType objects in which CCY1 = Currency 1 & CCY2 = Currency 2.
      //     Index 1 - includes a list of ForwardContractLineType objects in which CCY1 = Currency 1 & CCY2 = Triangulation currency.
      //     Index 2 - includes a list of ForwardContractLineType objects in which CCY1 = Triangulation currency & CCY2 = Currency 2.
      //
      // Notes;
      // 1) The decision to analyze the returned list of ForwardContractLineType objects is because
      //    of clarity, readability and mostly to ease the rest of the process in the 
      //    caller method, (i.e. 'performForwardContractAndDealerRateConversion').
      //    It causes an extra loop on the returned list, but in some cases it will
      //    prevent from executing a lot of code which will be irrelevant when we found
      //    out that there are records which should stop the process.
      // 2) If we've found a record which isn't illegal, (according to allowed 
      //    combinations, where allowed combinations are determined according to
      //    whether cross currency was used or not in the original conversion process),
      //    thenits existence should stop the forward contract process, while raising a process error
      //    to be checked in the caller method. Usually, there shouldn't be such records.
      
      arrMessageRates = new Object[]{new ArrayList<ForwardContractLineType>(), new ArrayList<ForwardContractLineType>(), new ArrayList<ForwardContractLineType>()};
      
      boolean bFoundIllegalRecords = false;
      
      int iSize = listMessageRates.size();
      
      for(int i=0; i<iSize && !bFoundIllegalRecords; i++)
      {
        ForwardContractLineType currentMessageRatesRecord = listMessageRates.get(i);
        
        String sCCY1 = currentMessageRatesRecord.getFFCCURRENCY1();
        String sCCY2 = currentMessageRatesRecord.getFFCCURRENCY2();
        
        // CCY1 = Currency 1 & CCY2 = Currency 2.
        if(sCCY1.equals(sCurrency1) && sCCY2.equals(sCurrency2))
        {
          ((ArrayList<ForwardContractLineType>)arrMessageRates[0]).add(currentMessageRatesRecord);
        }
        
        // CCY1 = Currency 1 & CCY2 = Triangulation currency.
        else if(bCrossCurrencyUsed && sCCY1.equals(sCurrency1) && sCCY2.equals(sTriangulationCurrency))
        {
          ((ArrayList<ForwardContractLineType>)arrMessageRates[1]).add(currentMessageRatesRecord);
        }
        
        // CCY1 = Triangulation currency & CCY2 = Currency 2.
        else if(bCrossCurrencyUsed && sCCY1.equals(sTriangulationCurrency) && sCCY2.equals(sCurrency2))
        {
          ((ArrayList<ForwardContractLineType>)arrMessageRates[2]).add(currentMessageRatesRecord);
        }

        // The pair of CCY1 & CCY2 are not one of the allowed combinations.
        else
        {
          bFoundIllegalRecords = true;
        }
      }
      
      // Found illegal records.  
      if(bFoundIllegalRecords)
      {
        String sErrorMessage = String.format(ERROR_MESSAGE_FORWARD_CONTRACT_FOUND_ILLEGAL_RECORDS, sMID, sConversionType, sCurrency1, sCurrency2, bCrossCurrencyUsed, sTriangulationCurrency);
        logger.info(sErrorMessage);
        
        // Error code 40015: 'Forward contract: for MID |1 and conversion type |2, found record(s) with currencies pair which don't match the allowed combinations, where input data is: currency 1 = |3, currency 2 = |4, cross currency used = |5, triangulation currency = |6'.
        ProcessError processError = new ProcessError(ProcessErrorConstants.ForwardContractFoundIllegalRecords, sErrorMessage,
                                                     new Object[]{sMID, sConversionType, sCurrency1, sCurrency2, bCrossCurrencyUsed, sTriangulationCurrency}); 
        fcdrOutputData.addError(processError);
        ErrorAuditUtils.setErrors(processError);
      }
    }
    
    
    
    return arrMessageRates;
  }
  
  /**
   * Returns filtered list of ForwardContractLineTypeImpl objects.
   */
  private List<ForwardContractLineType> filterMessageRatesRecords(List<ForwardContractLineType> listMessageRates,
                                                                  MessageRatesInputData messageRatesInputData)
  {
    List<ForwardContractLineType> listFilteredMessageRates = new ArrayList<ForwardContractLineType>();

    String sRequiredConversionType = messageRatesInputData.getConversionType().equals(ConversionType.Debit.toString())?
                                     MESSAGERATES_CONVERSION_TYPE_DR : MESSAGERATES_CONVERSION_TYPE_CR;
    boolean bCrossCurrencyUsed = messageRatesInputData.isCrossCurrencyUsed();
    
    String sCurrency1 = messageRatesInputData.getCurrency1();
    String sCurrency2 = messageRatesInputData.getCurrency2();
    String sTriangulationCurrency = messageRatesInputData.getTriangulationCurrency();
    
    String sCurrentConversionType, sCurrentCurrency1, sCurrentCurrency2;
    
    String sMID = messageRatesInputData.getMID();
    
    for(ForwardContractLineType fcLine : listMessageRates)
    {
      // This is for the following scenario:
      // 1) User creates message and enters forward conrtact records.
      // 2) All forward contract records that arrive from the browser don't have any conversion type, (as opposed
      //    to those loaded from database), and thus we set into then the required conversion type.
    	
    	if (fcLine.getFFCCONVERSIONTYPE() == null ) fcLine.setFFCCONVERSIONTYPE(com.fundtech.scl.commonTypes.FCConversionType.Enum.forString(sRequiredConversionType));
      sCurrentConversionType = fcLine.getFFCCONVERSIONTYPE().toString() ;
      
      // No need to continue if the forward contract line has a different conversion
      // type then the required one.
      if(sCurrentConversionType.equalsIgnoreCase(sRequiredConversionType))
      {
        // Since this is a new message, sets MID of new PDO into the input forward
        // contract records. 
        fcLine.setFFCMID(sMID);
        
        sCurrentCurrency1 = fcLine.getFFCCURRENCY1();
        sCurrentCurrency2 = fcLine.getFFCCURRENCY1();
        
        // The following logic is parallel to the case where message rates are
        // loaded from the database for DIRECT conversion, according to the
        // following query, (see 'DAOCurrencyConversion.'getMessageRates').
        //  "SELECT * FROM MESSAGERATES WHERE MID = ? AND CONVERSION_TYPE = ? AND (CCY1, CCY2) " +
        //  "NOT IN " +
        //  "(SELECT CCY1, CCY2 FROM MESSAGERATES WHERE MID = ? AND CONVERSION_TYPE = ? " +
        //  "AND (CCY1 = ? AND CCY2 = ?)) " +
        //  "UNION ALL " +
        //  "SELECT * FROM MESSAGERATES WHERE MID = ? AND CONVERSION_TYPE = ? " +
        //  "AND CCY1 = ? AND CCY2 = ?";
        if(!bCrossCurrencyUsed)
        {
          // Equivalent to the part under the 'UNION ALL':
          //  "SELECT * FROM MESSAGERATES WHERE MID = ? AND CONVERSION_TYPE = ? " +
          //  "AND CCY1 = ? AND CCY2 = ?";
          if(sCurrentCurrency1.equals(sCurrency1) && sCurrentCurrency2.equals(sCurrency2))
          {
            listFilteredMessageRates.add(fcLine);
          }
          
          // Equivalent to the part above the 'UNION ALL', which stands for an
          // illegal record, which should raise an error and stop the process.
          else
          {
            listFilteredMessageRates.add(0, fcLine);
          }
        }
        
        // The following logic is parallel to the case where message rates are
        // loaded from the database for INDIRECT conversion, according to the
        // following query, (see 'DAOCurrencyConversion.'getMessageRates').
        //  "SELECT * FROM MESSAGERATES WHERE MID = ? AND CONVERSION_TYPE = ? AND (CCY1, CCY2) " +
        //  "NOT IN " +
        //  "(SELECT CCY1, CCY2 FROM MESSAGERATES WHERE MID = ? AND CONVERSION_TYPE = ? " +
        //  "AND (CCY1 = ? AND CCY2 = ?) OR (CCY1 = ? AND CCY2 = ?) OR (CCY1 = ? AND CCY2 = ?)) " +
        //  "UNION ALL " +
        //  "SELECT * FROM MESSAGERATES WHERE MID = ? AND CONVERSION_TYPE = ? " +
        //  "AND CCY1 = ? AND CCY2 = ? " +
        //  "UNION ALL " +
        //  "SELECT * FROM MESSAGERATES WHERE MID = ? AND CONVERSION_TYPE = ? " +
        //  "AND CCY1 = ? AND CCY2 = ? " +
        //  "UNION ALL " +
        //  "SELECT * FROM MESSAGERATES WHERE MID = ? AND CONVERSION_TYPE = ? " +
        //  "AND CCY1 = ? AND CCY2 = ?";
        else
        {
          // Equivalent to the 'UNION ALL' parts:
          //  "UNION ALL " +
          //  "SELECT * FROM MESSAGERATES WHERE MID = ? AND CONVERSION_TYPE = ? " +
          //  "AND CCY1 = ? AND CCY2 = ? " +
          //  "UNION ALL " +
          //  "SELECT * FROM MESSAGERATES WHERE MID = ? AND CONVERSION_TYPE = ? " +
          //  "AND CCY1 = ? AND CCY2 = ? " +
          //  "UNION ALL " +
          //  "SELECT * FROM MESSAGERATES WHERE MID = ? AND CONVERSION_TYPE = ? " +
          //  "AND CCY1 = ? AND CCY2 = ?";
          if(   (sCurrentCurrency1.equals(sCurrency1) && sCurrentCurrency2.equals(sCurrency2))
             || (sCurrentCurrency1.equals(sCurrency1) && sCurrentCurrency2.equals(sTriangulationCurrency))
             || (sCurrentCurrency1.equals(sTriangulationCurrency) && sCurrentCurrency2.equals(sCurrency2)))
          {
            listFilteredMessageRates.add(fcLine);
          }
          
          // Equivalent to the part above the 'UNION ALL', which stands for an
          // illegal record, which should raise an error and stop the process.
          else
          {
            listFilteredMessageRates.add(0, fcLine);
          }
        }
      }
    }
    
    return listFilteredMessageRates;
  }
  
  /**
   * 
   */
  private void setRateUsageFields(PDO pdo, String sConversionType)
  {
  	final String TRACE_DATA_BEFORE_EXECUTING_RULES = "Rate Usage Fields Before rules: P_DBT_CUST_CD: {}, P_CDT_CUST_CD: {}, P_BASE_RATE_USAGE_NM: {}, P_DBT_RATE_USAGE_NM: {}, P_CDT_RATE_USAGE_NM: {}.";
  	
  	
  	
    String sOffice = pdo.getString(P_OFFICE);
    String sMID = pdo.getMID();
    
    // Debit customer code.
    String sDebitCustomerCustCode = pdo.getString(P_DBT_CUST_CD);
    //
    // In case debit customer code is empty/null, try get it from the debit account.
    if(isNullOrEmpty(sDebitCustomerCustCode))
    {
      Accounts debitAccounts = pdo.getNSetDEBIT_ACCOUNT();
      
      if(debitAccounts != null)
      {
        sDebitCustomerCustCode = debitAccounts.getCustCode();
        pdo.set(P_DBT_CUST_CD, sDebitCustomerCustCode);
      }
    }
    
    String sP_DBT_CUST_CD = pdo.getString(P_DBT_CUST_CD);
    String sP_CDT_CUST_CD = pdo.getString(P_CDT_CUST_CD);
    String sP_BASE_RATE_USAGE_NM = pdo.getString(P_BASE_RATE_USAGE_NM);
    String sP_DBT_RATE_USAGE_NM = pdo.getString(P_DBT_RATE_USAGE_NM);
    String sP_CDT_RATE_USAGE_NM = pdo.getString(P_CDT_RATE_USAGE_NM);
    logger.info(TRACE_DATA_BEFORE_EXECUTING_RULES, new Object[] {sP_DBT_CUST_CD, sP_CDT_CUST_CD, sP_BASE_RATE_USAGE_NM, sP_DBT_RATE_USAGE_NM, sP_CDT_RATE_USAGE_NM});
    
    try
    {
      Banks bank = CacheKeys.banksKey.getSingle(sOffice);
      List<RuleResult> listRuleResults;
      String[] arrObjectIDs;
      
      // BASE rate usage.
      //
      // The 'P_BASE_RATE_USAGE_NM' field wasn't set yet; executes related rule.
      if(isNullOrEmpty(sP_BASE_RATE_USAGE_NM))
      {
        // Always sets the BASE rate usage, which is required during the flow even
        // if the actual conversion type is 'Debit' or 'Credit'.
        arrObjectIDs = new String[]{sOffice};
         listRuleResults = m_ruleEngine.executeRule(Admin.getContextAdmin(), MessageConstantsInterface.RULE_TYPE_ID_BASE_RATE_USAGE_SELECTION, null,
                                                      sMID, arrObjectIDs).getResults();
        
        if(!listRuleResults.isEmpty())
        {
          String sBaseRateUsageUID = listRuleResults.get(0).getAction();
          pdo.set(P_BASE_RATE_USAGE_NM, sBaseRateUsageUID);
          pdo.getNSetBaseRateUsage();
        }
      }
      //
      // For cases where the P_BASE_RATE_USAGE_NM was already derived in a previous process, (e.g. 'getQuoteService' that is executed after submit message was
      // already executed once and completed successfully).
      if(!isNullOrEmpty(pdo.getString(P_BASE_RATE_USAGE_NM))) pdo.getNSetBaseRateUsage();

      // If conversion type was 'Debit' or 'Credit', then sets relevant rate usage fields.
      //
      // DEBIT rate usage.
      // The 'P_DBT_RATE_USAGE_NM' field wasn't set yet; executes related rule.
      if(sConversionType.equals(ConversionType.Debit.toString()) && isNullOrEmpty(sP_DBT_RATE_USAGE_NM)) 
      {
        arrObjectIDs = !isNullOrEmpty(sDebitCustomerCustCode) ? 
                       new String[]{sDebitCustomerCustCode, bank.getCustCode()} : new String[]{bank.getCustCode()};
        
        listRuleResults = m_ruleEngine.executeRule(Admin.getContextAdmin(), MessageConstantsInterface.RULE_TYPE_ID_DEBIT_RATE_USAGE_SELECTION, null, 
                                                      sMID, arrObjectIDs).getResults();
        
        if(!listRuleResults.isEmpty())
        {
          String sDebitRateUsageUID = listRuleResults.get(0).getAction();
          pdo.set(P_DBT_RATE_USAGE_NM, sDebitRateUsageUID);
          pdo.getNSetDebitRateUsage();
        }
      }
      //
      // For cases where the P_DBT_RATE_USAGE_NM was already derived in a previous process, (e.g. 'getQuoteService' that is executed after submit message was
      // already executed once and completed successfully).
      if(!isNullOrEmpty(pdo.getString(P_DBT_RATE_USAGE_NM))) pdo.getNSetDebitRateUsage();
      
      // CREDIT rate usage.
      // The 'P_CDT_RATE_USAGE_NM' field wasn't set yet; executes related rule.
      if(sConversionType.equals(ConversionType.Credit.toString()) && isNullOrEmpty(sP_CDT_RATE_USAGE_NM))
      {
        arrObjectIDs = !isNullOrEmpty(sP_CDT_CUST_CD) ? 
                       new String[]{sP_CDT_CUST_CD, bank.getCustCode()} : new String[]{bank.getCustCode()};
        
        listRuleResults = m_ruleEngine.executeRule(Admin.getContextAdmin(), MessageConstantsInterface.RULE_TYPE_ID_CREDIT_RATE_USAGE_SELECTION,
                                                      null, sMID, arrObjectIDs).getResults();
        
        if(!listRuleResults.isEmpty())
        {
          String sCreditRateUsageUID = listRuleResults.get(0).getAction();
          pdo.set(P_CDT_RATE_USAGE_NM, sCreditRateUsageUID);
          pdo.getNSetCreditRateUsage();
        }
      }
      //
      // For cases where the P_CDT_RATE_USAGE_NM was already derived in a previous process, (e.g. 'getQuoteService' that is executed after submit message was
      // already executed once and completed successfully).
      if(!isNullOrEmpty(pdo.getString(P_CDT_RATE_USAGE_NM))) pdo.getNSetCreditRateUsage();      
    }
    
    catch(Exception e)
    {
      ExceptionController.getInstance().handleException(e, this);
    }
  }
  

	public Double simpleAmountConversion(Double origAmount, String office, String ccy1, String ccy2)
			throws CurrencyConversionException {
		
		if(origAmount == null || origAmount.equals(BigDecimal.ZERO)) return origAmount;
		
		if(ccy1.equals(ccy2)) return origAmount;
		
		if(GlobalUtils.isNullOrEmpty(ccy1) || GlobalUtils.isNullOrEmpty(ccy2)){
			throw new CurrencyConversionException("Invalid conversion currency");
		}
		
		CacheInterface cache = CacheAdapterFactory.getInstance().getCacheAdapter(CacheAdapterFactory.CACHE_KEYS);
		SimpleCurrencyConversion simpleCurrencyConversion = new SimpleCurrencyConversion(origAmount, office, ccy1,
				ccy2, cache);
		return simpleCurrencyConversion.execute();		
		
		}

}
