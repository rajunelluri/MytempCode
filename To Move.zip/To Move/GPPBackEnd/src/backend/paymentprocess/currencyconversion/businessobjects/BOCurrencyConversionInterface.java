package backend.paymentprocess.currencyconversion.businessobjects;

import com.fundtech.core.security.Admin;

/**
 * internal interface for BOCurrencyConversion.
 */
public interface BOCurrencyConversionInterface{

	
	
	/** 
	 * This method should be called from outer classes, (e.g. BOFeesCalculation),
	 * and not from the business flow; for the business flow use the same method with 
	 * 'conversion type' as string input parameter.
	 * Gets CurrencyConversionInputData and performs currency conversion between the
	 * 2 currencies of the input.
	 */
	public backend.paymentprocess.currencyconversion.output.CurrencyConversionOutputData performCurrencyConversion(final Admin admin, backend.paymentprocess.currencyconversion.input.CurrencyConversionInputData ccInputData ) throws backend.paymentprocess.currencyconversion.exception.CurrencyConversionException ;
	
	/**
	 * Perform simple conversion based on minimal parameter and use STANDARD rate for this.
	 */
	public java.lang.Double simpleAmountConversion(java.lang.Double origAmount, java.lang.String office, java.lang.String ccy1, java.lang.String ccy2) throws backend.paymentprocess.currencyconversion.exception.CurrencyConversionException;
	

}//EOI  