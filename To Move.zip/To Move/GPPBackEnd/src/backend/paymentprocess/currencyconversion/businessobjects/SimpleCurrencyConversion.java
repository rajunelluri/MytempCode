package backend.paymentprocess.currencyconversion.businessobjects;

import java.lang.reflect.InvocationTargetException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.paymentprocess.currencyconversion.exception.CurrencyConversionException;

import com.fundtech.cache.entities.ExchrateBu;
import com.fundtech.cache.entities.ExchrateCfg;
import com.fundtech.cacheproviders.CacheInterface;
import com.fundtech.util.GlobalUtils;

public class SimpleCurrencyConversion {

	private static final Logger logger = LoggerFactory.getLogger(SimpleCurrencyConversion.class);

	private double rate;
	private String office;
	private Long currency1Unit, currency2Unit;
	private Double origAmount;
	private boolean isDirectConversion = false;
	private ExchrateCfg exchrateCfg = null;
	private ExchrateBu exchrateBu = null;
	private CacheInterface cacheInterface = null;

	public SimpleCurrencyConversion(Double origAmount, String office, String ccy1, String ccy2, CacheInterface cacheInterface) {

		try
		{
			setCacheInterface(cacheInterface);
			setOrigAmount(origAmount);
			setOffice(office);
			setCacheKeys(ccy1, ccy2);
			setCurrencies(ccy1, ccy2);
			setRate();
		}
		catch (Exception e)
		{
			logger.error("Reflection type exception", e);
		}
	}

	public Double execute() throws CurrencyConversionException {

		Double convertedAmount = 0.0;
		validateUnits(currency1Unit,currency1Unit,rate);
		if (isDirectConversion)
		{
			convertedAmount = origAmount * rate * (new Double(currency2Unit) / new Double(currency1Unit));
		}
		else
		// Indirect conversion.
		{
			convertedAmount = (origAmount / rate) * (new Double(currency1Unit) / new Double(currency2Unit));
		}

		logger.info("return convertedAmount[{}]", convertedAmount);

		return GlobalUtils.adjustPrecision(convertedAmount, this.exchrateCfg.getDecNo().intValue());
	}
	

	private void validateUnits(Long currency1Unit, Long currency2Unit,
			double rate) throws CurrencyConversionException {
		if(currency1Unit == null ||  currency1Unit.intValue() == 0 ||
		   currency2Unit == null ||  currency2Unit.intValue() == 0 ||  rate == 0){
			String currency1UnitVal = currency1Unit == null ? " null " : currency1Unit.toString();
			String currency2UnitVal = currency2Unit == null ? " null " : currency2Unit.toString();
			throw new CurrencyConversionException("Invalid setup, currency or rate are invalid. rate:" + rate + 
					  "Currency unit 1 : " + currency1UnitVal  +
					  "Currency unit 2 : " + currency2UnitVal);
		}		
	}

	private void setCacheInterface(CacheInterface cacheInterface) {

		this.cacheInterface = cacheInterface;
	}

	public CacheInterface getCacheInterface() {
		return this.cacheInterface;
	}

	private void setCacheKeys(String ccy1, String ccy2) throws NoSuchFieldException, NoSuchMethodException,
			InvocationTargetException, IllegalArgumentException, IllegalAccessException,CurrencyConversionException {
		final String STANDARD_RATE_TYPE = "STANDARD";
		String currencyPair = new StringBuffer(ccy1).append(ccy2).toString();

		logger.info("simpleAmountConversion for Office[{}], directCCYPair[{}]", new Object[] { office,currencyPair});

		this.exchrateBu = getCacheInterface().getSingleExchangeRateBu(currencyPair, office, STANDARD_RATE_TYPE);
		if (null==this.exchrateBu)
		{
			currencyPair=new StringBuffer(ccy2).append(ccy1).toString();
			this.exchrateBu = getCacheInterface().getSingleExchangeRateBu(currencyPair, office, STANDARD_RATE_TYPE);
		}
		this.exchrateCfg = getCacheInterface().getSingleExchangeRateCfg(currencyPair, office);
		
		if (this.exchrateCfg == null || this.exchrateBu == null)
		{
			throw new CurrencyConversionException("Invalid setup, currency pair ["+ currencyPair  +"] missing.");
		}

	}

	private void setCurrencies(String ccy1, String ccy2) {

		if (exchrateCfg.getCcy1().equals(ccy1))
		{
			currency1Unit = exchrateCfg.getCcy1Unit();
			currency2Unit = exchrateCfg.getCcy2Unit();
			isDirectConversion = true;
		}
		else
		{
			currency1Unit = exchrateCfg.getCcy2Unit();
			currency2Unit = exchrateCfg.getCcy1Unit();
			isDirectConversion = false;
		}

	}

	private void setOffice(String office) {
		this.office = office;
	}

	private void setOrigAmount(Double origAmount) {
		this.origAmount = origAmount;

	}

	private void setRate() {
		this.rate = (exchrateBu.getMidRate() != null) ? exchrateBu.getMidRate()
				: ((exchrateBu.getHighRate() + exchrateBu.getLowRate()) / 2);

	}
}
