package backend.paymentprocess.currencyconversion.ejb;

import javax.ejb.Stateless;

import backend.businessobject.proxies.interceptors.InterceptorSetType;
import backend.core.SuperSLSB;
import backend.paymentprocess.currencyconversion.ejbinterfaces.CurrencyConversion;
import backend.paymentprocess.currencyconversion.ejbinterfaces.CurrencyConversionLocal;

import com.fundtech.core.security.Admin;

@Stateless
public class CurrencyConversionBean extends SuperSLSB<CurrencyConversion> implements CurrencyConversionLocal, CurrencyConversion{
	
	public CurrencyConversionBean() { super(backend.paymentprocess.currencyconversion.businessobjects.BOCurrencyConversion.class, InterceptorSetType.Complete) ; }//EOM
	
	
	/** 
	 * Performs currency conversion according to the passed conversion type
	 * input parameter and according to the related PDO object.
	 * It will analyze the values within the PDO and will perform a call to the right
	 * conversion method.
	 * This is the method which will be exposed to the business flow, which will
	 * call 3 times for base, credit & debit, ('Mid' conversion type shouldn't be used
	 * in that case).
	 * @param sConversionType one of the following 3 options: Base, Credit & Debit,
	 * where 'Mid' conversion type shouldn't be used in that case
	 */
	@Override
	public com.fundtech.datacomponent.response.Feedback performCurrencyConversion(final Admin admin, java.lang.String sMID ) throws backend.paymentprocess.currencyconversion.exception.CurrencyConversionException {
		return this.m_bo.performCurrencyConversion(admin, sMID ) ;
	}//EOM
	
	/** 
	 * Simple conversion type of 
	 */
	@Override
	public java.lang.Double simpleAmountConversion(java.lang.Double origAmount, java.lang.String office, java.lang.String ccy1, java.lang.String ccy2) throws backend.paymentprocess.currencyconversion.exception.CurrencyConversionException 
	{
		return this.m_bo.simpleAmountConversion(origAmount, office, ccy1, ccy2);
	}//EOM	

}//EOC