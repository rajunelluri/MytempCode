package backend.paymentprocess.erroraudit;
// default package


public class ActivityAuditTask implements java.io.Serializable
{

    private String office;
    private String startDatetime;
    private String endDatetime;
    private String activityName;
    private String taskStatus;

    public ActivityAuditTask()
    {
    }

    public ActivityAuditTask(String office, String startDatetime, String endDatetime, String activityName, String taskStatus)
    {
        this.office = office;
        this.startDatetime = startDatetime;
        this.endDatetime = endDatetime;
        this.activityName = activityName;
        this.taskStatus = taskStatus;
    }

    public String toString()
    {
       
        return "";
    }
    

	public String getActivityName() {
		return this.activityName;
	}
    
    public void setActivityName(String activityName) {
		this.activityName = activityName;
	}
    
   	public String getOffice() {
   		return this.office;
   	}
    
    public void setOffice(String office) {
		this.office = office;
	}
    
   	public String getTaskStatus() {
   		return this.taskStatus;
   	}
    
    public void setTaskStatus(String taskStatus) {
		this.taskStatus = taskStatus;
	}

   	public String getStartDateTime() {
   		return this.startDatetime;
   	}
    
    public void setStartDateTime(String startDatetime) {
    	if (startDatetime.length() > 19)
    	{
    		startDatetime = startDatetime.substring(0, 19);
    	}
 		this.startDatetime = startDatetime;
 	}

   	public String getEndDateTime() {
   		return this.endDatetime;
   	}
    
    public void setEndDateTime(String endDatetime) {
    	if (endDatetime.length() > 19)
    	{
    		endDatetime = endDatetime.substring(0, 19);
    	}
 		this.endDatetime = endDatetime;
 	}

    
    
}