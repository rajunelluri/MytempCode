/**
 * Apr 8, 2008
 * ErrorAuditUtils.java
 * @author Vadim Koremblum
 */
package backend.paymentprocess.erroraudit;

import static com.fundtech.errors.ProcessErrorConstants.GenericError;
import static com.fundtech.util.GlobalUtils.isArrayNotNullAndNotEmpty;
import static com.fundtech.util.GlobalUtils.isNullOrEmpty;

import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.persistence.EntityManager;
import javax.xml.namespace.QName;

import org.apache.commons.lang.StringUtils;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.impl.values.XmlObjectBase;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import backend.businessobject.BOBasic;
import backend.core.module.MessageConstantsInterface;
import backend.core.module.ejbinterfaces.TxIsolation;
import backend.paymentprocess.debulkingprocess.common.WorkflowType;
import backend.paymentprocess.output.PaymentProcessOutputData;
import backend.services.cache.ASCacheFactory;
import backend.services.cache.EntityManagerHelper;
import backend.staticdata.dataaccess.dao.DAOStaticData;
import backend.staticdata.profilehandler.message.dataaccess.dao.DAOFILE_SUMMARY;
import backend.util.ServerConstants;
import backend.util.ServerUtils;

import com.fundtech.cache.entities.Journalmessages;
import com.fundtech.cache.entities.MsgSpecialInstructions;
import com.fundtech.cache.entities.Msgerr;
import com.fundtech.cache.entities.Newjournal;
import com.fundtech.cache.entities.WebSessionInfo;
import com.fundtech.cache.entities.Newjournal.SnapShotHolder;
import com.fundtech.cache.infrastructure.CacheException;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.core.paymentprocess.data.fields.DataType;
import com.fundtech.core.paymentprocess.data.fields.FieldType;
import com.fundtech.core.paymentprocess.data.fields.PaymentFieldInterface;
import com.fundtech.core.paymentprocess.data.fields.PaymentFieldInterface.ModificationType;
import com.fundtech.core.paymentprocess.data.fields.XmlPaymentField.XmlMultiOccurencePaymentField;
import com.fundtech.core.paymentprocess.errorhandling.ProcessError;
import com.fundtech.core.paymentprocess.errorhandling.ProcessErrorHolder;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.errors.ProcessErrorConstants;
import com.fundtech.jndi.ServiceLocator;
import com.fundtech.scl.commonTypes.MsgTableEntryBaseType;
import com.fundtech.scl.commonTypes.MsgTableType;
import com.fundtech.scl.commonTypes.MtableDocument;
import com.fundtech.scl.commonTypes.RecordType;
import com.fundtech.util.BindingParameter;
import com.fundtech.util.ErrorAuditInputData;
import com.fundtech.util.ErrorAuditUtilsInterface;
import com.fundtech.util.ExceptionController;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalDateTimeUtil;
import com.fundtech.util.GlobalUtils;
import com.fundtech.util.ErrorAuditInputData.ExtraTables;
import com.fundtech.util.datetime.DateAndZone;
import com.fundtech.util.datetime.NewASDateTimeUtils;

/**
 * 
 */
public class ErrorAuditUtils implements Comparable, ErrorAuditUtilsInterface, MessageConstantsInterface
{
    private static String FIELD_FORMAT_DELIMITER="@@";
    private static String PAYMENT_FIELD_FORMAT_PREFIX=FIELD_FORMAT_DELIMITER+":f";
    private static String NON_PAYMENT_FIELD_FORMAT_PREFIX=FIELD_FORMAT_DELIMITER+":t";
    private static Pattern m_pattern=Pattern.compile("(_(\\d{1,5})"+FIELD_FORMAT_DELIMITER+")");
    private static String PARAMETERS_FIELDS_DELIMITER="@@,";
    private static String ERROR_PARAMETERS_DELIMITER="~~";
    private static String NO_BINDING_VALUE=" ";
    private static DAOStaticData m_daoStaticData = new DAOStaticData();
    public static BOBasic m_boBasic=new BOBasic();
    public static ErrorAuditUtils m_instance;
    final static Logger errorLogger = LoggerFactory.getLogger("ERROR_LOG");
    private static final Logger logger = LoggerFactory.getLogger(ErrorAuditUtils.class);
    
    private static final long LONG_ERROR_CODE_USER_MODIFIED_FIELDS = Long.valueOf(ProcessErrorConstants.UserHasChangedFields).longValue(); 
    
      
    private ErrorAuditUtils()
    {
    }
    
    
    public static ErrorAuditUtils getInstance()
    {
        if (m_instance==null)
            m_instance=new ErrorAuditUtils();
        return m_instance;
    }
    
    public static void setErrors(PaymentProcessOutputData outputData)
    {
        ProcessErrorHolder errorHolder=outputData.getProcessErrorHolder();
        int size=errorHolder.getSize();
        for (int i=0;i<size;i++)
        {
            ProcessError error=errorHolder.getProcessError(i);
            setErrors(error);
        }
        
    }
    
    public static void setAuditTrails(ProcessErrorHolder auditTrail)
    {
        int size=auditTrail.getSize();
        for (int i=0;i<size;i++)
        {
            ProcessError error=auditTrail.getProcessError(i);
            setErrors(error);
        }
        
    }
    
    public List<Object> insertError(ProcessError error)
    {
    	return setErrors(error);
    }
    
    public static List<Object>  setErrors(ProcessError error)
    {
      return setErrors(error, null, null);
    }

    public static List<Object> setErrors(ProcessError error, PDO pdo){
    	return setErrors( error, pdo, null);
    }

    public static List<Object> setErrors(ProcessError error, Integer partitionID)
    {
        
        PDO pdo = Admin.getContextPDO();
        partitionID = partitionID!=null ? partitionID : 0; 
        ErrorAuditInputData eaInputData = new ErrorAuditInputData();
        eaInputData.setErrorCode((long)error.getErrorCode());
        eaInputData.setNonPaymentsFields(error.getNonPaymentFields());
        eaInputData.setFieldLogicalIDs(error.getLogicalFieldsArr());
        eaInputData.setWriteToDB(false);
        
        
        Admin admin = Admin.getContextAdmin();
        if(admin != null && admin.getWebSessionInfo() != null)
        {
          eaInputData.setUserId(Admin.getContextAdmin().getWebSessionInfo().getUserID());
        }
        if(pdo != null)
        {
            eaInputData.setOffice(pdo.getString(PDOConstantFieldsInterface.P_OFFICE));
            eaInputData.setMid(pdo.getMID());
            partitionID = pdo.getIsHistory();
        }
        
        eaInputData.setPartitionID(partitionID);
        
        return handleErrorAndAudit(eaInputData, pdo);
    }
    
    
    public static List<Object> setErrors(ProcessError error, PDO pdo, String fileId)
    {
        
        pdo = pdo != null ? pdo : Admin.getContextPDO();
        Integer partitionID = pdo!=null ? pdo.getIsHistory() : 0; 
        ErrorAuditInputData eaInputData = new ErrorAuditInputData();
        eaInputData.setErrorCode((long)error.getErrorCode());
        eaInputData.setNonPaymentsFields(error.getNonPaymentFields());
        eaInputData.setFieldLogicalIDs(error.getLogicalFieldsArr());
        eaInputData.setWriteToDB(false);
        
        
        Admin admin = Admin.getContextAdmin();
        if(admin != null && admin.getWebSessionInfo() != null)
        {
          eaInputData.setUserId(Admin.getContextAdmin().getWebSessionInfo().getUserID());
        }
        if(pdo != null)
        {
            eaInputData.setOffice(pdo.getString(PDOConstantFieldsInterface.P_OFFICE));
            eaInputData.setMid(pdo.getMID());
        }
        if( fileId != null){
        	eaInputData.setMid(fileId);
        	String flowType = null;
        	// There is no PDO for file-id, so cannot set into PDO, persist directly.
        	eaInputData.setWriteToDB(true);
        	if(pdo!=null && fileId.equals(pdo.getMID()))
        	{
        		flowType = pdo.getString(PDOConstantFieldsInterface.P_BUSINESS_FLOW_TP);
        	}
        	else
        	{
        		flowType = DAOFILE_SUMMARY.getInstance().getFlowType(fileId);
        	}
        	partitionID = GlobalConstants.BP.equals(flowType) ? GlobalUtils.getPartitionIDByMID(fileId) : 0;
        	pdo = null;
        }
        
        eaInputData.setPartitionID(partitionID);
        
        return handleErrorAndAudit(eaInputData, pdo);
    }
    

    
    public static List<Object> setError(int errCode, String mid, Feedback feedback, Object...errParams)
    {
    	Integer partitionID = 0;

		ProcessError pError=new ProcessError(errCode,mid,null,errParams);
        BOBasic.configureErrorFeedback(pError.getErrorCode(),pError.getDescription(), feedback);
        return setErrors(pError,partitionID);
    }
    
    public static List<Object> setError(int errCode, String mid, Integer partitionID, Feedback feedback, Object...errParams)
    {
		ProcessError pError=new ProcessError(errCode,mid,null,errParams);
        BOBasic.configureErrorFeedback(pError.getErrorCode(),pError.getDescription(), feedback);
        return setErrors(pError,partitionID);
    }

    
    public static List<Object> setError(int errCode, String mid, Feedback feedback, String[] logicalFieldsArr, Object[] errParams)
    {
		ProcessError pError=new ProcessError(errCode,mid,null,logicalFieldsArr,errParams);
        BOBasic.configureErrorFeedback(pError.getErrorCode(),pError.getDescription(), feedback);
        return setErrors(pError);
    }

    
    /**
     * Called from the messageInfrastructurescripts.js file for saving 'rekey verify' and 'sight verify' fields into 
     * NEWJOURNAL table.
     */
    public static List<Object> handleErrorAndAuditForVerifyRekey(int iErrorCode, String[] arrFieldLogicalIDs)
    {
      final String MESSAGE_HANDLE = "MESSAGE_HANDLE";
      final String REKEY_VERIFY_FIELDS = "REKEY_VERIFY_FIELDS";
      final String SIGHT_VERIFY_FIELDS = "SIGHT_VERIFY_FIELDS";
      
      final String[] ARR_FIELD_LOGICAL_ID_REKEY_VERIFY_FIELDS = new String[]{REKEY_VERIFY_FIELDS};
      final String[] ARR_FIELD_LOGICAL_ID_SIGHT_VERIFY_FIELDS = new String[]{SIGHT_VERIFY_FIELDS};
      
      final WebSessionInfo webSessionInfo = Admin.getContextAdmin().getNSetWebSessionInfo() ; 
      
      final String sUserID = webSessionInfo.getUserID(); 
      final String sDefaultOffice = webSessionInfo.getDefaultOffice() ; 
      
      ErrorAuditInputData eaInputData = new ErrorAuditInputData(false, webSessionInfo.getSessionID(), MESSAGE_HANDLE, sUserID, sDefaultOffice,
                                                                ServerConstants.EMPTY_STRING, ServerConstants.EMPTY_STRING,  
                                                                Admin.getContextAdmin().getClientRemoteAddress());
      
      eaInputData.setNEWJOURNALFieldLogicalIDs(GlobalUtils.editFieldsStringArray(arrFieldLogicalIDs));
      eaInputData.setErrorCode((long)iErrorCode);
      eaInputData.setMid(Admin.getContextPDO().getMID());
      
      eaInputData.setFieldLogicalIDs(iErrorCode == ProcessErrorConstants.UserHasVerifiedFields ? 
                                     ARR_FIELD_LOGICAL_ID_REKEY_VERIFY_FIELDS : ARR_FIELD_LOGICAL_ID_SIGHT_VERIFY_FIELDS);
      
      return handleErrorAndAudit(eaInputData);
    }

    /**
     * This method will be responsible for inserting the required audit/error entry into the related database table, 
     * (NEWJOURNAL, MSGERR or ERRORLOG) or return the data as JPA objects, 
     * and write the edited error text into the application server trace file
     * @param eaInputData
     * @return List of JPA Objects according to boolean flag located in ErrorAuditInputData
     *
     */
    public static List<Object> handleErrorAndAudit(ErrorAuditInputData eaInputData)
    {
     PDO pdo=Admin.getContextPDO();	
      return handleErrorAndAudit(eaInputData,pdo);
    }
    
    /**
     * This method will be responsible for inserting the required audit/error entry into the related database table, 
     * (NEWJOURNAL, MSGERR or ERRORLOG) or return the data as JPA objects, 
     * and write the edited error text into the application server trace file
     * @param eaInputData
     * @return List of JPA Objects according to boolean flag located in ErrorAuditInputData
     *
     */
    public static List<Object> handleErrorAndAudit(ErrorAuditInputData eaInputData, PDO pdo)
    {
        List<Object> listErrorAuditObjects=null;
        if (!eaInputData.isWriteToDB())
            listErrorAuditObjects=new ArrayList<Object>();
        Journalmessages journalMess=retrieveErrorAttributes(eaInputData);
        additionalSettingsBeforeAnalyzingBindingParameters(journalMess,eaInputData.getMid());
        analyzingBindingParametersProcess(eaInputData,journalMess,listErrorAuditObjects, pdo);
        return listErrorAuditObjects;
    }
    
    /**
     * This method will be used for displaying the error/audit text of the NEWJOURNAL, MSGERR and ACTIVITY_AUDIT tables
     * @param lErrorCode
     * @param sErrorParams
     * @param sOffice
     * @param sLanguage
     * @param arrFormats
     * @param bIsMultiple
     * @return String
     *
     */
    public String loadErrorAuditText(Long lErrorCode, String sErrorParams, String sOffice, String sLanguage
                                            , Object[] arrFormattingValues, Boolean bIsMultiple)
    {
        
        Journalmessages journalMess = CacheKeys.journalMessagesKey.getSingle(lErrorCode);
        
        if(journalMess == null) return getErrorText(GenericError, null) ; 
        String valueToReturn=journalMess.getDescription();
        if (sErrorParams!=null)
        {
            if (arrFormattingValues==null || arrFormattingValues.length==0)
                arrFormattingValues = ASCacheFactory.getInstance().getFormattingValues(sOffice);
            if (bIsMultiple!=null && bIsMultiple)
            {
                String[] arrOfSplitedErrorParams=sErrorParams.split(ERROR_PARAMETERS_DELIMITER);
                if (arrOfSplitedErrorParams!=null)
                {
                    StringBuilder sb=new StringBuilder();
                    
                    for (int i=0;i<arrOfSplitedErrorParams.length;i++)
                    {
                        sb.append(GlobalUtils.getEditedErrorText(journalMess.getDescription(),constructBindingParam(arrOfSplitedErrorParams[i])
                                ,arrFormattingValues,NO_BINDING_VALUE)).append(PARAMETERS_FIELDS_DELIMITER);
                    }
                    if (sb.length()>0)
                    {
                        valueToReturn=sb.substring(0,sb.length()-PARAMETERS_FIELDS_DELIMITER.length());
                    }
                }
            }
            else
            {
                valueToReturn=GlobalUtils.getEditedErrorText(journalMess.getDescription(),constructBindingParam(sErrorParams)
                                            ,arrFormattingValues,NO_BINDING_VALUE);
            }
        }
        
        
        return valueToReturn;
    }
    
    public static String loadErrorAuditText(Long lErrorCode, String sOffice, BindingParameter[] arrBindingParameters)
    {
        String valueToReturn=null;
        Journalmessages journalMess=CacheKeys.journalMessagesKey.getSingle(lErrorCode);
        
        if (journalMess!=null)
        {
          Object[] arrFormattingValues = !GlobalUtils.isNullOrEmpty(sOffice) ?
                                         ASCacheFactory.getInstance().getFormattingValues(sOffice) : null;
                                         
          valueToReturn = GlobalUtils.getEditedErrorText(journalMess.getDescription(),arrBindingParameters,
                                                         arrFormattingValues, NO_BINDING_VALUE);
        }
        return valueToReturn;
    }
    public String loadErrorAuditText(Long lErrorCode, Object... values)
    {
    	return loadErrorAuditText(lErrorCode, (String)null, values);
    }
    public String loadErrorAuditText(Long lErrorCode, String mid, Object... values)
    {
        String valueToReturn=null;
        Journalmessages journalMess=CacheKeys.journalMessagesKey.getSingle(lErrorCode);
        
        final PDO pdo = Admin.getContextPDO();
        Object[] arrFormattingValues = null ; 
        
        //implicitly retrieve the office and via it - the formatting values if the pdo was 
        //present
        if(pdo != null) {
        	final String sOffice = pdo.getString(PDOConstantFieldsInterface.P_OFFICE) ;  
        	arrFormattingValues = !GlobalUtils.isNullOrEmpty(sOffice) ?
                    ASCacheFactory.getInstance().getFormattingValues(sOffice) : null;
            mid = pdo.getMID();   
        }//EO if the pdo was presenet 
        
        if (journalMess!=null)
        {
          valueToReturn = GlobalUtils.getEditedErrorText(journalMess.getDescription(),preparationsForBindingProcess(values, journalMess, mid).getBindingParams(),
        		  arrFormattingValues, NO_BINDING_VALUE);
        }
        return valueToReturn;
    }

    
    public static <T> String onError(final int iErrorCode, String mid, Class<T> clsExceptionType, 
    																Object...arrBindingValues) throws Exception{ 
    	
    	final String sErrorMsg = getErrorText(iErrorCode, mid, arrBindingValues) ; 
    	
    	if(clsExceptionType != null)  { 
    		final Constructor constructor = clsExceptionType.getConstructor(String.class)  ;
    		constructor.newInstance(sErrorMsg) ; 
    	}//EO if the exception class was specifield 
    	
    	return sErrorMsg ; 
    }//EOM 
    
    public final Feedback configureFeedback(final int iErrorCode, Feedback feedback, Object...arrBindingValues){ 
    	return onError(iErrorCode, feedback, arrBindingValues) ; 
    }//EOM 
    
    public static Feedback onError(final String sErrorPrefix, final int iErrorCode, Feedback feedback, Object...arrBindingValues){
    	String sMid=null;
    	PDO pdo=Admin.getContextPDO();
    	if (null!=pdo)
    	{
    		sMid=pdo.getMID();
    	}
    	if (feedback==null)
    	{
    		feedback = new Feedback();
    	}

    	final String sErrorMsg = getErrorText(iErrorCode, sMid, arrBindingValues);
    	
    	feedback.setErrorText(sErrorMsg);
    	
    	return onError(sMid,iErrorCode, feedback,sErrorMsg,sErrorMsg,sErrorPrefix); 
    }
    
    public static Feedback onError(final int iErrorCode, Feedback feedback, Object...arrBindingValues){
    	String sMid=null;
    	PDO pdo=Admin.getContextPDO();
    	if (null!=pdo)
    	{
    		sMid=pdo.getMID();
    	}
    	if (feedback==null)
    	{
    		feedback = new Feedback();
    	}
    	return onError(iErrorCode, sMid, feedback, arrBindingValues);
    }
    
    public static Feedback onError(final int iErrorCode, String mid, Feedback feedback, Object...arrBindingValues){
    	
    	final String sErrorMsg = getErrorText(iErrorCode, mid, arrBindingValues) ; 
    	feedback.setErrorText(sErrorMsg);
    	return onError(mid,iErrorCode, feedback,sErrorMsg,sErrorMsg,"") ; 
    }//EOM 
        
    public static Feedback onError(final Throwable t, final Feedback feedback, Object...arrBindingValues){
    	int	theError = GlobalUtils.getErrorCode(t);
    	
    	theError = (-1 == theError) ? GenericError : theError;
    	final String sErrorText = GlobalUtils.getErrorMessage(t);
    	final String sErrorMsg = getErrorText(theError, null, arrBindingValues);  
    	final String sErrorPrefix = GlobalUtils.getErrorPrefix(t);  
    	final String sErrorMid = GlobalUtils.getErrorMid(t);  
    	
    	return onError(sErrorMid, theError, feedback, sErrorText, sErrorMsg, sErrorPrefix) ; 
    }//EOM 
    
    public static Feedback onError(final String sMID, final int iErrorCode, Feedback feedback, final String sErrorMsg, final String sUserErrorMsg, final String sErrorPrefix) { 
    	feedback = (feedback != null ? feedback : new Feedback()) ;  
    	feedback.setFailure(); 
    	feedback.setErrorMID(sMID);
    	feedback.setErrorCode(iErrorCode);
    	feedback.setErrorText(sErrorMsg) ;
    	feedback.setErrorPrefix(sErrorPrefix) ;
    	feedback.setUserErrorText(sUserErrorMsg) ; 
    	return feedback ; 
    }//EOM 
        
    public static final String getErrorText(final int iErrorCode, String mid, Object...arrBindingValues) {
    	//first attempt to retrieve the error formal argument 
    	Journalmessages errorMetadata = CacheKeys.journalMessagesKey.getSingle(iErrorCode) ; 
    	
    	//if the errorMetadata was null, fallback on to GenericError
    	if(errorMetadata == null) 
    		errorMetadata = CacheKeys.journalMessagesKey.getSingle(iErrorCode) ;
    	if(StringUtils.isEmpty(mid)){
    		  PDO pdo = Admin.getContextPDO();
    		  if(pdo != null) //it's message (not profile) 
    		  mid = pdo.getMID();
    	}
//    	return GlobalUtils.getEditedErrorText(
//    			errorMetadata.getDescription(),
//    			constructBindingParam(arrBindingValues) 
//    		) ;
    	return GlobalUtils.getEditedErrorText(
    			errorMetadata.getDescription(),
    			preparationsForBindingProcess(arrBindingValues, CacheKeys.journalMessagesKey.getSingle(iErrorCode), mid).getBindingParams() 
    		) ;
    	
    	
    }//EOM 
    
    /**
     * Method which creates Binding Parameters Array according to error parameters string.
     * The string looks something like this: @@1@@NUMBER@@,@@lala@@VARCHAR@@...
     * @param sErrorParams
     * @return BindingParameter[]
     *
     */
    private static BindingParameter[] constructBindingParam(String sErrorParams)
    {
        BindingParameter[] arrBindingParams=null;
        if (sErrorParams!=null && sErrorParams.length()>0)
        {
            String[] arrOfBindingParamsAsString=sErrorParams.split(PARAMETERS_FIELDS_DELIMITER);
            if (arrOfBindingParamsAsString!=null && arrOfBindingParamsAsString.length>0)
            {
                arrBindingParams=new BindingParameter[arrOfBindingParamsAsString.length];
                for (int i=0;i<arrBindingParams.length;i++)
                {
                    String[] arrArgumentsForBindingParam=
                                arrOfBindingParamsAsString[i].split(FIELD_FORMAT_DELIMITER);
                    //after splitting the binding param. string, index 0 holds empty string
                    //index 1 holds the value
                    //index 2 holds the type.
                    if (arrArgumentsForBindingParam!=null &&arrArgumentsForBindingParam.length>=3)
                    {
                        arrBindingParams[i]=new BindingParameter(arrArgumentsForBindingParam[1]
                                       ,DataType.reverseValueOf(arrArgumentsForBindingParam[2]));
                    }
                    else
                    {
                        arrBindingParams[i]=new BindingParameter(NO_BINDING_VALUE,DataType.STRING);
                    }
                }
            }
        }
        return arrBindingParams;
    }
    
    /**
     * Method which creates Binding Parameters Array according to error parameters string.
     * The string looks something like this: @@1@@NUMBER@@,@@lala@@VARCHAR@@...
     * @param sErrorParams
     * @return BindingParameter[]
     *
     */
    private static BindingParameter[] constructBindingParam(Object[] arr)
    {
        BindingParameter[] arrBindingParams=null;
        if (arr!=null && arr.length>0)
        {
            int size=arr.length;
            arrBindingParams=new BindingParameter[size];
            
            for (int i=0;i<size;i++)
            {
                arrBindingParams[i]=new BindingParameter(arr[i]!=null?arr[i].toString():"null",DataType.STRING);
            }
        }
        return arrBindingParams;
    }    
    
    /**
     * We need to retrieve the error attributes for the passed error code within the ErrorAuditInputData input parameter
     * @param eaInputData
     * @return Journalmessages
     *
     */
    private static Journalmessages retrieveErrorAttributes(ErrorAuditInputData eaInputData)
    {
        Journalmessages journal = CacheKeys.journalMessagesKey.getSingle(eaInputData.getErrorCode());
        if (journal==null)
        {//In case the cache doesn't return any value, then we need to create the parallel empty JPA 
         //object with the following default values:
            journal=new Journalmessages();
            journal.setErrorCode(eaInputData.getErrorCode());
            journal.setDescription(eaInputData.getErrorCode() + " - doesn't exist in errors system table");
            journal.setPricingWeight(0l);
            journal.setErrorSeverity(9l);
            journal.setFault("O");
            journal.setClass_("A");
            journal.setTypeAudit((short)1);
            journal.setTypeMsgerr((short)1);
            journal.setTypeErrlog((short)1);
            journal.setPaymentError(eaInputData.getMid()!=null&&eaInputData.getMid().length()>0?(short)1:(short)0);
        }
        return journal;
    }
    
    /**
     * In case, we deal with payment error, and this error is set to be written into the MSGERR table, 
     * (TYPE_MSGERR <> 0), or into the NEWJOURNAL table, (TYPE_AUDIT <> 0), but the MID is null, then there 
     * is no need to write the error into these tables, as they have MID as their unique key, and all logic 
     * around reading from them involves the MID. In that case, the error should be written into 
     * the ERRORLOG table, which doesn't hold an MID column
     * @param journalMess
     * @param sMid void
     *
     */
    private static void additionalSettingsBeforeAnalyzingBindingParameters(Journalmessages journalMess, String sMid)
    {
        if (journalMess.getPaymentError()!=0
                &&(journalMess.getTypeAudit()!=0 || journalMess.getTypeMsgerr()!= 0)
                && (sMid ==null || sMid.length()==0))
        {
            journalMess.setTypeMsgerr((short)0);
            journalMess.setTypeAudit((short)0);
            journalMess.setTypeErrlog((short)1);
            journalMess.setErrorSeverity(9l);
        }
    }
    /**
     * In case the PARAMETERS_FIELDS column isn't null, then it means that the error description includes 
     * binding parameters, where each parameter's value can be taken either from the message information 
     * or from the 'Non-payment fields' values' array within the ErrorAuditInputData input parameter
     * @param eaInputData
     * @param journalMess
     * @param listErrorAuditObjects void
     *
     */
    private static void analyzingBindingParametersProcess(ErrorAuditInputData eaInputData, Journalmessages journalMess,
                                                          List<Object> listErrorAuditObjects, PDO pdo)
    {
        String sEditedErrorText = null;
        Output output = null;
        if (journalMess.getParametersFields()!=null
                &&journalMess.getParametersFields().length()>0
                &&!isStopBindingProcess(eaInputData,journalMess))
        {
            output=preparationsForBindingProcess(eaInputData.getNonPaymentsFields(),journalMess, eaInputData.getMid());
            Object[] arrFormattingValues = ASCacheFactory.getInstance().getFormattingValues(eaInputData.getOffice());
            sEditedErrorText=GlobalUtils.getEditedErrorText(journalMess.getDescription(),output.getBindingParams(),arrFormattingValues
                                                                    ,NO_BINDING_VALUE);
            
        }else
        {
            output=preparationsForBindingProcess(eaInputData.getNonPaymentsFields(),journalMess, eaInputData.getMid());
            sEditedErrorText=GlobalUtils.getEditedErrorText(journalMess.getDescription(),null,null,NO_BINDING_VALUE);
        }
        writingToDb(journalMess,eaInputData,sEditedErrorText,output,listErrorAuditObjects, pdo);
    }
    /**
     * The decision whether to perform an immediate insert into the database, will be determined according 
     * to the 'Write to database' member of the ErrorAuditInputData input parameter.
     * In case 'Write to database' is true, the method will perform an immediate insert and returned value of this method should be null.
     * In case 'Write to database' is false, then returned value of this method should be an ArrayList, which will contain one or more 
     * JPA objects
     * @param journalMess
     * @param eaInputData
     * @param sEditedErrorText
     * @param output
     * @param listErrorAuditObjects void
     *
     */
    private static void writingToDb(Journalmessages journalMess, ErrorAuditInputData eaInputData, String sEditedErrorText, Output output,
                                    List<Object> listErrorAuditObjects, PDO pdo)
    {
        ActivityAudit auditActivity=insertIntoAuditActivity(journalMess,eaInputData,output,sEditedErrorText);
        Msgerr msgErr=insertIntoMsgErr(journalMess,eaInputData,output, pdo);
        Newjournal newJournal=insertIntoNewJournal(journalMess,eaInputData,output,pdo);
        Errorlog errorLog= persistErrorLogInTxIsolation(journalMess,eaInputData,sEditedErrorText);
        MsgSpecialInstructions msgSI=insertToMsgSpecialInstruction(eaInputData,output,pdo);
        
        if (eaInputData.isWriteToDB())
        {
            EntityManager entityManager=EntityManagerHelper.getEntityManagerHelper(EntityManagerHelper.PERSISTANCE_UNIT_MAIN,true).getEntityManager();
            try
            {
                if (auditActivity!=null)
                    entityManager.persist(auditActivity);
                if (msgErr!=null)
                    entityManager.persist(msgErr);
                if (newJournal!=null)
                    entityManager.persist(newJournal);
                if (msgSI!=null)
                    entityManager.persist(msgSI);
            }finally
            {
                EntityManagerHelper.closeSession(EntityManagerHelper.PERSISTANCE_UNIT_MAIN);
            }
        }
        else
        {
            pdo = pdo == null ? Admin.getContextPDO() : pdo;
            
            if (auditActivity!=null)
                listErrorAuditObjects.add(auditActivity);
            if (msgErr!=null)
            {
                listErrorAuditObjects.add(msgErr);
                if (pdo!=null)
                    pdo.addMsgerror(msgErr);
            }
            if (newJournal!=null)
            {
                listErrorAuditObjects.add(newJournal);
                if (pdo!=null)
                    pdo.addNewjournal(newJournal);
            }
            if (msgSI!=null)
            {
                listErrorAuditObjects.add(msgSI);
                if (pdo!=null)
                    pdo.addMsgSpecialInstructionList(msgSI);
            }
            if (errorLog!=null)
                listErrorAuditObjects.add(errorLog);            
        }
    }
    
    /**
     * There is no need to continue the binding process in the following cases:
     *   1) PAYMENT_ERROR is 0 & the 'Non-payment fields' values' array is null or empty.
     *   2) PAYMENT_ERROR is 1, the PARAMETERS_FIELDS column includes fields which are only from non-payment field 
     *      format & the 'Non-payment fields' values' array is null or empty
     * @param eaInputData
     * @param journalMess
     * @return boolean
     *
     */
    private static boolean isStopBindingProcess(ErrorAuditInputData eaInputData, Journalmessages journalMess)
    {
        boolean bFlag=false;
        //PAYMENT_ERROR is 0 & the 'Non-payment fields' values' array is null or empty
        if (journalMess.getPaymentError()==0 && (eaInputData.getNonPaymentsFields()==null||eaInputData.getNonPaymentsFields().length==0))
        {
            bFlag=true;
        }
        //PAYMENT_ERROR is 1, the PARAMETERS_FIELDS column includes fields which are only from non-payment field 
        //format & the 'Non-payment fields' values' array is null or empty
        else if (!bFlag &&journalMess.getPaymentError()!=0
                &&journalMess.getParametersFields().indexOf(PAYMENT_FIELD_FORMAT_PREFIX)==-1
                && (eaInputData.getNonPaymentsFields()==null||eaInputData.getNonPaymentsFields().length==0))
        {
            bFlag=true;
        }
        return bFlag;
    }
    
    /**
     * This step creates from the PARAMETER_FIELDS column 2 outputs which are required for the rest of the process.
     *   - The 2 outputs are:
     *   1) String that is equivalent to the PARAMETER_FIELDS column's value, only now it will include all values and types.
     *   This string will be referred as 'Updated Parameters Fields' from now on.
     *   2) Array of BindingParameter objects, where each object includes the parameter's value and its type.
     *   
     * @param arrNonPaymentFields
     * @param journalMess
     * @return Output - inner class which wraps two types of outputs 
     *
     */
    public static Output preparationsForBindingProcess(Object[] arrNonPaymentFields, Journalmessages journalMess, String mid)
    {
        String sValueToReturn="";
        
        BindingParameter[] arrBindingParams=null;
        String str;
        int iIndxNonPayment=0;
        if (journalMess.getParametersFields()!=null)
        {
            String[] arrSplitedPramasFields=journalMess.getParametersFields().split(PARAMETERS_FIELDS_DELIMITER);
            int iSize=arrSplitedPramasFields.length;
            arrBindingParams=new BindingParameter[iSize];
            StringBuilder sbUpdatedParamsFields=new StringBuilder();
            for (int i=0;i<iSize;i++)
            {
                str=arrSplitedPramasFields[i];       
                arrBindingParams[i]=str.startsWith(PAYMENT_FIELD_FORMAT_PREFIX)?getBindingParamFromPaymentField(str,mid)
                                                     :getBindingParamFromNonPaymentField(str,arrNonPaymentFields,iIndxNonPayment++);
                sbUpdatedParamsFields.append(FIELD_FORMAT_DELIMITER).append(arrBindingParams[i].getValue()).append(FIELD_FORMAT_DELIMITER)
                                     .append(arrBindingParams[i].getBindiParameterType().name()).append(FIELD_FORMAT_DELIMITER)
                                     .append(PARAMETERS_FIELDS_DELIMITER);
            }
            if (sbUpdatedParamsFields.length()>0)
                sValueToReturn=sbUpdatedParamsFields.substring(0,sbUpdatedParamsFields.length()-PARAMETERS_FIELDS_DELIMITER.length());
            
        }
        return new Output(sValueToReturn,arrBindingParams);
    }
    
    /**
     * Method which retrieves the binding parameter from non payment field array
     * @param sFieldParam
     * @param arrNonPaymentFields
     * @param iIndx
     * @return BindingParameter
     *
     */
    private static BindingParameter getBindingParamFromNonPaymentField(String sFieldParam, Object[] arrNonPaymentFields, int iIndx)
    {
        BindingParameter bindingParam=new BindingParameter();
        if (arrNonPaymentFields!=null && arrNonPaymentFields.length>iIndx)
        {
            arrNonPaymentFields[iIndx]=arrNonPaymentFields[iIndx]==null?" ":arrNonPaymentFields[iIndx];
            bindingParam.setValue(arrNonPaymentFields[iIndx].toString());
            try
            {       
                bindingParam.setBindiParameterType(Enum.valueOf(DataType.class,sFieldParam.substring(NON_PAYMENT_FIELD_FORMAT_PREFIX.length()
                                                                                    ,sFieldParam.length()-FIELD_FORMAT_DELIMITER.length())));
            }catch(IllegalArgumentException e)
            {
                bindingParam.setBindiParameterType(DataType.STRING);
            }
        }
        //if index is not valid, return no binding value whith type char
        else
        {
            bindingParam.setValue(NO_BINDING_VALUE);
            bindingParam.setBindiParameterType(DataType.STRING);
        }
        return bindingParam;
    }
    /**
     * Method which retrieves the binding parameter from payment fields, from payment information
     * @param sFieldParam
     * @return BindingParameter
     *
     */
    private static BindingParameter getBindingParamFromPaymentField(String sFieldParam, String mid)
    {
        BindingParameter bindingParam=new BindingParameter();
        String sParamName;
        int iIndex=-1;
        Matcher matcher=m_pattern.matcher(sFieldParam);
        PDO pdo=PaymentDataFactory.load(mid);
        PaymentFieldInterface paymentField=pdo.getField(sFieldParam);
        if (matcher.find())
        {
            
            sParamName=sFieldParam.substring(PAYMENT_FIELD_FORMAT_PREFIX.length(),sFieldParam.length()-matcher.group(1).length());
            iIndex=Integer.parseInt(matcher.group(2));
            try
            {
                bindingParam.setValue(pdo.getString(sParamName,iIndex));
            }catch(Exception e)
            {
                bindingParam.setValue(NO_BINDING_VALUE);
            }
            
        }
        else
        {
        	int size = sFieldParam.endsWith(FIELD_FORMAT_DELIMITER) ? sFieldParam.length() - 2 : sFieldParam.length();
            sParamName=sFieldParam.substring(PAYMENT_FIELD_FORMAT_PREFIX.length(), size);
            bindingParam.setValue(pdo.getString(sParamName));
        }
        
        bindingParam.setBindiParameterType(paymentField.getDataType());
        return bindingParam;
    }
    
    private static Msgerr insertIntoMsgErr(Journalmessages journalMess, ErrorAuditInputData eaInputData, Output output, PDO pdo)
    {
      Msgerr msgErr = null;
      
      if(journalMess.getTypeMsgerr() != 0 && journalMess.getPaymentError() != 0)
      {
        DateAndZone dateAndZone=NewASDateTimeUtils.getCurrentDateAndZoneByOffice(eaInputData.getOffice());
        Integer partitionID = (pdo != null)? pdo.getIsHistory() : eaInputData.getPartitionID();
        
        msgErr=new Msgerr(eaInputData.getMid(),null,output.getUpdatedParamsFields(),0l
                ,eaInputData.getFieldLogicalIDs()
                ,journalMess.getPricingWeight(),journalMess.getErrorSeverity(),journalMess.getFault(),journalMess.getErrorCode()
                ,dateAndZone.getDisplayZone(),dateAndZone.getDate(),eaInputData.getModuleId(), partitionID);
        
        
        // MINF.P_WHOSE_ERROR update.
        if(pdo != null)
        {
            String sFault = journalMess.getFault() != null ? journalMess.getFault().trim() : "";
          String sP_WHOSE_ERROR = pdo.getString(PDOConstantFieldsInterface.P_WHOSE_ERROR); 
          
          if(WHOSE_ERROR_CUSTOMER.equals(sFault) && !WHOSE_ERROR_CUSTOMER.equals(sP_WHOSE_ERROR))
          {
            pdo.set(PDOConstantFieldsInterface.P_WHOSE_ERROR, WHOSE_ERROR_CUSTOMER);
          }
          else if(sP_WHOSE_ERROR == null && !isNullOrEmpty(sFault))
          {
            pdo.set(PDOConstantFieldsInterface.P_WHOSE_ERROR, sFault);
          }
        }
      }
      
      return msgErr;
    }
    
    /**
     * 
     */
    private static Newjournal insertIntoNewJournal(Journalmessages journalMess, ErrorAuditInputData eaInputData, Output output, PDO pdo)
    {
      final String MISSING_FIELD_LOGICAL_ID = "MISSING_FIELD_LOGICAL_ID";
      
      Newjournal newJournal = null;
      
      if(journalMess.getTypeAudit()!= 0 && journalMess.getPaymentError()!= 0)
      {
        DateAndZone dateAndZone=NewASDateTimeUtils.getCurrentDateAndZoneByOffice(eaInputData.getOffice());
        
        String[] arrFieldLogicalIDs = eaInputData.getFieldLogicalIDs();
        String sFieldLogicalID = isArrayNotNullAndNotEmpty(arrFieldLogicalIDs) ? arrFieldLogicalIDs[0] : MISSING_FIELD_LOGICAL_ID;
        
        String[] arrNEWJOURNALFieldLogicalIDs = eaInputData.getNEWJOURNALFieldLogicalIDsArray();
        MtableDocument xbeanRelatedFieldsData = null;
        if(isArrayNotNullAndNotEmpty(arrNEWJOURNALFieldLogicalIDs))
        {
          xbeanRelatedFieldsData = createNEWJOURNAL_RelatedFieldsData(arrNEWJOURNALFieldLogicalIDs);
        }
        
        String msgStatus = (pdo != null)? pdo.getString(PDOConstantFieldsInterface.P_MSG_STS) : null ;
        Integer partitionID = (pdo != null)? pdo.getIsHistory() : eaInputData.getPartitionID();
        
        newJournal = new Newjournal(eaInputData.getOffice(), eaInputData.getUserStartDateAndTime() == null ? dateAndZone.getDate() : eaInputData.getUserStartDateAndTime(), dateAndZone.getDate(),
                                    eaInputData.getUserId(), eaInputData.getModuleId(), output.getUpdatedParamsFields(),
                                    eaInputData.getMid(), msgStatus, null, null,
                                    journalMess.getClass_(), journalMess.getPricingWeight(), sFieldLogicalID,
                                    journalMess.getFault(), null, journalMess.getErrorSeverity(), eaInputData.getHitInfo(), 
                                    dateAndZone.getDisplayZone(), Admin.getContextAdmin().getClientRemoteAddress(),
                                    journalMess.getErrorCode(), null, 0l, journalMess.getTypeFieldsChangeVerify(), 
                                    xbeanRelatedFieldsData, partitionID);
      }
      
      return newJournal;
    }
    
    /**
     * Returns MtableDocument object for the passed String array of field logical IDs.
     */
    private static MtableDocument createNEWJOURNAL_RelatedFieldsData(String[] arrNEWJOURNALFieldLogicalIDs)
    {

      MtableDocument mtableDocument = MtableDocument.Factory.newInstance();
      MsgTableType msgTableType = mtableDocument.addNewMtable();
      
      // Loops array of fields and prepares for each one of them a MsgTableType object which 
      // its ID will be a field logical ID.
      // The 'OLD_VALUE' & 'NEW_VALUE' elements remain null.
      for(int i=0; i<arrNEWJOURNALFieldLogicalIDs.length; i++)
      {
        addMsgTableRecord(msgTableType, arrNEWJOURNALFieldLogicalIDs[i], null, null, null);
      }
      
      return mtableDocument;
    }
    
    /**
     * Adds a record to the passed MsgTableType object.
     */
    public static final void addMsgTableRecord(final MsgTableType msgTableType, final String sFieldID, final DataType enumDataType,
    		final Object oOldValue, final Object oNewValue){
    	
      final String NAME_SPACE_MsgTable = "http://fundtech.com/SCL/CommonTypes" ; 
      final QName OLD_VALUE_QNAME = new QName(NAME_SPACE_MsgTable, "OLD_VALUE");
      final QName NEW_VALUE_QNAME = new QName(NAME_SPACE_MsgTable, "NEW_VALUE"); 
      final QName COLUMN_QNAME = new QName(NAME_SPACE_MsgTable, "column") ; 
      
      RecordType record = msgTableType.addNewRecord();
      final XmlObjectBase field = (XmlObjectBase)((XmlObjectBase)record).get_store().insert_element_user(
    		  (enumDataType == null ? COLUMN_QNAME : 
    		      new QName(NAME_SPACE_MsgTable, enumDataType.name()) 
    		  ), 0) ;
      ((MsgTableEntryBaseType)field).setId(sFieldID) ;
      
      if(oOldValue != null)
      {
        final XmlObjectBase xbeanOldValue = (XmlObjectBase) field.get_store().insert_element_user(OLD_VALUE_QNAME, 0) ;
        xbeanOldValue.setObjectValue(oOldValue);
      }

      if(oNewValue != null)
      {
        final XmlObjectBase xbeanNewValue = (XmlObjectBase) field.get_store().insert_element_user(NEW_VALUE_QNAME, 0) ;
        xbeanNewValue.setObjectValue(oNewValue);
      }
      
//      System.out.println(msgTableType);
//      System.out.println( ((DOUBLE)msgTableType.getRecordArray(0).getColumnArray(0)).getOLDVALUE());
//      System.out.println( ((DOUBLE)msgTableType.getRecordArray(0).getColumnArray(0)).getNEWVALUE());
    }
    
    /**
     * Prepares a NEWJOURNAL record for the user changed fields; this record might already exist in the list
     * of NEWJOURNAL objects that is kept in the passed PDO; in that case, this record will be used and all its 
     * properties - especially the MtableDocument property within it, which should be kept into the XML_RELATED_FIELDS_DATA
     * column - will be updated as required.
     * The MtableDocument property which should hold all modified fields data, will include data from 2 sources:
     * 1) Data from the 'm_mapCurrentStateSnapshots' NEWJOURNAL class member, in case we had already an existing
     * NEWJOURNAL record; from that HashMap, writable tables which were changed by the user, (e.g. fees, rates, etc),
     * will be taken. 
     * 2) Set of modified fields in the PDO.  
     */
    public static void prepareUserModifiedFieldsNEWJOURNALEntry(PDO pdo)
    {
      // STEP 1 - 
      // Checks if we have an already existing NEWJOURNAL record, and creates one in case no such has been found
      // or in case the first entry in the list isn't the one created for user modified fields.  
      //
      final Newjournal modifiedFieldsNewjournal = pdo.getUserModifiedFieldsNEWJOURNALEntry(true/*create instance of not yet instantiated*/) ; 
      
      // STEP 2 - 
      // Initiailizes the MtableDocument object which will be set into the 'modifiedFieldsNewjournal' variable
      // and will hold all data for the user modified fields.
      MtableDocument mtableDocumentXmlRelatedFieldsData = MtableDocument.Factory.newInstance();
      MsgTableType msgTableType = mtableDocumentXmlRelatedFieldsData.addNewMtable();
      
      // STEP 3 - 
      // Updates the MtableDocument object with all modified fields from the PDO.
  
      final Collection<PaymentFieldInterface> setModifiedFields = pdo.getModifiedFields() ; 
      
      if(setModifiedFields != null) { 
    	  for(PaymentFieldInterface modifiedField : setModifiedFields) { 
    		  
    		  //if the modification is not of type USER - skip 
    		  if(!modifiedField.isAuditable() || modifiedField.getModificationType() != ModificationType.User) continue ; 
    		  
    		  FieldType fieldType = modifiedField.getFieldType();
			  Object oOriginalValue;
    		  if(fieldType != FieldType.XML_MULTI)
				{
					oOriginalValue = modifiedField.getOriginalValue();
				}
				else
				{
					String sFieldPath = ((XmlMultiOccurencePaymentField)modifiedField).getLogicalFieldsXPath().getFieldPath(); 
					Object[] arrPathToField = new Object[]{ modifiedField.getFieldId()};
					oOriginalValue = ((XmlMultiOccurencePaymentField)modifiedField).getOriginalValue( arrPathToField);
				}
    		    addMsgTableRecord(msgTableType, modifiedField.getFieldId(),
    				  modifiedField.getDataType(),
    				  oOriginalValue !=null && oOriginalValue.equals(modifiedField.get()) ? null :oOriginalValue,
    				  modifiedField.get()
    				  ) ; 
    		  
    	  }//EO while there are more modified fields 
      }//EO if there were modified fields 
      
      // STEP 4 - 
      // Updates the MtableDocument object with writable tables data.
      Map<String, SnapShotHolder> mapStateSnapshots = modifiedFieldsNewjournal.getStateSnapshotsHM();
      if(mapStateSnapshots != null && !mapStateSnapshots.isEmpty())
      {
        Iterator<String> iterKeys = mapStateSnapshots.keySet().iterator();
        try{ 
	        while(iterKeys.hasNext())
	        {
	          String sKey = iterKeys.next();
	          SnapShotHolder snapShot = mapStateSnapshots.get(sKey);
	          
	          if(snapShot.getModificationType() == PaymentFieldInterface.ModificationType.User)
	          {
	            String[] arrObjectValue = snapShot.getValuesArr();
	            //only insert the table entry if there was a change (arrObjectValue[1] != null)
	            if(arrObjectValue.length == 2 && arrObjectValue[1] != null)
	            {
	              //parse the entries and store 
	        	  final XmlObject oldValue = XmlObject.Factory.parse(arrObjectValue[0]) ;
	        	  final XmlObject newValue = XmlObject.Factory.parse(arrObjectValue[1]) ;
	        	  addMsgTableRecord(msgTableType, sKey, DataType.TABLE, newValue, oldValue);
	           
	            }
	          }//EO if instance of string 
	         }//EO while 
          }catch(Exception e){ 
        	  ExceptionController.getInstance().handleException(e, null) ; 
          }//EO catch block 
      }//EO if the mapStateSnapshots was not null 
      
      // STEP 5 - 
      // Sets the Newjournal object with the modified fields data.
      modifiedFieldsNewjournal.setXmlRelatedFieldsData(mtableDocumentXmlRelatedFieldsData);
    }
    
    /**
     * Returns Newjournal JPA for the user modified fields entry in which the 'm_xbeanRelatedFieldsData'
     * class member is null, (i.e. no data yet for the NEWJOURNAL.XML_RELATED_FIELDS_DATA column).
     */
    public Newjournal createUserModifiedFieldsNEWJOURNALEntrySkeleton(PDO pdo)
    {
      String sPaymentOffice = pdo.getString(PDOConstantFieldsInterface.P_OFFICE);
      DateAndZone dateAndZone = NewASDateTimeUtils.getCurrentDateAndZoneByOffice(sPaymentOffice);
      
      String sMID = pdo.getString(PDOConstantFieldsInterface.P_MID);
      String sMessageStatus = pdo.getString(PDOConstantFieldsInterface.P_MSG_STS);
      
      Journalmessages journalmessages = CacheKeys.journalMessagesKey.getSingle(LONG_ERROR_CODE_USER_MODIFIED_FIELDS);
      
      final WebSessionInfo webSessionInfo = Admin.getContextAdmin().getNSetWebSessionInfo() ; 
      
      String sUserID = (webSessionInfo == null ? ServerConstants.EMPTY_STRING : webSessionInfo.getUserID() ) ; 
      
      return new Newjournal(sPaymentOffice, dateAndZone.getDate(), dateAndZone.getDate(), sUserID, null, null, sMID, 
                            sMessageStatus, null, null, journalmessages.getClass_(), 
                            journalmessages.getPricingWeight(), "MODIFIED_ENTRIES",
                            journalmessages.getFault(), null, journalmessages.getErrorSeverity(), null,
                            dateAndZone.getDisplayZone(), Admin.getContextAdmin().getClientRemoteAddress(),
                            journalmessages.getErrorCode(), null, 0l, journalmessages.getTypeFieldsChangeVerify(),
                            null, pdo.getIsHistory());
    }
    
  /**
   * Handles stored procedure call failure.
   * @param bErrorReturnCode true/false according to specific related SP definition.
   * @param feedback Feedback object returned from the SP call.
   * @param iErrorCode the error code to set in case 'bErrorReturnCode' is true.
   * @param sErrorMessagePrefix error message prefix for tracing; can be null.
   * @param sUserID related user ID; can be null if user isn't involved.  
   * @param sOffice the default office; can be null, in which case '***' will be used.
   * @param sModuleID the related module ID; can be null.
   * @param sSPName the stored procedure name.
   * @param arrNonPaymentFields Object[1] with SP name in it; passed as a parameter to force initializing
   *                            of it as a constant in the caller class.
   * @return feedbak updated Feedback object configured with error code and error text.
   */
  public static Feedback handleSPCallFailure(boolean bErrorReturnCode, Feedback feedback, int iErrorCode, 
                                             String sErrorMessagePrefix, String sUserID, String sOffice, String sModuleID,
                                             String sSPName, Object[] arrNonPaymentFields, boolean isWriteToConsole, boolean isWriteToDb)
  {
    final String DEF_USER_ID_AND_MODULE = "PROCESS";
    
 //   GlobalTracer GlobalTracer = GlobalTracer;
    
    
    // STEP 1 - 
    // Writes error into ERRORLOG table
    sUserID = !isNullOrEmpty(sUserID) ? sUserID : DEF_USER_ID_AND_MODULE;
    sOffice = !isNullOrEmpty(sOffice) ? sOffice : ServerConstants.DEFAULT_SERVER_OFFICE_NAME;
    sModuleID = !isNullOrEmpty(sModuleID) ? sModuleID : DEF_USER_ID_AND_MODULE;
    
    String sSessionID = Admin.getContextAdmin() != null ? Admin.getContextAdmin().getSessionID() : "BOGUS_SESSION_ID";
    String sIPAddress = Admin.getContextAdmin() != null ? Admin.getContextAdmin().getClientRemoteAddress() : "BOGUS_IP_ADDRESS";
    ErrorAuditInputData eaInputData = new ErrorAuditInputData(isWriteToDb, sSessionID,
                                                              sModuleID, sUserID, sOffice,
                                                              null, null, sIPAddress);
    
    DateAndZone dateAndZone = NewASDateTimeUtils.getCurrentDateAndZoneByOffice(sOffice);
    eaInputData.setUserStartDateAndTime(dateAndZone.getDate());

    eaInputData.setErrorCode((long)ProcessErrorConstants.StoredProcedureFailure);
    eaInputData.setNonPaymentsFields(arrNonPaymentFields);
    handleErrorAndAudit(eaInputData);
    
    Journalmessages errorMetaData = CacheKeys.journalMessagesKey.getSingle(ProcessErrorConstants.StoredProcedureFailure) ;
    BindingParameter[] arrBindingParameters = GlobalUtils.convertErrorParamsPatternStringToBindingParamsArray("@@"+sSPName+"@@STRING");
    String sErrorText = GlobalUtils.getEditedErrorText(errorMetaData.getDescription(), arrBindingParameters);

    // STEP 2 - 
    // Configures returned Feedback.
    if(bErrorReturnCode)
    {
      feedback.setErrorCode(iErrorCode);
      feedback.setErrorText(sErrorText);
    }
    
    // Do nothing; feedback is already set with error code/text.
    else if(!feedback.isSuccessful()) {} 
    
    sErrorMessagePrefix = !isNullOrEmpty(sErrorMessagePrefix) ? sErrorMessagePrefix : ServerConstants.EMPTY_STRING;
    if (isWriteToConsole) logger.info(sErrorMessagePrefix + ServerUtils.getFeedbackString(feedback));
    
    
    
    return feedback;
  }
    
  public static Errorlog persistErrorLogInTxIsolation(Journalmessages journalMess, ErrorAuditInputData eaInputData, String sEditedErrorText) {
      
	  try{ 
		  
		  //invoke only if the journal message entry is associate with the error log 
		  if (journalMess.getTypeErrlog()==0) return null ; 		  
		  
		  final TxIsolation txIsolationStub =  ServiceLocator.getInstance().SLSBlookup(TxIsolation.class) ; 
		    
		  return txIsolationStub.persistErrorLogInTxIsolation(Admin.getContextAdmin(), journalMess, eaInputData, sEditedErrorText) ;
		  
	  }catch(Exception t) { 
		 throw new RuntimeException(t) ; 
	  }//EO catch block
  }//EOM 
  
  
    public static Errorlog insertToErrLog(Journalmessages journalMess, ErrorAuditInputData eaInputData, String sEditedErrorText, boolean isWriteToConsole)
    {
    	
        Errorlog errorLogRecord=null;
        if (journalMess.isTypeErrlog())
        {           
            StackTraceElement[] arrStackTraceElement = new Throwable().getStackTrace();
            
            String stackTrace ="";
            String stackTraceLineNumber="";
            
            if (arrStackTraceElement.length > 35)
            {
            	stackTrace = arrStackTraceElement[35].getClassName();
            	stackTraceLineNumber = arrStackTraceElement[35].getLineNumber()+"";
            }

            String sTimeStamp = GlobalDateTimeUtil.getServerTimeStamp();
            
            String userId = eaInputData.getUserId();
            
            if(!sEditedErrorText.isEmpty() && userId == null)
            {
            	if(sEditedErrorText.contains("- ")){
	            	String tmp[] = sEditedErrorText.trim().split("\\- ");
	            	if(tmp.length > 3)
	            	{
	            		tmp = tmp[3].split("\\,");
	            		if(tmp.length > 0)
	            			userId = tmp[0];
	            	}
	            }
            }
            	
            
            errorLogRecord=new Errorlog(eaInputData.getModuleId(),sEditedErrorText, stackTrace
                                  ,stackTraceLineNumber,userId
                                  ,GlobalConstants.m_localHostIP
                                  ,sTimeStamp
                                  ,journalMess.getErrorSeverity(),journalMess.getErrorCode(),null,null);
            
            ErrorAuditUtils.initializeMDC(errorLogRecord);
            errorLogger.info(errorLogRecord.toString());            
            ErrorAuditUtils.initializeMDC(null);


            try
            {
                EntityManagerHelper.getEntityManagerHelper(EntityManagerHelper.PERSISTANCE_UNIT_MAIN,true).getEntityManager().persist(errorLogRecord);
                
            }
            catch(Throwable e)
            {
                ExceptionController.getInstance().handleException(e, "ErrorAuditUtils");
                
            }
            finally
            {
                EntityManagerHelper.closeSession(EntityManagerHelper.PERSISTANCE_UNIT_MAIN);
            }
        }
        return errorLogRecord;
    }
    
    private static void initializeMDC (Errorlog rec) {
    	if (rec != null) {
   			MDC.put("err.code", rec.getErrorCode() != null ? rec.getErrorCode().toString() : "");
   			MDC.put("err.severity", rec.getErrorSeverity() != null ? rec.getErrorSeverity().toString() : "");
   			MDC.put("err.desc", rec.getMoreInfo() != null ? rec.getMoreInfo() : "");
   			MDC.put("err.javaclass.name", rec.getCodefile() != null ? rec.getCodefile() : "");
   			MDC.put("err.javaclass.line", rec.getCodeline() != null ? rec.getCodeline() : "");
   			MDC.put("userId", rec.getUserId() != null ? rec.getUserId() : "");
   			MDC.put("ip", rec.getMachineId() != null ? rec.getMachineId() : "");
    	} else {
    		MDC.remove("err.code");
    		MDC.remove("err.severity");
    		MDC.remove("err.desc");
    		MDC.remove("err.javaclass.name");
    		MDC.remove("err.javaclass.line");
    		MDC.remove("userId");
    		MDC.remove("ip");
    	}
    }
    
    private static MsgSpecialInstructions insertToMsgSpecialInstruction(ErrorAuditInputData eaInputData,Output output, PDO pdo)
    {
    	Integer partitionID = pdo != null ? pdo.getIsHistory() : eaInputData.getPartitionID();
        MsgSpecialInstructions msgSpecialInstruction=null;
        if (eaInputData.isExtraTableContained(ExtraTables.MSG_SPECIAL_INSTRUCTION))
        {
            DateAndZone dateAndZone=NewASDateTimeUtils.getCurrentDateAndZoneByOffice(eaInputData.getOffice());
            msgSpecialInstruction=new MsgSpecialInstructions(eaInputData.getMid(),eaInputData.getErrorCode(),output.getUpdatedParamsFields()
                                    ,eaInputData.getSiStatus(),eaInputData.getPreventStpUid(),eaInputData.getPartyType(),eaInputData.getObjectId()
                                    ,dateAndZone.getDate(),dateAndZone.getDisplayZone(), partitionID);
        }
        return msgSpecialInstruction;
    }
    
    private static ActivityAudit insertIntoAuditActivity(Journalmessages journalMess, ErrorAuditInputData eaInputData, Output output, String sEditedErrorText)
    {
        ActivityAudit auditActivity=null;
        if (journalMess.getPaymentError()==0 && (journalMess.getTypeMsgerr()!=0 || journalMess.getTypeAudit()!=0))
        {
            DateAndZone dateAndZone=NewASDateTimeUtils.getCurrentDateAndZoneByOffice(eaInputData.getOffice());
            auditActivity=new ActivityAudit(eaInputData.isWriteToDB()?m_daoStaticData.getFormatedUniqueSysTimeFromDB().getValue():System.currentTimeMillis()+""
                                            ,eaInputData.getFlowId(),eaInputData.getModuleId(),eaInputData.getOffice()
                                            ,journalMess.getTypeMsgerr()!=0?"E":"A",eaInputData.getUserStartDateAndTime()
                                            ,dateAndZone.getDate(),journalMess.getErrorCode(),null,eaInputData.getUserId()
                                            ,eaInputData.getActivityType(),eaInputData.getActivityName()
                                            ,Admin.getContextAdmin()==null ? "" : Admin.getContextAdmin().getClientRemoteAddress()
                                            ,output.getUpdatedParamsFields(),journalMess.getErrorSeverity(),dateAndZone.getDisplayZone(), eaInputData.getTaskStatus());
        }
        return auditActivity;
    }
    
    public static class Output
    {
        String m_sUpdatedParamsFields;
        BindingParameter[] m_arrBindingParams;
        
        public Output(String str, BindingParameter[] arr)
        {
            m_sUpdatedParamsFields=str;
            m_arrBindingParams=arr;
        }
        public String getUpdatedParamsFields()
        {
            return m_sUpdatedParamsFields;
        }
        public BindingParameter[] getBindingParams()
        {
            return m_arrBindingParams;
        }
        public void setUpdatedParamsFields(String updatedParamsFields)
        {
            m_sUpdatedParamsFields = updatedParamsFields;
        }
        public void setBindingParams(BindingParameter[] bindingParams)
        {
            m_arrBindingParams = bindingParams;
        }
    }

    public int compareTo(Object o)
    {
        return 0;
    }
    
    public final String getErrorType(final int iErrorCode) { return ProcessErrorConstants.reverseValue.Of(iErrorCode) ; }//EOM      


}

