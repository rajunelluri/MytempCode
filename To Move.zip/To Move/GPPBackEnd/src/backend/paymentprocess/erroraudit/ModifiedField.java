/**
 * Apr 10, 2008
 * ModifiedField.java
 * @author Vadim Koremblum
 */
package backend.paymentprocess.erroraudit;

/**
 * 
 */
public class ModifiedField
{
    private String m_sLogicalFieldId;
    private String m_sFieldType;
    private String m_sOriginalValue;
    private String m_sNewValue;
    private Boolean m_bIsToBeAudited;
    
    /**
     * @param logicalFieldId
     * @param fieldType
     * @param originalValue
     * @param newValue
     * @param isToBeAudited
     */
    public ModifiedField(String logicalFieldId, String fieldType,
                         String originalValue, String newValue,
                         Boolean isToBeAudited)
    {
        m_sLogicalFieldId = logicalFieldId;
        m_sFieldType = fieldType;
        m_sOriginalValue = originalValue;
        m_sNewValue = newValue;
        m_bIsToBeAudited = isToBeAudited;
    }
    public String getLogicalFieldId()
    {
        return m_sLogicalFieldId;
    }
    public String getFieldType()
    {
        return m_sFieldType;
    }
    public String getOriginalValue()
    {
        return m_sOriginalValue;
    }
    public String getNewValue()
    {
        return m_sNewValue;
    }
    public Boolean isToBeAudited()
    {
        return m_bIsToBeAudited;
    }
    public void setLogicalFieldId(String logicalFieldId)
    {
        m_sLogicalFieldId = logicalFieldId;
    }
    public void setFieldType(String fieldType)
    {
        m_sFieldType = fieldType;
    }
    public void setOriginalValue(String originalValue)
    {
        m_sOriginalValue = originalValue;
    }
    public void setNewValue(String newValue)
    {
        m_sNewValue = newValue;
    }
    public void setIsToBeAudited(Boolean isToBeAudited)
    {
        m_bIsToBeAudited = isToBeAudited;
    }

}
