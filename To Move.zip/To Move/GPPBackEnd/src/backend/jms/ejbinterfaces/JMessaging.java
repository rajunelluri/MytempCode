package backend.jms.ejbinterfaces;

import java.util.Map;

import javax.ejb.Remote;
import com.fundtech.core.security.Admin;

/**
 * Remote interface for JMessaging.
 */
@Remote
public interface JMessaging{

	public static final String REMOTE_JNDI_NAME="ejb/JMessagingBean";
	
	
	/** 
	 * @author Guy Segev
	 * @date Aug 19, 2007
	 * <br><br>
	 * Creates a new send Jms session resource encapsulated within a {@link JmsSessionContext}  
	 * <br>
	 * instance
	 * <br> 
	 * @param sConnectionFactoryJndiAlias fully qualified connection-factory 
	 * <br>
	 * jndi name, as defined within the application server.
	 * @param arrDestinationNames an array containing a mixture of 
	 * <br>
	 * jndi names as defined within the application server or the destination name 
	 * <br> 
	 * as defined within the associated queue manager (termed 'Dynamic destination'). 
	 * <br> 
	 * the initialisation logic will attempt create the session queue using the 
	 * <br>
	 * index location as priority (thus, for instance the name in the 0 location 
	 * <br> 
	 * where all other queue names are held in rerseve, as failover for creation failure scenarios.
	 * <br> 
	 * @param bIsJmsTransacted true for client controlled commit/rollback facilities 
	 * <br> 
	 * and false for auto-commit session 
	 * @return {@link JmsSessionContext} instance containing the following initialised resources: 
	 * <br> 
	 * 1. ConnectionFactory 
	 * 2. IsTransacted boolean 
	 * 3. Session  
	 * 4. MessageProduder
	 * <br>
	 * @throws Exception if one of the resources creation/lookup had failed
	 * @bo.internalInterface
	 */
	public com.fundtech.jndi.JmsSessionContext createSendJmsSession(final Admin admin, java.lang.String sConnectionFactoryJndiAlias, java.lang.String[] arrDestinationNames, boolean bIsJmsTransacted, boolean bNonJmsProvider ) throws java.lang.Throwable ;
	
	/** 
	 * @author Guy Segev
	 * @date Aug 19, 2007
	 * <br><br>
	 * Creates a new send Jms session resource encapsulated within a {@link JmsSessionContext}  
	 * <br>
	 * instance
	 * <br> 
	 * @param sConnectionFactoryJndiAlias fully qualified connection-factory 
	 * <br>
	 * jndi name, as defined within the application server.
	 * @param sDestinationName jndi name as defined within the application server or the queue name 
	 * <br> 
	 * as defined within the associated queue manager (termed 'Dynamic Destination') 
	 * @param bIsJmsTransacted true for client controlled commit/rollback facilities 
	 * <br> 
	 * and false for auto-commit session 
	 * @return {@link JmsSessionContext} instance containing the following initialised resources: 
	 * <br> 
	 * 1. ConnectionFactory 
	 * 2. IsTransacted boolean 
	 * 3. QueueSession  
	 * 4. QueueSender 
	 * <br>
	 * @throws Exception if one of the resources creation/lookup had failed
	 * @bo.internalInterface
	 */
	public com.fundtech.jndi.JmsSessionContext createSendJmsSession(final Admin admin, java.lang.String sConnectionFactoryJndiAlias, java.lang.String sDestinationName, boolean bIsJmsTransacted, boolean bNonJmsProvider ) throws java.lang.Throwable ;
	
	/** 
	 * @author Guy Segev
	 * @date Aug 6, 2007
	 * <br><br>
	 * Sends a new Jms Object message whose content would be the messageBody formal arg,  
	 * <br>
	 * using the Jms Session context resources contained in the {@link JmsSessionContext} formal arg. 
	 * <br>
	 * @param bShouldReleaseResources if true and the session was marked as transacted, would commit the 
	 * <br> 
	 * session before disposing of it if all was successfull or rollback if otherwise. 
	 * <br> 
	 * on both cases, the {@link JmsSessionContext} resources would be disposed of at the method's end.
	 * <br>   
	 * @param jmsSessionContext must not be null, and contains the {@link QueueSender} and {@link QueueSession} 
	 * <br> 
	 * instances as well as the bIsTransacted flag to be used for the message sending operation.  
	 * @param messageBody message content to send
	 * @param messageProperties map with properties which should assign to the outgoing message. 
	 * 		  Standard JMS properties (JMSMessageID,JMSReplyTo..) would be assign using the standard set method
	 *  	  User define properties would we assign using Message.setObjectProperty
	 * @param sSessionId user session identifier.
	 * @throws Exception If an error had occured during the send operation, the method would 
	 * <br>
	 * check the bShouldReleaseResources and jmsSessionContext.isTransacted() flags and if both are true 
	 * <br> 
	 * would rollback the session prior to disposing of the resources.
	 */
	public void sendMessage(final Admin admin, boolean bShouldReleaseResources, com.fundtech.jndi.JmsSessionContext jmsSessionContext, java.io.Serializable messageBody, java.lang.String sSessionId, Map<String,Object> messageProperties) throws java.lang.Exception ;
	
	/** 
	 * @author Guy Segev
	 * @date Aug 12, 2007
	 * <br><br>
	 * Sends a new Jms Object message whose content would be the messageBody formal arg.  
	 * <br>
	 * creates a {@link JmsSessionContext} instance internallly, marking the created session as auto-commit one. 
	 * <br>
	 * Once the session was created, invokes the {@link #sendMessage(boolean,JmsSessionContext,Serializable,String)}, 
	 * <br>
	 * marking the bShouldDisopseOfResources as true as the session was created internally.
	 * <br>
	 * @param sConnectionFactoryJndiAlias Fully qualified jndi ConnectionFactory name defined 
	 * <br> 
	 * within the application server as a resource.
	 * <br>
	 * Internally invokes the {@link ServiceLocator#cacheJmsEntity(String,Object)} and 
	 * <br>{@link ServiceLocator#createJmsSessionContext(String,boolean)} See for more details.
	 * <br>
	 * <b>Note:</b> If an error had occured in the instantiaion process, all initialised resource 
	 * <br> 
	 * would be disposed of prior to throwing a JMSException to the client code indicating the failure.
	 * <br>
	 * @param sDestinationName destination name values could either be jndi aliases or destination names as defined within the queuemanager's context.
	 * @param messageBody content to embed in the message.
	 * @param sSessionId user session identifier.
	 * @return {@link Feedback} indicating the operation's result.
	 */
	public com.fundtech.datacomponent.response.Feedback sendMessage(final Admin admin, java.lang.String sConnectionFactoryJndiAlias, java.lang.String sDestinationName, boolean bNonJmsProvider, java.io.Serializable messageBody, java.lang.String sSessionId ) ;
	
	/** 
	 * @author Guy Segev
	 * @date Aug 12, 2007
	 * <br><br>
	 * Sends a message to the queue using the queue-connection-factory whose jndi names are associated with the 
	 * <br>
	 * sJmsConfigurationElementId key (as defined in the app-server-config.xml file). 
	 * <br>
	 * Internally creates a {@link JmsSessionContext} instance, flagging the session as auto-commit, 
	 * <br> 
	 * and the disposeResources as true so taht the internal call to {@link #sendMessage(String,String,Serializable,String)} 
	 * <br> 
	 * would disposed of the session context at the end of its flow.
	 * <br> 
	 * @see {@link #sendMessage(String,String,Serializable,String)} for more details.
	 * <br> 
	 * @param sJmsConfigurationElementId the Id of the app-server-config.xml-->jms-resource whose queue-connection-factory
	 * <br> 
	 * and queue jndi names are to be fetched from the incremented cache in the {@link ServiceLocator} 
	 * @param messageBody Message content. 
	 * @param sSessionId user's session identification 
	 * @return {@link Feedback} containing the results of the method's operation. 
	 */
	public com.fundtech.datacomponent.response.Feedback sendMessage(final Admin admin, java.lang.String sJmsConfigurationElementId, boolean bNonJmsProvider, java.io.Serializable messageBody, java.lang.String sSessionId ) ;
	
	/** 
	 * @author Guy Segev
	 * @date Aug 12, 2007
	 * <br><br>
	 * Sends one or more messages whose details are contained within the {@link JMSMessageObject} objects to a single 
	 * <br> 
	 * queue. 
	 * <br> 
	 * The method will initialise a single jms session context for all the messaeges and will flag it as auto commit. 
	 * <br> 
	 * Each error occuring in the process of sending the message would cause the whole operation to invalidate the whole 
	 * <br> 
	 * flow if the bShouldIgnoreIndividualFailures is set to true
	 * <br>
	 * The sendMessage() would set the bShouldReleaseResources to false as those would be used throughout the bulk process. 
	 * <br>
	 * The method would always dispose of the jmsSessionContext.
	 * <br> 
	 * @param sQueueConnectionFactoryJndiAlias Fully qualified jndi queueConnectionFactory name defined 
	 * <br> 
	 * within the application server as a resource.
	 * @param sQueueName Queue name values could either be jndi aliases or queue names as defined within the queuemanager's context.
	 * @param arrJMSMessageObjects  {@link JMSMessageObject})[] containing the individual message details.
	 * @param bShouldIgnoreIndividualFailures if true would continue the bulk operation dispite an error in one or more 
	 * <br>
	 * message sending operations. If False would terminate the bulk operation on the first error. 
	 * @param sSessionId user session identifier.
	 * @return {@link MultipleFieldFeedback} instance containing only the failure details if any.
	 */
	public com.fundtech.datacomponent.response.MultipleFieldFeedback sendMessages(final Admin admin, java.lang.String sQueueConnectionFactoryJndiAlias, java.lang.String sQueueName, com.fundtech.core.general.JMSMessageObject[] arrJMSMessageObjects, boolean bShouldIgnoreIndividualFailures, boolean bNonJmsProvider, java.lang.String sSessionId ) ;

}//EOI  