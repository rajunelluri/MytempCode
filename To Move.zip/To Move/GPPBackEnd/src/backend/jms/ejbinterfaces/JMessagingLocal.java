package backend.jms.ejbinterfaces;

import javax.ejb.Local;

/**
 * Local interface for JMessaging.
 */
@Local
public interface JMessagingLocal extends JMessaging{} ; 