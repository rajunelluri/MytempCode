package backend.jms.businessobjects;

import com.fundtech.core.security.Admin;

/**
 * internal interface for BOJMessaging.
 */
public interface BOJMessagingInterface{

	
	
	/** 
	 * @author Guy Segev
	 * @date Aug 19, 2007
	 * <br><br>
	 * Creates a new send Jms session resource encapsulated within a {@link JmsSessionContext}  
	 * <br>
	 * instance
	 * <br> 
	 * @param sConnectionFactoryJndiAlias fully qualified connection-factory 
	 * <br>
	 * jndi name, as defined within the application server.
	 * @param arrDestinationNames an array containing a mixture of 
	 * <br>
	 * jndi names as defined within the application server or the destination name 
	 * <br> 
	 * as defined within the associated queue manager (termed 'Dynamic destination'). 
	 * <br> 
	 * the initialisation logic will attempt create the session queue using the 
	 * <br>
	 * index location as priority (thus, for instance the name in the 0 location 
	 * <br> 
	 * where all other queue names are held in rerseve, as failover for creation failure scenarios.
	 * <br> 
	 * @param bIsJmsTransacted true for client controlled commit/rollback facilities 
	 * <br> 
	 * and false for auto-commit session 
	 * @return {@link JmsSessionContext} instance containing the following initialised resources: 
	 * <br> 
	 * 1. ConnectionFactory 
	 * 2. IsTransacted boolean 
	 * 3. Session  
	 * 4. MessageProduder
	 * <br>
	 * @throws Exception if one of the resources creation/lookup had failed
	 * @bo.internalInterface
	 */
	public com.fundtech.jndi.JmsSessionContext createSendJmsSession(final Admin admin, java.lang.String sConnectionFactoryJndiAlias, java.lang.String[] arrDestinationNames, boolean bIsJmsTransacted, boolean bNonJmsProvider ) throws java.lang.Throwable ;
	
	/** 
	 * @author Guy Segev
	 * @date Aug 19, 2007
	 * <br><br>
	 * Creates a new send Jms session resource encapsulated within a {@link JmsSessionContext}  
	 * <br>
	 * instance
	 * <br> 
	 * @param sConnectionFactoryJndiAlias fully qualified connection-factory 
	 * <br>
	 * jndi name, as defined within the application server.
	 * @param sDestinationName jndi name as defined within the application server or the queue name 
	 * <br> 
	 * as defined within the associated queue manager (termed 'Dynamic Destination') 
	 * @param bIsJmsTransacted true for client controlled commit/rollback facilities 
	 * <br> 
	 * and false for auto-commit session 
	 * @return {@link JmsSessionContext} instance containing the following initialised resources: 
	 * <br> 
	 * 1. ConnectionFactory 
	 * 2. IsTransacted boolean 
	 * 3. QueueSession  
	 * 4. QueueSender 
	 * <br>
	 * @throws Exception if one of the resources creation/lookup had failed
	 * @bo.internalInterface
	 */
	public com.fundtech.jndi.JmsSessionContext createSendJmsSession(final Admin admin, java.lang.String sConnectionFactoryJndiAlias, java.lang.String sDestinationName, boolean bIsJmsTransacted, boolean bNonJmsProvider ) throws java.lang.Throwable ;
	
	/** 
	 * @author Guy Segev
	 * @date Aug 19, 2007
	 * <br><br>
	 * Performs the following tasks: 
	 * <br> 
	 * 1.   Generates a new unique correlation id.
	 * <br>
	 * 2.   Initialises a new JmsSessionContext containing the following Resources: 
	 * <br>
	 * JmsQueueConnectionFactory, JmsQueue, JmsSession, QueueSender, MessageConsumer. 
	 * <br>
	 * the MessageConsumer would be initialised with a correlation id message selector
	 * <br>
	 * so as to receive only the reply message associated with the to be sent message
	 * <br> 
	 * Furthermore, the connection would be internally started (listening for incomming messages) 
	 * <br>
	 * were this  the first active receiver.
	 * <br>
	 * 3.    Send the message to the 'IN' queue.
	 * <br> 
	 * 4.   Commence a blocking 'Receive' on the 'OUT' queue using the Context's message consumer.
	 * <br> 
	 * with an exiercy time of {@link #MAX_JMS_RECEIVE_BLOCK_INTERVAL}. The receive would be filtering 
	 * <br> 
	 * the queue messages using the sent message's correlation id.
	 * <br> 
	 * 5.   Process the reply message searching for errors and handling them as they are found.
	 * <br>
	 * @param sQueueConnectionFactoryJndiAlias Jndi name mapped to the q-connection factory as defined in the 
	 * <br>
	 * application server 
	 * <br>
	 * @param sDynamicInQueuename Queue name as defined in the queue manager aocciated with the 
	 * <br> 
	 * sQueueConnectionFactoryJndiAlias formal args.
	 * <br>
	 * @param sDynamicOutQueuename Queue name as defined in the queue manager aocciated with the 
	 * <br> 
	 * sQueueConnectionFactoryJndiAlias formal args.
	 * <br> 
	 * @param sXmlMessage Content of the jms message.
	 * @return message as received from the reply queue.
	 * @throws RuntimeException 
	 * <br> 
	 * Exception would be thrown in the following scenarios: 
	 * <br>
	 * 2.   Misc resource exception stemming from unavailable queue managers, networks 
	 * <br> 
	 * or invalid jms resources.
	 * <br> 
	 * 3.   Receive timeout exception, which will occur if the response was not processed  
	 * <br> 
	 * within the {@link BOJMessagingHandler#MAX_JMS_RECEIVE_BLOCK_INTERVAL} interval
	 * <br> 
	 * 4.   BG Processing error generated exception. If the reply message was found to start with 
	 * <br> 
	 * the {@link BOJMessagingHandler#ERROR_MESSAGE_INDICATOR} prefix, an exception would be thrown 
	 * <br> 
	 * containing the error message.
	 * @bo.internalInterface
	 */
	public java.lang.String executeJmsCorrelationPattern(final Admin admin, java.lang.String sConnectionFactoryJndiAlias, java.lang.String[] arrDynamicInDestinationNames, java.lang.String[] arrDynamicOutDestinationNames, boolean bNonJmsProvider, java.lang.String sXmlMessage ) throws javax.jms.JMSException ;

}//EOI  