package backend.jms.businessobjects;

import static backend.businessobject.BOProxies.m_closeOpenNewOutFilesComplete;
import static backend.businessobject.BOProxies.m_fileCancellationLocalComplete;
import static backend.businessobject.BOProxies.m_groupActionsComplete;
import static backend.businessobject.BOProxies.m_debulkingProcessLogging;
import static backend.businessobject.BOProxies.m_internalFileApprovalInterfaceComplete;
import static backend.businessobject.BOProxies.m_nsfComplete;
import static backend.businessobject.BOProxies.m_queueExplorerLogging;
import static backend.businessobject.BOProxies.m_rebulkProcessComplete;
import static backend.businessobject.BOProxies.m_rtrComplete;
import static backend.businessobject.BOProxies.m_subbatchCancellationComplete;
import static backend.businessobject.BOProxies.m_subbatchCompletionLogging;
import static backend.businessobject.BOProxies.m_subbatchGenerationLogging;
import static backend.businessobject.BOProxies.m_debulkFileLogging;
import static backend.businessobject.BOProxies.m_rebulkProcessLogging;
import static backend.businessobject.BOProxies.m_processChunksLogging;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import backend.services.cache.ASCacheFactory;

import com.fundtech.core.security.Admin.CallSource;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.datacomponent.response.SimpleResponseDataComponent;

public class BOJBean extends BOJMessaging
{
    private static Map<String, Object> m_factoryClass = new HashMap<String, Object>();
    private static Map<String, String> m_factoryMethod = new HashMap<String, String>();
    private static Map<String, String> m_factoryCallSource = new HashMap<String, String>();
    
   
    @Override
    public Feedback sendMessage(String sConnectionFactoryJndiAlias, String sDestinationName, 
    		final boolean bNonJmsProvider, Serializable messageBody, String sSessionId)
    {
        Feedback feedback = new Feedback();
        try{
        	
        	if (m_factoryClass.size() == 0)
        	{
        	       m_factoryClass.put("Q_SUBATCH_GEN",m_subbatchGenerationLogging);
        	        m_factoryMethod.put("Q_SUBATCH_GEN","processSubBatchGeneration");
        	        m_factoryClass.put("Q_COMP_SUBATCH_CHUNK",m_subbatchCompletionLogging) ; 
        	        m_factoryMethod.put("Q_COMP_SUBATCH_CHUNK","processSubBatchCompletion");
        	        m_factoryClass.put("Q_CANCEL_SUBATCH_CHUNK",m_subbatchCancellationComplete) ; 
        	        m_factoryMethod.put("Q_CANCEL_SUBATCH_CHUNK","processSubBatchCancellation");
        	        m_factoryClass.put("Q_SUBATCH_RETRY_NSF",m_nsfComplete) ; 
        	        m_factoryMethod.put("Q_SUBATCH_RETRY_NSF","retryNSF");
        	        
        	        m_factoryClass.put("Q_FILE_TO_CLOSE",m_closeOpenNewOutFilesComplete) ; 
        	        m_factoryMethod.put("Q_FILE_TO_CLOSE","processCloseOpenNewOutFiles");
        	        m_factoryClass.put("Q_FILE_TO_CANCEL",m_fileCancellationLocalComplete) ; 
        	        m_factoryMethod.put("Q_FILE_TO_CANCEL","performIncomingFileCancellationProcess");
        	        m_factoryClass.put("Q_FILE_PROC_DIST",m_debulkingProcessLogging) ;         	        
        	        m_factoryMethod.put("Q_FILE_PROC_DIST","performDebulkPreProcessing");
        	        m_factoryCallSource.put("Q_FILE_PROC_DIST", CallSource.Service.name());
        	        m_factoryClass.put("Q_FILE_TO_SEND",m_rebulkProcessComplete) ; 
        	        m_factoryMethod.put("Q_FILE_TO_SEND","processRebulk");
        	        m_factoryClass.put("Q_FILE_FORCE_PROC_DIST",m_debulkFileLogging) ;
        	        m_factoryClass.put("jms/Q_EVENTS",m_groupActionsComplete) ; 
        	        m_factoryMethod.put("jms/Q_EVENTS","performGroupActions");
        	        m_factoryClass.put("Q_FILE_TO_SEND",m_rebulkProcessLogging) ;
        	        m_factoryClass.put("Q_FILE_APPROVAL",m_internalFileApprovalInterfaceComplete) ; 
        	        m_factoryMethod.put("Q_FILE_APPROVAL","processFileApproval");
        	        m_factoryClass.put("Q_FILE_DISTRIBUTED_PROC_DIST",m_processChunksLogging) ;
        	        
        	        m_factoryClass.put("Q_RTR_QUOTE_EVENTS",m_rtrComplete) ; 
        	        m_factoryMethod.put("Q_RTR_QUOTE_EVENTS","getGroupRTRQuote");
        	        
        	        m_factoryClass.put("Q_EXPLORER",m_queueExplorerLogging) ; 
        	        m_factoryMethod.put("Q_EXPLORER","applyChanges");

        	}
        	
            Object o = m_factoryClass.get(sDestinationName);
            if (o != null)
            {
	            o = ASCacheFactory.getThreadPool().submit(o,m_factoryMethod.get(sDestinationName),messageBody, (String)m_factoryCallSource.get(sDestinationName));
	            
	            if (o instanceof Feedback)
	                feedback = (Feedback)o;
	            else if (o instanceof SimpleResponseDataComponent)
	                feedback = ((SimpleResponseDataComponent)o).getFeedback();
            }
        }catch(Exception e)
        {
            feedback = new Feedback();
            feedback.setErrorCode(9999);
            feedback.setFailure();
            feedback.setException(e) ;
        }
        return feedback;
    }

}
