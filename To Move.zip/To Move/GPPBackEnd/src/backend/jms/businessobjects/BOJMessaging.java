package backend.jms.businessobjects;

import java.io.Serializable;
import java.util.Map;
import java.util.Random;

import javax.jms.DeliveryMode;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.businessobject.BOInterface;
import backend.businessobject.proxies.Input;
import backend.jms.JMSPropertiesHelper;
import backend.mapping.config.ASConfigurationFileMapper;
import backend.mapping.config.AppServerConfigKeysInterface;

import com.fundtech.annotations.DataSource;
import com.fundtech.annotations.Expose;
import com.fundtech.annotations.Expose.ExposureType;
import com.fundtech.annotations.Wrap;
import com.fundtech.core.general.JMSMessageObject;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.datacomponent.response.FieldFeedback;
import com.fundtech.datacomponent.response.MultipleFieldFeedback;
import com.fundtech.errors.ProcessErrorConstants;
import com.fundtech.jndi.JmsSessionContext;
import com.fundtech.jndi.ServiceLocator;
import com.fundtech.util.ExceptionController;


/**
 * @author Guy Segev
 * @date Aug 12, 2007
 * copyrights: Fundtech 2007.
 * <br><br> 
 * Singleton Utility class for sending and receiving JMS messages.
 * 
 * @bo.internalInterface
 * 
 * PROXY_TODO: initialising classes should use only logging decoration as there is no need for 
 * authorization and input validation throughout this class!!!!
 */
@Wrap(datasources={@DataSource(datasourceJndiKey="active")}, tx="Bean")

public class BOJMessaging implements BOInterface{

	private final static Logger logger = LoggerFactory.getLogger(BOJMessaging.class);
	
    //trace messages   
    private static final String SEND_MESSAGE_METHOD_SIGNATURE = "JMessagingHandler.sendMessage() " ;
    private static final String SEND_MESSAGE_ERROR_MSG  = SEND_MESSAGE_METHOD_SIGNATURE + " failure with errorMessage: %s.\nMessage content was:%n%s" ;
    private static final String SEND_MESSAGE_SUCCESS_MSG  = SEND_MESSAGE_METHOD_SIGNATURE + " - send success" ;
    private static final String RECEIVE_TIMEOUT_ERROR_MSG = "Message could not be process in a reasonalbe time" ;
        
    /**
     * NYI --> Still awaiting for actual error code value.
     */
    public static final int MSG_BEING_PROCESSED_ERROR_CODE = 123 ; //NYI change to the correct error code
    
    /**
     * Correlation id related constants.
     */
    public static final char[] CORRELATION_ID_PROPER_CHARS = {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F','a','b','c','d','e','f'};
    public static final int CORRELATION_ID_PROPER_CHARS_LENGTH = CORRELATION_ID_PROPER_CHARS.length;
    public static final int CORRELATION_ID_LENGTH = 48;
    
    /**
     * Timeout interval (in millis) used to break the block on receive operation. 
     */
    private static final long MAX_JMS_RECEIVE_BLOCK_INTERVAL = 5000L ;
    
    /**
     * Prefix indicating background processing fault. The existance of this prefix in a message 
     * <br> 
     * would trigger an exception  
     */
    private static final String ERROR_MESSAGE_INDICATOR = "MIF~~##" ;
    
    //private static final DAOBasic DAO ;
    
    private static final int DEFAULT_ACK_MODE = Session.AUTO_ACKNOWLEDGE ; 
                    
    static { 
        //Initialise the JMS jndi config file mappings cache.
        initialiseJmsMappingCache() ;
        //DAO = new DAOBasic() ;
    }//EO static block 
    
    /**
     * @author Guy Segev
     * @date Aug 12, 2007
     * <br><br>
     * Initialises the {@link ServiceLocator}; jms-resources jndi names cache.
     * <br> 
     * The initialisation of the cache is performed from here so that the cache would be lazilly 
     * <br>
     * instantiated. Moreover, the cache would be located in the GPPShare package so as to be 
     * <br> 
     * available to the web-server tier as well, and for that reason, the cache keys
     * <br> 
     * tighly coupled with the app-server tier are passed as formal args.
     * <br>
     */
    private static final void initialiseJmsMappingCache() { 
        ASConfigurationFileMapper asConfig = (ASConfigurationFileMapper) ASConfigurationFileMapper.getInstance(); 
        Map hmConfigJmsJndiResourcesCache = asConfig.getMultipleResourceValue(AppServerConfigKeysInterface.RESOURCES_JMS_RESOURCES_JMS_RESOURCE)  ;
        
        //set the map, queue and queue connection factory keys in the jndiLookupCache
        ServiceLocator.getInstance().initJmsJndiConfigResourcesCache(
            hmConfigJmsJndiResourcesCache 
            ) ;
    }//EOM
    
    /**
     * Private no args constructor.
     */
    public BOJMessaging() {}//EOM
            
    /**
     * @author Guy Segev
     * @date Aug 19, 2007
     * <br><br>
     * Creates a new send Jms session resource encapsulated within a {@link JmsSessionContext}  
     * <br>
     * instance
     * <br> 
     * @param sConnectionFactoryJndiAlias fully qualified connection-factory 
     * <br>
     * jndi name, as defined within the application server.
     * @param arrDestinationNames an array containing a mixture of 
     * <br>
     * jndi names as defined within the application server or the destination name 
     * <br> 
     * as defined within the associated queue manager (termed 'Dynamic destination'). 
     * <br> 
     * the initialisation logic will attempt create the session queue using the 
     * <br>
     * index location as priority (thus, for instance the name in the 0 location 
     * <br> 
     * where all other queue names are held in rerseve, as failover for creation failure scenarios.
     * <br> 
     * @param bIsJmsTransacted true for client controlled commit/rollback facilities 
     * <br> 
     * and false for auto-commit session 
     * @return {@link JmsSessionContext} instance containing the following initialised resources: 
     ** <br> 
     * 1. ConnectionFactory 
     * 2. IsTransacted boolean 
     * 3. Session  
     * 4. MessageProduder
     * <br>
     * @throws Exception if one of the resources creation/lookup had failed
     * 
     * @bo.internalInterface
     */
    @Expose( type = ExposureType.All) 
    public final JmsSessionContext createSendJmsSession(final String sConnectionFactoryJndiAlias, 
            String[] arrDestinationNames, boolean bIsJmsTransacted, final boolean bNonJmsProvider) throws Throwable {
        
        final JmsSessionContext jmsSessionContext  = 
        		JmsSessionContext.newProducerSession(sConnectionFactoryJndiAlias, bIsJmsTransacted, bNonJmsProvider, DEFAULT_ACK_MODE, arrDestinationNames) ; 
        
        return jmsSessionContext ;
    }//EOM
    
    /**
     * @author Guy Segev
     * @date Aug 19, 2007
     * <br><br>
     * Creates a new send Jms session resource encapsulated within a {@link JmsSessionContext}  
     * <br>
     * instance
     * <br> 
     * @param sConnectionFactoryJndiAlias fully qualified connection-factory 
     * <br>
     * jndi name, as defined within the application server.
     * @param sDestinationName jndi name as defined within the application server or the queue name 
     * <br> 
     * as defined within the associated queue manager (termed 'Dynamic Destination') 
     * @param bIsJmsTransacted true for client controlled commit/rollback facilities 
     * <br> 
     * and false for auto-commit session 
     * @return {@link JmsSessionContext} instance containing the following initialised resources: 
     * <br> 
     * 1. ConnectionFactory 
     * 2. IsTransacted boolean 
     * 3. QueueSession  
     * 4. QueueSender 
     * <br>
     * @throws Exception if one of the resources creation/lookup had failed
     * 
     * @bo.internalInterface
     */
    @Expose( type = ExposureType.All)
    public final JmsSessionContext createSendJmsSession(String sConnectionFactoryJndiAlias, 
            String sDestinationName, boolean bIsJmsTransacted, final boolean bNonJmsProvider) throws Throwable{
        
       final JmsSessionContext jmsSessionContext = 
        	JmsSessionContext.newProducerSession(sConnectionFactoryJndiAlias, bIsJmsTransacted, bNonJmsProvider, DEFAULT_ACK_MODE, sDestinationName) ;
        
        return jmsSessionContext ;
    }//EOM
            
    /** 
     * @author Guy Segev
     * @date Aug 6, 2007
     * <br><br>
     * Sends a new Jms Object message whose content would be the messageBody formal arg,  
     * <br>
     * using the Jms Session context resources contained in the {@link JmsSessionContext} formal arg. 
     * <br>
     * @param bShouldReleaseResources if true and the session was marked as transacted, would commit the 
     * <br> 
     * session before disposing of it if all was successfull or rollback if otherwise. 
     * <br> 
     * on both cases, the {@link JmsSessionContext} resources would be disposed of at the method's end.
     * <br>   
     * @param jmsSessionContext must not be null, and contains the {@link QueueSender} and {@link QueueSession} 
     * <br> 
     * instances as well as the bIsTransacted flag to be used for the message sending operation.  
     * @param messageBody message content to send 
     * @param sSessionId user session identifier.
     * @param messageProperties map with properties which should assign to the outgoing message. 
	 * 		  Standard JMS properties (JMSMessageID,JMSReplyTo..) would be assign using the standard set method
	 *  	  User define properties would we assign using Message.setObjectProperty
     * @throws Exception If an error had occured during the send operation, the method would 
     * <br>
     * check the bShouldReleaseResources and jmsSessionContext.isTransacted() flags and if both are true 
     * <br> 
     * would rollback the session prior to disposing of the resources.
     */
    @Expose
    public void sendMessage(boolean bShouldReleaseResources, @Input(skip=true)JmsSessionContext jmsSessionContext, 
            Serializable messageBody, String sSessionId,Map<String,Object> messageProperties) throws Exception{ 
         
    	boolean shouldCommit = true;
        try{            
            // Sends the message using an ObjectMessage !!!
            // Creating an ObjectMessage for which we need the 'Serializable' parameter;
            // This code is not required as long as we create and send a TextMessage
            // which requiresonly a string, (see ahead).
//            ObjectMessage message = jmsSessionContext.getQueueSession().createObjectMessage() ; 
//            message.setObject(messageBody) ;
//            jmsSessionContext.getQueueSender().send(messageBody) ;
            
            // Sends the message using a TextMessage !!!
            // Assumes that the 'Serializable' parameter is actually a string object.
            TextMessage message = jmsSessionContext.getSession().createTextMessage() ;
            message.setJMSTimestamp(System.currentTimeMillis());
            message.setText((String)messageBody) ;
            JMSPropertiesHelper.setMessageProperties(message,messageProperties);
            //jmsSessionContext.getProducer().setDisableMessageID(false);
            jmsSessionContext.getProducer().send(message) ;
            
            
			Admin admin = Admin.getContextAdmin();
			@SuppressWarnings("static-access")
			PDO pdo=admin.getContextPDO();
			String sMessageID = message.getJMSMessageID();
//			logger.debug("JMS Message ID = {}",sMessageID);
//			sMessageID= sMessageID; //JMSPropertiesHelper.getMessageIDAsString(sMessageID);
            if (null!=sMessageID)
            {
                logger.debug("JMS Message ID as string = {}",sMessageID);
                if (null!=pdo)
                {
                    //pdo.set(P_RELEASE_INDEX,sMessageID); // Store the MQ message id into the RELEASE_INDEX field so we can match it on the response.
                }
            }
            
            //if the bShouldReleaseResources is true and the session is transacted than commit 
            if(bShouldReleaseResources && jmsSessionContext.isTransacted()) jmsSessionContext.getSession().commit() ;
            
            logger.info(SEND_MESSAGE_SUCCESS_MSG) ; 
        }catch(Exception e) { 
           ExceptionController.getInstance().handleException(e, this) ;
           
           logger.info(SEND_MESSAGE_ERROR_MSG, e.getMessage(), messageBody) ; 
           
           //if the bShouldReleaseResources is true and the session is transacted than rollback 
           if(bShouldReleaseResources && jmsSessionContext.isTransacted()) jmsSessionContext.getSession().rollback() ;
           shouldCommit = false;
           throw e ;
        }finally { 
             if(bShouldReleaseResources) jmsSessionContext.dispose(!shouldCommit) ;
        }//EO catch block 
        
    }//EOM
        

	/**
     * @author Guy Segev
     * @date Aug 12, 2007
     * <br><br>
     * Sends a new Jms Object message whose content would be the messageBody formal arg.  
     * <br>
     * creates a {@link JmsSessionContext} instance internallly, marking the created session as auto-commit one. 
     * <br>
     * Once the session was created, invokes the {@link #sendMessage(boolean, JmsSessionContext, Serializable, String)}, 
     * <br>
     * marking the bShouldDisopseOfResources as true as the session was created internally.
     * <br>
     * @param sConnectionFactoryJndiAlias Fully qualified jndi ConnectionFactory name defined 
     * <br> 
     * within the application server as a resource.
     * <br>
     * Internally invokes the {@link ServiceLocator#cacheJmsEntity(String, Object)} and 
     * <br>
     * {@link ServiceLocator#createJmsSessionContext(String, boolean)} See for more details.
     * <br>
     * <b>Note:</b> If an error had occured in the instantiaion process, all initialised resource 
     * <br> 
     * would be disposed of prior to throwing a JMSException to the client code indicating the failure.
     * <br>
     * @param sDestinationName destination name values could either be jndi aliases or destination names as defined within the queuemanager's context.
     * @param messageBody content to embed in the message.
     * @param sSessionId user session identifier.
     * @return {@link Feedback} indicating the operation's result.
     */
    @Expose
    public Feedback sendMessage(String sConnectionFactoryJndiAlias, String sDestinationName, final boolean bNonJmsProvider, Serializable messageBody, String sSessionId) { 
        
        Feedback feedback = new Feedback() ;
        
        JmsSessionContext context = null ;
        boolean bCommit = true ; 
        try{ 
        	context = JmsSessionContext.newProducerSession(sConnectionFactoryJndiAlias, false/*nonTransacted*/, bNonJmsProvider, DEFAULT_ACK_MODE, sDestinationName) ;  
   
            //send the message, true = release resources
            this.sendMessage(true, context, messageBody, sSessionId,null) ; 
            
        }catch(Throwable e) { 
           /* feedback.setException(e) ; 
            feedback.setErrorText(e.getMessage()) ;
            feedback.setFailure() ;
            feedback.setErrorCode(ProcessErrorConstants.GenericJmsFailure) ;*/ 
            bCommit = false ; 
            if(e instanceof RuntimeException) throw (RuntimeException) e ; 
            else throw new RuntimeException(e) ;
        }finally{ 
        	
        	try{ 
        		if(context != null) context.dispose(!bCommit) ;
        	}catch(JMSException jmse) { 
        		throw new RuntimeException(jmse) ;
        	}//EO catch block
        }//EO catch block 
        
        return feedback ;
    }//EOM
    
    /**
     * @author Guy Segev
     * @date Aug 12, 2007
     * <br><br>
     * Sends a message to the queue using the queue-connection-factory whose jndi names are associated with the 
     * <br>
     * sJmsConfigurationElementId key (as defined in the app-server-config.xml file). 
     * <br>
     * Internally creates a {@link JmsSessionContext} instance, flagging the session as auto-commit, 
     * <br> 
     * and the disposeResources as true so taht the internal call to {@link #sendMessage(String, String, Serializable, String)} 
     * <br> 
     * would disposed of the session context at the end of its flow.
     * <br> 
     * @see {@link #sendMessage(String, String, Serializable, String)} for more details.
     * <br> 
     * @param sJmsConfigurationElementId the Id of the app-server-config.xml-->jms-resource whose queue-connection-factory
     * <br> 
     * and queue jndi names are to be fetched from the incremented cache in the {@link ServiceLocator} 
     * @param messageBody Message content. 
     * @param sSessionId user's session identification 
     * @return {@link Feedback} containing the results of the method's operation. 
     */
    @Expose
    public Feedback sendMessage(String sJmsConfigurationElementId, final boolean bNonJmsProvider, 
                                Serializable messageBody, String sSessionId) { 
       
        //fetch the configuration element jndi details from the cache  
        String[][] mtrxDestinationJndiAliass = 
            ServiceLocator.getInstance().getConfigJmsQueueJndiAliases(sJmsConfigurationElementId) ;
            
        String sDestinationJndiAlias = mtrxDestinationJndiAliass[0][0] ;
       
        String sConnectionFactoryJndiAlias = 
            ServiceLocator.getInstance().getConfigJmsConnectionFactoryJndiAlias(sJmsConfigurationElementId) ;
        
        Feedback feedback = this.sendMessage(sConnectionFactoryJndiAlias, sDestinationJndiAlias, bNonJmsProvider, messageBody, sSessionId) ; 

        return feedback ;
    }//EOM
    
    /**
     * @author Guy Segev
     * @date Aug 12, 2007
     * <br><br>
     * Sends one or more messages whose details are contained within the {@link JMSMessageObject} objects to a single 
     * <br> 
     * queue. 
     * <br> 
     * The method will initialise a single jms session context for all the messaeges and will flag it as auto commit. 
     * <br> 
     * Each error occuring in the process of sending the message would cause the whole operation to invalidate the whole 
     * <br> 
     * flow if the bShouldIgnoreIndividualFailures is set to true
     * <br>
     * The sendMessage() would set the bShouldReleaseResources to false as those would be used throughout the bulk process. 
     * <br>
     * The method would always dispose of the jmsSessionContext.
     * <br> 
     * @param sQueueConnectionFactoryJndiAlias Fully qualified jndi queueConnectionFactory name defined 
     * <br> 
     * within the application server as a resource.
     * @param sQueueName Queue name values could either be jndi aliases or queue names as defined within the queuemanager's context.
     * @param arrJMSMessageObjects  {@link JMSMessageObject})[] containing the individual message details.
     * @param bShouldIgnoreIndividualFailures if true would continue the bulk operation dispite an error in one or more 
     * <br>
     * message sending operations. If False would terminate the bulk operation on the first error. 
     * @param sSessionId user session identifier.
     * @return {@link MultipleFieldFeedback} instance containing only the failure details if any.
     */
    @Expose
    public MultipleFieldFeedback sendMessages(String sQueueConnectionFactoryJndiAlias,
                    String sQueueName, JMSMessageObject[] arrJMSMessageObjects,
                    boolean bShouldIgnoreIndividualFailures,
                    final boolean bNonJmsProvider, 
                    String sSessionId)  {
        
        int iLength = arrJMSMessageObjects.length ; 
        JMSMessageObject messageInfo = null ;
        MultipleFieldFeedback multipFieldFeedback = new MultipleFieldFeedback() ;
        FieldFeedback fieldFeedback = null ;
        JmsSessionContext jmsSessionContext = null ; 
        boolean shouldCommit = true;
        //first create a session to be used for all batch messages 
        //Transacted ==> false (i.e auto-commit)
        try{ 
            jmsSessionContext = this.createSendJmsSession(sQueueConnectionFactoryJndiAlias, sQueueName, false, bNonJmsProvider) ;
       
            //if the session was properly created, commence the batch send procedure
            for(int i=0; i < iLength; i++) { 
                messageInfo = arrJMSMessageObjects[i] ;
             
                try{ 
                    //send the message 
                    //false ==> do not dispose of the jms session context 
                    this.sendMessage(false, jmsSessionContext, messageInfo.getMessage(), sSessionId,null) ;

                }catch(Exception e) { 
                    //if the bShouldIgnoreIndividualFailures is true, mark the error and continue ; 
                    fieldFeedback = new FieldFeedback(MSG_BEING_PROCESSED_ERROR_CODE) ;
                    fieldFeedback.setErrorText(e.getMessage()) ;
                    fieldFeedback.addName(messageInfo.getKey()) ;
                    multipFieldFeedback.addFeedback(fieldFeedback) ;
                    fieldFeedback.setErrorCode(ProcessErrorConstants.GenericJmsFailure) ; 
                    
                    //if one exception disqualifies all other operations, throw an 
                    //exception to exist the loop and configure an error feedback
                    if(!bShouldIgnoreIndividualFailures) throw e ; 
                }//EO inner catch block
            }//EO while there are more messages to send 
            
            //no need for commit as the session was flagged as auto commit 
        }catch(Throwable e) { 
            //if the bShouldIgnoreIndividualFailures is true, mark the error and continue ; 
            fieldFeedback = new FieldFeedback(MSG_BEING_PROCESSED_ERROR_CODE) ;
            fieldFeedback.setErrorText(e.getMessage()) ;
            fieldFeedback.addName(messageInfo.getKey()) ;
            fieldFeedback.setErrorCode(ProcessErrorConstants.GenericJmsFailure) ; 
            multipFieldFeedback.addFeedback(fieldFeedback) ;
            shouldCommit = false;
            //no need for rollback as the session was flagged as auto commit 
        }finally{ 
            //dispose of the session context 
            if(jmsSessionContext != null)
            {
            	try
	            {
	            	jmsSessionContext.dispose(!shouldCommit) ;
	            }catch(Exception e)
	            {
	            	ExceptionController.getInstance().handleException(e, this);
	            }
            }
        }//EO catch block
        
        return multipFieldFeedback ;
    }//EOM  
        
    /**
     * @author Guy Segev
     * @date Aug 19, 2007
     * <br><br>
     * Performs the following tasks: 
     * <br> 
     * 1.   Generates a new unique correlation id.
     * <br>
     * 2.   Initialises a new JmsSessionContext containing the following Resources: 
     * <br>
     * JmsQueueConnectionFactory, JmsQueue, JmsSession, QueueSender, MessageConsumer. 
     * <br>
     * the MessageConsumer would be initialised with a correlation id message selector
     * <br>
     * so as to receive only the reply message associated with the to be sent message
     * <br> 
     * Furthermore, the connection would be internally started (listening for incomming messages) 
     * <br>
     * were this  the first active receiver.
     * <br>
     * 3.    Send the message to the 'IN' queue.
     * <br> 
     * 4.   Commence a blocking 'Receive' on the 'OUT' queue using the Context's message consumer.
     * <br> 
     * with an exiercy time of {@link #MAX_JMS_RECEIVE_BLOCK_INTERVAL}. The receive would be filtering 
     * <br> 
     * the queue messages using the sent message's correlation id.
     * <br> 
     * 5.   Process the reply message searching for errors and handling them as they are found.
     * <br>
     * @param sQueueConnectionFactoryJndiAlias Jndi name mapped to the q-connection factory as defined in the 
     * <br>
     * application server 
     * <br>
     * @param sDynamicInQueuename Queue name as defined in the queue manager aocciated with the 
     * <br> 
     * sQueueConnectionFactoryJndiAlias formal args.
     * <br>
     * @param sDynamicOutQueuename Queue name as defined in the queue manager aocciated with the 
     * <br> 
     * sQueueConnectionFactoryJndiAlias formal args.
     * <br> 
     * @param sXmlMessage Content of the jms message.
     * @return message as received from the reply queue.
     * @throws RuntimeException 
     * <br> 
     * Exception would be thrown in the following scenarios: 
     * <br>
     * 2.   Misc resource exception stemming from unavailable queue managers, networks 
     * <br> 
     *      or invalid jms resources.
     * <br> 
     * 3.   Receive timeout exception, which will occur if the response was not processed  
     * <br> 
     * within the {@link BOJMessagingHandler#MAX_JMS_RECEIVE_BLOCK_INTERVAL} interval
     * <br> 
     * 4.   BG Processing error generated exception. If the reply message was found to start with 
     * <br> 
     * the {@link BOJMessagingHandler#ERROR_MESSAGE_INDICATOR} prefix, an exception would be thrown 
     * <br> 
     * containing the error message.
     * 
     * @bo.internalInterface
     */
    @Expose ( type = ExposureType.InternalInterface) 
    public String executeJmsCorrelationPattern(String sConnectionFactoryJndiAlias, 
            String[] arrDynamicInDestinationNames, String[] arrDynamicOutDestinationNames, 
            final boolean bNonJmsProvider, String sXmlMessage) throws JMSException { 
       
       // BackendTracer tracer = GlobalTracer ; 
       
        boolean bIsTransacted = false ; 
        
        JmsSessionContext jmsSessionContext = null ;
        TextMessage message = null ;
                
        try{ 
            //Create the automatic correlation id
            final String CORRELATION_ID_TRACE = "Just created correlation id: " ; 
            
            String  sCorrelationId = this.generateCorrelationId() ;
            
            logger.info(CORRELATION_ID_TRACE + sCorrelationId) ;
            
            //Initialise a new JmsSessionContext instance.
            final String NEW_JMS_CONTEXT_TRACE = "Initialise a new JmsSessionContext instance." ; 
            logger.info(NEW_JMS_CONTEXT_TRACE) ;
            
            //This will create the following jms resoruces: 
            //JmsQueueConnectionFactory, JmsQueue, JmsSession, QueueSender, MessageConsumer
            //the MessageConsumer would be initialised with a correlation id message selector 
            //so as to receive only the reply message associated with the to be sent message 
            //Furthermore, the connection would be internally started (listening for incomming messages) 
            //were this  the first active receiver 
            jmsSessionContext = JmsSessionContext.newDualChannelSession(sConnectionFactoryJndiAlias, 
            		bIsTransacted, bNonJmsProvider, DEFAULT_ACK_MODE, 
                    arrDynamicInDestinationNames, arrDynamicOutDestinationNames, sCorrelationId) ;
            
            //Create a message and set its correlation id  
            final String CREATE_JMS_MESSAGE_TRACE = "Create a message and set its correlation id" ; 
            logger.info(CREATE_JMS_MESSAGE_TRACE) ;

            message = jmsSessionContext.getSession().createTextMessage() ;
            message.setJMSMessageID(sCorrelationId) ;
            message.setJMSCorrelationID(sCorrelationId) ;
            message.setJMSTimestamp(System.currentTimeMillis());
            message.setText(sXmlMessage) ;
            
            //Send the message and start the receiver on the reply queue.
            final String SEND_JMS_MESSAGE_TRACE = "end the message and start the receiver on the reply queue." ; 
            logger.info(SEND_JMS_MESSAGE_TRACE) ;
            
            jmsSessionContext.getProducer().send(message, DeliveryMode.NON_PERSISTENT, Message.DEFAULT_PRIORITY, MAX_JMS_RECEIVE_BLOCK_INTERVAL) ;
            
            //as the connection should automically be configured to receive incomming msgs 
            //there is no need to start it. 
            final String RECEIVE_JMS_MESSAGE_TRACE = "Commencing receive block on the message correlated to the one just sent." ; 
            logger.info(RECEIVE_JMS_MESSAGE_TRACE) ;
            
            int iCounter = 0 ; 
            message = null ;
            while(message == null) { 
            
            	message = (TextMessage) jmsSessionContext.getConsumer().receiveNoWait() ; 
            	
            	if(++iCounter == 10000) break ;  
            }//EO while the message had not arrived to the sender's reply queue 
            final String AFTER_RECEIVE_JMS_MESSAGE_BLOCK_TRACE = 
                "Just released from receive message block. Revceived message is:\n" ;  
            logger.info(AFTER_RECEIVE_JMS_MESSAGE_BLOCK_TRACE + message) ;
            
            //check the request for the following errors: 
            //null --> i.e. time out 
            //message containing the MAX_JMS_RECEIVE_BLOCK_INTERVAL --> i.e BG error 
            if(message ==  null) throw new RuntimeException(RECEIVE_TIMEOUT_ERROR_MSG) ;
            
            if(message.toString().
                    startsWith(ERROR_MESSAGE_INDICATOR)) throw new RuntimeException(message.toString()) ; 

            //else return the message
            return message.getText() ;
        }catch(RuntimeException rte) { 
            //just redicrect the exception
            throw rte ;
        }catch(Throwable e) {             
            throw new RuntimeException(e.getMessage()) ;
        }finally{ 
            //Dispose of the session. 
            //Will not perform the commit or rollback as the session was not transacted
            final String SESSION_DISPOSAL_TRACE = 
                "Dispose of the session.\nWill not perform the commit or rollback as the session was not transacted." ;  
            logger.info(SESSION_DISPOSAL_TRACE + message) ;
            
            jmsSessionContext.closeSession(false) ;
        }//EO catch block
        
    }//EOM
    
    /**
     * Generates a unique correlation ID.
     */
    public static final String generateCorrelationId(boolean bShouldAppendPrefix, int iMaxChar){
    	
    	 
    	
    	 final int MAX_INT_VALUE = 2147483647;
    	 final String CORRELATION_PREFIX = "ID:"  ; 
    	 StringBuffer sbSessionID = new StringBuffer() ; 
    	 
    	 long lSeed = System.currentTimeMillis() ; 
    	 Random random = new Random(lSeed);
    	
        for(int i=0; i<iMaxChar; i++){
          // The following 3 lines are the equivalent to the following C++ line in 
          // 'pay_dbfuncs.GenerateSessionID' method: "j = (int) Nn * rand() / (RAND_MAX + 1.0);"
          //
          int iNextInt = random.nextInt(MAX_INT_VALUE);
          float f =  ((float)iNextInt / (MAX_INT_VALUE + 1));
          int iCurrIndex = (int) (CORRELATION_ID_PROPER_CHARS_LENGTH * f);
          iCurrIndex = Math.abs(iCurrIndex);
          
          // Appends to the StringBuffer the char from the created index.
          sbSessionID.append(CORRELATION_ID_PROPER_CHARS[iCurrIndex]);
        }//EO while there are more chars required 
                
         
        
        return (bShouldAppendPrefix ? CORRELATION_PREFIX + sbSessionID.toString().toLowerCase() : sbSessionID.toString().toLowerCase()) ;
    } 
    
    public static final String generateCorrelationId(){
//    	return generateCorrelationId(true, CORRELATION_ID_LENGTH) ;
    	return generateCorrelationId(false, CORRELATION_ID_LENGTH) ;
    }//EOM
    
    
    private String hexToString(String sHexValue) { 
    	byte[] bytes = new byte[sHexValue.length() / 2];
    	for (int i = 0; i < bytes.length; i++) {
    		bytes[i] = (byte) Integer.parseInt(sHexValue.substring(2 * i, 2 * i + 2),16);
    	}

		String multi = new String(bytes);
		return multi ; 
    }//EOM 
    
    @Override
	public void businessObjectActivate() {}
    
    @Override
	public void businessObjectPassivate() {}
    
    @Override
	public void businessObjectRemove() {}
    
} 
