package backend.jms.spring.mdp.containers ; 

import static com.fundtech.util.GlobalUtils.collect;

import java.lang.reflect.Field;
import java.util.Iterator;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import javax.jms.Connection;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.Session;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.codehaus.xfire.XFire;
import org.codehaus.xfire.service.Binding;
import org.codehaus.xfire.service.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.support.GenericApplicationContext;
import org.springframework.jms.connection.ConnectionFactoryUtils;
import org.springframework.jms.listener.AbstractJmsListeningContainer;
import org.springframework.jms.listener.AbstractPollingMessageListenerContainer;
import org.springframework.jms.listener.SessionAwareMessageListener;
import org.springframework.jms.support.JmsUtils;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.springframework.transaction.support.TransactionSynchronization;

import backend.businessobject.tx.LastResourcesManager;
import backend.businessobject.tx.SpringTransactionProxy;
import backend.jms.spring.mdp.listeners.FndtMessageListenerAdapter;
import backend.paymentprocess.erroraudit.ErrorAuditUtils;

import com.fundtech.cache.entities.InterfaceTypes;
import com.fundtech.cache.infrastructure.regions.CacheKeys.ProcessSessionsKey;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.core.paymentprocess.errorhandling.ProcessError;
import com.fundtech.core.security.Admin;
import com.fundtech.core.security.Admin.CallSource;
import com.fundtech.errors.ProcessErrorConstants;
import com.fundtech.errors.RuntimeAggregatedException;
import com.fundtech.jndi.ServiceLocator;
import com.fundtech.util.ExceptionController;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalUtils;
import com.fundtech.util.Monitors;
import com.fundtech.webservices.infra.xfire.client.WSClientFactory.SoapBindingType;
import com.fundtech.webservices.infra.xfire.client.WSClientFactory.WebserviceBindingType;


public class LenientDefaultMessageListenerContainer extends org.springframework.jms.listener.DefaultMessageListenerContainer implements ApplicationContextAware{
	
	private final static Logger logger = LoggerFactory.getLogger(LenientDefaultMessageListenerContainer.class);
	
	private ApplicationContext m_appContext ; 
	private String m_sAssociatedServiceName ; 
	private boolean m_bInitialized ;  
	private int m_iBatchSize ; 
	private final static ThreadLocal<Long> m_tlAsyncInvokerReceiveTimeout = new ThreadLocal<Long>() ; 
	private long m_lReceiveTimeout ; 
	private DefaultTransactionDefinition transactionDefinition  ; 
	private CallSource m_enumContextCallSource ; 
	private Destination m_destination ; 
	private boolean m_bTxSupport ; 
	
	/**
	 * 'transactionContextPayments' is a thread lock with the list of all PDOs which where the context
	 * on all of the 'Admin' objects participating on the ongoing JTA transaction.
	 * 
	 * And in simple words:
	 * 1. Within a single JTA transaction, and based on the 'batchSize', 
	 * 	  multiple JMS messages might be consumed.
	 * 2. For each consumed message there is dedicated 'Admin' object
	 *    (see 'doInvokeListener'). This Admin object is cleanup after processing
	 *    the consumed message.
	 * 3. Each 'Admin' object maintain context PDOs: one PDO under 'Admin.m_contextPDO'
	 * 	  and multiple PDOs under 'Admin.m_mapSessionData' map thru 'Admin.CONTEXT_PDO_LIST' key. 
	 * 4. 'LenientDefaultMessageListenerContainer.contextPayments' is the set of all above payments.
	 * 
	 * 
	 * This context is required for the benefit of rollback: 
	 * 1. GPPSP propagates payments to the distribute cache immediately after success 
	 *    'DAS.batchSave' and regardless with a truly success commit.
	 *    GPPSP is still sensitive to failures which happens after propagation to
	 *    distributed cache as long as they occurred within BOBasic executeInProtectedBounderies.
	 * 2. Distributed cache compensation is implemented thru 'PaymentDataFactory.performFailureCompensation'
	 * 	  which cleanup the distributed caches (payment, dupex, ..).    
	 * 3. When consuming JMS message (LenientDefaultMessageListenerContainer), the transaction commit
	 * 	  is not happens within BOBasic executeInProtectedBounderies and hence rollback must be
	 * 	  applied on LenientDefaultMessageListenerContainer level.
	 */
	public static final transient ThreadLocal<Set<PDO>> jtaTransactionContextPayments = new ThreadLocal<Set<PDO>>() ; 
	
	public LenientDefaultMessageListenerContainer() {
		//initialize batchsize to 1 
		this.m_iBatchSize = 1 ; 
	}//EOM 
	
	@Override
	protected void doInvokeListener(SessionAwareMessageListener listener, Session session, Message message)
			throws JMSException {
		Admin admin = setAdmin(listener.toString());
			
		//register the last resources Manager with spring transaction synchronization manager 
		/*final SynchronizingLastResourcesManager lastResourcesManager = new SynchronizingLastResourcesManager() ;
		TransactionSynchronizationManager.registerSynchronization(lastResourcesManager) ;
		//register the last resources manager with the admin as well 
		admin.registerLastResourcesHandler(lastResourcesManager) ;*/
		
		//register the last resources manager with the admin as well 
		//Note: at this stage the tx should have already been opened and the closure handled by the invoking method 
		//admin.registerLastResourcesHandler(SpringTransactionProxy.m_txWrapper.get("[LenientDefaultMessageListenerContainer.doInvokeListener]", this.transactionDefinition)) ;

		try{ 
			super.doInvokeListener(listener, session, message);
		}finally{ 
			//remove the instance if 
			//SpringTransactionProxy.m_txWrapper.remove("[LenientDefaultMessageListenerContainer.doInvokeListener]", true/*bCommit*/) ;
			accumulateContextPayment(admin);
			
			clearAdmin(admin);
		}// EO catch block
	}// EOM
	
	private Admin setAdmin(String contextId) {
		final Admin admin = CallSource.Service.newAdmin(contextId + "_" + this.m_sAssociatedServiceName);
		admin.putSessionData(ProcessSessionsKey.KEY_SAME_PROCSS_SESSION_PROPAGATOR_JVM, GlobalConstants.BOOL_TRUE);
		admin.putSessionData(Admin.CONTEXT_KEEP_ADMIN_RESOURCES, GlobalConstants.BOOL_TRUE);
		admin.putSessionData(Admin.CONTEXT_IGNORE_ERROR_LOG_ON_EXCEPTION, GlobalConstants.BOOL_TRUE);
		Admin.setContextAdmin(admin);
		return admin;
	}
	
	private void clearAdmin(Admin admin) {
		//remove the CONTEXT_KEEP_ADMIN_RESOURCES session property and clear the admin context
		admin.getSessionData(Admin.CONTEXT_KEEP_ADMIN_RESOURCES, true/*bRemove*/) ;
 		
		//first check the override flag set in the admin and if set to false, abort
		//as there are nested invocations of this method 
		if(admin != null && !Admin.cleanupContext(admin)) {
			//System.err.println("admin.cleanupContext() was set to true, aborting cleanup") ; 
			return  ; 
		}//EO if the keep resources was set in the admin 
		
		//if the bShouldCleanAdminContext is true remove the admin instance from the thread local 		
		else Admin.contextCleanup() ; 
	}
	
	@Override
	protected void handleListenerException(Throwable ex) {
		try{ 
			super.handleListenerException(ex);
		}finally{ 
			ExceptionController.getInstance().handleException(ex, this, String.format("[MDP for Service: %s]: Listener Failure: ", this.m_sAssociatedServiceName)) ; 
		}//EO catch block 
	}//EOM 
	
	@Override
	protected final void handleListenerSetupFailure(Throwable ex, boolean alreadyRecovered) {
		if(this.m_bInitialized && !Admin.appDisposed()) { 
			this.handleListenerException(ex) ;
		}//EO if had run at least once 
		else { 
			if(Admin.appDisposed()) 
				logger.warn("JMS container (MDP) '{}' has detected that the application was shutdown. Disposing...", getBeanName() ) ;
			
			try { 
				this.destroy(ex)  ; 
			} catch(Exception e) { 
				logger.warn(getBeanName()+" handleListenerSetupFailure:",e);				
			}//EO catch block 
		}//EO else if not yet initialized 
	}//EOM 
	
	@Override
	protected final boolean receiveAndExecute(final Object invoker, Session session, MessageConsumer consumer) throws JMSException {
		if(Admin.appDisposed()) { 
				logger.warn("JMS container (MDP) '{}' has detected that the application was shutdown. Disposing...", getBeanName() ) ;
			this.stop() ; 
				return false ; 
		}else {
			int iReceivedMessagesCounter = 0 ; 
			RuntimeAggregatedException raisedException = null ; 
			
			Connection conn = null ;  
			boolean bJmsResourcesInitializedLocally = false ;  
			
			//if(!this.isBatchMode()) return super.receiveAndExecute(invoker, session, consumer);
			//else { 
				TransactionStatus txStatus = null ;
				SpringTransactionProxy txProxy = null ; 
				final String sTxOriginator = "[LenientDefaultMessageListenerContainer.receiveAndExecute."+getBeanName()+"]"  ;
				
				try{
					//if the transaction manager is defined, encapsulate the batch in a transaction 
					if(this.m_bTxSupport) { 						
						//txProxy = SpringTransactionProxy.m_txWrapper.get(sTxOriginator, this.transactionDefinition) ;
						txProxy = SpringTransactionProxy.m_txWrapper.getEnsureNew(sTxOriginator) ;
						logger.trace("transaction is {}",txProxy.hashCode());
						txStatus = txProxy.getTxStatus() ; 
					}//EO if the transaction manager was defined 
					
					//if the session was not yet initialized - initialize the resources 
					if(bJmsResourcesInitializedLocally  = (session == null)) { 
						logger.trace("initializing JMS resources...");
						conn = this.createConnection() ; 
						conn.start() ; 
						session = this.createSession(conn) ; 
						consumer = this.createListenerConsumer(session);
						logger.trace("JMS resources initialized");
					}//EO if the jms resources were not yet initialized 
					
					//first invoke a single receive if there was no message was received abort  
					if(!this.doReceiveAndExecute(invoker, session, consumer, txStatus))  {
						logger.trace("Single receive was performed, no messages were received");
						return false ;   
					}
					//else if there was a message, iterate over the batch size 
					//attempt to retrieve the current receive timeout 
											
					//set the timeout to 100 so there would be no wait for the subsequent 
					//receive as there might be retrieved messages in the tx already and timeout might occur 
					logger.trace("Iterating over messages, batch size is {}", this.m_iBatchSize);
					m_tlAsyncInvokerReceiveTimeout.set(100L) ;
					 
					//iterate as many items as defined in the batch size var  (-1 for the first receieve) and invoke the receive and execute for each
					for(iReceivedMessagesCounter = 1; iReceivedMessagesCounter < this.m_iBatchSize; iReceivedMessagesCounter++) {
						//if no message was received 
						if(!this.doReceiveAndExecute(invoker, session, consumer, txStatus)){
							break ;  								
						}//EO else if there was no message receive 
						
						//FOR DEBUG 
						//if(iReceivedMessagesCounter == 50) throw new RuntimeException("THIS IS THE DEBUG EXCEPTION") ;
						//FOR DEBUG END 
						
					}//EO while there are more iterations
				
					//remove received timeout override for subsequent invocations   
					this.m_tlAsyncInvokerReceiveTimeout.remove()  ;
					logger.trace("Iterating over messages is done");					
				}catch(Throwable t) { 
					ErrorAuditUtils.setError(ProcessErrorConstants.ReadFromMQFailure, null, null, new Object[]{this.getDestinationName()}); // defect 26713
					raisedException = new RuntimeAggregatedException(t) ;  
					logger.debug("Exception occured during receiveAndExecute, error message:{}\n\nstacktrace:\n{}", t.getMessage(), ExceptionUtils.getStackTrace(t));
				}finally{
					try{ 
						//release the jms resources if initialized here locally 
						if(bJmsResourcesInitializedLocally) { 
							logger.trace("Releasing locally initialized resources");
							JmsUtils.closeMessageConsumer(consumer);
							JmsUtils.closeSession(session);
							ConnectionFactoryUtils.releaseConnection(conn, getConnectionFactory(), true);
						}//EO if bJmsResourcesInitializedLocally == true 
					}catch(Throwable t) { 
						if(raisedException == null)
						{
							raisedException  = new RuntimeAggregatedException(t);
						}
						else {	
							raisedException.addException(t);
							}
						logger.debug("Exception occured during releasing resource, error message:{}\n\nstacktrace:\n{}", t.getMessage(), ExceptionUtils.getStackTrace(t));
					}//EO inner catch block 
					
					//if the batch was encapsulated by a transaction 
					//commit or roll it bacth depending on the existence of an exception  
					if(txProxy != null) { 
						//ThreadBoundCounterUTXWProxy.releaseTxResources() ; 
						
						/*if(raisedException != null) this.rollbackOnException(txStatus, raisedException) ; 
						else this.getTransactionManager().commit(txStatus);*/
					
						long startTime = System.currentTimeMillis();
						try{ 
							//SpringTransactionProxy.m_txWrapper.remove(sTxOriginator, (raisedException == null)) ;
							//work around, make sure the transaction ended regardless the SpringTransactionProxy ThreadLocal 
							logger.trace("Ending transaction");
							SpringTransactionProxy.endTransaction(txProxy, (raisedException == null),true) ;
						}catch(Throwable t) { 
							if(raisedException == null) 
								{
									raisedException  = new RuntimeAggregatedException(t);  
								}
							else {
								raisedException.addException(t); 
							}
							logger.debug("Exception occured while ending transaction, error message:{}\n\nstacktrace:\n{}", t.getMessage(), ExceptionUtils.getStackTrace(t));
						} finally {	
							logger.debug("Ending transaction");
							Monitors.JMS.txEnd(getBeanName().replace("_MDP", ""),iReceivedMessagesCounter,raisedException,System.currentTimeMillis()-startTime); 
						 }
						
					} else {
						logger.debug("avoiding ending transaction within 'LenientDefaultMessageListenerContainer' scope");
						Monitors.JMS.error("avoiding ending transaction within 'LenientDefaultMessageListenerContainer' scope");
					}
					
					try {
						//if there was an exception propegate it 
						if(raisedException != null) { 
							Admin.setRollbackExceptionHolder(raisedException);
							Admin.setRollbackPDOHolder(Admin.getContextPDO());
							
							try {
								logger.info("{}, due to failure ({}), perform compensation over the payments in the context"
										,getBeanName(),raisedException.getClass().getSimpleName());
								performFailureCompensation();
							} catch (Throwable e) {
								logger.error(getBeanName()+" perform failure compensation failed, system might" +
										" be on inconsistent situation." +
										" Considere manual cleanup for distributed caches",e);
								raisedException.addException(e);
							}
							//logger.warn("LenientDefaultMessageListenerContainer.receiveAndExecute:",raisedException);
							/*if(raisedException instanceof JMSException) throw (JMSException) raisedException ;
							else if(raisedException instanceof RuntimeException) throw (RuntimeException) raisedException ;
							else throw new RuntimeException(raisedException) ;*/
							final JMSException jmsexception = new JMSException("[LenientDefaultMessageListenerContainer.receiveAndExecute()]: "+raisedException) ; 
							jmsexception.setLinkedException(raisedException) ; 
							throw jmsexception ; 
						}//EO if exception was thrown 
					} finally {
						clearContextPayments();
					}
				}//EO catch block 
			//}//EO if batch mode			
			return (iReceivedMessagesCounter > 0) ;
		}//EO else if not disposed 
	}//EOM 
	
	/**
	 * add to the JTA transaction context payments the context payments of a given Admin 
	 * (reflects processing of single JMS message).
	 * An 'Admin' object maintain one context PDO under 'Admin.m_contextPDO'
	 * and multiple PDOs under 'Admin.m_mapSessionData' map thru 'Admin.CONTEXT_PDO_LIST' key. 
	 */
	private void accumulateContextPayment(Admin admin) {
		Set<PDO> transactionPayments = jtaTransactionContextPayments.get();
		
		if (transactionPayments == null) {
			transactionPayments = new HashSet<PDO>();
			jtaTransactionContextPayments.set(transactionPayments);
		}
		
		int originalSize = transactionPayments.size();
		
		if (admin.getContextPDO() != null)
			transactionPayments.add(admin.getContextPDO());
		
		PDO[] adminPdoList = (PDO[])admin.getSessionData(Admin.CONTEXT_PDO_LIST);
		if (adminPdoList != null)
			transactionPayments.addAll(Arrays.asList(adminPdoList));
		
		logger.info("accumulate transaction context payments: admin {} added {}" ,admin.getContextID(),transactionPayments.size()-originalSize);		
		logger.info("payments to the transaction context payments, current mids: {}",collect("P_MID",jtaTransactionContextPayments.get()));	
		
	}
	
	private void clearContextPayments() {
		jtaTransactionContextPayments.set(null);	
	}
	
	private void performFailureCompensation() throws Throwable {
		Set<PDO> transactionPayments = jtaTransactionContextPayments.get();
	
		if (CollectionUtils.isEmpty(transactionPayments)) {
			logger.info("{}, avoid failure compensation, there are no payments on the context..",getBeanName());	
			return;
		}
		
		logger.info("{}, performing failure compensation over payments:  {}"
				,getBeanName(),collect("P_MID",jtaTransactionContextPayments.get()));
		
		try {
			PaymentDataFactory.performFailureCompensation(transactionPayments.toArray(new PDO[0]));
		} finally {
				
		}		
	}
	
	/**
	 * Perform a rollback, handling rollback exceptions properly.
	 * @param status object representing the transaction
	 * @param ex the thrown listener exception or error
	 */
	private final void rollbackOnException(final TransactionStatus status, final Throwable ex) {
		logger.debug("Initiating transaction rollback on listener exception", ex);
		try {
			this.getTransactionManager().rollback(status);
		}catch (RuntimeException ex2) {
			logger.error("Listener exception overridden by rollback exception", ex);
			throw ex2;
		}catch (Error err) {
			logger.error("Listener exception overridden by rollback error", ex);
			throw err;
		}//EO catch block 
	}//EOM 
	
	@Override
	protected Message receiveMessage(MessageConsumer consumer) throws JMSException {
		final Long LReceiveTimeout = m_tlAsyncInvokerReceiveTimeout.get() ;  
		final long lFinalReceiveTimeout = (LReceiveTimeout == null ? this.m_lReceiveTimeout : LReceiveTimeout) ;  
		final Message message = ( lFinalReceiveTimeout < 0 ? consumer.receive() : consumer.receive(lFinalReceiveTimeout));
		//set the initialized to true so as to indicate that at least one message was received and the listener is active 
		this.m_bInitialized = true ; 
		return message ;
	}//EOM 
	
	public final void setBatchSize(final int iBatchSize) { this.m_iBatchSize = iBatchSize ; }//EOM 
	public final int getBatchSize() { return this.m_iBatchSize ; }//EOM 
	protected final boolean isBatchMode() { return this.m_iBatchSize > 1 ; }//EOM
	
	@Override
	public void setReceiveTimeout(long receiveTimeout) {
		super.setReceiveTimeout(receiveTimeout)  ;
		//cache the receive timeout locally as not visible in super class and no getter 
		this.m_lReceiveTimeout = receiveTimeout ; 
	}//EOM 
	@Override
	public final Connection createConnection() throws JMSException { return super.createConnection(); }//EOM 
	@Override
	public Session createSession(final Connection con) throws JMSException { return super.createSession(con); }//EOM 
	
	@Override
	public void recoverAfterListenerSetupFailure() {
		if(this.m_bInitialized) { 
			super.recoverAfterListenerSetupFailure() ; 
		}else { 
		
			try{ 
				//if(true || !this.m_configLookupBean.shouldRaiseErrorOnIniFailure()) { 
					final Field currentRecoveryMarker = AbstractJmsListeningContainer.class.getDeclaredField("running") ; 
					currentRecoveryMarker.setAccessible(true) ; 
					currentRecoveryMarker.set(this, false) ;
					new Thread(new Runnable(){ 
						@Override
						public void run() {
							destroy() ; 
							logger.warn("[{}]: JMS container (MDP) '{}' was Destroyed due to setup failure.", Thread.currentThread().getName() , getBeanName() ) ;
							m_bInitialized = false ; 
						}//EOM 
					}, this.getBeanName() + "_Disposer").start() ; 
				//}//EO if should stop container
			}catch(NoSuchFieldException e) { 
				logger.warn("Exception:\n{}", e);
			}//EO catch block 
			catch(Exception e) { 
				logger.warn("Exception:\n{}", e);
			}//EO catch block 			
		}//EO else if not yet initialized 
	}//EOM 
	
	@Override
	public void afterPropertiesSet() {
		try{  
			super.afterPropertiesSet();
			//now, retrieve the transaction definition from the super class using reflection as it is private 
			final Field transactionDefinitionField = AbstractPollingMessageListenerContainer.class.getDeclaredField("transactionDefinition") ; 
			transactionDefinitionField.setAccessible(true) ; 
			this.transactionDefinition = (DefaultTransactionDefinition) transactionDefinitionField.get(this) ; 
			
			//if the batch size is bigger than 1 and there is no transaction manager throw an excpetion 
			if(this.m_iBatchSize > 1 && this.getTransactionManager() == null) { 
				throw new IllegalStateException("[LenientDefaultMessageListenerContainer - " + this.m_sAssociatedServiceName + "]: Invalid configuration: Batch mode cannot be configured without Global Tracsaction.") ; 
			}//EO if batch mode without xa configuration  
			
			//cache the xa mode support state 
			this.m_bTxSupport = (this.getTransactionManager() != null) ; 
		}catch(Throwable t) { 
			//shut down the container
			this.destroy(t) ; 
		}//EO catch block 
	}//EOM 
	
	
	@Override
	public void setDestination(Destination destination) {
		try{ 
			super.setDestination(destination);
		}catch(Throwable t) { 
			//shut down the container
			this.destroy(t) ; 
		}//EO catch block 
	}//EOM 
	
	private final void destroy(final Throwable t)  {
		ErrorAuditUtils.setErrors(new ProcessError(ProcessErrorConstants.MONITOR_SERVICE_STATUS_CHANGED,(new Object[]{Monitors.SubSystem.MDP,getBeanName(),"Destroyed",t})));
		
		//this.destroy() ;
		this.recoverAfterListenerSetupFailure();
		//if the webservices 'init-failure-policy' attribute is set to strict (or not set at all) rethrow  the exception 
		//if(this.m_configLookupBean.shouldRaiseErrorOnIniFailure()) throw new RuntimeException(t) ;
		if(!Admin.appDisposed()) {
			throw new RuntimeException(t) ;
		}
	}//EOM 
	
	@Override
	public void destroy() {	
		ErrorAuditUtils.setErrors(new ProcessError(ProcessErrorConstants.MONITOR_SERVICE_STATUS_CHANGED,(new Object[]{Monitors.SubSystem.MDP,getBeanName(),"Destroyed",""})));
		
		final XFire xfireEnv = (XFire) this.m_appContext.getBean("xfire") ;
		final Service associatedService = xfireEnv.getServiceRegistry().getService(this.m_sAssociatedServiceName) ; 
		
		if(associatedService == null) {
			return  ;
		} 
		
		synchronized(associatedService) { 
			
			super.destroy();
			final GenericApplicationContext context = (GenericApplicationContext) this.m_appContext ;
			
			if(!context.containsBean(this.getBeanName())) {
				return ;
			} 
				
			context.removeBeanDefinition(this.getBeanName()) ;

			Binding binding = null ;
			final Iterator<Binding> iterator = associatedService.getBindings().iterator() ; 
			String sTransport = null ; 
			while(iterator.hasNext()) { 
				binding =  iterator.next() ;
				sTransport = binding.getBindingId() ;   
				
				//TODO: replace the constant equals with the commented section 
				if(sTransport.equals(WebserviceBindingType.Jms.getBindingId(SoapBindingType.Soap11)) ||
				  sTransport.equals(WebserviceBindingType.Jms.getBindingId(SoapBindingType.Soap12))
				  ) {
					binding.disable() ;
				}
				
				//if(sTransport.equals("http://www.soapjms.org/2007/08/soap/bindings/JMS/")) binding.disable() ; 
			}//EO while there 
			
		}//EO synch block 
		
		//clear the m_tlAsyncInvokerReceiveTimeout 
		m_tlAsyncInvokerReceiveTimeout.remove() ; 
			 
	}//EOM 
	@Override
	public final void setMessageListener(final Object messageListener) {
		super.setMessageListener(messageListener);
		//if the message listener is a fndtMessageListenerAdapter extract the context call source from its 
		//interface metadata's in message handler otherwise default to service
		InterfaceTypes interfaceTypeMetadata = null ; 
		try{ 
		
			if(messageListener instanceof FndtMessageListenerAdapter) { 
				final FndtMessageListenerAdapter fndtMsgListener = (FndtMessageListenerAdapter) messageListener ; 
				interfaceTypeMetadata = fndtMsgListener.getInterfaceTypeMetadata() ;
				if(interfaceTypeMetadata != null) this.m_enumContextCallSource = interfaceTypeMetadata.getInHandler().getCallSource() ;
				//set this instance as container services to the listener to be used to handler jms resources in case there is a reply to destination 
				//but the global tx was found not to be active 
				fndtMsgListener.setContainerServices(this) ; 
			}//EO if the message listener was a message listener adapter 
			
		}catch(Throwable t) { 
			ExceptionController.trace(t, this, "[setMessageListener["+interfaceTypeMetadata+"]") ; 
		}//EO catch block 
		
		if(this.m_enumContextCallSource == null) this.m_enumContextCallSource = CallSource.Service ;
	}//EOM 
	@Override
	protected Destination resolveDestinationName(Session session, String destinationName) throws JMSException {
		//return super.resolveDestinationName(session, destinationName);
		
		if(this.m_destination == null) { 
			try{  
				this.m_destination = ServiceLocator.getInstance().jmsDestinationLookup(destinationName, session, true,this.isPubSubDomain()) ;
			}catch(Exception t) {  
				final JMSException jmse = new JMSException(t.getMessage()) ;
				jmse.setLinkedException(t) ; 
				throw jmse ; 
			}//EO catch block 
		}//EO if not yet cached 
		
		return this.m_destination ;

		 
	}//EOM
	
	public final void setAssociatedServiceName(final String sAssociatedServiceName) { this.m_sAssociatedServiceName = sAssociatedServiceName ;}//EOM
	public final String getAssociatedServiceName() { return this.m_sAssociatedServiceName ; }//EOM
	
	@Override
	public final void setApplicationContext(ApplicationContext appContext) throws BeansException { this.m_appContext = appContext ; }//EOM

	public void initialize() {		
		super.initialize();
		//spring 3, startup is not automatic for programatic model
		start(); 
		ErrorAuditUtils.setErrors(new ProcessError(ProcessErrorConstants.MONITOR_SERVICE_STATUS_CHANGED,(new Object[]{Monitors.SubSystem.MDP,getBeanName(),"Initialized",""})));
	}
	private static final class SynchronizingLastResourcesManager extends LastResourcesManager implements TransactionSynchronization { 

		@Override
		public final void beforeCommit(boolean readOnly) { 
			try{ 
				this.commitLastResource() ;
			}catch(Throwable t) { 
				ExceptionController.throwRuntimeException(t) ; 
			}//EOM 
		}//EOM 
		
		@Override
		public final void afterCompletion(int status) { 
			//for tx commit failure scenarios 
			if(status == TransactionSynchronization.STATUS_ROLLED_BACK) { 
				try{ 
					this.compensate() ;
				}catch(Throwable t) { 
					ExceptionController.throwRuntimeException(t) ; 
				}//EOM  				
			}//EO status was rolledback 
		}//EOM 
		
		@Override
		public final void beforeCompletion() { /*do Nothing*/ }//EOM 
		
		@Override
		public final void afterCommit() { /*do Nothing*/  }//EOM 
		
		@Override
		public final void resume() { /*do Nothing*/  }//EOM
		
		@Override
		public final void suspend() { /*do Nothing*/ }//EOM 
		
		@Override
		public SynchronizingLastResourcesManager reset() { super.reset() ; return this ; }//EOM 

		@Override
		public void flush() {
			// TODO Auto-generated method stub
			
		}
		
	}//EOC SynchronizingLastResourcesManager
}//EOC 
