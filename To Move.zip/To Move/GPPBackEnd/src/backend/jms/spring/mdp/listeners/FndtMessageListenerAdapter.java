package backend.jms.spring.mdp.listeners ; 

import java.text.SimpleDateFormat;
import java.util.Map;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.jms.listener.adapter.MessageListenerAdapter;
import org.springframework.transaction.TransactionStatus;

import backend.businessobject.tx.SpringTransactionProxy;
import backend.core.module.ejbinterfaces.TxIsolation;
import backend.jms.JMSPropertiesHelper;
import backend.jms.spring.mdp.containers.LenientDefaultMessageListenerContainer;
import backend.paymentprocess.interfaces.common.TransmissionType;

import com.fundtech.cache.entities.InterfaceTypes;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.general.flows.FlowException;
import com.fundtech.core.general.threading.Callable;
import com.fundtech.core.security.Admin;
import com.fundtech.errors.ProcessErrorConstants;
import com.fundtech.interfaces.gateway.MessageContext;
import com.fundtech.interfaces.gateway.MessageGatewayInterface;
import com.fundtech.interfaces.handlers.InterfaceTypeInHandler;
import com.fundtech.jndi.ServiceLocator;
import com.fundtech.util.ExceptionController;
import com.fundtech.util.Monitors;

public class FndtMessageListenerAdapter extends MessageListenerAdapter implements ApplicationContextAware, BeanNameAware{
	private final static Logger logger = LoggerFactory.getLogger(FndtMessageListenerAdapter.class);
	
	protected String m_sInterfaceName ; 
	protected ApplicationContext m_appContext  ;
	private String m_toStirngRepresentation ;
	private LenientDefaultMessageListenerContainer m_containerSevices ; 

	public FndtMessageListenerAdapter() { 
		super() ;
	}//EOM
	
	public void setInterfaceType(final InterfaceTypes interfaceTypesMetadata){
		this.m_sInterfaceName = interfaceTypesMetadata.getInterfaceName() ; 
		this.m_toStirngRepresentation = ("[MDP " + this.m_sInterfaceName + ']') ;
	}//EOM
	public final void setContainerServices(final LenientDefaultMessageListenerContainer containerServices) { this.m_containerSevices = containerServices ;}//EOM 
	
	@Override
	protected final void postProcessResponse(Message request, Message response) throws JMSException {
		//if there is no correlation id in the request message, use the request's message Id 
		//as the correlation id else echo the correlation id 
		final String sCorrelationId = request.getJMSCorrelationID() ; 
		response.setJMSCorrelationID( (sCorrelationId == null || sCorrelationId.isEmpty() ? request.getJMSMessageID() : sCorrelationId));
		
		//set the message type to reply as the message is a response to a request message 
		///TODO: handle this property dynamically based on the type of the destination 
		response.setIntProperty("JMS_IBM_MsgType",  2/*MQMT_REPLY*/) ;
	}//EOM
		
	@Override 
	public void onMessage(final Message request, Session session) throws JMSException {
		long startTime = System.currentTimeMillis();
		
		//extract the payload from the message (would not perform further conversions.  
		//additional custom transformations would be performed in the message gateway) 		
		final Object oConvertedMessage = this.extractMessage(request) ;
		
		Monitors.JMS.messageStart(m_sInterfaceName, new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS").format(new java.util.Date(request.getJMSTimestamp())), oConvertedMessage);
			
					//Monitors.JMS.logger().isDebugEnabled() ? getTraceableRequestText(oConvertedMessage,-1) : ""});
		
		
		try{ 
			final Object oResponse = this.onMessageInner(oConvertedMessage, request, session) ;
			if(request.getJMSReplyTo() != null && oResponse != null) {
				
				//verify that the current tx is still active. 
				//if not, send the response in a new tx 
				final TransactionStatus txStatus = SpringTransactionProxy.m_txWrapper.getCurrent().getTxStatus() ; 
				if(txStatus.isRollbackOnly()) { 
					
					final Admin admin = Admin.getContextAdmin() ;
					
					final ServiceLocator serviceLocator = ServiceLocator.getInstance() ; 
					
					serviceLocator.SLSBlookup(TxIsolation.class).executeInNewTx(admin, 						
							new Callable() {
								@Override
								public Object call() throws Exception {
									Connection conn = null ; 
									Session newSession = null ; 
									ConnectionFactory connFactory = null ; 
									try{ 
										//never use the container's connection factory in this instance as weblogic would hang. 
										connFactory = serviceLocator.jmsQueueConnectionFactoryLookup(TransmissionType.getInterfacesQueueConFactoryJndi()) ;  
										conn = connFactory.createConnection() ;  
										newSession = m_containerSevices.createSession(conn) ; 
										handleResult(oResponse, request, newSession) ; 
										return null ;
									}catch(Throwable t) { 
										logger.error(t.getMessage()); 
										return null ;
									}finally{ 
										ServiceLocator.releaseResources(newSession, conn) ;
									}//EO catch block 
								}//EOM 
							}//EOC  callable
					
					); 
					
				}else this.handleResult(oResponse, request, session) ; 
			}//EO if should handle response 
		}catch(Throwable t){ 
			ExceptionController.getInstance().handleException(t, this) ;
			logger.error("Exception occured in onMessage", t);
			throw new JMSException(String.format("[MDP for Interface %s]: onMessage Failure with message: '%s'", m_sInterfaceName, ExceptionController.getActualException(t).toString())) ; 
		} finally {			
			Monitors.JMS.messageEnd(m_sInterfaceName,System.currentTimeMillis()-startTime);
		}		
	}//EOM 
	
	@Override
	protected void sendResponse(Session session, Destination destination, Message response) throws JMSException {  
		super.sendResponse(session, destination, response);
	}//EOM 
	
	protected Object onMessageInner(final Object oConvertedPayload, final Message request, final Session session) throws Throwable {
		final InterfaceTypes interfaceTypeMetadata = this.getInterfaceTypeMetadata() ; 

		//if the interface type is inactive throw an exception 
 		if(interfaceTypeMetadata.getInterfaceStatus().equals(InterfaceTypes.STATUS_NOT_ACTIVE)) 
				throw new FlowException(ProcessErrorConstants.InterfaceRequestFailure, "Inactive Status") ;
		
		final MessageContext context = new MessageContext(request.getJMSCorrelationID(), null/*PmntSrc*/, interfaceTypeMetadata) ;
		//TBD would it be correct if this enrichment of the transport properties be done internally by the MessageContext itself? 
		context.setInterfaceTransportContext(JMSPropertiesHelper.getIncomingMessageProperties(interfaceTypeMetadata, request));		
		//apply automatic reply to if JMSReplyTo is on and it's not used by the interface transport  properties configuration 
		boolean applyAutomticReplyTo = request.getJMSReplyTo() != null && !shouldDisableAutomaticReplyToQ(context);
		context.setProperty(MessageContext.APPLY_REPLYTO_KEY, applyAutomticReplyTo);
		
		//set the interface type in the admin for further use in the service layer for initialising the backend delegate
		//set the message context for later use of transport properties
		final Admin admin = Admin.getContextAdmin() ; 
		admin.setIncomingInterfaceType(interfaceTypeMetadata) ;
		admin.setMessageContext(context);
		
		final InterfaceTypeInHandler inHandler = interfaceTypeMetadata.getInHandler() ;
		final MessageGatewayInterface messageGateway = inHandler.getMessageGateway(oConvertedPayload, context) ; 
		
		Object response = messageGateway.onMessage(oConvertedPayload, context) ; 
 
		//this code could probably be removed now that the replyTo is automatically canceled when used on transport properties   
		boolean applyJMSReplyTo = (Boolean)context.getProperty(MessageContext.APPLY_REPLYTO_KEY);
		if (applyJMSReplyTo == false && request.getJMSReplyTo() != null)
			request.setJMSReplyTo(null);
		
		return response;
	}//EOM 
	
	private boolean shouldDisableAutomaticReplyToQ(MessageContext context ) {
		if (context.getInterfaceTransportContext().containsKey("JMSReplyTo")) {
			logger.info("'JMSReplyTo' had been used as transport properties ('transport.properties.save')" 
					+",hence assumes it shouldn't be an automatic reply to for this request"); 
			return true;
		}
		return false;
	}
	
	public final InterfaceTypes getInterfaceTypeMetadata() { return CacheKeys.interfaceTypesNameKey.getSingle(this.m_sInterfaceName) ; }//EOM 
	
	@Override
	public final void setApplicationContext(final ApplicationContext applicationcontext) throws BeansException {
		this.m_appContext = applicationcontext ; 
	}//EOM
	
	@Override
	public final void setBeanName(final String sName) { this.m_sInterfaceName = sName ; }//EOM 
	
	/**
	 * must be overridden to fix the stackoverflow bug in case the delegate is this instance 
	 */
	@Override
	public String getSubscriptionName() {
		final Object oDelegate = this.getDelegate() ; 
		if (oDelegate != this && oDelegate instanceof org.springframework.jms.listener.SubscriptionNameProvider) {
			return ((org.springframework.jms.listener.SubscriptionNameProvider) oDelegate).getSubscriptionName();
		}
		else {
			return oDelegate.getClass().getName();
		}
	}//EOM 
	
	@Override
	public final String toString() { return this.m_toStirngRepresentation ; }//EOM
	

	private Map getInterfaceTransportProperties(InterfaceTypes interfaceTypeMetadata,final Message message) {		
		
		Map transportProperties = JMSPropertiesHelper.getIncomingMessageProperties(interfaceTypeMetadata, message);
		logger.debug("transport properties {} ({})",transportProperties , interfaceTypeMetadata.getInterfaceName());
			
		return transportProperties;
	}	
}//EOM 
