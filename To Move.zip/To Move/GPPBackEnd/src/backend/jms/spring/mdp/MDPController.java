package backend.jms.spring.mdp ; 

import java.util.Iterator;

import org.codehaus.xfire.XFire;
import org.codehaus.xfire.service.Binding;
import org.codehaus.xfire.service.Endpoint;
import org.codehaus.xfire.service.Service;
import org.codehaus.xfire.xmlbeans.XmlBeansServiceFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.MutablePropertyValues;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.support.AbstractBeanDefinition;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.support.GenericApplicationContext;
import org.springframework.jms.listener.adapter.MessageListenerAdapter;
import org.springframework.jms.support.converter.MessageConverter;

import backend.jms.spring.mdp.containers.LenientDefaultMessageListenerContainer;
import backend.jms.spring.mdp.listeners.FndtMessageListenerAdapter;
import backend.paymentprocess.erroraudit.ErrorAuditUtils;
import backend.paymentprocess.interfaces.common.TransmissionType;

import com.fundtech.appServerConfigDefinition.JmsResource;
import com.fundtech.cache.entities.InterfaceTypes;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.paymentprocess.errorhandling.ProcessError;
import com.fundtech.errors.ProcessErrorConstants;
import com.fundtech.interfaces.handlers.converters.SimpleJmsPayloadConverter;
import com.fundtech.jndi.ServiceLocator;
import com.fundtech.mapping.AbstractConfigProxy;
import com.fundtech.spring.FndtSpringBeansFactory;
import com.fundtech.spring.config.DefaultBeanDefinitionConfigurer;
import com.fundtech.util.ExceptionController;
import com.fundtech.util.Monitors;
import com.fundtech.webservices.infra.ServiceTransportType;
import com.fundtech.webservices.infra.xfire.client.WSClientFactory.SoapBindingType;
import com.fundtech.webservices.infra.xfire.client.WSClientFactory.WebserviceBindingType;

public class MDPController implements ApplicationListener{

	private static final Logger logger = LoggerFactory.getLogger(MDPController.class);
	
	private static final String MDP_SUFFIX = "_MDP" ;  
	public static final String MDPS_APP_CONTEXT = "MDPS_APP_CONTEXT" ;


	private boolean onEvent = false;
	
	@Override
	public synchronized void onApplicationEvent(ApplicationEvent event) {		
		//event would be null when this method is directly invoked from the interfaceTypesMissHandler 
		if(onEvent || (event != null && !(event instanceof ContextRefreshedEvent))) 
			return ;  
		
		onEvent = true;
		
		//retrieve all interface type entries from persistence where direction is I is request protocol is JMS or SOAP over JMS (even the disabled or with 0 no of listeners)
		
		//final BackendTracer GlobalTracer = GlobalTracer ; 
		 
		try{ 
			//first attempt to retrieve the mdps context from the fndtSpringBeansFactory.
			//final ServiceLocator serviceLocator = ServiceLocator.getInstance() ;
			//if(serviceLocator.springApplicationContextExists(MDPS_APP_CONTEXT)) serviceLocator.removeSpringApplicationContext(MDPS_APP_CONTEXT, false/*bInSeperateThread*/) ;
			
			//FOR DEBUG 
			//if(true) return ; 
			//FOR DEBUG
			
			//now create a new context for the mdps 
			//serviceLocator.newSpringApplicationContext(MDPS_APP_CONTEXT, true/*defaultContextAsParent*/) ;
			//retrieve the fndtSpringBeansFactory 
			final FndtSpringBeansFactory springBeansFactory = ServiceLocator.getInstance().getFndtSpringBeansFactory() ; 
			//ensure that the mdp's context was created 
			springBeansFactory.getNsetApplicationContext(MDPS_APP_CONTEXT, true/*defaultContextAsParent*/) ;
			
			logger.info("[MDPController]: Commencing MDPs Initialization"); 
			final Iterator<InterfaceTypes> iterator = CacheKeys.interfaceTypesNameKey.getAllMDPs() ;

			//iterate over the records, extract each from the cache, configure the bean definition configurer and create the MDP
			//once done, refresh the spring context 
			final MDPBeanConfigurer beanDefinitionConfigurer = new MDPBeanConfigurer() ;  
			beanDefinitionConfigurer.connectionFactoryName =  this.getQConFactoryJndiAlias() ; //ServiceLocator.CONNECTION_FACTORY_JNDI;

			InterfaceTypes interfaceTypeMetadata = null ;

			while(iterator.hasNext()) {
				
				interfaceTypeMetadata = iterator.next() ;
				beanDefinitionConfigurer.interfaceTypeMetadata = interfaceTypeMetadata ;
				
				//invoke the get business object for the interface type 
				interfaceTypeMetadata.getBusinessObjectInstance() ; 
				
				//if the interface is disabled or the number of listeners  < 0 and the bean exist, remove it 
				if (InterfaceTypes.STATUS_NOT_ACTIVE.equals(interfaceTypeMetadata.getInterfaceStatus()) || 
					null==interfaceTypeMetadata.getNoOfListeners() || 
					interfaceTypeMetadata.getNoOfListeners().intValue()<=0) 
				{
					this.removeMDP(interfaceTypeMetadata, springBeansFactory) ;
				}
				else 
				{ 
					//create the MDP 
					logger.info("[MDPController]: About to initialize MDP for Interface Type: {}", interfaceTypeMetadata);
					String beanName= this.constructMDPID(interfaceTypeMetadata.getInterfaceName());
					ErrorAuditUtils.setErrors(new ProcessError(ProcessErrorConstants.MONITOR_SERVICE_STATUS_CHANGED,(new Object[]{Monitors.SubSystem.MDP,beanName,"Initializing",interfaceTypeMetadata})));
					try{
					springBeansFactory.getNsetSpringBean(beanName, LenientDefaultMessageListenerContainer.class,MDPS_APP_CONTEXT, beanDefinitionConfigurer) ;
					}catch(Throwable e){
						logger.error(interfaceTypeMetadata.getInterfaceName() + " failed initialization.",e);
					}
				
				}//EO else if should have created  
			}//EO while there are more MDPs
			
		}catch(Throwable t) { 
			ExceptionController.getInstance().handleException(t, this) ; 
		}finally{ 
			onEvent = false;
		}//EO catch block  
		
		logger.info("[MDPController]: Finished MDPs Initialization (Note: monitor the trace for subsequent individual MDP failures)"); 
	}//EOM 
	
	public final void addMDP(final String sMDPID) throws Throwable { 
		this.addMDP(this.getInterfaceTypesForMDPId(sMDPID)) ; 
	}//EOM 
	
	public final void addMDP(final InterfaceTypes interfaceTypeMetadata) throws Throwable { 
		final MDPBeanConfigurer beanDefinitionConfigurer = new MDPBeanConfigurer() ;
		beanDefinitionConfigurer.interfaceTypeMetadata = interfaceTypeMetadata ; 
		beanDefinitionConfigurer.connectionFactoryName = this.getQConFactoryJndiAlias();//ServiceLocator.CONNECTION_FACTORY_JNDI ;
		
		ServiceLocator.getInstance().getNsetSpringBean(this.constructMDPID(interfaceTypeMetadata.getInterfaceName()), LenientDefaultMessageListenerContainer.class, 
				MDPS_APP_CONTEXT, beanDefinitionConfigurer) ; 
	}//EOM
		
	public final void removeMDP(final String sMDPInterfaceName) throws Throwable {
		//retrieve the interface type from cache using the MDP id (interface name) 
		//construct an MDP configurer and invoke the service locator's remove Bean
		final InterfaceTypes interfaceTypeMetadata = this.getInterfaceTypesForMDPId(sMDPInterfaceName) ;
		this.removeMDP(interfaceTypeMetadata) ; 
	}//EOM 
		
	public final void removeMDP(final InterfaceTypes interfaceTypeMetadata) throws Throwable {
		this.removeMDP(interfaceTypeMetadata , ServiceLocator.getInstance().getFndtSpringBeansFactory()) ; 
	}//EOM
	
	public final void removeMDP(final InterfaceTypes interfaceTypeMetadata, final FndtSpringBeansFactory springBeansFactory) throws Throwable {
		final MDPBeanConfigurer mdpBeanConfigurer = new MDPBeanConfigurer() ; 
		mdpBeanConfigurer.interfaceTypeMetadata = interfaceTypeMetadata ; 
	
		springBeansFactory.destroyNRemoveSpringBean(this.constructMDPID(interfaceTypeMetadata.getInterfaceName()), 
				LenientDefaultMessageListenerContainer.class, 
				MDPS_APP_CONTEXT, 
				mdpBeanConfigurer) ;
	}//EOM 
	
	private final String constructMDPID(String sMDPID) { 
		return (!sMDPID.endsWith(MDP_SUFFIX) ? (sMDPID + MDP_SUFFIX) : sMDPID) ; 
	}//EOM 
	
	private final InterfaceTypes getInterfaceTypesForMDPId(final String sMDPId) { 
		return CacheKeys.interfaceTypesNameKey.getSingle(sMDPId.replace(MDP_SUFFIX, "")/*interface name*/) ;
	}//EOM
	
	/**
	 * Note: currently not an implementation of the DestoryBean 
	 * Aug 22, 2010
	 * Guys
	 *
	 * @throws Exception
	 */
	public final void destroy() throws Exception {
		//simply close the MDPS_APP_CONTEXT app context 
		//Note: might be better to dispose in a seperate thread  
		ServiceLocator.getInstance().removeSpringApplicationContext(MDPS_APP_CONTEXT, true/*bInSeperateThread*/) ;  
	}//EOM 
	
	public static final class MDPBeanConfigurer extends DefaultBeanDefinitionConfigurer { 

		private String connectionFactoryName ; 
		private InterfaceTypes interfaceTypeMetadata ; 
		
		public MDPBeanConfigurer(){}//EOM 
				
		@Override
		public final AbstractBeanDefinition configureBean(final AbstractBeanDefinition rawBeanDefintition, 
																	final GenericApplicationContext appContext) throws Exception{
			
			//derive the message listener classname from the transmission type associated with the request (incoming) 
			final ServiceLocator serviceLocator = ServiceLocator.getInstance() ;
			
			final TransmissionType enumTransmissionType = TransmissionType.valueOf(this.interfaceTypeMetadata.getRequestProtocol()) ;
			final boolean bSoapOverJMsTransmission = (enumTransmissionType == TransmissionType.SOAP_JMS) ; 
		
			//create the mdp message listener adapter instance (prototype) 
			final Object msgListenerDelegate = (MessageListenerAdapter) serviceLocator.getNsetSpringBean(
					FndtMessageListenerAdapter.class.getName(), FndtMessageListenerAdapter.class, 
					FndtSpringBeansFactory.DEFAULT_APP_CONTEXT, 
					new MDPListenerBeanConfigurer(this.interfaceTypeMetadata, bSoapOverJMsTransmission)
				);
			
			final String sAssociatedServiceName = this.interfaceTypeMetadata.getAssociatedServiceName() ; 
			
			final MutablePropertyValues propertyValues = new MutablePropertyValues() ; 
			propertyValues.addPropertyValue("associatedServiceName", sAssociatedServiceName) ;
			propertyValues.addPropertyValue("messageListener", msgListenerDelegate) ; 
			propertyValues.addPropertyValue("taskExecutor", appContext.getBean("CommonjTaskExecutor")) ; 
			      
			//Non XA version 
			//propertyValues.addPropertyValue("sessionTransacted", true) ;
			//propertyValues.addPropertyValue("cacheLevelName", "CACHE_NONE") ;
			//Non XA version   - END 
			
			int batchSize = 1;
			try {
				batchSize = Integer.parseInt((String)this.interfaceTypeMetadata.get("batch.Size"));
			} catch (Exception e) {				
			}
			logger.debug("batchSize: {}",batchSize);
			propertyValues.addPropertyValue("batchSize", batchSize) ;
			propertyValues.addPropertyValue("receiveTimeout", 3000) ;
			
			//Session caching - not working in WAS  
			//propertyValues.addPropertyValue("cacheLevelName", "CACHE_SESSION") ;
			//Session caching - not working in WAS  - END
			
			propertyValues.addPropertyValue("transactionManager", appContext.getBean("transactionManager")) ;
			propertyValues.addPropertyValue("connectionFactory", serviceLocator.jmsQueueConnectionFactoryLookup(this.connectionFactoryName, true/*bQualifiedSearch*/)) ;
			
			
            
			final String sDestinationName = this.interfaceTypeMetadata.getRequestConnectionsPoint();//String.format("queue:///%s?targetClient=1", this.interfaceTypeMetadata.getRequestConnectionsPoint()) ; 
//			following is R&D code, however, we supports jndi lookup and fallback to MQ URI only on jndi failure			
//			String sDestinationName = "";
//			// For JMS provider (E.G. WEBLOGIC) the destinationName should be without any prefix/suffix (E.G. queue:/// and targetClient=1)
//            Boolean nonJMSProvider = this.interfaceTypeMetadata.getNonJMSrecipient();
//            if (nonJMSProvider != null && nonJMSProvider == false) {
//                 sDestinationName = this.interfaceTypeMetadata.getRequestConnectionsPoint();
//            } else { // None JMS provider (E.G. MQ)
//                 sDestinationName = String.format("queue:///%s?targetClient=1", this.interfaceTypeMetadata.getRequestConnectionsPoint()) ;
//            }
			
			 
			propertyValues.addPropertyValue("destinationName", sDestinationName) ;
			propertyValues.addPropertyValue("maxConcurrentConsumers", this.interfaceTypeMetadata.getNoOfListeners()) ; 
			propertyValues.addPropertyValue("concurrentConsumers", this.interfaceTypeMetadata.getMinNoOfListeners()) ;
			//assuming configuration of minimum number of listener is for performance benefits, hence, also configure   
			//maxMessagesPerTask configuration to increase performenec. 
			//maxMessagesPerTask as -1 would keep the listening thread always up without rescheduling it thru the WOrkManager
			if (this.interfaceTypeMetadata.getMinNoOfListeners() > 1)
				propertyValues.addPropertyValue("maxMessagesPerTask", -1) ;

			rawBeanDefintition.setPropertyValues(propertyValues) ; 
			
			//if the interface is of TransmissionType.SOAP_JMS type configure the xfire service, else skip as there would be no service
			if(bSoapOverJMsTransmission) { 
				final XFire xfireEnv = (XFire) appContext.getBean("xfire") ;
				final Service service = xfireEnv.getServiceRegistry().getService(sAssociatedServiceName) ;
				
				if(service == null) throw new IllegalStateException(String.format("MDP %s failed to initialize as no associated webservice %s was defined", this.interfaceTypeMetadata.getInterfaceName(), sAssociatedServiceName)) ; 
				
				final XmlBeansServiceFactory xmlBeansFactory = new XmlBeansServiceFactory(xfireEnv.getTransportManager()) ; 
				   
				final Endpoint endpoint = 
					WebserviceBindingType.Jms.configureBinding(xmlBeansFactory, service, SoapBindingType.Soap12, 
							String.format("targetService=%s", service.getSimpleName()), sAssociatedServiceName + "JMSPort") ; 
				
				endpoint.setUrl(ServiceTransportType.JMS.getUri(this.interfaceTypeMetadata).toURL().toString()) ;
			}//EO if bSoapOverJMsTransmission
			
			return rawBeanDefintition ; 
			
		}//EOM
		
		@Override
		public LenientDefaultMessageListenerContainer postConfigureBeanInstance(final Object beanInstance, final GenericApplicationContext appContext) throws Exception {
			final LenientDefaultMessageListenerContainer mdp = (LenientDefaultMessageListenerContainer) beanInstance ;
			final int iNewNoOfListeners = this.interfaceTypeMetadata.getNoOfListeners() ; 
		 
			if(mdp.getMaxConcurrentConsumers() != iNewNoOfListeners) {
				//mdp.setConcurrentConsumers(iNewNoOfListeners) ; 
				mdp.setMaxConcurrentConsumers(iNewNoOfListeners) ; 
			}//EO if there no of consumers was changed 
			return mdp ;
		}//EOM 
		
		@Override
		public final void removeBean(final String sBeanAlias, final Class<?> clsBeanType, final GenericApplicationContext appContext) throws Exception {
			if(!appContext.containsBeanDefinition(sBeanAlias)) return ; 
			
			logger.info("[MDPController]: About to remove MDP for Interface Type:%n{}", this.interfaceTypeMetadata);
			
			final LenientDefaultMessageListenerContainer mdp = (LenientDefaultMessageListenerContainer) appContext.getBean(sBeanAlias) ;
			mdp.stop(new Runnable() { 
					@Override
					public final void run() {
						logger.info("[MDPController.postConfigureBeanInstance()]: MDP '" + interfaceTypeMetadata.getInterfaceName() + "' is stopped.");
						appContext.removeBeanDefinition(sBeanAlias) ;
					}//EOM 
			}) ; 
			
			//disable the jms transport if the transmission type is soap over jms 
			if(TransmissionType.valueOf(this.interfaceTypeMetadata.getRequestProtocol()) == TransmissionType.SOAP_JMS) { 
				final XFire xfireEnv = (XFire) appContext.getBean("xfire") ;
				final Service service = xfireEnv.getServiceRegistry().getService(this.interfaceTypeMetadata.getAssociatedServiceName()) ;
				final Binding binding = service.getBinding(WebserviceBindingType.Jms.getBindingId(SoapBindingType.Soap12)) ;
				binding.disable() ;
			}//EO if soap over jms 
		}//EOM
		
	}//EO MDPBeanConfigurer class  
	
	public static final class MDPListenerBeanConfigurer extends DefaultBeanDefinitionConfigurer { 
		
		final private InterfaceTypes m_interfaceTypeMetadata ;
		final boolean m_bSoapOverJMsTransmission ; 
		
		public MDPListenerBeanConfigurer(final InterfaceTypes interfaceTypeMetadata, final boolean bSoapOverJMsTransmission) { 
			this.m_interfaceTypeMetadata = interfaceTypeMetadata ;
			this.m_bSoapOverJMsTransmission = bSoapOverJMsTransmission ;
		}//EOM 
		
		@Override
		public final AbstractBeanDefinition configureBean(final AbstractBeanDefinition rawBeanDefintition, final GenericApplicationContext appContext) throws Exception {
			rawBeanDefintition.setScope(BeanDefinition.SCOPE_PROTOTYPE) ;
			
			return rawBeanDefintition ; 
		}//EOM 
		
		@Override
		public final Object postConfigureBeanInstance(final Object beanInstance, final GenericApplicationContext appContext) throws Exception{
			final FndtMessageListenerAdapter msgListenerDelegate = (FndtMessageListenerAdapter) beanInstance ; 
			
			ServiceLocator serviceLocator = ServiceLocator.getInstance() ;
			
			//create the message gateway required based on the m_bSoapOverJMsTransmission (singleton)
		/*	final Class<?> clsListenerDelegate = (this.m_bSoapOverJMsTransmission ? 
					XFireMessageGateway.class :
					BarePayloadMessagesGateway.class
				) ; 
			
			 final MessageGatewayInterface messageGateway = (MessageGatewayInterface) serviceLocator.getNsetSpringBean(
					clsListenerDelegate.getName(), clsListenerDelegate,  
					FndtSpringBeansFactory.DEFAULT_APP_CONTEXT
					//new MessageGatewayBeanConfigurer(this.m_interfaceTypeMetadata) 
				) ; */
			
			//construct a new instance of the SimlpeJmsPayloadConverter (singleton). 
			//if the interface defined a custom converter, chain it to the former 
			final MessageConverter msgConverter = serviceLocator.getNsetSpringBean(
					SimpleJmsPayloadConverter.class.getName(), 
					SimpleJmsPayloadConverter.class, 
					FndtSpringBeansFactory.DEFAULT_APP_CONTEXT 
					) ;
			
			msgListenerDelegate.setMessageConverter(msgConverter) ;
			//msgListenerDelegate.setMessageGateway(messageGateway) ; 
			
			//set the interface type in the delegate 
			msgListenerDelegate.setInterfaceType(this.m_interfaceTypeMetadata) ;
			return msgListenerDelegate ; 
		}//EOM 
		
	}//EOC MDPListenerBeanConfigurer
	
	//Mass payment retrofit
	private final String getQConFactoryJndiAlias() { 
		String sConFactoryName = "jms/FundtechQConFactory" ; 
		final JmsResource mdpsJmsResource = AbstractConfigProxy.getInstance().getJmsConfigElement("mdps") ; 
		if(mdpsJmsResource != null)  sConFactoryName = mdpsJmsResource.getDestinations().getConFactoryJndi() ;
		return sConFactoryName ; 
	}//EOM
	//Mass payment retrofit

}//EOC 
