
package backend.jms;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Queue;
import javax.jms.Topic;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.cache.entities.InterfaceTypes;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.core.security.Admin;
import com.fundtech.jndi.JmsSessionContext;
import com.ibm.mq.constants.MQConstants;

/**
 * Central class encapsulate message properties control.
 * 
 * This class respects message properties as declared on interfaces: 
 * 	add required message properties as declared on outgoing interfaces 
 * 	save (to PDO) message properties as decalred on incoming interfaces.
 *  
 * @since MAMBO
 */
public class JMSPropertiesHelper {
	private static final Logger logger = LoggerFactory.getLogger(JMSPropertiesHelper.class);
	
	public static Map getIncomingMessageProperties(InterfaceTypes incomingInterface,final Message message) {
		String[] transportPropertiesList = incomingInterface.getTransportPropertiesPreservedList();
		Map<String,Object> transportProperties = getMessageProperties(message,transportPropertiesList);
		
		if (!transportProperties.isEmpty())
			logger.debug("transport properties {} ({})",transportProperties , incomingInterface.getInterfaceName());
			
		return transportProperties;
	}
	
	/**
	 * Evaluate the concrete message properties when sending concrete PDO via concrete outgoing interface.   
	 * The values of the transport properties should exist on the PDO. 
	 * The enrichment may include mapping between transport properties. For example, property A value 
	 * should hold the value of property B.
	 * @param outgointInterface 
	 * @param pdo
	 * @param mapContext none null or null map
	 * @return  
	 */
	public static Map evaluateOutgoingMessageProperties(InterfaceTypes outgointInterface,String mid) {
		if (outgointInterface == null || mid == null)
			return null;
		PDO pdo  = null;
		try {
			pdo = pdo = PaymentDataFactory.load(mid);
		} catch (Throwable t) {
			logger.error("",t);
			return null;
		}
		
		if (pdo == null) { 
			logger.error("PDO '"+mid+"' Not Exists");
			return null;
		}
		
		Map<String,String> transportPropertiesMappingMetadata = outgointInterface.getTransportPropertiesEnrichMapping();
		if (transportPropertiesMappingMetadata.isEmpty()) return null;
			
		Map<String,String> transportPropertiesData = getTransportProperties(pdo);
		
		//create the concrete transport properties to send
		Map<String,String> outgoingTransportProperties = new HashMap<String,String>();
		
		for (Map.Entry<String,String> transportPropertyMapping : transportPropertiesMappingMetadata.entrySet()) {
			String transportPropertyName = transportPropertyMapping.getKey();
			String transportPropertyValue= transportPropertyMapping.getValue();
			//$ prefix: the value refers to saved transport property
			if (transportPropertyValue.startsWith("$")) {
				String referenceTransportProperty = transportPropertyValue.substring(1);
				
				if (!transportPropertiesData.containsKey(referenceTransportProperty)) {
					if (logger.isWarnEnabled()) {
						logger.warn( "outgoing iterface " + outgointInterface.getInterfaceName() 
									+": can't set value to transport property "+transportPropertyName
									+", reference transport property '"+referenceTransportProperty
								    + "' is missing on PDO ("+pdo.getMID()+")");
						continue;
					}
				}
				
				transportPropertyValue = transportPropertiesData.get(referenceTransportProperty);
			}
						
			outgoingTransportProperties.put(transportPropertyName, transportPropertyValue);
		}
		
		
		logger.debug("Outgoing Message Properties: {}",outgoingTransportProperties);
		
		return outgoingTransportProperties;
	}
	
	/**
	 * There are cases where transport properties scope is transaction and not PDO
	 * for example when there are multiple PDOs on transaction and the transport properties
	 * are used on a second level PDO (Ack). 
	 * On other cases, the transport properties might be used on different transaction and hence the 
	 * transport properties scope is PDO.
	 */
	private static Map getTransportProperties(PDO pdo) {
		Map transportPropertiesData = pdo.getTransportProperties();
		
		if (transportPropertiesData.isEmpty()) {
			//on transaction scope, the transport properties would be available on Admin.MessageContext  
			Admin admin = (Admin)Admin.getContextAdmin();
			if (admin != null && admin.getMessageContext() != null)
				transportPropertiesData = admin.getMessageContext().getInterfaceTransportContext();
			
			if (transportPropertiesData == null)
				transportPropertiesData = Collections.EMPTY_MAP;
			
			logger.info("could not find transport properties on PDO: {}, founded on Admin (MessageContext)? {}"
					,pdo.getMID(),transportPropertiesData.isEmpty() ? "false" : "true");			
		}
		
		return transportPropertiesData;
	}

	/**
	 * bind the transport properties by converting property value from its string representation to its real class  
	 * @param transportProperties
	 * @return
	 */
	public static void bindPropertiesValues(Map<String, String> messageProperties,PDO pdo,JmsSessionContext session) {
		if (messageProperties == null || messageProperties.isEmpty())
			return;
		
		for (Map.Entry property : messageProperties.entrySet())     		
    		property.setValue(bindPropertyValue((String)property.getKey(),(String)property.getValue(),pdo,session));
		
		logger.debug("Bounded Message Properties: {}",messageProperties);
	}
	
	/**
	 * bind the transport properties by converting property value from its string representation to its real class  
	 * @param transportProperties
	 * @return
	 */
	public static Object bindPropertyValue(String propertyName,String propertyStringValue,PDO pdo,JmsSessionContext session) {
		final String PDO_PREFIX="PDO.";
	    if (propertyName == null)
			return null;
	    
		if (null!=pdo && propertyStringValue.startsWith(PDO_PREFIX))
		{
		    //If the value string starts with PDO. we pick up the PDO logical field value
		    propertyStringValue=pdo.getString(propertyStringValue.substring(PDO_PREFIX.length()));
		}
		Object propertyObjectValue = propertyStringValue;
		
		try {
    		if ("JMSPriority".equals(propertyName) 
    				|| "JMSDeliveryMode".equals(propertyName)) 		//int		    			
    			propertyObjectValue = Integer.parseInt(propertyStringValue);
    		else if ("JMSTimestamp".equals(propertyName) 
    				|| "JMSExpiration".equals(propertyName)) 		//long		    			
    			propertyObjectValue = Long.parseLong(propertyStringValue);
    		else if ("JMSRedelivered".equals(propertyName))		//boolean
    			propertyObjectValue = Boolean.parseBoolean(propertyStringValue);
    		else if ("JMSReplyTo".equals(propertyName)
    				 	|| "JMSDestination".equals(propertyName)) 			//Destination
    			propertyObjectValue = session.getSession().createQueue(propertyStringValue);
    		else if (propertyName.startsWith("JMS_IBM_")) {		    			
    			propertyObjectValue = MQConstants.getValue(propertyStringValue);
    			
    			if (propertyObjectValue == null)
    				throw new Exception("unknown MQ property");		    			
    		}
		} catch (Exception e) {
			if (logger.isWarnEnabled())
				logger.warn("binding value "+propertyStringValue+" to transport property "+propertyName+" failed due to "+e);
		}
    			
		return propertyObjectValue;
	}
	
	public static Map<String,Object> getMessageProperties(Message message,String[] properties) {
		if (properties == null || message == null || properties.length == 0)
			return Collections.emptyMap();
		
		Map<String,Object> propertiesMap = new HashMap<String,Object>();
		
		for (String propertyName : properties) {
			try {
				propertiesMap.put(propertyName.trim(), getMessageProperty(message,propertyName));
			} catch (Exception e) {
				logger.warn("reading message property {} failed due to {}",propertyName, e);
			}				
		}		
		
		return propertiesMap;
	}

	public static Object getMessageProperty(Message message,String property) throws Exception {
		//due to complexity, skip: JMSCorrelationIDAsBytes
		if ("JMSCorrelationID".equals(property)) 	//String											
			return  message.getJMSCorrelationID();
			//return message.getJMSCorrelationID();
		if ("JMSMessageID".equals(property))  	//String
			return message.getJMSMessageID();
		if ("JMSPriority".equals(property)) 		//int
			return message.getJMSPriority();
		if ("JMSReplyTo".equals(property)) 			//Destination
			return getDestinationName(message.getJMSReplyTo());
		if ("JMSDestination".equals(property)) 	    //Destination
			return getDestinationName(message.getJMSDestination());			
		if ("JMSRedelivered".equals(property))		//boolean
			return message.getJMSRedelivered();
		if ("JMSType".equals(property)) 			//String
			return message.getJMSType();
		if ("JMSTimestamp".equals(property)) 		//long
			return message.getJMSTimestamp();			
		if ("JMSDeliveryMode".equals(property)) 	//int
			return message.getJMSDeliveryMode();
		if ("JMSExpiration".equals(property)) 		//long
			return message.getJMSExpiration();			
		
		if (!message.propertyExists(property)) 
			throw new Exception("property '"+"' not exists on message");
		
		return message.getObjectProperty(property);
	}

	public static Object getDestinationName(Destination destination) throws JMSException {		
		if (destination == null)
			return "";
		if (destination instanceof Queue)				
			return ((Queue)destination).getQueueName();				
		if (destination instanceof Topic)
			return ((Topic)destination).getTopicName();
		return "";
	}
	
	public static void setMessageProperties(Message message,Map<String, Object> messageProperties) {
    	if (message == null || messageProperties == null || messageProperties.isEmpty())
    		return;
    	
    	for (Map.Entry<String,Object> property : messageProperties.entrySet())     	
    		setMessageProperty(message,property.getKey(),property.getValue());    	
	}
	
	public static void setMessageProperty(Message message,String propertyName,Object propertyValue) {
		if (message == null || propertyName == null)
			return;
		
		try {
			//String
    		if ("JMSCorrelationID".equals(propertyName)) 	 
				message.setJMSCorrelationID((String)propertyValue);    		    
    		else if ("JMSMessageID".equals(propertyName))
    		{    			
				//message.setJMSMessageID("ID:" + (String)propertyValue);
				message.setJMSMessageID((String)propertyValue);
    		}
    		else if ("JMSType".equals(propertyName)) 			
				message.setJMSType((String)propertyValue);	    
    		//int
    		else if ("JMSPriority".equals(propertyName)) {	
    			message.setJMSPriority((Integer)propertyValue);
    		} else if ("JMSDeliveryMode".equals(propertyName)) 	{
    			message.setJMSDeliveryMode((Integer)propertyValue);
    		} 
    		//long
    		else if ("JMSTimestamp".equals(propertyName)) {		
    			message.setJMSTimestamp((Long)propertyValue);			
			} else if ("JMSExpiration".equals(propertyName)) {
    			message.setJMSExpiration((Long)propertyValue);
			}
			//boolean
			else if ("JMSRedelivered".equals(propertyName)) {		
				message.setJMSRedelivered((Boolean)propertyValue);
			} 
			//Destination 
    		else if ("JMSReplyTo".equals(propertyName)) {	
    			message.setJMSReplyTo((Destination)propertyValue);
    		} else if ("JMSDestination".equals(propertyName)) { 	    
    			message.setJMSDestination((Destination)propertyValue);
			} else  
    			message.setObjectProperty(propertyName, propertyValue);
		} catch (Exception e) {
			if (logger.isWarnEnabled())
				logger.warn("assigning message property "+propertyName+" failed due to "+e);
		}
	}
	
	public static String getMessageIDAsString(String sMessageID){
		String retValue = null;
		
		
		//Drop the "ID:"
		retValue=sMessageID.substring(3);
		
		//loop through string and conver to byte array
		//Each two charactes represent an hex value of the byte.
	    int iLength = retValue.length();
	    byte[] byteArray = new byte[iLength/2];
	    for(int i=0; i<iLength; i=i+2)
	    {
	      String sHexValue = retValue.substring(i, i+2);
	      Integer iHexValue  = Integer.parseInt (sHexValue, 16);
	      byteArray[i/2] = iHexValue.byteValue();	      
	    }
		retValue = new String(byteArray);		
		return retValue; 
		
	}
	
}
