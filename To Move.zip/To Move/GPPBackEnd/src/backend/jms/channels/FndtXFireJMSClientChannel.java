package backend.jms.channels ; 

import java.util.concurrent.locks.ReentrantLock;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.jms.Connection;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.codehaus.xfire.MessageContext;
import org.codehaus.xfire.XFire;
import org.codehaus.xfire.XFireException;
import org.codehaus.xfire.XFireRuntimeException;
import org.codehaus.xfire.exchange.OutMessage;
import org.codehaus.xfire.fault.XFireFault;
import org.codehaus.xfire.transport.AbstractTransport;

import com.fundtech.interfaces.handlers.converters.SimpleJmsPayloadConverter;
import com.fundtech.jndi.AsyncResourceReleaser;
import com.fundtech.jndi.ServiceLocator;
import com.fundtech.util.ExceptionController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.fundtech.webservices.infra.xfire.channels.FndtXFireBaseChannel;

import backend.jms.businessobjects.BOJMessaging;

public class FndtXFireJMSClientChannel extends FndtXFireBaseChannel implements MessageListener{

	private final static Logger logger = LoggerFactory.getLogger(FndtXFireJMSClientChannel.class);

	//private static final BackendTracer GlobalTracer = GlobalTracer ; 
	private static final String REPLY_TO_MESSAGE_JMS_PROPERTY_KEY = "jms.replyTo";
	private static final String DESTINATION_PROPERTY_KEY = "Destination" ; 
	private static final String SOURCE_PROPERTY_KEY = "Source" ;
	
	private static final String REPLY_TO_DESTINATION_JNDI_KEY = "replyToName" ; 
	private static final String CONNECTION_FACTORY_JNDI_KEY = "jndiConnectionFactoryName" ; 
	private static final String NON_JMS_RECIPIENT_PROPERTY = "nonJMSRecipient" ; 
	
	private static final SimpleJmsPayloadConverter m_payloadConverter = new SimpleJmsPayloadConverter() ;
	
	private MessageConsumer m_MessageConsumer;
	
    private boolean m_bIsTopic = false;
    private boolean m_bNonJMSrecipient ; 

    private Session m_consumerSession;
    private Session m_senderSession;
    private Connection m_JmsConn; 
    private Destination m_replyToDestination;
    private ReentrantLock m_sessionResourcesLock = new ReentrantLock() ; 
    private String m_instanceID; 
    private AsyncResourceReleaser m_resourceReleaser ; 
    
    public FndtXFireJMSClientChannel(final String sUri, final AbstractTransport transport, final XFire xfireEnv){
    	super(sUri, transport, true/*bClientMode*/, xfireEnv) ;
    }//EOM 
    
    public FndtXFireJMSClientChannel() {}//EOM
    
    @Override
    protected final FndtXFireBaseChannel initialize(String sURI) { 

    	//generate the instance id used as the correlation id 
    	//this.m_instanceID = new RandomGUID ().toString();
    	this.m_instanceID = BOJMessaging.generateCorrelationId() ;
    	
    	//valid uri format 
    	//jms:jndi:<queue name>?targetService=<targetServiceName>&jndiConnectionFactory=<jndi connection factory>&replyToName=<queue name>
    	final Pattern VALID_URI_PATTERN = Pattern.compile("jms:jndi:(.*?)\\?(.+)") ; 
    	
    	final Matcher matcher = VALID_URI_PATTERN.matcher(sURI) ;

    	if(!matcher.find()) throw new IllegalArgumentException(String.format(
    			"%s is not a valid Url. Must follow the following format: jms:jndi:<queue name>?targetService=<targetServiceName>&jndiConnectionFactory=<jndi connection factory>&replyToName=<queue name>", 
    			sURI)) ;
    	
    	//extract the request queue jndi name 
    	this.m_sRequestDestinationJndi = matcher.group(1) ;
    	
    	final String sPropertiesString = matcher.group(2) ; 
    	final String[] arrPropertyTuples = sPropertiesString.split(PROPERTY_TUPLE_SPLIT_REGEX) ; 
    	final int iLength = arrPropertyTuples.length ; 
    	
    	for(int i=0; i < iLength; i++) { 
    		this.m_mapPropertiesMap.put(arrPropertyTuples[i], arrPropertyTuples[++i]) ; 
    	}//EO while there are more tuples
    	
    	this.m_bNonJMSrecipient = this.m_mapPropertiesMap.get(NON_JMS_RECIPIENT_PROPERTY).equalsIgnoreCase("true") ;
    	
    	//retrieve the resource releaser from the appcontext via the service locator 
    	try {
    		this.m_resourceReleaser = ServiceLocator.getInstance().getNsetSpringBean("AsyncResourceReleaser", AsyncResourceReleaser.class) ;
    	}catch(Throwable t) { 
    		ExceptionController.getInstance().handleException(t, this) ;
    		//TODO: replace with actual exception
    		throw new RuntimeException(t) ;
    	}//EO catch block 
    	
    	return this ; 
    }//EOM
    
    @Override
    public final void send(final MessageContext context, final OutMessage outmessage) throws XFireException {
    	try{ 
    		//initialise the jms resources for the given session
    		//note, that the connection is shared across all channels 
    		//but each channel shall have its own send and receive sessions 
    		this.initSession(context);
    		
    		//construct the message string (i.e. payload body) 
    		final String sMessasgeString = this.getMessageAsString(context, outmessage) ; 
    		    		
    		//System.out.println("Out Message: " + sMessasgeString);
    		
    		//create the text message set the message in its payload as well as the context's id as the corelation id 
    		final TextMessage jmsMessage = this.m_senderSession.createTextMessage() ; 
    		jmsMessage.setText(sMessasgeString) ;
    		//jmsMessage.setJMSCorrelationID(context.getId());
    		//use the instance id as the correlation id to ensure that the same instance can be invoked multiple times 
    		//without recreating the message consumer (function selectors are readonly)
    		jmsMessage.setJMSCorrelationID(this.m_instanceID) ; 
    		
    		//System.out.println("send Correlation ID is " + context.getId());
    		
    		//attempt to rertieve the request/response destination depending whether client or server context
    		//from the context (server context only) 
    		Destination destination = (Destination) context.getProperty(REPLY_TO_MESSAGE_JMS_PROPERTY_KEY) ;

    		//if the destination was not cached in the context (i.e. client side), create a desntiation now 
    		if(destination == null) { 
    			destination = this.createDestination(this.m_senderSession, this.m_sRequestDestinationJndi) ;
    			
    			//set the reply to queue (which might be the same destination as the request in the 
    			//jms message
    			//Guys 29/12 -> changed the logic to only use the replyto destination if one was defined rather than resorting to the request queue 
    			//this was done as the message type is changed to request for one-way put operations instead of datagram   
        		//final Destination replyToDestination = (this.m_replyToDestination == null ? destination : this.m_replyToDestination) ;
    			if(m_replyToDestination != null) jmsMessage.setJMSReplyTo(this.m_replyToDestination) ;
    			
    			//if(bConfigureSelector) jmsMessage.setJMSType(this.m_sSelector);

    		}//EO if the destination was not cached (client context) 
    		else { 
    			//set the destination property set in the context as the jms message destination
    			jmsMessage.setStringProperty(DESTINATION_PROPERTY_KEY, (String) context.getProperty(DESTINATION_PROPERTY_KEY)) ; 
    			
    		}//EO else if server context (destination id was provided 
    		
    		//set the source channel' UUID as the source 
    		jmsMessage.setStringProperty(SOURCE_PROPERTY_KEY, this.m_instanceID) ;  
			
			//create the produder and send the message 
			this.m_senderSession.createProducer(null).send(destination, jmsMessage) ;
			
			logger.info("Sent message: Source ID: " + m_instanceID  + " Destination: " + destination +  
                    " JMSType: " + jmsMessage.getJMSType());
			
			//start listening to the response 
			 //as the connection should automically be configured to receive incomming msgs 
            //there is no need to start it. 
            this.waitForResponse(sMessasgeString, context.getClient().getTimeout()) ; 
	            
    	}catch (Throwable e){
    		logger.error(e.getMessage());
    		throw new XFireFault("Error sending message", e, XFireFault.SENDER);
    	}finally{ 
    		 
    	}//EO catch block 
    	
    }//EOM
    
    private final void waitForResponse(final String sRequest, Integer iTimeout) throws Throwable { 
    	if(this.m_replyToDestination == null) return ; 
    	
    	final String RECEIVE_JMS_MESSAGE_TRACE = "Commencing receive block on the message correlated to the one just sent." ; 
    	logger.info(RECEIVE_JMS_MESSAGE_TRACE);
        
    	if(iTimeout == null) iTimeout = 5000 ; 
        final Message message = (TextMessage) this.m_MessageConsumer.receive(iTimeout) ;
        
        /*while(message == null) { 
        
        	message = (TextMessage) this.m_MessageConsumer.receiveNoWait() ; 
        	
        	if(++iCounter == 99999) break ;  
        }//EO while the message had not arrived to the sender's reply queue 
*/        
        final String AFTER_RECEIVE_JMS_MESSAGE_BLOCK_TRACE = 
            "Just released from receive message block. Revceived message is:\n" ;  
        logger.info(AFTER_RECEIVE_JMS_MESSAGE_BLOCK_TRACE + message) ;
        
        //check the request for the following errors: 
        //null --> i.e. time out 
        //message containing the MAX_JMS_RECEIVE_BLOCK_INTERVAL --> i.e BG error 
        final String RECEIVE_TIMEOUT_ERROR_MSG = "[%s]: Timeout had occured while waiting for response; request: %s" ;
        if(message ==  null) throw new RuntimeException(String.format(RECEIVE_TIMEOUT_ERROR_MSG, this.getUri(), sRequest)) ;
        else this.onMessage(message) ; 
    	
    }//EOM 
    
    @Override
    public final void onMessage(final Message message) {
    	System.err.println("Received message");
    	
    	try{   
    		//System.out.println("JMS Message :\n" + message);
    		//((TextMessage)message).getText()
    		this.onInnerReceive((String)this.m_payloadConverter.fromMessage(message), message.getJMSCorrelationID(), null/*INTERFACE_TYPES --> need to somehow retrieve the jpa */) ; 
    	}catch (Throwable e){
    		logger.error("Error receiving message " + message, e); 
    	}//EO catch block
    	
    }//EOM 
    
    private final void initSession(final MessageContext context) throws Exception {
    	
    	//if the consumer session was already initialized then the session resources should be resused
    	//as the close session operation is asynchronous due to the slowness of the consumer's disposal 
    	//and a such concurrent operation can be in progress, acquire exclusive lock on the check code section 
    	this.m_sessionResourcesLock.lock() ; 
    	
    	try{ 
	    	if(this.m_consumerSession != null) { 
	    		//CRUCIAL: modify the context message id to this instance's id so as to be able to correlate the response message down the xfire invocation flow  
	    		context.setId(this.m_instanceID) ;
	    		return ;
	    	}//EO if the session is to be reused 
	    	
	    	this.m_sessionResourcesLock.unlock() ; 
	    	
	    	//generate the instance id used as the correlation id 
	    	this.m_instanceID = BOJMessaging.generateCorrelationId() ;
	    	
    		//CRUCIAL: modify the context message id to this instance's id so as to be able to correlate the response message down the xfire invocation flow  
    		context.setId(this.m_instanceID) ;

    		String sReplyToDestination =  null ; 
	    	 
			//retrieve the consumer 
	    	sReplyToDestination= this.m_mapPropertiesMap.get(REPLY_TO_DESTINATION_JNDI_KEY) ;
	    	if(sReplyToDestination  == null || sReplyToDestination.equals(this.m_sRequestDestinationJndi)) sReplyToDestination = null ;
	    	
    		//create n cache the connection factory 
    		//Note: if the sReplyToDestination does not exist (one way) lookup must be qualified so as to ensure that the XA connection factory would be retrieved as  the client must participate in the JTA Tx
	    	//else if the sReplyToDestination exists, lookup must be annonymous so as to ensure that the connection factory would be used 
	    	//in a non-xa manner as otherwise the consumer would wait for the tx to close prior to listening 
	    	//which defies the whole synchronous concept 
    		final String sConnectioFactoryJndi = this.m_mapPropertiesMap.get(CONNECTION_FACTORY_JNDI_KEY) ;
    		
    		//FOR DEBUG --> removed 
    	/*	this.m_JmsConn = ServiceLocator.getInstance().jmsQueueConnectionFactoryLookup(sConnectioFactoryJndi, 
    				(sReplyToDestination == null)bQualifiedLookup).createConnection() ; */
    		
    		this.m_JmsConn = ServiceLocator.getInstance().jmsQueueConnectionFactoryLookup(sConnectioFactoryJndi, 
    				true/*bQualifiedLookup*/).createConnection() ;
    		//FOR DEBUG 
    		
	    	//start the connection 
	    	this.m_JmsConn.start() ; 
	    	//create the consumer and sender sessions 
	    	this.m_senderSession = this.m_JmsConn.createSession(false, Session.AUTO_ACKNOWLEDGE) ; 
	
	    	//final String sServiceName = this.m_mapPropertiesMap.get(TARGET_SERVICE_NAME_KEY) ; 
	        	
	    	//if the context is that of a server, then the consumer should be started on the request queue
	        	
	    	//if the reply to destination is provided and is not the same as the request destination
	    	//create a message consumer and set this instance as the listener
	    	if(sReplyToDestination  != null) {

	    		//create the reply to destination
		    	this.m_consumerSession = this.m_JmsConn.createSession(false, Session.AUTO_ACKNOWLEDGE) ;
		    	
	    		this.m_replyToDestination = this.createDestination(this.m_consumerSession, sReplyToDestination) ;   
	    		
	    		this.m_MessageConsumer = this.m_consumerSession.createConsumer(this.m_replyToDestination, this.createMessageSelector(this.m_instanceID)) ;
	    		//this.m_MessageConsumer = this.m_consumerSession.createConsumer(this.m_replyToDestination) ;
	    		
	    		//this.m_MessageConsumer.setMessageListener(this) ;
	    		
	    	}//EO if the reply to queue is not the same as the request queue 
    	}finally{
    		
    		if(this.m_sessionResourcesLock.isLocked()) this.m_sessionResourcesLock.unlock() ; 
    	}//EO catch block 
    }//EOM
    
    private final String createMessageSelector(final String sCorrelationId) {
        //logger.debug("JMSType='" + this.m_sSelector + "' and Source<>'" + MyID + "'");
        //return "JMSType='" + this.m_sSelector + "' and Source<>'" + MyID + "')";
    	//return String.format("JMSCorrelationID ='%s' and Source<>'%s'", sCorrelationId, MyID) ; 
    	return String.format("JMSCorrelationID ='%s'", sCorrelationId) ;
    }//EOM 
    
    private final Destination createDestination(final Session session, String sDestinationJndi) throws JMSException{ 
    	
    	//if the destination is a non jms recipient and not already configured, configure the destination name 
    	if(m_bNonJMSrecipient && sDestinationJndi.indexOf("?targetClient=") == -1) sDestinationJndi = String.format("queue:///%s?targetClient=1", sDestinationJndi) ; 
    	
    	return (this.m_bIsTopic ? 
    			session.createTopic(sDestinationJndi) : 
    			session.createQueue(sDestinationJndi) 
    	);
    }//EOM 
    
    @Override
    public final void closeSession() {
    	 
    	//as the message consumer close operation is slow, invoke it in another thread of operation 
    	//using the workManager available from from the associated transport.
    	//due to the asynchronous nature of the operation it is possible that the initSession() 
    	//would be invoked prior to the resources release (no avialable thread in the task manager. 
    	//therefore, first nullify the global variables containing the resources 
    	//in a scope of an exclusive lock 
    	this.m_sessionResourcesLock.lock() ;
    	try{ 
    		/*System.out.println("before adding Resource " + this.m_senderSession);
    		System.out.println("before adding Resource " + this.m_MessageConsumer) ; 
    		System.out.println("before adding Resource " + this.m_consumerSession) ;*/
    		
    		this.m_resourceReleaser.addToStack(this.m_senderSession, this.m_MessageConsumer, this.m_consumerSession, this.m_JmsConn) ;  
    		
    		//add all resources to the releaser's stack first  
			this.m_JmsConn = null ; 
			
			this.m_consumerSession = null ; 
			this.m_senderSession = null ;
			this.m_MessageConsumer = null ;
			
			//ensure that the instance id gets generated so that if the instance is placed back in the pool 
			//and retrieved, it would not receive any messages left on the response queue by subsequent invocations (due to time out for instance) 
			this.m_instanceID = null ;
			
			//unlock the session 
			this.m_sessionResourcesLock.unlock() ; 
			
		}catch(Throwable t) { 
			throw new XFireRuntimeException(String.format("Error closing client's session", t)) ;
    	}finally{  
    		if(this.m_sessionResourcesLock.isLocked()) this.m_sessionResourcesLock.unlock() ; 
		}//EO catch block 
    }//EOM 
    
    
    /*
    @Override
    public final void closeSession() {
    	
    	 
    	//as the message consumer close operation is slow, invoke it in another thread of operation 
    	//using the workManager available from from the associated transport.
    	//due to the asynchronous nature of the operation it is possible that the initSession() 
    	//would be invoked prior to the resources release (no avialable thread in the task manager. 
    	//therefore, first nullify the global variables containing the resources 
    	//in a scope of an exclusive lock 
    	this.m_sessionResourcesLock.lock() ;
    	try{ 
			//move all variables to method scope first 
			this.m_JmsConn = null ; 
			final Session consumerSession = this.m_consumerSession ;
			final Session senderSession  = this.m_senderSession ;
			final MessageConsumer messageConsumer = this.m_MessageConsumer ;
			
			this.m_consumerSession = null ; 
			this.m_senderSession = null ;
			this.m_MessageConsumer = null ;
			//ensure that the instance id gets generated so that if the instance is placed back in the pool 
			//and retrieved, it would not receive any messages left on the response queue by subsequent invocations (due to time out for instance) 
			this.m_instanceID = null ;
			
			//unlock the session 
			this.m_sessionResourcesLock.unlock() ; 
		
			
		}catch(Throwable t) { 
			throw new XFireRuntimeException(String.format("Error closing client's session", t)) ;
    	}finally{  
    		if(this.m_sessionResourcesLock.isLocked()) this.m_sessionResourcesLock.unlock() ; 
		}//EO catch block 
    }//EOM 
    */ 
    
    @Override
    public void close() { super.close(); }//EOM 
        
    @Override
    public final void dispose() {
    	super.dispose();
    	this.closeSession() ; 
    	this.m_JmsConn = null ; 
    	this.m_sessionResourcesLock = null ; 
    	this.m_bIsTopic = false ; 
    }//EOM 
    
    @Override
    public final String toString() { 
    	return String.format("JMS Channel for %s Service: [Request Dest: %s, Repsonse Dest: %s, ConnFactory: %s]", 
    			this.m_mapPropertiesMap.get(TARGET_SERVICE_NAME_KEY), 
    			this.m_sRequestDestinationJndi, 
    			this.m_mapPropertiesMap.get(REPLY_TO_DESTINATION_JNDI_KEY), 
    			this.m_mapPropertiesMap.get(CONNECTION_FACTORY_JNDI_KEY) 
    		);
    }//EOM
    
    public static void main(String[] args) {
		
    	final String sURI = "jms:jndi:Q_OUT_XCT?targetServiceName=MessageSubmitService;jndiConnectionFactory=FUNDTECH.QM;replyToName=Q_SUBATCH_GEN" ; 

    	System.out.println(new FndtXFireJMSClientChannel().initialize(sURI)) ;
	}//EOM
	
}//EOC
