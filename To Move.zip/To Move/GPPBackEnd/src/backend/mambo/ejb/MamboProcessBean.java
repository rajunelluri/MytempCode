package backend.mambo.ejb;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;

import backend.businessobject.BOInterface;
import backend.businessobject.proxies.BOProxy;
import backend.businessobject.proxies.interceptors.InterceptorSetType;
import backend.core.SuperSLSB;
import backend.mambo.ejbinterfaces.MamboProcess;
import backend.mambo.ejbinterfaces.MamboProcessLocal;
import backend.mambo.businessobjects.BOMamboProcess;


import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;


/**
 * XDoclet-based session bean.  The class must be declared
 * public according to the EJB specification.
 *
 * To generate the EJB related files to this EJB:
 *		- Add Standard EJB module to XDoclet project properties
 *		- Customize XDoclet configuration for your appserver
 *		- Run XDoclet
 *
 * Below are the xdoclet-related tags needed for this EJB.
 * 
 * @ejb.bean name="MamboProcess"
 *           display-name="Name for MamboProcess"
 *           description="Description for MamboProcess"
 *           jndi-name="ejb/MamboProcessBean"
 *           local-jndi-name="ejb/MamboProcessBeanLocal"
 *           type="Stateless"
 *           view-type="both"
 *           transaction-type="Bean"
 *           common-business-interface="true" 
 * 
 *  @ejb.business.interface         
 *           
 * @ejb.resource-ref jndi-name="${datasource.jndi}"
 *           res-ref-name="${datasource.jndi}"   
 *           res-type="javax.sql.DataSource"
 *           res-auth="Application"
 */
@Stateless
public class MamboProcessBean extends SuperSLSB<MamboProcess> implements MamboProcessLocal, MamboProcess{
 

	public MamboProcessBean(){ super(backend.mambo.businessobjects.BOMamboProcess.class,InterceptorSetType.Complete);}//EOM 

	 
	/**
	 * Get account explorer 
	 * @param sSessionID - user's session id
	 * @return - account explorer
	 * 
	 * @ejb.business  
	 */
	public Feedback executeChannelInFlow(final Admin admin,String mid){
		return m_bo.executeChannelInFlow(admin,mid);
	}
	
	public Feedback executeHubInFlow(final Admin admin, String mid){
		return m_bo.executeHubInFlow(admin,mid);
	}
	
}