package backend.mambo.validation;

import com.fundtech.core.paymentprocess.data.MamboConstantsInterface;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.security.Admin;
import com.fundtech.util.ErrorAuditInputData;
import com.fundtech.util.GlobalConstants;

import backend.paymentprocess.erroraudit.ErrorAuditUtils;
import com.fundtech.util.datetime.DateAndZone;
import com.fundtech.util.datetime.NewASDateTimeUtils;


public class InternalError {
	private int code;
	private Object[] parameters;
	private String errorText;
	
	
	
	public int getCode() {
		return code;
	}

	public Object[] getParameters() {
		return parameters;
	}


	public InternalError(int code,Object[] parameters) {
		this.code = code;
		this.parameters = parameters != null ? parameters : new Object[0];			
	}
	
	public String getErrorText() {
		if (errorText == null)
			errorText = ErrorAuditUtils.getInstance().loadErrorAuditText((long)code,parameters);
		
		return errorText;
	}
	
	public void reportInternalError(PDO pdo, String activity) {
		Admin admin = (Admin)Admin.getContextAdmin();
		String office = pdo==null ? GlobalConstants.DEFAULT_SERVER_OFFICE_NAME : pdo.getString(PDOConstantFieldsInterface.P_OFFICE);
		String user = pdo==null? "" : pdo.getString(MamboConstantsInterface.X_MAM_CRED_USER_ID);
				
		ErrorAuditInputData eaInputData = new ErrorAuditInputData(true, admin.getSessionID(), "",user, office , activity, activity, admin.getClientRemoteAddress());

		DateAndZone dateAndZone = NewASDateTimeUtils.getCurrentDateAndZoneByOffice(office);
		eaInputData.setUserStartDateAndTime(dateAndZone.getDate());

		eaInputData.setErrorCode((long) this.code);
		eaInputData.setNonPaymentsFields(this.parameters);
		ErrorAuditUtils.handleErrorAndAudit(eaInputData);
	}
}//InternalError