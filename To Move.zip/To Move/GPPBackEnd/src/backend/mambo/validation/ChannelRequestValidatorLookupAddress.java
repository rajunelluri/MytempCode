package backend.mambo.validation;


import backend.mambo.dataaccess.dao.BPAYAddress;
import backend.mambo.dataaccess.dao.DAOBpayAddress;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.errors.ProcessErrorConstants;



public class ChannelRequestValidatorLookupAddress extends ChannelRequestValidator{

	ChannelRequestValidatorLookupAddress(PDO pdo) {
		super(pdo);
	}

	@Override
	public boolean validateContent() {
		boolean valid = true;

		//office validation
		String office = pdo.getString(PDOConstantFieldsInterface.P_OFFICE);
		boolean isOfficeValid = isOfficeValid(office);
		if (!isOfficeValid){
			InternalError fiidErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_MISSING_FIID_FOR_OFFICE,new Object[]{office});
			addInternalError(fiidErr);
			valid = false;
		}
		

		//Check the <OrgtrSchmeAdrId><Id>:
		String ortrSchmeAdrId = pdo.getString("X_MAM_ORGTR_SCHME_ADR_ID");
		String clientId = pdo.getString("X_MAM_CLIENT_ID");
		DAOBpayAddress daoBpayAddress = DAOBpayAddress.getInstance();
		BPAYAddress bpayAddressRecord= daoBpayAddress.getBPAYAddress(ortrSchmeAdrId);//gets bpay address only if recStatus='AC'
		//Check that address is defined in GPP DB (with rec status ="AC")
		if (bpayAddressRecord==null){
			//90014
			InternalError fiidErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_ADDRESS_NOT_EXIST,new Object[]{ortrSchmeAdrId});
			addInternalError(fiidErr);
			valid = false;
		}else{
			//address status in DB != 'ACTV' - report error
			if (!"ACTV".equals(bpayAddressRecord.getAddressSts())){
				//90015
				InternalError fiidErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_ADDRESS_STATUS,new Object[]{bpayAddressRecord.getAddressSts(),ortrSchmeAdrId,"Lookup Address"});
				addInternalError(fiidErr);
				valid = false;
			}
			//client of address from DB != Client ID received in input request - report error
			if (!clientId.equals(bpayAddressRecord.getClientId())){
				//90016
				InternalError fiidErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_ADDRESS_CLIENT,new Object[]{ortrSchmeAdrId,bpayAddressRecord.getClientId(),clientId});
				addInternalError(fiidErr);
				valid = false;
			}
			//office of address from DB != Office derived for the input request - report error
			if (!office.equals(bpayAddressRecord.getOffice())){
				//90017
				InternalError fiidErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_ADDRESS_OFFICE,new Object[]{bpayAddressRecord.getOffice(),ortrSchmeAdrId,office});
				addInternalError(fiidErr);
				valid = false;
			}
		}
		
		//Check that either the BPAY Address Identifier <SchmeAdrId><Id> or the Address Display Name <DispNm> is present (and not 
		String enquiredBpayAddress = pdo.getString(new Object[]{"X_MAM_SCHME_ADR_GROUP",0,"X_MAM_SCHME_ADR_ID"});
		String enquiredDispName = pdo.getString("X_MAM_DISP_NM");
		
		
		//both enquiredBpayAddress and enquiredDispName exist - report error
		if ((enquiredBpayAddress!=null)&&(enquiredDispName!=null)){
			//90026
			InternalError fiidErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_TAG_NOT_ALLOWED_WHEN_OTHER_TAG_EXISTS,new Object[]{"(DispNm)","(SchmeAdrId.Id)"});
			addInternalError(fiidErr);
			valid = false;
		}
		//neither one of enquiredBpayAddress or enquiredDispName exist - report error
		if ((enquiredBpayAddress==null)&&(enquiredDispName==null)){
			//90029
			InternalError fiidErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_AT_LEAST_ONE_TAG_SHOULD_EXIST,new Object[]{"(SchmeAdrId.Id)","(DispNm)"});
			addInternalError(fiidErr);
			valid = false;
		}
		

		String context = pdo.getString("X_MAM_CNTXT");
		//context exists and enquired address doesn't exist - report error
		if ((context!=null)&&(enquiredBpayAddress==null)){
			//90025
			InternalError fiidErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_TAG_MANDATORY_WHEN_OTHER_TAG_EXISTS,new Object[]{"(SchmeAdrId.Id)","(Cntxt)"});
			addInternalError(fiidErr);
			valid = false;
		}
		//context exists and enquiredDispName exists - report error
		if ((context!=null)&&(enquiredDispName!=null)){
			//90026
			InternalError fiidErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_TAG_NOT_ALLOWED_WHEN_OTHER_TAG_EXISTS,new Object[]{"(DispNm)","(Cntxt)"});
			addInternalError(fiidErr);
			valid = false;
		}

		
		
		return valid;
	}

	@Override
	public String getServiceName() {
		return "Lookup Address";
	}

}
