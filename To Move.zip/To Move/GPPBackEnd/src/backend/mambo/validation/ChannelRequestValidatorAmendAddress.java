
package backend.mambo.validation;

import backend.mambo.dataaccess.dao.BPAYAddress;
import static backend.mambo.dataaccess.dao.DAOBpayAddress.*;
import backend.mambo.dataaccess.dao.DAOBpayAddress;

import com.fundtech.core.paymentprocess.data.MamboConstantsInterface;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.errors.ProcessErrorConstants;

public class ChannelRequestValidatorAmendAddress extends ChannelRequestValidator {

	ChannelRequestValidatorAmendAddress(PDO pdo) {
		super(pdo);
	}

	@Override
	public boolean validateContent() {
		boolean valid = true;

		//office validation
		String office = pdo.getString(PDOConstantFieldsInterface.P_OFFICE);
		valid = validateOffice(office);
		
		String addressId = pdo.getString(MamboConstantsInterface.X_MAM_ORGTR_SCHME_ADR_ID);
		BPAYAddress bpayAddress = validateBPayAddressExists(addressId);
		
		if (bpayAddress == null) {
			return false;
		}
		
		
		valid = validateBPayAddress( bpayAddress
							,pdo.getString(MamboConstantsInterface.X_MAM_CLIENT_ID) //expected client id 
							,new String[]{DAOBpayAddress.ACTIVE_ADDRESS_STATUS,DAOBpayAddress.INACTIVE_ADDRESS_STATUS}); //expected statues
		
		String currestStatus = bpayAddress.getAddressSts();
		String newStatus = pdo.getString(MamboConstantsInterface.X_MAM_ADR_STS);
		
		if (!	((ACTIVE_ADDRESS_STATUS.equals(currestStatus) && INACTIVE_ADDRESS_STATUS.equals(newStatus))
			  || (INACTIVE_ADDRESS_STATUS.equals(currestStatus) && ACTIVE_ADDRESS_STATUS.equals(newStatus)))) {
			InternalError fiidErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_AMEND_ADDRESS_INVALID_ACTION,new Object[]{currestStatus,newStatus});
			addInternalError(fiidErr);
			valid = false;
		}
		
		return valid;
	}
		
	@Override
	public String getServiceName() {			
		return "Amend Address";
	}
}
