package backend.mambo.validation;

import backend.mambo.dataaccess.dao.DAOBpayAddress;

import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.cache.syspar.SystemParametersInterface;
import com.fundtech.core.paymentprocess.data.MamboConstantsInterface;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.errors.ProcessErrorConstants;
import com.fundtech.util.GlobalConstants;

public class ChannelRequestValidatorReserveAddress extends ChannelRequestValidator{

		ChannelRequestValidatorReserveAddress(PDO pdo) {
			super(pdo);
		}
		
		@Override
		public boolean validateContent() {	
			boolean valid = true;
			
			String office = pdo.getString(PDOConstantFieldsInterface.P_OFFICE);
			valid = isOfficeValid(office);
			if (!valid){
				InternalError fiidErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_MISSING_FIID_FOR_OFFICE,new Object[]{office});
				addInternalError(fiidErr);
			}
			
			boolean isPersitentRsrv = pdo.getBoolean(MamboConstantsInterface.X_MAM_PERSISTENT);
			int nbReqRsrvAds = Integer.parseInt(pdo.getString(MamboConstantsInterface.X_MAM_NB_OF_ADRS));
			if (isPersitentRsrv){
				int maxPstntRsrvForFI = Integer.parseInt(CacheKeys.SystParKey.getSingle(GlobalConstants.DEFAULT_SERVER_OFFICE_NAME, SystemParametersInterface.SYST_PAR_MAX_NB_OF_PSTNT_ADR_RSRV).getParmValue());
				int currentlyPstntRsrvHeldByFI = DAOBpayAddress.getInstance().getNbPstntRsrvForFI(pdo.getString(PDOConstantFieldsInterface.P_OFFICE));
				int minPstntRsrvInReq = 1;
				if (((currentlyPstntRsrvHeldByFI+nbReqRsrvAds) > maxPstntRsrvForFI)||(nbReqRsrvAds<minPstntRsrvInReq)){
					InternalError pstntLimErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_EXCEEDS_LIMITS_OF_PSTNT_ADR_RSRV_FOR_FI,new Object[]{String.valueOf(nbReqRsrvAds),String.valueOf(currentlyPstntRsrvHeldByFI),String.valueOf(maxPstntRsrvForFI)});
					addInternalError(pstntLimErr);
					valid = false;
				}
			}else{
				int maxLimitNonPstntRsrvForReq = Integer.parseInt(CacheKeys.SystParKey.getSingle(GlobalConstants.DEFAULT_SERVER_OFFICE_NAME, SystemParametersInterface.SYST_PAR_MAX_NB_OF_NN_PSTNT_ADR_RSRV).getParmValue());
				int minLimitNonPstntRsrvForReq = 1;
				if ((nbReqRsrvAds < minLimitNonPstntRsrvForReq)||(nbReqRsrvAds > maxLimitNonPstntRsrvForReq)){
					InternalError nonPstntLimErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_EXCEEDS_LIMITS_OF_NON_PSTNT_ADR_RSRV_FOR_REQ,new Object[]{String.valueOf(nbReqRsrvAds),String.valueOf(maxLimitNonPstntRsrvForReq)});
					addInternalError(nonPstntLimErr);
					valid = false;
				}
			}
			return valid;
		}

		@Override
		public String getServiceName() {			
			return "Reserve Address";
		}

}
