package backend.mambo.validation;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;

public class ChannelRequestValidatorFactory {
	
	private ChannelRequestValidatorFactory(){
		
	}

	public static ChannelRequestValidator getChannelRequestValidator(PDO pdo){
		String msgType = pdo.getString(PDOConstantFieldsInterface.P_MSG_TYPE);
		if (msgType.equals("MAMBO_FTM401")){
			return new ChannelRequestValidatorReserveAddress(pdo);
		}
		if (msgType.equals("MAMBO_FTM411")){
			return new ChannelRequestValidatorCreateAddress(pdo);
		}
		if (msgType.equals("MAMBO_FTM451")){
			return new ChannelRequestValidatorLookupAddress(pdo);
		}
		if (msgType.equals("MAMBO_FTM441")){
			return new ChannelRequestValidatorAmendAddress(pdo);
		}

		return null;
	}
	
}
