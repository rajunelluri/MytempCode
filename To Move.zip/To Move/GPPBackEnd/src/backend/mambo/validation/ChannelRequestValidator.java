package backend.mambo.validation;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.apache.xmlbeans.impl.values.XmlObjectBase;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Node;

import backend.core.module.security.dataaccess.dao.DAOSecurity;
import backend.dataaccess.dto.DTODataHolder;
import backend.mambo.dataaccess.dao.BPAYAddress;
import backend.mambo.dataaccess.dao.DAOBpayAddress;

import com.fundtech.cache.entities.Banks;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.paymentprocess.data.MamboConstantsInterface;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.das.DASInterface;
import com.fundtech.core.paymentprocess.data.das.DASInterface.XmlLocationType;
import com.fundtech.core.paymentprocess.data.paymenttypes.PaymentType;
import com.fundtech.errors.ProcessErrorConstants;
import com.fundtech.scl.commonTypes.FreeFormTextType;
import com.fundtech.util.GlobalConstants;


public abstract class ChannelRequestValidator {
		protected static final Logger logger = LoggerFactory.getLogger(ChannelRequestValidator.class);

		protected PDO pdo;		
		protected List<String> schemaValidationErrors;
				
		protected XmlObjectBase rawRequest;
		
		protected List<InternalError> internalErrors;
		
		ChannelRequestValidator(PDO pdo) {
			this.pdo = pdo;
		}
		

		public boolean validateSchema() {
			schemaValidationErrors = pdo.validateXml(XmlLocationType.XML_ORIG_MSG);		
			return schemaValidationErrors == null;
		}

		public boolean validateUserRole() {
			final String COLUMN_USERS_USER_ID = "USER_ID";
			final String COLUMN_USERS_OFFICE = "OFFICE";
			final String COLUMN_USERS_DEPARTMENT = "DEPARTMENT";
			final String COLUMN_USERS_U_ENT_NAME = "U_ENT_NAME";
			final String COLUMN_USERS_REC_STATUS = "REC_STATUS";
			final String COLUMN_USERS_SUSPENDED = "SUSPENDED";
			
			String sMsgUserId = pdo.getString(MamboConstantsInterface.X_MAM_CRED_USER_ID);
			String sMsgUserRole = pdo.getString(MamboConstantsInterface.X_MAM_CRED_USER_ROLE);	
			
			DTODataHolder dtoUsers = new DAOSecurity().getUserData(sMsgUserId);
			
			HashMap hmData = dtoUsers.getDataRow();

			// User name.
			String sUserId = (String) hmData.get(COLUMN_USERS_USER_ID);
			// User role
			String sUserRole = (String) hmData.get(COLUMN_USERS_U_ENT_NAME);
			// Record Status
			String sRecSts = (String) hmData.get(COLUMN_USERS_REC_STATUS);
			// Record Suspended
			String sUserSusp = (String) hmData.get(COLUMN_USERS_SUSPENDED);
		
			if ((!sMsgUserId.equals(sUserId)) || (!sMsgUserRole.equals(sUserRole)) || (!"AC".equals(sRecSts)) || (!"0".equals(sUserSusp))){
				InternalError userOrRoleErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_USER_OR_ROLE,new Object[]{sMsgUserId,sMsgUserRole});
				addInternalError(userOrRoleErr);
				return false;
			}
			
			
			// Office.
			String sUserOffice = (String) hmData.get(COLUMN_USERS_OFFICE);
			// Department.
			String sUserDepartment = (String) hmData.get(COLUMN_USERS_DEPARTMENT);
			
			//verify that user office matches interface office
			String currentOffice = pdo.getString(PDOConstantFieldsInterface.P_OFFICE);
			if (!currentOffice.equals(sUserOffice)){
				InternalError userOrRoleErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_USER_OR_ROLE,new Object[]{sMsgUserId,sMsgUserRole});
				addInternalError(userOrRoleErr);
				return false;
			}
			
			logger.info("User and Role validation succeeded");

			pdo.set(PDOConstantFieldsInterface.P_DEPARTMENT,  sUserDepartment) ;
			
			logger.info("Office and Department were derived from User. Office is:"+sUserOffice+" and department is:"+sUserDepartment);

			return true;
		}
		
		public abstract boolean validateContent();
		public abstract String getServiceName(); 
		
		protected boolean isOfficeValid(String office){ 
			boolean valid = true;
			Banks bank = CacheKeys.banksKey.getSingle(office);
			if (bank!=null){
				String bankName = bank.getReferencebranch();
				if ((bankName==null)||(bankName.equals(GlobalConstants.EMPTY_STRING))){	
					valid = false;
				}
			}
			return valid;
		}

		
		public List<String> getSchemaValidationErrors() {
			return schemaValidationErrors;
		}
		
		public void processSchemaValidationErrors() {
			boolean invalidPDO = processInvalidPDO();
			
			if (invalidPDO && processInvalidXml())
				return;
			
			if (invalidPDO && processInvalidDocumentType())
				return;
			
			if (processInvalidInstructionID())
				return;
			
			processInvalidContent();
		}
		
		private boolean processInvalidPDO() {
			if (!isInvalidPDO())
				return false;
			
			String invalidPayload = getInvalidPDOPayload();
			
			try {
				rawRequest = (XmlObjectBase) PaymentType.m_contextXchemaTypeLoader.parse(invalidPayload,null/*targetSchemaType*/,null/*xmloptions*/);
			} catch (Exception e) {
				rawRequest = null;
			}
			
			return true;
		}

		private boolean processInvalidXml() {
			if (rawRequest != null)
				return false;
			InternalError invalidXmlError = new InternalError(ProcessErrorConstants.ERR_INVALID_XML,null);
			invalidXmlError.reportInternalError(null,"XML validation");
			
			return true;
		}

		private boolean processInvalidDocumentType() {			
			Node actualRoot = rawRequest.getDomNode() ; 			
			if(actualRoot.getNodeType() == Node.DOCUMENT_NODE) 
				actualRoot = actualRoot.getFirstChild() ; 
			String qname = "{"+actualRoot.getNamespaceURI()+"}"+ actualRoot.getLocalName() ;
			
			InternalError undefMsgTypeError = new InternalError(ProcessErrorConstants.ERR_UNIDENTIFIED_MESSAGE_TYPE,new Object[]{qname});
			undefMsgTypeError.reportInternalError(null,"XML validation");
			
			return false;
		}
		
		private boolean processInvalidInstructionID() {		
			String instID = (String)pdo.get(MamboConstantsInterface.X_MAM_INSTR_ID);
			if (instID != null && instID.length() > 0)
				return false;

			InternalError invalidInstrIdError = new InternalError(ProcessErrorConstants.ERR_INVALID_INSTRUCTION_ID,null);
			invalidInstrIdError.reportInternalError(null, "XML validation");
			return true;
		}
		
		private boolean processInvalidContent() {
			if (schemaValidationErrors == null || schemaValidationErrors.isEmpty())
				return false;
			
			for (int i=0;i<schemaValidationErrors.size();i++){ 
				addInternalError(new InternalError(ProcessErrorConstants.ERR_BAD_XML_CONTENT, new Object[]{schemaValidationErrors.get(i)}));
			}
			
			return false;
		}
		
				
		private boolean isInvalidPDO() {
			XmlObjectBase originalMessage = pdo.getXml(DASInterface.ORIG_XML_MSG_KEY) ;
			if (originalMessage instanceof FreeFormTextType) {
		    	FreeFormTextType fft = (FreeFormTextType)originalMessage;
		    	if ("INVALID".equalsIgnoreCase(fft.getType())) 
		    		return true;
			}
			return false;		
		}
		
		private String getInvalidPDOPayload() {
			XmlObjectBase originalMessage = pdo.getXml(DASInterface.ORIG_XML_MSG_KEY) ;
			return ((FreeFormTextType)originalMessage).xgetPayload().getStringValue();
		}
		
		public void addInternalError(InternalError error) {
			if (error == null)
				return;
			if (internalErrors==null)
				internalErrors = new ArrayList<InternalError>();
			internalErrors.add(error);
		}
		
		public boolean containsInternalErrors() {
			return internalErrors != null && !internalErrors.isEmpty();
		}
		
		public void processInternalErrors(PDO responsePDO) {
			if (!containsInternalErrors())
				return;
				
			responsePDO.set(MamboConstantsInterface.X_MAM_RESP_STS,MamboConstantsInterface.REJECTED_RESPONSE_STATUS);
			
			for (int i=0; i<internalErrors.size() ; i++) {				
				InternalError iError = internalErrors.get(i);
				
				//set internal error code
				responsePDO.set((Object)String.valueOf(iError.getCode()),new Object[]{MamboConstantsInterface.X_MAM_RESP_STS_RSN_GROUP, i, MamboConstantsInterface.X_MAM_RESP_INTR_STS_RSN_CODE});
				
				//set internal error text
				responsePDO.set((Object)iError.getErrorText(),new Object[]{MamboConstantsInterface.X_MAM_RESP_STS_RSN_GROUP, i, MamboConstantsInterface.X_MAM_RESP_INTR_ERR_TEXT});
				
				//set error origin to 'internal'
				responsePDO.set((Object)MamboConstantsInterface.ERROR_ORIGIN_INTERNAL,new Object[]{MamboConstantsInterface.X_MAM_RESP_STS_RSN_GROUP, i, MamboConstantsInterface.X_MAM_RESP_ERR_ORIGIN});
			}
		}
		
		protected boolean validateOffice(String office) {
			boolean isOfficeValid = isOfficeValid(office);
			if (!isOfficeValid){
				InternalError fiidErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_MISSING_FIID_FOR_OFFICE,new Object[]{office});
				addInternalError(fiidErr);
				return false;
			}
			
			return true;
		}

		protected BPAYAddress validateBPayAddressExists(String addressId) {
			DAOBpayAddress daoBpayAddress = DAOBpayAddress.getInstance();
			BPAYAddress bpayAddressRecord= daoBpayAddress.getBPAYAddress(addressId);//gets bpay address only if recStatus='AC'

			if (bpayAddressRecord==null){//Entry does not exist in DB - report error
				InternalError notExistErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_ADDRESS_NOT_EXIST,new Object[]{addressId});
				addInternalError(notExistErr);				
				return null;
			}
			
			return bpayAddressRecord;
		}
		/**
		 * execute asserts on expected exists address
		 */
		protected boolean validateBPayAddress(BPAYAddress bpayAddressRecord,String expectedClientId,String[] expectedStatues) {
			boolean valid = true;
			
			if (expectedClientId != null) {
				if (! pdo.getString(MamboConstantsInterface.X_MAM_CLIENT_ID).equals(bpayAddressRecord.getClientId())){
					//Record client != request client - Report error
					InternalError clntErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_ADDRESS_CLIENT,new Object[]{bpayAddressRecord.getAddressId(),bpayAddressRecord.getClientId(),pdo.getString(MamboConstantsInterface.X_MAM_CLIENT_ID)});
					addInternalError(clntErr);
					valid = false;
				}
			}
			
			if (! pdo.getString(PDOConstantFieldsInterface.P_OFFICE).equals(bpayAddressRecord.getOffice())){
				//Record office != request office - Report error
				InternalError officeErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_ADDRESS_OFFICE,new Object[]{bpayAddressRecord.getOffice(),bpayAddressRecord.getAddressId(),pdo.getString(PDOConstantFieldsInterface.P_OFFICE)});
				addInternalError(officeErr);
				valid = false;
			}
			
			
			if (expectedStatues != null) {
				if (! Arrays.asList(expectedStatues).contains(bpayAddressRecord.getAddressSts())) {
					InternalError stsErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_ADDRESS_STATUS,new Object[]{bpayAddressRecord.getAddressSts(),bpayAddressRecord.getAddressId(),getServiceName()});
					addInternalError(stsErr);
					valid = false;
				}
			}
			
			return valid;
		}
}
