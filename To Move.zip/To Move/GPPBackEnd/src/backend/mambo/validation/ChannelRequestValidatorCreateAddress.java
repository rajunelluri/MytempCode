package backend.mambo.validation;


import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import backend.mambo.dataaccess.dao.BPAYAddress;
import backend.mambo.dataaccess.dao.DAOBpayAddress;

import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.cache.syspar.SystemParametersInterface;
import com.fundtech.core.paymentprocess.data.MamboConstantsInterface;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.errors.ProcessErrorConstants;
import com.fundtech.util.GlobalConstants;


public class ChannelRequestValidatorCreateAddress extends ChannelRequestValidator{

	ChannelRequestValidatorCreateAddress(PDO pdo) {
		super(pdo);
	}


	@Override
	public boolean validateContent() {
		boolean valid = true;

		//office validation
		String office = pdo.getString(PDOConstantFieldsInterface.P_OFFICE);
		boolean isOfficeValid = isOfficeValid(office);
		if (!isOfficeValid){
			InternalError fiidErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_MISSING_FIID_FOR_OFFICE,new Object[]{office});
			addInternalError(fiidErr);
			valid = false;
		}

		//if bpay address is provided in input, validate:
		//	Exists already as entry in BPAY_ADDRESS table in GPP DB, and:
		// recorde status = "AC"
		//i.	Holds address status of 'Reserved'. 
		//ii.	Is linked to same Client ID as <ClntId> received in input request. 
		//iii.	Defined in the same Office as the Office derived for the input request
		//iv.	Is not expired, as per the EXPIRATION_TIME attribute of the entry.
		String addressId = pdo.getString(new Object[]{MamboConstantsInterface.X_MAM_SCHME_ADR_GROUP, 0, MamboConstantsInterface.X_MAM_SCHME_ADR_ID}); 
		if (addressId!=null){//Address exists in message 
			DAOBpayAddress daoBpayAddress = DAOBpayAddress.getInstance();
			BPAYAddress bpayAddressRecord= daoBpayAddress.getBPAYAddress(addressId);//gets bpay address only if recStatus='AC'

			if (bpayAddressRecord==null){//Entry does not exist in DB - report error

				InternalError notExistErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_ADDRESS_NOT_EXIST,new Object[]{addressId});
				addInternalError(notExistErr);
				valid = false;

			}else{//Entry exists in DB

				if (! DAOBpayAddress.RSVD_ADDRESS_STATUS.equals(bpayAddressRecord.getAddressSts())){
					//Record status != 'Reserved' - Report error
					InternalError stsErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_ADDRESS_STATUS,new Object[]{bpayAddressRecord.getAddressSts(),addressId,"Create Address"});
					addInternalError(stsErr);
					valid = false;
				}
				if (! pdo.getString(MamboConstantsInterface.X_MAM_CLIENT_ID).equals(bpayAddressRecord.getClientId())){
					//Record client != request client - Report error
					InternalError clntErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_ADDRESS_CLIENT,new Object[]{addressId,bpayAddressRecord.getClientId(),pdo.getString(MamboConstantsInterface.X_MAM_CLIENT_ID)});
					addInternalError(clntErr);
					valid = false;
				}
				if (! pdo.getString(PDOConstantFieldsInterface.P_OFFICE).equals(bpayAddressRecord.getOffice())){
					//Record office != request office - Report error
					InternalError officeErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_ADDRESS_OFFICE,new Object[]{bpayAddressRecord.getOffice(),addressId,office});
					addInternalError(officeErr);
					valid = false;
				}
				if ((bpayAddressRecord.getExpirationTime()!=null)&&(new Date().after(bpayAddressRecord.getExpirationTime()))){
					//Record expiration date has passed - Report error
					InternalError expErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_ADDRESS_EXPIRED,new Object[]{addressId});
					addInternalError(expErr);
					valid = false;
				}
			}
		}//EO (AddressId != null)


		if (pdo.getString(MamboConstantsInterface.X_MAM_SCHME_ADR_TP)!=null){
			if (MamboConstantsInterface.ADDRESS_TYPE_INDV.equals(pdo.getString(MamboConstantsInterface.X_MAM_SCHME_ADR_TP))){
				//AdrTp=INDV
				if (pdo.get(new Object[]{MamboConstantsInterface.X_MAM_ACCPTD_ACCT_OPT, 0, MamboConstantsInterface.X_MAM_ACCPTD_ACCT_TP})!=null){
					//AcctTp is present - report error
					InternalError tagErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_TAG_NOT_ALLOWED_WITH_OTHER_TAG,new Object[]{"(AcctTp)","(AdrTp)",MamboConstantsInterface.ADDRESS_TYPE_INDV});
					addInternalError(tagErr);
					valid = false;
				}
				if (pdo.get(new Object[]{MamboConstantsInterface.X_MAM_ACCPTD_ACCT_OPT, 0, MamboConstantsInterface.X_MAM_MIN_ACCPTD})!=null){
					//MinAmtAccptd is present - report error
					InternalError tagErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_TAG_NOT_ALLOWED_WITH_OTHER_TAG,new Object[]{"(MinAmtAccptd)","(AdrTp)",MamboConstantsInterface.ADDRESS_TYPE_INDV});
					addInternalError(tagErr);
					valid = false;
				}
				if (pdo.get(new Object[]{MamboConstantsInterface.X_MAM_ACCPTD_ACCT_OPT, 0, MamboConstantsInterface.X_MAM_MAX_ACCPTD})!=null){
					//MaxAmtAccptd is present - report error
					InternalError tagErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_TAG_NOT_ALLOWED_WITH_OTHER_TAG,new Object[]{"(MaxAmtAccptd)","(AdrTp)",MamboConstantsInterface.ADDRESS_TYPE_INDV});
					addInternalError(tagErr);
					valid = false;
				}
				if (pdo.getString(MamboConstantsInterface.X_MAM_DISP_TXT)!=null){
					//DispTxt is present - report error
					InternalError tagErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_TAG_NOT_ALLOWED_WITH_OTHER_TAG,new Object[]{"(DispTxt)","(AdrTp)",MamboConstantsInterface.ADDRESS_TYPE_INDV});
					addInternalError(tagErr);
					valid = false;
				}
				if (pdo.getString(MamboConstantsInterface.X_MAM_DISP_URL)!=null){
					//DispURL is present - report error
					InternalError tagErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_TAG_NOT_ALLOWED_WITH_OTHER_TAG,new Object[]{"(DispURL)","(AdrTp)",MamboConstantsInterface.ADDRESS_TYPE_INDV});
					addInternalError(tagErr);
					valid = false;
				}
				if (!"0001".equals(pdo.getString(MamboConstantsInterface.X_MAM_CHRG_CTGY))){
					//ChrgCtgy!='0001' - report error
					InternalError tagErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_TAG_VALUE_NOT_ALLOWED_WITH_OTHER_TAG,new Object[]{"(ChrgCtgy)",pdo.getString(MamboConstantsInterface.X_MAM_CHRG_CTGY),"(AdrTp)",MamboConstantsInterface.ADDRESS_TYPE_INDV});
					addInternalError(tagErr);
					valid = false;
				}
				if (pdo.countOccurrences(MamboConstantsInterface.X_MAM_OTHR_ID)!=0){
					//OthrId is present - report error
					InternalError tagErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_TAG_NOT_ALLOWED_WITH_OTHER_TAG,new Object[]{"(OthrId)","(AdrTp)",MamboConstantsInterface.ADDRESS_TYPE_INDV});
					addInternalError(tagErr);
					valid = false;
				}
			}else if (MamboConstantsInterface.ADDRESS_TYPE_NON_INDV.equals(pdo.getString(MamboConstantsInterface.X_MAM_SCHME_ADR_TP))){
				//AdrTp=NIND
				if (pdo.getBoolean(MamboConstantsInterface.X_MAM_DISP_NM_OPTOUT)){
					//DispNmOptOut != False - report error
					InternalError tagErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_TAG_VALUE_NOT_ALLOWED_WITH_OTHER_TAG,new Object[]{"(DispNmOptOut)",pdo.getBoolean(MamboConstantsInterface.X_MAM_DISP_NM_OPTOUT),"(AdrTp)",MamboConstantsInterface.ADDRESS_TYPE_NON_INDV});
					addInternalError(tagErr);
					valid = false;
				}
				if (!"0002".equals(pdo.getString(MamboConstantsInterface.X_MAM_CHRG_CTGY))){
					//ChrgCtgy!='0002' - report error
					InternalError tagErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_TAG_VALUE_NOT_ALLOWED_WITH_OTHER_TAG,new Object[]{"(ChrgCtgy)",pdo.getString(MamboConstantsInterface.X_MAM_CHRG_CTGY),"(AdrTp)",MamboConstantsInterface.ADDRESS_TYPE_NON_INDV});
					addInternalError(tagErr);
					valid = false;
				}
			}
		}//EO AdrTp!=null


		int countAccptAcctOpt = pdo.countOccurrences(MamboConstantsInterface.X_MAM_ACCPTD_ACCT_OPT);
		for (int i=0; i<countAccptAcctOpt ; i++){
			String AcctTp = pdo.getString(new Object[]{MamboConstantsInterface.X_MAM_ACCPTD_ACCT_OPT, i, MamboConstantsInterface.X_MAM_ACCPTD_ACCT_TP});
			Double minAccptdFromMsg = pdo.getDecimal(new Object[]{MamboConstantsInterface.X_MAM_ACCPTD_ACCT_OPT, i, MamboConstantsInterface.X_MAM_MIN_ACCPTD})==null?null:pdo.getDecimal(new Object[]{MamboConstantsInterface.X_MAM_ACCPTD_ACCT_OPT, i, MamboConstantsInterface.X_MAM_MIN_ACCPTD}).doubleValue();
			if (minAccptdFromMsg!=null){
				Double minAccptdSchemeLevel = Double.parseDouble(CacheKeys.SystParKey.getSingle(GlobalConstants.DEFAULT_SERVER_OFFICE_NAME, SystemParametersInterface.SYST_PAR_HUB_MIN_AMT_ACCPTD).getParmValue());
				if (minAccptdFromMsg < minAccptdSchemeLevel){
					//minAmtAccptd is smaller than scheme level minimum amount accepted - report error
					InternalError minErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_VALUE_THAN_VALUE,new Object[]{"(MinAmtAccptd) of AcctTp="+AcctTp,"<","Scheme Level Minimum Amount Accepted"});
					addInternalError(minErr);
					valid = false;
				}
			}

			Double maxAccptdFromMsg = pdo.getDecimal(new Object[]{MamboConstantsInterface.X_MAM_ACCPTD_ACCT_OPT, i, MamboConstantsInterface.X_MAM_MAX_ACCPTD})==null?null:pdo.getDecimal(new Object[]{MamboConstantsInterface.X_MAM_ACCPTD_ACCT_OPT, i, MamboConstantsInterface.X_MAM_MAX_ACCPTD}).doubleValue();
			if (maxAccptdFromMsg!=null){
				Double maxAccptdSchemeLevel = Double.parseDouble(CacheKeys.SystParKey.getSingle(GlobalConstants.DEFAULT_SERVER_OFFICE_NAME, SystemParametersInterface.SYST_PAR_HUB_MAX_AMT_ACCPTD).getParmValue());
				if (maxAccptdFromMsg > maxAccptdSchemeLevel){
					//maxAmtAccptd is greater than scheme level maximum amount accepted - report error
					InternalError maxErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_VALUE_THAN_VALUE,new Object[]{"(MaxAmtAccptd) of AcctTp="+AcctTp,">","Scheme Level Maximum Amount Accepted"});
					addInternalError(maxErr);
					valid = false;
				}
			}

			
			if (minAccptdFromMsg!=null && maxAccptdFromMsg!=null && (minAccptdFromMsg > maxAccptdFromMsg)){
				//maxAmtAccptd is smaller than minAmtAccptd - report error
				InternalError minMaxErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_VALUE_THAN_VALUE,new Object[]{"(MaxAmtAccptd) of AcctTp="+AcctTp,"<","(MinAmtAccptd) of AcctTp="+AcctTp});
				addInternalError(minMaxErr);
				valid = false;
			}
		}

		
		//if <OthrId><Issr> is 'ABR' then <OthrId><Id> length should be 11
		//if <OthrId><Issr> is 'ASIC' then <OthrId><Id> length should be 9
		int countOthrId = pdo.countOccurrences(MamboConstantsInterface.X_MAM_OTHR_ID);
		for (int i=0; i<countOthrId ; i++){
			String othridissr = pdo.getString(new Object[]{MamboConstantsInterface.X_MAM_OTHR_ID, i, MamboConstantsInterface.X_MAM_OTHR_ID_ISSR});
			String othridid = pdo.getString(new Object[]{MamboConstantsInterface.X_MAM_OTHR_ID, i, MamboConstantsInterface.X_MAM_OTHR_ID_ID});
			if ( (("ABR".equals(othridissr))&&(((othridid)==null)||(othridid.length()!=11)))||
					(("ASIC".equals(othridissr))&&(((othridid)==null)||(othridid.length()!=9))) ){
				InternalError lengthErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_VALUE_LENGTH,new Object[]{(othridid==null?0:othridid.length()),"(OthrId.Id)",othridissr,"(OthrId.Issr)"});
				addInternalError(lengthErr);
				valid = false;			
			}
		}
		
		
		
		//All amount fields must have a currency of 'AUD' 
		if ((pdo.get(MamboConstantsInterface.X_MAM_CDT_ACCT_CCY)!=null)&&(!"AUD".equals(pdo.get(MamboConstantsInterface.X_MAM_CDT_ACCT_CCY)))){
			InternalError ccyErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_TAG_VALUE_NOT_ALLOWED,new Object[]{pdo.get(MamboConstantsInterface.X_MAM_CDT_ACCT_CCY),"(CdtAcct.Ccy)"});
			addInternalError(ccyErr);
			valid = false;	
		}
		if ((pdo.get(MamboConstantsInterface.X_MAM_DBT_ACCT_CCY)!=null)&&(!"AUD".equals(pdo.get(MamboConstantsInterface.X_MAM_DBT_ACCT_CCY)))){
			InternalError ccyErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_TAG_VALUE_NOT_ALLOWED,new Object[]{pdo.get(MamboConstantsInterface.X_MAM_DBT_ACCT_CCY),"(DbtAcct.Ccy)"});
			addInternalError(ccyErr);
			valid = false;	
		}
		if ((pdo.get(MamboConstantsInterface.X_MAM_ONLN_ACCT_CCY)!=null)&&(!"AUD".equals(pdo.get(MamboConstantsInterface.X_MAM_ONLN_ACCT_CCY)))){
			InternalError ccyErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_TAG_VALUE_NOT_ALLOWED,new Object[]{pdo.get(MamboConstantsInterface.X_MAM_ONLN_ACCT_CCY),"(OnlnPurchsAcct.Ccy)"});
			addInternalError(ccyErr);
			valid = false;	
		}
		if ((pdo.get(MamboConstantsInterface.X_MAM_FEE_ACCT_CCY)!=null)&&(!"AUD".equals(pdo.get(MamboConstantsInterface.X_MAM_FEE_ACCT_CCY)))){
			InternalError ccyErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_TAG_VALUE_NOT_ALLOWED,new Object[]{pdo.get(MamboConstantsInterface.X_MAM_FEE_ACCT_CCY),"(FeeAcct.Ccy)"});
			addInternalError(ccyErr);
			valid = false;	
		}
		for (int i=0; i<countAccptAcctOpt ; i++){
			String minCcy = pdo.getString(new Object[]{MamboConstantsInterface.X_MAM_ACCPTD_ACCT_OPT, i, MamboConstantsInterface.X_MAM_MIN_ACCPTD_CCY});
			String maxCcy = pdo.getString(new Object[]{MamboConstantsInterface.X_MAM_ACCPTD_ACCT_OPT, i, MamboConstantsInterface.X_MAM_MAX_ACCPTD_CCY});
			String surchCcy = pdo.getString(new Object[]{MamboConstantsInterface.X_MAM_ACCPTD_ACCT_OPT, i, MamboConstantsInterface.X_MAM_SURCHRG_AMT_CCY});
			
			if ((minCcy!=null)&&(!"AUD".equals(minCcy))){
				InternalError ccyErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_TAG_VALUE_NOT_ALLOWED,new Object[]{minCcy,"(MinAmtAccptd.Ccy)"});
				addInternalError(ccyErr);
				valid = false;	
			}
			if ((maxCcy!=null)&&(!"AUD".equals(maxCcy))){
				InternalError ccyErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_TAG_VALUE_NOT_ALLOWED,new Object[]{maxCcy,"(MaxAmtAccptd.Ccy)"});
				addInternalError(ccyErr);
				valid = false;	
			}
			if ((surchCcy!=null)&&(!"AUD".equals(surchCcy))){
				InternalError ccyErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_TAG_VALUE_NOT_ALLOWED,new Object[]{surchCcy,"(SurchrgAmt.Ccy)"});
				addInternalError(ccyErr);
				valid = false;	
			}
		}
		
		
		
		//Verify allowableUse section:
		int countAllwblUse = pdo.countOccurrences(MamboConstantsInterface.X_MAM_ALLWBL_USE);
		if (countAllwblUse>0){
			Set<String> allAllwblUse = new HashSet<String>();
			for (int i=0; i<countAllwblUse ; i++){
				allAllwblUse.add(pdo.getString(new Object[]{MamboConstantsInterface.X_MAM_ALLWBL_USE, i}));
			}
			//verify that if any one of the following Allowable Usages is selected, then they all must be selected: CPRQ, SPRQ, RSPT, SRFD
			String tagsList1 = ";";
			tagsList1 += allAllwblUse.contains("CPRQ")?"CPRQ;":"";
			tagsList1 += allAllwblUse.contains("SPRQ")?"SPRQ;":"";
			tagsList1 += allAllwblUse.contains("RSPT")?"RSPT;":"";
			tagsList1 += allAllwblUse.contains("SRFD")?"SRFD;":"";
			String fullTagsList1 = ";CPRQ;SPRQ;RSPT;SRFD;";
			if ((!tagsList1.equals(";")) && (!tagsList1.equals(fullTagsList1))){
				InternalError listErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_INCOMPLETE_LIST_VALUES,new Object[]{tagsList1.substring(1, 4),tagsList1,fullTagsList1});
				addInternalError(listErr);
				valid = false;	
			}
			//verify that if any one of the following Allowable Usages is selected, then they all must be selected: RPRQ,SPMT
			String tagsList2 = ";";
			tagsList2 += allAllwblUse.contains("RPRQ")?"RPRQ;":"";
			tagsList2 += allAllwblUse.contains("SPMT")?"SPMT;":"";
			String fullTagsList2 = ";RPRQ;SPMT;";
			if ((!tagsList2.equals(";")) && (!tagsList2.equals(fullTagsList2))){
				InternalError listErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_INCOMPLETE_LIST_VALUES,new Object[]{tagsList2.substring(1, 4),tagsList2,fullTagsList2});
				addInternalError(listErr);
				valid = false;	
			}
			
			//Verify that if ROLP allowable use is selected, then <LkdAccts><OnlnPurchsAcct> must also be specified
			if ((allAllwblUse.contains("ROLP"))&&(pdo.getString(MamboConstantsInterface.X_MAM_ONLN_ACCT_ID)==null)){
				InternalError tagMandErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_TAG_MUST_WITH_OTHER_TAG,new Object[]{"(LkdAccts.OnlnPurchsAcct)","(AllwblUse)","ROLP"});
				addInternalError(tagMandErr);
				valid = false;		
			}
			//Verify that if SOLP allowable use is selected, then <LkdAccts><CdtAcct> must also be specified
			if ((allAllwblUse.contains("SOLP"))&&(pdo.getString(MamboConstantsInterface.X_MAM_CDT_ACCT_ID)==null)){
				InternalError tagMandErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_TAG_MUST_WITH_OTHER_TAG,new Object[]{"(LkdAccts.CdtAcct)","(AllwblUse)","SOLP"});
				addInternalError(tagMandErr);
				valid = false;		
			}
			//Verify that if RUPT allowable use is selected, then <LkdAccts><CdtAcct> must also be specified
			if ((allAllwblUse.contains("RUPT"))&&(pdo.getString(MamboConstantsInterface.X_MAM_CDT_ACCT_ID)==null)){
				InternalError tagMandErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_TAG_MUST_WITH_OTHER_TAG,new Object[]{"(LkdAccts.CdtAcct)","(AllwblUse)","RUPT"});
				addInternalError(tagMandErr);
				valid = false;		
			}
			//Verify that if RSPT allowable use is selected, then <LkdAccts><CdtAcct> must also be specified
			if ((allAllwblUse.contains("RSPT"))&&(pdo.getString(MamboConstantsInterface.X_MAM_CDT_ACCT_ID)==null)){
				InternalError tagMandErr = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_TAG_MUST_WITH_OTHER_TAG,new Object[]{"(LkdAccts.CdtAcct)","(AllwblUse)","RSPT"});
				addInternalError(tagMandErr);
				valid = false;		
			}
			
		}
			
		return valid;
	}
	
	@Override
	public String getServiceName() {			
		return "Create Address";
	}

}
