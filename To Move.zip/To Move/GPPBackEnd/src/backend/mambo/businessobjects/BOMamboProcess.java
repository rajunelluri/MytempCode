package backend.mambo.businessobjects;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import org.apache.xmlbeans.XmlDateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.core.module.MessageConstantsInterface;
import backend.mambo.dataaccess.dao.BPAYAddress;
import backend.mambo.dataaccess.dao.DAOBpayAddress;
import backend.mambo.dataaccess.dao.BPAYAddress.AllwblUse;
import backend.mambo.dataaccess.dao.BPAYAddress.LkdAcct;
import backend.mambo.validation.ChannelRequestValidator;
import backend.mambo.validation.ChannelRequestValidatorFactory;
import backend.paymentprocess.interfaces.businessobjects.BOInterfaces;
import backend.paymentprocess.matchingcheck.businessobjects.BOMatchingCheck;
import backend.paymentprocess.matchingcheck.output.MatchingCheckOutputData;
import backend.staticdata.AuditHandler;
import backend.staticdata.profilehandler.message.BPAY_ADDRESSProfileHandler;
import com.fundtech.cache.entities.Banks;
import com.fundtech.cache.entities.Errcodes;
import com.fundtech.cache.entities.InterfaceTypes;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.cache.syspar.SystemParametersInterface;
import com.fundtech.core.paymentprocess.data.MamboConstantsInterface;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.core.paymentprocess.data.paymenttypes.PaymentType;
import com.fundtech.datacomponent.request.FieldsContainer;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.errors.ProcessErrorConstants;
import com.fundtech.interfaces.gateway.MessageContext;
import com.fundtech.util.ExceptionController;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalDateTimeUtil;
import backend.mambo.validation.InternalError;;


public class BOMamboProcess 
{
	private final static Logger logger = LoggerFactory.getLogger(BOMamboProcess.class);
	protected static DAOBpayAddress m_daoBpayAddress = DAOBpayAddress.getInstance();

	public BOMamboProcess(){ 
	}

	public Feedback executeChannelInFlow(String mid)
	{
		PDO pdo = PaymentDataFactory.load(mid);
		Feedback feedback = new Feedback();

		logger.debug("In executeChannelInFlow()");

		//Perform validation on channel request (after basic properties and transport properties had been set so that response pdo would use this setup)
		boolean stopExecution = validateChannelRequest(pdo);
		if (stopExecution) {
			logger.debug("stopping execution due to validation errors.");
			feedback.setFailure();
			feedback.setErrorText("stopping execution due to validation errors.");
			return feedback;
		}

		//set P_MSG_STS to "WAIT_HUB" and save request to MINF 
		pdo.set(PDOConstantFieldsInterface.P_MSG_STS,MessageConstantsInterface.MESSAGE_STATUS_WAITHUB);

		try {//create a BPAY message with the same TX_ID value in it, and send it out to the hub

			//send BPAY request to hub 
			transformChannelRequestToHubRequest(pdo);
			
			//set fields on outgoing message
			setFieldsToNewHubRequest(pdo);

			//office in PDO should be set to '***' because of HUB interface declaration
			String origOffice = pdo.getString(PDOConstantFieldsInterface.P_OFFICE); 
			pdo.set(PDOConstantFieldsInterface.P_OFFICE, GlobalConstants.DEFAULT_SERVER_OFFICE_NAME);
			new BOInterfaces().performOutgoingRequestHandler(pdo.getMID(), InterfaceTypes.INTERFACE_TYPE_MAMBO_HUB_OUT, (String)null);	
			pdo.set(PDOConstantFieldsInterface.P_OFFICE,origOffice);
			
		} catch (Throwable e) {//do not set feedback to failed, because it will cause the request pdo to not be saved
			logger.error("",e);
			logger.error("Failed to send request to HUB, setting message status to repair");	
			pdo.set(PDOConstantFieldsInterface.P_MSG_STS,MessageConstantsInterface.MESSAGE_STATUS_REPAIR);
		}	
		return feedback;
	}

	private boolean validateChannelRequest(PDO pdo) {
		ChannelRequestValidator validator = ChannelRequestValidatorFactory.getChannelRequestValidator(pdo);
		
		if (!validator.validateSchema()) {

			logger.debug("Schema validation errors: {}",validator.getSchemaValidationErrors());
			
			validator.processSchemaValidationErrors();
			if (validator.containsInternalErrors()) {
				PDO responsePDO = newChannelResponsePDO(pdo);
				validator.processInternalErrors(responsePDO);
				
				try {
					new BOInterfaces().performOutgoingRequestHandler(responsePDO.getMID(), InterfaceTypes.INTERFACE_TYPE_MAMBO_CHANNEL_OUT, (String) null);	
				} catch (Throwable e) {
					ExceptionController.getInstance().handleException(e, this);
				}
			}
			return true;
		} else if (!validator.validateUserRole()) {
			logger.debug("User and Role validation failed");
			if (validator.containsInternalErrors()) {
				PDO responsePDO = newChannelResponsePDO(pdo);
				validator.processInternalErrors(responsePDO);

				try {
					new BOInterfaces().performOutgoingRequestHandler(responsePDO.getMID(), InterfaceTypes.INTERFACE_TYPE_MAMBO_CHANNEL_OUT, (String) null);	
				} catch (Throwable e) {
					ExceptionController.getInstance().handleException(e, this);
				}
			}
			return true;
		} else if (!validator.validateContent()) {
			logger.debug("Content validation failed");
			if (validator.containsInternalErrors()) {
				PDO responsePDO = newChannelResponsePDO(pdo);
				validator.processInternalErrors(responsePDO);

				try {
					new BOInterfaces().performOutgoingRequestHandler(responsePDO.getMID(), InterfaceTypes.INTERFACE_TYPE_MAMBO_CHANNEL_OUT, (String) null);	
				} catch (Throwable e) {
					ExceptionController.getInstance().handleException(e, this);
				}
			}
			return true;
		}

		return false;
	}

	private PDO newChannelResponsePDO(PDO channelRequestPDO) {
		PDO channelResposnePDO = PaymentDataFactory.newPDO(PaymentType.valueOf(MessageConstantsInterface.MESSAGE_TYPE_MAMBO_FTM402));
		channelResposnePDO.set(PDOConstantFieldsInterface.P_OFFICE,channelRequestPDO.getString(PDOConstantFieldsInterface.P_OFFICE));
		channelResposnePDO.set(MamboConstantsInterface.X_MAM_DLVRY_TM_STMP,deliveryTimestamp());
		channelResposnePDO.set(MamboConstantsInterface.X_MAM_ORIG_BIZ_MSG_IDR,channelRequestPDO.get(MamboConstantsInterface.X_MAM_BIZ_MSG_IDR));
		channelResposnePDO.set(MamboConstantsInterface.X_MAM_ORIG_DLVRY_TM_STMP,channelRequestPDO.get(MamboConstantsInterface.X_MAM_DLVRY_TM_STMP));
		channelResposnePDO.set(MamboConstantsInterface.X_MAM_STS_ID,"N/A");
		channelResposnePDO.set(MamboConstantsInterface.X_MAM_ORGNL_INSTR_ID,channelRequestPDO.get(MamboConstantsInterface.X_MAM_INSTR_ID));
		channelResposnePDO.set(MamboConstantsInterface.X_MAM_ORGNL_TX_ID,"N/A");
		
		addTransportProperties(channelResposnePDO,channelRequestPDO);		
		return channelResposnePDO;
	}

	private Object deliveryTimestamp() { // the logical field type is string and not date, TBD fix 
		XmlDateTime now = XmlDateTime.Factory.newInstance();
		now.setDateValue(new Date());
		return now.getGDateValue().toString();
	}
	

	
	public Feedback executeHubInFlow(String mid)
	{
		PDO pdo = PaymentDataFactory.load(mid);
		Feedback feedback = new Feedback();

		logger.debug("In executeHubInFlow()");

		BOMatchingCheck m_boMatchingCheck = new BOMatchingCheck();
		MatchingCheckOutputData matchingCheckOutputData = m_boMatchingCheck.performMatchingCheck(pdo.getMID(), MessageConstantsInterface.RELATION_TYPE_MAMBO_HUB, MessageConstantsInterface.RELATION_TYPE_MAMBO_CHANNEL, false, null);

		if (matchingCheckOutputData.getMID()==null){//a match was not found
			logger.debug("Matching failed while trying to find a request message with txId={}. Ignore message.",pdo.get(MamboConstantsInterface.X_MAM_ORGNL_TX_ID));
			
			//report to error log
			InternalError matchingFailureError = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_MATCHING_FAILED, new Object[]{pdo.get(MamboConstantsInterface.X_MAM_ORGNL_TX_ID)});
			matchingFailureError.reportInternalError(pdo,"Matching");
			
			feedback.setFailure();
			feedback.setErrorText("Matching failed. Ignore message.");
			
			return feedback;
		}//EO a match was not found

		logger.debug("A matching request was found (matched request MID={})",matchingCheckOutputData.getMID());

		PDO matchedRequestPdo = PaymentDataFactory.load(matchingCheckOutputData.getMID());

		//set response office and department according to matched request
		String requestOffice = matchedRequestPdo.getString(PDOConstantFieldsInterface.P_OFFICE);
		pdo.set(PDOConstantFieldsInterface.P_OFFICE, requestOffice);
		String requestDepartment =matchedRequestPdo.getString(PDOConstantFieldsInterface.P_DEPARTMENT);
		pdo.set(PDOConstantFieldsInterface.P_DEPARTMENT,requestDepartment);
		logger.debug("The office and the department of the Hub response were set according to matched request, to these values: {} , {}",requestOffice,requestDepartment);

		//verify that message status of the request is "WAIT_HUB"
		if(!MessageConstantsInterface.MESSAGE_STATUS_WAITHUB.equals(matchedRequestPdo.get(PDOConstantFieldsInterface.P_MSG_STS))){//a match was found but request status is not as expected
			logger.debug("Matching succeeded but message status is {}. Ignore message.",matchedRequestPdo.get(PDOConstantFieldsInterface.P_MSG_STS));
			
			//report to audit trail 
			InternalError matchingStatusError = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_MATCHING_STATUS_NOT_WAIT_HUB, new Object[]{pdo.get(MamboConstantsInterface.X_MAM_ORGNL_TX_ID)});
			matchingStatusError.reportInternalError(pdo,"Matching Status");

			feedback.setFailure();
			feedback.setErrorText("Matching succeeded but message status is "+matchedRequestPdo.get(PDOConstantFieldsInterface.P_MSG_STS)+". Ignore message.");
			return feedback;
		}

		//request message status is WAIT_HUB, as expected	
		logger.debug("The matched request message status is as expected ({})",matchedRequestPdo.get(PDOConstantFieldsInterface.P_MSG_STS));

		try{	

			//set hub response message to "COMPLETE" status and add transport properties according to matched request
			pdo.set(PDOConstantFieldsInterface.P_MSG_STS,MessageConstantsInterface.MESSAGE_STATUS_COMPLETE);
			addTransportProperties(pdo,matchedRequestPdo);	
			
		
			if (MamboConstantsInterface.ACCEPTED_RESPONSE_STATUS.equals(pdo.get(MamboConstantsInterface.X_MAM_RESP_STS))){//ACCEPTED BY HUB
				
				logger.debug("Hub response message returned an {} reply status",MamboConstantsInterface.ACCEPTED_RESPONSE_STATUS);
				
				//update profile tables, like BPAY_ADDRESS with response data
				feedback = updateProfileTables(pdo,matchedRequestPdo);
				
				if (!feedback.isSuccessful()){//update profile tables failed
					logger.error("Failed to update profile tables for request {}. "+feedback.getErrorText(),pdo.get(MamboConstantsInterface.X_MAM_ORGNL_TX_ID));
					feedback = new Feedback();
					
					//report error to error log
					InternalError dbInsertionError = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_DB_DISCREPANCY, new Object[]{pdo.get(MamboConstantsInterface.X_MAM_ORGNL_TX_ID)});
					dbInsertionError.reportInternalError(pdo,"Insert BPAY_ADDRESS");

					//set message status to REJECTED for both request and response
					matchedRequestPdo.set(PDOConstantFieldsInterface.P_MSG_STS,MessageConstantsInterface.MESSAGE_STATUS_REJECTED);  
					PaymentDataFactory.save(true /* remove pdo from cache */, matchedRequestPdo) ;
					pdo.set(PDOConstantFieldsInterface.P_MSG_STS,MessageConstantsInterface.MESSAGE_STATUS_REJECTED);
					
					//create response to channel and send it
					transformHubResponseToChannelResponse(pdo);
					pdo.set(MamboConstantsInterface.X_MAM_RESP_STS,MamboConstantsInterface.REJECTED_RESPONSE_STATUS);
					
					//store internal errors in pdo 
					pdo.set((Object)String.valueOf(dbInsertionError.getCode()),new Object[]{MamboConstantsInterface.X_MAM_RESP_STS_RSN_GROUP, 0, MamboConstantsInterface.X_MAM_RESP_INTR_STS_RSN_CODE});		
					pdo.set((Object)dbInsertionError.getErrorText(),new Object[]{MamboConstantsInterface.X_MAM_RESP_STS_RSN_GROUP, 0, MamboConstantsInterface.X_MAM_RESP_INTR_ERR_TEXT});
					pdo.set((Object)MamboConstantsInterface.ERROR_ORIGIN_INTERNAL,new Object[]{MamboConstantsInterface.X_MAM_RESP_STS_RSN_GROUP, 0, MamboConstantsInterface.X_MAM_RESP_ERR_ORIGIN});
					
					//delete all schmeAdrId elements from response
					pdo.deleteAllOccurrences(MamboConstantsInterface.X_MAM_SCHME_ADR_GROUP);
					
				}else{//update profile tables succeeded

					//update request message on MINF with a COMPLETE status
					matchedRequestPdo.set(PDOConstantFieldsInterface.P_MSG_STS,MessageConstantsInterface.MESSAGE_STATUS_COMPLETE);  
					PaymentDataFactory.save(true /* remove pdo from cache */, matchedRequestPdo) ;	
					logger.debug("Channel request message was udpated in MINF with status={}",MessageConstantsInterface.MESSAGE_STATUS_COMPLETE);
				
					
					transformHubResponseToChannelResponse(pdo);
				}
			}else{//REJCTED BY HUB
				
				logger.debug("Hub response message returned a {} reply status",MamboConstantsInterface.REJECTED_RESPONSE_STATUS);
				
				//update request message on MINF with a REJECTED status
				matchedRequestPdo.set(PDOConstantFieldsInterface.P_MSG_STS,MessageConstantsInterface.MESSAGE_STATUS_REJECTED);  
				PaymentDataFactory.save(true /* remove pdo from cache */, matchedRequestPdo) ;
				
				logger.debug("Channel request message status was updated in MINF to ="+MessageConstantsInterface.MESSAGE_STATUS_REJECTED);
				
				logger.debug("Transforming Bpay message type to FTM and sending response back to channel.");
				
				//get error parameters before transformation
				String[][] extErrorsParams = getExternalErrorsParams(pdo);
				
				transformHubResponseToChannelResponse(pdo);
				
				//set external errors info
				setExternalErrorsInfo(pdo,extErrorsParams);
			}

			//set header elements and send response to channel
			pdo.set(MamboConstantsInterface.X_MAM_DLVRY_TM_STMP,deliveryTimestamp());
			//Extract bizMsgIdr from request
			pdo.set(MamboConstantsInterface.X_MAM_ORIG_BIZ_MSG_IDR,matchedRequestPdo.get(MamboConstantsInterface.OX_MAM_BIZ_MSG_IDR));
			//Extract orig_dlvry_tm_stmp from request
			pdo.set(MamboConstantsInterface.X_MAM_ORIG_DLVRY_TM_STMP,matchedRequestPdo.get(MamboConstantsInterface.OX_MAM_DLVRY_TM_STMP));
			
			new BOInterfaces().performOutgoingRequestHandler(pdo.getMID(), InterfaceTypes.INTERFACE_TYPE_MAMBO_CHANNEL_OUT,(String)  null);

		}catch(Throwable e){
			logger.error("",e);
			//do not set feedback failure, so that response pdo will be saved to MINF
		}
		return feedback;
	}


	private String generateTxId(PDO pdo) {
		String mid = pdo.getMID();
		String office = pdo.getString(PDOConstantFieldsInterface.P_OFFICE);
		String bankName = getBankRefernceBranch(office);
		return bankName+"_"+mid;
	}
	
	private String getBankRefernceBranch(String office){
		Banks bank = CacheKeys.banksKey.getSingle(office);
		String bankName = bank.getReferencebranch();
		return bankName;
	}
	
	private String getMsgDefIdr(PDO pdo){
		String msgType = pdo.getString(PDOConstantFieldsInterface.P_MSG_TYPE);
		if (msgType.equals(MessageConstantsInterface.MESSAGE_TYPE_MAMBO_FTM401))
			return "BPAY.401.01.01";
		if (msgType.equals(MessageConstantsInterface.MESSAGE_TYPE_MAMBO_FTM411))
			return "BPAY.411.01.01";
		if (msgType.equals(MessageConstantsInterface.MESSAGE_TYPE_MAMBO_FTM441))
			return "BPAY.441.01.01";
		if (msgType.equals(MessageConstantsInterface.MESSAGE_TYPE_MAMBO_FTM451))
			return "BPAY.451.01.01";
		return "UNKNOWN";
	}
	
	private Feedback updateProfileTables(PDO resPdo, PDO reqMatchedPdo){
		Feedback feedback= new Feedback();
		String reqMsgType = reqMatchedPdo.getString(PDOConstantFieldsInterface.P_MSG_TYPE);

		if (reqMsgType.equals(MessageConstantsInterface.MESSAGE_TYPE_MAMBO_FTM401)){
			//If the original request is a "RESERVE ADDRESS" request, then store all bpay addresses received from HUB in BPAY_ADDRESS table,
			//with RSVD status
			List<String> bpayAddresses = new ArrayList<String>();

			int numOfBpayAddresses = resPdo.countOccurrences(MamboConstantsInterface.X_MAM_SCHME_ADR_GROUP);
			for (int i=0; i<numOfBpayAddresses; i++){
				bpayAddresses.add(resPdo.get(new Object[]{MamboConstantsInterface.X_MAM_SCHME_ADR_GROUP, i, MamboConstantsInterface.X_MAM_SCHME_ADR_ID}).toString());
			}

			String sClientId=reqMatchedPdo.get(MamboConstantsInterface.OX_MAM_CLIENT_ID).toString();//non optional field in FTM401 request message

			String sAddressStatus=DAOBpayAddress.RSVD_ADDRESS_STATUS;

			boolean bIsPersistent =  Boolean.valueOf(reqMatchedPdo.get(MamboConstantsInterface.OX_MAM_PERSISTENT).toString());//non optional field in message

			String sOffice=resPdo.get(PDOConstantFieldsInterface.P_OFFICE).toString();
			String sDepartment=resPdo.get(PDOConstantFieldsInterface.P_DEPARTMENT).toString();
			String sRecordStatus="AC"; 

			//set time-stamp, update-date and expiration time (for non persistent addresses):	
			Date currentTime = new Date();
			String sTimeStamp=GlobalDateTimeUtil.getSimpleDateFormatByFormat(GlobalDateTimeUtil.STATIC_DATA_TIME_STAMP).format(currentTime);
			String sUpdateDate=GlobalDateTimeUtil.getSimpleDateFormatByFormat(GlobalDateTimeUtil.STATIC_DATA_DATE_TIME_AM_PM_12).format(currentTime);	
			String sExpirationTime=null;
			if (!bIsPersistent){
				int numOfHoursReserve = Integer.parseInt(CacheKeys.SystParKey.getSingle(GlobalConstants.DEFAULT_SERVER_OFFICE_NAME, SystemParametersInterface.SYST_PAR_NO_HRS_RSV).getParmValue());
				Date expirationDate = new Date(currentTime.getTime()+(numOfHoursReserve*60*60*1000));//adding numOfHoursReserve hours
				String sExpirationDateInDBFormat = GlobalDateTimeUtil.getSimpleDateFormatByFormat(GlobalDateTimeUtil.STATIC_DATA_DATE_TIME_AM_PM_12).format(expirationDate);
				sExpirationTime=sExpirationDateInDBFormat;
			}


			feedback = m_daoBpayAddress.insertRecordInto_BPAY_ADDRESS_Table(bpayAddresses, sClientId, sAddressStatus, bIsPersistent, sExpirationTime, sTimeStamp, sOffice, sDepartment, sRecordStatus, sUpdateDate);
			if (feedback.isSuccessful()){

				FieldsContainer fcModifiedFields = new FieldsContainer();
				fcModifiedFields.addField(BPAY_ADDRESSProfileHandler.FIELD_CLNT_ID, sClientId);
				fcModifiedFields.addField(BPAY_ADDRESSProfileHandler.FIELD_ADR_STS, sAddressStatus);
				fcModifiedFields.addField(BPAY_ADDRESSProfileHandler.FIELD_PSTNT_RSVATN, bIsPersistent?"1":"0");
				fcModifiedFields.addField(BPAY_ADDRESSProfileHandler.FIELD_EXPIRATION_TIME, sExpirationTime);
				fcModifiedFields.addField(BPAY_ADDRESSProfileHandler.FIELD_TIME_STAMP, sTimeStamp);
				fcModifiedFields.addField(BPAY_ADDRESSProfileHandler.FIELD_OFFICE, sOffice);
				fcModifiedFields.addField(BPAY_ADDRESSProfileHandler.FIELD_DEPARTMENT, sDepartment);
				fcModifiedFields.addField(BPAY_ADDRESSProfileHandler.FIELD_REC_STATUS, sRecordStatus);
				fcModifiedFields.addField(BPAY_ADDRESSProfileHandler.FIELD_UPDATE_DATE, sUpdateDate);

				for (String bpayAddress : bpayAddresses) { 
					fcModifiedFields.addField(BPAY_ADDRESSProfileHandler.FIELD_UID_BPAY_ADDRESS, bpayAddress);
					fcModifiedFields.addField(BPAY_ADDRESSProfileHandler.FIELD_SCHME_ADR_ID,bpayAddress);
					Feedback profileUpdateFeedback = new BPAY_ADDRESSProfileHandler().setProfileUpdate(reqMatchedPdo.getString(MamboConstantsInterface.OX_MAM_CRED_USER_ID), fcModifiedFields,AuditHandler.ACTION_CREATE,bpayAddress);
					if (!profileUpdateFeedback.isSuccessful()){
						logger.error("The BPAY ADDRESS : {} creation failed to be logged in PROFILE_UPDATE table in DB. Will continue flow as usual",bpayAddress);
					}
				}
			}else{
				logger.error("BPAY_ADDRESS profile update has failed.");
			}
			
			
			
		}else if (reqMsgType.equals(MessageConstantsInterface.MESSAGE_TYPE_MAMBO_FTM411)){
			
			//check for discrepancies:
			String reqAddressId = reqMatchedPdo.getString(new Object[]{MamboConstantsInterface.X_MAM_SCHME_ADR_GROUP, 0, MamboConstantsInterface.X_MAM_SCHME_ADR_ID});
			String resAddressId = resPdo.getString(new Object[]{MamboConstantsInterface.X_MAM_SCHME_ADR_GROUP, 0, MamboConstantsInterface.X_MAM_SCHME_ADR_ID});
			if ((reqAddressId!=null) && (!reqAddressId.equals(resAddressId))){
				feedback.setFailure();
				feedback.setErrorText("The address that was sent in request is different than the address that was received in response.");
				return feedback;
			}
			BPAYAddress bpayAddressRec = m_daoBpayAddress.getBPAYAddress(resAddressId);
		    if ((reqAddressId==null) && (bpayAddressRec!=null)){
		    	feedback.setFailure();
				feedback.setErrorText("The address that was received in response should be new, but it already exists in BPAY_ADDRESS table.");
				return feedback;
		    }
			
			
			
			logger.debug("Should now update static profiles for response of ftm411 request");
	
			Date currentTime = new Date();
			if (bpayAddressRec==null){//record doesn't exist
				bpayAddressRec = new BPAYAddress();
				bpayAddressRec.setAddressId(resAddressId);
				bpayAddressRec.setClientId(reqMatchedPdo.getString(MamboConstantsInterface.OX_MAM_CLIENT_ID));
				bpayAddressRec.setPersistent(false);
				bpayAddressRec.setOffice(resPdo.getString(PDOConstantFieldsInterface.P_OFFICE));
				bpayAddressRec.setDepartment(resPdo.getString(PDOConstantFieldsInterface.P_DEPARTMENT));
				bpayAddressRec.setTimeStamp(GlobalDateTimeUtil.getSimpleDateFormatByFormat(GlobalDateTimeUtil.STATIC_DATA_TIME_STAMP).format(currentTime));	
				bpayAddressRec.setExpirationTime(null);
			}
			bpayAddressRec.setAddressSts("ACTV");
			bpayAddressRec.setRecSts("AC");
			bpayAddressRec.setUpdateDate(currentTime);
			
			
			bpayAddressRec.setSctrId(reqMatchedPdo.getString(MamboConstantsInterface.X_MAM_SCTR_ID));
			bpayAddressRec.setSctrIssr(reqMatchedPdo.getString(MamboConstantsInterface.X_MAM_SCTR_ISSR));
			bpayAddressRec.setDispNm(reqMatchedPdo.getString(MamboConstantsInterface.X_MAM_DISP_NM));
			bpayAddressRec.setDispNmOptOut(Boolean.parseBoolean(reqMatchedPdo.getString(MamboConstantsInterface.X_MAM_DISP_NM_OPTOUT)));
			bpayAddressRec.setDispTxt(reqMatchedPdo.getString(MamboConstantsInterface.X_MAM_DISP_TXT));
			bpayAddressRec.setDispUrl(reqMatchedPdo.getString(MamboConstantsInterface.X_MAM_DISP_URL));
			bpayAddressRec.setOtherIdId1(reqMatchedPdo.getString(new Object[]{MamboConstantsInterface.X_MAM_OTHR_ID, 0, MamboConstantsInterface.X_MAM_OTHR_ID_ID}));
			bpayAddressRec.setOtherIdIssr1(reqMatchedPdo.getString(new Object[]{MamboConstantsInterface.X_MAM_OTHR_ID, 0, MamboConstantsInterface.X_MAM_OTHR_ID_ISSR}));
			bpayAddressRec.setOtherIdId2(reqMatchedPdo.getString(new Object[]{MamboConstantsInterface.X_MAM_OTHR_ID, 1, MamboConstantsInterface.X_MAM_OTHR_ID_ID}));
			bpayAddressRec.setOtherIdIssr2(reqMatchedPdo.getString(new Object[]{MamboConstantsInterface.X_MAM_OTHR_ID, 1, MamboConstantsInterface.X_MAM_OTHR_ID_ISSR}));
			bpayAddressRec.setChrgCtgy(reqMatchedPdo.getString(MamboConstantsInterface.X_MAM_CHRG_CTGY));
			
			
			int countAcctTps = reqMatchedPdo.countOccurrences(MamboConstantsInterface.OX_MAM_ACCPTD_ACCT_OPT);
			for (int i=0 ; i<countAcctTps ;i++){
				String accountType = reqMatchedPdo.get(new Object[]{MamboConstantsInterface.OX_MAM_ACCPTD_ACCT_OPT, i, MamboConstantsInterface.OX_MAM_ACCPTD_ACCT_TP}).toString();
				if (accountType.equals("CRDT")){
					bpayAddressRec.setAccptAcctCdt(true);
					bpayAddressRec.setMinAmtAccptdCdt(reqMatchedPdo.getString(new Object[]{MamboConstantsInterface.OX_MAM_ACCPTD_ACCT_OPT, i, MamboConstantsInterface.OX_MAM_MIN_ACCPTD}));
					bpayAddressRec.setMaxAmtAccptdCdt(reqMatchedPdo.getString(new Object[]{MamboConstantsInterface.OX_MAM_ACCPTD_ACCT_OPT, i, MamboConstantsInterface.OX_MAM_MAX_ACCPTD}));
					bpayAddressRec.setSurchrgAmtCdt(reqMatchedPdo.getString(new Object[]{MamboConstantsInterface.OX_MAM_ACCPTD_ACCT_OPT, i, MamboConstantsInterface.OX_MAM_SURCHRG_AMT}));
					bpayAddressRec.setSurchrgRateCdt(reqMatchedPdo.getString(new Object[]{MamboConstantsInterface.OX_MAM_ACCPTD_ACCT_OPT, i, MamboConstantsInterface.OX_MAM_SURCHRG_RATE}));
				}else if (accountType.equals("DEBT")){
					bpayAddressRec.setAccptAcctDbt(true);
					bpayAddressRec.setMinAmtAccptdDbt(reqMatchedPdo.getString(new Object[]{MamboConstantsInterface.OX_MAM_ACCPTD_ACCT_OPT, i, MamboConstantsInterface.OX_MAM_MIN_ACCPTD}));
					bpayAddressRec.setMaxAmtAccptdDbt(reqMatchedPdo.getString(new Object[]{MamboConstantsInterface.OX_MAM_ACCPTD_ACCT_OPT, i, MamboConstantsInterface.OX_MAM_MAX_ACCPTD}));
					bpayAddressRec.setSurchrgAmtDbt(reqMatchedPdo.getString(new Object[]{MamboConstantsInterface.OX_MAM_ACCPTD_ACCT_OPT, i, MamboConstantsInterface.OX_MAM_SURCHRG_AMT}));
					bpayAddressRec.setSurchrgRateDbt(reqMatchedPdo.getString(new Object[]{MamboConstantsInterface.OX_MAM_ACCPTD_ACCT_OPT, i, MamboConstantsInterface.OX_MAM_SURCHRG_RATE}));
				}
			}
			
			//Set Linked Accounts
			if (reqMatchedPdo.getString(MamboConstantsInterface.OX_MAM_CDT_ACCT_ID)!=null){
				LkdAcct cdtLkdAcct = bpayAddressRec.new LkdAcct();
				cdtLkdAcct.setLkdAcctId(reqMatchedPdo.getString(MamboConstantsInterface.OX_MAM_CDT_ACCT_ID));
				cdtLkdAcct.setLkdAcctTp("CDT"); //CDT/DBT/ONLINE/FEE 	
				String acctTp = reqMatchedPdo.getString(MamboConstantsInterface.OX_MAM_CDT_ACCT_TP_CD)==null?reqMatchedPdo.getString(MamboConstantsInterface.OX_MAM_CDT_ACCT_TP_PRTRY):reqMatchedPdo.getString(MamboConstantsInterface.OX_MAM_CDT_ACCT_TP_CD);
				cdtLkdAcct.setCustAcctTp(acctTp);			
				cdtLkdAcct.setAcctCcy(reqMatchedPdo.getString(MamboConstantsInterface.OX_MAM_CDT_ACCT_CCY));
				
				bpayAddressRec.addLinkedAccount(cdtLkdAcct);
			}
			if (reqMatchedPdo.getString(MamboConstantsInterface.OX_MAM_DBT_ACCT_ID)!=null){
				LkdAcct dbtLkdAcct = bpayAddressRec.new LkdAcct();
				dbtLkdAcct.setLkdAcctId(reqMatchedPdo.getString(MamboConstantsInterface.OX_MAM_DBT_ACCT_ID));
				dbtLkdAcct.setLkdAcctTp("DBT"); //CDT/DBT/ONLINE/FEE 	
				String acctTp = reqMatchedPdo.getString(MamboConstantsInterface.OX_MAM_DBT_ACCT_TP_CD)==null?reqMatchedPdo.getString(MamboConstantsInterface.OX_MAM_DBT_ACCT_TP_PRTRY):reqMatchedPdo.getString(MamboConstantsInterface.OX_MAM_DBT_ACCT_TP_CD);
				dbtLkdAcct.setCustAcctTp(acctTp);			
				dbtLkdAcct.setAcctCcy(reqMatchedPdo.getString(MamboConstantsInterface.OX_MAM_DBT_ACCT_CCY));
				
				bpayAddressRec.addLinkedAccount(dbtLkdAcct);
			}
			if (reqMatchedPdo.getString(MamboConstantsInterface.OX_MAM_ONLN_ACCT_ID)!=null){
				LkdAcct onlnLkdAcct = bpayAddressRec.new LkdAcct();
				onlnLkdAcct.setLkdAcctId(reqMatchedPdo.getString(MamboConstantsInterface.OX_MAM_ONLN_ACCT_ID));
				onlnLkdAcct.setLkdAcctTp("ONLINE"); //CDT/DBT/ONLINE/FEE 	
				String acctTp = reqMatchedPdo.getString(MamboConstantsInterface.OX_MAM_ONLN_ACCT_TP_CD)==null?reqMatchedPdo.getString(MamboConstantsInterface.OX_MAM_ONLN_ACCT_TP_PRTRY):reqMatchedPdo.getString(MamboConstantsInterface.OX_MAM_ONLN_ACCT_TP_CD);
				onlnLkdAcct.setCustAcctTp(acctTp);			
				onlnLkdAcct.setAcctCcy(reqMatchedPdo.getString(MamboConstantsInterface.OX_MAM_ONLN_ACCT_CCY));
				
				bpayAddressRec.addLinkedAccount(onlnLkdAcct);
			}
			if (reqMatchedPdo.getString(MamboConstantsInterface.OX_MAM_FEE_ACCT_ID)!=null){
				LkdAcct feeLkdAcct = bpayAddressRec.new LkdAcct();
				feeLkdAcct.setLkdAcctId(reqMatchedPdo.getString(MamboConstantsInterface.OX_MAM_FEE_ACCT_ID));
				feeLkdAcct.setLkdAcctTp("FEE"); //CDT/DBT/ONLINE/FEE 	
				String acctTp = reqMatchedPdo.getString(MamboConstantsInterface.OX_MAM_FEE_ACCT_TP_CD)==null?reqMatchedPdo.getString(MamboConstantsInterface.OX_MAM_FEE_ACCT_TP_PRTRY):reqMatchedPdo.getString(MamboConstantsInterface.OX_MAM_FEE_ACCT_TP_CD);
				feeLkdAcct.setCustAcctTp(acctTp);			
				feeLkdAcct.setAcctCcy(reqMatchedPdo.getString(MamboConstantsInterface.OX_MAM_FEE_ACCT_CCY));
				
				bpayAddressRec.addLinkedAccount(feeLkdAcct);
			}
			
			//Set Allowable Use
			int countAllwblUse = reqMatchedPdo.countOccurrences(MamboConstantsInterface.X_MAM_ALLWBL_USE);
			for (int i=0; i< countAllwblUse ; i++){
				AllwblUse allwblUse = bpayAddressRec.new AllwblUse();
				allwblUse.setUse(reqMatchedPdo.getString(new Object[]{MamboConstantsInterface.X_MAM_ALLWBL_USE, i}));
				bpayAddressRec.addAllwblUsage(allwblUse);
			}
			
			feedback = m_daoBpayAddress.insert_or_update_BpayAddress(bpayAddressRec);
			
			if (feedback.isSuccessful()){

				FieldsContainer fcModifiedFields = new FieldsContainer();
				fcModifiedFields.addField(BPAY_ADDRESSProfileHandler.FIELD_ADR_STS, bpayAddressRec.getAddressSts());
				fcModifiedFields.addField(BPAY_ADDRESSProfileHandler.FIELD_REC_STATUS, bpayAddressRec.getRecSts());
				fcModifiedFields.addField(BPAY_ADDRESSProfileHandler.FIELD_UPDATE_DATE, bpayAddressRec.getUpdateDate().toString());
				
				fcModifiedFields.addField(BPAY_ADDRESSProfileHandler.FIELD_SCTR_ID, bpayAddressRec.getSctrId());
				fcModifiedFields.addField(BPAY_ADDRESSProfileHandler.FIELD_SCTR_ISSR, bpayAddressRec.getSctrIssr());
				fcModifiedFields.addField(BPAY_ADDRESSProfileHandler.FIELD_DISP_NM, bpayAddressRec.getDispNm());
				fcModifiedFields.addField(BPAY_ADDRESSProfileHandler.FIELD_DISP_NM_OPT_OUT, bpayAddressRec.isDispNmOptOut()?"1":"0");
				fcModifiedFields.addField(BPAY_ADDRESSProfileHandler.FIELD_DISP_TXT, bpayAddressRec.getDispTxt());
				fcModifiedFields.addField(BPAY_ADDRESSProfileHandler.FIELD_DISP_URL, bpayAddressRec.getDispUrl());
				fcModifiedFields.addField(BPAY_ADDRESSProfileHandler.FIELD_OTHRID_ID1, bpayAddressRec.getOtherIdId1());
				fcModifiedFields.addField(BPAY_ADDRESSProfileHandler.FIELD_OTHRID_ISSR1, bpayAddressRec.getOtherIdIssr1());
				fcModifiedFields.addField(BPAY_ADDRESSProfileHandler.FIELD_OTHRID_ID2, bpayAddressRec.getOtherIdId2());
				fcModifiedFields.addField(BPAY_ADDRESSProfileHandler.FIELD_OTHRID_ISSR2, bpayAddressRec.getOtherIdIssr2());
				fcModifiedFields.addField(BPAY_ADDRESSProfileHandler.FIELD_CHRG_CTGY, bpayAddressRec.getChrgCtgy());
				
				fcModifiedFields.addField(BPAY_ADDRESSProfileHandler.FIELD_ACCPTD_ACT_CDT, bpayAddressRec.isAccptAcctCdt()?"1":"0");
				fcModifiedFields.addField(BPAY_ADDRESSProfileHandler.FIELD_MAX_AMT_ACCPTD_CDT, bpayAddressRec.getMaxAmtAccptdCdt());
				fcModifiedFields.addField(BPAY_ADDRESSProfileHandler.FIELD_MIN_AMT_ACCPTD_CDT, bpayAddressRec.getMinAmtAccptdCdt());
				fcModifiedFields.addField(BPAY_ADDRESSProfileHandler.FIELD_SURCHRG_AMT_CDT, bpayAddressRec.getSurchrgAmtCdt());
				fcModifiedFields.addField(BPAY_ADDRESSProfileHandler.FIELD_SURCHRG_RATE_CDT, bpayAddressRec.getSurchrgRateCdt());
				
				fcModifiedFields.addField(BPAY_ADDRESSProfileHandler.FIELD_ACCPTD_ACT_DBT, bpayAddressRec.isAccptAcctDbt()?"1":"0");
				fcModifiedFields.addField(BPAY_ADDRESSProfileHandler.FIELD_MAX_AMT_ACCPTD_DBT, bpayAddressRec.getMaxAmtAccptdDbt());
				fcModifiedFields.addField(BPAY_ADDRESSProfileHandler.FIELD_MIN_AMT_ACCPTD_DBT, bpayAddressRec.getMinAmtAccptdDbt());
				fcModifiedFields.addField(BPAY_ADDRESSProfileHandler.FIELD_SURCHRG_AMT_DBT, bpayAddressRec.getSurchrgAmtDbt());
				fcModifiedFields.addField(BPAY_ADDRESSProfileHandler.FIELD_SURCHRG_RATE_DBT, bpayAddressRec.getSurchrgRateDbt());

				
				Feedback profileUpdateFeedback = new BPAY_ADDRESSProfileHandler().setProfileUpdate(reqMatchedPdo.getString(MamboConstantsInterface.OX_MAM_CRED_USER_ID), fcModifiedFields,(reqAddressId==null)?AuditHandler.ACTION_CREATE:AuditHandler.ACTION_UPDATE, bpayAddressRec.getAddressId());
				if (!profileUpdateFeedback.isSuccessful()){
					logger.error("The BPAY ADDRESS : {} creation/update failed to be logged in PROFILE_UPDATE table in DB. Will continue flow as usual",bpayAddressRec.getAddressId());
				}

			}else{
				logger.error("BPAY_ADDRESS profile update has failed.");
			}
		} else if (reqMsgType.equals(MessageConstantsInterface.MESSAGE_TYPE_MAMBO_FTM441)) {
			String addressID = reqMatchedPdo.getString(MamboConstantsInterface.X_MAM_ORGTR_SCHME_ADR_ID);
			String newStatus = reqMatchedPdo.getString(MamboConstantsInterface.X_MAM_ADR_STS);
			feedback = m_daoBpayAddress.amendStatus(addressID, newStatus);
			if (feedback.isSuccessful()) {
				FieldsContainer fcModifiedFields = new FieldsContainer();
				fcModifiedFields.addField(BPAY_ADDRESSProfileHandler.FIELD_ADR_STS, newStatus);
				Feedback profileUpdateFeedback = new BPAY_ADDRESSProfileHandler().setProfileUpdate(reqMatchedPdo.getString(MamboConstantsInterface.OX_MAM_CRED_USER_ID), fcModifiedFields,AuditHandler.ACTION_UPDATE,addressID);
				if (!profileUpdateFeedback.isSuccessful()){
					logger.error("The BPAY ADDRESS : {} amend status failed to be logged in PROFILE_UPDATE table in DB. Will continue flow as usual",addressID);
				}
			}
		}
		else if (reqMsgType.equals(MessageConstantsInterface.MESSAGE_TYPE_MAMBO_FTM451)){
			logger.debug("No profiles to update for lookup service response");
		}

		return feedback;
	}

	
	
	private void setExternalErrorsInfo(PDO pdo,String[][] additionalParams){
		Errcodes extErrCodeRecord = null;
		int numOfExtErrs = pdo.countOccurrences(MamboConstantsInterface.X_MAM_RESP_STS_RSN_GROUP);
		for (int i=0 ; i<numOfExtErrs ; i++){
			String sExtErrCode = pdo.get(new Object[]{MamboConstantsInterface.X_MAM_RESP_STS_RSN_GROUP, i,MamboConstantsInterface.X_MAM_RESP_STS_EXT_RSN_CODE}).toString();
			
			extErrCodeRecord = CacheKeys.errcodesKey.getSingle(GlobalConstants.DEFAULT_SERVER_OFFICE_NAME,"MAMBO", pdo.getString(PDOConstantFieldsInterface.P_MSG_TYPE), sExtErrCode);
			
			//set external error text
			String extErrTxt = "";
			if (extErrCodeRecord!=null){
				extErrTxt = extErrCodeRecord.getContents();
				Object[] extErrTxtParams = additionalParams[i];
				extErrTxt = String.format(extErrTxt, extErrTxtParams).replaceAll("%s", "?");
				pdo.set((Object)extErrTxt,new Object[]{MamboConstantsInterface.X_MAM_RESP_STS_RSN_GROUP, i, MamboConstantsInterface.X_MAM_RESP_EXT_ERR_TEXT});
			}
			
			
			InternalError hubExtError = new InternalError(ProcessErrorConstants.MAMBO_FAILURE_HUB_ERROR, new Object[]{});
			hubExtError.reportInternalError(pdo,"Hub Error");
			
			//set internal error code
			pdo.set((Object)String.valueOf(hubExtError.getCode()),new Object[]{MamboConstantsInterface.X_MAM_RESP_STS_RSN_GROUP, i, MamboConstantsInterface.X_MAM_RESP_INTR_STS_RSN_CODE});
			
			//set internal error text
			pdo.set((Object)hubExtError.getErrorText(),new Object[]{MamboConstantsInterface.X_MAM_RESP_STS_RSN_GROUP, i, MamboConstantsInterface.X_MAM_RESP_INTR_ERR_TEXT});
			
			//set error origin to 'external'
			pdo.set((Object)MamboConstantsInterface.ERROR_ORIGIN_EXTERNAL,new Object[]{MamboConstantsInterface.X_MAM_RESP_STS_RSN_GROUP, i, MamboConstantsInterface.X_MAM_RESP_ERR_ORIGIN});
		}
		
	}
	

	

	private String[][] getExternalErrorsParams(PDO pdo){
		int numOfErrors = pdo.countOccurrences(MamboConstantsInterface.X_MAM_RESP_STS_RSN_GROUP);
		String[][] arrAddtlInfos = new String[numOfErrors][];
		for (int i=0; i<numOfErrors ; i++){
			int numOfAddtlInfoForError = 0;
			String[] addtlInfosForError = new String[5];
			Arrays.fill(addtlInfosForError, "N/A");
			
			while (numOfAddtlInfoForError<5 && pdo.get(new Object[]{MamboConstantsInterface.X_MAM_RESP_STS_RSN_GROUP, i, MamboConstantsInterface.X_MAM_RESP_STS_RSN_ADDTL_INF, numOfAddtlInfoForError})!=null){
				String addtlInf = pdo.get(new Object[]{MamboConstantsInterface.X_MAM_RESP_STS_RSN_GROUP, i, MamboConstantsInterface.X_MAM_RESP_STS_RSN_ADDTL_INF, numOfAddtlInfoForError}).toString();
				addtlInfosForError[numOfAddtlInfoForError]=addtlInf;
				numOfAddtlInfoForError++;
			}
			arrAddtlInfos[i] = addtlInfosForError;
		}

		return arrAddtlInfos;
	}


	private void addTransportProperties(PDO pdo, PDO relatedPDO) {
		String transportProperty = (String)relatedPDO.get(PDOConstantFieldsInterface.X_EXTN_INTERFACES_TRANS_PROP);
		
		if (logger.isDebugEnabled())
			logger.debug("PDO ("+pdo.getMID()+") transport properties: "+transportProperty+"(relatedPDO "+ relatedPDO.getMID()+")");
				
		pdo.set(PDOConstantFieldsInterface.X_EXTN_INTERFACES_TRANS_PROP,transportProperty);		
	}
	
	private void transformChannelRequestToHubRequest(PDO pdo) throws Throwable{
		String messageType = pdo.getString(PDOConstantFieldsInterface.P_MSG_TYPE);
		String targetMessageType = null;
		if (messageType.equals(MessageConstantsInterface.MESSAGE_TYPE_MAMBO_FTM401)){
			targetMessageType = MessageConstantsInterface.MESSAGE_TYPE_MAMBO_BPAY401;		
		}else if (messageType.equals(MessageConstantsInterface.MESSAGE_TYPE_MAMBO_FTM411)){
			targetMessageType = MessageConstantsInterface.MESSAGE_TYPE_MAMBO_BPAY411;
		}else if (messageType.equals(MessageConstantsInterface.MESSAGE_TYPE_MAMBO_FTM441)){
			targetMessageType = MessageConstantsInterface.MESSAGE_TYPE_MAMBO_BPAY441;
		}else if (messageType.equals(MessageConstantsInterface.MESSAGE_TYPE_MAMBO_FTM451)){
			targetMessageType = MessageConstantsInterface.MESSAGE_TYPE_MAMBO_BPAY451;
		}
		
			
		if (targetMessageType == null)
			throw new RuntimeException("can't determine the the transform type");
		
		logger.debug("Transforming {} message type to {}.",messageType,targetMessageType);
		pdo.transform(targetMessageType);
	}
	
	private void transformHubResponseToChannelResponse(PDO pdo) throws Throwable{
		String messageType = pdo.getString(PDOConstantFieldsInterface.P_MSG_TYPE);
		if (messageType.equals(MessageConstantsInterface.MESSAGE_TYPE_MAMBO_BPAY402)){
			logger.debug("Transforming {} message type to {}.",messageType,MessageConstantsInterface.MESSAGE_TYPE_MAMBO_FTM402);
			pdo.transform(MessageConstantsInterface.MESSAGE_TYPE_MAMBO_FTM402);
			
		}else if (messageType.equals(MessageConstantsInterface.MESSAGE_TYPE_MAMBO_BPAY452)){
			logger.debug("Transforming {} message type to {}.",messageType,MessageConstantsInterface.MESSAGE_TYPE_MAMBO_FTM452);
			int occurs = pdo.countOccurrences("X_MAM_SCHME_ADR_DISP_INF");
			final class DispInf{
				String othrid1;
				String othrissr1;
				String othrid2;
				String othrissr2;
				String allwblUse;
				String acctTp1;
				String minAccptd1;
				String minAccptdCcy1;
				String maxAccptd1;
				String maxAccptdCcy1;
				String acctTp2;
				String minAccptd2;
				String minAccptdCcy2;
				String maxAccptd2;
				String maxAccptdCcy2;
			}
			
			DispInf[] dispInfos = new DispInf[occurs];
			for (int i=0; i< occurs ; i++){
				DispInf displayInfo = new DispInf();
				displayInfo.othrid1 = pdo.getString(new Object[]{"X_MAM_SCHME_ADR_DISP_INF",i,"X_MAM_OTHR_ID",0,"X_MAM_OTHR_ID_ID"});
				displayInfo.othrissr1 = pdo.getString(new Object[]{"X_MAM_SCHME_ADR_DISP_INF",i,"X_MAM_OTHR_ID",0,"X_MAM_OTHR_ID_ISSR"});
				displayInfo.othrid2 = pdo.getString(new Object[]{"X_MAM_SCHME_ADR_DISP_INF",i,"X_MAM_OTHR_ID",1,"X_MAM_OTHR_ID_ID"});
				displayInfo.othrissr2 = pdo.getString(new Object[]{"X_MAM_SCHME_ADR_DISP_INF",i,"X_MAM_OTHR_ID",1,"X_MAM_OTHR_ID_ISSR"});
				
				displayInfo.allwblUse = pdo.getString(new Object[]{"X_MAM_SCHME_ADR_DISP_INF",i,"X_MAM_ALLWBL_USE",0});
				
				displayInfo.acctTp1 = pdo.getString(new Object[]{"X_MAM_SCHME_ADR_DISP_INF",i,"X_MAM_ACCPTD_ACCT_OPT",0,"X_MAM_ACCPTD_ACCT_TP"}); 
				displayInfo.minAccptd1 = pdo.getString(new Object[]{"X_MAM_SCHME_ADR_DISP_INF",i,"X_MAM_ACCPTD_ACCT_OPT",0,"X_MAM_MIN_ACCPTD"});
				displayInfo.minAccptdCcy1 = pdo.getString(new Object[]{"X_MAM_SCHME_ADR_DISP_INF",i,"X_MAM_ACCPTD_ACCT_OPT",0,"X_MAM_MIN_ACCPTD_CCY"});
				displayInfo.maxAccptd1 =	pdo.getString(new Object[]{"X_MAM_SCHME_ADR_DISP_INF",i,"X_MAM_ACCPTD_ACCT_OPT",0,"X_MAM_MAX_ACCPTD"});
				displayInfo.maxAccptdCcy1 = pdo.getString(new Object[]{"X_MAM_SCHME_ADR_DISP_INF",i,"X_MAM_ACCPTD_ACCT_OPT",0,"X_MAM_MAX_ACCPTD_CCY"});
				
				displayInfo.acctTp2 = pdo.getString(new Object[]{"X_MAM_SCHME_ADR_DISP_INF",i,"X_MAM_ACCPTD_ACCT_OPT",1,"X_MAM_ACCPTD_ACCT_TP"});
				displayInfo.minAccptd2 = pdo.getString(new Object[]{"X_MAM_SCHME_ADR_DISP_INF",i,"X_MAM_ACCPTD_ACCT_OPT",1,"X_MAM_MIN_ACCPTD"});
				displayInfo.minAccptdCcy2 = pdo.getString(new Object[]{"X_MAM_SCHME_ADR_DISP_INF",i,"X_MAM_ACCPTD_ACCT_OPT",1,"X_MAM_MIN_ACCPTD_CCY"});
				displayInfo.maxAccptd2 =	pdo.getString(new Object[]{"X_MAM_SCHME_ADR_DISP_INF",i,"X_MAM_ACCPTD_ACCT_OPT",1,"X_MAM_MAX_ACCPTD"});
				displayInfo.maxAccptdCcy2 = pdo.getString(new Object[]{"X_MAM_SCHME_ADR_DISP_INF",i,"X_MAM_ACCPTD_ACCT_OPT",1,"X_MAM_MAX_ACCPTD_CCY"});

				dispInfos[i] = displayInfo;
			}

			
			pdo.transform(MessageConstantsInterface.MESSAGE_TYPE_MAMBO_FTM452);
			
			for (int i=0; i< occurs ; i++){				
				//i-th dispInf , othrid 
		        if (dispInfos[i].othrid1!=null)
		        	pdo.set((Object)dispInfos[i].othrid1,new Object[]{"X_MAM_SCHME_ADR_DISP_INF",i,"X_MAM_OTHR_ID",0,"X_MAM_OTHR_ID_ID"});
		        if (dispInfos[i].othrissr1 != null)
		        	pdo.set((Object)dispInfos[i].othrissr1,new Object[]{"X_MAM_SCHME_ADR_DISP_INF",i,"X_MAM_OTHR_ID",0,"X_MAM_OTHR_ID_ISSR"});
		        if (dispInfos[i].othrid2 != null)
		        	pdo.set((Object)dispInfos[i].othrid2,new Object[]{"X_MAM_SCHME_ADR_DISP_INF",i,"X_MAM_OTHR_ID",1,"X_MAM_OTHR_ID_ID"});
		        if (dispInfos[i].othrissr2 != null)
		        	pdo.set((Object)dispInfos[i].othrissr2,new Object[]{"X_MAM_SCHME_ADR_DISP_INF",i,"X_MAM_OTHR_ID",1,"X_MAM_OTHR_ID_ISSR"});
		        //i-th dispInf , allwblUse
		        if (dispInfos[i].allwblUse != null)
		        	pdo.set((Object)dispInfos[i].allwblUse,new Object[]{"X_MAM_SCHME_ADR_DISP_INF",i,"X_MAM_ALLWBL_USE",0});
		        //i-th dispInf , 1st acct_opt 
		        if (dispInfos[i].acctTp1 != null)
		        	pdo.set((Object)dispInfos[i].acctTp1, new Object[]{"X_MAM_SCHME_ADR_DISP_INF",i,"X_MAM_ACCPTD_ACCT_OPT",0,"X_MAM_ACCPTD_ACCT_TP"});
		        if (dispInfos[i].minAccptd1 != null)
		        	pdo.set((Object)dispInfos[i].minAccptd1,new Object[]{"X_MAM_SCHME_ADR_DISP_INF",i,"X_MAM_ACCPTD_ACCT_OPT",0,"X_MAM_MIN_ACCPTD"});
		        if (dispInfos[i].minAccptdCcy1 != null)
		        	pdo.set((Object)dispInfos[i].minAccptdCcy1, new Object[]{"X_MAM_SCHME_ADR_DISP_INF",i,"X_MAM_ACCPTD_ACCT_OPT",0,"X_MAM_MIN_ACCPTD_CCY"});
		        if (dispInfos[i].maxAccptd1 != null)
		        	pdo.set((Object)dispInfos[i].maxAccptd1, new Object[]{"X_MAM_SCHME_ADR_DISP_INF",i,"X_MAM_ACCPTD_ACCT_OPT",0,"X_MAM_MAX_ACCPTD"});
		        if (dispInfos[i].maxAccptdCcy1 != null)
		        	pdo.set((Object)dispInfos[i].maxAccptdCcy1, new Object[]{"X_MAM_SCHME_ADR_DISP_INF",i,"X_MAM_ACCPTD_ACCT_OPT",0,"X_MAM_MAX_ACCPTD_CCY"});
				//i-th dispInf , 2nd acct_opt 
		        if (dispInfos[i].acctTp2 != null)	
		        	pdo.set((Object)dispInfos[i].acctTp2, new Object[]{"X_MAM_SCHME_ADR_DISP_INF",i,"X_MAM_ACCPTD_ACCT_OPT",1,"X_MAM_ACCPTD_ACCT_TP"});
		        if (dispInfos[i].minAccptd2 != null)
		        	pdo.set((Object)dispInfos[i].minAccptd2, new Object[]{"X_MAM_SCHME_ADR_DISP_INF",i,"X_MAM_ACCPTD_ACCT_OPT",1,"X_MAM_MIN_ACCPTD"});
		        if (dispInfos[i].minAccptdCcy2 != null)
		        	pdo.set((Object)dispInfos[i].minAccptdCcy2, new Object[]{"X_MAM_SCHME_ADR_DISP_INF",i,"X_MAM_ACCPTD_ACCT_OPT",1,"X_MAM_MIN_ACCPTD_CCY"});
		        if (dispInfos[i].maxAccptd2 != null)
		        	pdo.set((Object)dispInfos[i].maxAccptd2, new Object[]{"X_MAM_SCHME_ADR_DISP_INF",i,"X_MAM_ACCPTD_ACCT_OPT",1,"X_MAM_MAX_ACCPTD"});
		        if (dispInfos[i].maxAccptdCcy2 != null)
		        	pdo.set((Object)dispInfos[i].maxAccptdCcy2, new Object[]{"X_MAM_SCHME_ADR_DISP_INF",i,"X_MAM_ACCPTD_ACCT_OPT",1,"X_MAM_MAX_ACCPTD_CCY"});
			}
			
		}	
	}
	
	private void setFieldsToNewHubRequest(PDO pdo){
		//set TxId
		String txId= generateTxId(pdo);
		pdo.set(MamboConstantsInterface.X_MAM_TX_ID , txId);
		//set version to default value (1.00)
		pdo.set(MamboConstantsInterface.X_MAM_VERSION , MamboConstantsInterface.VERSION);
		//set from_FIID 
		pdo.set(MamboConstantsInterface.X_MAM_FR_FIID,getBankRefernceBranch(pdo.getString(PDOConstantFieldsInterface.P_OFFICE)));
		//set TO_FIID
		pdo.set(MamboConstantsInterface.X_MAM_TO_FIID,CacheKeys.SystParKey.getSingle(GlobalConstants.DEFAULT_SERVER_OFFICE_NAME, SystemParametersInterface.SYST_PAR_HUB_FIID).getParmValue());
		//set bizMsgIdr to be like TxId
		pdo.set(MamboConstantsInterface.X_MAM_BIZ_MSG_IDR,txId);
		//set MsgDefIdr to be the name of outgoing message
		pdo.set(MamboConstantsInterface.X_MAM_MSG_DEF_IDR,getMsgDefIdr(pdo));
		//set extension
		pdo.set(MamboConstantsInterface.X_MAM_ADDTL_XTNSN_ELEM, "");
	}
}