package backend.mambo.businessobjects;

import static com.fundtech.util.GlobalUtils.isNullOrEmpty;
import java.util.Date;
import com.fundtech.cache.entities.Banks;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.cache.syspar.SystemParametersInterface;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.core.paymentprocess.errorhandling.ProcessError;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.errors.ProcessErrorConstants;
import com.fundtech.util.GlobalConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import backend.businessobject.BOBasic;
import backend.core.module.MessageConstantsInterface;
import backend.paymentprocess.erroraudit.ErrorAuditUtils;
import backend.paymentprocess.paymentservices.businessobjects.BOPaymentServices;
import com.fundtech.util.datetime.NewASDateTimeUtils;


public class BOMamboSetBasicProperties extends BOBasic implements PDOConstantFieldsInterface, MessageConstantsInterface
{

	private static final Logger logger = LoggerFactory.getLogger(BOMamboSetBasicProperties.class);
	private static final String SET_BASIC_PROPERTIES = "Set Basic Properties";
	private static final ProcessError m_pErrorSetBasicPropertiesServiceFailure = new ProcessError(ProcessErrorConstants.ServiceFailure, new Object[]{SET_BASIC_PROPERTIES});

	private static final String TRACE_METHOD_OUTPUT = "Method output result: {}.";

	private static final String LAST_STEP = "MID: %s, Last step: %s.";
	private static final String STEP_SET_PAYMENT_OFFICE = "Set payment office";


	/*
	 * 
	 * @param sMID
	 * @return
	 * @throws Throwable
	 */
	public Feedback setMamboBasicProperties(final String sMID){

		final String TRACE_INVALID_OFFICE = "Request includes invalid office: {}.";

		Feedback feedback = new Feedback();
		boolean bSuccess = true;
		String sLastStep = null;
		ProcessError processError = null;
		Integer partitionID = 0;
		try
		{
			PDO pdo = PaymentDataFactory.load(sMID);
			partitionID = pdo.getIsHistory();
			String sP_OFFICE = pdo.getString(P_OFFICE);
			String sP_CREATE_DT = pdo.getString(P_CREATE_DT);	
			String sP_DBT_MOP = pdo.getString(P_DBT_MOP);

			
			//In case office is null, set to office from parameter, if parameter is also null - set to default (***)
			if(isNullOrEmpty(sP_OFFICE))
			{
				sLastStep = STEP_SET_PAYMENT_OFFICE;
				bSuccess = setMamboPaymentOffice();
			}else{
				logger.info("Office was already set before calling this method. (Probably in the interface's getPDO(). And its value is {}", sP_OFFICE);
			}

			// Sets the create date; only for new messages.
			if((pdo.isNew() || isNullOrEmpty(sP_CREATE_DT)))
			{
				pdo.set(P_CREATE_DT, NewASDateTimeUtils.getCurrentDateAndZoneByOffice(pdo.getString(P_OFFICE)).getDate()) ;
			} 
			
			//Set DBT MOP to BPAY
			pdo.set(P_DBT_MOP,MessageConstantsInterface.MOP_BPAY);

			// Assures that the office is a valid one.
			sP_OFFICE = pdo.getString(P_OFFICE);
			Banks banks = CacheKeys.banksKey.getSingle(sP_OFFICE);
			if(banks == null)
			{
				logger.info(TRACE_INVALID_OFFICE, sP_OFFICE);

				// Error code 60089: 'Invalid office: |1'.
				processError = new ProcessError(ProcessErrorConstants.InvalidOffice, new Object[]{sP_OFFICE});
				bSuccess = false;
			}
      
		}
		catch(Throwable t)
		{
			traceAndConfigureErrorFeedback(sMID, sLastStep, feedback, true, processError,partitionID);
		
		}
		return feedback;
	}

	private boolean setMamboPaymentOffice()
	{
//		final String TRACE_SELECTED_OFFICE = "Selected P_OFFICE: {}.";
//		final String TRACE_SELECTED_DEPARTMENT = "Selected P_DEPARTMENT: {}.";
//		final String TRACE_OFFICE_SELECTED_USING_INTERFACE_TYPES_TABLE = "Office is selected according to INTERFACE_TYPES table";
		final String TRACE_SETS_DEFAULT_OFFICE_AND_DEPARTMENT = "Office couldn't be derived from INTERFACE_TYPES table. sets default office ('***') and department ('...')";

		boolean bSuccess = true;
		boolean bSetDefaultOfficeAndDepartment = false;

		PDO pdo = Admin.getContextPDO();

		//Set office according to input and default department according to sys params
//		if(sOffice != null)
//		{
//			logger.info(TRACE_OFFICE_SELECTED_USING_INTERFACE_TYPES_TABLE);
//			final String sDefaultDepartmentPerOffice = CacheKeys.SystParKey.getSingle(sOffice, SystemParametersInterface.SYST_PAR_DEF_DEPT).getParmValue();
//			pdo.set(P_OFFICE,  sOffice) ;
//			pdo.set(P_DEPARTMENT,  sDefaultDepartmentPerOffice) ;
//			logger.info(TRACE_SELECTED_OFFICE, sOffice);
//			logger.info(TRACE_SELECTED_DEPARTMENT, sDefaultDepartmentPerOffice);
//		}
//		else
//		{
			bSetDefaultOfficeAndDepartment = true;
//		}

		// Office was not found; set its value and the department value to the default one.
		if(bSetDefaultOfficeAndDepartment)
		{
			logger.info(TRACE_SETS_DEFAULT_OFFICE_AND_DEPARTMENT);

			pdo.set(P_OFFICE, GlobalConstants.DEFAULT_SERVER_OFFICE_NAME);
			pdo.set(P_DEPARTMENT, BOPaymentServices.getDefaultDepartment(GlobalConstants.DEFAULT_SERVER_OFFICE_NAME)) ; 
			bSuccess = true;      	
		}
		logger.info(TRACE_METHOD_OUTPUT, bSuccess);
		return bSuccess;
	}


	/**
	 * 
	 */
	private void traceAndConfigureErrorFeedback(String sMID, String sLastStep, Feedback feedback, boolean bSetErrorIntoPDO,
			ProcessError processError, Integer partitionID)
	{
		final String FEEDBACK_ERROR_SEPARATOR = " - ";

		ProcessError finalProcessError;

		if(processError == null)
		{
			finalProcessError = m_pErrorSetBasicPropertiesServiceFailure;
			String sTraceLastStep = String.format(LAST_STEP, sMID, sLastStep);
			logger.info(sTraceLastStep);
			configureErrorFeedback(m_pErrorSetBasicPropertiesServiceFailure.getErrorCode(), m_pErrorSetBasicPropertiesServiceFailure.getDescription(), feedback);
			feedback.setErrorText(m_pErrorSetBasicPropertiesServiceFailure.getDescription() + FEEDBACK_ERROR_SEPARATOR + sTraceLastStep);
		}

		else
		{
			configureErrorFeedback(processError.getErrorCode(), processError.getDescription(), feedback);
			finalProcessError = processError;
		}

		if(bSetErrorIntoPDO) ErrorAuditUtils.setErrors(finalProcessError);	
	}


}
