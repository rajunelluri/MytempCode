package backend.mambo.dataaccess.dao;

import java.util.Date;
import java.util.LinkedList;
import java.util.List;


public class BPAYAddress {
	private String addressId;
	private String clientId;
	private String addressSts;
	private boolean persistent;
	private Date expirationTime;
	private String timeStamp;
	private String office;
	private String department;
	private String recSts;
	private Date updateDate;
	
	private String sctrId;
	private String sctrIssr;
	private String dispNm;
	private boolean dispNmOptOut;
	private String dispTxt;
	private String dispUrl;
	private String otherIdId1;
	private String otherIdIssr1;
	private String otherIdId2;
	private String otherIdIssr2;
	private String chrgCtgy;
	private boolean accptAcctCdt;
	private boolean accptAcctDbt;
	private String minAmtAccptdCdt;
	private String maxAmtAccptdCdt;
	private String minAmtAccptdDbt;
	private String maxAmtAccptdDbt;
	private String surchrgAmtCdt;
	private String surchrgRateCdt;
	private String surchrgAmtDbt;
	private String surchrgRateDbt;
	
	private List<LkdAcct> linkedAccounts = new LinkedList<LkdAcct>();
	private List<AllwblUse> allwblUsages = new LinkedList<AllwblUse>();
	


	
	
	
	public BPAYAddress() {
		super();
	}
	public String getAddressId() {
		return addressId;
	}
	public void setAddressId(String addressId) {
		this.addressId = addressId;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public String getAddressSts() {
		return addressSts;
	}
	public void setAddressSts(String addressSts) {
		this.addressSts = addressSts;
	}
	public boolean isPersistent() {
		return persistent;
	}
	public void setPersistent(boolean persistent) {
		this.persistent = persistent;
	}
	public Date getExpirationTime() {
		return expirationTime;
	}
	public void setExpirationTime(Date expirationTime) {
		this.expirationTime = expirationTime;
	}
	public String getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}
	public String getOffice() {
		return office;
	}
	public void setOffice(String office) {
		this.office = office;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getRecSts() {
		return recSts;
	}
	public void setRecSts(String recSts) {
		this.recSts = recSts;
	}
	public Date getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	public String getSctrId() {
		return sctrId;
	}
	public void setSctrId(String sctrId) {
		this.sctrId = sctrId;
	}
	public String getSctrIssr() {
		return sctrIssr;
	}
	public void setSctrIssr(String sctrIssr) {
		this.sctrIssr = sctrIssr;
	}
	public String getDispNm() {
		return dispNm;
	}
	public void setDispNm(String dispNm) {
		this.dispNm = dispNm;
	}
	public boolean isDispNmOptOut() {
		return dispNmOptOut;
	}
	public void setDispNmOptOut(boolean dispNmOptOut) {
		this.dispNmOptOut = dispNmOptOut;
	}
	public String getDispTxt() {
		return dispTxt;
	}
	public void setDispTxt(String dispTxt) {
		this.dispTxt = dispTxt;
	}
	public String getDispUrl() {
		return dispUrl;
	}
	public void setDispUrl(String dispUrl) {
		this.dispUrl = dispUrl;
	}
	public String getOtherIdId1() {
		return otherIdId1;
	}
	public void setOtherIdId1(String otherIdId1) {
		this.otherIdId1 = otherIdId1;
	}
	public String getOtherIdIssr1() {
		return otherIdIssr1;
	}
	public void setOtherIdIssr1(String otherIdIssr1) {
		this.otherIdIssr1 = otherIdIssr1;
	}

	public String getOtherIdId2() {
		return otherIdId2;
	}
	public void setOtherIdId2(String otherIdId2) {
		this.otherIdId2 = otherIdId2;
	}
	public String getOtherIdIssr2() {
		return otherIdIssr2;
	}
	public void setOtherIdIssr2(String otherIdIssr2) {
		this.otherIdIssr2 = otherIdIssr2;
	}
	public String getChrgCtgy() {
		return chrgCtgy;
	}
	public void setChrgCtgy(String chrgCtgy) {
		this.chrgCtgy = chrgCtgy;
	}
	public boolean isAccptAcctCdt() {
		return accptAcctCdt;
	}
	public void setAccptAcctCdt(boolean accptAcctCdt) {
		this.accptAcctCdt = accptAcctCdt;
	}
	public boolean isAccptAcctDbt() {
		return accptAcctDbt;
	}
	public void setAccptAcctDbt(boolean accptAcctDbt) {
		this.accptAcctDbt = accptAcctDbt;
	}
	public String getMinAmtAccptdCdt() {
		return minAmtAccptdCdt;
	}
	public void setMinAmtAccptdCdt(String minAmtAccptdCdt) {
		this.minAmtAccptdCdt = minAmtAccptdCdt;
	}
	public String getMaxAmtAccptdCdt() {
		return maxAmtAccptdCdt;
	}
	public void setMaxAmtAccptdCdt(String maxAmtAccptdCdt) {
		this.maxAmtAccptdCdt = maxAmtAccptdCdt;
	}
	public String getMinAmtAccptdDbt() {
		return minAmtAccptdDbt;
	}
	public void setMinAmtAccptdDbt(String minAmtAccptdDbt) {
		this.minAmtAccptdDbt = minAmtAccptdDbt;
	}
	public String getMaxAmtAccptdDbt() {
		return maxAmtAccptdDbt;
	}
	public void setMaxAmtAccptdDbt(String maxAmtAccptdDbt) {
		this.maxAmtAccptdDbt = maxAmtAccptdDbt;
	}
	public String getSurchrgAmtCdt() {
		return surchrgAmtCdt;
	}
	public void setSurchrgAmtCdt(String surchrgAmtCdt) {
		this.surchrgAmtCdt = surchrgAmtCdt;
	}
	public String getSurchrgRateCdt() {
		return surchrgRateCdt;
	}
	public void setSurchrgRateCdt(String surchrgRateCdt) {
		this.surchrgRateCdt = surchrgRateCdt;
	}
	public String getSurchrgAmtDbt() {
		return surchrgAmtDbt;
	}
	public void setSurchrgAmtDbt(String surchrgAmtDbt) {
		this.surchrgAmtDbt = surchrgAmtDbt;
	}
	public String getSurchrgRateDbt() {
		return surchrgRateDbt;
	}
	public void setSurchrgRateDbt(String surchrgRateDbt) {
		this.surchrgRateDbt = surchrgRateDbt;
	}
	

	public List<LkdAcct> getLinkedAccounts() {
		return linkedAccounts;
	}
	public void addLinkedAccount(LkdAcct linkedAccount) {
		this.linkedAccounts.add(linkedAccount);
	}
	public List<AllwblUse> getAllwblUsages() {
		return allwblUsages;
	}
	public void addAllwblUsage(AllwblUse use) {
		this.allwblUsages.add(use);
	}


	public class LkdAcct{
		private String lkdAcctId;
		private String lkdAcctTp;
		private String custAcctTp;
		private String acctCcy;
		
		public String getLkdAcctId() {
			return lkdAcctId;
		}
		public void setLkdAcctId(String lkdAcctId) {
			this.lkdAcctId = lkdAcctId;
		}
		public String getLkdAcctTp() {
			return lkdAcctTp;
		}
		public void setLkdAcctTp(String lkdAcctTp) {
			this.lkdAcctTp = lkdAcctTp;
		}
		public String getCustAcctTp() {
			return custAcctTp;
		}
		public void setCustAcctTp(String custAcctTp) {
			this.custAcctTp = custAcctTp;
		}
		public String getAcctCcy() {
			return acctCcy;
		}
		public void setAcctCcy(String acctCcy) {
			this.acctCcy = acctCcy;
		}
	}
	
	
	public class AllwblUse{
		String use;

		public String getUse() {
			return use;
		}

		public void setUse(String use) {
			this.use = use;
		}	
	}
	

}
