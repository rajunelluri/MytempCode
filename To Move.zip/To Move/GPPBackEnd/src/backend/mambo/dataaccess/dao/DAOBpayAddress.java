package backend.mambo.dataaccess.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.dataaccess.dao.DAOBasic;
import backend.mambo.dataaccess.dao.BPAYAddress.AllwblUse;
import backend.staticdata.profilehandler.message.BPAY_ADDRESSProfileHandler;

import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.util.GlobalDateTimeUtil;


public class DAOBpayAddress extends DAOBasic 
{
	
	public final static String RSVD_ADDRESS_STATUS = "RSVD";
	public final static String ACTIVE_ADDRESS_STATUS = "ACTV";
	public final static String INACTIVE_ADDRESS_STATUS = "INAT";
	public final static String CLOSED_ADDRESS_STATUS = "CLSD";
	
    private static DAOBpayAddress m_daoBpayAddress = new DAOBpayAddress();
    private static final Logger logger = LoggerFactory.getLogger(DAOBpayAddress.class);
  /**
   * Private constructor. 
   */
  private DAOBpayAddress()
  {
  }
  
  public static DAOBpayAddress getInstance()
  {
    return m_daoBpayAddress;
  }
  
  
  public Feedback insertRecordInto_BPAY_ADDRESS_Table(List<String> sBpayAddresses,String sClientId,String sAddressStatus,
		  boolean isPersistent,String sExpirationTime,String sTimeStamp, String sOffice, String sDepartment, String sRecordStatus, String sUpdateDate)
  {
	  PreparedStatement selectprepStmnt=null;
	  PreparedStatement insertprepStmnt=null;
	  Connection con =null;
	  Feedback feedbackRetVal = new Feedback();


	  if (logger.isDebugEnabled())
		  logger.debug("In insertRecordInto_BPAY_ADDRESS_Table()");
	  int numOfAddresses = sBpayAddresses.size();
	  if (numOfAddresses==0)
		  return feedbackRetVal;

	  String SELECT_FROM_BPAY_ADDRESS_QUERY_STRING = 
		  "SELECT COUNT(*) FROM BPAY_ADDRESS WHERE UID_BPAY_ADDRESS IN (";
	  for (int i=0 ; i<numOfAddresses; i++){
		  if (i == (numOfAddresses-1))
			  SELECT_FROM_BPAY_ADDRESS_QUERY_STRING += "?)";
		  else
			  SELECT_FROM_BPAY_ADDRESS_QUERY_STRING += "? ,";
	  }
	  
	  
	  try{
		  
		  con = getConnection();
		  
		  if (logger.isDebugEnabled())
			  logger.debug("Verify that neither one of the addresses already exist in BPAY_ADDRESS table in DB");
		  //check that neither one of the addresses exist in DB
		  selectprepStmnt = con.prepareStatement(SELECT_FROM_BPAY_ADDRESS_QUERY_STRING);
		  
		  for (int i=1; i<=sBpayAddresses.size() ; i++){
			  selectprepStmnt.setString(i,sBpayAddresses.get(i-1));
		  }
		  ResultSet rs = selectprepStmnt.executeQuery();
		  int countResult = 1;
		  if (rs.next()){
			  countResult = rs.getInt(1);
		  }
		  if (countResult>0){	
			  throw new Exception("One or more of the addresses already exist in BPAY_ADDRESS table"); 
		  }


		  if (logger.isDebugEnabled())
			  logger.debug("Addresses do not exist in BPAY_ADDRESS table in DB, now trying to insert them");
		  
		  final String INSERT_TO_BPAY_ADDRESS_QUERY_STRING = 
			  "INSERT INTO BPAY_ADDRESS"+
			  "(UID_BPAY_ADDRESS, SCHME_ADR_ID, CLNT_ID, ADR_STS, PSTNT_RSVATN, EXPIRATION_TIME, TIME_STAMP, OFFICE, DEPARTMENT, REC_STATUS, UPDATE_DATE)"+
			  "VALUES(?,?,?,?,?,TO_DATE(?,'mm/dd/yyyy hh:mi:ss am'),?,?,?,?,TO_DATE(?,'mm/dd/yyyy hh:mi:ss am'))" ; 

		  insertprepStmnt = con.prepareStatement(INSERT_TO_BPAY_ADDRESS_QUERY_STRING);

		  insertprepStmnt.setString(3,sClientId);
		  insertprepStmnt.setString(4,sAddressStatus);
		  insertprepStmnt.setInt(5,isPersistent?1:0);
		  insertprepStmnt.setString(6,sExpirationTime);//date
		  insertprepStmnt.setString(7,sTimeStamp);
		  insertprepStmnt.setString(8,sOffice);
		  insertprepStmnt.setString(9,sDepartment);
		  insertprepStmnt.setString(10,sRecordStatus);
		  insertprepStmnt.setString(11,sUpdateDate);//date

		  int loopCount=0;
		  String concatAddresses = "";
		  for (String sBpayAddress : sBpayAddresses){
			  insertprepStmnt.setString(1,sBpayAddress);
			  insertprepStmnt.setString(2,sBpayAddress);
			  insertprepStmnt.addBatch();
			  loopCount++;
			  concatAddresses = concatAddresses.concat("'"+sBpayAddress+"' ; ");
		  }

		  int count[] = insertprepStmnt.executeBatch();

		  if (logger.isDebugEnabled())
			  logger.debug("Successfully inserted "+(loopCount)+" new addresses into BPAY_ADDRESS table. The following new addresses were added: "+concatAddresses);


	  }catch(Exception e){
		  // An error has occurred while trying to perform this action
		  logger.error("Insert process into BPAY_ADDRESS has failed.",e);
		  feedbackRetVal.setFailure(); 
		  feedbackRetVal.setException(e); 
	  }
	  finally{
		  releaseResources(null, insertprepStmnt, con); 
		  releaseResources(null, selectprepStmnt, con); 
	  }
	  return feedbackRetVal;
  }
  
  public int getNbPstntRsrvForFI(String office){
	  if (logger.isDebugEnabled())
		  logger.debug("In getNbPstntRsrvForFI()");

	  final String COUNT_PERSISTENT_PER_OFFICE_FROM_BPAY_ADDRESS_QUERY_STRING = 
		  "SELECT COUNT(*) FROM BPAY_ADDRESS WHERE ADR_STS='"+RSVD_ADDRESS_STATUS+"' AND PSTNT_RSVATN=1 AND REC_STATUS='AC' AND OFFICE=?";
	  PreparedStatement prepStmnt=null;
	  Connection con =null;	
	  int countResponse=0;
	  try
	  {
		  con = getConnection(DATA_SOURCE_ID_ACTIVE);
		  prepStmnt = con.prepareStatement(COUNT_PERSISTENT_PER_OFFICE_FROM_BPAY_ADDRESS_QUERY_STRING);
		  prepStmnt.setString(1,office);
		  ResultSet rs = prepStmnt.executeQuery();
		  while (rs.next()){
			  countResponse = rs.getInt(1);
		  }
		  con.close();
	  }catch (Exception e){
		  // An error has occurred while trying to perform this action
		  logger.error(e.getMessage());
	  }finally{
		  releaseResources(null, prepStmnt, con); 
	  }
	  return countResponse;
  }
  
  public BPAYAddress getBPAYAddress(String addressId){
	  if (logger.isDebugEnabled())
		  logger.debug("In getBPAYAddress()");
	  
	  final String SELECT_FROM_BPAY_ADDRESS_QUERY_STRING = 
		  "SELECT * FROM BPAY_ADDRESS WHERE UID_BPAY_ADDRESS=? AND REC_STATUS='AC'";
	 
	  PreparedStatement prepStmnt=null;
	  Connection con =null;	
	  BPAYAddress address=null;
	  try
	  {
		  con = getConnection(DATA_SOURCE_ID_ACTIVE);
		  prepStmnt = con.prepareStatement(SELECT_FROM_BPAY_ADDRESS_QUERY_STRING);
		  prepStmnt.setString(1,addressId);
		  ResultSet rs = prepStmnt.executeQuery();
		  if (rs.next()){
			  address = new BPAYAddress();
			  address.setAddressId(rs.getString(BPAY_ADDRESSProfileHandler.FIELD_SCHME_ADR_ID));		
			  address.setClientId(rs.getString(BPAY_ADDRESSProfileHandler.FIELD_CLNT_ID));
			  address.setAddressSts(rs.getString(BPAY_ADDRESSProfileHandler.FIELD_ADR_STS));
			  address.setPersistent(rs.getInt(BPAY_ADDRESSProfileHandler.FIELD_PSTNT_RSVATN)==0?false:true);
			  address.setExpirationTime(rs.getTimestamp(BPAY_ADDRESSProfileHandler.FIELD_EXPIRATION_TIME));
			  address.setTimeStamp(rs.getString(BPAY_ADDRESSProfileHandler.FIELD_TIME_STAMP));
			  address.setOffice(rs.getString(BPAY_ADDRESSProfileHandler.FIELD_OFFICE));
			  address.setDepartment(rs.getString(BPAY_ADDRESSProfileHandler.FIELD_DEPARTMENT));
			  address.setRecSts(rs.getString(BPAY_ADDRESSProfileHandler.FIELD_REC_STATUS));
			  address.setUpdateDate(rs.getTimestamp(BPAY_ADDRESSProfileHandler.FIELD_UPDATE_DATE));
		  }
		  con.close();
	  }catch (Exception e){
		  // An error has occurred while trying to perform this action
		  logger.error(e.getMessage());
	  }finally{
		  releaseResources(null, prepStmnt, con); 
	  }
	  return address;
	  
  }
  
  
  public Feedback insert_or_update_BpayAddress(BPAYAddress bpayAddress)
  {
	  if (logger.isDebugEnabled())
		  logger.debug("In insert_or_update_BpayAddress()");
	  

	  PreparedStatement insertOrUpdateBpayAddressPrepStmnt=null;
	  PreparedStatement insertBpayAddressAllwblUsePrepStmnt=null;
	  PreparedStatement insertBpayAddressLkdAcctsPrepStmnt=null;
	  Connection con =null;
	  Feedback feedbackRetVal = new Feedback();
	  
	  boolean isRecordAlreadyExists = false;
	  if (getBPAYAddress(bpayAddress.getAddressId())!=null){
		  isRecordAlreadyExists=true;
	  }
	  
	  String INSERT_OR_UPDATE_BPAY_ADDRESS_QUERY_STRING="";
	  if (isRecordAlreadyExists){
		  INSERT_OR_UPDATE_BPAY_ADDRESS_QUERY_STRING = 
			  "UPDATE BPAY_ADDRESS SET "+
			  "UID_BPAY_ADDRESS=?, SCHME_ADR_ID=?, CLNT_ID=?, ADR_STS=?, PSTNT_RSVATN=?, EXPIRATION_TIME=TO_DATE(?,'mm/dd/yyyy hh:mi:ss am'), " +
			  "TIME_STAMP=?, OFFICE=?, DEPARTMENT=?, REC_STATUS=?, UPDATE_DATE=TO_DATE(?,'mm/dd/yyyy hh:mi:ss am')," +
			  "SCTR_ID=?, SCTR_ISSR=?, DISP_NM=?, DISP_NM_OPT_OUT=?, DISP_TXT=?, DISP_URL=?, OTHRID_ID1=?, OTHRID_ISSR1=?, OTHRID_ID2=?, OTHRID_ISSR2=?, CHRG_CTGY=?," +//22
			  "ACCPTD_ACT_CDT=?, ACCPTD_ACT_DBT=?, MIN_AMT_ACCPTD_CDT=?, MAX_AMT_ACCPTD_CDT=?,SURCHRG_AMT_CDT=?, SURCHRG_RATE_CDT=?, MIN_AMT_ACCPTD_DBT=?, MAX_AMT_ACCPTD_DBT=?,SURCHRG_AMT_DBT=?, SURCHRG_RATE_DBT=?" +//32
			  " WHERE UID_BPAY_ADDRESS=?";	//33 fields
	  }else {
			INSERT_OR_UPDATE_BPAY_ADDRESS_QUERY_STRING = 
				  "INSERT INTO BPAY_ADDRESS "+
				  "(UID_BPAY_ADDRESS, SCHME_ADR_ID, CLNT_ID, ADR_STS, PSTNT_RSVATN, EXPIRATION_TIME, TIME_STAMP, OFFICE, DEPARTMENT, REC_STATUS, UPDATE_DATE" +//11
				  ", SCTR_ID, SCTR_ISSR, DISP_NM, DISP_NM_OPT_OUT, DISP_TXT, DISP_URL, OTHRID_ID1, OTHRID_ISSR1, OTHRID_ID2, OTHRID_ISSR2, CHRG_CTGY" +//22
				  ",ACCPTD_ACT_CDT, ACCPTD_ACT_DBT, MIN_AMT_ACCPTD_CDT, MAX_AMT_ACCPTD_CDT, SURCHRG_AMT_CDT, SURCHRG_RATE_CDT, MIN_AMT_ACCPTD_DBT, MAX_AMT_ACCPTD_DBT, SURCHRG_AMT_DBT, SURCHRG_RATE_DBT)"+//32
				  "VALUES(?,?,?,?,?,TO_DATE(?,'mm/dd/yyyy hh:mi:ss am'),?,?,?,?,TO_DATE(?,'mm/dd/yyyy hh:mi:ss am')," +//11
				  "?,?,?,?,?,?,?,?,?,?,?"+//22
				  ",?,?,?,?,?,?,?,?,?,?)" ;//32
	  }
	  
	  try{
		  con = getConnection();

		  insertOrUpdateBpayAddressPrepStmnt = con.prepareStatement(INSERT_OR_UPDATE_BPAY_ADDRESS_QUERY_STRING);
		  
		  insertOrUpdateBpayAddressPrepStmnt.setString(1,bpayAddress.getAddressId());
		  insertOrUpdateBpayAddressPrepStmnt.setString(2,bpayAddress.getAddressId());
		  insertOrUpdateBpayAddressPrepStmnt.setString(3,bpayAddress.getClientId());
		  insertOrUpdateBpayAddressPrepStmnt.setString(4,bpayAddress.getAddressSts());
		  insertOrUpdateBpayAddressPrepStmnt.setInt(5,bpayAddress.isPersistent()?1:0);
		  insertOrUpdateBpayAddressPrepStmnt.setString(6,bpayAddress.getExpirationTime()==null?null:GlobalDateTimeUtil.getSimpleDateFormatByFormat(GlobalDateTimeUtil.STATIC_DATA_DATE_TIME_AM_PM_12).format(bpayAddress.getExpirationTime()));//date
		  insertOrUpdateBpayAddressPrepStmnt.setString(7,bpayAddress.getTimeStamp());
		  insertOrUpdateBpayAddressPrepStmnt.setString(8,bpayAddress.getOffice());
		  insertOrUpdateBpayAddressPrepStmnt.setString(9,bpayAddress.getDepartment());
		  insertOrUpdateBpayAddressPrepStmnt.setString(10,bpayAddress.getRecSts());
		  insertOrUpdateBpayAddressPrepStmnt.setString(11,bpayAddress.getUpdateDate()==null?null:GlobalDateTimeUtil.getSimpleDateFormatByFormat(GlobalDateTimeUtil.STATIC_DATA_DATE_TIME_AM_PM_12).format(bpayAddress.getUpdateDate()));//date

		  insertOrUpdateBpayAddressPrepStmnt.setString(12,bpayAddress.getSctrId());
		  insertOrUpdateBpayAddressPrepStmnt.setString(13,bpayAddress.getSctrIssr());
		  insertOrUpdateBpayAddressPrepStmnt.setString(14,bpayAddress.getDispNm());
		  insertOrUpdateBpayAddressPrepStmnt.setInt(15,bpayAddress.isDispNmOptOut()?1:0);
		  insertOrUpdateBpayAddressPrepStmnt.setString(16,bpayAddress.getDispTxt());
		  insertOrUpdateBpayAddressPrepStmnt.setString(17,bpayAddress.getDispUrl());
		  insertOrUpdateBpayAddressPrepStmnt.setString(18,bpayAddress.getOtherIdId1());
		  insertOrUpdateBpayAddressPrepStmnt.setString(19,bpayAddress.getOtherIdIssr1());
		  insertOrUpdateBpayAddressPrepStmnt.setString(20,bpayAddress.getOtherIdId2());
		  insertOrUpdateBpayAddressPrepStmnt.setString(21,bpayAddress.getOtherIdIssr2());
		  insertOrUpdateBpayAddressPrepStmnt.setString(22,bpayAddress.getChrgCtgy());
		  insertOrUpdateBpayAddressPrepStmnt.setInt(23,bpayAddress.isAccptAcctCdt()?1:0);
		  insertOrUpdateBpayAddressPrepStmnt.setInt(24,bpayAddress.isAccptAcctDbt()?1:0);
		  
	
		  if (bpayAddress.getMinAmtAccptdCdt()==null){
			  insertOrUpdateBpayAddressPrepStmnt.setNull(25, java.sql.Types.DECIMAL);
		  }else{
			  insertOrUpdateBpayAddressPrepStmnt.setDouble(25,Double.parseDouble(bpayAddress.getMinAmtAccptdCdt()));
		  }
		  
		  if (bpayAddress.getMaxAmtAccptdCdt()==null){
			  insertOrUpdateBpayAddressPrepStmnt.setNull(26,java.sql.Types.DECIMAL);
		  }else{
			  insertOrUpdateBpayAddressPrepStmnt.setDouble(26,Double.parseDouble(bpayAddress.getMaxAmtAccptdCdt()));
		  }
		  
		  if (bpayAddress.getSurchrgAmtCdt()==null){
			  insertOrUpdateBpayAddressPrepStmnt.setNull(27,java.sql.Types.DECIMAL);
		  }else{
			  insertOrUpdateBpayAddressPrepStmnt.setDouble(27,bpayAddress.getSurchrgAmtCdt()==null?null:Double.parseDouble(bpayAddress.getSurchrgAmtCdt()));
		  }
		  
		  if (bpayAddress.getSurchrgRateCdt()==null){
			  insertOrUpdateBpayAddressPrepStmnt.setNull(28,java.sql.Types.DECIMAL);
		  }else{
			  insertOrUpdateBpayAddressPrepStmnt.setDouble(28,Double.parseDouble(bpayAddress.getSurchrgRateCdt()));
		  }
		  
		  if (bpayAddress.getMinAmtAccptdDbt()==null){
			  insertOrUpdateBpayAddressPrepStmnt.setNull(29,java.sql.Types.DECIMAL);
		  }else{
			  insertOrUpdateBpayAddressPrepStmnt.setDouble(29,Double.parseDouble(bpayAddress.getMinAmtAccptdDbt()));
		  }
		  
		  if (bpayAddress.getMaxAmtAccptdDbt()==null){
			  insertOrUpdateBpayAddressPrepStmnt.setNull(30,java.sql.Types.DECIMAL);
		  }else{
			  insertOrUpdateBpayAddressPrepStmnt.setDouble(30,Double.parseDouble(bpayAddress.getMaxAmtAccptdDbt()));
		  }
		  
		  if (bpayAddress.getSurchrgAmtDbt()==null){
			  insertOrUpdateBpayAddressPrepStmnt.setNull(31,java.sql.Types.DECIMAL);
		  }else{
			  insertOrUpdateBpayAddressPrepStmnt.setDouble(31,Double.parseDouble(bpayAddress.getSurchrgAmtDbt()));
		  }
		  
		  if (bpayAddress.getSurchrgRateDbt()==null){
			  insertOrUpdateBpayAddressPrepStmnt.setNull(32,java.sql.Types.DECIMAL);
		  }else{
			  insertOrUpdateBpayAddressPrepStmnt.setDouble(32,Double.parseDouble(bpayAddress.getSurchrgRateDbt()));
		  }

		  if (isRecordAlreadyExists){
			  insertOrUpdateBpayAddressPrepStmnt.setString(33,bpayAddress.getAddressId());
		  }
																						  
				 		
		  insertOrUpdateBpayAddressPrepStmnt.executeUpdate();

		  if (logger.isDebugEnabled())
			  logger.debug("The following BpayAddress={} was successfully {} BPAY_ADDRESS table.",bpayAddress.getAddressId(),isRecordAlreadyExists?"UPDATED in":"INSERTED into");

		  
		  List<BPAYAddress.AllwblUse> allwblUseList = bpayAddress.getAllwblUsages();
		  if (!allwblUseList.isEmpty()){
			  String INSERT_INTO_BPAY_ADDRESS_ALLWBL_USE_QUERY_STRING = 
				  "INSERT INTO BPAY_ADDRESS_ALLWBL_USE "+
				  "(SCHME_ADR_ID, OFFICE, DEPARTMENT, ALLWBL_USE, TIME_STAMP, REC_STATUS, UPDATE_DATE) " +
				  "VALUES(?,?,?,?,?,?,TO_DATE(?,'mm/dd/yyyy hh:mi:ss am'))";
				 
			  insertBpayAddressAllwblUsePrepStmnt= con.prepareStatement(INSERT_INTO_BPAY_ADDRESS_ALLWBL_USE_QUERY_STRING);
			  
			  insertBpayAddressAllwblUsePrepStmnt.setString(1,bpayAddress.getAddressId());
			  insertBpayAddressAllwblUsePrepStmnt.setString(2,bpayAddress.getOffice());
			  insertBpayAddressAllwblUsePrepStmnt.setString(3,bpayAddress.getDepartment());
			
			  insertBpayAddressAllwblUsePrepStmnt.setString(5,GlobalDateTimeUtil.getSimpleDateFormatByFormat(GlobalDateTimeUtil.STATIC_DATA_TIME_STAMP).format(bpayAddress.getUpdateDate()));
			  insertBpayAddressAllwblUsePrepStmnt.setString(6,bpayAddress.getRecSts());
			  insertBpayAddressAllwblUsePrepStmnt.setString(7,GlobalDateTimeUtil.getSimpleDateFormatByFormat(GlobalDateTimeUtil.STATIC_DATA_DATE_TIME_AM_PM_12).format(bpayAddress.getUpdateDate()));
			  
			  int loopCount=0;
			  
			  for (AllwblUse use : allwblUseList){
				  insertBpayAddressAllwblUsePrepStmnt.setString(4,use.getUse());
				  insertBpayAddressAllwblUsePrepStmnt.addBatch();
				  loopCount++;
			  }
	
			  int count[] = insertBpayAddressAllwblUsePrepStmnt.executeBatch();
			  
			  if (logger.isDebugEnabled())
				  logger.debug("Successfully inserted {} new usages into BPAY_ADDRESS_ALLWBL_USE table.",loopCount);
	  }
		  
		  List<BPAYAddress.LkdAcct> linkedAccountsList = bpayAddress.getLinkedAccounts();
		  if (!linkedAccountsList.isEmpty()){
			  String INSERT_INTO_BPAY_ADDRESS_LINKED_ACCOUNTS_QUERY_STRING = 
				  "INSERT INTO BPAY_ADDRESS_LINKED_ACCOUNTS "+
				  "(SCHME_ADR_ID, OFFICE, DEPARTMENT, LKD_ACCT_ID,LKD_ACCT_TP, CST_ACCT_TP, ACCT_CCY, TIME_STAMP, REC_STATUS, UPDATE_DATE) " +
				  "VALUES(?,?,?,?,?,?,?,?,?,TO_DATE(?,'mm/dd/yyyy hh:mi:ss am'))";
				 
			  insertBpayAddressLkdAcctsPrepStmnt= con.prepareStatement(INSERT_INTO_BPAY_ADDRESS_LINKED_ACCOUNTS_QUERY_STRING);
			  
			  insertBpayAddressLkdAcctsPrepStmnt.setString(1,bpayAddress.getAddressId());
			  insertBpayAddressLkdAcctsPrepStmnt.setString(2,bpayAddress.getOffice());
			  insertBpayAddressLkdAcctsPrepStmnt.setString(3,bpayAddress.getDepartment());
			
			  insertBpayAddressLkdAcctsPrepStmnt.setString(8,GlobalDateTimeUtil.getSimpleDateFormatByFormat(GlobalDateTimeUtil.STATIC_DATA_TIME_STAMP).format(bpayAddress.getUpdateDate()));
			  insertBpayAddressLkdAcctsPrepStmnt.setString(9,bpayAddress.getRecSts());
			  insertBpayAddressLkdAcctsPrepStmnt.setString(10,GlobalDateTimeUtil.getSimpleDateFormatByFormat(GlobalDateTimeUtil.STATIC_DATA_DATE_TIME_AM_PM_12).format(bpayAddress.getUpdateDate()));
			  
			  int loopCount=0;
			  
			  for (BPAYAddress.LkdAcct acct : linkedAccountsList){
				  insertBpayAddressLkdAcctsPrepStmnt.setString(4,acct.getLkdAcctId());
				  insertBpayAddressLkdAcctsPrepStmnt.setString(5,acct.getCustAcctTp());
				  insertBpayAddressLkdAcctsPrepStmnt.setString(6,acct.getLkdAcctTp());
				  insertBpayAddressLkdAcctsPrepStmnt.setString(7,acct.getAcctCcy());
				  insertBpayAddressLkdAcctsPrepStmnt.addBatch();
				  loopCount++;
			  }
	
			  int count[] = insertBpayAddressLkdAcctsPrepStmnt.executeBatch();
			  
			  if (logger.isDebugEnabled())
				  logger.debug("Successfully inserted {} new usages into BPAY_ADDRESS_LINKED_ACCOUNTS table.",loopCount);
	  }

	  }catch(Exception e){
		  // An error has occurred while trying to perform this action
		  logger.error("Insert/Update process into BPAY_ADDRESS has failed.",e);
		  feedbackRetVal.setFailure(); 
		  feedbackRetVal.setException(e); 
	  }
	  finally{
		  releaseResources(null, insertOrUpdateBpayAddressPrepStmnt, con); 
	  }
	  return feedbackRetVal;
  }
  
  /**
   * Amend existing address status.
   * @param addressID
   * @param newStatus
   * @throws Exception
   */
  public Feedback amendStatus(String addressID,String newStatus) {
	  Feedback feedback = new Feedback();
	  
	  if (addressID == null || addressID.length() == 0) {
		  logger.debug("null or empty address",addressID);
		  feedback.setFailure();
		  return feedback;
	  }
	  
	  logger.debug("amending address {} status to {}",addressID,newStatus);
	  if (!isValidStatus(newStatus))
		  throw new IllegalArgumentException("unexpected status "+newStatus);
	  
	  Connection conn = null;
	  PreparedStatement statement = null;
	  
	  try {
		  conn = getConnection();
		  String AMEND_ADDRESS_STATEMENT = "update BPAY_ADDRESS t set t.ADR_STS=? where t.UID_BPAY_ADDRESS=?";
		  statement = conn.prepareStatement(AMEND_ADDRESS_STATEMENT);
		  
		  statement.setString(1,newStatus);
		  statement.setString(2,addressID);
		  
		  int rowsCount = statement.executeUpdate();
		  if (rowsCount == 0) {
			  logger.error("no ");
			  //update didn't took place
			  feedback.setFailure();
			  feedback.setErrorText("address "+addressID+" not exists");
		  }
	  }  catch(Exception e){
		  logger.error("Amend Status failed.",e);
		  feedback.setFailure(); 
		  feedback.setException(e); 
	  }
	  finally {
		  releaseResources(null, statement, conn); 
	  }
	  return feedback;
  }
  
  
  public static boolean isValidStatus(String status) {
	  return RSVD_ADDRESS_STATUS.equals(status) 
	  			|| ACTIVE_ADDRESS_STATUS.equals(status)
	  			|| INACTIVE_ADDRESS_STATUS.equals(status)
	  			|| CLOSED_ADDRESS_STATUS.equals(status);
  }
  
  
  
  

}