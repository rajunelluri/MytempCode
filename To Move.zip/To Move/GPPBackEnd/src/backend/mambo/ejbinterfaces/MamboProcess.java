 
package backend.mambo.ejbinterfaces;

import javax.ejb.Remote;

import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;

/**
 * Remote interface for AccountExplorer.
 */
@Remote
public interface MamboProcess{ 
	
	public static final String REMOTE_JNDI_NAME="ejb/MamboProcessBean";

	public Feedback executeChannelInFlow(Admin admin,String mid);
	public Feedback executeHubInFlow(Admin admin,String mid);
	
}//EOI 
