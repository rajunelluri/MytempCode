package backend.businessobject;

import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;
import javax.transaction.Status;
import javax.transaction.SystemException;
import javax.transaction.UserTransaction;

public class UserTransactionProxy implements UserTransaction
{
  UserTransaction m_utx;
  boolean m_bInitiatedTransactionBegin;
  
  /**
   * 
   */
  public UserTransactionProxy(UserTransaction utx)
  {
    m_utx = utx;
  }
  
  @Override
  public void begin() throws NotSupportedException, SystemException
  {
    if(getStatus() != Status.STATUS_ACTIVE )
    {
      m_utx.setTransactionTimeout(3600);
      m_utx.begin();
      m_bInitiatedTransactionBegin = true;
    }
  }

  @Override
  public void commit() throws RollbackException, HeuristicMixedException,
      HeuristicRollbackException, SecurityException, IllegalStateException, SystemException {
    if(m_bInitiatedTransactionBegin && this.getStatus() == Status.STATUS_ACTIVE) m_utx.commit();
    else if (this.getStatus() == Status.STATUS_MARKED_ROLLBACK) {
    	System.err.println("UserTransactionProxy - attempted to commit while transaction was marked as rollback only. Rolling back Tx");
    	m_utx.rollback();
    }
  }

  @Override
  public int getStatus() throws SystemException
  {
    return m_utx.getStatus();
  }

  @Override
  public void rollback() throws IllegalStateException, SecurityException, SystemException
  {
    if(m_bInitiatedTransactionBegin && 
    		(this.getStatus() == Status.STATUS_ACTIVE || this.getStatus() == Status.STATUS_MARKED_ROLLBACK)) m_utx.rollback();
    
  }

  @Override
  public void setRollbackOnly() throws IllegalStateException, SystemException
  {
    m_utx.setRollbackOnly();
  }

  @Override
  public void setTransactionTimeout(int seconds) throws SystemException
  {
    m_utx.setTransactionTimeout(seconds);
  }
}