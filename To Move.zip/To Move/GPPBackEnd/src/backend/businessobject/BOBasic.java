package backend.businessobject;

import java.lang.reflect.Method;
import java.util.Date;
import java.util.Properties;

import javax.transaction.TransactionManager;
import javax.transaction.UserTransaction;

import org.hibernate.cfg.Configuration;
import org.hibernate.transaction.TransactionManagerLookup;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.PermissionHandler;
import backend.businessobject.tx.OriginatorAwareTransaction;
import backend.businessobject.tx.SpringTransactionProxy;
import backend.dataaccess.dao.DAOPermission;
import backend.dataaccess.dto.DTODataHolder;
import backend.paymentprocess.erroraudit.ErrorAuditUtils;
import backend.staticdata.dataaccess.dao.DAOStaticData;
import backend.staticdata.dataaccess.dto.DTOModifiedField;
import backend.staticdata.module.layout.factory.StaticDataProfileFactory;
import backend.staticdata.profilehandler.BasicProfileHandler;
import backend.staticdata.profilehandler.ProfileConstants;
import backend.staticdata.profilehandler.ProfileHandlerFactory;
import backend.staticdata.profilehandler.general.APPLY_CHANGESProfileHandler;
import backend.util.ServerConstants;
import backend.util.ServerUtils;

import com.fundtech.cache.infrastructure.CacheException;
import com.fundtech.cache.infrastructure.CacheServiceInterface;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.general.flows.FlowException;
import com.fundtech.core.paymentprocess.errorhandling.ProcessError;
import com.fundtech.core.security.Admin;
import com.fundtech.core.security.Admin.CallSource;
import com.fundtech.datacomponent.request.FieldsContainer;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.datacomponent.response.MultipleFieldFeedback;
import com.fundtech.datacomponent.response.SimpleResponseDataComponent;
import com.fundtech.errors.ProcessErrorConstants;
import com.fundtech.util.ExceptionController;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalDateTimeUtil;


/*
 * Description: 
 * Company:		Fundtech Israel
 * Author:		Yaron Mizrahi
 * Date:		Apr 6, 2005
 */

/**
 * @author YaronM
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class BOBasic implements BOInterface 
{

	private final static Logger logger = LoggerFactory.getLogger(BOBasic.class);
   // protected static GlobalTracer GlobalTracer = GlobalTracer;
    private static final String GENERAL_ERROR_MESSAGE = "Exception has occured on business object.";
    private static ProcessError serviceFailurePError ; 
        
    protected static DAOPermission m_daoPermission = new DAOPermission() ;
    protected static DAOStaticData m_daoStaticData = new DAOStaticData() ;
    private static String HIBERNATE_SFG_LOCATION="META-INF/hibernate.cfg.xml";
    private static String TRANSACTION_MANAGER_LOOKUP_CLASS="hibernate.transaction.manager_lookup_class";
    private TransactionManager m_transactionManager;
    private Object m_transactionManagerLock;
    protected String m_sModuleID;
    
    public BOBasic() 
    {
        super();
        m_transactionManager=null;
        m_transactionManagerLock=new Object();
        initModuleID();
        GlobalConstants.setErrorAuditUtils(ErrorAuditUtils.getInstance());
        GlobalConstants.setPermissionHandler(PermissionHandler.getInstance());
    }
    
    /**
	 * Auditing the Profile status change in the profile audit trail
	 * @param sProfileID
	 * @param office
	 * @param arrModifiedFields
	 * @param messageIdentification
	 * @param department
	 * @param userName
	 * @return
	 */
	public static Feedback profileAudit(String sProfileID, String office, DTOModifiedField[] arrModifiedFields,String messageIdentification,String department,String userName, String sUniqueRecID){

		DTODataHolder dtoProfileData = new DTODataHolder();
		FieldsContainer fieldsContainer = new FieldsContainer();
		
		String sEffectiveDate = GlobalDateTimeUtil.getSimpleDateFormatByFormat(GlobalDateTimeUtil.STATIC_DATA_DATE).format(new Date());
		
		String sMasterTable = StaticDataProfileFactory.getInstance().getProfile(sProfileID).getMasterTable();
		fieldsContainer.addField(sMasterTable + ServerConstants.DOT + ServerConstants.COLUMN_OFFICE, office);
		fieldsContainer.addField(sMasterTable + ServerConstants.DOT + ServerConstants.COLUMN_DEPARTMENT, department);
		
		String sTimeStamp = GlobalDateTimeUtil.getSimpleDateFormatByFormat(GlobalDateTimeUtil.STATIC_DATA_TIME_STAMP).format(new Date());
		BasicProfileHandler profileHandler = ProfileHandlerFactory.getInstance().getHandler(sProfileID);
		Feedback feedback = profileHandler.customizedAudit(userName, sUniqueRecID, messageIdentification, sEffectiveDate, sTimeStamp, arrModifiedFields, dtoProfileData, fieldsContainer, sProfileID);
		
		/** Update static_data_refresh to prevent running Apply chnages one more time **/
		APPLY_CHANGESProfileHandler applyChangesHandler = (APPLY_CHANGESProfileHandler) ProfileHandlerFactory.getInstance().getHandler(ProfileConstants.PROFILE_ID_APPLY_CHANGES);
		applyChangesHandler.updateStaticDataRefreshTable(false, "P" + sProfileID);
		
		return feedback;
	}

    
    /** Biz object activation operations */
    public void businessObjectActivate()
    {
     // todo implement   
    }
    
    /** Biz object passivation operations */
    public void businessObjectPassivate()
    {
        // todo implement        
    }
    
    /** Biz object removal operations */
    public void businessObjectRemove()
    {
        // todo implement        
    } 
    
    /**
     * 
     */
    private void initModuleID()
    {
       m_sModuleID = ServerConstants.EMPTY_STRING;
    }
    
    /**
     * 
     */
    protected String getModuleID()
    {
      return m_sModuleID;
    }
    
    /**
     * protective transaction management, to be used by entry points such as JMS,Events
     */
    public static final Feedback startTransactionEnsureNew(UserTransaction[] arrTransactionHolder) {
    	UserTransaction utx = null;
        Feedback feedback = new Feedback();
    
        try
        {
          // Enabling nested transaction calls for better code reuse
          //utx = ThreadBoundCounterUTXWProxy.getStartedInstance();
          
          utx = SpringTransactionProxy.m_txWrapper.getEnsureNew() ;	
//          logger.debug("get SpringTransactionProxy was called from BOBasic.startTransaction");
          arrTransactionHolder[0] = utx;
          /*
          utx = (UserTransaction) ServiceLocator.getInstance().getContext().lookup("java:comp/UserTransaction");
          arrTransactionHolder[0] = new UserTransactionProxy(utx);
          arrTransactionHolder[0].begin();
          */
        }
        catch(Throwable e)
        {
           logger.error("",e);	
          feedback.setFailure();
          feedback.setException(e);
          feedback.setErrorText(e.toString());
        }
        
        return feedback;
    }
    
    /**
     * Starts transaction
     * @param arrTransactionHolder - return the user transaction object
     * @return feedback
     */
    public static final Feedback startTransaction(UserTransaction[] arrTransactionHolder) 
    {
        UserTransaction utx = null;
        Feedback feedback = new Feedback();
    
        try
        {
          // Enabling nested transaction calls for better code reuse
          //utx = ThreadBoundCounterUTXWProxy.getStartedInstance();
          
          utx = SpringTransactionProxy.m_txWrapper.get() ;	
          arrTransactionHolder[0] = utx;
          /*
          utx = (UserTransaction) ServiceLocator.getInstance().getContext().lookup("java:comp/UserTransaction");
          arrTransactionHolder[0] = new UserTransactionProxy(utx);
          arrTransactionHolder[0].begin();
          */
        }
        catch(Throwable e)
        {
           logger.error("",e);	
          feedback.setFailure();
          feedback.setException(e);
          feedback.setErrorText(e.toString());
        }
        
        return feedback; 
    }
    
    /**
     * End transaction
     * @param utx - user transaction
     * @param bCommit - indication whether to commit or rollback the transaction
     * @return feedback
     */
    public static final Feedback endTransaction(UserTransaction utxProxy, boolean bCommit, String sTxOriginator)
    {
        Feedback feedback = new Feedback();
        
        if(utxProxy == null){
        	feedback.setFailure();
        	feedback.setErrorText("No Transaction was found") ;
        	return feedback;
        }
 
        try
        {
         SpringTransactionProxy.m_txWrapper.remove(sTxOriginator, bCommit) ; 
        }
        catch(Throwable e)
        {
        	logger.error(e.getMessage()); 
            feedback.setFailure();
            feedback.setException(e);
        }//EO catch block 
        
        return feedback;
    }//EOM    
    
    /**
     * End transaction
     * @param utx - user transaction
     * @param bCommit - indication whether to commit or rollback the transaction
     * @return feedback
     */
    public static final Feedback endTransaction(UserTransaction utxProxy, boolean bCommit)
    {
        Feedback feedback = new Feedback();
        
        if(utxProxy == null){
        	feedback.setFailure();
        	feedback.setErrorText("No Transaction was found") ;
        	return feedback; 
        }
 
        try
        {
          
          /*if(bCommit)
          {
            utxProxy.commit();
          }
          else
          {
            utxProxy.rollback();
          }*/
        	
         SpringTransactionProxy.m_txWrapper.remove(null/*sOriginator*/, bCommit) ; 
          
          // Enabling nested transaction calls for better code reuse
         // ThreadBoundCounterUTXWProxy.closeTx( bCommit);
        	
        }
        catch(Throwable e)
        {
        	logger.error(e.getMessage()); 
            feedback.setFailure();
            feedback.setException(e);
        }//EO catch block 
        

        return feedback;
    }//EOM
    
    public static final boolean isSameTxOriginator(final UserTransaction utx, final String sOriginator) {
    	return( (utx instanceof OriginatorAwareTransaction) && ((OriginatorAwareTransaction)utx).isSameOriginator(sOriginator)) ; 
    }//EOM 
    
    public static final boolean isSameTxOriginator(final String sOriginator) { 
    	final SpringTransactionProxy txProxy = SpringTransactionProxy.m_txWrapper.getCurrent() ;
    	return (txProxy != null && txProxy.isSameOriginator(sOriginator)) ;
    }//EOM 
    
    public static final UserTransaction startTx() throws Throwable { return startTx(null/*sOriginator*/) ; }//EOM 
    
    /**
     * protective transaction management, to be used by entry points such as JMS,Events
     */
    public static final UserTransaction startTxEnsureNew() throws Throwable {     	
    	return SpringTransactionProxy.m_txWrapper.getEnsureNew() ;
    }//EOM
    
    public static final UserTransaction startTx(final String sOriginator) throws Throwable { 
    	return SpringTransactionProxy.m_txWrapper.get(sOriginator) ; 
    }//EOM 
    
    public static final void closeTx(final boolean bCommit) throws Throwable { closeTx(null/*sOriginator*/, bCommit) ; }//EOM 
    
    public static final void closeTx(final String sOriginator, final boolean bCommit) throws Throwable { 
    	SpringTransactionProxy.m_txWrapper.remove(sOriginator, bCommit) ; 
    }//EOM  
    
    /**
     * Handles BO exception when returned value is multiple field feedback  
     * @param e - Original BO exception
     * @param arrTransactionHolder - transaction holder array
     * @return multiple field feedback
     */
    protected MultipleFieldFeedback handleExceptionWithMultipleFieldFeedback
                                        (Exception e, UserTransaction[] arrTransactionHolder)
    {
        Feedback feedback = handleExceptionWithFeedback(e, arrTransactionHolder); 
        MultipleFieldFeedback multipleFeedback = new MultipleFieldFeedback();
        multipleFeedback.setFeedback(feedback);

        return multipleFeedback;
    }

    /**
     * Handles BO exception when returned value is feedback  
     * @param e - Original BO exception
     * @param arrTransactionHolder - transaction holder array
     * @return feedback
     */
    protected Feedback handleExceptionWithFeedback(Exception e, UserTransaction[] arrTransactionHolder)
	{
      // Transaction rollback.
      if(arrTransactionHolder[0] != null)
      {
        try
        {
          arrTransactionHolder[0].rollback();
        }
        catch(Exception eRollback)
        {
            ExceptionController.getInstance().handleException(eRollback, this);
        }
  	  }
  	
      ExceptionController.getInstance().handleException(e, this);
    	
      Feedback feedback = new Feedback();
      feedback.setFailure();
      feedback.setException(e);
      feedback.setErrorText(GENERAL_ERROR_MESSAGE);
      feedback.setUserErrorText(GENERAL_ERROR_MESSAGE);
      if(Admin.getContextAdmin().getCallSource() == CallSource.Service) feedback.setErrorCode(ProcessErrorConstants.GenericError) ; 
      
		
	  return feedback;
	}
    
    /**
     * Helper method for returning a failed operation 
     * @param sErrorMessage String to be written to the ServerTrace instance.
     * @param feedback Feedback instance containing the failure details 
     * @param bConfigureFeedback If true will set the feedback's failure flag and errorMessage. 
     *                           If flase, will leave the feedback as is 
     * @return SimpleResponseDataComponent containing the feedback
     * 
     *  @bo.skip
     */
    public final SimpleResponseDataComponent configureErrorResponse( String sErrorMessage, Feedback feedback, boolean bConfigureFeedback) { 
        SimpleResponseDataComponent response = new SimpleResponseDataComponent() ;
    	
        if(bConfigureFeedback) {
            if(feedback == null) feedback = response.getFeedback() ;
            
            feedback.setFailure() ; 
            feedback.setErrorText(sErrorMessage) ;
        }//EO if the feedback should be configured
        
        logger.error(sErrorMessage); 
        
        response.setFeedback(feedback) ;
        return response ; 
    }
    
    /**
     * configure ErrorFeedback
     */
    public static final Feedback configureErrorFeedback(ProcessError pe, Feedback feedback)
    {    	
      return handleError(pe.getErrorCode(), pe.getDescription(), null, feedback);
    }

    /**
     * configure ErrorFeedback
     */
    public static final Feedback configureErrorFeedback(int iErrorCode,String sMsgError, Feedback feedback)
    {    	
      return handleError(iErrorCode,sMsgError, null, feedback);
    }
    
    public static final Feedback handleError(Throwable e, Feedback feedback) { 
    	return handleError(null, null, e, feedback) ; 
    }//EOM 
    
    /**
     * configure ErrorFeedback
     */
    public static final Feedback handleError(final Integer iErrorCode, String sMsgError, Throwable e, Feedback feedback)
    {       
       
      
      feedback = feedback != null ? feedback : new Feedback();
      
      //if the mesage is null, retrieve the developer message from the exception and use the generic error for the user 
      if(sMsgError == null) { 
    	  getGenericFailureProcessError(feedback) ;
    	   
    	  if(e != null) { 
    		  e = (e.getCause() == null ? e : e.getCause()) ; 
    	  
    		  if(sMsgError == null) sMsgError = (e.getMessage() ==  null ? e.getClass().getName() : e.getMessage()) ;
    	  }//EO if there was an exception provided 
    	  
    	  //set the message in the developer message slot 
    	 feedback.setErrorText(sMsgError) ; 
      }else { 
	      feedback.setErrorCode(iErrorCode);
	      feedback.setErrorText(sMsgError);
	      feedback.setUserErrorText(sMsgError);
	      feedback.setFailure();
      }//EO else if a custom message was provided 
      
      if(e != null) { 
    	  feedback.setException(e);
    	  ExceptionController.getInstance().handleException(e, null) ; 
      }//EO if the exception was provided 
            
      logger.error(ServerUtils.getFeedbackString(feedback)); 
      
      
        
      return feedback ; 
    }//EOM 
    
    /**
     * configure ErrorGeneralFeedback
     */
    public static final Feedback configureGenericErrorFeedback(Feedback feedback)
    {       
         
      
        feedback.setErrorCode(1);
        feedback.setErrorText("Service failure");
        feedback.setUserErrorText("Service failure");
        feedback.setFailure();
        logger.error("Service failure") ; 
        
          
        
        return feedback ; 
    }
    
    /**
     * 
     */
    public static final ProcessError getGenericFailureProcessError(Feedback feedback)
    {
      final Object[] arrDummyNullNonPaymentFields = null;
      
      ProcessError pError = new ProcessError(28560, arrDummyNullNonPaymentFields);
      String sDescription = pError.getDescription();
      
      feedback.setErrorCode(28560);
      feedback.setErrorText(sDescription);
      feedback.setUserErrorText(sDescription);
      feedback.setFailure();
      
      return pError;
    }
    
    public TransactionManager getTransactionManager()
    {
        if (m_transactionManager==null)
        {
            synchronized(m_transactionManagerLock)
            {
                if (m_transactionManager==null)
                {
                    try
                    {
                        Configuration config=new Configuration().configure(HIBERNATE_SFG_LOCATION);
                        TransactionManagerLookup transactionManagerLookup=(TransactionManagerLookup)Class
                                            .forName(config.getProperty(TRANSACTION_MANAGER_LOOKUP_CLASS)).newInstance();
                        m_transactionManager=transactionManagerLookup.getTransactionManager(new Properties());
                    }
                    catch(Exception e)
                    {
                        // TODO Auto-generated catch block
                        ExceptionController.getInstance().handleException(e,this);
                    }
                }
            }
        }

        return m_transactionManager;
    }
    
    
  /**
   * Traces the method using the ServerTrace.logFileTrac()
   * @param sMessage Stirng to write to trace.
   * @param sSessionId user identification 
   */
  /*public static String infoTrace(String sMessage, Object...params) 
  {		
    String sTraceMsg = logger.info(sMessage, params) ; 
    logger.info(sTraceMsg);
    return sTraceMsg; 
  }//EOM*/
  
  /**
   * 
   */
  protected Feedback genericServiceExceptionHandling(Throwable e, String sServiceName, String sLastServiceStep)
  {
  	final String LAST_STEP = "Last step: {}.";
  	
  	
  	
  	Feedback feedback = new Feedback();
  	
  	logger.info(LAST_STEP, sLastServiceStep);
    ExceptionController.getInstance().handleException(e, this);
    
    ProcessError pError = new ProcessError(ProcessErrorConstants.ServiceFailureWithLastStep, new Object[]{sServiceName, sLastServiceStep+" ("+e+")"});
    configureErrorFeedback(pError.getErrorCode(),pError.getDescription(), feedback);
    ErrorAuditUtils.setErrors(pError);
    
    
    
    return feedback;
  }
  
  
  protected final Object executeInProtectedBoundaries(final Method method, final Object...formalArgs) throws FlowException{ 
	  
	  FlowException raisedException = null ; 
	  final long lBefore = System.nanoTime() ;
	  boolean bTopLevelInvocation = false ;
	  String sTxOriginator = null ; 
	  UserTransaction utx = null ; 
	  
	  Admin admin = Admin.getContextAdmin() ; 
	  final boolean bSharedResourcesMode = admin.supportsSharedResources() ; 
	  	  
	  try{ 
		  bTopLevelInvocation = (admin.getSessionData(Admin.CONTEXT_PROTECTIVE_BOUNDARIES_NESTEED_INVOCATION_IND) == null) ;
		  if(bTopLevelInvocation) admin.putSessionData(Admin.CONTEXT_PROTECTIVE_BOUNDARIES_NESTEED_INVOCATION_IND, bTopLevelInvocation) ;
		  
		  //only begin the transaction is first level invocation (currently counter is only used as an indication)
		  if(bTopLevelInvocation) {
			 // ThreadBoundCounterUTXWProxy.getStartedInstance();
			  //start a nested transaction using the method name + the before time as the originator contextx 
			  utx = startTx((sTxOriginator = method.getName() + "_" + lBefore)) ;
			  logger.debug("get SpringTransactionProxy was called from BOBasic");
			  admin.putSessionData("ORIGINATOR", sTxOriginator);
			  //start a shared connection if the admin supports such behaviour
			  if(bSharedResourcesMode )m_daoPermission.getConnection() ;
			  //initialize a shared jms resources session --> disabled for now as not working in fndtXfireJmsClientChannel (hannging while tx is opened) 
			 // JmsSessionContext.initSharedSession(TransmissionType.getInterfacesQueueConFactoryJndi()) ; 
			  
			  //first attempt to start a local cache Tx (session) (pass the cache region key to indicate that the tx should be opened on the local cache) 
		      CacheServiceInterface.eINSTANCE.beginTx(CacheKeys.SystParKey, false /*bOkToJoinActiveTx*/) ;
		      //then attempt to start a distributed cache Tx (session) (pass the cache region key to indicate that the tx should be opened on the distributed cache)
		     // CacheServiceInterface.eINSTANCE.beginTx(CacheKeys.dupexCheckKey, false /*bOkToJoinActiveTx*/) ;
		  }//EO if bTopLevelInvocation
	      
		  //ensure that this jvm is synchronized with the data of any external jvm invoker session
	      CacheKeys.ProcessSessionsKey.apply();

	      if(serviceFailurePError == null) serviceFailurePError = new ProcessError(ProcessErrorConstants.ServiceFailure, new Object[]{ this.getClass().getName()});
	      final long lBeforeExeuction = System.nanoTime() ;

	   	 //removed the isAccessible restoration to avoid locking 
	      //as in multi threaded environment there would a race condition between the invocation 
	      //and the setAccessible(false) 
	     // boolean isAccessible = method.isAccessible();
	      if (!method.isAccessible()) method.setAccessible(true);
	      Object o = method.invoke(this, formalArgs) ;
	      //if (!isAccessible) method.setAccessible(false);
	      
	      logger.debug("[BoBasic.executeInProtectedBoundaries()]: actual Execution time ----> {}" , ((float)(System.nanoTime()-lBeforeExeuction)/GlobalConstants.NANOS_TO_MS_DIVIDER));

		  return  o;
		  
	  }catch(FlowException fe) { 
		  raisedException =  fe ; 
	  }catch(Throwable t) { 
		  raisedException = this.onFlowFailure(t, raisedException, false/*bThrow*/,serviceFailurePError) ; 
	  }finally{ 
		  
		 //only dispose of the response if first level invocation 
		if(bTopLevelInvocation) { 
		  	 
			//TODO: if the tx should be rolledback for any reason, purhaps the pdo and the qexplorer should be compensated 
	    	try{ 
	    		CacheServiceInterface.eINSTANCE.closeTx(CacheKeys.SystParKey, (raisedException == null)/*bCommit*/, true /*forceClose*/) ;
	    		
	    		//FOR DEBUG
			   // if(true) throw new CacheException("local cache close") ;
			    //FOR DEBUG
	    		
	    	}catch(CacheException t) { 
	    		raisedException = this.onFlowFailure(t, raisedException, false/*bThrow*/,serviceFailurePError) ;
	    	}//EO catch block 
	    	
	    	/*
	    	 try{ 
	    		CacheServiceInterface.eINSTANCE.closeTx(CacheKeys.dupexCheckKey, (raisedException == null)bCommit, true forceClose) ;
	    		
	    	}catch(CacheException t) { 
	    		raisedException = this.onFlowFailure(t, raisedException, falsebThrow,serviceFailurePError) ;
	    	}//EO catch block 
	    	 */		    	
			try{
			   
				//if the context supports shared resources and this is a top level 
				//boundary, close the shared resources prior to closing the transaction 
				if(bTopLevelInvocation && bSharedResourcesMode) Admin.m_contextFlowResources.remove() ;  
				
			   final long lBeforeCommit = System.nanoTime() ;
		       
			   //ThreadBoundCounterUTXWProxy.closeTx((raisedException == null)) ;
			   closeTx(sTxOriginator, (raisedException == null)) ;
			
		       logger.debug("[BoBasic.executeInProtectedBoundaries()]: Commit time ----> {}" , ((float)(System.nanoTime()-lBeforeCommit)/GlobalConstants.NANOS_TO_MS_DIVIDER));
		        
		    }catch(Throwable t) { 
		       raisedException = this.onFlowFailure(t, raisedException, false/*bThrow*/,serviceFailurePError) ;
		    }//EO close Tx catch block
			  
		    //if there was an exception exeucte pdo compensation policy 
		    if(raisedException != null) { 
		    	try{ 
		    		
		    		BOProxies.m_businessFlowSelectorLogging.performFailurePaymentCompensation(admin);
		    		   
		    	}catch(Throwable t){ 
			    	   raisedException = this.onFlowFailure(t, raisedException, false/*bThrow*/,serviceFailurePError) ;
		    	}//EO catch block 
		    }//EO if there was an exception
		    
		    //remove the top level invocation flag 
		    admin.getSessionData(Admin.CONTEXT_PROTECTIVE_BOUNDARIES_NESTEED_INVOCATION_IND, true) ;
		}//EO if top level invocation
		else if ((raisedException != null)&&(admin.getSessionData(Admin.FORBID_SUB_INVOCATION_ROLLBACK) == null)) { 
			try{ 
				//mark the exception for rollback only 
				//ThreadBoundCounterUTXWProxy.getStartedInstance(true/*do not increment the active users*/).setRollbackOnly() ;
				if(utx != null) utx.setRollbackOnly() ; 
			}catch(Throwable t){ 
		    	   raisedException = this.onFlowFailure(t, raisedException, false/*bThrow*/,serviceFailurePError) ;
	    	}//EO catch block 
		}//EO if nested invocation with a raised exception 
		
		final Boolean boolSameJVM = (Boolean)Admin.getContextAdmin().getSessionData(CacheKeys.ProcessSessionsKey.KEY_SAME_PROCSS_SESSION_PROPAGATOR_JVM);
	    // Sends the 1st parameter, (= bRemovePDOFromLocalCache), as true as the business flow selector might be called using a bean class, 
	    // (i.e. a different JVM). In case we're in the same JVM, (i.e. boolSameJVM = true), the 'true' value won't affect the 'propagate' method; see there.
	    CacheKeys.ProcessSessionsKey.propagate(true/*bRemovePDOFromLocalCache*/, boolSameJVM);
	    
	    
	       
	    logger.debug("[BoBasic.executeInProtectedBoundaries()] AFTER ----> {}" , ((float)(System.nanoTime()-lBefore)/GlobalConstants.NANOS_TO_MS_DIVIDER));
	    
	    //if the bRaiseError flag is set to true, throw a new flow exception to the invoker 
	    //to indicate that the tx had failed
	    if(raisedException != null){
	    	Admin.setRollbackExceptionHolder(raisedException);
			Admin.setRollbackPDOHolder(Admin.getContextPDO());
	    	throw raisedException ; 
	    } 
	  }//EO catch block
	  
	  return new Feedback() ;
  }//EOM   
  
  protected final FlowException onFlowFailure(Throwable t, FlowException flowException, final boolean bThrow, ProcessError pError) throws FlowException{ 
	  ExceptionController.getInstance().handleException(t, this);
      
	  //write the error to error log 
	  int errorCode = ProcessErrorConstants.GenericError; 
      if (pError != null)
      {
    	  errorCode = pError.getErrorCode();
    	  ErrorAuditUtils.setErrors(pError);
      }
      
      if(flowException != null) flowException.addError(t) ; 
      else { 
    	  t = ExceptionController.getActualException(t) ; 
    	  if(t instanceof FlowException && flowException == null) flowException = (FlowException) t;
    	  else flowException = new FlowException(errorCode, t, Admin.getContextAdmin().getFlowID()) ;
      }//EO else if the flow exception formal arg was not provided 
      if(bThrow) throw flowException ; 
      else return flowException ; 
  }//EOM

}
