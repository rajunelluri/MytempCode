package backend.businessobject.tx;

import javax.transaction.HeuristicMixedException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.cache.entities.G3Response;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.general.tx.LastResourceInterface;

public class RemoveFromResponseFromHostCacheLastResourceHandler implements LastResourceInterface {

	private static final Logger logger = LoggerFactory.getLogger(RemoveFromResponseFromHostCacheLastResourceHandler.class);
	private String instrId;
	private String mid;
	
	
	public RemoveFromResponseFromHostCacheLastResourceHandler(G3Response g3Response){
		this.instrId = g3Response.getInstrId();
		this.mid = g3Response.getMid();
	}
	
	
	@Override
	public void commitLastResource() throws HeuristicMixedException {
		// Do nothing
		
	}

	@Override
	public void compensate() throws HeuristicMixedException {
		// Do nothing
		
	}

	/**
	 * Remove posting request from cache after transaction in committed
	 */
	@Override
	public void afterCommit() throws HeuristicMixedException {
		logger.info("afterCommit: Removing the cache from responseFromHostKey for InstrId {}, sMid {}", instrId, mid);
		G3Response resp = new G3Response();
		resp.setInstrId(instrId);
		resp.setMid(mid);
		CacheKeys.responseFromHostKey.removeSingle(resp);
		
	}

	@Override
	public String getID() {
		return RemoveFromResponseFromHostCacheLastResourceHandler.class.getName();
	}
}
