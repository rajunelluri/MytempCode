package backend.businessobject.tx;

import java.util.List;

import javax.transaction.HeuristicMixedException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.core.module.MessageConstantsInterface;
import backend.services.events.handlers.PaymentDistributerEventHandler;

import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.general.tx.LastResourceInterface;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.security.Admin;
import com.fundtech.scl.commonTypes.MFamilyLineType;

public class SplitCounterDecrement implements LastResourceInterface  {
	
	private String parentMID,childMID;
	private static final Logger logger = LoggerFactory.getLogger(SplitCounterDecrement.class);
	private boolean forceWakeParent;

	public SplitCounterDecrement(String nparentMID,String nchildMID,boolean bforceWakeParent) {
		this.parentMID = nparentMID;
		this.childMID = nchildMID;
		this.forceWakeParent = bforceWakeParent;
		}

	@Override
	public void commitLastResource() throws HeuristicMixedException {
		
	
	}

	@Override
	public void compensate() throws HeuristicMixedException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void afterCommit() throws HeuristicMixedException {
		
		int LeftChildrenNotInFinalStatus =  9999;
		if(!forceWakeParent){
			LeftChildrenNotInFinalStatus  = CacheKeys.SplitChildrenCounterKey.decrement(parentMID);			
		}
		else if (forceWakeParent &&childMID.isEmpty() )
		{
			logger.debug("forceWakeParent scenario childMID is null,fetching childMID from RF"); 
			PDO pdo = Admin.getContextPDO();
			childMID = pdo.getMID();
    		logger.debug("forceWakeParent scenario childMID={}",childMID); 
		}
		logger.debug("forceWakeParent ["+ forceWakeParent + "] decrementing the counter cache for split payments to :" +LeftChildrenNotInFinalStatus + "due to arrival of last payment MID "+ childMID + " the event will wake the parent upon successful commit ");
		
		logger.info("set for acked/nacked MID={} an EVENT_WAKE_PARENT_SPLIT to check if all children of split payment are in final statuses",new Object[]{ parentMID});
		if (LeftChildrenNotInFinalStatus == 0 || forceWakeParent){
			try {
				PaymentDistributerEventHandler.addOneTimeEvent(MessageConstantsInterface.EVENT_WAKE_PARENT_SPLIT, childMID, null);
			} catch (Throwable e) {
				logger.info("failed in adding the WAKE_PARENT event for MID "+parentMID);
				e.printStackTrace();
			}
		}
		else{
			logger.debug("don't yet get back to parent as not all the children were processed and parent was not forced to continue");
		}
	}

	@Override
	public String getID() {
		// TODO Auto-generated method stub
		return null;
	}
/*	*//**
	 * opening a new transaction to add the event since the original child payment that was the last child payment of a parent split payment which reached a final status decremented the counter cache to 0 after its transaction commit
	 * therefore the event adding from db will be done by a new transaction.  
	 * @throws Throwable 
	 * 
	 *//*
	void addEventWakeCall() throws Throwable{
		final UserTransaction[] arrUserTransaction = new UserTransaction[1];

		Feedback feedback = BOBasic.startTransaction(arrUserTransaction);
		if (!feedback.isSuccessful())
			throw new TransactionException(feedback.toString());

		boolean bShouldCommitTx = true;
		try {
			/////////////////////////////////////the LOGIC to perform//////////////////////////////////////////////////////////
			PaymentDistributerEventHandler.addOneTimeEvent(MessageConstantsInterface.EVENT_WAKE_PARENT_SPLIT, childMID, null);
		} catch (Throwable e) {
			ExceptionController.getInstance().handleException(e, this);

			// set the bShouldCommitTx to false so that the transaction would be rolled back
			bShouldCommitTx = false;
			// must be thrown so as to provide the client code with the option to rollback
			throw e;
		} finally {

			// commit transaction
			feedback = BOBasic.endTransaction(arrUserTransaction[0], bShouldCommitTx);
			// if the tx had failed, throw an exception
			if (!feedback.isSuccessful())
				throw new TransactionException(feedback.toString());

		}// EO catch block
	}
	
*/
}

