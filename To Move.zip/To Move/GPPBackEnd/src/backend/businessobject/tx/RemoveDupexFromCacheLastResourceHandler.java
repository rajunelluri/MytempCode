/**
 * 
 */
package backend.businessobject.tx;


import java.util.List;

import javax.transaction.HeuristicMixedException;

import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.general.tx.LastResourceInterface;

/**
 * @author eranm
 *
 */
public class RemoveDupexFromCacheLastResourceHandler implements LastResourceInterface {

	private List<String> dupekKeys;
	
	public RemoveDupexFromCacheLastResourceHandler(List<String> dupexKeys) {
		
		dupekKeys = dupexKeys;
		
	}
	/* (non-Javadoc)
	 * @see com.fundtech.core.general.tx.LastResourceInterface#afterCommit()
	 */
	@Override
	public void afterCommit() throws HeuristicMixedException {
		 
		if (dupekKeys != null && !dupekKeys.isEmpty()) {
			for (String dupexKey : dupekKeys) {
				//FOR DEBUG
				//sysout(GlobalTracer.info("RemoveDupex using LastResourceManager , key : " + dupexKey));
				CacheKeys.dupexCheckKey.removeSingle(dupexKey);
			}
		}
	}

	/* (non-Javadoc)
	 * @see com.fundtech.core.general.tx.LastResourceInterface#commitLastResource()
	 */
	@Override
	public void commitLastResource() throws HeuristicMixedException {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see com.fundtech.core.general.tx.LastResourceInterface#compensate()
	 */
	@Override
	public void compensate() throws HeuristicMixedException {
		// TODO Auto-generated method stub
		if (dupekKeys != null && !dupekKeys.isEmpty()) {
			for (String dupexKey : dupekKeys) {
				//FOR DEBUG
				//sysout(GlobalTracer.info("RemoveDupex using LastResourceManager , key : " + dupexKey));
				CacheKeys.dupexCheckKey.removeSingle(dupexKey);
			}
		}

	}

	/* (non-Javadoc)
	 * @see com.fundtech.core.general.tx.LastResourceInterface#getID()
	 */
	@Override
	public String getID() {
		// TODO Auto-generated method stub
		return RemoveDupexFromCacheLastResourceHandler.class.getName();
	}

}
