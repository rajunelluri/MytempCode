package backend.businessobject.tx;

import static com.fundtech.util.Monitors.TX;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.transaction.HeuristicMixedException;
import javax.transaction.NotSupportedException;
import javax.transaction.Status;
import javax.transaction.SystemException;
import javax.transaction.UserTransaction;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.jta.JtaTransactionManager;
import org.springframework.transaction.jta.JtaTransactionObject;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.springframework.transaction.support.DefaultTransactionStatus;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import com.fundtech.core.security.Admin;
import com.fundtech.jndi.ServiceLocator;
import com.fundtech.spring.FndtSpringBeansFactory;
import com.fundtech.util.ExceptionController;
import com.fundtech.util.Monitors;

public class SpringTransactionProxy extends LastResourcesManager implements UserTransaction, TransactionSynchronization, OriginatorAwareTransaction{
	private final static Logger logger = LoggerFactory.getLogger(SpringTransactionProxy.class);
	
	
	private TransactionStatus m_txStatus ;
	private String m_sOriginator ; 
	private boolean m_bDefferedLastResourceRegistration ;
	
	private final DefaultTransactionDefinition m_txMetadata ; 
	private static volatile PlatformTransactionManager m_txManager ;
	
	private static final String LOCKED_BY = "LOCKED_BY_" ; 
	
	private Date allocationTStamp;
	private Exception allocationStack;
	
	public static final void endTransaction(SpringTransactionProxy txProxy,boolean bCommit,boolean removeFromThreadLocal) throws Throwable {
		try {
			long startTime = System.currentTimeMillis();
			
			if(bCommit) 
				m_txManager.commit(txProxy.m_txStatus) ; 
			else
				m_txManager.rollback(txProxy.m_txStatus) ;
			
			
			Monitors.TX.txEnd(bCommit,(System.currentTimeMillis()-startTime),txProxy.m_sOriginator);			
		} catch (Throwable t) {
			removeFromThreadLocal = true;
			logger.debug("Exception occured while Commit or rollback transaction, error message:{}\n\nstacktrace:\n{}", t.getMessage(), ExceptionUtils.getStackTrace(t));
			throw t;
		} finally{
		//	logger.debug("End Transaction");
			if(removeFromThreadLocal) {
				logger.trace("clearing SpringTransactionProxyWrapper ThreadLocal");
				m_txWrapper.remove() ; 
			}
		}//EO catch block					
	}//EOM 
	
	public static final class SpringTransactionProxyWrapper extends ThreadLocal<SpringTransactionProxy> { 
		@Override
		public final SpringTransactionProxy get() { return this.get(null/*sOriginator*/) ; }//EOM 
		
		public final SpringTransactionProxy getCurrent() { return super.get() ; }//EOM 
		
		public final SpringTransactionProxy get(final String sOriginator) { return this.get(sOriginator, null/*txMetadata*/) ; }//EOM
		
		public final SpringTransactionProxy getEnsureNew() { 
			return this.getEnsureNew(null/*sOriginator*/) ;			
		}//EOM
		
		/**
		 * 1. this class is using 'required' as default transaction attribute, hence 'start-tx' would join existing transaction
		 * 2. when joining, the transaction is not 'new'
		 * 4. Thru PlatformTransactionManager it's impossible to close not 'new' transaction 
		 * 5. If a none 'new' transaction would stuck on the thread, it would not be possible to close it  
		 * 6. on entry points (MQ,Events) a new transaction is expected to be used
		 * 7. this protective method support 'new' transaction by closing (rollback) existing(unexpected) one, it's not supporting nesting transaction	 
		 * 8. this is not like 'requires new'. ('requires new' needs thread local stack) 
		 */
		public final SpringTransactionProxy getEnsureNew(final String sOriginator) {
			protectiveCleanup(); //for the benefit of 'isNewTransaction' force access to PlatformTransactionManager by first remove the current transaction if exists			
			SpringTransactionProxy txProxy = this.get(sOriginator) ;
			if (txProxy != null && txProxy.m_txStatus != null && !txProxy.m_txStatus.isNewTransaction()) {					
				logger.warn("while serving getEnsureNew call,found unexpected transaction on thread," +
						" rollback this transaction and re-attempt to create new one." +
						"Unexpected transaction allocation time:{}, allocation stack: "
						,new Object[]{txProxy.allocationTStamp == null ? "" : new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS").format(txProxy.allocationTStamp)}
						,txProxy.allocationStack);
				
				TX.info("while serving getEnsureNew call,found unexpected transaction on thread," +
								" rollback this transaction and re-attempt to create new one." +
								"Unexpected transaction allocation time:{}, allocation stack: "
								,new Object[]{txProxy.allocationTStamp == null ? "" : new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS").format(txProxy.allocationTStamp)}
								,txProxy.allocationStack);
				
				
				try {
					//direct JTA rollback
					UserTransaction ut = ((JtaTransactionManager)m_txManager).getUserTransaction();					
					if (ut != null) { //paranoid
						ut.rollback();
						logger.info("old transaction status {}",ut.getStatus());
					}					
				} catch (Throwable e) {
					logger.warn("fail to rollback old transaction",e);
				} finally {
					//internal cleanups
					protectiveCleanup();
				}
				txProxy = get(sOriginator);				
			}
			return txProxy;
		}//EOM
		
		
		public final SpringTransactionProxy get(final String sOriginator, final DefaultTransactionDefinition txMetadata) {  
			SpringTransactionProxy txProxy = super.get() ;
			if (sOriginator != null && sOriginator.contains("executeBusinessFlowInner")){
				logger.debug("TX PROXY is null: " + (txProxy == null));
				logger.debug("Admin is null: " + (Admin.getContextAdmin() == null));
			}
			
			try {
				if (txProxy != null && txProxy.getStatus() != Status.STATUS_ACTIVE) {					
					logger.info("----------------------> [SpringTransactionProxy.get] --> txProxy != null with status:  " + (txProxy.getStatus()),new Exception());
					TX.info("----------------------> [SpringTransactionProxy.get] --> txProxy != null with status:  " + (txProxy.getStatus()),new Exception());
					//transaction can be rollback (for example, timeout), do not assume it as illegal state
					if (!(txProxy.m_txStatus.isNewTransaction()
							&& (txProxy.getStatus() == Status.STATUS_MARKED_ROLLBACK 
								|| txProxy.getStatus() == Status.STATUS_ROLLEDBACK
								|| txProxy.getStatus() == Status.STATUS_ROLLING_BACK))) {
						logger.info("----------------------> [SpringTransactionProxy.get], abort existing transation and create new transatcion");
						TX.info("----------------------> [SpringTransactionProxy.get], abort existing transation and create new transatcion");
						txProxy = null;
					}
				} 
			} catch(Throwable t) {
				logger.error("",t);
			}
			
			try{ 
				if(txProxy == null) { 
					txProxy = new SpringTransactionProxy(sOriginator, txMetadata) ; 
					this.set(txProxy) ; 
				}//EO if not yet created
				else {
					logger.debug("TX PROXY m_bDefferedLastResourceRegistration: " + txProxy.m_bDefferedLastResourceRegistration);
					if(txProxy.m_bDefferedLastResourceRegistration) {
						txProxy.registerAsLastResourceHandler() ; 
					}//EO if not yet registerd with the admin as last resource handler
				} 
			}catch(Throwable t) { 
				logger.error(t.getMessage());
				ExceptionController.throwRuntimeException(t) ; 
			}//EO catch block 
			
			return txProxy ; 
		}//EOM
		
		public final void remove(final String sOriginator, final boolean bCommit) throws Throwable{
			final SpringTransactionProxy txProxy = super.get() ;
			boolean bRemoveFromThreadLocal = false ; 
			try{ 				
				if(txProxy == null) {  
					logger.error("[SpringTransactionProxy.remove()]: No Active Transaction is associated with this Thread") ; 
				}//EO if there was no active transaction 
				else bRemoveFromThreadLocal = txProxy.closeTx(sOriginator,  bCommit) ;
			}catch(Throwable t) { 
				if(txProxy != null) txProxy.ensureState() ; 
				bRemoveFromThreadLocal = true ; 
				throw t ; 
			}finally{
//				System.out.println("----------------------> [SpringTransactionProxy.remove] --> bRemoveFromThreadLocal :  " + (bRemoveFromThreadLocal));
				
				if(bRemoveFromThreadLocal) {
					logger.trace("clearing SpringTransactionProxyWrapper ThreadLocal");
					super.remove() ; 
				}
			}//EO catch block 
			
		}//EOM 
		
		
		
		@Override
		public final void remove() {
			
			//first retrieve the value and determine whether the tx was closed properly 
			final SpringTransactionProxy txProxy = super.get() ;
			if(txProxy == null) return ;
			//else 
			super.remove() ;
			
			logger.trace("clearing SpringTransactionProxyWrapper ThreadLocal");
			
			try{ 
				//invoke the ensure state so as to ensure that the tx would be rolledback if not yet closed 
				txProxy.ensureState();
			}catch(Throwable t) { 
				ExceptionController.throwRuntimeException(t) ; 
			}//EO catch block 
			
		}//EOM 
		
		private void protectiveCleanup() {
		//	logger.debug("protective cleanup");
			super.remove();
			try {
				TransactionSynchronizationManager.clearSynchronization();
			} catch (Exception ignore) {//IllegalState				
			}
			
		}
	}//EO class SpringTransactionProxyWrapper
	
	public static final SpringTransactionProxyWrapper m_txWrapper = new SpringTransactionProxyWrapper() ; 
	
	private SpringTransactionProxy() throws Throwable{ 
		this(null/*sOriginator*/, null/*txMetadata*/) ;
	}//EOM 
	
	private SpringTransactionProxy(final DefaultTransactionDefinition txMetadata) throws Throwable{ this(null/*sOriginator*/, txMetadata); }//EOM
	
	private SpringTransactionProxy(final String sOriginator, final DefaultTransactionDefinition txMetadata) throws Throwable{
		this.m_txMetadata =
			( txMetadata != null ? 
					txMetadata :  
			  		ServiceLocator.getInstance().getNsetSpringBean(DefaultTransactionDefinition.class.getName(), DefaultTransactionDefinition.class) 
			  	) ;
		
		this.m_sOriginator = sOriginator ; 
		
		this.allocationStack = new Exception();
		this.allocationTStamp = new Date();
		
		this.begin();
		
		logger.trace("starting new UserTransaction");
	}//EOM 
		
	private UserTransaction getUserTransaction() {
		return ((JtaTransactionObject)((DefaultTransactionStatus)this.m_txStatus).getTransaction()).getUserTransaction();
	}

	@Override
	public void begin() throws NotSupportedException, SystemException {
		//first ensure that the tx manager was initialized 
		try{ 
			if(m_txManager == null) m_txManager = (PlatformTransactionManager)
				ServiceLocator.getInstance().getSpringApplicationContext(FndtSpringBeansFactory.DEFAULT_APP_CONTEXT).getBean("transactionManager") ;
		}catch(Throwable t) { 
			ExceptionController.trace(t, this) ; 
			throw new NotSupportedException("[SpringTransactionProxy.begin()]: Failed to Initialize Transaction Manager") ; 
		}//EO catch block 
		
		//now start/join the transaction 
		this.m_txStatus = m_txManager.getTransaction(this.m_txMetadata) ; 
		
		//register this instance as the last resource manager with the Admin. 
		//Note: existing of a previously registerd manager is permitted so as to support MDP scenarios  
		this.registerAsLastResourceHandler(); 		
	}//EOM 
	
	private final void registerAsLastResourceHandler() { 
		final Admin admin = Admin.getContextAdmin() ; 
		if(admin != null) {
			admin.registerLastResourcesHandler(this, false/*bFailIfHandlerAlreadyExists*/)  ;
			this.m_bDefferedLastResourceRegistration = false ; 
			//register this resource handler with the spring  transaction synchronization 
			TransactionSynchronizationManager.registerSynchronization(this) ;
		} else {
			this.m_bDefferedLastResourceRegistration = true ;
		}
	}//EOM
	
	@Override
	public final int getStatus() throws SystemException {
		return getUserTransaction().getStatus() ; 
	}//EOM 
		
	@Override
	public void rollback() throws IllegalStateException, SecurityException, SystemException {
		this.rollback(null/*sOriginator*/) ; 		
	}//EOM 
	
	/**
	 * 
	 * Apr 10, 2011
	 * guys
	 *
	 * @param sOriginator Context Id of the originator of the instance creation (nullable) 
	 * Note: if the instance was created with an originator context and the originator formal arg 
	 *  is not the same as the creation one, invoke the setRollbackOnly instead 
	 * @return true is same originator and false if otherwise 
	 * @throws IllegalStateException
	 * @throws SecurityException
	 * @throws SystemException
	 */
	@Override
	public final boolean rollback(final String sOriginator) throws IllegalStateException, SecurityException, SystemException {
		logger.trace("rollbacking UserTransaction");
		if(this.m_sOriginator == null || (this.m_sOriginator.equals(sOriginator)) ){
			long startTime = System.currentTimeMillis();
			m_txManager.rollback(this.m_txStatus) ; 	
			
			Monitors.TX.txEnd(false,(System.currentTimeMillis()-startTime),sOriginator);
			return true ; 
		}else  { 
			this.setRollbackOnly() ;
			return false ; 
		}//EO if not the same originator 
	}//EOM 
		
	@Override
	public void commit() throws HeuristicMixedException {
		this.commit(null/*sOriginator*/) ; 
	}//EOM
	
	/**
	 * @return true is same originator and false if otherwise 
	 */
	@Override
	public final boolean commit(final String sOriginator) throws HeuristicMixedException { 
		if(this.m_sOriginator == null || (this.m_sOriginator.equals(sOriginator)) ){
			long startTime = System.currentTimeMillis();
			logger.trace("commiting UserTransaction");
			m_txManager.commit(this.m_txStatus) ;
			
			Monitors.TX.txEnd(true,(System.currentTimeMillis()-startTime),sOriginator);
			
			return true ; 
		}//EO if the originator was the same as the creation's one
		else {
			logger.debug("ignoring commit {}",sOriginator);
			return false  ;
		}
	}//EOM 
	
	@Override
	public void setRollbackOnly() throws IllegalStateException, SystemException {
		this.m_txStatus.setRollbackOnly() ; 
	}//EOM 
	
	@Override
	public void setTransactionTimeout(final int iTimeout) throws SystemException {
		this.m_txMetadata.setTimeout(iTimeout) ; 
	}//EOM 
	
	public final boolean closeTx(final String sOriginator, final boolean bCommit) throws Throwable {
		//System.out.println("close Tx with commit = " + bCommit + " by thread " + Thread.currentThread().getName());
		if(bCommit) return this.commit(sOriginator) ; 
		else return this.rollback(sOriginator) ; 
	}//EOM 
	
	@Override
	public final boolean isSameOriginator(final String sOriginator) { 
		return (this.m_sOriginator == null && sOriginator == null ||
			this.m_sOriginator != null && this.m_sOriginator.equals(sOriginator)) ; 
	}//EOM 
	
	/**
	 * Ensures that an originator exists, and of not, assigns an implicit interim one to be removed 
	 * using the unlock tx (has no effect if a tx orignator is already defined) 
	 * 
	 * To be used symmetirically with the unlockTransaction()
	 */
	public final void lockTransaction(final String sLockerId) {
		if(this.m_sOriginator == null) this.m_sOriginator = LOCKED_BY + sLockerId ; 
		else logger.info("[SpringTransactionProxy.lockTransaction()]: Attempt was made to lock a tx with an explicit originator '"+this.m_sOriginator+"' with a locker id '" + sLockerId + "' - Ignoring request." ) ; 
	}//EOM
	
	public final void unlockTransaction() {
		//if the m_sOriginator begins with the LOCKED_BY prefix, nullify the former 
		if(this.m_sOriginator != null && this.m_sOriginator.startsWith(LOCKED_BY)) this.m_sOriginator = null ;
	}//EOM 
	
	public final TransactionStatus getTxStatus() { return this.m_txStatus ; }//EOM
	
	@Override
	public final void beforeCommit(boolean readOnly) { 
		try{ 
			//invoke the super classe's commit last resource which would iterate over all registed 
			//last resources and invoke their commitLastResource() in turn. 
			this.commitLastResource() ;
		}catch(Throwable t) { 
			ExceptionController.throwRuntimeException(t) ; 
		}//EOM 
	}//EOM 
	
	@Override
	public final void afterCompletion(int status) { 
		//for tx commit failure scenarios 
		if(status == TransactionSynchronization.STATUS_ROLLED_BACK) { 
			try{ 
				this.compensate() ;
			}catch(Throwable t) { 
				ExceptionController.throwRuntimeException(t) ; 
			}//EOM  				
		}//EO status was rolledback 
	}//EOM 
	
	@Override
	public final void beforeCompletion() { /*do Nothing*/ }//EOM 
	
	@Override
	public final void afterCommit() {
		try {
			super.afterCommit();
		} catch (Throwable t) {
			ExceptionController.throwRuntimeException(t) ; 
		}
	}//EOM 
	
	@Override
	public final void resume() { /*do Nothing*/  }//EOM
	
	@Override
	public final void suspend() { /*do Nothing*/ }//EOM 
	
	@Override
	public SpringTransactionProxy reset() { super.reset() ; return this ; }//EOM 
	
	public final void ensureState() throws Throwable{ 
		//if this instance had infact opened a transaction (as opposing to participating in a nested tx) 
		//rollback the tx and log 
		final UserTransaction utx = ((JtaTransactionObject)((DefaultTransactionStatus)this.m_txStatus).getTransaction()).getUserTransaction() ; 
		//System.out.println("TX STATUS --> " + utx.getStatus()) ;
		if(this.m_txStatus.isNewTransaction() && !this.m_txStatus.isCompleted()) { 
			String message = "[SpringTransactionProxy.finalize()]: Tx with originator '"+this.m_sOriginator+"' was left opened! Rolling back!!";
			logger.error(message) ;
			
			
			this.rollback(this.m_sOriginator) ;  
			  
			throw new IllegalStateException(message) ; 
		}//EO if the transaction was opened in the scope of this instance  
	}//EOM 
	
//	@Override
//	protected final void finalize() throws Throwable {
//		this.ensureState() ; 
//	}//EOm 
	
	@Override
	public final String toString() { return super.toString() + " --> [SpringTransactionProxy]: Originator["+this.m_sOriginator+"], TxOpener["+this.m_txStatus.isNewTransaction()+"]" ; }//EOM  

	@Override
	public void flush() {
		// TODO Auto-generated method stub
		
	}
}//EOC 
