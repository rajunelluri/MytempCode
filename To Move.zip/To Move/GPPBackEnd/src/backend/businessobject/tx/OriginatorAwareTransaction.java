package backend.businessobject.tx;

import javax.transaction.HeuristicMixedException;
import javax.transaction.SystemException;

public interface OriginatorAwareTransaction {

	boolean commit(final String sOriginator) throws HeuristicMixedException ; 
	boolean rollback(final String sOriginator) throws IllegalStateException, SecurityException, SystemException ; 
	boolean isSameOriginator(final String sOriginator) ; 
	 
}//EOI 
