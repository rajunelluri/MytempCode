package backend.businessobject.tx;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import javax.transaction.HeuristicMixedException;

import com.fundtech.core.general.tx.LastResourceInterface;
import com.fundtech.core.general.tx.LastResourcesHandlerInterface;
import com.fundtech.errors.RuntimeAggregatedException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LastResourcesManager<K extends LastResourceInterface> implements LastResourcesHandlerInterface<K>, LastResourceInterface{
	private final static Logger logger = LoggerFactory.getLogger(LastResourcesManager.class);
	
	private List<K> m_listLastResources ;
	
	public LastResourcesManager(){}//EOM 
	
	@Override
	public final void registerLastResource(K lastResource) {
		if(this.m_listLastResources == null) this.m_listLastResources = new LinkedList<K>() ; 
		this.m_listLastResources.add(lastResource) ; 
	}//EOM 
	
	public final void removeLastResource(final String sID) {
	  if(this.m_listLastResources == null) return ; 
	  final Iterator<K> lastResourcesIterator = this.m_listLastResources.iterator() ;
	  K lastResource = null ;
	  while(lastResourcesIterator.hasNext()) {
		  lastResource = lastResourcesIterator.next() ; 
		  if(lastResource.getID().equals(sID)) lastResourcesIterator.remove() ; 
	  }//EO while there are more last resources 
	}//EOM
	
	@Override
	public String toString() {
		return "[LastResourcesManager]: No of Resources: " + (this.m_listLastResources == null ? 0 : this.m_listLastResources.size()) ; 
	}//EOM 
	
	@Override
	public void commitLastResource() throws HeuristicMixedException {
	  if(this.m_listLastResources == null) return ;  
			
	  final RuntimeAggregatedException[] arrRuntimeAggregateExceptionHolder = new RuntimeAggregatedException[1] ;  
		
	  //if there are last resources, roll them back as well  
	  final int iLength = this.m_listLastResources.size() ; 
	  K lastResource = null ; 
	  for(int i=0; i < iLength; i++) { 
		  	try{ 
		  		lastResource = this.m_listLastResources.get(i) ; 
		  		lastResource.commitLastResource();
		  	}catch(Throwable t) { 
		  		arrRuntimeAggregateExceptionHolder[0] = new RuntimeAggregatedException(t) ; 
		  		this.compensate(i, arrRuntimeAggregateExceptionHolder) ; 
		  		break ;
		  	}//EO catch block 
	  }//EO while there are more Last Resource  
		  
	  if(arrRuntimeAggregateExceptionHolder[0] != null) throw arrRuntimeAggregateExceptionHolder[0] ; 
	}//EOM
	
	private final void compensate(final int iToIndex, final RuntimeAggregatedException[] arrRuntimeArregatedException)  throws HeuristicMixedException { 

	  K lastResource = null ; 
	  
	  for(int j = 0; j <= iToIndex; j++) { 
  		lastResource =  this.m_listLastResources.get(j) ;
  		try{ 
  			lastResource.compensate() ;
  		}catch(Throwable t) { 
  			logger.error("[ThreadBoundCounterUTXWProxy.commit()]: Last resource '" + lastResource.getID() + "' had failed to compensate, System is now in inconsistent state!! ("+t.getMessage()+")");
  			if(arrRuntimeArregatedException[0] == null) arrRuntimeArregatedException[0] = new RuntimeAggregatedException(t) ; 
  			arrRuntimeArregatedException[0].addException(t) ; 
  		}//EO catch block 
  	  }//EO while there are more resources to perform compensation for 
  		
	}//EOM 
	
	@Override
	public void compensate() throws HeuristicMixedException { 
		if(this.m_listLastResources == null) return ; 
		final RuntimeAggregatedException[] arrRuntimeAggregateExceptionHolder = new RuntimeAggregatedException[1] ;
		this.compensate(this.m_listLastResources.size()-1, arrRuntimeAggregateExceptionHolder) ; 
		
		if(arrRuntimeAggregateExceptionHolder[0] != null) throw arrRuntimeAggregateExceptionHolder[0] ;
	}//EOM
	
	@Override
	public LastResourcesHandlerInterface reset() { if(this.m_listLastResources != null) this.m_listLastResources.clear() ; return this;}//EOM 
	
	@Override
	public final String getID() { return "LastResourcesManager" ; }//EOM 
	
	/* (non-Javadoc)
	 * @see com.fundtech.core.general.tx.LastResourceInterface#afterCommit()
	 */
	@Override
	public void afterCommit() throws HeuristicMixedException {

	  K lastResource = null ; 
	  if (m_listLastResources != null ) {
		  int size = m_listLastResources.size();
		  for(int j = 0; j < size; j++) { 
	  		lastResource =  this.m_listLastResources.get(j) ;
	  		try{ 
	  			lastResource.afterCommit();
	  		}catch(Throwable t) {
	  			logger.error("[ThreadBoundCounterUTXWProxy.commit()]: Last resource '" + lastResource.getID() + "' had failed to do afterCommit operation! ("+t.getMessage()+")");
	  		}//EO catch block 
  	  }//EO while there are more resources to perform compensation for 
	 }
	}//EOM 
}//EOC
