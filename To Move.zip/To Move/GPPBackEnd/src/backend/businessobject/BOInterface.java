package backend.businessobject;

/*
 * Description: Biz object interface 
 * Company:		Fundtech Israel
 * Author:		Yaron Mizrahi
 * Date:		Apr 6, 2005
 */

public interface BOInterface
{
    /** Biz object activation operations */
    public void businessObjectActivate();
    
    /** Biz object passivation operations */
    public void businessObjectPassivate();
    
    /** Biz object removal operations */
    public void businessObjectRemove();
}
