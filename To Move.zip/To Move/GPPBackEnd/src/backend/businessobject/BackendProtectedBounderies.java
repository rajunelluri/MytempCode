package backend.businessobject;

import java.lang.reflect.Method;

import javax.transaction.UserTransaction;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.businessobject.tx.SpringTransactionProxy;
import backend.dataaccess.dao.DAOPermission;
import backend.paymentprocess.erroraudit.ErrorAuditUtils;

import com.fundtech.ProtectedBounderies;
import com.fundtech.cache.infrastructure.CacheException;
import com.fundtech.cache.infrastructure.CacheServiceInterface;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.general.flows.FlowException;
import com.fundtech.core.paymentprocess.errorhandling.ProcessError;
import com.fundtech.core.security.Admin;
import com.fundtech.core.security.Admin.CallSource;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.errors.ProcessErrorConstants;
import com.fundtech.util.ExceptionController;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalUtils;

public class BackendProtectedBounderies implements ProtectedBounderies {
	private final static Logger logger = LoggerFactory.getLogger(BackendProtectedBounderies.class);

	private static ProcessError serviceFailurePError ;
	protected static DAOPermission m_daoPermission ;
	
	public final Object executeInProtectedBoundaries(final Object instance,final Method method, final Object...formalArgs) throws FlowException { 		  
		  FlowException raisedException = null ; 
		  final long lBefore = System.nanoTime() ;
		  boolean bTopLevelInvocation = false ;
		  String sTxOriginator = null ; 
		  UserTransaction utx = null ; 
		  
		  Admin admin = Admin.getContextAdmin();
		  
		  if (admin == null) 
			  Admin.setContextAdmin(CallSource.System.newAdmin("missing_admin_"+GlobalUtils.generateGUIDRandom())); 
		  
		  final boolean bSharedResourcesMode = admin.supportsSharedResources() ; 
		  	  
		  try{ 
			  bTopLevelInvocation = (admin.getSessionData(Admin.CONTEXT_PROTECTIVE_BOUNDARIES_NESTEED_INVOCATION_IND) == null) ;
			  if(bTopLevelInvocation) admin.putSessionData(Admin.CONTEXT_PROTECTIVE_BOUNDARIES_NESTEED_INVOCATION_IND, bTopLevelInvocation) ;
			  
			  //only begin the transaction is first level invocation (currently counter is only used as an indication)
			  if(bTopLevelInvocation) {
				 // ThreadBoundCounterUTXWProxy.getStartedInstance();
				  //start a nested transaction using the method name + the before time as the originator contextx 
				  utx = startTx((sTxOriginator = method.getName() + "_" + lBefore)) ; 
				  admin.putSessionData("ORIGINATOR", sTxOriginator);
				  //start a shared connection if the admin supports such behaviour
				  if(bSharedResourcesMode ) {
					  if (m_daoPermission == null)
						  m_daoPermission = new DAOPermission();
					  m_daoPermission.getConnection() ;
				  }
				  //initialize a shared jms resources session --> disabled for now as not working in fndtXfireJmsClientChannel (hannging while tx is opened) 
				 // JmsSessionContext.initSharedSession(TransmissionType.getInterfacesQueueConFactoryJndi()) ; 
				  
				  //first attempt to start a local cache Tx (session) (pass the cache region key to indicate that the tx should be opened on the local cache) 
			      CacheServiceInterface.eINSTANCE.beginTx(CacheKeys.SystParKey, false /*bOkToJoinActiveTx*/) ;
			      //then attempt to start a distributed cache Tx (session) (pass the cache region key to indicate that the tx should be opened on the distributed cache)
			     // CacheServiceInterface.eINSTANCE.beginTx(CacheKeys.dupexCheckKey, false /*bOkToJoinActiveTx*/) ;
			  }//EO if bTopLevelInvocation
		      
			  //ensure that this jvm is synchronized with the data of any external jvm invoker session
		      CacheKeys.ProcessSessionsKey.apply();

		      if(serviceFailurePError == null) serviceFailurePError = new ProcessError(ProcessErrorConstants.ServiceFailure, new Object[]{ this.getClass().getName()});
		      final long lBeforeExeuction = System.nanoTime() ;

		   	 //removed the isAccessible restoration to avoid locking 
		      //as in multi threaded environment there would a race condition between the invocation 
		      //and the setAccessible(false) 
		     // boolean isAccessible = method.isAccessible();
		      if (!method.isAccessible()) method.setAccessible(true);
		      Object o = method.invoke(instance, formalArgs) ;
		      //if (!isAccessible) method.setAccessible(false);
		      
		      logger.trace("[actual Execution time ----> {}" , ((float)(System.nanoTime()-lBeforeExeuction)/GlobalConstants.NANOS_TO_MS_DIVIDER));

			  return  o;
			  
		  }catch(FlowException fe) { 
			  raisedException =  fe ; 
		  }catch(Throwable t) { 
			  raisedException = this.onFlowFailure(t, raisedException, false/*bThrow*/,serviceFailurePError) ; 
		  }finally{ 			  
			 //only dispose of the response if first level invocation 
			if(bTopLevelInvocation) { 			  	 
				//TODO: if the tx should be rolledback for any reason, purhaps the pdo and the qexplorer should be compensated 
		    	try{ 
		    		CacheServiceInterface.eINSTANCE.closeTx(CacheKeys.SystParKey, (raisedException == null)/*bCommit*/, true /*forceClose*/) ;		    		
		    		//FOR DEBUG
				   // if(true) throw new CacheException("local cache close") ;
				    //FOR DEBUG		    		
		    	}catch(CacheException t) { 
		    		raisedException = this.onFlowFailure(t, raisedException, false/*bThrow*/,serviceFailurePError) ;
		    	}//EO catch block 
		    	
		    	/*
		    	 try{ 
		    		CacheServiceInterface.eINSTANCE.closeTx(CacheKeys.dupexCheckKey, (raisedException == null)bCommit, true forceClose) ;
		    		
		    	}catch(CacheException t) { 
		    		raisedException = this.onFlowFailure(t, raisedException, falsebThrow,serviceFailurePError) ;
		    	}//EO catch block 
		    	 */		    	
				try{
					//if the context supports shared resources and this is a top level 
					//boundary, close the shared resources prior to closing the transaction 
					if(bTopLevelInvocation && bSharedResourcesMode) Admin.m_contextFlowResources.remove() ;  
					
				   final long lBeforeCommit = System.nanoTime() ;
			       
				   //ThreadBoundCounterUTXWProxy.closeTx((raisedException == null)) ;
				   closeTx(sTxOriginator, (raisedException == null)) ;
				
			       logger.trace("Commit time ----> {}" , ((float)(System.nanoTime()-lBeforeCommit)/GlobalConstants.NANOS_TO_MS_DIVIDER));
			        
			    }catch(Throwable t) { 
			       raisedException = this.onFlowFailure(t, raisedException, false/*bThrow*/,serviceFailurePError) ;
			    }//EO close Tx catch block
				  
			    //if there was an exception exeucte pdo compensation policy 
			    if(raisedException != null) { 
			    	try{ 
			    		BOProxies.m_businessFlowSelectorLogging.performFailurePaymentCompensation(admin);
			    	}catch(Throwable t) { 
			    		raisedException = this.onFlowFailure(t, raisedException, false/*bThrow*/,serviceFailurePError) ;
			    	}//EO catch block 
			    }//EO if there was an exception
			    
			    //remove the top level invocation flag 
			    admin.getSessionData(Admin.CONTEXT_PROTECTIVE_BOUNDARIES_NESTEED_INVOCATION_IND, true) ;
			}//EO if top level invocation
			else if ((raisedException != null)&&(admin.getSessionData(Admin.FORBID_SUB_INVOCATION_ROLLBACK) == null)) { 
				try{ 
					//mark the exception for rollback only 
					//ThreadBoundCounterUTXWProxy.getStartedInstance(true/*do not increment the active users*/).setRollbackOnly() ;
					if(utx != null) 
						utx.setRollbackOnly() ; 
				}catch(Throwable t){ 
					raisedException = this.onFlowFailure(t, raisedException, false/*bThrow*/,serviceFailurePError) ;
		    	}//EO catch block 
			}//EO if nested invocation with a raised exception 
			
			final Boolean boolSameJVM = (Boolean)Admin.getContextAdmin().getSessionData(CacheKeys.ProcessSessionsKey.KEY_SAME_PROCSS_SESSION_PROPAGATOR_JVM);
		    // Sends the 1st parameter, (= bRemovePDOFromLocalCache), as true as the business flow selector might be called using a bean class, 
		    // (i.e. a different JVM). In case we're in the same JVM, (i.e. boolSameJVM = true), the 'true' value won't affect the 'propagate' method; see there.
		    CacheKeys.ProcessSessionsKey.propagate(true/*bRemovePDOFromLocalCache*/, boolSameJVM);
		    
		    
		       
		    logger.trace("AFTER ----> {}" , ((float)(System.nanoTime()-lBefore)/GlobalConstants.NANOS_TO_MS_DIVIDER));
		    
		    //if the bRaiseError flag is set to true, throw a new flow exception to the invoker 
		    //to indicate that the tx had failed
		    if(raisedException != null) throw raisedException ; 
		  }//EO catch block
		  
		  return new Feedback() ;
	  }//EOM   

	public static final UserTransaction startTx() throws Throwable { 
		return startTx(null/*sOriginator*/) ; 
	}//EOM 
	    
    public static final UserTransaction startTx(final String sOriginator) throws Throwable { 
    	return SpringTransactionProxy.m_txWrapper.get(sOriginator) ; 
    }//EOM 
    
    public static final void closeTx(final boolean bCommit) throws Throwable { 
    	closeTx(null/*sOriginator*/, bCommit) ; 
    }//EOM 
    
    public static final void closeTx(final String sOriginator, final boolean bCommit) throws Throwable { 
    	SpringTransactionProxy.m_txWrapper.remove(sOriginator, bCommit) ; 
    }//EOM
    
    protected final FlowException onFlowFailure(Throwable t, FlowException flowException, final boolean bThrow, ProcessError pError) throws FlowException{ 
  	  ExceptionController.getInstance().handleException(t, this);
        
  	  //write the error to error log 
  	  int errorCode = ProcessErrorConstants.GenericError; 
        if (pError != null)
        {
      	  errorCode = pError.getErrorCode();
      	  ErrorAuditUtils.setErrors(pError);
        }
        
        if(flowException != null) flowException.addError(t) ; 
        else { 
      	  t = ExceptionController.getActualException(t) ; 
      	  if(t instanceof FlowException && flowException == null) flowException = (FlowException) t;
      	  else flowException = new FlowException(errorCode, t, Admin.getContextAdmin().getFlowID()) ;
        }//EO else if the flow exception formal arg was not provided 
        if(bThrow) throw flowException ; 
        else return flowException ; 
    }//EOM
}
