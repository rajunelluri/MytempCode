package backend.businessobject;

  /**
   	* Business Object auto-generated interface used for the creation of the dynamic proxy decorator 
   	* for methods which are not to be exposed via ejbs yet are to be available from other bos 
   	* Should be used in the BO's stead 
    */ 
  public interface BOTreeInterface { 
     /**
    * Creates a profile tree
    * @param dtoGroups - DTODataHolder of tree categories data
    * @param dtoNodes - DTODataHolder of tree items data
    * @return TreeResponse
    */	 	
  public com.fundtech.datacomponent.response.ProfileTree.TreeResponse getTree( com.fundtech.core.security.Admin admin, backend.dataaccess.dto.DTODataHolder dtoGroups,backend.dataaccess.dto.DTODataHolder dtoNodes ) ;
  //		   		   
     /**
    * Creates a profile tree
    * @param dtoGroups - DTODataHolder of tree categories data
    * @param dtoNodes - DTODataHolder of tree items data
    * @return TreeResponse
    */	 	
  public com.fundtech.datacomponent.response.ProfileTree.TreeResponse getTree( com.fundtech.core.security.Admin admin, backend.dataaccess.dto.DTODataHolder dtoGroups,backend.dataaccess.dto.DTODataHolder dtoNodes,boolean bExcludePermission ) ;
  //		   		   
}//EOI
