/*
 * Tree
 * @author Inna Ben-Shushan
 * @date 8 October 2006
 */
package backend.businessobject;

import java.util.ArrayList;
import java.util.HashMap;

import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.datacomponent.response.ProfileTree.TreeGroup;
import com.fundtech.datacomponent.response.ProfileTree.TreeNode;
import com.fundtech.datacomponent.response.ProfileTree.TreeResponse;
import com.fundtech.util.GlobalXMLTextUtil;

import backend.dataaccess.dto.DTODataHolder;

/**
 * 
 * Jan 15, 2008
 * BOTree.java
 * 
 *Note --> use the logging decoration only with this class as it is not exposed externally
 * @bo.internalInterface
 */
public class BOTree extends BOBasic
{
	private static final String KEY_CATEGORY_ID = "CATEGORY_ID";
	private static final String KEY_CATEGORY_NAME = "CATEGORY_NAME";
	private static final String KEY_CATEGORY_PARENT = "CATEGORY_PARENT";
	
	private static final String KEY_FIELD_NAME = "FIELD_NAME";
	private static final String KEY_PERMISSION = "PERMISSION";
	private static final String KEY_DESCRIPTION = "DESCRIPT";
	
	public BOTree()
	{
		
	}
	
	/**
	 * Creates a profile tree
	 * @param dtoGroups - DTODataHolder of tree categories data
	 * @param dtoNodes - DTODataHolder of tree items data
	 * @return TreeResponse
	 * 
	 * @bo.internalInterface
	 */
	public TreeResponse getTree(DTODataHolder dtoGroups, DTODataHolder dtoNodes)
	{
		return getTree(dtoGroups, dtoNodes, false);
	}
	
	/**
	 * Creates a profile tree
	 * @param dtoGroups - DTODataHolder of tree categories data
	 * @param dtoNodes - DTODataHolder of tree items data
	 * @return TreeResponse
	 * 
	 * @bo.internalInterface
	 */
	public TreeResponse getTree(DTODataHolder dtoGroups, DTODataHolder dtoNodes, boolean bExcludePermission)
	{
		TreeResponse treeRes = new TreeResponse(bExcludePermission);
		
		Feedback feedback = handleGroups(dtoGroups, treeRes);
		if(feedback.isSuccessful())
		{
			feedback = handleNodes(dtoNodes, treeRes);
		}

		treeRes.setFeedback(feedback);
		
		return treeRes;
	}
	
	/**
	 * Handle Group nodes
	 * @param dtoGroups - DTODataHolder of tree categories data
	 * @param treeRes - TreeResponse
	 * @param hmParents - HashMap
	 * @return feedback
	 */
	private Feedback handleGroups(DTODataHolder dtoGroups, TreeResponse treeRes)
	{
		Feedback feedback = dtoGroups.getFeedBack();
		
		if(feedback.isSuccessful())
		{
			int iLength = dtoGroups.getRowsNumber();
			ArrayList alGroups = dtoGroups.getDataAL();

			for(int i=0 ; i<iLength ; i++)
			{
				GroupDetails gd = new GroupDetails((HashMap)alGroups.get(i));
				// Create group
				TreeGroup tgGroup = new TreeGroup(gd.getID(),gd.getName(),gd.getParentID());
				treeRes.addGroup(tgGroup);
			}
		}
		
		return feedback;
	}
	
	/**
	 * A single node details
	 */
	private class GroupDetails
	{
		private String m_sID;
		private String m_sName;
		private String m_sParentID;
				
		public GroupDetails(HashMap hm)
		{
			m_sID = (String)hm.get(KEY_CATEGORY_ID);
			m_sName = (String)hm.get(KEY_CATEGORY_NAME);
			m_sParentID = (String)hm.get(KEY_CATEGORY_PARENT);
		}
		
		public String getID()
		{
			return m_sID;
		}
		
		public String getName()
		{
			return m_sName;
		}
		
		public String getParentID()
		{
			return m_sParentID;
		}
	}
	
	/**
	 * Handle nodes
	 * @param aer - account explorer
	 */
	private Feedback handleNodes(DTODataHolder dtoNodes, TreeResponse treeRes)
	{
		Feedback feedback = dtoNodes.getFeedBack();
		
		if(feedback.isSuccessful())
		{
			int[] arrCounterNodes = new int[1];
			int iLength = dtoNodes.getRowsNumber();
			for(int i=0; i<iLength ; i++)
			{
				addNode(treeRes, dtoNodes.getDataRow(i), ++arrCounterNodes[0]);
			}
		}
		
		return feedback;
	}
		
	/**
	 * Add node
	 * @param aer - account explorer response
	 */
	private void addNode(TreeResponse treeRes, HashMap hmNode,	int iCounterNode)
	{
		NodeDetails nd = new NodeDetails(hmNode);
					
        
		TreeNode node = new TreeNode(nd.getGroupID(),nd.getName(), nd.getDescription(), nd.getPermission());
		node.setID(iCounterNode);
		
		treeRes.addNode(node);
	}
		
	/**
	 * A single node details
	 */
	private class NodeDetails
	{
		private String m_sGroupID;
		private String m_sName;
		private String m_sDescription;
		private String m_sPermission;
		
		
		public NodeDetails(HashMap hm)
		{
		    //CR1002 - must encode the value as some elements must be escaped or otherwise represented 
             ///guy 9/01/2007
			m_sGroupID = GlobalXMLTextUtil.encode((String)hm.get(KEY_CATEGORY_ID)) ;
			m_sName = GlobalXMLTextUtil.encode((String)hm.get(KEY_FIELD_NAME)) ;
			m_sDescription = GlobalXMLTextUtil.encode((String)hm.get(KEY_DESCRIPTION)) ; 
			m_sPermission = GlobalXMLTextUtil.encode((String)hm.get(KEY_PERMISSION)) ;
		}
		
		public String getGroupID()
		{
			return m_sGroupID;
		}
		
		public String getName()
		{
			return m_sName;
		}
		
		public String getDescription()
		{
			return m_sDescription;
		}
		
		public String getPermission()
		{
			return m_sPermission;
		}
	}
}
