package backend.businessobject.sharedresources.proxies;

import java.lang.reflect.Method;
import java.sql.Connection;

import com.fundtech.jndi.sharedresources.SharedResourceProxy1;

public class SharedSQLConnectionProxy extends SharedResourceProxy1<Connection>  {

	static { 
		register(Connection.class, SharedSQLConnectionProxy.class) ; 
	}//EO static block
	
	public SharedSQLConnectionProxy(final Connection oDelegate) { super(oDelegate) ; }//EOM
	
	@Override
	protected final Object getDeferredInvocationMockResponse(final Method method, Object[] args) {
		//all rollback and commit methods return null ; 
		return null;
	}//EOM 
	
}//EOC 
