package backend.businessobject;

import backend.businessobject.proxies.BOProxy;
import backend.core.module.message.groupactions.businessobjects.BOGroupActions;
import backend.core.module.message.groupactions.ejbinterfaces.GroupActionsLocal;
import backend.core.module.messagehandle.businessobjects.BOMessageHandle;
import backend.core.module.messagehandle.businessobjects.BOMessageHandleInterface;
import backend.core.module.messagehandle.ejbinterfaces.MessageHandleLocal;
import backend.core.module.qexplorer.businessobjects.BOQueueExplorer;
import backend.core.module.qexplorer.businessobjects.BOQueueExplorerInterface;
import backend.core.module.qexplorer.ejbinterfaces.QueueExplorerLocal;
import backend.core.module.queues.businessobjects.BOQueues;
import backend.core.module.queues.businessobjects.BOQueuesInterface;
import backend.core.module.security.businessobjects.BOSecurity;
import backend.core.module.security.businessobjects.BOSecurityInterface;
import backend.jms.businessobjects.BOJBean;
import backend.jms.businessobjects.BOJMessaging;
import backend.jms.ejbinterfaces.JMessagingLocal;
import backend.paymentprocess.accountderivation.businessobjects.BOAccountDerivation;
import backend.paymentprocess.accountderivation.businessobjects.BOAnticipatedFundAccountDerivation;
import backend.paymentprocess.accountderivation.ejbinterfaces.AccountDerivation;
import backend.paymentprocess.accountderivation.ejbinterfaces.AccountDerivationLocal;
import backend.paymentprocess.anticipatedfunds.businessobjects.BOAnticipatedFunds;
import backend.paymentprocess.anticipatedfunds.ejbinterfaces.AnticipatedFundsLocal;
import backend.paymentprocess.approverefusecancel.businessobjects.BOApproveRefuseCancel;
import backend.paymentprocess.approverefusecancel.ejbinterfaces.ApproveRefuseCancelLocal;
import backend.paymentprocess.balanceinquiry.businessobjects.BOBalanceInquiry;
import backend.paymentprocess.balanceinquiry.ejbinterfaces.BalanceInquiryLocal;
import backend.paymentprocess.bankrout.businessobjects.BOBankRout;
import backend.paymentprocess.bankrout.ejbinterfaces.BankRoutLocal;
import backend.paymentprocess.baseprocess.businessobjects.BOBaseProcess;
import backend.paymentprocess.baseprocess.businessobjects.BOBaseProcessInterface;
import backend.paymentprocess.businessflowselector.businessobjects.BOBusinessFlowSelector;
import backend.paymentprocess.businessflowselector.businessobjects.BOBusinessFlowSelectorInterface;
import backend.paymentprocess.businessflowselector.ejbinterfaces.BusinessFlowSelectorLocal;
import backend.paymentprocess.closeopennewoutfiles.businessobjects.BOCloseOpenNewOutFiles;
import backend.paymentprocess.closeopennewoutfiles.ejbinterfaces.CloseOpenNewOutFilesLocal;
import backend.paymentprocess.compliance.businessobjects.BOCompliance;
import backend.paymentprocess.compliance.ejbinterfaces.ComplianceLocal;
import backend.paymentprocess.creditdailylimit.businessobjects.BOCreditDailyLimit;
import backend.paymentprocess.creditdailylimit.businessobjects.BOCreditDailyLimitInterface;
import backend.paymentprocess.creditpartyenrichment.businessobjects.BOCreditPartyEnrichment;
import backend.paymentprocess.creditpartyenrichment.ejbinterfaces.CreditPartyEnrichmentLocal;
import backend.paymentprocess.currencyconversion.businessobjects.BOCurrencyConversion;
import backend.paymentprocess.currencyconversion.businessobjects.BOCurrencyConversionInterface;
import backend.paymentprocess.currencyconversion.ejbinterfaces.CurrencyConversionLocal;
import backend.paymentprocess.debitauthorization.businessobjects.BODebitAuthorization;
import backend.paymentprocess.debitauthorization.ejbinterfaces.DebitAuthorizationLocal;
import backend.paymentprocess.debulkingprocess.businessobjects.BODebulkFile;
import backend.paymentprocess.debulkingprocess.businessobjects.BODebulkingProcess;
import backend.paymentprocess.debulkingprocess.businessobjects.BOG3BPDebulkFile;
import backend.paymentprocess.debulkingprocess.ejbinterfaces.DebulkFileLocal;
import backend.paymentprocess.debulkingprocess.ejbinterfaces.DebulkingProcessLocal;
import backend.paymentprocess.enrichment.businessobjects.BOEnrichment;
import backend.paymentprocess.enrichment.ejbinterfaces.EnrichmentLocal;
import backend.paymentprocess.feescalculation.businessobjects.BOFeesCalculation;
import backend.paymentprocess.feescalculation.ejbinterfaces.FeesCalculationLocal;
import backend.paymentprocess.fileapproval.businessobjects.BOFileApproval;
import backend.paymentprocess.fileapproval.businessobjects.BOFileApprovalInterface;
import backend.paymentprocess.findfirstinchain.businessobjects.BOFindFirstInChain;
import backend.paymentprocess.findfirstinchain.ejbinterfaces.FindFirstInChainLocal;
import backend.paymentprocess.generatetransaction.businessobjects.BOGenerateTransaction;
import backend.paymentprocess.generatetransaction.ejbinterfaces.GenerateTransactionLocal;
import backend.paymentprocess.glm.bands.businessobjects.BOBands;
import backend.paymentprocess.glm.bands.ejbinterface.BandsLocal;
import backend.paymentprocess.glm.capsmanagement.businessobjects.BOCapsManagement;
import backend.paymentprocess.glm.capsmanagement.ejbinterface.CapsManagementLocal;
import backend.paymentprocess.glm.process.businessobjects.BOGLMProcessing;
import backend.paymentprocess.glm.process.ejbinterfaces.GLMProcessingLocal;
import backend.paymentprocess.highvalueprocess.businessobjects.BOHighValueProcess;
import backend.paymentprocess.highvalueprocess.businessobjects.BOHighValueProcessWrapper;
import backend.paymentprocess.highvalueprocess.ejbinterfaces.HighValueProcess;
import backend.paymentprocess.highvalueprocess.ejbinterfaces.HighValueProcessWrapper;
import backend.paymentprocess.incomingfilecancellation.businessobjects.BOIncomingFileCancellation;
import backend.paymentprocess.incomingfilecancellation.ejbinterfaces.IncomingFileCancellationLocal;
import backend.paymentprocess.incomingrejectreturn.businessobjects.BOIncomingRejectReturn;
import backend.paymentprocess.incomingrejectreturn.ejbinterfaces.IncomingRejectReturnLocal;
import backend.paymentprocess.interfaces.businessobjects.BOInterfaces;
import backend.paymentprocess.interfaces.businessobjects.BOInterfacesInterface;
import backend.paymentprocess.interfaces.businessobjects.BOResendableInterfaces;
import backend.paymentprocess.interfaces.businessobjects.ejbinterfaces.ResendableInterfacesLocal;
import backend.paymentprocess.interoffice.businessobjects.BOInteroffice;
import backend.paymentprocess.interoffice.ejbinterfaces.InterofficeLocal;
import backend.paymentprocess.ledgerconfirmation.businessobjects.BOLedgerConfirmation;
import backend.paymentprocess.ledgerconfirmation.ejbinterfaces.LedgerConfirmationLocal;
import backend.paymentprocess.loadcustomer.businessobjects.BOLoadCustomer;
import backend.paymentprocess.loadcustomer.ejbinterfaces.LoadCustomerLocal;
import backend.paymentprocess.loadpostinginfo.businessobjects.BOLoadPostingInfo;
import backend.paymentprocess.loadpostinginfo.businessobjects.BOLoadPostingInfoInterface;
import backend.paymentprocess.loadpostinginfo.ejbinterfaces.LoadPostingInfoLocal;
import backend.paymentprocess.mappaymentinfo.businessobjects.BOMapPaymentInfoUsingRules;
import backend.paymentprocess.mappaymentinfo.ejbinterfaces.MapPaymentInfoUsingRules;
import backend.paymentprocess.matchingcheck.businessobjects.BOMatchingCheck;
import backend.paymentprocess.matchingcheck.ejbinterfaces.MatchingCheckLocal;
import backend.paymentprocess.memopost.businessobjects.BOMemoPost;
import backend.paymentprocess.memopost.ejbinterfaces.MemoPostLocal;
import backend.paymentprocess.mopselection.businessobjects.BOMopSelection;
import backend.paymentprocess.mopselection.ejbinterfaces.MopSelectionLocal;
import backend.paymentprocess.nsf.businessobjects.BONsf;
import backend.paymentprocess.nsf.ejbinterfaces.NsfLocal;
import backend.paymentprocess.ocbc.g3adminmessages.businessobjects.BOAdminMessageBoSelector;
import backend.paymentprocess.ocbc.g3adminmessages.ejbinterfaces.AdminMessageBoSelector;
import backend.paymentprocess.ocbc.g3adminmessages.ejbinterfaces.AdminMessageBoSelectorLocal;
import backend.paymentprocess.ocbc.g3reconciliation.businessobject.BOG3ReconciliationFlow;
import backend.paymentprocess.ocbc.g3reconciliation.ejbinterfaces.G3ReconciliationFlowLocal;
import backend.paymentprocess.ocbc.g3reversal.businessobject.BOG3ReversalFlow;
import backend.paymentprocess.ocbc.g3reversal.ejbinterfaces.G3ReversalFlowLocal;
import backend.paymentprocess.outbounddirectscovers.businessobjects.BOOutboundDirectsCovers;
import backend.paymentprocess.outbounddirectscovers.ejbinterfaces.OutboundDirectsCoversLocal;
import backend.paymentprocess.outgoingrequestforcharges.businessobjects.BOOutgoingRequestForCharges;
import backend.paymentprocess.outgoingrequestforcharges.ejbinterfaces.OutgoingRequestForChargesLocal;
import backend.paymentprocess.partylimit.businessobjects.BOPartyLimit;
import backend.paymentprocess.partylimit.ejbinterfaces.PartyLimitLocal;
import backend.paymentprocess.partyprocessing.businessobjects.BOAnticipatedFundsPartyProcessing;
import backend.paymentprocess.partyprocessing.businessobjects.BOPartyProcessing;
import backend.paymentprocess.partyprocessing.businessobjects.BOPartyProcessingInterface;
import backend.paymentprocess.paymentadvising.businessobjects.BOPaymentAdvising;
import backend.paymentprocess.paymentadvising.ejbinterfaces.PaymentAdvisingLocal;
import backend.paymentprocess.paymentservices.businessobjects.BOPaymentServices;
import backend.paymentprocess.paymentservices.ejbinterfaces.PaymentServicesLocal;
import backend.paymentprocess.pisnmatching.businessobjects.BOPISNMatching;
import backend.paymentprocess.pisnmatching.ejbinterfaces.PISNMatching;
import backend.paymentprocess.pisnmatching.ejbinterfaces.PISNMatchingLocal;
import backend.paymentprocess.positionkeeping.businessobjects.BOPositionKeeping;
import backend.paymentprocess.positionkeeping.ejbinterfaces.PositionKeepingLocal;
import backend.paymentprocess.processedchunks.businessobjects.BOProcessedChunks;
import backend.paymentprocess.processedchunks.ejbinterfaces.ProcessedChunksLocal;
import backend.paymentprocess.processflows.businessobjects.BOProcessFlows;
import backend.paymentprocess.processflows.businessobjects.BOProcessFlowsInterface;
import backend.paymentprocess.processflows.ejbinterfaces.ProcessFlowsLocal;
import backend.paymentprocess.rebulking.businessobject.BORebulkProcess;
import backend.paymentprocess.rebulking.ejbinterfaces.RebulkProcessLocal;
import backend.paymentprocess.reconciliation.businessobject.BOReconciliation;
import backend.paymentprocess.reconciliation.ejbinterfaces.Reconciliation;
import backend.paymentprocess.reconciliation.ejbinterfaces.ReconciliationLocal;
import backend.paymentprocess.rtr.businessobjects.BORTR;
import backend.paymentprocess.rtr.ejbinterfaces.RTRLocal;
import backend.paymentprocess.ruleexecution.businessobjects.BORuleExecution;
import backend.paymentprocess.ruleexecution.businessobjects.BORuleExecutionInterface;
import backend.paymentprocess.setbasicproperties.businessobjects.BOSetBasicProperties;
import backend.paymentprocess.setbasicproperties.ejbinterfaces.SetBasicPropertiesLocal;
import backend.paymentprocess.settlementconfirmation.businessobjects.BOSettlementConfirmation;
import backend.paymentprocess.settlementconfirmation.ejbinterfaces.SettlementConfirmationLocal;
import backend.paymentprocess.settlementnotice.businessobjects.BOSettlementNotice;
import backend.paymentprocess.settlementnotice.ejbinterfaces.SettlementNoticeLocal;
import backend.paymentprocess.specialinstruction.businessobjects.BOSpecialInstruction;
import backend.paymentprocess.specialinstruction.ejbinterfaces.SpecialInstructionLocal;
import backend.paymentprocess.standingorder.businessobjects.BOStandingOrder;
import backend.paymentprocess.standingorder.businessobjects.BOStandingOrderInterface;
import backend.paymentprocess.stopflags.businessobjects.BOStopFlags;
import backend.paymentprocess.stopflags.ejbinterfaces.StopFlagsLocal;
import backend.paymentprocess.stprules.businessobjects.BOSTPRules;
import backend.paymentprocess.stprules.ejbinterfaces.STPRulesLocal;
import backend.paymentprocess.subbatchcancellation.businessobjects.BOSubBatchCancellation;
import backend.paymentprocess.subbatchcancellation.ejbinterfaces.SubBatchCancellationLocal;
import backend.paymentprocess.subbatchcompletion.businessobjects.BOSubBatchCompletion;
import backend.paymentprocess.subbatchcompletion.ejbinterfaces.SubBatchCompletionLocal;
import backend.paymentprocess.subbatchgeneration.businessobjects.BOSubBatchGeneration;
import backend.paymentprocess.subbatchgeneration.ejbinterfaces.SubBatchGenerationLocal;
import backend.paymentprocess.suspenseaccount.businessobjects.BOSuspenseAccountDerivation;
import backend.paymentprocess.suspenseaccount.ejbinterfaces.SuspenseAccountDerivationLocal;
import backend.paymentprocess.throttling.businessobjects.BOThrottling;
import backend.paymentprocess.throttling.ejbinterfaces.ThrottlingLocal;
import backend.paymentprocess.uidgeneration.businessobjects.BOUidGeneration;
import backend.paymentprocess.uidgeneration.ejbinterfaces.UidGenerationLocal;
import backend.paymentprocess.unifiedgateway.businessobjects.BOMessageUnifiedGateway;
import backend.paymentprocess.unifiedgateway.ejbinterfaces.MessageUnifiedGateway;
import backend.paymentprocess.warehousing.businessobjects.BOWarehousing;
import backend.paymentprocess.warehousing.ejbinterfaces.WarehousingLocal;
import backend.staticdata.module.approvedecline.businessobjects.BOApproveDeclineProfile;
import backend.staticdata.module.approvedecline.businessobjects.BOApproveDeclineProfileInterface;
import backend.staticdata.module.changestatus.businessobjects.BOChangeProfileStatus;
import backend.staticdata.module.changestatus.ejbinterfaces.ChangeProfileStatusLocal;
import backend.staticdata.module.create.businessobjects.BOCreateProfile;
import backend.staticdata.module.create.businessobjects.BOCreateProfileInterface;
import backend.staticdata.module.lockrelease.businessobjects.BOLockReleaseProfile;
import backend.staticdata.module.lockrelease.businessobjects.BOLockReleaseProfileInterface;
import backend.util.edw.businessobjects.BOEdw;
import backend.util.edw.ejbinterfaces.EdwInterfaceLocal;

public interface BOProxies {

	public static final MessageHandleLocal m_messageHandleLogging = BOProxy.loggingDecoration(BOMessageHandle.class) ;
	public static final BOMessageHandleInterface m_internalMessageHandleLogging = BOProxy.loggingDecoration(BOMessageHandle.class, BOMessageHandleInterface.class) ;
	
	public static final ResendableInterfacesLocal m_resendableInterfaces = BOProxy.loggingDecoration(BOResendableInterfaces.class,ResendableInterfacesLocal.class);
	
	public static final BOBaseProcessInterface m_internalBaseProcessLogging = BOProxy.loggingDecoration(BOBaseProcess.class, BOBaseProcessInterface.class) ;
	
	public static FeesCalculationLocal m_feeCalculationLogging = BOProxy.loggingDecoration(BOFeesCalculation.class, FeesCalculationLocal.class);
	 
	public static final StopFlagsLocal m_stopFlagsLogging = BOProxy.loggingDecoration(BOStopFlags.class, StopFlagsLocal.class);
	 
	public static final BOLoadPostingInfoInterface m_internalLoadPostingInfoPdoHandling = BOProxy.pdoHandlingDecoration(BOLoadPostingInfo.class, BOLoadPostingInfoInterface.class);
    public static final LoadPostingInfoLocal m_loadPostingInfoLogging = BOProxy.loggingDecoration(BOLoadPostingInfo.class, LoadPostingInfoLocal.class);
    
    public static final GroupActionsLocal m_groupActionsComplete = BOProxy.completeDecoration(BOGroupActions.class, GroupActionsLocal.class) ;
    public static final GroupActionsLocal m_groupActionsLogging = BOProxy.loggingDecoration(BOGroupActions.class, GroupActionsLocal.class) ;
    
    
    public static final BOQueueExplorerInterface m_internalQueueExplorerLogging = BOProxy.loggingDecoration(BOQueueExplorer.class,BOQueueExplorerInterface.class);
    public static final QueueExplorerLocal m_queueExplorerLogging = BOProxy.loggingDecoration(BOQueueExplorer.class);
    public static final QueueExplorerLocal m_queueExplorerComplete = BOProxy.loggingDecoration(BOQueueExplorer.class);
    
    public static BOSecurityInterface m_boSecurityLogging = BOProxy.loggingDecoration(BOSecurity.class, BOSecurityInterface.class);
    
    public static final BOQueuesInterface m_boQueuesLogging = BOProxy.loggingDecoration(BOQueues.class, BOQueuesInterface.class);
    
    public static final JMessagingLocal m_jmsHandlerLogging = BOProxy.loggingDecoration(BOJMessaging.class);
    public static final JMessagingLocal m_BOJBeanHandlerLogging = BOProxy.loggingDecoration(BOJBean.class, JMessagingLocal.class);
    
    public static final AccountDerivationLocal m_accountDerivationComplete = BOProxy.completeDecoration(BOAccountDerivation.class, AccountDerivationLocal.class);
    public static final AccountDerivationLocal m_accountDerivationLogging = BOProxy.loggingDecoration(BOAccountDerivation.class, AccountDerivationLocal.class);
    public static final AccountDerivation m_internalAnticipatedFundAccountDerivationLogging = BOProxy.loggingDecoration(BOAnticipatedFundAccountDerivation.class, AccountDerivation.class);

    public static final ApproveRefuseCancelLocal m_approveRefuseCancelComplete = BOProxy.completeDecoration(BOApproveRefuseCancel.class, ApproveRefuseCancelLocal.class);
    
    public static final AnticipatedFundsLocal m_anticipatedFundsLogging = BOProxy.loggingDecoration(BOAnticipatedFunds.class, AnticipatedFundsLocal.class);
    
    public static final BankRoutLocal m_bankRoutLogging = BOProxy.loggingDecoration(BOBankRout.class, BankRoutLocal.class);
    
    public static final BusinessFlowSelectorLocal m_businessFlowSelectorLogging = BOProxy.loggingDecoration(BOBusinessFlowSelector.class, BusinessFlowSelectorLocal.class);
    public static final BOBusinessFlowSelectorInterface m_internalBusinessFlowSelectorLogging = BOProxy.loggingDecoration(BOBusinessFlowSelector.class, BOBusinessFlowSelectorInterface.class) ;
    
    public static final ComplianceLocal m_complianceLogging = BOProxy.loggingDecoration(BOCompliance.class, ComplianceLocal.class);
    public static final BOCreditDailyLimitInterface m_internalCreditDailyLimitLogging = BOProxy.loggingDecoration(BOCreditDailyLimit.class, BOCreditDailyLimitInterface.class);
    public static final CreditPartyEnrichmentLocal m_creditPartyEnrichmentComplete = BOProxy.completeDecoration(BOCreditPartyEnrichment.class, CreditPartyEnrichmentLocal.class);

    public static final CurrencyConversionLocal m_currencyConversionComplete = BOProxy.completeDecoration(BOCurrencyConversion.class, CurrencyConversionLocal.class);
    public static final CurrencyConversionLocal m_currencyConversionLogging = BOProxy.loggingDecoration(BOCurrencyConversion.class, CurrencyConversionLocal.class);
    public static final BOCurrencyConversionInterface m_internalCurrencyConversionLogging = BOProxy.loggingDecoration(BOCurrencyConversion.class, BOCurrencyConversionInterface.class);
    
    public static final EnrichmentLocal m_enrichmentLogging = BOProxy.loggingDecoration(BOEnrichment.class, EnrichmentLocal.class);
    
    public static final DebitAuthorizationLocal m_debitAuthorizationComplete = BOProxy.completeDecoration(BODebitAuthorization.class, DebitAuthorizationLocal.class);
    public static final DebitAuthorizationLocal m_debitAuthorizationLogging = BOProxy.loggingDecoration(BODebitAuthorization.class, DebitAuthorizationLocal.class);
    
    public static final DebulkFileLocal m_debulkFileLogging =  BOProxy.loggingDecoration(BODebulkFile.class) ;
    public static final DebulkFileLocal m_debulkG3FileLogging =  BOProxy.loggingDecoration(BOG3BPDebulkFile.class, DebulkFileLocal.class) ;
    public static final RebulkProcessLocal m_rebulkProcessLogging = BOProxy.loggingDecoration(BORebulkProcess.class, RebulkProcessLocal.class) ;
    public static final BOFileApprovalInterface m_internalFileApprovalInterfaceComplete = BOProxy.completeDecoration(BOFileApproval.class, BOFileApprovalInterface.class) ;
    
    public static final FindFirstInChainLocal m_findFirstInChainLogging = BOProxy.loggingDecoration(BOFindFirstInChain.class, FindFirstInChainLocal.class);
    
    public static final GenerateTransactionLocal m_generateTransactionLogging = BOProxy.loggingDecoration(BOGenerateTransaction.class, GenerateTransactionLocal.class);
    
    public static final HighValueProcess m_highValueProcessLogging = BOProxy.loggingDecoration(BOHighValueProcess.class, HighValueProcess.class);
    
    public static final HighValueProcessWrapper m_highValueProcessWrapperLogging = BOProxy.loggingDecoration(BOHighValueProcessWrapper.class, HighValueProcessWrapper.class);
    
    public static final CloseOpenNewOutFilesLocal m_closeOpenNewOutFilesComplete = BOProxy.loggingDecoration(BOCloseOpenNewOutFiles.class, CloseOpenNewOutFilesLocal.class) ;
    public static final DebulkingProcessLocal m_debulkingProcessLogging = BOProxy.loggingDecoration(BODebulkingProcess.class, DebulkingProcessLocal.class) ;
    public static final IncomingFileCancellationLocal m_fileCancellationLocalComplete = BOProxy.completeDecoration(BOIncomingFileCancellation.class, IncomingFileCancellationLocal.class) ;
    
    public static final BOInterfacesInterface m_internalInterfacesLogging = BOProxy.loggingDecoration(BOInterfaces.class, BOInterfacesInterface.class) ;
    
    public static final InterofficeLocal m_interofficeLocalLogging = BOProxy.loggingDecoration(BOInteroffice.class, InterofficeLocal.class);
    
    public static final LoadCustomerLocal m_loadCustomerComplete = BOProxy.completeDecoration(BOLoadCustomer.class, LoadCustomerLocal.class);
    public static final LoadCustomerLocal m_loadCustomerLogging = BOProxy.loggingDecoration(BOLoadCustomer.class, LoadCustomerLocal.class);
    
    public static final MapPaymentInfoUsingRules m_mapPaymentInfoUsingRulesLogging = BOProxy.loggingDecoration(BOMapPaymentInfoUsingRules.class,MapPaymentInfoUsingRules.class);
    
    public static final MatchingCheckLocal m_matchingCheckLogging = BOProxy.loggingDecoration(BOMatchingCheck.class, MatchingCheckLocal.class);
    
    public static final MopSelectionLocal m_mopSelectionLogging = BOProxy.loggingDecoration(BOMopSelection.class, MopSelectionLocal.class);
    
    public static final NsfLocal m_nsfComplete = BOProxy.completeDecoration(BONsf.class, NsfLocal.class) ;
    
    public static final OutgoingRequestForChargesLocal m_outgoingRequestForChargesLogging = BOProxy.loggingDecoration(BOOutgoingRequestForCharges.class, OutgoingRequestForChargesLocal.class);
    
    public static final BOPartyProcessingInterface m_internalPartyProcessingLogging = BOProxy.loggingDecoration(BOPartyProcessing.class, BOPartyProcessingInterface.class);
    
    public static final BOPartyProcessingInterface m_internalAFPartyProcessingLogging = BOProxy.loggingDecoration(BOAnticipatedFundsPartyProcessing.class, BOPartyProcessingInterface.class);
    
    public static final PaymentAdvisingLocal m_paymentAdvisingLogging = BOProxy.loggingDecoration(BOPaymentAdvising.class, PaymentAdvisingLocal.class);
    
    public static final PaymentServicesLocal m_paymentServicesLogging = BOProxy.loggingDecoration(BOPaymentServices.class, PaymentServicesLocal.class);
    
    public static final PISNMatching m_pisnMatchingLogging = BOProxy.loggingDecoration(BOPISNMatching.class, PISNMatchingLocal.class);
    
    public static final BOProcessFlowsInterface m_interfaceProcessFlowsComplete = BOProxy.completeDecoration(BOProcessFlows.class, BOProcessFlowsInterface.class);
    
	public static final ProcessFlowsLocal  m_processFlowsLocal = BOProxy.loggingDecoration(BOProcessFlows.class, ProcessFlowsLocal.class);
    
    public static final RebulkProcessLocal m_rebulkProcessComplete = BOProxy.completeDecoration(BORebulkProcess.class, RebulkProcessLocal.class) ;
    
    public static final RTRLocal m_rtrLogging = BOProxy.loggingDecoration(BORTR.class) ;
	
	public static final RTRLocal m_rtrComplete = BOProxy.completeDecoration(BORTR.class) ;
	
	public static final BORuleExecutionInterface m_internalRuleExecutionLogging = BOProxy.loggingDecoration(BORuleExecution.class, BORuleExecutionInterface.class) ;
	
	public static final SetBasicPropertiesLocal m_setBasicPropertiesLogging = BOProxy.loggingDecoration(BOSetBasicProperties.class, SetBasicPropertiesLocal.class) ;
	
	public static final SpecialInstructionLocal m_specialInstructionLogging = BOProxy.loggingDecoration(BOSpecialInstruction.class, SpecialInstructionLocal.class);
	
	public static final BOStandingOrderInterface m_internalStandingOrder = BOProxy.loggingDecoration(BOStandingOrder.class,BOStandingOrderInterface.class);
	
	public static final STPRulesLocal m_stpRulesLogging = BOProxy.loggingDecoration(BOSTPRules.class, STPRulesLocal.class);
	
	public static final STPRulesLocal m_stpRulesComplete = BOProxy.completeDecoration(BOSTPRules.class, STPRulesLocal.class);
	
	public static final SubBatchCancellationLocal m_subbatchCancellationComplete = BOProxy.loggingDecoration(BOSubBatchCancellation.class, SubBatchCancellationLocal.class) ;
	
	public static final SubBatchCompletionLocal m_subbatchCompletionLogging = BOProxy.loggingDecoration(BOSubBatchCompletion.class, SubBatchCompletionLocal.class) ;
	
	public static final SubBatchGenerationLocal m_subbatchGenerationLogging = BOProxy.loggingDecoration(BOSubBatchGeneration.class, SubBatchGenerationLocal.class) ;

	public static final ProcessedChunksLocal m_processChunksLogging = BOProxy.loggingDecoration(BOProcessedChunks.class ,ProcessedChunksLocal.class);
	public static final BOApproveDeclineProfileInterface m_internalApproveDeclineComplete = BOProxy.completeDecoration(BOApproveDeclineProfile.class, BOApproveDeclineProfileInterface.class) ;
	
	public static final ChangeProfileStatusLocal m_changeProfileStatusLogging = BOProxy.loggingDecoration(BOChangeProfileStatus.class,ChangeProfileStatusLocal.class);
	
	public static final BOCreateProfileInterface m_internalCreateProfileComplete = BOProxy.completeDecoration(BOCreateProfile.class, BOCreateProfileInterface.class) ;
	
	public static final BOLockReleaseProfileInterface m_internalLockReleaseComplete = BOProxy.completeDecoration(BOLockReleaseProfile.class, BOLockReleaseProfileInterface.class) ;
	
	public static final UidGenerationLocal m_uidGenerationLogging = BOProxy.loggingDecoration(BOUidGeneration.class, UidGenerationLocal.class)  ;
	
	public static final BalanceInquiryLocal m_balanceInquiryLogging = BOProxy.loggingDecoration(BOBalanceInquiry.class, BalanceInquiryLocal.class);

	public static final MessageUnifiedGateway m_MessasgeUnifiedGatewayLogging = BOProxy.loggingDecoration(BOMessageUnifiedGateway.class)  ;
	
	public static final PartyLimitLocal m_PartyLimitLogging = BOProxy.loggingDecoration(BOPartyLimit.class, PartyLimitLocal.class)  ;
	public static final SuspenseAccountDerivationLocal m_suspenseAccountDerivationLogging = BOProxy.loggingDecoration(BOSuspenseAccountDerivation.class, SuspenseAccountDerivationLocal.class);
	public static final PositionKeepingLocal m_PositionKeepingLogging = BOProxy.loggingDecoration(BOPositionKeeping.class, PositionKeepingLocal.class)  ;

	public static final MemoPostLocal m_MemoPostLogging = BOProxy.loggingDecoration(BOMemoPost.class, MemoPostLocal.class)  ;

	public static final SettlementConfirmationLocal m_settlementConfirmationLogging = BOProxy.loggingDecoration(BOSettlementConfirmation.class, SettlementConfirmationLocal.class)  ;
	
	public static final SettlementNoticeLocal m_settlementNoticeLogging = BOProxy.loggingDecoration(BOSettlementNotice.class, SettlementNoticeLocal.class)  ;
	
	public static final LedgerConfirmationLocal m_ledgerConfirmationLogging = BOProxy.loggingDecoration(BOLedgerConfirmation.class, LedgerConfirmationLocal.class)  ;
	public static final IncomingRejectReturnLocal m_incomingRejectReturnLocalLogging = BOProxy.loggingDecoration(BOIncomingRejectReturn.class, IncomingRejectReturnLocal.class);
	public static final ThrottlingLocal m_ThrottlingLogging = BOProxy.loggingDecoration(BOThrottling.class, ThrottlingLocal.class)  ;
	
	public static final OutboundDirectsCoversLocal m_outboundDirectsCoversLogging = BOProxy.loggingDecoration(BOOutboundDirectsCovers.class, OutboundDirectsCoversLocal.class)  ;

	public static final CapsManagementLocal m_capsManagementLogging = BOProxy.loggingDecoration(BOCapsManagement.class, CapsManagementLocal.class)  ;
	
	public static final BandsLocal m_bandsLogging = BOProxy.loggingDecoration(BOBands.class, BandsLocal.class)  ;
	
	public static final GLMProcessingLocal m_glmProcessingLogging = BOProxy.loggingDecoration(BOGLMProcessing.class, GLMProcessingLocal.class)  ;
	
	public static final G3ReconciliationFlowLocal m_g3ReconciliationFlowLogging = BOProxy.loggingDecoration(BOG3ReconciliationFlow .class, G3ReconciliationFlowLocal.class)  ;
	
	public static final G3ReversalFlowLocal m_g3ReversalFlowLogging = BOProxy.loggingDecoration(BOG3ReversalFlow.class, G3ReversalFlowLocal.class)  ;
	
	public static final Reconciliation m_ReconciliationLogging = BOProxy.loggingDecoration(BOReconciliation.class,ReconciliationLocal.class);
	
	WarehousingLocal m_WarehousingLogging = BOProxy.loggingDecoration(BOWarehousing.class, WarehousingLocal.class);
	
	public static final EdwInterfaceLocal m_EdwTableUpdateLogging = BOProxy.loggingDecoration(BOEdw.class, EdwInterfaceLocal.class);
	
	public static final AdminMessageBoSelector m_adminMessegesBoSelectorLogging = BOProxy.loggingDecoration(BOAdminMessageBoSelector.class, AdminMessageBoSelectorLocal.class);
}//EOI 
