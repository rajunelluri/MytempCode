package backend.businessobject.proxies ;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.MissingResourceException;

import org.springframework.beans.factory.config.ConstructorArgumentValues;
import org.springframework.beans.factory.support.AbstractBeanDefinition;
import org.springframework.context.support.GenericApplicationContext;

import com.fundtech.core.security.Admin;
import com.fundtech.interceptors.InterceptorException;
import com.fundtech.interceptors.InterceptorInterface;
import com.fundtech.interceptors.impl.PerformanceInterceptor;
import com.fundtech.jndi.ServiceLocator;
import com.fundtech.mapping.AbstractConfigProxy;
import com.fundtech.spring.FndtSpringBeansFactory;
import com.fundtech.spring.config.DefaultBeanDefinitionConfigurer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.businessobject.BOInterface;
import backend.businessobject.proxies.interceptors.InterceptorSetType;


/**
 * Jan 29, 2008
 * BOProxy.java
 * @author guys
 * 
 * Decorator class & own factory responsible for the interception of All provided interfaces 
 * methods, their decorations and propogation to the internally stored BO delegate.
 * The following Decoartion tasks are supported: 
 * 
 * 1. Logging 
 * 2. User Authorization 
 * 3. User input validation.
 * 4. Error handling 
 * 5. NYI --> User Transactions 
 * 
 * The class provides its own set of factory methods, each constructing a proxy with a different set of 
 * InterceptorInterface instances. defined in the InterceptorSetType enum.
 * A separate default LoggingInterceptor interceptor instance is created and added to the interceptor's 
 * set at the first location.
 * Note: Interceptors are run in the order in which they are located in the provided set 
 * (for order please review the InterceptorSetType enum) 
 * 
 * The set of Proxy implemented interfaces is determined using the following logic: 
 * 
 * 1.	If a set of interface classes to implement formal args was provided, adds the BOInterface.class 
 *    	to the provided set (if not already present) and use it exclusively.
 * 2. 	If a set of interface classes to implement formal args was <b>not</b> provided, a default set 
 * 	  	Containing the following interfaces is used: 
 *		2.1.	BOInterface.class 
 *		2.2. 	XDcolet generated Local interface artifact constructed as follows: 
 *			    <bo package name whereby the businessobjects namespace is replaced with 'ejbinterfaces'>.
 *			    <BO class name cropped of its 'BO' leading prefix>Local
 *	  
 *	  	Note: This interface is also the returned type identified as <T> 
 * 
 * As an additional formal argument, all factory methods require the BO's .Class instance, 
 * which would be used to instantiate the proxy internal delegate.
 * 
 * Note: The com.fundtech.core.security.Admin class is a crutial part of the application flow and must 
 * be present in all Proxy's intercepted methods signatures as the first argument.
 * It is used for context tracing, and used authorization atifacts resource context injections.
 * 
 * It is not required however that the internal BO delegate share the restriction as this proxy provides 
 * the service of Admin instance removal from the formal args set, and the lookup and invocation of the BO 
 * delagate's corresponding method (without the admin instance).
 * In fact the Bo delegate MUST NOT publish the admin in its publically exposed methods.
 * 
 * The access to he admin in the BO and DAO tiers is achieved through the ThreadLocal machanism. 
 * It is the reponsibility of the LoggingInterceptor to configure the ThreadLocal context admin during the 
 * 'before' decoration 
 * 
 * Note: in actuality, the proxy will not fail a method invocation whose signature does not contain 
 * an admin class, it will retain the original formal argument set and will propogate it as-is 
 * to the bo delagate. An invocation of an interceptor's getAdmin() at any stage during the invoke() 
 * life cycle in a remote EJB call environment will however!!!
 * Use of the feature however would have to done with caution as the admin 
 * provide metadata required for trace and context tracer for gppshare classes. 
 * 
 * The proxy provides the following decorations to each method invocation: 
 * 
 * 1. 	Admin instance extraction from the formal arg set, and subsequent lookup of the internal BO delegate's 
 *    	method using the intercepted method name and the new formal args set without the admin. 
 * 2.   Invocation of the InterceptorInterface.before for all subscribed interceptors prior to the method invocation. 
 * 3.	Invocation of the BO delegate method.
 * 4.	Invocation of the InterceptorInterface.after for all subscribed interceptors prior to the method invocation.
 * 5.	In event of an InterceptorException, a replacement of the returned value with the new returned Value object 
 * 	    retrieved from the InterceptorException instance itself 
 * 6. 	In event of any other exception, error handling and invocation of all InterceptorInterface.afterThrowing
 * 		for all suubscribed interceptors.
 * 7. 	In the finally block an invocation of all InterceptorInterface.afterFinally for all suubscribed interceptors.
 * 
 * @param <T> returned proxy interface type 
 */
public class BOProxy <T> implements InvocationHandler { 

	private final static Logger logger = LoggerFactory.getLogger(BOProxy.class);
	 
	private static final String PROXY_CREATION_FAILURE_MSG = "Could not create proxy, returning actual instance." ; 
	private static final String BI_INTERFACE_NAME_REPLACEMENT_REGEX = "(.*\\.).*\\.BO(.*)$" ; 
	private static final String BI_INTERFACE_NAME_REPLACEMENT_TEMPALTE = "$1ejbinterfaces.$2Local" ; 
	public static final String PROXIES_CACHE = "PROXIES_CACHE_BEAN" ;  
	public static final String PROXY_UID_KEY = "PROXY.UID" ; 
		
	private Object m_instance ; 
	private Class<?> m_instanceType ; 
	private Map m_mapInitParams ; 
	
	private InterceptorInterface[] m_arrInterceptros ;
	private PerformanceInterceptor m_performanceInterceptor ; 
	private final Map<Object,Method> m_mapCachedMethods  ;
	
	// Key: BO class name, (e.g. BOServices).
	// Value - Integer holding how many times this BO class was accessed so far.
//	private static Map<String, Integer> m_hmBOCounter = new HashMap<String, Integer>();
	public static final <T> T getCachedProxy(final String sProxyUID, final InterceptorSetType interceporSet, Class<T> clssProxyInterface) throws Throwable{ 
		final Map<String, Object> mapProxiesCache = (Map<String, Object>) ServiceLocator.getInstance().getNsetSpringBean(BOProxy.PROXIES_CACHE, HashMap.class) ;
		
		Class<T> clsFinalBOInterface = clssProxyInterface ; 
		final String sInterfaceName = clssProxyInterface.getName(); 
		if(!sInterfaceName.startsWith("BO") && !sInterfaceName.endsWith("Local")) {
			try{ 
				clsFinalBOInterface = (Class<T>) Class.forName(sInterfaceName + "Local") ;
			}catch(Throwable t) {}//EO catch block 
		}//EO if not local interface 
				
		String sProxyKey = (sProxyUID == null ? "" : sProxyUID) + '^' + clsFinalBOInterface.getName() + '^' +  interceporSet.name();
		//System.out.println(mapProxiesCache.toString().replace(",", "\n"));
		final T oProxy = (T) mapProxiesCache.get(sProxyKey) ;
		if(oProxy == null) throw new MissingResourceException("[BOProxy.getCachedProxy()]: Could not find cached instance (might not have been defined in BOProxies using Logging Decoration)", clsFinalBOInterface.getName(), sProxyKey) ;
		return oProxy ;
	}//EOM 
			
	@SuppressWarnings("unchecked")
	public static final <T> T loggingDecoration(final Class<?> instanceClass) {
		return (T) wrap(instanceClass, InterceptorSetType.None,  null) ; 
	}//EOM
	
	public static final <T> T loggingDecoration(final Class<?> instanceClass, Class<T> primaryInterfaceToImplement) {
		return wrap(instanceClass, InterceptorSetType.None, primaryInterfaceToImplement) ; 
	}//EOM
	
	public static final <T> T loggingDecoration(final Class<?> instanceClass, Class<T> primaryInterfaceToImplement,Class<?>...arrAdditionalInterfacesToImplement) {
		return wrap(instanceClass,InterceptorSetType.None,null /*initParams*/,primaryInterfaceToImplement,arrAdditionalInterfacesToImplement) ; 
	}//EOM
	
	@SuppressWarnings("unchecked")
	public static final <T> T completeDecoration(final Class<?> instanceClass) {
		return (T) wrap(instanceClass, InterceptorSetType.Complete,  null)  ;
	}//EOM
	
	public static final <T> T completeDecoration(final Class<?> instanceClass, Class<T> primaryInterfaceToImplement) {
		return wrap(instanceClass, InterceptorSetType.Complete, primaryInterfaceToImplement)  ;
	}//EOM
		
	@SuppressWarnings("unchecked")
	public static final <T> T noDecoration(final Class<?> instanceClass) {
		return (T) wrap(instanceClass, InterceptorSetType.None, null) ; 
	}//EOM
	
	public static final <T> T noDecoration(final Class<?> instanceClass, Class<T> primaryInterfaceToImplement) {
		return wrap(instanceClass, InterceptorSetType.None, primaryInterfaceToImplement) ; 
	}//EOM

    @SuppressWarnings("unchecked")
	public static final <T> T pdoHandlingDecoration(final Class<?> instanceClass) {
        return (T) wrap(instanceClass, InterceptorSetType.PdoHandling,  null) ; 
    }//EOM
    
    public static final <T> T pdoHandlingDecoration(final Class<?> instanceClass, Class<T> primaryInterfaceToImplement) {
        return wrap(instanceClass, InterceptorSetType.PdoHandling, primaryInterfaceToImplement) ; 
    }//EOM
    
    public static final <T> T wrap(final Class<?> instanceClass, final InterceptorSetType interceporSet, 
    		Class<T> primaryInterfaceToImplement) {
    	return wrap(instanceClass, interceporSet, null /*initParams*/, primaryInterfaceToImplement) ; 
    }//EOM 
	
	public static final <T> T wrap(final Class<?> instanceClass, final InterceptorSetType interceporSet, 
			final Map mapInitParams, Class<T> primaryInterfaceToImplement, Class<?>...arrAdditionalInterfacesToImplement) {
		
		T returnValue = null ; 
		try{  
			
			//consutrct the list of interfaces to implement 
			final Class<?>[] arrPrimaryInterfaceToImplement = { primaryInterfaceToImplement } ; 
			final Class<?>[] arrFinalInterfaceSetToImplement = getInterfacesToImplement(instanceClass, arrPrimaryInterfaceToImplement, arrAdditionalInterfacesToImplement);
			
			//first attempt to lookup a cached instance of the proxy with the exact same characteristics in the proxies cache stored in spring
			
			//if a proxy uid was provided, use it as part of the key 
			String sProxyUID = (String) (mapInitParams == null ? "" : mapInitParams.get(PROXY_UID_KEY)) ;
			if(sProxyUID == null) sProxyUID = "" ; 

			final String sProxyKey = sProxyUID + '^' + instanceClass.getName() + '^' + System.identityHashCode(primaryInterfaceToImplement) + '^' +  interceporSet.name() ;
			
			final Map<String,T> mapCachedProxyMap = ServiceLocator.getInstance().getNsetSpringBean(PROXIES_CACHE, HashMap.class) ;
			returnValue = (T) mapCachedProxyMap.get(sProxyKey) ; 
			
			//if no such instance was yet created, create one now 
			if(returnValue == null) { 
			
				final BOProxy<T> invocationHandler = new BOProxy<T>(instanceClass, interceporSet) ;
				
				//add the bo interface to the list of interfaces as the actived passivate 
			    //and remove should not be a part of the business interface yet be exposed  
				//through the proxy 
				returnValue = (T) Proxy.newProxyInstance(
					Thread.currentThread().getContextClassLoader(), 
					arrFinalInterfaceSetToImplement,
					invocationHandler 						
					); 
				
				//prior to instantiating the instance's delegate, cache the proxy
				//this is required so as to prevent circular dependencies.  
				//by deferring the instantiation to after caching the proxy, 
				//it is ensured that even if circular dependency exists, 
				//it would be defered to the end of the dependency instantiation 
				//stack hierarchy.
				//cache twice, once with the BO class and once without (required for service proxy extraction) 
				mapCachedProxyMap.put((sProxyKey ), returnValue ) ;
				
				final String sProxyAlias = sProxyUID + '^' + arrPrimaryInterfaceToImplement[0].getName() + '^' +  interceporSet.name() ;
				mapCachedProxyMap.put(sProxyAlias, returnValue ) ;
				//instantiate the delegate 
				invocationHandler.instantiateDelegate(instanceClass, mapInitParams) ; 
				
			}//EO if not yet cached 
		}catch(Throwable t) { 
			//ExceptionController.getInstance().handleException(t, BOProxy.class.getName()) ;
			logger.error(PROXY_CREATION_FAILURE_MSG); 
			throw new java.lang.IllegalStateException(t) ; 
		}//EO catch block 
		
		return returnValue ; 
	}//EOM
	
	private static final Class<?>[] getInterfacesToImplement(final Class<?> instanceClass, 
				Class<?>[] arrPrimaryInterfaceToImplementHolder, Class<?>...arrAdditionalInterfacesToImplement) throws Exception{
		
		Class<?> primaryInterfaceToImplement =  arrPrimaryInterfaceToImplementHolder[0] ; 
		//as a rule, if there are no interfaces to implement were provided, assign the the ejbinterfaces.<className without the BO prefix>Local.class
		if(primaryInterfaceToImplement == null) { 
			
			primaryInterfaceToImplement =  
				Class.forName(
						instanceClass.getName().replaceAll(BI_INTERFACE_NAME_REPLACEMENT_REGEX, 
								BI_INTERFACE_NAME_REPLACEMENT_TEMPALTE)); 
			
			arrPrimaryInterfaceToImplementHolder[0] = primaryInterfaceToImplement ; 
		}//EO if the interface class 
	 
		//check if the list contains to bo interface and if not add the interface to it.
		//no further check is performed here 
		boolean bShouldAddBoInterface = true ; 
		for(Class<?> interfaceClass : arrAdditionalInterfacesToImplement) { 
			
			if(interfaceClass.isAssignableFrom(BOInterface.class)) { 
				bShouldAddBoInterface = false ; 
				break ; 
			}//EO if there bo interface or its subclass was found
			
		}//EO while there are more interfaces to iterate over 
		
		//finally manually check whether the primaryInterfaceToImplement is assignable from the bointerface 
		if(primaryInterfaceToImplement.isAssignableFrom(BOInterface.class)) bShouldAddBoInterface = false ; 
		
		final int iNoOfEnrichedInterfaces = (bShouldAddBoInterface ? 2 : 1) ; 
		
		int iOriginalLength = arrAdditionalInterfacesToImplement.length ; 
		Class[] arrTemp = new Class[iOriginalLength + iNoOfEnrichedInterfaces] ; 
		System.arraycopy(arrAdditionalInterfacesToImplement, 0, arrTemp, 0, iOriginalLength) ; 
		
		//add the primaryInterfaceToImplement to the array and if there no bointerface class included in the array 
		//or assignable from one of the interfaces (including the primary one)
		arrTemp[iOriginalLength] = primaryInterfaceToImplement ; 
		if(bShouldAddBoInterface) arrTemp[iOriginalLength+1] = BOInterface.class ;
		
		arrAdditionalInterfacesToImplement = arrTemp ; 
	 
		return arrAdditionalInterfacesToImplement ; 
	}//EOM 
					
	public BOProxy(final Class<?> contractInterface, final InterceptorSetType interceporSet) throws Throwable { 
		
		//add an implicit PerformanceInterceptor to the set
		this.m_performanceInterceptor =  new PerformanceInterceptor(AbstractConfigProxy.getInstance()) ; 
				
		this.m_mapCachedMethods = new HashMap<Object,Method>() ;  
		
		//add the individual logging interceptor to the first index of the array 
		final int iOriginalLength = interceporSet.getInterceptorSet().length  ;
		this.m_arrInterceptros = new InterceptorInterface[iOriginalLength+1] ; 
		this.m_arrInterceptros[0] = this.m_performanceInterceptor ; 
		System.arraycopy(interceporSet.getInterceptorSet(), 0, m_arrInterceptros, 1, iOriginalLength) ;
		
		 
	}//EOM 


	private final void instantiateDelegate(final Class<?> contractInterface, final Map mapInitParams) throws Throwable { 

		
		final DefaultBeanDefinitionConfigurer formalArgumentBeanDefinition = new DefaultBeanDefinitionConfigurer() { 
			
		    @Override
		    public AbstractBeanDefinition configureBean(final AbstractBeanDefinition rawBeanDefintition,
		    		final GenericApplicationContext appContext) throws Exception {
		    	
		    	try{ 
					//determine whether the class has a map constructor and if so, invoke that constructor 
					contractInterface.getDeclaredConstructor(Map.class) ;
					
					final ConstructorArgumentValues constArgs = new ConstructorArgumentValues() ; 
					constArgs.addGenericArgumentValue(mapInitParams) ; 
					rawBeanDefintition.setConstructorArgumentValues(constArgs) ;
					
				}catch(Exception e) {
				}//EO catch block 
				
				super.configureBean(rawBeanDefintition, appContext) ; 
				return rawBeanDefintition ; 
		    }//EOM 
			
		};  
		
		
		//if a proxy uid was provided, use it as part of the bean's key 
		String sProxyUID = (String) (mapInitParams == null ? "" : mapInitParams.get("PROXY.UID")) ;
		if(sProxyUID == null) sProxyUID = "" ; 
		sProxyUID = sProxyUID + '^' + contractInterface.getName() ; 
		
		this.m_instance = 
			ServiceLocator.getInstance().getNsetSpringBean(sProxyUID, 
					contractInterface, FndtSpringBeansFactory.DEFAULT_APP_CONTEXT, 
					formalArgumentBeanDefinition) ; 
		
		//if the instance is null then there is in most probability a cyclic referencing during the initialization of the bean 
		//therefore, cache the init params and defer the initialization process to a later stage (lazy) 
		if(this.m_instance == null) { 
			this.m_instanceType = contractInterface ; 
			this.m_mapInitParams = mapInitParams ; 
		}//EO if there was a problem initializing the bo bean instance 
	}//EOM
	
	public Object invoke(Object proxy, Method method, Object[] formalArgs) throws Throwable {
		
		Object retValue = null ; 
		Object[] boFormalArgs = null ; 
		Class[] boArgTypes = null ;  
		Method boMethod = null ; 
		
		try{ 
			//if the delegate instance was not yet initialized do so now 
			if(this.m_instance == null) this.instantiateDelegate(this.m_instanceType, this.m_mapInitParams) ; 
			
			//use the interface's method metadata to locate the bo's method 
			//by first removing the first argument, that is the admin
			//then invoke the bo's method instead
			final Class[] interfaceArgTypes = method.getParameterTypes() ;
			
			if(formalArgs ==  null || (formalArgs.length > 0 && interfaceArgTypes[0] != Admin.class) ) { 
				boFormalArgs = formalArgs ; 
				boArgTypes = interfaceArgTypes ; 
			}else{ 
				boFormalArgs = new Object[formalArgs.length-1] ; 
				boArgTypes =  new Class[interfaceArgTypes.length-1] ;
				
				System.arraycopy(formalArgs, 1, boFormalArgs, 0, boFormalArgs.length) ;
				System.arraycopy(interfaceArgTypes, 1, boArgTypes, 0, boArgTypes.length) ;
				
				//as the admin was removed from the formal args, and 
				//remote ejb invocation will not propogate the threadlocal data 
				//store the admin in the thread local context 
				Admin.setContextAdmin((Admin) formalArgs[0]) ; 
			}//else if the first parameter was admin 
			
			//first search for the method in the methods cache and if not found, retrieve
			final String sMethodId = method.toString() ; 
			boMethod = this.m_mapCachedMethods.get(sMethodId) ;
			if(boMethod == null) { 
				boMethod = this.m_instance.getClass().getMethod(method.getName(), boArgTypes) ; 
				this.m_mapCachedMethods.put(sMethodId, boMethod) ; 
			}//EO if the method was not yet cached 
			
			//updateBOCounterMap(m_instance.getClass().toString());
		
			for(InterceptorInterface interceptor : this.m_arrInterceptros) { 
				interceptor.before(this.m_instance, boMethod, boFormalArgs) ; 
			}//EO while there are more interceptros 
			
			retValue = boMethod.invoke(this.m_instance, boFormalArgs) ;
			
			for(InterceptorInterface interceptor : this.m_arrInterceptros) { 
				interceptor.after(this.m_instance, boMethod, boFormalArgs) ; 
			}//EO while there are more interceptros 
			
		}catch(InterceptorException interceptionException) { 
			//NYI --> log the interception exception here 
			//return the interceptionException.returnValue if the return 
			//type is the same as it 
			logger.error(interceptionException.getMessage()); 
			
			final Object interceptorResponse = interceptionException.getReturnValue() ; 
			
			if(interceptorResponse != null && method.getReturnType().isAssignableFrom(interceptorResponse.getClass())) {
				retValue = interceptorResponse ; 
			}//EO if the interceptor's return value was the same as the method's return value 
			
		}catch(Throwable  throwable) { 
						
			for(InterceptorInterface interceptor : this.m_arrInterceptros) { 
				interceptor.afterThrowing(this.m_instance, boMethod, throwable, boFormalArgs) ;
			}//EO while there are more interceptros 
			
			//NOTE: should it rethrow the exception instead? 
			throw throwable.getCause() == null ? throwable : throwable.getCause() ; 	
		}finally{
			for(InterceptorInterface interceptor : this.m_arrInterceptros) { 
				interceptor.afterFinally(this.m_instance, boMethod, boFormalArgs) ;
			}//EO while there are more interceptros 

		}//EO catch block
		
		return retValue ;
	}//EOM
	
//	private static void updateBOCounterMap(String sProxyInstanceClassString)
//	{
//	  int iDotIndex = sProxyInstanceClassString.lastIndexOf(ServerConstants.DOT);
//      int iAtIndex = sProxyInstanceClassString.lastIndexOf(ServerConstants.AT_SIGN);
//      String sBOClassName = iAtIndex != -1 ? sProxyInstanceClassString.substring(iDotIndex+1, iAtIndex) : 
//                                             sProxyInstanceClassString.substring(iDotIndex+1);
//      
//      Integer intCounter = m_hmBOCounter.get(sBOClassName);
//      
//      if(intCounter == null)
//      {
//        m_hmBOCounter.put(sBOClassName, Integer.valueOf(1));
//      }
//      else
//      {
//        int iOldCounter = intCounter.intValue();
//        m_hmBOCounter.put(sBOClassName, Integer.valueOf(++iOldCounter));
//      }
//      
//      //printBOCountersMap();
//	}
//	
//	private static void printBOCountersMap()
//	{
//	  final String TRACE_PREFIX = "BO Classes Counter Data:";
//	  final String TRACE_PART_1 = "\n                                               BO class name: ";
//	  final String TRACE_PART_2 = ", Accessed so far: ";
//	  
//	  StringBuilder sbCounters = new StringBuilder(TRACE_PREFIX);
//	  
//	  Iterator<String> iterKeys = m_hmBOCounter.keySet().iterator();
//	  while(iterKeys.hasNext())
//	  {
//	    String sBOClassName = iterKeys.next();
//	    int iBOCount = m_hmBOCounter.get(sBOClassName);
//	    
//	    sbCounters.append(TRACE_PART_1).append(sBOClassName).append(TRACE_PART_2).append(iBOCount);
//	  }
//	  
//	  logger.info(sbCounters.toString());
//	}
	
	@Override
	public final String toString() { return "BOProxy[" + this.m_instance.toString() + ']' ; }//EOM
	
}//EOC
