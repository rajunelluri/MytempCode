package backend.businessobject.proxies ; 

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import backend.util.ServerConstants;
import com.fundtech.lang.BrowserDataType;

/**
 * 
 * Feb 3, 2008
 * Input.java
 * @author guys
 *
 * Runtime formal argument level annotation providing the {@link InputValidationInterceptor} 
 * an additional metadata on a given parameter such as its fully qualified name, explicity data 
 * type and whether its validation should be skipped entirely.
 *
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.PARAMETER)
public @interface Input {
   		
	/**
	 * 
	 * Feb 3, 2008
	 * guys
	 *
	 * @return Fully qualified name in the format of <tablename>.<parametername> 
	 * used by the {@link InputValidationInterceptor} for data type inferring.
	 */
	String name() default ServerConstants.EMPTY_STRING ; 
	/**
	 * 
	 * Feb 3, 2008
	 * guys
	 *
	 * @return explicit datatype represented by a BrowserDataType instance. 
	 */
	BrowserDataType type() default BrowserDataType.VARCHAR ; 
	/**
	 * 
	 * Feb 3, 2008
	 * guys
	 *
	 * @return true if the parameter validation is not required and false 
	 * if is it.
	 */
	boolean skip() default  false  ;
	
}//EOA
