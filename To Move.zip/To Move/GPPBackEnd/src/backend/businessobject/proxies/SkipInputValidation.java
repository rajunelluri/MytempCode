package backend.businessobject.proxies ; 

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import backend.businessobject.proxies.interceptors.impl.InputValidationInterceptor;

/**
 * 
 * Feb 3, 2008
 * SkipInputValidation.java
 * @author guys
 *
 * Runtime method level flag annotation providing an indication to the {@link InputValidationInterceptor} 
 * whethe to perform validation or skip the given method. 
 *
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface SkipInputValidation {
}//EOA
