package backend.businessobject.proxies ;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import backend.businessobject.proxies.interceptors.impl.AuthorizeUserInterceptor;

/**
 * Jan 31, 2008
 * AuthorizeUser.java
 * @author guys
 *
 * Runtime method level annotation used by the {@link AuthorizeUserInterceptor} as an indication 
 * Whether to perform user authorization prior to invoking the actual BO method.
 * 
 * An additional metadata property returnWebSessionInfo is provided to indicate whether to 
 * the WebSessionInfo Hashmap returned from the isUserAuthorized method should be 
 * stored in the context admin and made available for subsequent client use.
 *
 */
@Retention(RetentionPolicy.RUNTIME) 
@Target(ElementType.METHOD)
public @interface LoadPDO {
}//EO Annotation
