package backend.businessobject.proxies.interceptors.impl;

import java.lang.reflect.Method;

import backend.businessobject.proxies.LoadPDO;

import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.core.security.Admin;
import com.fundtech.interceptors.InterceptorException;
import com.fundtech.interceptors.impl.InterceptorAdapter;


public class LoadPDOInterceptor extends InterceptorAdapter{

	

	@Override
	public Object before(Object instance, Method method, Object... formalArgs)
									throws IllegalAccessException, InterceptorException{ 
		if(!this.isRequired(instance, method)) return null ; 
		
		//add any merge data stored in the session scope 
		final Object oMergeData = Admin.getContextAdmin().getSessionData(Admin.CONTEXT_INPUT, true) ; 
		PaymentDataFactory.load((String)formalArgs[0], oMergeData);

		return null ;  
	}//EOM
	
	@Override
	protected final boolean isRequiredInner(Object instance, Method method, Object... formalArgs) {
		return (super.isRequiredInner(instance, method, formalArgs) && 
				method.getAnnotation(LoadPDO.class) != null
			   ) ; 
	}//EOM
}//EOC
