package backend.businessobject.proxies.interceptors ;

import com.fundtech.interceptors.InterceptorInterface;

import backend.businessobject.proxies.interceptors.impl.AuthorizeUserInterceptor;
import backend.businessobject.proxies.interceptors.impl.InputValidationInterceptor;
import backend.businessobject.proxies.interceptors.impl.LoadPDOInterceptor;

/**
 * Feb 3, 2008
 * InterceptorSetType.java
 * @author guys
 *
 * Preconfigured Interceptors sets enumeration.
 *
 */
public enum InterceptorSetType {

	None(),  
	Complete(new InputValidationInterceptor(), new AuthorizeUserInterceptor()),
	PdoHandling(new LoadPDOInterceptor());  
	
	private InterceptorInterface[] m_arrInterceptors ;
	
	private InterceptorSetType(InterceptorInterface...arrInterceptors) { 
		this.m_arrInterceptors = arrInterceptors ;  
	}//EOM
	
	public InterceptorInterface[] getInterceptorSet() { 
		return this.m_arrInterceptors ;
	}//EOM
	
}//EOM
