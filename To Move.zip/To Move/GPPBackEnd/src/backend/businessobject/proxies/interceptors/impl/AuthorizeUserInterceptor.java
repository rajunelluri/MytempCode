package backend.businessobject.proxies.interceptors.impl;

import java.lang.reflect.Method;

import com.fundtech.cache.entities.WebSessionInfo;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.datacomponent.response.SimpleResponseDataComponent;
import com.fundtech.interceptors.InterceptorException;
import com.fundtech.interceptors.impl.InterceptorAdapter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.businessobject.proxies.AuthorizeUser;
import backend.businessobject.proxies.interceptors.InterceptorSetType;
import backend.core.module.BOCoreServices;

/**
 * 
 * Jan 29, 2008
 * AuthorizeUserInterceptor.java
 * @author guys
 * 
 * BO method interceptor tasked with User Authorisation and participates in the BOProxy decoration mechanism.
 * 
 * The class relies heavily on the {@link AuthorizeUser} method level annotation to determine whether 
 * to perform the authorisation of not.
 * 
 * The {@link AuthorizeUser} class contains a single optional member returnWebSessionInfo which if set to 
 * true will cause the operation to instill a map containing the WebsessionInfo content returned from the 
 * Authorize user in the ThreadLocal context admin. 
 *  
 * Note: Currently, there is only a single instance of this class (though the creation of more is not it restricted) 
 * which resides in the {@link InterceptorSetType}.
 * 
 * Note: The before() of this class must not be invoked prior to the LoggingInterceptor's one as the 
 * context admin would not be configured.
 */
public class AuthorizeUserInterceptor extends InterceptorAdapter{

	private final static Logger logger = LoggerFactory.getLogger(AuthorizeUserInterceptor.class);

	private static final String AUTHORIZATION_FAILURE = "User Authorization had failed with message: " ;
	private static final String NO_ADMIN_INSTANCE_FOUND_MSG = "Method must contain an admin instance as one of its formal arguments for the authorize user to operate." ; 
	
	private BOCoreServices m_AuthorizationHandler ; 
	
	public AuthorizeUserInterceptor() {}//EOM 
	
	/**
	 * Jan 29, 2008
	 * guys
	 * 
	 * Guranteed to be invoked prior to the delegate method invocation. 
	 * 
	 * Note: Will abort if the {@link AuthorizeUserInterceptor#isRequired(Object, Method, Object...)} returns false.
	 * 
	 * @param instance Delegate (not proxy) instance
	 * @param method Delegate (not Proxy) method (might be static) 
	 * @param formalArgs A list of all formal args provided by a given client exclusive of an Admin instance.
	 * @return null
	 * @throws IllegalAccessException
	 * @throws InterceptorException if the user was not authorized. Constructs an error Response 
	 * and sets it in the exception
	 */
	@Override
	public Object before(Object instance, Method method, Object... formalArgs)
									throws IllegalAccessException, InterceptorException{ 
		if(!this.isRequired(instance, method)) return null ; 
		
		 
		
		//use the bo object for the authorization procedure 
		final boolean bShouldReturnWebSessionInfoMap =  method.getAnnotation(AuthorizeUser.class).returnWebSessionInfo() ; 
		final Feedback feedback = new Feedback() ; 
		
		boolean bIsAuthorized = false ; 
		
		final Admin admin = this.getAdmin(formalArgs) ;
		 
		if(admin == null) this.generateFailure(null, NO_ADMIN_INSTANCE_FOUND_MSG, feedback) ; 
		
		if(this.m_AuthorizationHandler == null) this.m_AuthorizationHandler = new BOCoreServices() ;

		if(bShouldReturnWebSessionInfoMap) {
					
			final WebSessionInfo webSessionInfo = this.m_AuthorizationHandler.performUserAuthoization(feedback) ; 
			
			if(webSessionInfo != null) { 
				admin.setWebSessionInfo(webSessionInfo) ;
				bIsAuthorized = true ; 
			}//EO if the user session was located 
		}else  {
			bIsAuthorized = this.m_AuthorizationHandler.isUserAuthorized(feedback) ;
		}//EO else if the bShouldReturnWebSessionInfoMap was false 
		
		if(!bIsAuthorized) 
			this.generateFailure(admin.getSessionID(), AUTHORIZATION_FAILURE, feedback) ;
					
		 
		
		return null ;  
	}//EOM
	
	/**
	 * Jan 29, 2008
	 * guys
	 * 
	 * Constructs an error response, sets it in a new InterceptorException and throws it
	 *  
	 * @param sSessionID
	 * @param sErrorMessage
	 * @param feedback
	 * @param boCoreServices
	 * @throws InterceptorException
	 */
	private final void generateFailure(final String sSessionID, String sErrorMessage, 
					final Feedback feedback) throws InterceptorException { 
		
		final boolean bShouldConfigureFeedback = (feedback == null) ;
		
		if(!bShouldConfigureFeedback) sErrorMessage = sErrorMessage + feedback.getErrorText() ; 
		
		final SimpleResponseDataComponent returnValue = 
			this.m_AuthorizationHandler.configureErrorResponse(sErrorMessage,
					feedback, bShouldConfigureFeedback) ; 
		
		throw new InterceptorException((AUTHORIZATION_FAILURE + sErrorMessage), returnValue) ;
	}//EOM 
	
	/**
	 * Jan 29, 2008
	 * guys
	 *
	 * @param instance Delegate (not proxy) instance
	 * @param method Delegate (not Proxy) method (might be static)
	 * @param formalArgs A list of all formal args provided by a given client exclusive of an Admin instance.
	 * 
	 * @return true IFF the formal args are not null and the method name is not 'businessObjectRemove'
	 * (This check is required for methods using the context Admin which will not be present 
	 * during the EJB remove invocation of the method at an application shutdown only),  and
	 * the AuthorizeUser method level annotation exists  
	 */
	@Override
	protected final boolean isRequiredInner(Object instance, Method method, Object... formalArgs) {
		return (super.isRequiredInner(instance, method, formalArgs) && 
				method.getAnnotation(AuthorizeUser.class) != null
			   ) ; 
	}//EOM
}//EOC
