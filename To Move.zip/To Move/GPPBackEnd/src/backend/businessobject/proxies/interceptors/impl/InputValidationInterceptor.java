package backend.businessobject.proxies.interceptors.impl;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.HashMap;

import com.fundtech.core.paymentprocess.data.paymenttypes.PaymentType;
import com.fundtech.datacomponent.request.FieldsContainer;
import com.fundtech.interceptors.InterceptorException;
import com.fundtech.interceptors.impl.InterceptorAdapter;
import com.fundtech.lang.BrowserDataType;
import com.fundtech.util.GlobalUtils;
import com.fundtech.util.InputValidatorContainerInterface;
import com.fundtech.util.UserInputValidatorInterface;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.businessobject.proxies.Input;
import backend.businessobject.proxies.SkipInputValidation;
import backend.businessobject.proxies.interceptors.InterceptorSetType;
import backend.util.UserInputValidator;

/**
 * 
 * Jan 29, 2008
 * InputValidationInterceptor.java
 * @author guys
 * 
 * BO method interceptor tasked with User Input Valdation and participates in the BOProxy decoration mechanism.
 * 
 * The class relies heavily on the {@link SkipInputValidation} method level marker annotation to determine whether 
 * to perform the validation or not as well as the {@link Input} parameter level annotation to determine whether 
 * to validate a given formal argument and for additional paramter metadata such as qualified name and data type.
 * 
 * Note: Currently, there is only a single instance of this class (though the creation of more is not it restricted) 
 * which resides in the {@link InterceptorSetType}.
 * 
 * Note: The before() of this class must not be invoked prior to the LoggingInterceptor's one as the 
 * context admin would not be configured.
 */
public class InputValidationInterceptor extends InterceptorAdapter{

	private final static Logger logger = LoggerFactory.getLogger(InputValidationInterceptor.class);

	protected static final UserInputValidatorInterface m_inputValidator =  UserInputValidator.getInstance() ;
		
	/**
	 * Jan 29, 2008
	 * guys
	 * 
	 * Guranteed to be invoked prior to the delegate method invocation. 
	 * 
	 * Iterates over all formal arguments and for each validate each paramter using the following logic: 
	 * 1. If the Arg is null or of a boolean type do no validation 
	 * 2. If the parameter has an input annotation, whose skip is true do no validation 
	 * 3. Use the Input's provided data type and qualified name (both optional) to validate the 
	 * 	  paramter. if none exist, use the following logic: 
	 * 		3.1.	validate in accordance with the instance type of the parameter and if no dedicated 
	 * 				method for instance type validating was found, treat the parameter as an unqualified 
	 * 				string.
	 * 
	 *  Note: Will abort if the {@link InputValidationInterceptor#isRequired(Object, Method, Object...)} returns false.
	 *  
	 * @param instance Delegate (not proxy) instance
	 * @param method Delegate (not Proxy) method (might be static) 
	 * @param formalArgs A list of all formal args provided by a given client exclusive of an Admin instance.
	 * @return null
	 * @throws IllegalAccessException
	 * @throws InterceptorException 
	 */
	@Override
	public Object before(Object instance, Method method, Object... formalArgs) {
		if(!this.isRequired(instance, method, formalArgs)) return null ;
		
		 
				
		final Annotation[][] annotations = method.getParameterAnnotations();
		
		final int iLegnth = formalArgs.length ;
		
		Object formalArg= null ; 
		String sFieldName = null ; 
		BrowserDataType enumDataType = null; 
		
		for(int i=0; i < iLegnth; i++) {  
			
			formalArg = formalArgs[i] ; 
			 
			if(formalArg == null || formalArg instanceof Boolean|| formalArg instanceof Enum || formalArg instanceof PaymentType) continue ;  
			 
			//if there is no input annotation continue with the validation and defualt 
			//to VARCHAR datatype 
			if((annotations[i].length == 0 || !(annotations[i][0] instanceof Input)) ){ 
				enumDataType = BrowserDataType.VARCHAR ; 
			}else { 
				
				final Input input = (Input) annotations[i][0] ; 
				
				if(input.skip()) continue ;
				
				enumDataType  = input.type() ; 
				sFieldName = input.name() ;
			}//EO else if the input attribute was present 
				
			switch(enumDataType) { 

				case NUMBER: { 
					formalArgs[i] = m_inputValidator.formatUnqualifiedNumericInput(formalArg.toString()) ;  
				}break;
				
				case CONTAINER : { 
					((InputValidatorContainerInterface)formalArg).formatUserInput(m_inputValidator) ;
				}break;
				
				case VARCHAR : //filter through
				default: { 
				
					if(formalArg instanceof InputValidatorContainerInterface) { 
						((InputValidatorContainerInterface)formalArg).formatUserInput(m_inputValidator) ;
					}else if(formalArg instanceof FieldsContainer) { 
						m_inputValidator.formatUserInput(((FieldsContainer)formalArg)) ;
					}else if(formalArg instanceof HashMap) { 
						m_inputValidator.formatUserInput(((HashMap)formalArg)) ;
					}else if(formalArg instanceof Object[]) { 
						m_inputValidator.formatUserInput((Object[])formalArg) ; 
					}else {
						if(GlobalUtils.isNullOrEmpty(sFieldName)){ 				
							formalArgs[i] = 
								m_inputValidator.formatUnqualifiedStringInput(formalArg.toString()) ;
						}else {
							formalArgs[i] = m_inputValidator.formatUserInput(formalArg.toString(), sFieldName) ;
						}//EO else if the name was specified 
						
					}//EO else if the parameter was not an a self validating container
				}break; 
			
			}//EO switch 
			
		}//EO while there are more arguments to validate
				
		 
		return null ;
	}///EOM
		 
	/**
	 * Jan 29, 2008
	 * guys
	 *
	 * @param instance Delegate (not proxy) instance
	 * @param method Delegate (not Proxy) method (might be static)
	 * @param formalArgs A list of all formal args provided by a given client exclusive of an Admin instance.
	 * 
	 * @return true IFF the formal args are not null and the method name is not 'businessObjectRemove'
	 * (This check is required for methods using the context Admin which will not be present 
	 * during the EJB remove invocation of the method at an application shutdown only),  and
	 * the SkipInputValidation method level annotation does not exist  
	 */
	@Override
	protected final boolean isRequiredInner(Object instance, Method method, Object... formalArgs) {		
		return (super.isRequiredInner(instance, method, formalArgs) && 
				(formalArgs != null && method.getAnnotation(SkipInputValidation.class) == null) 
				); 
	}//EOM
	
}//EOM
