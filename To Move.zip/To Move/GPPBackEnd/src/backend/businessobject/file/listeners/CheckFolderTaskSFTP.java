package backend.businessobject.file.listeners;

import java.io.File;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.cache.entities.InterfaceTypes;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.util.SFTPUtils;

public class CheckFolderTaskSFTP extends CheckFolderTask
{
	private static final Logger logger = LoggerFactory.getLogger(CheckFolderTaskSFTP.class);
	final SFTPUtils sftputils=new SFTPUtils();
	public CheckFolderTaskSFTP(InterfaceTypes anInterfaceType)
	{
		super(anInterfaceType);
	}

	@Override
	protected File[] getFileList(InterfaceTypes it,Feedback feedback)
	{
//		
//		sftputils.receive("SFTPtest","",false,feedback);;
//		sftputils.runScript("SFTPtestOUT", "testscript2.sh","", feedback);;
//		sftputils.runScript("SFTPtestOUT", "/home/dbsftp/YoniG/testscript.sh","", feedback);
//		  InputStream in = IOUtils.toInputStream("testing 1 2");
////	      sftputils.send("SFTPtest","C:\\fromSFTP/test2.txt",in,"",feedback);
//	      sftputils.send("SFTPtest","C:\\fromSFTP/test2.txt",null,"",feedback);
//		  InputStream in = IOUtils.toInputStream("testing 1 2");
//	      sftputils.zipFiles(new String[]{"D:/temp/DAO_BOCReference.java","D:/temp/BOC_AccountLookup_toGPP_ex1.xml","D:/temp/33900_TraceFileID_1330695457B50234.txt"}, 
//	    		  in, "testentry", "C:/fromSFTP/ziptest.zip", false, feedback);
	      //sftputils.send("SFTPtestOUT","",null,"",feedback);
		List<String> localFileList=sftputils.receive(it,"",false,feedback);
		if (!feedback.isSuccessful())
		{
			return new File[0];
		}
		File[] files=new File[localFileList.size()];
		int i=0;
		for (String localFileName:localFileList) 
		{
			files[i++]=new File(localFileName);
		}
		return files;
	}

}