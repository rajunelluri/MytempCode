package backend.businessobject.file.listeners;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;


import com.fundtech.cache.entities.InterfaceTypes;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.util.GlobalConstants;

public class FileListenersLauncher implements ApplicationListener {

	private static final Logger logger = LoggerFactory.getLogger(FileListenersLauncher.class);
	private Map<String,FileListener> mapFileListener=new HashMap<String,FileListener>();

	@Override
	public void onApplicationEvent(ApplicationEvent arg0) {
		logger.info("Initializing FILE/SFTP listeners");

		try 
		{
			Iterator<InterfaceTypes> interfaces=CacheKeys.interfaceTypesKey.getByDirectionAndType("I",InterfaceTypes.PROTOCOL_FILE,InterfaceTypes.PROTOCOL_SFTP);
			while (interfaces.hasNext())
			{
				InterfaceTypes it=interfaces.next();
				int iNoOfThreads = it.getNoOfListeners() != null ? it.getNoOfListeners() : 0;
				String strFileListenerKey=it.getOffice()+GlobalConstants.POWER_SIGN+it.getInterfaceName();
				FileListener fl=mapFileListener.get(strFileListenerKey);
				if (null!=fl)
				{
					fl.stopListener();
					mapFileListener.remove(strFileListenerKey);
				}
				if (0==iNoOfThreads) // || InterfaceTypes.STATUS_NOT_ACTIVE.equals(it.getInterfaceStatus()))
				{
					//A listener is not needed
					logger.info("Skipping FileListener for NAME={},OFFICE={},REQUEST_PROTOCOL={},NO_OF_LISTENERS={},STATUS={}",new Object[]{it.getInterfaceName(),it.getOffice(),it.getRequestProtocol(),it.getNoOfListeners(),it.getInterfaceStatus()});
				}
				else
				{
					int iPoolIntervalMinutes=1;
					if (null!=it.get("POLL_INTERVAL"))
					{
						iPoolIntervalMinutes=Integer.parseInt(it.get("POLL_INTERVAL").toString());
					}
					else if (null!=it.get("INTERVAL")) 
					{
						iPoolIntervalMinutes=Integer.parseInt(it.get("INTERVAL").toString());
					}
					logger.info("Creating FileListener NAME={},OFFICE={},REQUEST_PROTOCOL={} with {} threads (direction={},iPoolIntervalMinutes={})",new Object[]{it.getInterfaceName(),it.getOffice(),it.getRequestProtocol(),iNoOfThreads,it.getRequestDirection(),iPoolIntervalMinutes});
					fl=new FileListener(1,iPoolIntervalMinutes,iNoOfThreads,it);
					mapFileListener.put(strFileListenerKey,fl);
					fl.activateListener();
				}
			}
		} 
		catch (Throwable t) 
		{
			logger.error("Error during FileListenersLauncher.onApplicationEvent", t);
		}

	}
}
