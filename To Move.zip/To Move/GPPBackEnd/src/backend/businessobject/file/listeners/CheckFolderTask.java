package backend.businessobject.file.listeners;

import java.io.File;
import java.io.FilenameFilter;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.paymentprocess.interfaces.dao.DAOInterfaces;
import backend.staticdata.profilehandler.DAOBasicProfileHandler;

import com.fundtech.cache.entities.InterfaceTypes;
import com.fundtech.cache.infrastructure.CacheServiceInterface;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.cache.infrastructure.regions.CacheKeys.ProcessSessionsKey;
import com.fundtech.core.security.Admin;
import com.fundtech.core.security.Admin.CallSource;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.interfaces.handlers.InterfaceTypeInHandler;
import com.fundtech.util.BeanIOUtils;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalFileUtil;
import com.fundtech.util.GlobalUtils;
import com.fundtech.util.SFTPUtils;



public class CheckFolderTask implements Runnable
{
	private static final Logger logger = LoggerFactory.getLogger(CheckFolderTask.class);
	private static final DAOBasicProfileHandler errorLog = new DAOBasicProfileHandler();
	
	private final InterfaceTypes interfaceType;
	private String archiveFolder;
	private final String incomingFolder;
	private String[] fileExt;
	private String[] controlFileExt;
	private String sFilePattern;
	private int iTimeWindowStartHour=0; 
	private int iTimeWindowStartMin=0; 
	private int iTimeWindowEndHour=24; 
	private int iTimeWindowEndMin=0;
	private long iRETENTION_DAYS;

	private final Lock lock;
	private final boolean PROCESS_ONE_FILE_PER_TRANSACTION=true;
	/**
	 * 
	 * @param anInterfaceType - interface type that listener uses
	 */
	@SuppressWarnings("unchecked")
	public CheckFolderTask(InterfaceTypes anInterfaceType) {
		this.interfaceType=anInterfaceType;
		this.archiveFolder=SFTPUtils.enrichArchiveFolder(interfaceType,InterfaceTypes.REQUEST_CONNECTIONS_POINT);
		this.incomingFolder = SFTPUtils.fixPath(interfaceType.getRequestConnectionsPoint(),false);	
		this.fileExt=SFTPUtils.getExts(SFTPUtils.getPropertyValue(interfaceType,"FILE_EXTENSION"));
		if (0==this.fileExt.length)
		{
			this.fileExt=SFTPUtils.getExts(SFTPUtils.getPropertyValue(interfaceType,"FILE_EXT"));
		}
		this.controlFileExt=SFTPUtils.getExts(SFTPUtils.getPropertyValue(interfaceType,"CONTROL_FILE_EXT"));
		this.sFilePattern=SFTPUtils.getPropertyValue(interfaceType,"FILE_PATTERN");
		String str=SFTPUtils.getPropertyValue(interfaceType,"TIME_WINDOW_START");
		if (!GlobalUtils.isNullOrEmpty(str))
		{
			this.iTimeWindowStartHour=Integer.parseInt(str.substring(0,2));
			this.iTimeWindowStartMin=Integer.parseInt(str.substring(3,5));
		}
		str=SFTPUtils.getPropertyValue(interfaceType,"TIME_WINDOW_END");
		if (!GlobalUtils.isNullOrEmpty(str))
		{
			this.iTimeWindowEndHour=Integer.parseInt(str.substring(0,2));
			this.iTimeWindowEndMin=Integer.parseInt(str.substring(3,5));
		}
		String sRETENTION_DAYS=SFTPUtils.getPropertyValue(interfaceType,"RETENTION_DAYS");
		iRETENTION_DAYS=0;
		if (!GlobalUtils.isNullOrEmpty(sRETENTION_DAYS))
		{
			iRETENTION_DAYS=Long.parseLong(sRETENTION_DAYS);
		}
		logger.debug("INTERFACE_NAME={}, RequestConnectionsPoint={},CONTROL_FILE_EXT={},FILE_PATTERN={},ARCHIVE_FOLDER={}, FILE_EXTENSION={},TIME_WINDOW_START={}:{},TIME_WINDOW_END={}:{},RETENTION_DAYS={}", 
				new Object[] {anInterfaceType.getInterfaceName(), incomingFolder,controlFileExt,sFilePattern,archiveFolder, fileExt,iTimeWindowStartHour,iTimeWindowStartMin,iTimeWindowEndHour,iTimeWindowEndMin,iRETENTION_DAYS});
		lock = new ReentrantLock();
	}
	
	/**
	 * 
	 * @param fileToProcess
	 * @return Feedback Success - decoding was successful. Failure - decoding file failed.
	 */
	@SuppressWarnings("unchecked")
	public static Feedback decodeFile(InterfaceTypes it,File fileToProcess)
	{
		Feedback feedback=new Feedback(); 
		String decoderClass=SFTPUtils.getPropertyValue(it,"DECODER_CLASS");
		if(!GlobalUtils.isNullOrEmpty(decoderClass))
		{
			String decoderKeyFile=SFTPUtils.getPropertyValue(it,"DECODER_KEY_FILE");
			logger.debug("decoderClass={},decoderKeyFile={}",new Object[]{decoderClass, decoderKeyFile});
			if(!GlobalUtils.isNullOrEmpty(decoderKeyFile))
			{
				try 
				{
					File keyFile = new File(decoderKeyFile);
					if (!keyFile.exists()){
						feedback.setFailure();
						String error = "Error, DECODER_KEY_FILE=" + decoderKeyFile + " does not exist";
						feedback.setErrorText(error);
						return feedback;
					}
					
					//Getting decoder class from Custom property (in interface type table)
					@SuppressWarnings("rawtypes")
					Class cls = Class.forName(decoderClass);
					Object obj = cls.newInstance();
					
					Method method = obj.getClass().getMethod("decoder", String.class, String.class,String.class);
					
					//Gets the absolute path of incoming file
					String incomingFile = SFTPUtils.fixPath(fileToProcess.getAbsolutePath(),true);
					
					//Adding dec_ to beginning of file name
					int i;
					i=incomingFile.lastIndexOf("/");
					String decodedFile=incomingFile.substring(0,i+1)+"dec_"+fileToProcess.getName();
					
					//Call decoder class using reflection
					feedback = (Feedback)method.invoke(obj, incomingFile,decodedFile,decoderKeyFile);
					
					//Decoded file is held under name: dec_<orig_file_name>
					File decFile = new File(decodedFile);
					File incFile = new File(incomingFile);
					
					//Deleting the orig_file_name and moving the dec_<orig_file_name> to <orig_file_name> (which will be decrypted now)
					if (!incFile.delete())
					{
						logger.error("Could not delete original file {} before it is overwritten by the decoded file {}",new Object[]{incomingFile, decodedFile});
					}
					if (decFile.renameTo(new File(incomingFile))) {
						logger.info("file {} was renamed to {} ",new Object[]{decodedFile, incomingFile});
					} else {
						logger.warn("File renaming from {} to {} has failed.",new Object[]{decodedFile, incomingFile});
					}
						
				} catch (Throwable e) {												
						feedback.setFailure();						
						String error = "Failed decrypting file: " + fileToProcess.getName() + " and stop the upload process. " + "Exception from class: " + e.getClass().getName();
						logger.error(error,e);
						feedback.setErrorText(error);
				}
			}
			else
			{
				feedback.setFailure();
				String error = "decoderKeyFile custom property is empty";
				feedback.setErrorText(error);
				logger.debug("No decryption is done: decodeClass = {}, decoderKeyFile = {}", decoderClass, decoderKeyFile);
			}
		}
		return feedback;
	}
	/**
	 * Run the file listener process
	 */
	@Override
	public void run() {
		
		InterfaceTypes it = CacheKeys.interfaceTypesNameKey.getSingle(interfaceType.getInterfaceName());
		if (it.getInterfaceStatus().equals(InterfaceTypes.STATUS_NOT_ACTIVE)) {
			logger.debug("interface {} is not ACTIVE, skipping..", interfaceType.getInterfaceName());
			return;
		}
		Calendar calendar=new GregorianCalendar();
		if (calendar.get(Calendar.HOUR_OF_DAY)<iTimeWindowStartHour ||
			(calendar.get(Calendar.HOUR_OF_DAY)==iTimeWindowStartHour && calendar.get(Calendar.MINUTE)<iTimeWindowStartMin))
		{
			return;
		}
		if (calendar.get(Calendar.HOUR_OF_DAY)>iTimeWindowEndHour ||
			(calendar.get(Calendar.HOUR_OF_DAY)==iTimeWindowEndHour && calendar.get(Calendar.MINUTE)>iTimeWindowEndMin))
		{
			return;
		}
		
		logger.debug("CheckFolderTask InterfaceName={},Office={}", it.getInterfaceName(),it.getOffice());
		Feedback feedback=new Feedback();
		File[] files=new File[0];
		try
		{
			files=getFileList(it,feedback);
			if (feedback.isSuccessful() && (null==files || 0==files.length))
			{
				return;
			}
		}
		catch (Exception ex)
		{
			logger.error("CheckFolderTask:run",ex.getMessage());
			feedback.setErrorText(ex.getMessage());
			feedback.setFailure();
		}
		
		if (feedback.isSuccessful())
		{
			List<File> arrFiles=new ArrayList<File>(); 
			for (File f : files) 
			{
				if(f.isDirectory())	continue;	// Filtering directories Out.
				File destFile = null;
				try 
				{
					lock.lock();
					if (f.exists()) 
					{
						if (!GlobalUtils.isNullOrEmpty(archiveFolder))
						{
							destFile = GlobalFileUtil.moveFileAddTimeStampIfExist(f, new File(archiveFolder));
							logger.info("file {} was moved to {}", f.getAbsolutePath(), destFile.getAbsolutePath());
							arrFiles.add(destFile);
						}
						else
						{
							arrFiles.add(f);
						}
					}
					else
					{
						logger.info("skipping {} please check file and permissions. f.canWrite={}",new Object[]{f.getName(),f.canWrite()});
					}
				}
				finally
				{
					lock.unlock();
				}
			}
			files=arrFiles.toArray(new File[0]);
		}
		
		if (feedback.isSuccessful())
		{
			@SuppressWarnings("unchecked")
			String sZIP=SFTPUtils.getPropertyValue(it,"ZIP");;
			if (sZIP.startsWith("Y") || sZIP.startsWith("y") || sZIP.startsWith("T") || sZIP.startsWith("t") || sZIP.startsWith("1"))
			{
				String[] fileNames=new String[files.length];
				int i=0;
				for (File file:files) 
				{
					fileNames[i++]=file.getAbsolutePath();
				}
				SFTPUtils sftputils=new SFTPUtils();
				List<String> unzippedFiles=sftputils.unzipFiles(fileNames,true,feedback);
				if (!feedback.isSuccessful() || 0==unzippedFiles.size())
				{
					return;
				}
				files=new File[unzippedFiles.size()];
				i=0;
				for (String localFileName:unzippedFiles) 
				{
					files[i++]=new File(localFileName);
				}
			}
		}
		
		if (feedback.isSuccessful())
		{
			for (File f : files) 
			{
				try {
					
					feedback=decodeFile(it,f);
					//In case feedback was not successful, printing error into interface error log
					if (!feedback.isSuccessful()){
						
						try {
							int sessionId = errorLog.getSessionId();
							errorLog.addInterfaceErrorLog("SYSTEM", sessionId, it.getInterfaceName(), "ERROR", feedback.getErrorText());
							String decodedFile = archiveFolder + File.separatorChar + "dec_" + f.getName() ;
							Thread.sleep(30000); //sleep is needed for file to have time to be created in the file system
							File decFile = new File(decodedFile);
							if (decFile !=null){
								decFile.delete();
							}
						} catch (Throwable e) {
							logger.error("addInterfaceErrorLog failed..", e);						
						}
					}
					
				} catch (Exception e) {
					logger.error("Error while decoding "+f.getAbsolutePath(), e);					
					continue;
				}
			}
		}
		if (feedback.isSuccessful() && !GlobalUtils.isNullOrEmpty(SFTPUtils.getPropertyValue(it,"BEANIO_TO_STREAM")))
		{
			if (GlobalUtils.isNullOrEmpty(it.getHandlerClass())){
				BeanIOUtils beanIOUtils=new BeanIOUtils();
				files=beanIOUtils.convert(it,files,feedback);
			}
		}
		if (!feedback.isSuccessful())
		{
			logger.error("{} will be set to {} due to '{}'",new Object[]{it.getInterfaceName(),InterfaceTypes.STATUS_NOT_ACTIVE,feedback.getErrorText()});
			try 
			{
				int sessionId=errorLog.getSessionId();
				errorLog.addInterfaceErrorLog("SYSTEM",sessionId,it.getInterfaceName(),"ERROR",feedback.getErrorText());
			} 
			catch (Throwable e) 
			{
				logger.error("addInterfaceErrorLog failed.", e);				
			}
			DAOInterfaces.getInstance().updateInterfaceTypesStatus(it.getOffice(), it.getInterfaceName(), InterfaceTypes.STATUS_NOT_ACTIVE, it.getNonActiveBehaviour(), feedback);
			if (feedback.isSuccessful())
			{
				 CacheServiceInterface.eINSTANCE.applyChanges(new String[] { CacheKeys.interfaceTypesKey.name(),CacheKeys.interfaceTypesNameKey.name()}, null);
			}
			return;
		}
		for (File f : files) {
			logger.info("working on file: "+f.getAbsolutePath());
			
			try {
				final Admin admin = CallSource.Service.newAdmin("FILE"
						+ "_" + null);
				admin.putSessionData(
						ProcessSessionsKey.KEY_SAME_PROCSS_SESSION_PROPAGATOR_JVM,
						GlobalConstants.BOOL_TRUE);
				admin.putSessionData(Admin.CONTEXT_KEEP_ADMIN_RESOURCES,
						GlobalConstants.BOOL_TRUE);
				admin.putSessionData(
						Admin.CONTEXT_IGNORE_ERROR_LOG_ON_EXCEPTION,
						GlobalConstants.BOOL_TRUE);
				Admin.setContextAdmin(admin);

				//Running the file upload process only in case feedback is successful. 
				if (feedback.isSuccessful()){
					logger.debug("delegating work to handler {}",new Object[]{interfaceType.getInHandler().getClass().getName()});
					final InterfaceTypeInHandler inHandler = interfaceType.getInHandler();
					inHandler.handleIn(interfaceType, f.getAbsolutePath());
				}
				else{
					feedback.setSuccess(); //Setting feedback to be successful for next file to be read.
				}
			} catch (Throwable t) {
				logger.error("Processing file "+f.getAbsolutePath()+" has failed.", t);
			} finally {
				Admin.contextCleanup();;
			}
		}
	}
	
	/**
	 * 
	 * @param fileArr Which may contains Files and Folders will be filtered out of Folders  
	 * @return array of type File which will hold only Files
	 */
	protected File[] removeFoldersFromFileArray(File[] fileArr){
		Collection<File> listFiles=new ArrayList<File>(); 
		for(File file : fileArr)
		{
			if (!file.isDirectory() && file.exists())
			{
				listFiles.add(file);
				if (PROCESS_ONE_FILE_PER_TRANSACTION)
				{
					break;
				}
			}
		}
		return listFiles.toArray(new File[0]);
	}
	
	protected File[] getFileList(InterfaceTypes it,Feedback feedback)
	{
		File folder = new File(incomingFolder);
		if (!folder.isDirectory()) {
			String str="folder "+incomingFolder+" does not exist.";
			feedback.setFailure();
			feedback.setErrorText(str);
			logger.error(str);
			return new File[0];
		}
		SFTPUtils.purgeOldFiles(archiveFolder,iRETENTION_DAYS);
	//	SFTPUtils.purgeOldFiles(incomingFolder,iRETENTION_DAYS);
		
		final boolean bUseControlFile=(controlFileExt.length>0 && fileExt.length>0);
		File files[];
		if (bUseControlFile || !GlobalUtils.isNullOrEmpty(sFilePattern) || fileExt.length>0)
		{
			files=folder.listFiles(new FilenameFilter()
			{
				@Override
				public boolean accept(File directory, String fileName) 
				{
					File f=new File(directory,fileName);
					if (f.isDirectory() || !f.exists())
					{
						return false;
					}
					boolean bIncludeThisFile = false;
					if (bUseControlFile)
					{
						bIncludeThisFile = fileName.endsWith("."+controlFileExt[0]);
					}
					else if (fileExt.length>0)
					{
						for (String ext:fileExt)
						{
							if (fileName.endsWith("."+ext))
							{
								bIncludeThisFile = true;
							}
						}
					}
					if (!bIncludeThisFile && !GlobalUtils.isNullOrEmpty(sFilePattern)){
						bIncludeThisFile = fileName.matches(sFilePattern);
					}
			        return bIncludeThisFile;
				};
			});
		}
		else
		{
			files=folder.listFiles();;
		}
		
		if (bUseControlFile)
		{
			List<File> arrFiles=new ArrayList<File>(); 
			for (File controlFile:files) 
			{
				boolean bFound=false;
				String localFileWithExt=controlFile.getAbsolutePath();
				for (String ext:fileExt)
				{
					localFileWithExt=localFileWithExt.substring(0,localFileWithExt.length()-controlFileExt[0].length())+ext;
					File localFile=new File(localFileWithExt);
					if (localFile.exists() && localFile.isFile())
					{
						arrFiles.add(localFile);
						bFound=true;
					}
				}
				if (bFound)
				{
					controlFile.delete();
					if (PROCESS_ONE_FILE_PER_TRANSACTION)
					{
						break;
					}
				}
			}
			files=arrFiles.toArray(new File[0]);
		}else{
			// Filtering the Folders out.
			files = removeFoldersFromFileArray(files);
		}
		
		return files;
	}

}
