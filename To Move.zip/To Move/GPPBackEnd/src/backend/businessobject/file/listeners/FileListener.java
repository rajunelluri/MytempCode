package backend.businessobject.file.listeners;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.cache.entities.InterfaceTypes;

public class FileListener {

	private final ScheduledExecutorService fScheduler;
	private final long iInitialDelayMinutes;
	private final long iDelayBetweenRunsMinutes;
	private ScheduledFuture<?> checkFolderFuture;

	private final InterfaceTypes interfaceType;
	private static final Logger logger = LoggerFactory.getLogger(FileListener.class);

	FileListener(long aInitialDelay, long aDelayBetweenBeepsMinutes, int numOfThreads,InterfaceTypes it) 
	{
		iInitialDelayMinutes = aInitialDelay;
		iDelayBetweenRunsMinutes = aDelayBetweenBeepsMinutes;
		interfaceType = it;
		fScheduler = Executors.newScheduledThreadPool(numOfThreads);	
	}

	void activateListener() {
		Runnable checkFolderTask = null;
		if (InterfaceTypes.PROTOCOL_FILE.equals(interfaceType.getRequestProtocol()))
		{
			checkFolderTask=new CheckFolderTask(interfaceType);
		}
		else
		{
			checkFolderTask=new CheckFolderTaskSFTP(interfaceType);
		}
		checkFolderFuture = fScheduler.scheduleWithFixedDelay(checkFolderTask, iInitialDelayMinutes,iDelayBetweenRunsMinutes, TimeUnit.MINUTES);
		logger.info("Activating listener for Name={} Office={} RequestProtocol={} iInitialDelayMinutes={} iDelayBetweenRunsMinutes={}",new Object[]{interfaceType.getInterfaceName(),interfaceType.getOffice(),interfaceType.getRequestProtocol(),iInitialDelayMinutes,iDelayBetweenRunsMinutes});
	}

	public void stopListener() {
		Runnable stopAlarm = new StopListening(checkFolderFuture);
		fScheduler.schedule(stopAlarm, 0, TimeUnit.SECONDS);
	}

	private static final boolean MAY_INTERRUPT_IF_RUNNING = false;

	
	
	private final class StopListening implements Runnable {
		StopListening(ScheduledFuture<?> aSchedFuture) {
			fSchedFuture = aSchedFuture;
		}

		public void run() {
			logger.info("Stopping listener Name={} Office={} RequestProtocol={}",new Object[]{interfaceType.getInterfaceName(),interfaceType.getOffice(),interfaceType.getRequestProtocol()});
			fSchedFuture.cancel(MAY_INTERRUPT_IF_RUNNING);
			fScheduler.shutdown();
		}

		private final ScheduledFuture<?> fSchedFuture;
	}

}