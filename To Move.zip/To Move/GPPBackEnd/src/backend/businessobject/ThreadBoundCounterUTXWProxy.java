package backend.businessobject;

import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;
import javax.transaction.UserTransaction;

import com.fundtech.jndi.ServiceLocator;
import com.fundtech.spring.FndtSpringBeansFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * Mar 24, 2010
 * ThreadBoundCounterUTXWProxy.java
 * @author Guys
 * 
 * Note: THIS CLASS BINDS THE TX TO A SINGLE THREAD (for use in method scope nested tx scenarios only!!!!)
 *
 */
public class ThreadBoundCounterUTXWProxy implements UserTransaction{

  private final static Logger logger = LoggerFactory.getLogger(ThreadBoundCounterUTXWProxy.class);
  private final UserTransaction m_utx;
  private int m_iNestedInvocationsCounter ; 
  private int m_iRollbackOnlyMarkerNestedDepth  ;
  
  private static ThreadLocal<ThreadBoundCounterUTXWProxy> m_txWrapper = new ThreadLocal<ThreadBoundCounterUTXWProxy>() ;
  
  public static final ThreadBoundCounterUTXWProxy getStartedInstance() throws Throwable { return getStartedInstance(false/*bSilentParticipation*/) ;}//EOM
    
  public static final ThreadBoundCounterUTXWProxy getStartedInstance(boolean bSilentParticipation) throws Throwable { 
	
	  ThreadBoundCounterUTXWProxy utxProxy = m_txWrapper.get() ; 
	 if(utxProxy != null) { 
		 //System.out.println("getStartedInstance NOT NULL");
		 if(!bSilentParticipation) utxProxy.m_iNestedInvocationsCounter++ ; 
		 return utxProxy ; 
	 }//EO if the tx was already started (nested TX ) 
	 //else  
	 //final UserTransaction utx = (UserTransaction) ServiceLocator.getInstance().getContext().lookup("java:comp/UserTransaction");
	 final UserTransaction utx = ((org.springframework.transaction.jta.JtaTransactionManager)ServiceLocator.getInstance().getSpringApplicationContext(FndtSpringBeansFactory.DEFAULT_APP_CONTEXT).getBean("transactionManager")).getUserTransaction() ; 
	 utxProxy = new ThreadBoundCounterUTXWProxy(utx) ; 
     m_txWrapper.set(utxProxy) ;
     return utxProxy  ;
  }//EOM 
  
  public static final boolean joinActiveSession() { 
	  final ThreadBoundCounterUTXWProxy utxProxy = m_txWrapper.get() ; 
	  if(utxProxy == null) return false ; 
	  else return utxProxy.m_iNestedInvocationsCounter++ != -999 ; 	  
  }//EOM 
    
  public static final void closeTx(final boolean bCommit) throws Throwable{
	  final ThreadBoundCounterUTXWProxy utxProxy = m_txWrapper.get() ;
	  try
	  {
		  if(utxProxy == null) return ; 
		  else if(bCommit) utxProxy.commit() ; 
		  else utxProxy.rollback() ;
		  //System.out.println("closeTx nested invocation level --> " + utxProxy.m_iNestedInvocationsCounter);
	  }finally
	  {
	  //if the nested invocations counter is 0 remove from the thread local 
		  if(utxProxy != null && utxProxy.m_iNestedInvocationsCounter == 0) m_txWrapper.remove() ;
	  }
  }//EOM
  
  public static final boolean isNestedTx() { 
	  final ThreadBoundCounterUTXWProxy utxProxy = m_txWrapper.get() ; 
	  return (utxProxy == null ? false : utxProxy.m_iNestedInvocationsCounter > 1) ;  
  }//EOM 
  
  private ThreadBoundCounterUTXWProxy(final UserTransaction utx) throws NotSupportedException, SystemException{ 
    this.m_utx = utx;
    this.m_iRollbackOnlyMarkerNestedDepth = -1 ; 
    this.begin() ; 
  }//EOM 
    
  @Override
  public final void begin() throws NotSupportedException, SystemException{
     if(this.m_iNestedInvocationsCounter++ == 0) { 
    	 this.m_utx.setTransactionTimeout(3600);
    	 this.m_utx.begin();
     }//EO  if the tx was not yet initialized 
   }//EOM 

  @Override
  public final void commit() throws RollbackException, HeuristicMixedException,
      HeuristicRollbackException, SecurityException, IllegalStateException, SystemException{
    if(--this.m_iNestedInvocationsCounter == 0) { 
    	if(!this.isMarkedForRollbackOnly()) {
    		//System.out.println("ThreadBoundCounterUTXWProxy.commit() --> top level invoker") ; 
    		this.m_utx.commit();
    	}else { 
    		logger.info("Error While Attempting to commit the Tx: Tx was already marked for rollback by nested level {}; rolling back Tx!", this.m_iRollbackOnlyMarkerNestedDepth) ; 
    		this.m_utx.rollback() ;
    	}//EO else if m_markedForRollbackOnly
    }//EO if no nested invocations 
  }//EOM 

  @Override
  public final int getStatus() throws SystemException{ return m_utx.getStatus(); }

  @Override
  public final void rollback() throws IllegalStateException, SecurityException, SystemException{
	  if(--this.m_iNestedInvocationsCounter == 0) { 
		  //System.out.println("ThreadBoundCounterUTXWProxy.commit() --> top level invoker") ; 
		  this.m_utx.rollback();
	  }//EO if top level invoker
	  else this.setRollbackOnly() ; 
	   
  }//EOM 

  @Override
  public final void setRollbackOnly() throws IllegalStateException, SystemException{ 
	  this.m_utx.setRollbackOnly();
	  this.m_iRollbackOnlyMarkerNestedDepth = this.m_iNestedInvocationsCounter ; 
  }//EOM
  
  public final boolean isMarkedForRollbackOnly() { return this.m_iRollbackOnlyMarkerNestedDepth != -1 ; }//EOM 

  @Override
  public final void setTransactionTimeout(int seconds) throws SystemException{ 
	  this.m_utx.setTransactionTimeout(seconds); 
  }//EOM 
}
