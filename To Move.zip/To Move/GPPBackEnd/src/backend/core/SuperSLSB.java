package backend.core;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;
import javax.ejb.EJBContext;

import backend.businessobject.BOInterface;
import backend.businessobject.proxies.BOProxy;
import backend.businessobject.proxies.interceptors.InterceptorSetType;

/**
 * Sep 22, 2008
 * SuperSLSB.java
 * @author guys
 *
 * Super EJB implementation initiailising the BO 
 *
 */
public class SuperSLSB<T> {

	protected T m_bo ; 

	@Resource
	protected EJBContext context ; 
	
	public SuperSLSB(){} 
	
	@SuppressWarnings("unchecked")
	public SuperSLSB(final Class<?> boClassType, final InterceptorSetType interceporSet) { 
		this.m_bo = (T) BOProxy.wrap(boClassType, interceporSet, null/*primary interface to implement*/) ; 
	}//EOM 
	
	public SuperSLSB(final Class<?> boClassType, final InterceptorSetType interceporSet, 
			final Class<T> primaryInterfaceToImplement, final Class<?>...arrAdditionalInterfacesToImplement) { 
		this.m_bo = BOProxy.wrap(boClassType, interceporSet, null/*init Params map*/,primaryInterfaceToImplement, arrAdditionalInterfacesToImplement) ; 		
	}//EOM 
	
	public SuperSLSB(final Class<?> boClassType) { this(boClassType, (Class<T> ) null/*primaryInterfaceToImplement*/) ; }//EOM 
	
	public SuperSLSB(final Class<?> boClassType, Class<T> primaryInterfaceToImplement) { 
		this.m_bo = BOProxy.completeDecoration(boClassType, primaryInterfaceToImplement) ; 		
	}//EOM  
	
	@PostConstruct
	protected void activate() { 
		((BOInterface)this.m_bo).businessObjectActivate() ; 
	}//EOM 
	
	@PreDestroy
	protected void dispose() { 
		((BOInterface)this.m_bo).businessObjectRemove() ;
	}//EOM 
	
}//EOM 
