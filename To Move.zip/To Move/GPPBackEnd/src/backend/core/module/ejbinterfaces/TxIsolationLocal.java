package backend.core.module.ejbinterfaces;

import javax.ejb.Local;

/**
 * Local interface for TxIsolation.
 */
@Local
public interface TxIsolationLocal extends TxIsolation{} ; 