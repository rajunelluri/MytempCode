package backend.core.module.ejbinterfaces;

import javax.ejb.Remote;

import com.fundtech.core.security.Admin;

/**
 * Remote interface for TxIsolation.
 */
@Remote
public interface TxIsolation{

	public static final String REMOTE_JNDI_NAME="ejb/TxIsolationBean";
	
	
	public backend.paymentprocess.erroraudit.Errorlog persistErrorLogInTxIsolation(final Admin admin, com.fundtech.cache.entities.Journalmessages journalMess, com.fundtech.util.ErrorAuditInputData eaInputData, java.lang.String sEditedErrorText ) ;
	
	public backend.dataaccess.dto.DTODataHolder executeSP_GET_OUT_FILE(final Admin admin, java.lang.String sAction, backend.paymentprocess.subbatchcompletion.businessobjects.BOSubBatchCompletion.OutGroupingIDData outGroupingIDData, int iOutFileIndex ) ;
	
	public com.fundtech.datacomponent.response.Feedback updateInterfaceTypesStatusTable(final Admin admin, java.lang.String office, java.lang.String interfaceName, java.lang.String status, java.lang.String notActiveBehavior, com.fundtech.datacomponent.response.Feedback feedback ) ;
	
	public com.fundtech.datacomponent.response.Feedback updateCDT_DAILY_TRANSFER_Table(final Admin admin, java.lang.String sTotalDebitAmount, java.lang.String sFileSummaryCustCode, java.lang.String sBusinessDate, java.lang.Long lDailyCdtXferLimit, boolean bFileSummaryOverrideLimitCheck, int[] arrAffectedRows ) ;
	
	public com.fundtech.datacomponent.response.Feedback rollbackCDT_DAILY_TRANSFER_Changes(final Admin admin, java.lang.String sTotalBaseAmount, java.lang.String sFileSummaryCustCode, java.lang.String sBusinessDate, int[] arrAffectedRows ) ;
	
	public com.fundtech.datacomponent.response.Feedback executeTask(final Admin admin, java.io.Serializable boObject, java.lang.String methodName, java.io.Serializable input ) ;
	
	public com.fundtech.datacomponent.response.Feedback executeFileUploadTask(final Admin admin, java.lang.String sFilewithPath, java.lang.String sTaskID, java.lang.String sFinancialInst, java.lang.String sCntCurIban, java.lang.String sVersion, java.lang.String sHandleMembership, java.lang.String sMode ) ;
	
	public com.fundtech.datacomponent.response.Feedback execute_Accuity_Upload(final Admin admin, java.lang.String sTaskID, java.lang.String sOffice, java.lang.String sDept, java.lang.String sFilePath, java.lang.String sUploadType, java.lang.String[] sFiles ) ;
	
	public java.io.Serializable invokeInterfaceInNewTx(final Admin admin, backend.paymentprocess.interfaces.common.TransmissionType enumTransmissionType, java.io.Serializable message, java.lang.String mid, com.fundtech.cache.entities.InterfaceTypes mapProperties, com.fundtech.datacomponent.response.Feedback feedback, java.util.HashMap mapContext ) throws java.lang.Exception ;
	
	public int updateACCOUNTS_TableForBIBlockDiffPayerBankAndPayeeBank(final Admin admin, java.lang.String sDebitAccountUID, java.lang.String sP_DBT_AMT, java.lang.String sP_CDT_AMT, java.lang.String sCreditAccountUID, java.lang.Long lDebitAsset ) ;
	
	public int updateACCOUNTS_TableForBIBlockSamePayerBankAndPayeeBank(final Admin admin, java.lang.String sDebitAccountUID, java.lang.String sP_DBT_AMT ) ;
	
	public int updateACCOUNTS_TableForBIUnblockDiffPayerBankAndPayeeBank(final Admin admin, java.lang.String sCreditAccountUID, java.lang.String sP_CDT_AMT, java.lang.String sP_DBT_AMT, java.lang.String sDebitAccountUID ) ;
	
	public int updateACCOUNTS_TableForBIUnblockSamePayerBankAndPayeeBank(final Admin admin, java.lang.String sCreditAccountUID, java.lang.String sP_CDT_AMT ) ;

	public int updateAccountsSelectedAttributes(final Admin admin, String setQuery, String [] params) ;
	
	//mass payment retrofit
	public abstract int incNumOfProcessChunksInFileSummary(Admin paramAdmin, String paramString)
    throws Exception;

  public abstract int incNumOfCompletedChunksInFileSummary(Admin paramAdmin, String paramString)
    throws Exception;

  public abstract int decNumOfProcessChunksInFileSummary(Admin paramAdmin, String paramString)
    throws Exception;

  public abstract int decNumOfCompletedChunksInFileSummary(Admin paramAdmin, String paramString)
    throws Exception;
  
  public java.io.Serializable executeInNewTx(final Admin admin, com.fundtech.core.general.threading.Callable callable ) throws java.lang.Exception ;
  //mass payment retrofit
}//EOI  