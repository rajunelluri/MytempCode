package backend.core.module.txisolation;

import java.rmi.RemoteException;

import com.fundtech.cache.entities.Journalmessages;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.util.ErrorAuditInputData;

import backend.dataaccess.dto.DTODataHolder;
import backend.paymentprocess.erroraudit.Errorlog;
import backend.paymentprocess.subbatchcompletion.businessobjects.BOSubBatchCompletion.OutGroupingIDData;

public interface TxIsolationSuperInterface {

	Errorlog persistErrorLogInTxIsolation(Journalmessages journalMess, ErrorAuditInputData eaInputData, String sEditedErrorText) throws RemoteException ; 
	
	DTODataHolder executeSP_GET_OUT_FILE(String sAction, OutGroupingIDData outGroupingIDData, int iOutFileIndex) throws RemoteException ;

	Feedback updateCDT_DAILY_TRANSFER_Table(String sTotalDebitAmount, String sFileSummaryCustCode, String sBusinessDate, 
                                            Long lDailyCdtXferLimit, boolean bFileSummaryOverrideLimitCheck, int[] arrAffectedRows);
	
    Feedback rollbackCDT_DAILY_TRANSFER_Changes(String sTotalBaseAmount, String sFileSummaryCustCode, String sBusinessDate, int[] arrAffectedRows);
    
    Feedback executeFileUploadTask(String sFilewithPath,String sTaskID,String sFinancialInst,String sCntCurIban,String sVersion,String sHandleMembership,String sMode) throws RemoteException ;
}//EOI 
