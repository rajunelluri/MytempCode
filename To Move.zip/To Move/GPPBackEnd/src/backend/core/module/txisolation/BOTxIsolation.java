package backend.core.module.txisolation;

import java.io.Serializable;
import java.lang.reflect.Method;
import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.businessobject.BOBasic;
import backend.businessobject.proxies.SkipInputValidation;
import backend.dataaccess.dto.DTODataHolder;
import backend.paymentprocess.SubBatchProcessInterface;
import backend.paymentprocess.balanceinquiry.dao.DAOBalanceInquiry;
import backend.paymentprocess.creditdailylimit.dao.DAOCreditDailyLimit;
import backend.paymentprocess.debulkingprocess.dao.DAODebulkingProcess;
import backend.paymentprocess.erroraudit.ErrorAuditUtils;
import backend.paymentprocess.erroraudit.Errorlog;
import backend.paymentprocess.interfaces.common.TransmissionType;
import backend.paymentprocess.interfaces.dao.DAOInterfaces;
import backend.paymentprocess.subbatchcompletion.businessobjects.BOSubBatchCompletion.OutGroupingIDData;
import backend.paymentprocess.subbatchcompletion.dao.DAOSubBatchCompletion;
import backend.services.cache.ASCacheFactory;
import backend.staticdata.profilehandler.general.dataaccess.dao.DAORUN_TASK;
import backend.staticdata.profilehandler.message.dataaccess.dao.DAOACCOUNTS;

import com.fundtech.annotations.EJBRef;
import com.fundtech.annotations.EJBRef.EJBRefType;
import com.fundtech.annotations.Expose;
import com.fundtech.annotations.Expose.TransactionType;
import com.fundtech.annotations.JMS;
import com.fundtech.annotations.Wrap;
import com.fundtech.cache.entities.InterfaceTypes;
import com.fundtech.cache.entities.Journalmessages;
import com.fundtech.core.general.threading.Callable;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.datacomponent.response.SimpleResponseDataComponent;
import com.fundtech.spring.SpringApplicationContext;
import com.fundtech.util.ErrorAuditInputData;


@Wrap (EJBRefs={   
	    @EJBRef(type=EJBRefType.Local, jndi="ejb/MessageHandleBeanLocal", 
	            interfaceClass="backend.pa}ymentprocess.messagehandle.ejbinterfaces.MessageHandleLocal", 
	            targetEJB="MessageHandle")}, 
	            jmsResources={@JMS(conFactoryJmsResourceKey="interfaces")}
				) 

public class BOTxIsolation extends BOBasic implements SubBatchProcessInterface 
{  

  private final static Logger logger = LoggerFactory.getLogger(BOTxIsolation.class);
  private static DAOSubBatchCompletion m_daoSubBatchCompletion =  DAOSubBatchCompletion.getInstance();
  private static DAODebulkingProcess m_daoDebulkingProcess =  DAODebulkingProcess.getInstance();
  private static DAOCreditDailyLimit m_daoCreditDailyLimit =  DAOCreditDailyLimit.getInstance();
  private static DAOBalanceInquiry m_daoBalanceInquiry =  DAOBalanceInquiry.getInstance();
  private static DAOACCOUNTS m_daoAccounts =  DAOACCOUNTS.getInstance();

  //private static DAORUN_TASK m_daoRunTask =  DAORUN_TASK.getInstance();
  private static DAORUN_TASK m_daoRunTask =  new DAORUN_TASK();
  private static DAOInterfaces m_daoInterface = DAOInterfaces.getInstance();
  
  @SkipInputValidation
  @Expose(txType=TransactionType.RequiresNew)
  public final Errorlog persistErrorLogInTxIsolation(Journalmessages journalMess, ErrorAuditInputData eaInputData, String sEditedErrorText){ 
      	  
      
      
      //ensure that the shared resources flag set in the admin is set to false 
   /*   
    * Removed in R&D version
    * final Admin admin = Admin.getContextAdmin() ;
      final boolean bOrigSharedResourcesSupport = admin.supportsSharedResources() ; 
      admin.disableSharedResourcesSupport() ; 
*/      
      Errorlog errorLog = null ;;;;   
      try{ 
          errorLog = ErrorAuditUtils.insertToErrLog(journalMess, eaInputData, sEditedErrorText, !ASCacheFactory.getCommService().equals("EJB")) ; 
      }catch(RuntimeException rte) { 
    	  throw rte ; 
      }catch(Throwable t) { 
          logger.error("Problems persisting the following process error:n" + sEditedErrorText); 
          throw new RuntimeException(t) ;
      }finally{ 
    	  //restore the orig shared resources flag
    //	  admin.setSharedResourecsSupport(bOrigSharedResourcesSupport) ; 
      }//EO catch block  
      
      
      return errorLog ; 
  }//EOM 
  
  @SkipInputValidation
  @Expose(txType=TransactionType.RequiresNew)
  public DTODataHolder executeSP_GET_OUT_FILE(String sAction, OutGroupingIDData outGroupingIDData, int iOutFileIndex)
  {
    return m_daoSubBatchCompletion.executeSP_GET_OUT_FILE(sAction, outGroupingIDData, iOutFileIndex);
  }
  
  @SkipInputValidation
  @Expose(txType=TransactionType.RequiresNew)  
  public Feedback updateInterfaceTypesStatusTable(String office, String interfaceName, String status, String notActiveBehavior, Feedback feedback)
  {
	  return m_daoInterface.updateInterfaceTypesStatus(office, interfaceName, status, notActiveBehavior, feedback);
  }
  
  @SkipInputValidation
  @Expose(txType=TransactionType.RequiresNew)
  public Feedback updateCDT_DAILY_TRANSFER_Table(String sTotalDebitAmount, String sFileSummaryCustCode, String sBusinessDate,
                                                 Long lDailyCdtXferLimit, boolean bFileSummaryOverrideLimitCheck, int[] arrAffectedRows)
  {
    return m_daoCreditDailyLimit.updateCDT_DAILY_TRANSFER_Table(sTotalDebitAmount, sFileSummaryCustCode, sBusinessDate, lDailyCdtXferLimit, bFileSummaryOverrideLimitCheck, arrAffectedRows);
  }
  
  @SkipInputValidation
  @Expose(txType=TransactionType.RequiresNew)
  public Feedback rollbackCDT_DAILY_TRANSFER_Changes(String sTotalBaseAmount, String sFileSummaryCustCode, String sBusinessDate, int[] arrAffectedRows)
  {
    return m_daoCreditDailyLimit.rollbackCDT_DAILY_TRANSFER_Changes(sTotalBaseAmount, sFileSummaryCustCode, sBusinessDate, arrAffectedRows);
  }
  
  
  @SkipInputValidation   
  @Expose(txType=TransactionType.RequiresNew)
  public Feedback executeTask(Serializable boObject, String methodName, Serializable input)
  {
      Feedback feedback = null;
      try{
    	  //input must not be null     	  
          Method m = boObject.getClass().getMethod(methodName, Admin.class, input.getClass()) ;
          Object o = m.invoke(boObject,Admin.getContextAdmin(), input);
          if (o instanceof Feedback) 
            feedback = (Feedback)o;
          else if (o instanceof SimpleResponseDataComponent)
            feedback = ((SimpleResponseDataComponent)o).getFeedback();
      }catch(Exception e)
      {
    	  logger.error(e.getMessage());
          feedback = new Feedback();
          feedback.setErrorCode(9999);
          feedback.setFailure();
      }
      return feedback;
  }
  
  @SkipInputValidation
  @Expose(txType=TransactionType.NotSupported)
  public Feedback executeFileUploadTask(String sFilewithPath,String sTaskID,String sFinancialInst,String sCntCurIban,String sVersion,String sHandleMembership,String sMode)
  {
    return m_daoRunTask.executeFileUploadTask(sFilewithPath,sTaskID,sFinancialInst,sCntCurIban,sVersion,sHandleMembership,sMode);
  }
  
  @SkipInputValidation
  @Expose(txType=TransactionType.NotSupported)  
  public Feedback execute_Accuity_Upload(String sTaskID, String sOffice, String sDept, String sFilePath, String sUploadType, String[] sFiles)
  {
    return m_daoRunTask.execute_Accuity_Upload(sTaskID,sOffice, sDept, sFilePath, sUploadType, sFiles);
  }
  
  
  @SkipInputValidation
  @Expose(txType=TransactionType.NotSupported) 
  public Serializable invokeInterfaceInNewTx(final TransmissionType enumTransmissionType, final Serializable message, final String mid, final InterfaceTypes mapProperties, final Feedback feedback, final HashMap mapContext) throws Exception {
	  
	  //ensure that the shared resources flag set in the admin is set to false 
      final Admin admin = Admin.getContextAdmin() ;
      final boolean bOrigSharedResourcesSupport = admin.supportsSharedResources() ; 
      admin.disableSharedResourcesSupport() ; 
      
	  //must convert throwable to exception as was does not permit ejb interfaces to throw Throwable in their business method 
	  //signatures 
	  try{ 
		  return enumTransmissionType.transmitInTx(message, mid, mapProperties, feedback, mapContext) ;
	  }catch(Throwable t) { 
		  throw new RuntimeException(t) ; 
	  }finally{ 
		  //restore the orig shared resources flag
    	  admin.setSharedResourecsSupport(bOrigSharedResourcesSupport) ; 
	  }//EO catch block 
	  
  }//EOM 
     
   @SkipInputValidation
  @Expose(txType=TransactionType.RequiresNew)
  public int updateACCOUNTS_TableForBIBlockDiffPayerBankAndPayeeBank(String sDebitAccountUID, String sP_DBT_AMT, String sP_CDT_AMT, String sCreditAccountUID, Long lDebitAsset)
  {
    return m_daoBalanceInquiry.updateACCOUNTS_TableForBIBlockDiffPayerBankAndPayeeBank(sDebitAccountUID, sP_DBT_AMT, sP_CDT_AMT, sCreditAccountUID, lDebitAsset);
  }
  
  @SkipInputValidation
  @Expose(txType=TransactionType.RequiresNew)
  public int updateACCOUNTS_TableForBIBlockSamePayerBankAndPayeeBank(String sDebitAccountUID, String sP_DBT_AMT)
  {
    return m_daoBalanceInquiry.updateACCOUNTS_TableForBIBlockSamePayerBankAndPayeeBank(sDebitAccountUID, sP_DBT_AMT);
  }
  
  @SkipInputValidation
  @Expose(txType=TransactionType.RequiresNew)
  public int updateACCOUNTS_TableForBIUnblockDiffPayerBankAndPayeeBank(String sCreditAccountUID, String sP_CDT_AMT, String sP_DBT_AMT, String sDebitAccountUID)
  {
    return m_daoBalanceInquiry.updateACCOUNTS_TableForBIUnblockDiffPayerBankAndPayeeBank(sCreditAccountUID, sP_CDT_AMT, sP_DBT_AMT, sDebitAccountUID);
  }
  
  @SkipInputValidation
  @Expose(txType=TransactionType.RequiresNew)
  public int updateACCOUNTS_TableForBIUnblockSamePayerBankAndPayeeBank(String sCreditAccountUID, String sP_CDT_AMT)
  {
    return m_daoBalanceInquiry.updateACCOUNTS_TableForBIUnblockSamePayerBankAndPayeeBank(sCreditAccountUID, sP_CDT_AMT);
  }
  
  @SkipInputValidation
  @Expose(txType=TransactionType.RequiresNew)
  public int updateAccountsSelectedAttributes(String setQuery , String[] params)
  {
    return m_daoAccounts.updateAccountsSelectedAttributes(setQuery,params);
  }
  
  //mass payment retrofit
  @SkipInputValidation
  @Expose(txType=TransactionType.RequiresNew)
  public int incNumOfProcessChunksInFileSummary(String internalFileId) throws Exception
  {
    return m_daoDebulkingProcess.incNumOfProcessChunksInFileSummary(internalFileId);
  }
  
  @SkipInputValidation
  @Expose(txType=TransactionType.RequiresNew)
  public int incNumOfCompletedChunksInFileSummary(String internalFileId) throws Exception
  {
    return m_daoDebulkingProcess.incNumOfCompletedChunksInFileSummary(internalFileId);
  }
  
  @SkipInputValidation
  @Expose(txType=TransactionType.RequiresNew)
  public int decNumOfProcessChunksInFileSummary(String internalFileId) throws Exception
  {
    return m_daoDebulkingProcess.decNumOfProcessChunksInFileSummary(internalFileId);
  }
  
  @SkipInputValidation
  @Expose(txType=TransactionType.RequiresNew)
  public int decNumOfCompletedChunksInFileSummary(String internalFileId) throws Exception
  {
    return m_daoDebulkingProcess.decNumOfCompletedChunksInFileSummary(internalFileId);
  }
  
  @SkipInputValidation
  @Expose(txType=TransactionType.RequiresNew)
  public Serializable executeInNewTx(final Callable callable) throws Exception { 
	  return (Serializable) callable.call();  
  }//EOM
  //mass payment retrofit

}//EOC
