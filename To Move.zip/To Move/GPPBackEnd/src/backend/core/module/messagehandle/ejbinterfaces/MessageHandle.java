package backend.core.module.messagehandle.ejbinterfaces;

import javax.ejb.Remote;
import com.fundtech.core.security.Admin;

/**
 * Remote interface for MessageHandle.
 */
@Remote
public interface MessageHandle{

	public static final String REMOTE_JNDI_NAME="ejb/MessageHandleBean";
	
	
	/** 
	 * Audits an action.
	 */
	public com.fundtech.datacomponent.response.UserResponse auditAction(final Admin admin, com.fundtech.datacomponent.request.AuditActionInputData auditActionInputData ) ;
	
	/** 
	 * @param fndtBatchMsg
	 * @return
	 */
	public java.io.Serializable submitMessageService(final Admin admin, java.io.Serializable fndtBatchMsg ) ;
	
	/** 
	 * @param msgFieldsInput
	 * @param pdo
	 * @return
	 */
	public com.fundtech.datacomponent.response.GlobalResponseDataComponentText submitMessage(final Admin admin, com.fundtech.datacomponent.request.MessageFieldsInputData msgFieldsInput ) ;
	
	public com.fundtech.datacomponent.response.GlobalResponseDataComponentText saveMessage(final Admin admin, com.fundtech.datacomponent.request.MessageFieldsInputData msgFieldsInput ) ;
	
	public com.fundtech.datacomponent.response.UserResponse saveMessage(final Admin admin, java.lang.String sMID ) ;
	
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent getMessageXml(final Admin admin, java.lang.String sMID, com.fundtech.core.paymentprocess.data.paymenttypes.PaymentType enumOutPaymentType, java.util.Map mapCustomizations, java.io.Serializable oFndtMsgSubsetXml, java.io.Serializable oSkelletonRootXml, java.io.Serializable oMergeInput ) ;
	
	/** 
	 */
	public com.fundtech.datacomponent.response.Feedback formatOutMessage(final Admin admin, java.lang.String sMID ) ;
	
	/** 
	 * Returns Group Actions data. trace_todo: could not remove the user authorized as the action id is not a formal arg
	 */
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent performGroupAction(final Admin admin, com.fundtech.core.messagehandle.request.GroupActionRequestData groupActionRequestData ) ;
	
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent manipulateMessageData(final Admin admin, java.lang.String sMID, java.lang.String[] arrObjectAttchments ) ;
	
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent manipulateMessageData(final Admin admin, java.lang.String sManipulationDataID ) ;
	
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent generateMsgComponentFragment(final Admin admin, java.util.Map parametersMap ) ;
	
	public com.fundtech.datacomponent.response.UserResponse saveScreenset(final Admin admin, com.fundtech.datacomponent.request.MessageScreenSetSaveRequestData inputContainer ) ;
	
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent invokeClientAjaxEvent(final Admin admin, com.fundtech.datacomponent.request.MessageFieldsInputData parameterMap ) ;
	
	/** 
	 * handles the association of a template to a user   
	 */
	public com.fundtech.datacomponent.response.GlobalResponseDataComponentText handleTemplateAssociation(final Admin admin, com.fundtech.datacomponent.request.MessageFieldsInputData msgFieldsInput ) ;

}//EOI  