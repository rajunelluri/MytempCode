package backend.core.module.messagehandle.businessobjects;

import static backend.businessobject.BOProxies.m_PositionKeepingLogging;
import static backend.businessobject.BOProxies.m_currencyConversionComplete;
import static backend.businessobject.BOProxies.m_internalRuleExecutionLogging;
import static backend.businessobject.BOProxies.m_matchingCheckLogging;
import static backend.businessobject.BOProxies.m_rtrComplete;
import static backend.businessobject.BOProxies.m_stpRulesLogging;
import static com.fundtech.datacomponent.request.RequestKeys.EVENT_TYPES_KEY;
import static com.fundtech.datacomponent.request.RequestKeys.FRAGMENT_ID_KEY;
import static com.fundtech.datacomponent.request.RequestKeys.IS_SERVICE;
import static com.fundtech.datacomponent.request.RequestKeys.KEY_INT_SUCCESSFUL_MSG_OPERATION_ACTION;
import static com.fundtech.datacomponent.request.RequestKeys.TEMPLATE_UNCHANGED_FIELDS_KEY;
import static com.fundtech.datacomponent.request.RequestKeys.USER_MODIFIED_FIELDS_KEY;
import static com.fundtech.datacomponent.request.RequestKeys.USER_QUALIFIED_MODIFIED_FIELDS_KEY;
import static com.fundtech.util.GlobalConstants.CARRIAGE_RETURN_AND_NEWLINE;
import static com.fundtech.util.GlobalConstants.COMMA;
import static com.fundtech.util.GlobalConstants.NEWLINE;
import static com.fundtech.util.GlobalUtils.isNullOrEmpty;
import backend.services.events.handlers.PaymentDistributerEventHandler;
import backend.services.timers.AggregatedEventsTimer;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.ConcurrentModificationException;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;
import java.util.TreeSet;

import javax.jms.QueueSession;

import org.apache.commons.lang.StringUtils;
import org.apache.xmlbeans.XmlBoolean;
import org.apache.xmlbeans.XmlCursor;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlOptions;
import org.apache.xmlbeans.impl.values.XmlObjectBase;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.businessobject.BOBasic;
import backend.businessobject.BOProxies;
import backend.businessobject.proxies.AuthorizeUser;
import backend.businessobject.proxies.LoadPDO;
import backend.businessobject.proxies.SkipInputValidation;
import backend.core.module.MessageConstantsInterface;
import backend.core.module.message.businessobjects.BOMessage;
import backend.core.module.messageload.businessobjects.BOMessageLoad;
import backend.core.module.security.businessobjects.UserEntitlementData;
import backend.paymentprocess.SubBatchProcessInterface;
import backend.paymentprocess.commons.MessageUtils;
import backend.paymentprocess.commons.MsgClassType;
import backend.paymentprocess.creditdailylimit.dao.DAOCreditDailyLimit;
import backend.paymentprocess.currencyconversion.common.CurrencyConversionConstants.ConversionType;
import backend.paymentprocess.dao.DAS;
import backend.paymentprocess.debulkingprocess.dao.DAODebulkingProcess;
import backend.paymentprocess.erroraudit.ErrorAuditUtils;
import backend.paymentprocess.flowstep.common.BackFromRepairFlowStep;
import backend.paymentprocess.highvalueprocess.businessobjects.BOHighValueProcess;
import backend.paymentprocess.interfaces.handlers.PegaLoadInterfaceHandler;
import backend.paymentprocess.layout.MessageLayoutCache;
import backend.paymentprocess.layout.generation.ScreensetPagesGenerator;
import backend.paymentprocess.mappaymentinfo.businessobjects.BOMapPaymentInfoUsingRules;
import backend.paymentprocess.mappaymentinfo.output.MapPaymentInfoUsingRulesOutputData;
import backend.paymentprocess.nsf.dao.DAONsf;
import backend.paymentprocess.positionkeeping.dao.DAOPositionKeeping;
import backend.paymentprocess.rebulking.dao.DAORebulkProcess;
import backend.paymentprocess.rtr.businessobjects.BORTR.RTROperator;
import backend.paymentprocess.ruleexecution.businessobjects.BORuleExecution;
import backend.paymentprocess.specialinstruction.businessobjects.BOSpecialInstruction;
import backend.services.cache.ASCacheFactory;
import backend.services.cache.entitlements.EntitlementsDataFactory;
import backend.util.ServerConstants;
import backend.util.ServerUtils;

import com.fundtech.annotations.DataSource;
import com.fundtech.annotations.Expose;
import com.fundtech.annotations.Expose.ExposureType;
import com.fundtech.annotations.JMS;
import com.fundtech.annotations.Wrap;
import com.fundtech.cache.entities.Customrs;
import com.fundtech.cache.entities.LogicalFieldsXpath;
import com.fundtech.cache.entities.Mop;
import com.fundtech.cache.entities.MsgSpecialInstructions;
import com.fundtech.cache.entities.Msgerr;
import com.fundtech.cache.entities.Newjournal;
import com.fundtech.cache.entities.PreventStp;
import com.fundtech.cache.entities.PruleTypes;
import com.fundtech.cache.entities.Prules;
import com.fundtech.cache.entities.Relationtypes;
import com.fundtech.cache.entities.RuleResult;
import com.fundtech.cache.entities.RuleResults;
import com.fundtech.cache.entities.RuleResults.CompletionCode;
import com.fundtech.cache.entities.WebSessionInfo;
import com.fundtech.cache.infrastructure.CacheException;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.cache.syspar.SystemParametersInterface;
import com.fundtech.core.general.flows.FlowException;
import com.fundtech.core.message.MessageLayoutCacheInterface;
import com.fundtech.core.message.generation.Button;
import com.fundtech.core.message.generation.MessageComponent;
import com.fundtech.core.messagehandle.request.GroupActionInputDataForMessage;
import com.fundtech.core.messagehandle.request.GroupActionRequestData;
import com.fundtech.core.messagehandle.response.GroupActionOutputDataForMessage;
import com.fundtech.core.paymentprocess.PDOException;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.core.paymentprocess.data.das.DASInterface;
import com.fundtech.core.paymentprocess.data.das.DASInterface.XmlLocationType;
import com.fundtech.core.paymentprocess.data.das.FndtMsgSubSetCursor;
import com.fundtech.core.paymentprocess.data.fields.DataType;
import com.fundtech.core.paymentprocess.data.fields.PaymentFieldInterface;
import com.fundtech.core.paymentprocess.data.fields.PaymentFieldInterface.ModificationType;
import com.fundtech.core.paymentprocess.data.paymenttypes.PaymentType;
import com.fundtech.core.paymentprocess.errorhandling.BusinessException;
import com.fundtech.core.paymentprocess.errorhandling.ProcessError;
import com.fundtech.core.paymentprocess.events.EventBus;
import com.fundtech.core.paymentprocess.events.EventType;
import com.fundtech.core.paymentprocess.events.EventUncheckedException;
import com.fundtech.core.paymentprocess.events.ServerEvents;
import com.fundtech.core.paymentprocess.events.scripts.ScriptErrorResult;
import com.fundtech.core.paymentprocess.events.scripts.ScriptResult;
import com.fundtech.core.security.Admin;
import com.fundtech.core.security.Admin.CallSource;
import com.fundtech.datacomponent.request.AuditActionInputData;
import com.fundtech.datacomponent.request.FieldsContainer;
import com.fundtech.datacomponent.request.MessageFieldsInputData;
import com.fundtech.datacomponent.request.MessageScreenSetSaveRequestData;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.datacomponent.response.GlobalAbstractResponseDataComponent;
import com.fundtech.datacomponent.response.GlobalResponseDataComponentText;
import com.fundtech.datacomponent.response.SimpleContentSharedResponse;
import com.fundtech.datacomponent.response.SimpleResponseDataComponent;
import com.fundtech.datacomponent.response.UserDialog;
import com.fundtech.datacomponent.response.UserResponse;
import com.fundtech.datacomponent.response.layout.MessageButton;
import com.fundtech.datacomponent.response.layout.MessageLayout;
import com.fundtech.datacomponent.response.layout.MessageScreenObject;
import com.fundtech.errors.FTGenericRuntimeException;
import com.fundtech.errors.ProcessErrorConstants;
import com.fundtech.jndi.JmsSessionContext;
import com.fundtech.scl.commonTypes.FndtBatchMsgType;
import com.fundtech.scl.commonTypes.FndtMsgBatchDocument;
import com.fundtech.scl.commonTypes.FndtMsgDocument;
import com.fundtech.scl.commonTypes.FndtMsgExtensionType;
import com.fundtech.scl.commonTypes.FndtMsgHeaderType;
import com.fundtech.scl.commonTypes.FndtMsgSubsetType;
import com.fundtech.scl.commonTypes.FndtMsgType;
import com.fundtech.scl.commonTypes.MFamilyLineType;
import com.fundtech.scl.commonTypes.MsgNotesLineType;
import com.fundtech.scl.commonTypes.OperationalSectionType;
import com.fundtech.scl.commonTypes.PMIDType;
import com.fundtech.scl.commonTypes.PmntTxInfType;
import com.fundtech.scl.commonTypes.ProcessingPersistentInfoType;
import com.fundtech.scl.commonTypes.ResponseDetailsType;
import com.fundtech.spring.SpringApplicationContext;
import com.fundtech.util.BindingParameter;
import com.fundtech.util.ExceptionController;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalDateTimeUtil;
import com.fundtech.util.GlobalUtils;
import com.fundtech.util.GlobalXMLTextUtil;
import com.fundtech.util.TreeCursorInterface;
import com.fundtech.util.datetime.NewASDateTimeUtils;



/**
 * Title: BOMessageHandle Description: Business object for core message handling services Company: Fundtech Israel Author: Inna Ben-Shushan Date:
 * 04/07/07
 *
 * @version 1.0 <br>
 *          <b>Note:</b> For the flow to operate properly, the {@link MessageButtonFactory} must be <br>
 *          &nbsp;&nbsp;&nbsp; populated which requires the 'product.state.webserver' value in the web.xml to be 'DEVELOPMENT_J2EE' <br>
 *          &nbsp;&nbsp;&nbsp; or 'DEPLOYMENT
 */
@Wrap(datasources = { @DataSource(datasourceJndiKey = "active") }, tx = "Bean", jmsResources={@JMS(conFactoryJmsResourceKey="interfaces")})

public class BOMessageHandle extends BOMessage implements PDOConstantFieldsInterface,MessageConstantsInterface
{

	private final static Logger logger = LoggerFactory.getLogger(BOMessageHandle.class);
    private static DAONsf m_daoNsf = DAONsf.getInstance();
	//private static DASInterface m_das = new DAS();

	// trace messages
	private static final String ERROR_MESSAGE = "Message processing had failed";
	private static final String NEW_JOURNAL_GROUP_ACTION_MSG = "User action on message : ";
	private static final String JMS_CONTEXT_INIT_FALIURE_MSG = "JMS resources intialisation failure";

	// Error codes.
	public static final int ERROR_CODE_PAYMENT_ALREADY_PENDS_USER_ACTION = 28725;

	// General constants.
	private static final String DEFAULT_MODULE_ID = "9999";
	private static final String NEW_JOURNAL_CLASS_VALUE = "A";
	private static final String NEW_JOURNAL_FIELD_ID_VALUE = "-1";
	private static final String NEW_JOURNAL_FAULT_VALUE = "O";
	private static final String NEW_JOURNAL_AUDIT_SUB_TYPE_VALUE = "ACTION";
	private static final String NEW_JOURNAL_ERROR_CODE_VALUE = "99"; // NYI change to the correct error code
	private static final String METHOD_PREFIX = "BOMessageHandle.submitMessage - ";
    private static final String WS_DUMMY_SCREENSET_ID = "SERVICES_INTERFACE";
    private static final String INVALID_SWIFT_MESSAGE = "Invalid SWIFT Message";
    private static final String M_MSG_NOTES_GRID = "M_MSG_NOTES_GRID";


	private static DAOCreditDailyLimit m_daoCreditDaily = DAOCreditDailyLimit.getInstance();
	
	public static enum MessageActionType { 
		Validate(0) { 
			public final GlobalResponseDataComponentText execute(final MessageFieldsInputData msgInputData, final BOMessageHandle visitor) {
				//do nothing as the save would be performed at the end of the batch processing 
				//return visitor.saveMessage(msgInputData) ;
				return Submit.execute(msgInputData, visitor) ;
			}
			
			@Override
			public final boolean isTransient() { return true ; } 
		},
		ValidateTemplate(2, MessageActionType.Validate){
			public final boolean isTransient() { return true ; }
		},
		Save(0) { 
			public final GlobalResponseDataComponentText execute(final MessageFieldsInputData msgInputData, final BOMessageHandle visitor) {
				//do nothing as the save would be performed at the end of the batch processing 
				//return visitor.saveMessage(msgInputData) ;
				return new GlobalResponseDataComponentText() ;
			}
		}, 
		Submit(0){ 
			@Override
			public final GlobalResponseDataComponentText execute(final MessageFieldsInputData msgInputData, final BOMessageHandle visitor) {
				return visitor.submitMessage(msgInputData) ;
			} 
		},
		CreateTemplate(2, MessageActionType.Submit) { 
			@Override
			public final GlobalResponseDataComponentText execute(final MessageFieldsInputData msgInputData, final BOMessageHandle visitor) {
				return visitor.submitMessage(msgInputData) ; 
			}
			
			@Override
			protected final PDO newPDO(final String sMID, final Object oAdditionalInput) { 				
				return PaymentDataFactory.newPDO(oAdditionalInput, false/*bTransient*/, true/*bPrimary*/, true/*bConjoinedOrigNCurrentMode*/, sMID);
			}
		};
		
		private static final Map<String, MessageActionType> m_mapReverseValues = new HashMap<String, MessageActionType>() ; 
		private MessageActionType m_enumDelegateActionName ;
		private int m_iMinfPartitionId ; 
		
		static { 
			String sActionName =  null ;
			for(MessageActionType enumSubmitActionType : MessageActionType.values()) { 
				sActionName = (enumSubmitActionType.m_enumDelegateActionName == null ? enumSubmitActionType.name() : enumSubmitActionType.m_enumDelegateActionName.name()) ; 
				
				m_mapReverseValues.put((sActionName + '^' + enumSubmitActionType.m_iMinfPartitionId), enumSubmitActionType) ; 
			}//EO while there are more actions 
		}
				
		private MessageActionType(final int iMinfPartitionId){ this.m_iMinfPartitionId = iMinfPartitionId ;}//EOM
		
		private MessageActionType(final int iMinfPartitionId, final MessageActionType enumDelegateActionName) { 
			this(iMinfPartitionId) ; 
			this.m_enumDelegateActionName = enumDelegateActionName ;
		} 
		
		public static final MessageActionType safeValueOf(final String sActionType, final int iMinfPartitionId) { 
			final MessageActionType enumMessageActionType = m_mapReverseValues.get(sActionType + '^' + iMinfPartitionId) ; 
			return (enumMessageActionType == null ? Submit : enumMessageActionType) ; 
		} 
		
		public GlobalResponseDataComponentText execute(final MessageFieldsInputData msgInputData, final BOMessageHandle visitor) { 
			return (this.m_enumDelegateActionName != null ? this.m_enumDelegateActionName.execute(msgInputData, visitor) : null) ; 
		}
		
		public final PDO newPDO(final String sMID, final boolean bUseMIDforCreation, final Object oAdditionalInput) {
			//if no mid provided or the mid provided was in the context of creation 
			//create a new payment
			PDO pdo = null ;
			
			if (sMID == null || bUseMIDforCreation){
				pdo = this.newPDO(sMID, oAdditionalInput) ; 
			}else{
				pdo = PaymentDataFactory.load(sMID, oAdditionalInput);
			} 
			
			return pdo ; 
		} 
		
		public boolean isTransient() { return false ; }
		
		protected PDO newPDO(final String sMID, final Object oAdditionalInput) { 
			return PaymentDataFactory.newPDO(oAdditionalInput, false/*bTransient*/, true/*bPrimary*/, true/*bConjoinedOrigNCurrentMode*/, sMID);
		}
		
	}//EO enum MessageActionType 

	/**
	 * Constructor.
	 */
	public BOMessageHandle()
	{
	}

	// /////////////////////////////////////////
	// /// START 'handleMessageAction' METHODS /////
	// /////////////////////////////////////////

	/**
	 * Audits an action.
	 */
	@Expose
	@AuthorizeUser(returnWebSessionInfo = true)
	public final UserResponse auditAction(final AuditActionInputData auditActionInputData)
	{
		UserResponse response = new UserResponse();
		final Feedback feedback = response.getFeedback();

		String sActionButtonID = auditActionInputData.getActionID();
		String sMID = auditActionInputData.getMID();

		try
		{
			// Print action.
			if (MESSAGE_BUTTON_PRINT.equals(sActionButtonID))
			{
				MessageScreenObject mso = CacheKeys.UserMessageKey.getSingle(sMID);
				PDO pdo = mso.getData();

				// Clears all PDO data for the future "THIN" save process; the only thing to save for
				// this message is a new error to be entered into NEWJOURNAL table.
				pdo.setThinMode(true);

				// Error code 125: 'User has printed the message'.
				ProcessError processError = new ProcessError(ProcessErrorConstants.UserHasPrintedTheMessage);
				ErrorAuditUtils.setErrors(processError, pdo);

				PaymentDataFactory.batchSave(false, pdo);
			}

			else
			{
				feedback.setFailure();
			}
		}

		catch (Exception e)
		{
			ExceptionController.getInstance().handleException(e, this);
			feedback.setFailure();
		}
		catch (Throwable t)
		{
			ExceptionController.getInstance().handleException(t, this);
			feedback.setFailure();
		}

		finally
		{
			feedback.getDialogs().getLast().setButtons(UserDialog.DIALOG_BUTTON_CLOSE_MSG);

			if (feedback.isSuccessful())
			{
				feedback.setErrorCode(ProcessErrorConstants.MessageOperationCompletedSuccesssfully);
				final BindingParameter bpAction = new BindingParameter(sActionButtonID, DataType.STRING);
				feedback.setErrorVariables(new BindingParameter[] { bpAction });
			}
			else
			{
				feedback.setErrorCode(ProcessErrorConstants.GenericError);
			}
		}

		return response;
	}
	
	/**
	 * 
	 * @param fndtBatchMsg
	 * @return
	 */
	/**
	 * @param fndtBatchMsg
	 * @return
	 */
	@SkipInputValidation
	//@AuthorizeUser(returnWebSessionInfo = true)
	@Expose
	public Serializable submitMessageService(final Serializable fndtBatchMsg) throws Throwable{

		final FndtBatchMsgType fndtBatchMsgType = (FndtBatchMsgType) fndtBatchMsg;
		final FndtBatchMsgType fndtBatchMsgTypeResponse = FndtBatchMsgType.Factory.newInstance();
		final PmntTxInfType fndtMsgResponseContainer = fndtBatchMsgTypeResponse.addNewFndtPmntTxInf() ;
		
		//extract the D_SKIP_PERSIST_ON_ERROR from the batch header if provided 
		XmlBoolean skipPersistenceOnErrorXbean = null;
		if (fndtBatchMsgType.getFndtHeader() != null) {
			skipPersistenceOnErrorXbean  = fndtBatchMsgType.getFndtHeader().xgetDSKIPPERSISTONERROR() ;
		}
		final boolean bGlobalRollbackOnError = skipPersistenceOnErrorXbean != null && skipPersistenceOnErrorXbean.getBooleanValue() ; 
		
		Feedback feedback = new Feedback()  ;
 		GlobalResponseDataComponentText internalOperationResponse = null ;
		String sMID = null,templateMID = null, screensetId, sButtonId = null, sP_TIME_STAMP = null ; 
		PDO pdo = null;
		FndtMsgHeaderType header = null ; 
		FndtMsgType fndtMsgType = null ;
		FndtMsgExtensionType reqExtn = null, respExtn = null ;  
		MessageFieldsInputData messageFieldsInputData = null ;
		FndtMsgType fndtMsgTypeResponse = null ; 
		FndtMsgDocument transformedOutputFndtMsgRoot = null ;
		boolean bCommit = true, bUseMIDforCreation = false, bCreatePaymentFromTemplate = false, bNewPaymentContext = false;  
		final List<PDO> listAllBatchPDOs = new ArrayList<PDO>(), listPersistentPDOs = new ArrayList<PDO>() ;
		Throwable submitException = null  ;
		XmlObjectBase listMembersContainerXbean = null ;		
		OperationalSectionType operationalSectionType = null ; 
		XmlCursor tidyingCursor = null ;
		MessageActionType enumMessageSubmitAction = null ;
		ProcessingPersistentInfoType persistenceInfoType = null ;
		int iMinfPartitionId = 0 ; 
		PMIDType MIDXbean = null ;
		PaymentFieldInterface timeStampField = null ;
		Map<String, List<PDO>> eventReleiseIndexMap = new HashMap<String, List<PDO>>();
		Map<String, Double> dailyLimitMap = new HashMap<String, Double>();
		final MessageLayoutCache buttonsCache = (MessageLayoutCache) CacheKeys.MiscResoucesKey.getSingle(MessageLayoutCacheInterface.class) ; 
		Button messageButton = null ;
		
		//TODO: retrieve an override output type from the request 
		PaymentType enumSubmitResponsePaymentType = PaymentType.valueOf("MSG_SBMT_OUT") ;

		String incomingMsg = null;
		
		try{
//			System.out.println(Thread.currentThread().getId() + " --> " +"SubmitMsgService --> START --> before loop") ;
			//ThreadBoundCounterUTXWProxy.getStartedInstance() ;
			BOBasic.startTx("[BOMessageHandle.submitMessageService]") ; 
				
			//final List<String> errors = new ArrayList<String>() ; 
			//fndtBatchMsgType.validate(new XmlOptions().setErrorListener(errors)) ; 
			//System.out.println(errors) ;
			
			FndtMsgType[] fndtMsgTypeArr = fndtBatchMsgType.getFndtPmntTxInf().getFndtMsgArray();
			int length = fndtMsgTypeArr.length;
			
			for (int j=0; j< length; j++){
				FndtMsgType currFndtMsgType = fndtMsgTypeArr[j];
				fndtMsgType = currFndtMsgType ;  
				header = fndtMsgType.getHeader();
				
				//TODO: add as a fndt msg to response 
				if(fndtMsgType.getMsg() == null) continue ; 
				
				//copy the message 
				
				if(header != null && (MIDXbean = header.getPMID()) != null) { 
					sMID =  MIDXbean.getStringValue() ; 
					 
					//if the mid was to be used for creation and its length is not valid, 
					if((bUseMIDforCreation = MIDXbean.getForCreation()) && sMID.length() != 16) { 
						//report the error 
						//TODO: should the message be saved regardless ?? 
					}//EO if the mid was to be used for creation
						 
				}else bUseMIDforCreation = false ;  
				
				reqExtn = fndtMsgType.getMsg().getExtn() ; 
				
				screensetId = "SERVICES_INTERFACE" ;
				operationalSectionType = reqExtn.getOperationalSection() ; 
				
				//derive the minf partition id (active/history/template) and the submit action 
				persistenceInfoType = reqExtn.getProcessingPersistentInfo() ;
				iMinfPartitionId = ( persistenceInfoType == null ? 0 : persistenceInfoType.getPISHISTORY()) ;
				
				if(operationalSectionType == null || GlobalUtils.isNullOrEmpty((sButtonId = operationalSectionType.getDBUTTONID()))) { 
					//create a new pdo and set the current mid in it (if provided) 
					//then create a message error					
					pdo = PaymentDataFactory.newPDO(PaymentType.valueOf(PaymentType.PT_PACS_008), true /*bTransient*/, true/*bPrimary*/, false/*bConjoinedMode*/, sMID, iMinfPartitionId == 0 /* is BP flow*/) ; 
					//if(sMID != null) pdo.setMID(sMID) ; 
					//else sMID = pdo.getMID() ;
					
					//ensure that the pdo is not persisted
					pdo.set(D_SKIP_PERSIST_ON_ERROR, true) ;
					
					final ProcessError processError = new ProcessError(ProcessErrorConstants.NoSubmitActionProvided);
					ErrorAuditUtils.setErrors(processError, pdo);
					feedback = ErrorAuditUtils.onError(ProcessErrorConstants.NoSubmitActionProvided, null, sMID) ;
				
				}
				// Check if the button id is valid
                else if( buttonsCache.getCachedComponent(sButtonId) == null ){
                    //then create a message error
                	//CR 112826 Redundant message popup displayed when trying to perform force posting on the message.
                    pdo = PaymentDataFactory.load(sMID) ;
                    pdo.setTransientMode();
                    //ensure that the pdo is not persisted
                   	pdo.set(D_SKIP_PERSIST_ON_ERROR, true) ;
                    final ProcessError processError = new ProcessError( ProcessErrorConstants.SubmitActionNotValid );
                    ErrorAuditUtils.setErrors(processError, pdo );
                    feedback = ErrorAuditUtils.onError( ProcessErrorConstants.SubmitActionNotValid, null, sButtonId );
                }
				else { 
					
					enumMessageSubmitAction = MessageActionType.safeValueOf(sButtonId, iMinfPartitionId) ;
					bNewPaymentContext = (bUseMIDforCreation || sMID == null)  ; 
					
					sP_TIME_STAMP = persistenceInfoType.getPTIMESTAMP();
					//if the payment input related to an existing payment, the p_time_stamp must be provided 
					//else fail the current payment processing 
					
					/*
					 *  P_TIME_STMAP if it is not provided we will use it from the PDO instead of generating error
					 * 
					if(!bNewPaymentContext && (persistenceInfoType == null || 
								GlobalUtils.isNullOrEmpty(sP_TIME_STAMP))) {
						
						pdo = PaymentDataFactory.newPDO(PaymentType.valueOf(PaymentType.PT_PAIN_001), true , false, sMID) ;
						
						pdo.set(D_SKIP_PERSIST_ON_ERROR, true) ;
						
						final ProcessError processError = new ProcessError(ProcessErrorConstants.MissingP_TIME_STAMP);
						ErrorAuditUtils.setErrors(processError, pdo);
						feedback = ErrorAuditUtils.onError(ProcessErrorConstants.MissingP_TIME_STAMP, null, sMID) ;
					}*/
					
										
					
					if(feedback.isSuccessful()) { 
					
						//if the P_TEMPLATE_ID was not null, then the payment is linked to a template in some way. 
						//if the MID is for creation then this is a context of create payment from template
						//else this is an action on a payment which was originally created from template
						templateMID = reqExtn.getProcessingPersistentInfo().getPTEMPLATEMID() ; 
						bCreatePaymentFromTemplate = (templateMID != null && bNewPaymentContext) ;  
						 
						//if create payment from template use the template mid to load the template pdo (would be cloned later) 
						//else use the source mid (sMID) 
						//Note: a load payment operation would already merge the fndtMsgType into the existing data
						pdo = enumMessageSubmitAction.newPDO((bCreatePaymentFromTemplate ? templateMID : sMID), bUseMIDforCreation, fndtMsgType.xmlText(new XmlOptions().setSaveOuter())) ;
										
						//if the pdo is in AUTHEX status (invalid payment log and configure)
						if(pdo.getString(P_MSG_STS).equals(MessageConstantsInterface.MESSAGE_STATUS_AUTHEX)) {
							//configure the feedback to an error
							feedback = ErrorAuditUtils.onError(ProcessErrorConstants.GenericError, feedback, null, String.format("Message %s In Invalid Status %s, aborting processing", sMID, pdo.getString(P_MSG_STS))) ;
							//if the pdo was empty set the D_SKIP_PERSIST_ON_ERROR to true so as to skip persistence 
							if(pdo.isEmpty()) pdo.set(D_SKIP_PERSIST_ON_ERROR, true) ;
						}//EO if the pdo was invalid 
						
						//if the pdo was not new and the input time stamp was provided however it is not the same as the original one, 
						//then the payment was already modified by another entity (concurrency violation) 
						else if(!bNewPaymentContext && StringUtils.isNotEmpty(sP_TIME_STAMP) && !pdo.getOriginalValue(P_TIME_STAMP).equals(sP_TIME_STAMP)) {
							final ProcessError processError = new ProcessError(ProcessErrorConstants.PDOConcurrentViolation);
							ErrorAuditUtils.setErrors(processError, pdo);
							feedback = ErrorAuditUtils.onError(ProcessErrorConstants.PDOConcurrentViolation, null, sMID) ;
							//there is no need to persist the message in this case the it will surely fail, hence set the D_SKIP_PERSIST_ON_ERROR 
							pdo.set(D_SKIP_PERSIST_ON_ERROR, true) ; 
							//replace the timestamp with the original one so as to return it to the user 
							timeStampField = pdo.getField(P_TIME_STAMP) ;
							timeStampField.set(timeStampField.getOriginalValue(), false) ;
						//if the button id does not support creation raise an error 
						}
						// Check if the action is allowed for the current message status
						else if(!isActionAllowedForState( pdo, sButtonId) )
						{
                            // ensure that the pdo is not persisted
                            pdo.set(D_SKIP_PERSIST_ON_ERROR, true);
                            
                            int errCode;

                            // in case of an attempt to cancel an S message which is not in eligible state, 
							// 40102 (CancellationRequestValidationFailure) should be shown
							//
							if(MESSAGE_BUTTON_CANCEL.equals(sButtonId) && pdo.isBulkSubBatchPayment())
							{
								errCode = ProcessErrorConstants.CancellationRequestValidationFailure;
							}
							else
							{
								errCode = ProcessErrorConstants.SubmitActionNotAllowedForState;
							}
							
							ErrorAuditUtils.setErrors(new ProcessError(errCode), pdo);
                            feedback = ErrorAuditUtils.onError(GlobalUtils.GPP_ERROR_PREFIX, errCode, null, sButtonId, PDOConstantFieldsInterface.P_MSG_STS );
                        }						
						
					}//EO if existing payment and no P_TIME_STAMP was provided 
						
					//if there were no validation errors and the payment is to be created from template, perform numerous validations
					///on the template including unmodifiable fields check
					//failures would be added as errors to the pdo as well as configured in the feedback 
					//24/11/2010String templateUnchangedFields = "";
					if(templateMID == null) {
						templateMID = pdo.getString(PDOConstantFieldsInterface.P_TEMPLATE_MID);
					}
					if(feedback.isSuccessful() && templateMID != null) {
						//save all template Unchanged Fields
						//24/11/2010templateUnchangedFields  = pdo.getNSetTemplateUnchangedFields();
						pdo = this.doTemplateOperationsPriorToSubmit(
							pdo /*template pdo or payment linked to the template on a subsequent action*/, 
							sMID /*source (input) MID */,
							bCreatePaymentFromTemplate, 
							feedback
						  ) ; 
					}
					//ensure that the mid is populated in event of new or create payment from template scenarios 
					sMID = pdo.getMID() ; 
//					this monitor field should set D_IS_CONT_FLOW_UNTILL_HANDOF to true in set basic properties service when executed in business flow selector,
//					therefore in this scenario this field should be always empty.
					pdo.set(PDOConstantFieldsInterface.MU_IS_CONTINUE_UNTIL_HANDOFF, MessageConstantsInterface.MONITOR_FLAG_X);
					// Always executes set basic properties.
					Feedback feedbackSetBasicProperties = BOProxies.m_setBasicPropertiesLogging.setBasicProperties(Admin.getContextAdmin(), sMID);

					if(pdo.isEnrichMode()){
						setDepartmentForEnrichment(pdo);
					}
					
					//if the given payment was template related and 
					//all its validations have passed continue to the actual submit operation
					if (feedback.isSuccessful() && feedbackSetBasicProperties.isSuccessful()){
					
						messageFieldsInputData = new MessageFieldsInputData(sMID, screensetId);
		
						messageFieldsInputData.put(FRAGMENT_ID_KEY, sButtonId);
						messageFieldsInputData.put(IS_SERVICE, Boolean.TRUE);
						
						// The D_BUTTON_ID value is needed for the onServerChange event handling see handleScreenSet
						FieldsContainer userModifiedFields = createUserModifiedFields(pdo);
						userModifiedFields.addField(WS_DUMMY_SCREENSET_ID + GlobalConstants.DOT + sButtonId, sButtonId);
						
						messageFieldsInputData.put(USER_QUALIFIED_MODIFIED_FIELDS_KEY, userModifiedFields);
						
//						if payment field exist then and its value is null, then user meant to delete the template unchanged fields, therefore, set unchanged fields as empty string
						String unchangedFields = null;
						if (pdo.getField(PDOConstantFieldsInterface.D_TEMPLATE_UNCHANGED_FIELDS) != null)
						{
							unchangedFields = pdo.getString(D_TEMPLATE_UNCHANGED_FIELDS) != null ? pdo.getString(D_TEMPLATE_UNCHANGED_FIELDS) : GlobalConstants.EMPTY_STRING; 
						}
						
						
						messageFieldsInputData.put(TEMPLATE_UNCHANGED_FIELDS_KEY, unchangedFields );
						
						//24/11/2010if(!templateUnchangedFields.equals("")) {
						//	messageFieldsInputData.put(TEMPLATE_UNCHANGED_FIELDS_KEY, templateUnchangedFields );
						//}
						//perform the actual operation 
						
						internalOperationResponse = enumMessageSubmitAction.execute(messageFieldsInputData, this) ;
						pdo = Admin.getContextPDO();

						//Do post processing for enrich
						if(pdo.isEnrichMode()){
							pdo = performEnrichPostProcessing(pdo);
						}
						
						sMID = pdo.getMID();
						
						String eventReleaseIndex = pdo.getString(PDOConstantFieldsInterface.D_EVENT_RELEASE_INDEX);
						String messageSts = pdo.getString(PDOConstantFieldsInterface.P_MSG_STS);
						
//						Check if  PDO.D_EVENT_RELEASE_INDEX is populated and P_MSG_STS = 'WAITE_RTR' (??? I don't like specifying hard coded a message status) then 
//						add to an hashmap (eventRelease) the D_EVENT_RELEASE_INDEX if not already exists 
//						Add the PDO to the list of PDOs under this D_EVENT_RELEASE_INDEX

						if (!GlobalUtils.isNullOrEmpty(eventReleaseIndex) && MessageConstantsInterface.MESSAGE_STATUS_WAIT_RTR.equals(messageSts))
						{
							if (!eventReleiseIndexMap.containsKey(eventReleaseIndex)) eventReleiseIndexMap.put(eventReleaseIndex, new ArrayList<PDO>());
							eventReleiseIndexMap.get(eventReleaseIndex).add(pdo);
						}
						
//						IF P_MSG_STS was changed not to 'REPAIR', 'PEND_APPROVE' then 
//						Invoke a new rule to decide if Company Limit check is required
//						If Action was returned and it is not STOP then 
//						Add the P_CUST_BASE_AMT  to a totalCustBaseAmt in a new Hashmap (dailyLimit) by valueDate = X_STTLM_DT  
						
						boolean isOrigCustomerHasLimit = pdo.getNSetORIG_INITIATING_CUSTOMER() != null && pdo.getNSetORIG_INITIATING_CUSTOMER().getDailyCdtXferLimit() != null 
												&& pdo.getNSetORIG_INITIATING_CUSTOMER().getDailyCdtXferLimit() > 0; 
//						boolean isMsgStsValid = MessageConstantsInterface.MESSAGE_STATUS_WAIT_RTR.equals(messageSts) || MessageConstantsInterface.MESSAGE_STATUS_WAIT_ACK.equals(messageSts)
//														|| MessageConstantsInterface.MESSAGE_STATUS_COMPLETE.equals(messageSts)
//														|| MessageConstantsInterface.MESSAGE_STATUS_WAIT_CONFIRMATION.equals(messageSts)
//														|| MessageConstantsInterface.MESSAGE_STATUS_SCHEDULE.equals(messageSts)
//														|| MessageConstantsInterface.MESSAGE_STATUS_WAIT_RELEASE.equals(messageSts);		

						boolean isFlowCompletedSuccessfully = pdo.getBoolean(PDOConstantFieldsInterface.D_COMPLETED_MANUAL_HANDLING) != null 
																	&& pdo.getBoolean(PDOConstantFieldsInterface.D_COMPLETED_MANUAL_HANDLING); 						
						boolean isMsgStsCanceled = MessageConstantsInterface.MESSAGE_STATUS_CANCELED.equals(pdo.getString(P_MSG_STS));
						boolean isLimitUtilized = MessageConstantsInterface.MONITOR_FLAG_PROCESSED.equals(pdo.getString(PDOConstantFieldsInterface.MF_LIMIT_UTILIZED));
						boolean isTemplate = pdo.getInteger(PDOConstantFieldsInterface.P_IS_HISTORY) != null && pdo.getInteger(PDOConstantFieldsInterface.P_IS_HISTORY) == 2; 
						
//						credit daily update should be performed only if flow completed successfully and it is not template and customer has limit
//						or 
//						payment was canceled and limit was already utilized, in this case the amount should be subtracted.
						if (!isTemplate && (isOrigCustomerHasLimit && isFlowCompletedSuccessfully && !isLimitUtilized)
								||(isMsgStsCanceled && isLimitUtilized))
						{
							RuleResults ruleResults=m_internalRuleExecutionLogging.executeRule(Admin.getContextAdmin(), MessageConstantsInterface.RULE_TYPE_ID_COMPANY_LIMIT_CHECK,null,pdo.getMID()
									, new String[]{pdo.getString(PDOConstantFieldsInterface.P_OFFICE), GlobalConstants.DEFAULT_SERVER_OFFICE_NAME});
							
							if (ruleResults.getResults().size() > 0 && ruleResults.getCompletionCode() != RuleResults.CompletionCode.STOP)
							{
								Date sttlmDate = pdo.getDate(PDOConstantFieldsInterface.X_STTLM_DT_1B);
								if (sttlmDate != null)
								{
									double custBaseAMount = pdo.getDecimal(PDOConstantFieldsInterface.P_CUST_BASE_AMT) != null ? 
											pdo.getDecimal(PDOConstantFieldsInterface.P_CUST_BASE_AMT).doubleValue() : 0;
											
									String key = GlobalDateTimeUtil.getFormattedDateString(sttlmDate, GlobalDateTimeUtil.STATIC_DATA_DATE)
															+GlobalConstants.POWER_SIGN+pdo.getString(PDOConstantFieldsInterface.P_ORG_INITG_PTY_CUST_CD); 
									double prevAmount = dailyLimitMap.containsKey(key) ? dailyLimitMap.get(key) : 0;
									
									dailyLimitMap.put(key, isMsgStsCanceled ? (prevAmount - custBaseAMount) : (prevAmount + custBaseAMount));		
								}
								pdo.set(PDOConstantFieldsInterface.MF_LIMIT_UTILIZED, MessageConstantsInterface.MONITOR_FLAG_PROCESSED);
							}
						}
							
						
						//internalOperationResponse = this.submitMessage(messageFieldsInputData, true /*bOpenTransaction*/, pdo);
						feedback = internalOperationResponse.getFeedback();
						
					}//EO if the feedback was successful					
					else
					{
						// In case of an invalid office received in the request and identified in the set basic properties stage,
						// throws flow execption for rollback.
						if(ProcessErrorConstants.InvalidOffice == feedbackSetBasicProperties.getErrorCode())
						{
							throw new FlowException(feedbackSetBasicProperties.getErrorText());
						}
						else if(ProcessErrorConstants.ServiceFailure == feedbackSetBasicProperties.getErrorCode())
						{
							throw new FlowException(feedbackSetBasicProperties.getErrorText());
						}
					}
				}//EO else if the button id was provided
				
				//in any event (success or failure) add the pdo to a list so that at the end of the operation it could be removed from local 
				//cache and depending on the outcome of the service, propagated to the distributed cache or not
				listAllBatchPDOs.add(pdo) ;
				
				/*//TODO: as there is currently no distinction between technical and business exception, 
				//there is no way of determining when to abort and when to continue;
				//Hence, as a temp workaround, only uncaught exceptions would cause the process to abort  
				transformedOutputFndtMsgRoot = (FndtMsgDocument) PaymentDataFactory.transformToXml(sMID,  enumSubmitResponsePaymentType, XmlLocationType.XML_MSG, nullmapCustomisations, null) ;
				fndtMsgTypeResponse = transformedOutputFndtMsgRoot.getFndtMsg() ;     
				
				fndtMsgResponseContainer.addNewFndtMsg() ; 
				fndtMsgResponseContainer.setFndtMsgArray(i++, fndtMsgTypeResponse);*/
						
				//there was a template validation or submit operation failure of some sort
				if(!feedback.isSuccessful()) { 
					
					if( (submitException = feedback.getException()) != null && (!(submitException instanceof BusinessException) || (submitException instanceof PDOException)) ) { 
						throw submitException ; 
					}//EO if the exception was technical rather than business 
					else { 
						
						logger.error("A Business Error had occured during The Submit Operation {} for MID {}; continuing to process next message", feedback.getErrorText(), sMID);
						
						//if the global skip persistence is set to true, set the commit to false so that there would be no 
						//commit but continue to process all other payments as their individual response is still required 
						if(bGlobalRollbackOnError) { 
							logger.warn("The All-or-Nothing mode is set to true (flag SKIP_PERSIST_ON_ERROR), will rollback all message actvities at the end of the " +
									"process") ;
							bCommit = false ; 
						}//EO if the all-or-nothing flag was set to true  
						
						//if the SKIP_PERSIST_ON_ERROR flag is set on the level of the given message, 
						//ensure that the pdo would not be cached by setting the IsGlobalPDO flag to false 
						if(pdo.getBoolean(D_SKIP_PERSIST_ON_ERROR)!= null && pdo.getBoolean(D_SKIP_PERSIST_ON_ERROR)) { 
							pdo.setIsGlobalPDO(false) ; 
						}else if(!enumMessageSubmitAction.isTransient()) { 
							//as the D_SKIP_PERSIST_ON_ERROR is false, the pdo should be persisted if the enumMessageSubmitAction is not transient (e.g. validate)
							//inspite of the error add the pdo to the save list 
							listPersistentPDOs.add(pdo) ;							
						}//EO else if the pdo had not been marked with the fail-on-error flag 						
												
						//mark the pdo as 
						feedback.setSuccess() ; 
					}//EO else if business error 
				}//EO if there was an error 
				else if(!enumMessageSubmitAction.isTransient()) {   
					
					//add the pdo to the save list even if the bCommit flag is already set to false
					//as the list would simply be discarded at the end 
					listPersistentPDOs.add(pdo) ;			
					
				}//EO else if there no appearant error 
				
				//clear resources for next iteration 
				sMID = sButtonId = templateMID = sP_TIME_STAMP = null ;
				MIDXbean = null ;
				bCreatePaymentFromTemplate = false; 
				bNewPaymentContext = false; 
			}//EO while there are more messages 
			
			if (feedback.isSuccessful())
			{
				handleDailyCreditAndEventMaps(dailyLimitMap, eventReleiseIndexMap, feedback);
			}
						
		}catch (FlowException ex){
				ExceptionController.getInstance().handleException(ex, this);
		    	final String sErrorText = GlobalUtils.getErrorMessage(ex) ;
				feedback = ErrorAuditUtils.onError(pdo.getMID(), ex.getErrorCode(), feedback, sErrorText, sErrorText, GlobalUtils.GPP_ERROR_PREFIX);
				bCommit = false ; 
		}catch (Throwable t){
			feedback = ErrorAuditUtils.onError(t, feedback);
			ExceptionController.getInstance().handleException(t, this);
			
			if(t instanceof PDOException){
				PDO pdeException = ((PDOException)t).getPdo();
				if(pdeException == null ){
				{
						if(t.getMessage()!=null){
							feedback.setErrorText(t.getMessage());
						}else{
							feedback.setErrorText(INVALID_SWIFT_MESSAGE);
						}
					}
				}
				if(pdeException!=null && pdeException.getListMSGERR()!=null && pdeException.getListMSGERR().size()>0){
					String sErrorText = populateMessageErrors(pdeException);
					feedback.setErrorText(sErrorText);
				}else{
					if(((PDOException)t).getErrorDescription()!=null){
						feedback.setErrorText(((PDOException)t).getErrorDescription()	);
					}else{
						if(t.getMessage()!=null){
							feedback.setErrorText(t.getMessage());
						}else{
							feedback.setErrorText(INVALID_SWIFT_MESSAGE);
						}
					}
				}
			}
			bCommit = false ; 
		}finally{
			
			//if the bCommit is set to false, rollback the Tx as well as remove all pdos from local cache without propegating them 
			//to the distributed one
			final String sFinilizationTraceMsg = (bCommit ? "Successful termination, persisting payments."  : 
						"An error had occured during processing the payments, rolling back Tx and discarding modifications - No payments would be persisted" ) ; 
			logger.info(sFinilizationTraceMsg); 
				
			try{ 
				//if bCommit was true and there were payments to persist, persist all pdos in the listPersistentPDOs
				// Do not allow batchSave for Cancellation requests. Otherwise, it will create new minf entry with pseudo PDO
				if(bCommit && !listPersistentPDOs.isEmpty() && !MESSAGE_BUTTON_CANCEL.equals(operationalSectionType.getDBUTTONID())) 
					PaymentDataFactory.batchSave(false/*bRemove from cache*/, 
							DASInterface.MIDBasedPDOListSorter, 
							listPersistentPDOs.toArray(new PDO[]{})) ;
				
			}catch(Throwable t) { 
					ExceptionController.getInstance().handleException(t, this);
					feedback = ErrorAuditUtils.onError(t, feedback);
					// set the bCommit to false
					bCommit = false;
			}finally{ 
	        	//iterate over all the pdos in the listAllPdos and for each determine whether to propegate to distributed cache 
				//based on whether the bCommit = false || pdo.isGlobal = false (business error on individual payment) 
				//Note: add all linked pdos to the to be release list so as to remove them from local cache as well 
				//Note: As no locks were performed here, there is no need to set the pdos in thin mode and to send 
				//them to the distributed cache to be  released 
				try{
					// Prepare data to log in MESSAGE_EXTERNAL_INTERACTION table the web response details
					//
		        	DAODebulkingProcess	daoDebulkPrc = DAODebulkingProcess.getInstance();
		        	Connection conn = daoDebulkPrc.getConnection();
					PreparedStatement psIns = conn.prepareStatement(DAS.MESSAGE_EXTERNAL_INTERACTION_INSERT_STATEMENT);

					List <PDO> messagesToRelease = new ArrayList<PDO>();
					
					int i = 0;
					for(PDO aPdo : listAllBatchPDOs) { 
						if(!bCommit) aPdo.setIsGlobalPDO(false) ;
						//rertieve all linked pdos associated with the given pdo 
						//and if the commit is false or the pdo's is global is  false 
						//pass false to the set is global else pass null as not to affect the current setting
						messagesToRelease.add(aPdo);
						aPdo.addLinkedMsgsToList(messagesToRelease, (!bCommit || !aPdo.isGlobalPDO() ? false : null)/*bIsGlobal*/) ; 
						
						try{
							//if the feedback indicate success, add the current pdo to the response 
							transformedOutputFndtMsgRoot = (FndtMsgDocument) PaymentDataFactory.transformToXml(aPdo.getMID(),  enumSubmitResponsePaymentType, XmlLocationType.XML_MSG, null/*mapCustomisations*/, null) ;
							fndtMsgTypeResponse = transformedOutputFndtMsgRoot.getFndtMsg() ;     
							fndtMsgResponseContainer.addNewFndtMsg() ; 
							fndtMsgResponseContainer.setFndtMsgArray(i++, fndtMsgTypeResponse);
							
							// Log in MESSAGE_EXTERNAL_INTERACTION table the web response details
							//
							LogInMessageExternalInteraction(psIns, aPdo.getMID(), transformedOutputFndtMsgRoot.xmlText());
						}catch(Throwable t) { 
							ExceptionController.getInstance().handleException(t, this) ; 
							this.configureErrorResponse("an Error had occured while transforming pdo for response. Please consult the traces", feedback, true) ; 
						}
						
					}//EO while there are more pdos to remove from local cache
					
					psIns.executeBatch();
					
					CacheKeys.ProcessPDOKey.removeFromLocalAndPropagateToRemote(messagesToRelease)  ;
				}catch(CacheException ce) { 
					ExceptionController.getInstance().handleException(ce, this) ; 
					this.configureErrorResponse("an Error had occured while releasing pdo locks. Please consult the traces", feedback, true) ;
					//ensure rollback 
					bCommit = false ; 
				}
				
				try{ 
					//ThreadBoundCounterUTXWProxy.closeTx(bCommit) ;
					BOBasic.closeTx("[BOMessageHandle.submitMessageService]", bCommit) ; 
					
					// This case supposed to work for unsuccessfull feedback, caused also by previous exception throw.
					// I'm doing it after the transaction was closed already, because it probably was rolled back, so
					// a special transaction will be opened here
					//
					if(feedback.isSuccessful() == false) 
					{ 
						FndtMsgBatchDocument msgBatchDocument = FndtMsgBatchDocument.Factory.newInstance();
						final FndtBatchMsgType fndtResponseBatchMsgType = msgBatchDocument.addNewFndtMsgBatch() ; 
						final ResponseDetailsType responseDetails = fndtResponseBatchMsgType.addNewResponseDetails() ; 
						
						responseDetails.setReturnCode(feedback.getErrorPrefix() + Integer.toString(feedback.getErrorCode())) ; 
						responseDetails.setDescription(feedback.getErrorText()) ;
						
						BOBasic.startTx("[BOMessageHandle.submitMessageService]") ; 

						// Prepare data to log in MESSAGE_EXTERNAL_INTERACTION table the web response details
						//
			        	DAODebulkingProcess	daoDebulkPrc = DAODebulkingProcess.getInstance();
			        	Connection conn = daoDebulkPrc.getConnection();
						PreparedStatement psIns = conn.prepareStatement(DAS.MESSAGE_EXTERNAL_INTERACTION_INSERT_STATEMENT);

						// Log in MESSAGE_EXTERNAL_INTERACTION table the web response details
						//
						LogInMessageExternalInteraction(psIns, feedback.getErrorMID(), msgBatchDocument.xmlText());
						psIns.executeBatch();
						BOBasic.closeTx("[BOMessageHandle.submitMessageService]", true) ; 
					}//EO if the response was that of a feedback
				}catch(Throwable rt) { 
					ExceptionController.getInstance().handleException(rt, this);
					feedback = ErrorAuditUtils.onError(rt, feedback);

					//execute the pdo compensation policy (cache removal) 
					final PDO[] arrPdos = new PDO[listAllBatchPDOs.size()] ;
					listAllBatchPDOs.toArray(arrPdos) ; 
					
					try{ 
						PaymentDataFactory.performFailureCompensation(arrPdos) ;
					}catch(Throwable ct) { 
						ExceptionController.getInstance().handleException(ct, this);
						feedback = ErrorAuditUtils.onError(ct, feedback);
					}//EO compensation exception 
					
				}//EO rollback tx catch block 
			}//EO inner tx release 
		}//EO finally 
			
		return (Serializable) (feedback.isSuccessful() ? fndtBatchMsgTypeResponse : feedback) ;
		
	}//EOM 
	
	private void LogInMessageExternalInteraction(PreparedStatement psIns, String mid, String content) throws SQLException
	{
		String timestamp = GlobalDateTimeUtil.getSimpleDateFormatByFormat(GlobalDateTimeUtil.STATIC_DATA_TIME_STAMP).format(new Date());
		String uid = mid + GlobalConstants.POWER_SIGN + "WEB_SERVICE_RESPONSE" + GlobalConstants.POWER_SIGN
				+ "Response" + GlobalConstants.POWER_SIGN + timestamp;
		int indx = 1;

		GlobalUtils.setObject(psIns, indx++, mid);
		GlobalUtils.setObject(psIns, indx++, "WEB_SERVICE_RESPONSE");
		GlobalUtils.setObject(psIns, indx++, "N/A");
		GlobalUtils.setObject(psIns, indx++, "N/A");
		GlobalUtils.setObject(psIns, indx++, "Response");
		GlobalUtils.setObject(psIns, indx++, content);
		GlobalUtils.setObject(psIns, indx++, "");
		GlobalUtils.setObject(psIns, indx++, "...");
		GlobalUtils.setObject(psIns, indx++, "");
		GlobalUtils.setObject(psIns, indx++, timestamp);
		GlobalUtils.setObject(psIns, indx++, uid);
		GlobalUtils.setObject(psIns, indx++, GlobalConstants.REC_STATUS_ACTIVE);
		GlobalUtils.setObject(psIns, indx++, 0);
		psIns.addBatch();
	}
	
	private String populateMessageErrors(PDO pdo){
		StringBuilder errorMsg = new StringBuilder();
		List<Msgerr> msgErr = pdo.getListMSGERR(); 
		if(msgErr!=null && msgErr.size()>0){
			for (Msgerr err : msgErr) {
				String sErrorParams = err.getErrorParams();
		        String description = GlobalConstants.getErrorAuditUtils().loadErrorAuditText(err.getErrorCode(), sErrorParams,
		        		pdo.getString(PDOConstantFieldsInterface.P_OFFICE), GlobalConstants.EMPTY_STRING, null, false);
		        errorMsg.append(description).append(GlobalConstants.NEWLINE);
		        errorMsg.append(GlobalConstants.COMMA);
			}
		}
		return errorMsg.toString();
	}
	
	private void setDepartmentForEnrichment(PDO pdo){
		BORuleExecution boRuleExecution = new BORuleExecution();
		   String[] arrObjectIDs = new String[]{pdo.getString(P_OFFICE)};
		   // Run Rule
		   try {
			List<RuleResult> listRuleResults = 
			   	boRuleExecution.executeRule(MessageConstantsInterface.RULE_TYPE_ID_DEPARTMENT, null,	pdo.getMID(), arrObjectIDs).getResults();
			if(!listRuleResults.isEmpty()){
			   	for (RuleResult result : listRuleResults){
			   		String sDepartmentCode = result.getAction();
			   		pdo.set(P_DEPARTMENT,sDepartmentCode);
			   		logger.info("Department is set to : {} ",sDepartmentCode);
			   	}
			}
		} catch (Throwable e) {
			logger.error("Could not set department for Enrichment",e);
		}
	}
	
	private PDO performEnrichPostProcessing(PDO pdo){
				try {
					
					if(StringUtils.isNotEmpty((String)pdo.get(GlobalConstants.CUTOFF_LIST))){
						List<Msgerr> msgErr = pdo.getListMSGERR();
						Msgerr err = new Msgerr();
						err.setErrorCode(new Long(ProcessErrorConstants.MISSED_CUTOFF));
						err.setTIME_STAMP(new Date().toString());
						msgErr.add(err);
						pdo.setListMSGERR(msgErr);
					}
					
					if(pdo.getString(D_COPY_DIRECT_MID)!=null){
						PaymentFieldInterface field  = null;
						List<Msgerr> prevMsgErr = pdo.getListMSGERR();
						String prevMur = pdo.getString(OX_MSG_USER_REF);
						String prevMsgSubType = pdo.getString(P_MSG_SUB_TYPE);
						int iLength = pdo.countOccurrences(PDOConstantFieldsInterface.X_INSTR_NXT_AGT_OTHER_CODES);
						if(iLength>0){
							field  = pdo.getField(PDOConstantFieldsInterface.X_INSTR_NXT_AGT_OTHER_CODES);
						}

						//switch PDO's: From Cover to the Direct
						pdo = PaymentDataFactory.load(pdo.getString(D_COPY_DIRECT_MID));
						pdo.setEnrichMode(); 
						pdo.setListMSGERR(prevMsgErr);
						pdo.set(X_MSG_USER_REF, prevMur);
						if(field!=null){
							pdo.setPaymentField(field);
						}
						if(StringUtils.isNotEmpty(prevMsgSubType)){
							pdo.set(P_MSG_SUB_TYPE, prevMsgSubType);
						}
					}
					if(StringUtils.isEmpty(pdo.getString(X_INSTD_AGT_BIC_2AND))){
						logger.info(X_INSTD_AGT_BIC_2AND + " is null, replacing with D_INSTD_AGT_BIC_2AND");
						pdo.set(X_INSTD_AGT_BIC_2AND,pdo.get(OX_INSTD_AGT_BIC_2AND));
						
						String originalReciverBic4 = pdo.get(OX_INSTD_AGT_BIC_2AND).toString().substring(0,4);
						String firstInchainBic = pdo.getString(D_FIRST_IN_CDT_CHAIN_BIC);
						if (GlobalConstants.dummyBics.contains(originalReciverBic4) && StringUtils.isNotEmpty(firstInchainBic) && StringUtils.isNotEmpty(pdo.getString(P_CDT_CUST_CD))) {
							//QC # 16406 : CCT - A EUR Payment to an ABA fails Enrichment with a Technical Error. 
							if(firstInchainBic.length() != 9){
								pdo.set(X_INSTD_AGT_BIC_2AND,pdo.get(D_FIRST_IN_CDT_CHAIN_BIC));
							}
						}
					}
					
					pdo.set(X_ENRICH_MSG, PaymentDataFactory.formatPDO(pdo));
			}
			 catch (BusinessException e) {
				logger.error("Error occured during performEnrichPostProcessing",e);
			}
		return pdo;
	}
	
	private void deleteEnrichmentPositionfigure(String mid , Integer partitionId){
		try {
			DAOPositionKeeping dao = (DAOPositionKeeping) SpringApplicationContext.getBean("DAOPositionKeeping");
			dao.delPreviousMessagePositionFigure(mid, partitionId);
		} catch (Throwable e) {
			logger.error("Could not delete position figure for enrichment mid {}",mid);
		}
	}
	
	// Check if the requested action is allowed for the current state of the message
	private boolean isActionAllowedForState( PDO pdo, String sButtonId ) throws Exception {
	    String sMID = pdo.getMID();
	    String sButtonIdInFieldSet = WS_DUMMY_SCREENSET_ID + "." + sButtonId;
	    
	    // Execute the filterset selection rule to find which filtersets are valid
	    String[] arrObjectIDs = new String[] { pdo.getString(P_OFFICE), ServerConstants.DEFAULT_SERVER_OFFICE_NAME };
	    List<RuleResult> listRuleResults = m_internalRuleExecutionLogging.executeRule(
	        Admin.getContextAdmin(), MessageConstantsInterface.RULE_TYPE_ID_MESSAGE_FIELDS_SETS_SELECTION, 
	        null, sMID, arrObjectIDs).getResults();
	    logger.info( "isActionAllowedForState(),Action:" + sButtonId + ",State:" + pdo.getString( "P_MSG_STS"  ) + ",Matching FieldSet Rules count:" + ( listRuleResults != null ?listRuleResults.size():0 ));
	    // Loop thru the valid filtersets
	    boolean bButtonFound = false;
	    for( int i=0; i< listRuleResults.size(); i++ ){
	        RuleResult currRuleResult = listRuleResults.get(i);
	        String fieldSetId = currRuleResult.getAction();
	        // retrieve the fieldset from the cache
	        // TODO : Assuming that its the SERVICES_INTERFACE screen-set only
	        MessageLayoutCacheInterface messagelayoutCache = (MessageLayoutCacheInterface) 
	           CacheKeys.MiscResoucesKey.getSingle( MessageLayoutCacheInterface.class);
	        Map<String, MessageComponent> fieldSet = messagelayoutCache.getFieldset( fieldSetId, WS_DUMMY_SCREENSET_ID);
	        // Check if the requested button id is amongst the enabled buttons in the fieldset
	        if( fieldSet != null && fieldSet.size() > 0 ){
	            MessageComponent mscomp = fieldSet.get( sButtonIdInFieldSet );
	            // Break when the button is found
	            // TODO : What if it is disabled in another fieldset ?
	            if( mscomp != null && mscomp.getState() == 1 ){
	                bButtonFound = true;
	                break;
	            }
	        }
	    }// end loop thru filtersets
	    logger.info( "isActionAllowedForState():result:" + bButtonFound );
        return bButtonFound;
	}

	
	private void handleDailyCreditAndEventMaps(Map<String, Double> dailyLimitMap, Map<String,List<PDO>> eventReleaseMap, Feedback feedback) throws Throwable
	{
		if (dailyLimitMap != null && dailyLimitMap.size() > 0)
		{
			Iterator<String> iter = dailyLimitMap.keySet().iterator();
			String key;
			String custCode;
			String businessDate ;
			while (iter.hasNext())
			{
				key = iter.next();
				String[] arr = key.split("\\"+GlobalConstants.POWER_SIGN);
				int[] updatedRows = new int[1];
				if (arr != null && arr.length == 2)
				{
					businessDate = arr[0];
					custCode = arr[1];
					Customrs orgCustomer = CacheKeys.customrsCCKey.getSingle(custCode);
					
					m_daoCreditDaily.updateCDT_DAILY_TRANSFER_Table(dailyLimitMap.get(key).toString(), custCode, businessDate,orgCustomer.getDailyCdtXferLimit(),false,updatedRows);
					
					if (updatedRows[0] == 0) throw new FlowException(ProcessErrorConstants.DailyLimitWasExhausted);
				}
			}
		}
		
		if (eventReleaseMap != null && eventReleaseMap.size() > 0)
		{
			Iterator iter = eventReleaseMap.values().iterator();
			
			while(iter.hasNext())
			{
				List<Serializable> pdoList = (List<Serializable>)iter.next();
				feedback.setFeedback(m_rtrComplete.getExternalRTR(Admin.getContextAdmin(), pdoList.toArray(new Serializable[pdoList.size()]) , RTROperator.GetRTRBook.name()));
				
				if (!feedback.isSuccessful()) throw new FlowException(feedback);
			}
		}
	}
	
	private PDO doTemplateOperationsPriorToSubmit(final PDO templateOrLinkedPayment,  
			String sSourceMID,  final boolean bCreatePaymentFromTemplateContext, 
			final Feedback responseFeedback) { 
		 
		final String sTemplateOrLinkedPaymentMID = templateOrLinkedPayment.getMID() ; 
		final String sTemplateType = templateOrLinkedPayment.getString(P_TEMPLATE_TYPE) ;
		
		//if the template type is P (full) load the template unmodifiable fields list from persistence 
		//stored against the template MID first
		//then check whether any of said fields have been modified by the merge operation
		String sTemplateUnmodifiableFieldsList = null ;  
		if("P".equals(sTemplateType) && 
				!(sTemplateUnmodifiableFieldsList = templateOrLinkedPayment.getNSetTemplateUnchangedFields()).isEmpty()
			) { 
			
			final List<String> changedFieldsList = new ArrayList<String>();
			
			PaymentFieldInterface paymentField = null ; 
			//use the raw fields data map rather than the getField method as the latter would layzilly create 
			//the field if not present in the underlying mapPDOFields
			final Map<Object, PaymentFieldInterface> mapPDOFields = templateOrLinkedPayment.getDataMap() ; 
			
			int iIndexOfOccurrenceParenthesis = -1, iOccurrence = -1   ;
			
			for(String sElementId : sTemplateUnmodifiableFieldsList.split(COMMA)){ 
				
				if((iIndexOfOccurrenceParenthesis = sElementId.indexOf('[')) != -1) { 
					iOccurrence = Integer.parseInt(sElementId.substring(iIndexOfOccurrenceParenthesis+1, sElementId.length()-1)) ; 
					sElementId = sElementId.substring(0, iIndexOfOccurrenceParenthesis) ; 
					
				}//EO if there is a multi occurrence index 
				
				paymentField = mapPDOFields.get(sElementId) ; 
				
				//if the payment field was not empty and the orig valuea is not the same as the updated value 
				//add the field to the modified fields list 
				if(paymentField == null) continue;
				//else 
				
				if(iIndexOfOccurrenceParenthesis == -1 ? paymentField.hadChanged() : 
					paymentField.hadChanged(sElementId, iIndexOfOccurrenceParenthesis)) changedFieldsList.add(sElementId) ;
				
			}//EO while there are more unmodifiable logical fields 
			
			//if there one or more of the unmodifiable fields have changed raise an error and return 
			if (!changedFieldsList.isEmpty())  
				ErrorAuditUtils.setError(ProcessErrorConstants.MessageCannotChangeFields, sTemplateOrLinkedPaymentMID, 
						responseFeedback, changedFieldsList.toArray(new String[changedFieldsList.size()]), null);
				
		}//EO if the template was in P MODE 
		
		PDO resultPDO = null ;
		
		//determine whether this is a create payment from template context as the current pdo is in fact the template. 
		//Clone the payment first as validation errors should not be associated with the template pdo.  
		if (bCreatePaymentFromTemplateContext) { 
			
			//extract the message status prior to the clone operation as it would simply replace the status and MID 
			//in the current templateOrLinkedPayment reference rather then create a new deep copy of the latter 
			final String sTemplateMsgStatus = templateOrLinkedPayment.getString(PDOConstantFieldsInterface.P_MSG_STS) ;
			
			//extract all message errors stored in the template pdo first (currently only from unmodifiable fields validation
			//and add to the cloned pdo after the clone. this is done as the clone operation would 
			//clear the list 
			//if there is not source MID, create onen now so as to be able to modify the msg error related mid 
			sSourceMID = (sSourceMID == null ? GlobalUtils.generateGUID() : sSourceMID) ; 
			final List<Msgerr> listMsgErrors =  new ArrayList<Msgerr>() ; 
			final List <Msgerr> templateMsgErrors = templateOrLinkedPayment.getListMSGERR() ;
		
			if(templateMsgErrors != null) { 
				for(Msgerr msgError : templateMsgErrors) { 
					msgError.getId().setMid(sSourceMID) ; 
					listMsgErrors.add(msgError) ; 
				}//EO while there are more template message errors  
			}//EO if templateMsgErrors was not null 
			
			//clone the template prior to the validations as the error messages should be injected into the new payment 
			//Note: the clone shall only invoke a local cache get as the template was already fetched 
			//from distributed cache (templateOrLinkedPayment) 
			XmlObject tempDoc = RECEIVED_STATUS_EXTENSION_MERGE_DOCUMENT.copy();
			//pass an extension document with a received message status 
			resultPDO = PaymentDataFactory.clonePDO(sTemplateOrLinkedPaymentMID, sSourceMID, null /*historyValue*/, (Serializable) tempDoc);
			
			//if the message errors list is not empty, set it in the cloned pdo 
			if(!listMsgErrors.isEmpty()) resultPDO.setListMSGERR(listMsgErrors) ;  
			
			//if the context is that of create payment from template check the template's status and raise an error 
			//if the status is not COMPLETE
			if(!sTemplateMsgStatus.equals(MESSAGE_STATUS_COMPLETE)){
				
				final ProcessError processError = new ProcessError(ProcessErrorConstants.InvalidStatusDuringCreateFromTemplate, 
						sTemplateOrLinkedPaymentMID, sTemplateOrLinkedPaymentMID, sTemplateMsgStatus);
				ErrorAuditUtils.setErrors(processError, resultPDO);
				
				ErrorAuditUtils.onError(ProcessErrorConstants.InvalidStatusDuringCreateFromTemplate, 
						responseFeedback, sTemplateOrLinkedPaymentMID, sTemplateMsgStatus) ;
				
			}//EO if create from template and template status != COMPLETE
			else if ("S".equals(sTemplateType)) { 
				
				final ProcessError processError = new ProcessError(ProcessErrorConstants.InvalidTemplateTypeSDuringCreationFromTemplate, 
						sTemplateOrLinkedPaymentMID);
				ErrorAuditUtils.setErrors(processError, resultPDO);
				
				ErrorAuditUtils.onError(ProcessErrorConstants.InvalidTemplateTypeSDuringCreationFromTemplate, 
						responseFeedback, sTemplateOrLinkedPaymentMID) ;
				
			}else if ("F".equals(sTemplateType)){
				//Check message. Not relevant at this time (6)
			}//EO else if 'F' 
			
		}//EO if create from template 
		else resultPDO = templateOrLinkedPayment ; //else if the payment is linked to a template 
		
		//if the feedback indicates a validation failure, 
		//configure the cloned pdo so that it would not be persisted and cached 
		if(!responseFeedback.isSuccessful()) { 
			resultPDO.set(D_SKIP_PERSIST_ON_ERROR, true);
		}//EO if validation error 

		return resultPDO ; 
	}//EOM

	/**
	 * @param pdo
	 * @return
	 */
	private FieldsContainer createUserModifiedFields(PDO pdo)
	{

		Collection<PaymentFieldInterface> modifiedFields = pdo.getModifiedFields();
		Map<String, Object> map = new HashMap<String, Object>();
		for (PaymentFieldInterface paymentFieldInterface : modifiedFields)
		{
			map.put(paymentFieldInterface.getFieldId(), paymentFieldInterface.get());
		}

		FieldsContainer fieldsContainer = new FieldsContainer(map);
		return fieldsContainer;
	}
	
	
	private PDO loadPdo(final MessageFieldsInputData msgFieldsInput, Admin admin)
	{
		final String sMID = msgFieldsInput.getMID();
		boolean isService = msgFieldsInput.isService();
		PDO pdo = null;
		if(!isService) pdo = CacheKeys.UserMessageKey.getSingleUserPDO(sMID);
		if(pdo == null) pdo = PaymentDataFactory.load(sMID);
		
		// set the button id in the PDO
		final String sActionButtonID = msgFieldsInput.getFragmentID();
		pdo.set(D_BUTTON_ID, sActionButtonID);
		pdo.set(P_LAST_ACTION, sActionButtonID);
		pdo.setTemplateUnchangedFields(msgFieldsInput.getTemplateUnchangedFields());
		
		
		
		// if the action is in the context of autofeeder mode, and the current button (action) id supports the next button operation,
		// set the bAutoFeederMode to true so as to configure the next action in the user feedback in case of operation success
		boolean bAutoFeederMode = ("1".equals(pdo.getWithTransientLookup(D_AUTOFEEDER_MODE)));
		if (bAutoFeederMode)
		{
			MessageLayoutCacheInterface msgLayoutCache = (MessageLayoutCacheInterface) CacheKeys.MiscResoucesKey
					.getSingle(MessageLayoutCacheInterface.class);
			bAutoFeederMode = ((Button) msgLayoutCache.getCachedComponent(sActionButtonID)).supportsAutoFeederNext();
		}// EO if in context of autofeeder mode

		// set the last submit in the pdo
		return pdo;
	}
	
	
	
	private Feedback performDualCheck(PDO pdo, String userId, String actionButtonId, Feedback feedback)
	{
		final String DUAL_USERS_DELIMITER = "\\^";
		final String sP_DUAL_USERS = pdo.getString(P_DUAL_USERS);
		if (!isNullOrEmpty(sP_DUAL_USERS))
		{
			String[] arrDualUsers = sP_DUAL_USERS.split(DUAL_USERS_DELIMITER);
			boolean bFailDualControl = false;

			for (int i = 0; i < arrDualUsers.length && !bFailDualControl; i++)
			{
				bFailDualControl = userId.equals(arrDualUsers[i]);
			}

			// Error code '40106': 'Action |1 cannot be performed as it requires dual control'.
			if (bFailDualControl)
			{
				ProcessError pe = new ProcessError(ProcessErrorConstants.DualControlRequired, new Object[] { actionButtonId });
				configureErrorFeedback(ProcessErrorConstants.DualControlRequired, pe.getDescription(), feedback);
			}
		}
		
		return feedback;
	}
	
	private void clearErrorsAndAudit(PDO pdo, GlobalResponseDataComponentText response, Feedback feedback)
	{
		List pdoListMember = pdo.getListMSGERR() ; 
		if(pdoListMember != null) pdoListMember.clear() ; 
		
		pdoListMember = pdo.getListNEWJOURNAL() ; 
		if(pdoListMember != null) pdoListMember.clear() ;
		
		final ProcessError processError = new ProcessError(feedback.getErrorCode(), feedback.getUserErrorText()) ; 
		ErrorAuditUtils.setErrors(processError, pdo) ; 
		response.setFeedback(feedback);

	}

	
	private GlobalResponseDataComponentText executeEvents(PDO pdo, MessageFieldsInputData msgFieldsInput, String screenSetId, GlobalResponseDataComponentText response) throws EventUncheckedException
	{
		// invoke all the following server events:
		// onServerChange (only on the modified user fields
		// final FieldsContainer fcModifiedFields = msgFieldsInput.getUserModifiedFields() ;
		// if(fcModifiedFields != null) {
		// final String[] arrModifiedFields = fcModifiedFields.getFieldIds() ;
		// if(arrModifiedFields != null)
//		String[] arrFieldIDs = msgFieldsInput.getQualifiedUserModifiedFields() != null ? msgFieldsInput.getQualifiedUserModifiedFields()
//				.getFieldIds() : null;
		
		String[] arrFieldIDs = msgFieldsInput.getTotalUserModifiedFields()!= null ? msgFieldsInput.getTotalUserModifiedFields()
				 : (msgFieldsInput.getQualifiedUserModifiedFields() != null ? msgFieldsInput.getQualifiedUserModifiedFields()
							.getFieldIds() : null);

		m_EventBus.fireEvent(screenSetId, msgFieldsInput, arrFieldIDs, ServerEvents.onServerChange);
		// }//EO if there were modified fields

		// onMandatory
		// invoke the pre save events which shall perform actions such as determining whether
		// to insert the user id as well due to dual control check
		m_EventBus.fireEvent(screenSetId, msgFieldsInput, ServerEvents.onPreServerSave, ServerEvents.onMandatory);

		if (pdo.get(P_MSG_TYPE).equals("SWIFT_300")){
			try{
				PaymentDataFactory.formatPDO(pdo);
			} catch (BusinessException e){
				ExceptionController.getInstance().handleException(e, this);
				response = new SimpleContentSharedResponse("The SWIFT 300 input is invalid");
				Feedback feedback = response.getFeedback();
				feedback.setFailure();
				feedback.setUserErrorText("The SWIFT 300 input is invalid\n" + e.getErrorDescription());
				feedback.setErrorText("The SWIFT 300 input is invalid\n" + e.getErrorDescription());
			}
		}

		return response;
	}
	
	private GlobalResponseDataComponentText handleStackEventErrors(PDO pdo, MessageFieldsInputData msgFieldsInput, GlobalResponseDataComponentText response)
	{
		// retrieve the errors stack from the context msgFieldsInput (initialised during the first event fire() invocation
		// if the stack is not empty, constrcut the errors json and return to the client.
		final Stack<ScriptErrorResult> stackEventErrors = (Stack<ScriptErrorResult>) msgFieldsInput.get(EventBus.EVENT_ERRORS_KEY);

		if (stackEventErrors != null && !stackEventErrors.isEmpty())
		{
			// constrcut the accumulative trace error string as well as the user response
			final StringBuilder traceBuilder = new StringBuilder().append(ErrorAuditUtils.loadErrorAuditText(
					(long) ProcessErrorConstants.SaveValidationFailure, pdo.getString(P_OFFICE), null));
			final StringBuilder userRespBuilder = new StringBuilder("var mapErrors = new Object();\n\r");
			final String sErrorTemplate = "mapErrors['%s'] = ['%s'] ;\n";

			for (ScriptErrorResult scriptError : stackEventErrors)
			{
				traceBuilder.append(scriptError.getError().getDescription());

				userRespBuilder.append(
						String.format(sErrorTemplate, scriptError.getSAssociatedFieldId(), scriptError.getError().getDescription())).append(
						CARRIAGE_RETURN_AND_NEWLINE);
			}// EO while there are more script errors

			logger.error(traceBuilder.toString());

			response = new SimpleContentSharedResponse("JSON", userRespBuilder.append(
					"var bErrors = oMessageModel.fDisplayErrors(mapErrors, false);\ndelete mapErrors;\nbErrors;").toString());
			response.getFeedback().setFailure(); // set the failure flag so that the screen remains opened
			
		}// EO if there were errors

		return response;
	}
	
	/**
	 * 
	 */
	private String preActionsForEventsExecutionUsingGroupActions(PDO pdo, MessageFieldsInputData msgFieldsInput, String sActionButtonID)
	{
		final String TRACE_FOUND_SCREEN_SET = "Found screen set: {}.";
		final String TRACE_FOUND_RELATED_GROUP_ACTION_BUTTON_REF = "Found and added '{}' key into map of 'txtQualifiedUserModified' key within the MessageFieldsInputData object.";
		
		
		
		String sScreenSetId = null;
			
		Admin admin = Admin.getContextAdmin();
		String sMID = pdo.getMID();
		String[] arrObjectIDs = new String[]{pdo.getString(P_OFFICE), ServerConstants.DEFAULT_SERVER_OFFICE_NAME};
		
		try
		{
			List<RuleResult> listRuleResults = m_internalRuleExecutionLogging.executeRule(admin, MessageConstantsInterface.RULE_TYPE_ID_MESSAGE_SCREEN_SET_SELECTION, null, sMID, arrObjectIDs).getResults();

			// Found screen set ID.
			if (!listRuleResults.isEmpty())
			{
				sScreenSetId = listRuleResults.get(0).getAction();
				logger.info(TRACE_FOUND_SCREEN_SET, sScreenSetId);
			}
			
			if(sScreenSetId != null)
			{
				listRuleResults = m_internalRuleExecutionLogging.executeRule(admin, MessageConstantsInterface.RULE_TYPE_ID_MESSAGE_FIELDS_SETS_SELECTION, null, sMID, arrObjectIDs).getResults();
			
				String[] arrFieldsSetsIDs = new String[0];
				
				if (!listRuleResults.isEmpty())
				{
					arrFieldsSetsIDs = new String[listRuleResults.size()];
	
					for (int i = 0; i < arrFieldsSetsIDs.length; i++)
					{
						RuleResult ruleResult = listRuleResults.get(i);
						arrFieldsSetsIDs[i] = ruleResult.getAction();
					}
				}
	
				MessageLayout messageLayout = new MessageLayout(sScreenSetId, null, new TreeSet<MessageButton>());
				final MessageLayoutCacheInterface layoutCache = (MessageLayoutCacheInterface) CacheKeys.MiscResoucesKey.getSingle(MessageLayoutCacheInterface.class);
				
				Map mapConfigurationDelta = layoutCache.getFieldsSetsDelta(sScreenSetId, arrFieldsSetsIDs);
				
				boolean bFound = false;
				Iterator iterKeys = mapConfigurationDelta.keySet().iterator();
				
				while(iterKeys.hasNext() && !bFound)
				{
					String sKey = iterKeys.next().toString();
					
					// e.g. PN_BUTTON_TOP.ForceNSF.
					if(sKey.endsWith(ServerConstants.DOT + sActionButtonID))
					{
						bFound = true;
						
						Map<String, Object> map = new HashMap<String, Object>();
						map.put(sKey, mapConfigurationDelta.get(sKey));
						FieldsContainer fieldsContainer = new FieldsContainer(map);
						logger.info(TRACE_FOUND_RELATED_GROUP_ACTION_BUTTON_REF, sKey);
						
						msgFieldsInput.put(USER_QUALIFIED_MODIFIED_FIELDS_KEY, fieldsContainer);
					}
				}
			}
		}
		
		catch(Exception e)
		{
			ExceptionController.getInstance().handleException(e, this);
		}
		
		
		
		return sScreenSetId;
	}
	
	private GlobalResponseDataComponentText handleScreenSet(PDO pdo, MessageFieldsInputData msgFieldsInput, 
			                                                    GlobalResponseDataComponentText response, String sActionButtonID) 
																                          throws EventUncheckedException
	{
		String screenSetId = msgFieldsInput.getScreenSetID();
		
		// In case of group actions, need to derive the screen set as the group action which stands for a button on the message
		// might have related actions/events in MESSAGE_FIELD_ACTIONS which should be executed.
		if(screenSetId == null)
		{
			screenSetId = preActionsForEventsExecutionUsingGroupActions(pdo, msgFieldsInput, sActionButtonID);
		}
		
		// Might be null when called from the group actions logic.
		if (screenSetId != null)
		{
			response= executeEvents(pdo, msgFieldsInput, screenSetId, response);
			if (response.getFeedback().isSuccessful())
			{
				response = handleStackEventErrors(pdo, msgFieldsInput, response);
			}
		}// EO screen set ID != null
		
		return response;
	}

	
	private void handleModifiedFields(PDO pdo, MessageFieldsInputData msgFieldsInput, boolean isService, boolean[] bUserHasChangedFields)
	{
		// In case fields were changed by the user, prepares the user modified fields NEWJOURNAL entry.
		final FieldsContainer fcModifiedFields = msgFieldsInput.getUserModifiedFields();
		
		final String sActionButtonID = msgFieldsInput.getFragmentID();

		if (fcModifiedFields != null)
		{
			final String[] arrModifiedFields = fcModifiedFields.getFieldIds();

			// If there is only one changed field and this field is the button that was pressed during the submit action,
			// then there is no need to prepare the modified fields NEWJOURNAL entry.
			boolean bSingleFieldChange = arrModifiedFields != null && arrModifiedFields.length == 1;
			boolean bOnlyButtonClickReference = false;
			if (bSingleFieldChange)
			{
				String sChangedFieldValue = fcModifiedFields.getField(arrModifiedFields[0]);
				if (sChangedFieldValue != null) sChangedFieldValue = GlobalXMLTextUtil.unescape(sChangedFieldValue).trim();

				// Boolean is set to true when the user has only pressed a button on the GUI side without changing any field;
				// When the button is pressed, it is being entered into the 'msgFieldsInput' object as a modified field, where its key
				// is the button ID and its value can be:
				//     1) The MESSAGEBUTTONS.BUTTONID value of that button.
				//  OR 2) The MESSAGE_FIELDS.ALIAS value of that button, (was entered in the message designer and thus has override case 1), where this alias
				//        is also used as the fragment ID, (kept in 'sActionButtonID').
				// In both cases there is no need for the NEWJOURNAL entry.
				bOnlyButtonClickReference =    arrModifiedFields[0].equals(sChangedFieldValue)
					                          || arrModifiedFields[0].equals(sActionButtonID);
			}

		    boolean bUserModifiedField = false;  
		    final Collection<PaymentFieldInterface> cModifiedFields = pdo.getModifiedFields() ; 
		    if(cModifiedFields != null) { 
		    	for(PaymentFieldInterface modifiedField : cModifiedFields) { 
		    		if(modifiedField.isAuditable() && modifiedField.getModificationType() == ModificationType.User) { 
		    			bUserModifiedField = true;
		    			break;
		    		}
		    	}
		    }

			final String strMessageTables =  msgFieldsInput.getDirtyMessageTables() == null? "": msgFieldsInput.getDirtyMessageTables().toString();
		    if (strMessageTables.contains(M_MSG_NOTES_GRID))
            {
                     ProcessError processError = new ProcessError(ProcessErrorConstants.UserHasAddedNewNote);
                     ErrorAuditUtils.setErrors(processError, pdo);
            }
		    
            if (bUserModifiedField || (!bSingleFieldChange || (bSingleFieldChange && !bOnlyButtonClickReference)))
			{
				bUserHasChangedFields[0] = true;
				ErrorAuditUtils.prepareUserModifiedFieldsNEWJOURNALEntry(pdo);
			}
		}
		
		else if (isService) ErrorAuditUtils.prepareUserModifiedFieldsNEWJOURNALEntry(pdo);
	}
	
	private PDO futurePendingChangesHandling(PDO pdo) throws Throwable
	{
//		IF P_PROC_DATE > Office Business date (i.e. future effective date) and  
//				PDO has NO MFAMILY entry with Relation type 'Future Changes^Original Template' (i.e. Not a future pending changes) 
//						and it is not a newly created PDO and the original P_MSG_STS = 'COMPLETE' then  
//			viii.	Change the PDO to be a new PDO and generate a new P_MID for it.
//			ix.	Need to make sure that the newly created newjournal, Message Notes entries will be written against the new P_MID. 
//			x.	Create new MFAMILY entries between the original Template P_MID and the New future template P_MID. 
//				1.	For the original - 'Original Template^Future Changes'
//				2.	For the Future changes - 'Future Changes^Original Template' 
//			xi.	Continue to the Manual Workflow Rule with the new PDO

		Date processDate =pdo.getDate(PDOConstantFieldsInterface.P_PROC_DT);
		Date officeBusinessDate = pdo.getDate(PDOConstantFieldsInterface.F_OFFICE_BDT);
		if (!MessageConstantsInterface.MESSAGE_BUTTON_VALIDATE.equals(pdo.getString(PDOConstantFieldsInterface.D_BUTTON_ID)) 
				&& processDate != null && officeBusinessDate != null && processDate.after(officeBusinessDate)
				&& !pdo.isRelationExist(MessageConstantsInterface.RELATION_TYPE_FUTURE_CHANGES, MessageConstantsInterface.RELATION_TYPE_ORIGINAL_TEMPLATE)
				&& !pdo.isNew()
				&& MessageConstantsInterface.MESSAGE_STATUS_COMPLETE.equals(pdo.getString(PDOConstantFieldsInterface.P_MSG_STS)))
		{
			String mainPdoMid = pdo.getMID();
			String unchangeFields = pdo.getNSetTemplateUnchangedFields();
			String buttonId = pdo.getString(PDOConstantFieldsInterface.D_BUTTON_ID);
//			remove the PDO from cache.
			
//			PaymentDataFactory.batchSave(true, pdo);
			
			PDO newPdo = PaymentDataFactory.clonePDO(pdo.getMID(),2, null);
			
//			this fields is mapped to prevent duplication with original PDO.
			newPdo.set(PDOConstantFieldsInterface.P_TEMPLATE_MID, mainPdoMid);
			newPdo.set(PDOConstantFieldsInterface.D_BUTTON_ID, buttonId);
			Relationtypes relationTypes = CacheKeys.relationtypesKey.getSingle(MessageConstantsInterface.RELATION_TYPE_FUTURE_CHANGES+
					GlobalConstants.POWER_SIGN + MessageConstantsInterface.RELATION_TYPE_ORIGINAL_TEMPLATE);
			
        	String timeStamp = Relationtypes.PREVENT_DUPLICATION_REQUIRED_WITH_TIME_STAMP == relationTypes.getPreventDuplication() ?
	                m_daoMessage.getSystemDateAndTimeFromDatabase() : ServerConstants.EMPTY_STRING;

            MFamilyLineType mFamily = MFamilyLineType.Factory.newInstance();
            mFamily.setFMFAMILYPMID(newPdo.getMID());
            mFamily.setFMFAMILYRELATEDMID(mainPdoMid);
            mFamily.setFMFAMILYSELFRELATEDTYPE(MessageConstantsInterface.RELATION_TYPE_FUTURE_CHANGES);
            mFamily.setFMFAMILYRELATEDTYPE(MessageConstantsInterface.RELATION_TYPE_ORIGINAL_TEMPLATE);
            mFamily.setFMFAMILYTIMESTAMP(timeStamp);
            mFamily.setFMFAMILYISNEW(true);
            
            newPdo.addMfamily(mFamily);
            
//            original PDO should loaded to saved later on.  
            newPdo.getLinkedMsg(MessageConstantsInterface.RELATION_TYPE_ORIGINAL_TEMPLATE);
            newPdo.promoteToPrimary();
            
            pdo = newPdo;
            
            pdo.setTemplateUnchangedFields(unchangeFields);

		}
		return pdo;
	}
	
	private void businessWorkFlowRuleHandling(PDO pdo, Admin admin, boolean[] continueWithFlow, StringBuilder sbStatusSelectionResult) throws Throwable
	{
		List<RuleResult> listRuleResults = null;
		RuleResult ruleResult = null;
		String sOffice = pdo.getString(P_OFFICE);
		String[] arrObjectIDs = new String[] { sOffice };
		String sMID = pdo.getMID();

		listRuleResults = m_internalRuleExecutionLogging.executeRule(admin,
				RULE_TYPE_ID_GUI_WORKFLOW_STATUS_SELECTION, null, sMID, arrObjectIDs).getResults();

		final String GUI_WORKFLOW_RULE_RESULT = "GUI workflow status selection rule result: ";
		if (!listRuleResults.isEmpty())
		{
			sbStatusSelectionResult.append(listRuleResults.get(0).getAction());
		}
		logger.info(GUI_WORKFLOW_RULE_RESULT + sbStatusSelectionResult);
		
		if (!isNullOrEmpty(sbStatusSelectionResult.toString()))
		{
			ruleResult = listRuleResults.get(0);
			String sStatusSelectionResult = sbStatusSelectionResult.toString();

			// Action is 'CONT_FLOW' or 'CONT_FLOW_NO_SAVE' or 'CONT_FLOW_UNTIL_HANDOFF'; flow will continue and message status will be determined there.
			if (sStatusSelectionResult.indexOf(SYS_RULE_ACTION_CONT_FLOW) != -1)
			{
				continueWithFlow[0] = true;
				pdo.set(PDOConstantFieldsInterface.D_IS_CONT_FLOW_UNTIL_HANDOFF, !sStatusSelectionResult.equals(SYS_RULE_ACTION_CONT_FLOW));
			}

			// Action is 'RETURN_TO_BASE_STATUS' or 'NO_CHANGE';
			// Sets the status of the message and flow WON'T continue.
			else if (sStatusSelectionResult.equals(SYS_RULE_ACTION_RETURN_TO_BASE_STATUS)
					|| !sStatusSelectionResult.equals(SYS_RULE_ACTION_NO_CHANGE))
			{
				// In case P_CREATE_DT is null, set it so it won't remian empty upon first save to the database.
				if(pdo.getDate(P_CREATE_DT) == null)
				{
					pdo.set(P_CREATE_DT, NewASDateTimeUtils.getCurrentDateAndZoneByOffice(sOffice).getDate()) ;
				}
				
				String sNewStatus;

				if (sStatusSelectionResult.equals(SYS_RULE_ACTION_RETURN_TO_BASE_STATUS))
				{
					sNewStatus = !GlobalUtils.isNullOrEmpty(pdo.getString(P_BASE_MSG_STS)) ? pdo.getString(P_BASE_MSG_STS) : pdo.getString(P_PREVIOUS_MSG_STS);
				}
				else
				{
					sNewStatus = sStatusSelectionResult;
				}
				pdo.set(P_PREVIOUS_MSG_STS, pdo.getString(P_MSG_STS));
				pdo.set(P_MSG_STS, sNewStatus);

		
				if (MessageConstantsInterface.MESSAGE_STATUS_CANCELED.equals(sNewStatus))
				{
					pdo.set(P_DUPLICATE_INDEX, (String)null);
					
					// if message cancelled successfully then we'll Updates the PDO with an Error code 40288: 'Payment cancelled by user |1.'
				    String userID = Admin.getContextAdmin().getWebSessionInfo()!=null ? Admin.getContextAdmin().getWebSessionInfo().getUserID() : null;
				    ProcessError processError = new ProcessError(ProcessErrorConstants.ApproveCancellationRequest, new Object[] { userID });
				    ErrorAuditUtils.setErrors(processError,pdo.getIsHistory());
				}
				
				// NEWJOURNAL update.
				PruleTypes pruleType = CacheKeys.PRulesTypeKey.getSingle(RULE_TYPE_ID_GUI_WORKFLOW_STATUS_SELECTION);
				Prules prule = CacheKeys.PRulesUIDKey.getSingle(ruleResult.getRuleUID());
				String[] arrErrorParams = new String[] { sNewStatus, pruleType.getRuleTypeName(), prule.getRuleName(), ruleResult.getObjectUid() };
				//
				// Error code 40033: 'Message status was set to |1 by |2 (|3) attached to |4'.
				ProcessError pError = new ProcessError(ProcessErrorConstants.MessageStatusWasChanged, (Object[]) arrErrorParams);
				logger.info(METHOD_PREFIX + pError.getDescription());
				ErrorAuditUtils.setErrors(pError,pdo.getIsHistory());
				
				//Error code 1001: 'Message status changed from |1 to |2'. QC 33052
				ProcessError processError = new ProcessError(ProcessErrorConstants.MessageStatusChanged, new Object[] { pdo.getString(P_PREVIOUS_MSG_STS), sNewStatus });
				ErrorAuditUtils.setErrors(processError,pdo);
			}// EO if the status was change
			
			// In case the action is not one of the 'CONT_FLOW' types, activates payment advising.
			if(sStatusSelectionResult.indexOf(SYS_RULE_ACTION_CONT_FLOW) == -1)
			{
				final String TRACE_NOTIFICATION_FLOW = "Workflow rule action is {}, (not CONT_FLOW type); executes notification flow...";
				logger.info(TRACE_NOTIFICATION_FLOW, sStatusSelectionResult);
				BOHighValueProcess.performNotificationFlow(pdo);
			}
			
			String internalFileId = pdo.getString(PDOConstantFieldsInterface.P_IN_INTERNAL_FILEID);
			String flowType = pdo.getString(PDOConstantFieldsInterface.P_BUSINESS_FLOW_TP);
			if (!GlobalUtils.isNullOrEmpty(internalFileId) && 
				flowType.equals(GlobalConstants.RT) && 
				sStatusSelectionResult.equals(MessageConstantsInterface.MESSAGE_STATUS_CANCELED)){
				
				String param = internalFileId + "^" + pdo.getString(PDOConstantFieldsInterface.P_MID);
				PaymentDistributerEventHandler.addOneTimeEvent(MessageConstantsInterface.EVENT_CHECK_CANCELED_PAYMENTS, param, null);
			}
			
		}// EO if there were rule results
	}
	
	private void handleScheduleTemplate(PDO pdo) 
	{
//		If P_IS_HISTORY = 2 (Template) and P_MSG_STS = 'SCHEDULE' then 
//			Set the P_RELEASE_INDEX according to the logic within the MOP selection Service when we set it to 'SCHEDULE'

		if (pdo.getInteger(PDOConstantFieldsInterface.P_IS_HISTORY) != null && pdo.getInteger(PDOConstantFieldsInterface.P_IS_HISTORY) == 2 
				&& MessageConstantsInterface.MESSAGE_STATUS_SCHEDULE.equals(pdo.getString(PDOConstantFieldsInterface.P_MSG_STS)))
		{
			Date processDate =pdo.getDate(PDOConstantFieldsInterface.P_PROC_DT);
			Date officeBusinessDate = pdo.getDate(PDOConstantFieldsInterface.F_OFFICE_BDT);

			if(processDate != null && officeBusinessDate != null && processDate.after(officeBusinessDate))
			{
				String mop = pdo.get(PDOConstantFieldsInterface.P_CDT_MOP) != null ? pdo.getString(PDOConstantFieldsInterface.P_CDT_MOP) : "BOOK";
				//String formatedDate = GlobalDateTimeUtil.getSTATIC_DATA_DATE_SimpleDateFormat().format(processDate);
				String formatedDate = GlobalDateTimeUtil.dateToStaticDataString(processDate);
				String event = MessageConstantsInterface.EVENT_RELEASE_FROM_SCHEDULE;
				pdo.set(PDOConstantFieldsInterface.P_RELEASE_INDEX, event+GlobalConstants.POWER_SIGN+pdo.getString(PDOConstantFieldsInterface.P_OFFICE)
			    		  +GlobalConstants.POWER_SIGN+mop+GlobalConstants.POWER_SIGN+formatedDate);
				
			}
		}

	}
	
	private void callBusinessFlowSelector(PDO pdo, Admin admin, Feedback feedback) throws Throwable
	{
		String sMID = pdo.getMID();
		// determine whether the pdo's orig and current xml document instances are the same
		// if so, then the payment had not undergone the flow yet, and prior to doing so,
		// the logical link between the orig and current must be severed.
		//in case of template the payment must stay in conjoined mode  
		boolean bIsTemplate = false;
		if (pdo.getInteger(PDOConstantFieldsInterface.P_IS_HISTORY)!= null) {
			bIsTemplate =  (pdo.getInteger(PDOConstantFieldsInterface.P_IS_HISTORY)== 2);			
		}
		
		
		if (pdo.isConjoined() && 
			!bIsTemplate && 
			pdo.get(PDOConstantFieldsInterface.D_IS_CONT_FLOW_UNTIL_HANDOFF) != null &&
			!pdo.getBoolean(PDOConstantFieldsInterface.D_IS_CONT_FLOW_UNTIL_HANDOFF))
		{
			logger.debug(METHOD_PREFIX + "About to split the ORIG-CURRENT documents link for PDO {}", sMID);

			/*
			 * pdo.transform(pdo.getPaymentType(DASInterface.ORIG_XML_MSG_KEY).name()) ; //set the MF_INITIAL_CREATE service monitor to X to
			 * indicate that subsequent pdo loads would //not share the xml document pdo.set(MF_INITIAL_CREATE, EPMTY_FLAG) ;
			 */
			pdo.severConjoinedLinks();
		}// EO if the current and orig xml are the same documet instance) 
		
		// Opens a transaction, which will be closed at the end of this message.
		//System.out.println(Thread.currentThread().getId() + " --> " +"SubmitMessage(MessageInputData) --> START --> before slpitting") ;
		//ThreadBoundCounterUTXWProxy.getStartedInstance(true/*bSilentParticipation*/) ;
		BOBasic.startTx("[BOMessageHandle.submitMessage]") ;
		// ASAF: for now - 01/12/2009 - assumes that we're on the same JVM, thus calls the propagate method as follows:
		// 1) 'bRemovePDOFromLocalCache' as false.
		// 2) 'bSameJVM' as true.
		CacheKeys.ProcessSessionsKey.propagate(false, true);

		// Executes the business flow selection, where if no business flow definition rule is defined for this
		// message properties, process will be stopped.
		//feedback = BOProxies.m_businessFlowSelectorLogging.executeFlow(admin, sMID, false, ServerConstants.EMPTY_OBJECT_ARRAY);
		//BOProxies.m_businessFlowSelectorLogging.executeFlow(admin, sMID, false, ServerConstants.EMPTY_OBJECT_ARRAY);
		
		//invoke the flows out (Flow_Selector_OUT) interface out handler which would execut the business flow selector code   
		final HashMap mapContext = new HashMap() ;
 
		final SimpleResponseDataComponent interfaceResponse = 
			BOProxies.m_internalInterfacesLogging.performOutgoingRequestHandler(
					Admin.getContextAdmin(), 
					pdo.getMID(), 
					"FLOWS", 
					"OUT",
					mapContext) ; 
			
		//extract the feedback response from the interface response and merge with the flow's feedback 
		final Feedback businessFlowSelectorFeedback = (Feedback) interfaceResponse.getDataArray()[0] ; 
		feedback.setFeedback(businessFlowSelectorFeedback) ; 
			
		CacheKeys.ProcessSessionsKey.apply();
		
		//QC29411 keep the original admin
		if (Admin.getContextAdmin() != admin) 
			Admin.setContextAdmin(admin);
	}
	
	private void invokeDualControlRule(PDO pdo, String[] arrObjectIDs, String userId) throws Exception
	{
		// Invokes the dual control rule.
		List<RuleResult> listRuleResults = m_internalRuleExecutionLogging.executeRule(Admin.getContextAdmin(), RULE_TYPE_ID_DUAL_CONTROL,
				null, pdo.getMID(), arrObjectIDs).getResults();
		// Got back an action.
		if (!listRuleResults.isEmpty())
		{
			final String sDualControlAction = listRuleResults.get(0).getAction();
			logger.info(METHOD_PREFIX + "dual control action: " + sDualControlAction);
			handleNewDualUsersValue(sDualControlAction, pdo, userId);
		}
		// No action was returned.
		else
		{
			if (!isNullOrEmpty(pdo.getString(P_DUAL_USERS)))
				pdo.set(P_DUAL_USERS, (String) null);
		}

	}
	
	private PDO submitMessageProcessing(PDO pdo, MessageFieldsInputData msgFieldsInput,Admin admin,boolean[] userHasChangedFields, 
			String sUserID, boolean bAutoFeederMode, String sActionButtonID, GlobalResponseDataComponentText response, Feedback feedback, Feedback saveFeedback) throws Throwable
	{
		String sMID = pdo.getMID();
		boolean[] bContinueWithFlow = new boolean[]{false};
		String[] arrObjectIDs = new String[] { pdo.getString(P_OFFICE) };
		String[] unchangedFields;
		StringBuilder sStatusSelectionResult = new StringBuilder();
		String buttonID = pdo.getString(PDOConstantFieldsInterface.D_BUTTON_ID);
		
		//Provide User ID in PDO, so it could be used by interim/final Pain002
		//
		pdo.set("D_USER_ID", admin.getWebSessionInfo().getUserID());
		
		// Store the status whether the message was submitted by Web Service on PDO object, as a D_ field
		//
		pdo.set("D_IS_SERVICE", msgFieldsInput.isService() ? 1 : 0);

		//If P_IS_HISTORY = 2 (Template) and D_BUTTTON_ID not in set of fixed buttons 
		//			i.	Invoke the STP RULES VALIDATION Service
		//			ii.	If Repair then Return with no save
		if (pdo.getInteger(PDOConstantFieldsInterface.P_IS_HISTORY) == 2)
		{
			String arrButtonIDs[] = {MessageConstantsInterface.MESSAGE_BUTTON_SENT_TO_REPAIR, MessageConstantsInterface.MESSAGE_BUTTON_CANCEL_TEMPLATE };
			Set<String> buttonIDs = new HashSet<String>(Arrays.asList(arrButtonIDs));
			if (!buttonIDs.contains(buttonID))
			{
				 boolean isSupportStpRule = CacheKeys.SystParKey.getSingleParmValue(pdo.getString(PDOConstantFieldsInterface.P_OFFICE), 
	    		   												SystemParametersInterface.SYS_PAR_SUPPORT_STP_RULE).equals(GlobalConstants.Yes) ; 
				 if (isSupportStpRule) {
					feedback.setFeedback(m_stpRulesLogging.validateSTPRules(admin, sMID));
				 }
	//			f Repair then Return with no save
			    pdo.set(D_RULE_TYPE_ID, MessageConstantsInterface.RULE_TYPE_ID_VALIDATION);
			    MapPaymentInfoUsingRulesOutputData mapPaymentInfoUsingRulesOutputData = BOMapPaymentInfoUsingRules.handleRuleExecutionAndMappingToPDO(sMID);
			    
	//		    if validation rule set the status to 'CANCELED' then it should remain 'CANCELED'
	//		    if it is not 'CANCELED' and validate STP failed, then set the status to 'REPAIR'
	//		    if STP successful then remain the status from validation rule (if it was selected at all). 
			    String messageSts = pdo.getString(PDOConstantFieldsInterface.P_MSG_STS);
			    
				if (!MessageConstantsInterface.MESSAGE_STATUS_CANCELED.equals(messageSts) && !feedback.isSuccessful())
				{
					pdo.set(PDOConstantFieldsInterface.P_MSG_STS, MessageConstantsInterface.MESSAGE_STATUS_REPAIR);
				}else if (MessageConstantsInterface.MESSAGE_STATUS_CANCELED.equals(messageSts))
				{
					List<RuleResult> listRuleResults = mapPaymentInfoUsingRulesOutputData.getRuleResults().getResults(); 
					String validationRuleId = listRuleResults != null && listRuleResults.size() > 0  ? listRuleResults.get(0).getAction() : null;
					Object[] arrNonPaymentFields = null;
					if (validationRuleId != null)
					{
						PreventStp preventStp = CacheKeys.preventStpKey.getSingle(validationRuleId);
					      
					    Long errorCode = preventStp.getErrorCode();
					    if(errorCode!=null){
					    	arrNonPaymentFields = new String[] { pdo.getString(X_TX_ID),pdo.getString(F_UMR),pdo.getString(F_CREDITOR_ID)};
					    	ErrorAuditUtils.setError(errorCode.intValue(), sMID, feedback, null, arrNonPaymentFields);
					    }else{
					    	// Error code 40111: 'Validation rule |1 (|2) found'.
					    	arrNonPaymentFields = new Object[]{preventStp.getName(), preventStp.getDescription()};
					    	ErrorAuditUtils.setError(ProcessErrorConstants.ValidationRuleFailure, sMID, feedback, null, arrNonPaymentFields);
					    }
					}else
					{
						arrNonPaymentFields = new Object[]{sMID};
						ErrorAuditUtils.setError(ProcessErrorConstants.PaymentCancelled, sMID, pdo.getIsHistory(), feedback,arrNonPaymentFields);
					}
				
				    pdo.setTransientMode();
				}
			}		    
		}
		
		if(!validateForceSchedule(pdo)){
			final BindingParameter operationParam = new BindingParameter(pdo.getString(P_CDT_MOP), DataType.STRING);
			feedback.setFailure();
			feedback.setErrorCode(ProcessErrorConstants.ForceScheduleMopError);
			feedback.setErrorText("Mop Error.");
			feedback.setErrorVariables(new BindingParameter[] { operationParam });
		}
		
		// Do not allow S message cancellation through the Web Service when current dated and future timed
		//
		if(feedback.isSuccessful())
		{
			String msgBatchType=pdo.getString(PDOConstantFieldsInterface.P_BATCH_MSG_TP);
			if(msgFieldsInput.isService() && (buttonID.equals(MessageConstantsInterface.MESSAGE_BUTTON_CANCEL)) && isCurrentDatedFutureTimed(pdo) == true 
					&&  ("S".equals(msgBatchType) && "true".equals(pdo.getString(PDOConstantFieldsInterface.X_BTCH_BOOKG))))
			{
				ProcessError processError = new ProcessError(ProcessErrorConstants.CurrentDatedFutureTimeCancellationFailure);
				String finalError = processError.getDescription().replace("|1", pdo.getMID());
                throw new FTGenericRuntimeException(sMID, processError.getErrorCode(), finalError, GlobalUtils.GPP_ERROR_PREFIX);
			}
			
			pdo.set(D_MESSAGE_SUBMIT_USER_ID, sUserID);
				
			pdo = futurePendingChangesHandling(pdo);	
			
			sMID = pdo.getMID();
	          
			handleSpecialInstructionOverride(pdo);
			// Invokes the user GUI workflow status selection rule.
			businessWorkFlowRuleHandling(pdo, admin, bContinueWithFlow,sStatusSelectionResult);	
			
			handleScheduleTemplate(pdo);
			
			// as there are only persisted msg errors in the pdo, there is no need to save them again
			// thus, remove them prior to the save
			
			final List<Msgerr> listMsgErrors = pdo.getNSetListMSGERR();
			if (listMsgErrors != null)
				listMsgErrors.clear();

			// Prior to saving the message, no need for the '40061' NEWJOURNAL entry, ('User has changed fields'),
			// if no actual fields changes were done by the user; e.g. pressing the 'Force Daily Limit' button.
			if (!userHasChangedFields[0]) pdo.pruneUserModifiedFieldsNewJournalEntry();
			
			Feedback businessFlowFeedback = new Feedback();
		
			// CONTINUING THE PROCESS WHILE CALLING THE BUSINESS FLOW SELECTOR !!!
			if (response.getFeedback().isSuccessful() && bContinueWithFlow[0] && !"2".equals(pdo.getString(P_IS_HISTORY)))
			{			
				String midCurrent = pdo.getMID();
				pdo = getPdoForRetryMatch(pdo);				
				sMID = pdo.getMID();
				try
				{
					callBusinessFlowSelector(pdo, admin, MESSAGE_BUTTON_REFUSE_CANCEL.equals(buttonID) ? businessFlowFeedback : feedback);
				}
				finally
				{
					cancelOriginalPdoForRetryMatch(pdo, midCurrent);
				}
			}//EO if continue with flow 
			 
			invokeDualControlRule(pdo, arrObjectIDs, sUserID);
	        //this is the case for Partial Repetitive Template, need to update unchangedFields as part of transaction
	        if(pdo.getTemplateUnchangedFields() != null) 
	        {
	          this.handleUnchangedFields(pdo,pdo.getTemplateUnchangedFields());
	        } //EO Partial Repetitive treatment
		}
		
		if (feedback.isSuccessful()) pdo.set(P_LAST_SUBMIT_TS, m_daoMessage.getSystemDateAndTimeFromDatabase());
		
		
		// Saves the message while removing it from the cache, where:
		// 1) Save for the message without continuing the process, (i.e. no business flow selection execution),
		// in which case, there is no open transaction.
		// OR
        // 2) Template type 'P' case: there shouldn't be any business flow selection execution;
        //    in this case, there will be an open transaction which will be opened during the above template flow.
        // OR
        // 3) Save for the message AFTER continuing the process using the business flow selection execution,
			// in which case we have an open transaction.
        //if the action was not CONT_FLOW_NO_SAVE 
        //or (D_SKIP_PERSIST_ON_ERROR is true and the P_MSG_STATUS is REPAIR) save the message, else skip the save procedure 
        if((!msgFieldsInput.isService() || MessageConstantsInterface.MESSAGE_BUTTON_CANCEL.equals(buttonID)) && 
        	!sStatusSelectionResult.toString().equals(SYS_RULE_ACTION_CONT_FLOW_NO_SAVE) && 
        	!(pdo.getBoolean(D_SKIP_PERSIST_ON_ERROR)!= null && pdo.getBoolean(D_SKIP_PERSIST_ON_ERROR) &&
        	  pdo.getString(PDOConstantFieldsInterface.P_MSG_STS).equals("REPAIR")
        	  )
           ) { 
        	//in this point, before saving the message and closing the TX, the message should re-eval for
        	//Position Keeping.
        	logger.debug("Position Keeping Evaluated from manual message handling");
        	m_PositionKeepingLogging.positionKeeping(Admin.getContextAdmin(),pdo.getMID());   
			response = this.saveMessage(sMID);
			saveFeedback.setFeedback(response.getFeedback());

			if (!saveFeedback.isSuccessful())
			{
				//QC #35288 : Marking the PDO as not global as code was before, is not correct because when an error message pops up, close event is not executed so message remains on cache
				BOMessageLoad.releaseLockedMessage(false, false, sMID);
				logger.info(ServerUtils.getFeedbackString(saveFeedback));
			}// EO if the save operation had failed
			else
			{
				BOMessageLoad.releaseLockedMessage(false, false, sMID);
			}
			
        }//EO if save was required 

        // Do not allow S message cancellation on current dated future timed files
        //
        if (feedback.isSuccessful() && 
        		((!msgFieldsInput.isService() && MESSAGE_STATUS_CANCELED.equals(pdo.getString(P_MSG_STS))) ||
        		 (msgFieldsInput.isService() && MESSAGE_STATUS_CANCELED.equals(pdo.getString(P_MSG_STS)) && isCurrentDatedFutureTimed(pdo) == false)))
		{
        	String str=pdo.getString(P_BATCH_MSG_TP);
        	if (!GlobalUtils.isNullOrEmpty(str))
        	{
        		if (SubBatchProcessInterface.BATCH_MESSAGE_TYPE_INDIVIDUAL.equals(str))
        		{
        			BackFromRepairFlowStep backFromRepairFlowStep=new BackFromRepairFlowStep();
        			backFromRepairFlowStep.performMainAction(pdo);
        		}
        		else // it is S
        		{
        			BOHighValueProcess.handleBatchSubsetStatus(pdo);
                    String internalFileId = pdo.getString(PDOConstantFieldsInterface.P_IN_INTERNAL_FILEID);
                    String sUniqueGroupingID = pdo.getString(PDOConstantFieldsInterface.P_UNIQUE_GROUPING_ID) ;
                    String bulkID = pdo.getString(PDOConstantFieldsInterface.D_BULK_ID) ;
	            	try
	            	{
	    		          PDO subbatchPDO=PaymentDataFactory.newPDO();
	    		          subbatchPDO.set(PDOConstantFieldsInterface.P_OFFICE, pdo.getString(PDOConstantFieldsInterface.P_OFFICE));
	    		          subbatchPDO.set(PDOConstantFieldsInterface.P_BATCH_MSG_TP, SubBatchProcessInterface.BATCH_MESSAGE_TYPE_SUB);
	    		          subbatchPDO.setIncomingFileSummary(pdo.getNSetIncomingFileSummary()) ;
			        	  subbatchPDO.set(PDOConstantFieldsInterface.P_MSG_STS, MessageConstantsInterface.MESSAGE_STATUS_CANCELED);
			        	  subbatchPDO.set(PDOConstantFieldsInterface.D_CHUNK_ID_LIST, m_daoNsf.getFILE_SUBSET_CHUNKS_CHUNK_ID(internalFileId, sUniqueGroupingID,bulkID));
			        	  subbatchPDO.set(PDOConstantFieldsInterface.P_IN_INTERNAL_FILEID,internalFileId);
			        	  subbatchPDO.set(PDOConstantFieldsInterface.P_UNIQUE_GROUPING_ID,sUniqueGroupingID);
			              
			        	  BOHighValueProcess.performNotificationFlow(subbatchPDO);
			        	  //done inside handleBatchSubsetStatus
			        	  //m_daoNsf.updateFILE_SUBSET_CHUNKS_Table(SubBatchProcessInterface.STATUS_SUB_BATCH_CANCELED, internalFileId, internalFileId);
			        	  
			        	  
			        	  // Change the FILE_SUMMARY entry status to FileCanceled.
			        	  //
			        	  DAODebulkingProcess	daoDebulkPrc = DAODebulkingProcess.getInstance();
			        	  DAORebulkProcess		daoRebulkPrc = DAORebulkProcess.getInstance();
			        	  Connection conn = daoDebulkPrc.getConnection();
			        	  daoDebulkPrc.updateFileSummaryStatusAndAudit(conn, SubBatchProcessInterface.STATUS_FILE_CANCELED, internalFileId);
			        	  
			        	  Admin.setContextPDO(pdo);
	            	}
    	            catch(Throwable t)
    	            {
        	              ExceptionController.getInstance().handleException(t, this);
        	              feedback.setFailure();
        	              feedback.setErrorCode(1);
        	              feedback.setErrorText(t.getMessage());
        	              throw new FlowException(t);
    	            }
        		}
        	}
		}

        // Ends the transaction for above case 2.
        if(!feedback.isSuccessful() && "RELEASE".equals(pdo.getString(P_MSG_STS))){
        	feedback.setSuccess();
        }
        
		// if the feedback had indicated a failure, set the error code to generic failure and the button action to reload
		if (!feedback.isSuccessful() || !saveFeedback.isSuccessful())
		{
			// Determines final feedback to save into the response, where precedence is:
			// 1st - the save process feedback.
			// 2nd - the initial submit feedback.
			feedback.setFeedback(!saveFeedback.isSuccessful() ? saveFeedback : feedback);

			// If feedback already includes a message to the user, no need to configure it with a generic error message.
			if (isNullOrEmpty(feedback.getUserErrorText()) && isNullOrEmpty(feedback.getErrorText()))
				ErrorAuditUtils.onError(ProcessErrorConstants.GenericError, feedback);
			// if(ProcessErrorConstants.reverseValue.Of(feedback.getErrorCode()) == null)
			feedback.getDialogs().getLast().setButtons(UserDialog.DIALOG_BUTTON_RELOAD_MSG);
		}// EO if the high value proecss had failed

		else
		{
			final BindingParameter operationParam = new BindingParameter(sActionButtonID, DataType.STRING);

			// if the message was in the context of autofeeder, set the next button action instead of the close
			final int iDialogButtonAction = (!bAutoFeederMode ? UserDialog.DIALOG_BUTTON_CLOSE_MSG
					: UserDialog.DIALOG_BUTTON_LOAD_NEXT_AUTOFEEDER_MSG);
			feedback.getDialogs().getLast().setButtons(iDialogButtonAction);// close/next message
			feedback.setErrorCode(ProcessErrorConstants.MessageOperationCompletedSuccesssfully);
			feedback.setErrorVariables(new BindingParameter[] { operationParam });
		}// EO else if the feedback was successful
	
		return pdo;
	}
	
	private boolean isCurrentDatedFutureTimed(PDO pdo)
	{
		boolean bReturnValue = false;
		Date	date = new Date();
		Date	holdDate = pdo.getDate(PDOConstantFieldsInterface.P_HOLD_DATE);

		if(holdDate != null && date.getDate() == holdDate.getDate() &&
				date.getTime() < holdDate.getTime())
		{
			bReturnValue = true;
		}
		
		return bReturnValue;
	}
	
	// TODO koby - should be removed in phase II
	private void cancelOriginalPdoForRetryMatch(PDO pdo, String midCurrent)
	{		
		if(!isRetryMatch(pdo) || midCurrent == pdo.getMID())
		{
			return;
		}
				
		cancelPayment(midCurrent);	
		//When the canceled payment is saved it becomes the contextPDO. 
		//need to set the context back to the updated payment 
		Admin.setContextPDO(pdo);
	}
	
	// TODO koby - should be removed in phase II
	private boolean isRetryMatch(PDO pdo)
	{
		String buttonId = pdo.getString(PDOConstantFieldsInterface.D_BUTTON_ID);
		if(buttonId == null || !buttonId.equals(PegaLoadInterfaceHandler.BUTTON_ID_RETRY_MATCH))
		{
			return false;
		}
		
		return true;
	}
	
	// TODO koby - should be removed in phase II
	private void cancelPayment(String mid)
	{
		try
		{
			logger.info("Pega load payment match found, canceling and saving payment {}", mid);
			PDO pdo = CacheKeys.ProcessPDOKey.getSingle(mid);
			pdo.set(P_MSG_STS, MESSAGE_STATUS_CANCELED);
			pdo.set(P_USER_STATE_MONITOR, "");	
			pdo.set(P_RELEASE_INDEX, "");	
			pdo.setListMFAMILY(null);
			PaymentDataFactory.save(true, pdo);
		}
		catch(Throwable t)
		{
			logger.error("Falied to cancel payment " + mid + ". Cancel the payment manually", t);
		}
	}

	// TODO koby - should be removed in phase II
	private PDO getPdoForRetryMatch(PDO pdo) throws BusinessException
	{		
		if(!isRetryMatch(pdo))
		{
			return pdo;
		}
	
		//Must remove the PDO from cache as long as it has it's original ID. 
		//otherwise, cancelPayment by MID will load the wrong PDO		
		CacheKeys.ProcessPDOKey.removeFromLocalAndRemote(pdo);		
		logger.info("Attempting to find a match for payment {} recieved from Pega load", pdo.getMID());
		PDO pdoUpdated = new PegaLoadInterfaceHandler().processPDO(pdo);
		
		// This is performed specifically for retry match and handled differently in pegs load via the setEnrichmentOrThrottling()
		pdoUpdated.setThrottlingMode();  
		return pdoUpdated;
	}

	private boolean validateForceSchedule(PDO pdo) {
		boolean isAllowForceSchedule = true;
		try{
			if ("Force Schedule".equals(pdo.getString(PDOConstantFieldsInterface.D_BUTTON_ID)))	{
				String cdtMop = pdo.getString(PDOConstantFieldsInterface.P_CDT_MOP);
				Mop cdtmop = CacheKeys.mopKey.getSingle(pdo.getString(PDOConstantFieldsInterface.P_OFFICE), cdtMop);
				
				if (cdtmop!=null && !cdtmop.getAllowSchedForce()) {
					isAllowForceSchedule = false;
				}
			}
		}
		catch(Throwable e){
			isAllowForceSchedule = true;
		}
		return isAllowForceSchedule;
	}
	
	private void handleSpecialInstructionOverride(PDO pdo)
	{
		boolean flag = false;
    	WebSessionInfo webSessionInfo = Admin.getContextAdmin().getNSetWebSessionInfo();
    	String userId = webSessionInfo !=null ? webSessionInfo.getUserID() : "";
        if (!pdo.isNew()){
	        List<MsgSpecialInstructions> msgSIList=pdo.getNSetMsgSpecialInstructionList();
	        String specialInsUsrSts = pdo.getString(PDOConstantFieldsInterface.MU_SPECIAL_INST_STS) != null ? pdo.getString(PDOConstantFieldsInterface.MU_SPECIAL_INST_STS) : ""; 
	        if (msgSIList!=null && MessageConstantsInterface.MONITOR_FLAG_OVERRIDE.equals(specialInsUsrSts))
	        {
	            for (MsgSpecialInstructions msgSI : msgSIList)
	            {
//                	if user override the special instructions for this message, then mark then as overriden - mark then with status 1
	            	if (msgSI.getSiStatus() == BOSpecialInstruction.STATUS_NEW)
	            	{
	            		msgSI.setSiStatus(BOSpecialInstruction.STATUS_OVERRIDEN);
	            		msgSI.setIsUpdated(true);
	            		msgSI.setUserId(userId);
	            		flag = true;
	            	}
	            }
	        }
        }
        
        if (flag)
        {
        	ErrorAuditUtils.setError(ProcessErrorConstants.UserAcceptedSpecialIns, pdo.getMID(), pdo.getIsHistory(), null, new Object[]{userId, pdo.getString(PDOConstantFieldsInterface.P_MSG_STS)});
        }

	}
	/**
	 * 
	 * @param msgFieldsInput
	 * @param pdo
	 * @return
	 */
	@AuthorizeUser(returnWebSessionInfo = true)
	@Expose
	public GlobalResponseDataComponentText submitMessage(final MessageFieldsInputData msgFieldsInput){
		
		
		final String METHOD_RESULT = METHOD_PREFIX + "result: ";

		

		GlobalResponseDataComponentText response = new UserResponse();
		Feedback feedback = response.getFeedback(), saveFeedback = new Feedback() ;
			
		boolean bCommit = true ;
		
		try
		{
			final String sMID = msgFieldsInput.getMID();
			
			//ensure that the TX open/close paradigm is symmetric as an explicit close is invoked regardless of wether the 
			//start tx is invoked. the joinActiveSession will only incement the nested invocation count 
			//if an active tx exists. this is required as the tx is only opened if the continue with flow flag is set to true or in templates unchanged fields 
			//System.out.println(Thread.currentThread().getId() + " --> " +"SubmitMessage(MessageInputData) --> INCREMENT --> joinActiveSession") ;
			//ThreadBoundCounterUTXWProxy.joinActiveSession() ;
			
			// if pdo does not exist in UserMessageKey cache, try to load it from PaymentDataFactory
			Admin admin = Admin.getContextAdmin();
			PDO pdo = loadPdo(msgFieldsInput, admin);
			boolean isService = msgFieldsInput.isService();			
			final String sActionButtonID = msgFieldsInput.getFragmentID();
			final WebSessionInfo webSessionInfo = admin.getWebSessionInfo();
			final String sUserID = webSessionInfo.getUserID();
			boolean bAutoFeederMode = ("1".equals(pdo.getWithTransientLookup(D_AUTOFEEDER_MODE)));
			// THIS SHOULD BE STEP ONE DO NOT ADD ANY FUNCTIONALITY BEFORE PERMISSION AND DUAL CHECK

			// step1: perform the following validations:
			// 1. button id  
			// 2. message type + sub type
			// 3. department
			// 4. message status
			final boolean[] arrMessageReadonlyPointer = new boolean[1];
			
			feedback = this.checkUserPermission(pdo, sActionButtonID, arrMessageReadonlyPointer, feedback);

			// Dual control check.
			if (feedback.isSuccessful()) performDualCheck(pdo,sUserID, sActionButtonID, feedback);

			if (!feedback.isSuccessful())
			{
				//clear the errors and audit and add this only error
				clearErrorsAndAudit(pdo, response, feedback);
				return response;
			}// EO if the user did not have permissions

			// Invokes base currency conversion; required for the decision, (done in latter user GUI workflow status selection rule),
			// if to route the payment first to Verify or to Skip Verify and route it directly to Release.
			pdo.set(D_CURRENCY_CONVERSION_TYPE, ConversionType.Base.toString());
			if (pdo.getString(OX_STTLM_CCY) != null) feedback = m_currencyConversionComplete.performCurrencyConversion(admin, sMID);
			if (!feedback.isSuccessful())
			{
				pdo.set(P_MSG_STS, MessageConstantsInterface.MESSAGE_STATUS_REPAIR);
				response.setFeedback(feedback);
				return response;
			}

			// else

			// step2: perform button related events ????


			// merge the fields with the pdo
			if (!isService) this.mergeModifiedFieldsWithPdo(pdo, msgFieldsInput);
			response = handleScreenSet(pdo, msgFieldsInput,response, sActionButtonID);
			
			if (!response.getFeedback().isSuccessful()) return response;
			
			boolean[] userHasChangedFields = new boolean[]{false};
			handleModifiedFields(pdo, msgFieldsInput, isService, userHasChangedFields);
			// Adds NEWJOURNAL entry for the button execution; error code 40090: '|1 has been executed'.
			ProcessError processError = new ProcessError(ProcessErrorConstants.ButtonActionHasBeenExecuted, new Object[] { sActionButtonID });
			ErrorAuditUtils.setErrors(processError,pdo.getIsHistory());

			// if the pdo is new (and this is a user save,
			// copy the current xml to the orignal xml prior to continuing
			/*
			if (pdo.isNew())
			{
				final XmlMetadata currentxml = pdo.getXmlMetadata(DASInterface.CURRENT_XML_MSG_KEY);
				pdo.addXmlDocument(XmlLocationType.XML_ORIG_MSG, currentxml.getPaymentType(), currentxml.getXml());
			}// EO if this payment was a new user save
			 */
			if (shouldContinueAfterTemplateManagement(pdo, admin, feedback))
				pdo=submitMessageProcessing(pdo, msgFieldsInput, admin, userHasChangedFields, sUserID, 
						bAutoFeederMode, sActionButtonID, response, feedback, saveFeedback);
			
  			if (("Approve Liq Reject".equals(sActionButtonID) || "Approve Liq Cancel".equals(sActionButtonID)) && feedback.isSuccessful()){

				//if message was liquidity rejected/canceled successfully, and it is an OPI/OSN - check if there is a matched message that should also be rejected/canceled
				boolean isOPI = MSG_CLASS_OPI.equals(pdo.getString(P_MSG_CLASS));
				boolean isOSN = MSG_CLASS_OSN.equals(pdo.getString(P_MSG_CLASS));

				if ((MESSAGE_STATUS_LIQ_REJECTED.equals(pdo.getString(P_MSG_STS))|| MESSAGE_STATUS_LIQ_CANCELED.equals(pdo.getString(P_MSG_STS)))&& (isOPI || isOSN)){

					PDO matchedPdoToReject = pdo.getLinkedMsg(isOPI?RELATION_TYPE_COVER:RELATION_TYPE_DIRECT);

					if ((matchedPdoToReject!=null)&&(!MESSAGE_STATUS_LIQ_REJECTED.equals(matchedPdoToReject.getString(P_MSG_STS)))&&(!MESSAGE_STATUS_LIQ_CANCELED.equals(matchedPdoToReject.getString(P_MSG_STS)))){

						if (isOSN && (MESSAGE_STATUS_WAIT_ACK.equals(matchedPdoToReject.getString(P_MSG_STS)) || MESSAGE_STATUS_COMPLETE.equals(matchedPdoToReject.getString(P_MSG_STS)))){

							//do not reject/cancel matched message, show a message to the user
							logger.info("Message {} was liquidity rejected/canceled successfully, but there is a linked direct msg {}, which is in {} status, and it will not be liq rejected/canceled automatically. A pop-up message will be displayed to user.",new Object[]{pdo.getMID(),matchedPdoToReject.getMID(),matchedPdoToReject.getString(P_MSG_STS)});

							ProcessError opiosnProcessError = new ProcessError(ProcessErrorConstants.CannotCancelMatchedOPI, new Object[]{});
							ErrorAuditUtils.setErrors(opiosnProcessError,pdo.getIsHistory());

							// Updates the feedback that will be displayed to the user.
							feedback.setFailure();
							feedback.setErrorCode(opiosnProcessError.getErrorCode());
							feedback.setErrorText(opiosnProcessError.getDescription());

						}else{//reject matched message

							logger.info("Message {} was liquidity rejected/canceled successfully. There is a linked msg {}, which is in {} status and is about to be liquidity rejected/canceled automatically too.",new Object[]{pdo.getMID(),matchedPdoToReject.getMID(),matchedPdoToReject.getString(P_MSG_STS)});
							//promote linked pdo to primary and start liquidity rejection/cancellation flow for it
							matchedPdoToReject.promoteToPrimary();
							matchedPdoToReject.set(D_BUTTON_ID,sActionButtonID);
							matchedPdoToReject.set(PDOConstantFieldsInterface.P_RELEASE_INDEX,"");
							matchedPdoToReject=submitMessageProcessing(matchedPdoToReject, new MessageFieldsInputData(matchedPdoToReject.getMID(), msgFieldsInput.getScreenSetID()), admin, new boolean[]{false}, sUserID, 
									bAutoFeederMode, sActionButtonID, response, feedback, saveFeedback);
							//promote original PDO back to primary
							pdo.promoteToPrimary();

						}
					}
				}
			}

		}catch (Throwable t){ 
			ExceptionController.getInstance().handleException(t, this);
			ErrorAuditUtils.onError(t, feedback);
			feedback.setException(t) ;
			// MSG_TODO: reload the screen, pdo, and message screen object
			feedback.getDialogs().getLast().setButtons(UserDialog.DIALOG_BUTTON_RELOAD_MSG);// MSG_TODO: reload
			bCommit = false ; 
		}finally {			
			try{ 
				//ThreadBoundCounterUTXWProxy.closeTx(bCommit) ;
				BOBasic.closeTx("[BOMessageHandle.submitMessage]", bCommit) ;
			}catch(Throwable t) { 
				ExceptionController.getInstance().handleException(t, this);
				ErrorAuditUtils.onError(t, feedback);
			}//EO inner tx release 
		}// EO catch block
		feedback.getDialogs().getLast().setButtons(UserDialog.DIALOG_BUTTON_CLOSE_MSG);// MSG_TODO: reload

		response.setFeedback(feedback);
		response.getFeedback().clearSuccessfullUserDialogs();

		logger.info(String.format(METHOD_RESULT, response.getFeedback()));
		

		return response;
	}// EOM

	/**
	* 
	*/
	private void handleNewDualUsersValue(String sDualControlRuleAction, PDO pdo, String sUserID)
	{
		final String RULE_ACTION_ADD_USER = "ADD_USER";
		final String RULE_ACTION_OVERRIDE_USER = "OVERRIDE_USER";
		final String RULE_ACTION_SKIP_CHECK = "SKIP_CHECK";
		final String RULE_ACTION_CLEAN = "CLEAN";

		final String TRACE_NEW_DUAL_USERS_VALUE = "Sets P_DUAL_USERS to {}.";

		

		String sNewDualUsers;

		String sCurrentDualUsers = pdo.getString(P_DUAL_USERS);

		if (RULE_ACTION_ADD_USER.equals(sDualControlRuleAction))
		{
			sNewDualUsers = isNullOrEmpty(sCurrentDualUsers) ? sUserID : sCurrentDualUsers + ServerConstants.POWER_SIGN + sUserID;
		}

		else if (RULE_ACTION_OVERRIDE_USER.equals(sDualControlRuleAction))
		{
			sNewDualUsers = sUserID;
			pdo.set(P_BASE_MSG_STS, pdo.getString(P_PREVIOUS_MSG_STS));
		}

		else if (RULE_ACTION_SKIP_CHECK.equals(sDualControlRuleAction))
		{
			sNewDualUsers = sCurrentDualUsers;
		}

		else if (RULE_ACTION_CLEAN.equals(sDualControlRuleAction))
		{
			sNewDualUsers = null;
			pdo.set(P_BASE_MSG_STS, pdo.getString(P_MSG_STS));
		}

		else
		{
			sNewDualUsers = null;
		}

		logger.info(TRACE_NEW_DUAL_USERS_VALUE, sNewDualUsers);
		pdo.set(P_DUAL_USERS, sNewDualUsers);

		
	}

  @AuthorizeUser(returnWebSessionInfo = true)
  @Expose
  @LoadPDO 
  public GlobalResponseDataComponentText saveMessage(final MessageFieldsInputData msgFieldsInput){
	  GlobalResponseDataComponentText response = null;
	  boolean bCommit = true ; 
	  Feedback feedback = new Feedback();
	  final String sMID = msgFieldsInput.getMID() ;

      try{ 
    	  final PDO pdo = PaymentDataFactory.load(sMID) ; 
    	  
    	  //ensure that the TX open/close paradigm is symmetric as an explicit close is invoked regardless of wether the 
    	  //start tx is invoked. the joinActiveSession will only incement the nested invocation count 
    	  //if an active tx exists. this is required as the tx is only opened if the continue with flow flag is set to true or in templates unchanged fields 
    	  //System.out.println(Thread.currentThread().getId() + " --> " +"SaveMessage(MessageInputData) --> INCREMENT --> joinActiveSession") ;
    	  //ThreadBoundCounterUTXWProxy.joinActiveSession() ;
    	  BOBasic.startTx("[BOMessageHandle.saveMessage(final MessageFieldsInputData msgFieldsInput)]") ; 
			
    	  final String sActionButtonID = msgFieldsInput.getFragmentID();
    	  pdo.set(D_BUTTON_ID, sActionButtonID);

		  // merge any modified fields into the podo if not invoked from the context of a service 
    	  if(!msgFieldsInput.isService()) { 
				this.mergeModifiedFieldsWithPdo(pdo, msgFieldsInput);
	
				String sScreenSetID = msgFieldsInput.getScreenSetID();
				if(!isNullOrEmpty(sScreenSetID)) executeEvents(pdo, msgFieldsInput, sScreenSetID, response);
	
				final String strMessageTables =  msgFieldsInput.getDirtyMessageTables().toString();
			    if (strMessageTables.contains(M_MSG_NOTES_GRID))
	            {
	                     ProcessError processError = new ProcessError(ProcessErrorConstants.UserHasAddedNewNote);
	                     ErrorAuditUtils.setErrors(processError, pdo);
	            }
				// finally if the server events have not raise an error, save the msg
				// if no actual fields changes were done by the user; e.g. pressing the 'Force Daily Limit' button.
				// Prior to saving the message prine the '40061' NEWJOURNAL entry ('User has changed fields') if no modifications were found
				if (msgFieldsInput.getUserModifiedFields() == null && !pdo.pruneUserModifiedFieldsNewJournalEntry()){
					// Error code 113: 'User has exit message without performing any action'.
					ProcessError processError = new ProcessError(ProcessErrorConstants.UserHasSavedMessageWithoutPerformingAnyAction);
					ErrorAuditUtils.setErrors(processError, pdo);
	          }else{ //modified fields for audit trail. 
	        	  ErrorAuditUtils.prepareUserModifiedFieldsNEWJOURNALEntry(pdo);
	          }//EO else if there were modified fields 
				
    	  }//EO if the context was not that of a service invocation

    	  // set the successful operation action int in the transient map of the pdo and clear after the invocation
    	  pdo.setTransient(D_SUCCESSFUL_OPERATION_ACTION, msgFieldsInput.get(KEY_INT_SUCCESSFUL_MSG_OPERATION_ACTION));

	      //handle the possibility of Partial Repetitive Templates functionality
	      if(pdo.getTemplateUnchangedFields() != null) {
	    	 
    		// Opens a transaction, which will be closed at the end of this message.
	    	 //System.out.println(Thread.currentThread().getId() + " --> " +"saveMessage(MessageInputData) --> START ---> Templates") ;
	    	//ThreadBoundCounterUTXWProxy.getStartedInstance(true/*silent Participation*/) ;
	    	BOBasic.startTx("[BOMessageHandle.submitMessage]") ; 
	    	  
        	feedback = this.handleUnchangedFields(pdo,pdo.getTemplateUnchangedFields());
        	 
      	  } //EO Partial Repetitive treatment

          if (feedback.isSuccessful()) {
      		response = this.saveMessage(sMID) ;
      		feedback = response.getFeedback();
      	  }//EOM 
	      
		  // clear the successfull operatiaon action
	      pdo.removeTransientField(D_SUCCESSFUL_OPERATION_ACTION);

	      if(!feedback.isSuccessful()){
              response = new UserResponse() ;
              response.setFeedback(feedback);
	      }//EO if successful operaetion
	      
      }catch(Throwable t) { 
    	  ExceptionController.getInstance().handleException(t, this);
    	  response = new UserResponse();
    	  ErrorAuditUtils.onError(t, response.getFeedback());
    	  bCommit = false ; 
      }finally{ 
    	 try{ 
    		BOMessageLoad.releaseLockedMessage(false, false, sMID);
			//ThreadBoundCounterUTXWProxy.closeTx(bCommit) ;
    		BOBasic.closeTx("[BOMessageHandle.saveMessage(final MessageFieldsInputData msgFieldsInput)]", bCommit) ; 
		}catch(Throwable t) { 
			ExceptionController.getInstance().handleException(t, this);
			ErrorAuditUtils.onError(t, feedback);
			response.setFeedback(feedback);
		}//EO inner tx release
      }//EO catch block 

      return response;
  }//EOM 
  
  @AuthorizeUser(returnWebSessionInfo = true)
  @Expose
  public UserResponse saveMessage(final String sMID)
	{
	  	logger.debug("save message {}",sMID);
	  	
	    final String sTxOriginator = "[BOMessageHandle.saveMessage(sMID)]" ; 
		final UserResponse response = new UserResponse();
		Feedback feedback = response.getFeedback();
		
		final PDO pdo = PaymentDataFactory.load(sMID);
		boolean bCommit = true ; 
		
		try{
			if (pdo != null)
			{
				String sOperationID = pdo.getString(D_BUTTON_ID);
				final BindingParameter operationParam = new BindingParameter((sOperationID == null ? MESSAGE_BUTTON_SAVE
						: sOperationID), DataType.STRING);
				
	
				// Will be used during the message release process, ('BOMessageLoad.releaseLockedMessage' method).
				pdo.setTransient(D_FIELDS_WERE_NOT_MODIFIED, pdo.fieldsWereNotModified(false/*bIgnoreAutomatedModifications*/));
	
				// if the action is in the context of autofeeder mode, and the current button (action) id supports the next button operation,
				// set the bAutoFeederMode to true so as to configure the next action in the user feedback in case of operation success
				boolean bAutoFeederMode = ("1".equals(pdo.getWithTransientLookup(D_AUTOFEEDER_MODE)));
				if (bAutoFeederMode)
				{
					final MessageLayoutCacheInterface msgLayoutCache = (MessageLayoutCacheInterface) CacheKeys.MiscResoucesKey
							.getSingle(MessageLayoutCacheInterface.class);
					bAutoFeederMode = ((Button) msgLayoutCache.getCachedComponent(sOperationID)).supportsAutoFeederNext();
				}// EO if in context of autofeeder mode
	
				// do not remove from local cache as the release lock will perform the removal in a
				// contorlled manner
				//start a tx if not already opened (will be taken care of in the ThreadBoundCounterUTXWProxy
				//System.out.println(Thread.currentThread().getId() + " --> " +"saveMessage(sMID) --> START ---> before Save") ;
				//ThreadBoundCounterUTXWProxy.getStartedInstance() ;
				BOBasic.startTx(sTxOriginator) ; 
				PaymentDataFactory.batchSave(false /* remove from cache */, pdo);
	
				// if the message was in the context of autofeeder, set the next button action instead of the D_SUCCESSFUL_OPERATION_ACTION value
				Integer iSuccessfullOperatinAction = (Integer) pdo.getWithTransientLookup(D_SUCCESSFUL_OPERATION_ACTION);
				if (iSuccessfullOperatinAction == null)
					iSuccessfullOperatinAction = UserDialog.DIALOG_BUTTON_CLOSE_MSG;
				// UserDialog.DIALOG_BUTTON_CLOSE_MSG
				final int iDialogButtonAction = (!bAutoFeederMode ? iSuccessfullOperatinAction : UserDialog.DIALOG_BUTTON_LOAD_NEXT_AUTOFEEDER_MSG);
				feedback.getDialogs().getLast().setButtons(iDialogButtonAction);// close/next message
	
				feedback.setErrorCode(ProcessErrorConstants.MessageOperationCompletedSuccesssfully);
				feedback.setErrorVariables(new BindingParameter[] { operationParam });
			}
			else
			{
				ErrorAuditUtils.onError(ProcessErrorConstants.PDONoMinfRecord, response.getFeedback(), sMID);
			}// EO if the pdo was not found
	
		}catch (ConcurrentModificationException e){
			bCommit = handleExceprionForSaveMessage(feedback, e,sTxOriginator);
			// Configure different user message for ConcurrentModificationException
			ErrorAuditUtils.onError(ProcessErrorConstants.MessageUpdatedByAnotherProcess, feedback, (Object[])null);	
			CacheKeys.ProcessPDOKey.removeFromLocalAndRemote(false,pdo);
		}catch (Throwable e){
			bCommit = handleExceprionForSaveMessage(feedback, e,sTxOriginator); 
		}finally{ 
			try{ 
				//System.out.println(Thread.currentThread().getId() + " --> " +"saveMessage(sMID) --> CLOSE ---> before Save") ;
				//ThreadBoundCounterUTXWProxy.closeTx(bCommit) ;
				BOBasic.closeTx(sTxOriginator, bCommit) ;
			}catch(Throwable t) { 
				ExceptionController.getInstance().handleException(t, this);
				ErrorAuditUtils.onError(t, feedback);
				feedback.setException(t) ; 
			}//EO inner tx release
		}// EO catch block
		return response;
	}// EOM

  private boolean handleExceprionForSaveMessage(Feedback feedback, Throwable e, final String sOriginator) {
	  boolean bCommit;
	  //if(!ThreadBoundCounterUTXWProxy.isNestedTx()) ExceptionController.getInstance().handleException(e, this);
	  if(BOBasic.isSameTxOriginator(sOriginator)) ExceptionController.getInstance().handleException(e, this);

	  // configure feedback and trace exception
	  ErrorAuditUtils.onError(e, feedback);

	  //set the exception in the feedback so that invokers can inspect it (e.g. submitMessageService())
	  feedback.setException(e) ; 

	  // set the response's json action to perform audit trail false so that the close operation
	  // will not treat the event as no changes close event and will save an audit trail entry
	  feedback.getDialogs().getLast().setJSONAction("ActionTypes.Close.bPerformAuditAction = false ;");
	  bCommit = false ;
	  return bCommit;
  }

	// /////////////////////////////////////////
	// /// START 'get message xml' METHODS /////
	// /////////////////////////////////////////
	
	@LoadPDO
	@Expose 
	@SkipInputValidation
	public SimpleResponseDataComponent getMessageXml(final String sMID, final PaymentType enumOutPaymentType,
			final Map mapCustomizations,  final Serializable oFndtMsgSubsetXml, final Serializable oSkelletonRootXml, 
														final Serializable oMergeInput){

		final SimpleResponseDataComponent response = new SimpleResponseDataComponent();

		try{
			// should be reinstated once the bo decoration was modified to include the pdo load interceptor
			// final PDO pdo = Admin.getContextPDO();
			final PDO pdo = PaymentDataFactory.load(sMID, oMergeInput);
			
			if(!pdo.isEmpty()) {
    			if (CallSource.Gui != Admin.getContextAdmin().getCallSource() && 2 == pdo.getInteger(PDOConstantFieldsInterface.P_IS_HISTORY)) 
	       			pdo.set(PDOConstantFieldsInterface.D_TEMPLATE_UNCHANGED_FIELDS, pdo.getNSetTemplateUnchangedFields());
			}
			// CREDIT SIDE
			// retrieve the D_SKIP_MESSAGE_REPAIR and if false, branch to message
			// repairing
			Feedback feedback = null;
//			final Boolean bShouldSkipMessageRepair = pdo.getBoolean(D_SKIP_MESSAGE_REPAIR);
//			if (bShouldSkipMessageRepair != null && !bShouldSkipMessageRepair)
//				feedback = this.formatOutMessage(pdo);

			// if the feedback indicated failure abort
			//if the enumOutPaymentType was not provided, return an error
			if (feedback != null && !feedback.isSuccessful()){
				response.setFeedback(feedback);
				return response;
			}// EO if the feedback indicated failure abort
			else if(enumOutPaymentType == null) {
				this.configureErrorFeedback(ProcessErrorConstants.GenericError, "No Target Payment Type was provided", feedback) ;
				response.setFeedback(feedback);
				return response;
			}//EO if there was no output payment type 

			// finally transform the pdo
			XmlObjectBase responseXmlRoot = null ; 
			
			if(oFndtMsgSubsetXml == null){ 
				responseXmlRoot = PaymentDataFactory.transformToXml(sMID, enumOutPaymentType, XmlLocationType.XML_MSG,
						mapCustomizations, oSkelletonRootXml);
			}else { 
				
				final TreeCursorInterface<LogicalFieldsXpath> fieldsCursor = new FndtMsgSubSetCursor((FndtMsgSubsetType)oFndtMsgSubsetXml, 
						enumOutPaymentType, XmlLocationType.XML_MSG) ;
				
				responseXmlRoot = PaymentDataFactory.transformToXml(sMID, mapCustomizations, fieldsCursor, oSkelletonRootXml) ; 
			}//EO else if the fields cursor was provided 

			response.setDataArray(new Object[] { responseXmlRoot, enumOutPaymentType });
		}catch (Throwable e){
			// configure feedback and trace exception
			ErrorAuditUtils.onError(e, response.getFeedback());
			ExceptionController.getInstance().handleException(e, this);
		}// EO catch block
		return response;
	}// EOM

	/**
	* 
	*/
	@Expose
	public final Feedback formatOutMessage(final String sMID)
	{
		return this.formatOutMessage(PaymentDataFactory.load(sMID));
	}

	private final Feedback formatOutMessage(final PDO pdo)
	{
		final String ERROR_MESSAGE = "Error has occurred during format out message";
		final String TRACE_MAPPING_OUT_UID = "Mapping out rule UID: {}.";

		

		Feedback feedback = new Feedback();

		try
		{

			MsgClassType msgClassType =  MessageUtils.getMsgClassType(pdo);	    	
			Mop mop = msgClassType.getDestMop(pdo);

			if (mop != null && mop.getExpectreply() != null)
			{
				Long expectReply = mop.getExpectreply();
				//QC # 16475 : Payment not to go to WAIT_ACK if Throttling mode && OUTBOUND
				if ( pdo.isOutboundThrottlingMode() && MESSAGE_STATUS_APPROVE_LIQ_REJECT.equals(pdo.getString(P_MSG_STS))) {
					expectReply = new Long(3);
				}
				// TODO:
				// Set the MUR = P_MID (Need to close this with Shlomi - maybe it should be done on WTX)
				if (expectReply == 1){
					logger.debug("Mop expectReply==1, changing status to {}",MESSAGE_STATUS_WAIT_ACK);
					pdo.set(P_MSG_STS, MESSAGE_STATUS_WAIT_ACK);
				}else if (expectReply == 2){
					logger.debug("Mop expectReply==2, changing status to {}",MESSAGE_STATUS_WAIT_CONFIRMATION);
					pdo.set(P_MSG_STS, MESSAGE_STATUS_WAIT_CONFIRMATION);
				}

				// TODO:
				// Remove <ACK_NAK> XML group from the XML_MSG and its related logical fields under it.
				// Remove <MOP_NOTIFICATION> XML group from the XML_MSG and its related logical fields under it.

				pdo.set(PDOConstantFieldsInterface.X_ACK_NAK_MSG, (String)null);
				pdo.set(PDOConstantFieldsInterface.X_IS_NAK, (String)null);
				pdo.set(PDOConstantFieldsInterface.X_IS_RJCT, (String)null);
				pdo.set(PDOConstantFieldsInterface.X_MOP_NOTIFICATION_MSG, (String)null);
				pdo.set(PDOConstantFieldsInterface.X_MOP_NOTIFICATION_MSG_TYPE, (String)null);
				pdo.set(PDOConstantFieldsInterface.X_RJCT_RSN, (String)null);
				pdo.set(PDOConstantFieldsInterface.P_ACK_STS, (String) null);			
			}
			pdo.set(D_RULE_TYPE_ID, RULE_TYPE_ID_MAPPING_OUT_SELECTION);
			this.manipulateMessageData(pdo.getMID(), new String[] { pdo.getString(P_OFFICE), ServerConstants.DEFAULT_SERVER_OFFICE_NAME });

			pdo.set(MF_FORMAT_OUT, MONITOR_FLAG_PROCESSED);
		}
		catch (Exception e)
		{
			ExceptionController.getInstance().handleException(e, this);
			configureErrorFeedback(1, ERROR_MESSAGE, feedback);
		}

		

		return feedback;
	}// EOM

	private final boolean prunePDO(final String sValue, final String sContent, final String[] arrFieldIdsToRemove,
			final boolean bShouldRemoveFromPdo, final PDO pdo)
	{

		boolean hadPruned = false;
		if (sValue.indexOf(sContent) != -1)
		{
			pdo.removePaymentField(bShouldRemoveFromPdo, arrFieldIdsToRemove);
			hadPruned = true;
		}

		return hadPruned;
	}// EOM

	// /////////////////////////////////////////
	// /// START 'performGroupAction' METHODS /////
	// /////////////////////////////////////////

	/**
	 * Returns Group Actions data. trace_todo: could not remove the user authorized as the action id is not a formal arg
	 */
	@AuthorizeUser(returnWebSessionInfo = true)
	@Expose
	public SimpleResponseDataComponent performGroupAction(GroupActionRequestData groupActionRequestData)
	{
		String sUserID = null;

		final String sActionID = groupActionRequestData.getActionID();

		HashMap hmOptionalFields = groupActionRequestData.getOptionalFields();
		GroupActionInputDataForMessage[] arrGroupActionInputDataForMessage = groupActionRequestData.getDataForMessage();

		SimpleResponseDataComponent response = new SimpleResponseDataComponent();
		Feedback feedback = new Feedback();
		String sActionDescription = groupActionRequestData.getActionDescription();

		WebSessionInfo webSessionInfo = null;

		// Successfull user authorization check.
		if ((webSessionInfo = this.isUserAuthorized(feedback, sActionID)) != null)
		{

			sUserID = webSessionInfo.getUserID();

			GroupActionOutputDataForMessage[] arrGroupActionOutputDataForMessage = new GroupActionOutputDataForMessage[arrGroupActionInputDataForMessage.length];

			int iLength = arrGroupActionInputDataForMessage.length;

			for (int iIndex = 0; iIndex < iLength; iIndex++)
			{
				GroupActionInputDataForMessage input = arrGroupActionInputDataForMessage[iIndex];
				String sMID = input.getMid();

				MessageFieldsInputData messageFieldsInputData = new MessageFieldsInputData(sMID, null);
				messageFieldsInputData.put(FRAGMENT_ID_KEY, sActionID);
				
				FieldsContainer fc = new FieldsContainer();
				for (Object key : hmOptionalFields.keySet()){
					fc.addField(key.toString(), (String)hmOptionalFields.get(key.toString()));
				}
				messageFieldsInputData.put(USER_MODIFIED_FIELDS_KEY, fc);

				GlobalResponseDataComponentText submitResponse = submitMessage(messageFieldsInputData);

				arrGroupActionOutputDataForMessage[iIndex] = new GroupActionOutputDataForMessage(sMID);

				if (!submitResponse.getFeedback().isSuccessful())
				{
					arrGroupActionOutputDataForMessage[iIndex].setErrorDescription(submitResponse.getFeedback().getUserErrorText());
				}
			}

			if (feedback.isSuccessful())
			{
				response.setDataArray(new Object[] { arrGroupActionOutputDataForMessage });
			}
		}

		if (!feedback.isSuccessful())
		{
			response = configureErrorResponse(feedback.getErrorText(), feedback, false);
		}

		return response;
	}

	/**
	 * @author Guy Segev
	 * @date Aug 12, 2007 <br>
	 * <br>
	 *       Specialised version of the superclasse's {@link #isUserAuthorized}, implementing the following <br>
	 *       logic: <br>
	 *       1. Invocation of the superclasses {@link #isUserAuthorized} and if successfull, <br>
	 *       2. Retreival of the button id's (group action's) permission from the ASCacheFactory's incremental cache. <br>
	 *       3. Retreival of the entitlement name data, and the orig_perm_prof_access in particular, for the session id. <br>
	 *       4. Validation of the existance of the button ID's permission in the user's permission set. <br>
	 * @param admin {@link Admin} instance housing the session id
	 * @param feedback {@link Feedback} instance
	 * @param hmWebSessionInfo Map containing the user's entitlement name amongst other data.
	 * @param sActionId The given button ID whose permission should exist in the user's permissino set.
	 * @return true if the user session is authorised as well holding a valid permission for the Button ID (group action) false if otherwise.
	 */
	@SkipInputValidation
	public WebSessionInfo isUserAuthorized(Feedback feedback, String sActionId)
	{

		WebSessionInfo webSessionInfo = null;

		if ((webSessionInfo = this.performUserAuthoization(feedback)) == null)
			return null;

		// Gets the user permission for the group action from the MESSAGE_GROUP_ACTIONS table
		// for the action id.
		String sPermission = ASCacheFactory.getInstance().getButtonGroupActionPermission(sActionId);

		// Finally, determines whether the user has the permission in its permissions list.
		String sUserEntitlementName = webSessionInfo.getUEntName();

		UserEntitlementData entitlemetCodeDataContainer = EntitlementsDataFactory.getInstance().getUserEntitlementData(sUserEntitlementName);

		String sAccessLevelPermissionList = entitlemetCodeDataContainer.getORIG_PERM_PROF_ACCESS();
		char[] arrLevel = new char[1];

		feedback = m_permissionHandler.checkPermissionInList(sPermission, sAccessLevelPermissionList, false, arrLevel);

		return (feedback.isSuccessful() ? webSessionInfo : null);
	}

	@LoadPDO
	@Expose
	public SimpleResponseDataComponent manipulateMessageData(final String sMID, String[] arrObjectAttchments)
	{
		final String TRACE_MANIPULATION_RULE_ID_AND_EXEC_SCRIPT = "Current manipulation rule UID: {}; Execution script:\n{}";
		//final GlobalTracer tracer = Admin.m_contextTracer.get();

		SimpleResponseDataComponent response = new SimpleResponseDataComponent();

		try
		{
			// first retrieve the rule type id, rule sub type and invoke the rule on the
			// message type
			final PDO pdo = Admin.getContextPDO();
			final String sRuleTypeId = pdo.getString(D_RULE_TYPE_ID);
			final String sRuleSubType = pdo.getString(D_RULE_SUB_TYPE);
			if (arrObjectAttchments == null || (arrObjectAttchments.length == 1 && GlobalUtils.isNullOrEmpty(arrObjectAttchments[0])))
				arrObjectAttchments = new String[] { pdo.getString(P_OFFICE) };
			final RuleResults ruleResults = m_internalRuleExecutionLogging.executeRule(Admin.getContextAdmin(), sRuleTypeId, sRuleSubType, pdo.getMID(),
					arrObjectAttchments);

			if (ruleResults.getCompletionCode() == CompletionCode.FAILURE)
			{
				ErrorAuditUtils.onError(ProcessErrorConstants.RuleExecutionError, response.getFeedback());
				return response;
			}// EO if there was an error

			// iterate over the results, aggregate the resutls execution scripts in an array and execute the scripts
			final List<RuleResult> listRuleResults = ruleResults.getResults();

			final StringBuilder scriptBuilder = new StringBuilder();

			String sDataManipulationId = null;
			Prules dataManipulationMetadata = null;
			final StringBuilder scriptIdBuilder = new StringBuilder(); 

			logger.info("Manipulation rules list size: {}.", listRuleResults.size());			
			
			for (RuleResult ruleResult : listRuleResults)
			{

				sDataManipulationId = ruleResult.getAction();
				scriptIdBuilder.append(sDataManipulationId).append('^') ; 

				// Retrieve the rule JPA from cache
				dataManipulationMetadata = CacheKeys.PRulesUIDKey.getSingle(sDataManipulationId);

				// if dataManipulationMetadata is null log an error
				if (dataManipulationMetadata == null)
				{
					logger.error("Data Manipulation Script with Id: {} was does not exist", sDataManipulationId);
					continue;
				}// EO if the dataManipulationMetadata was null

				String sExecScript = dataManipulationMetadata.getExecScript();
				logger.debug(TRACE_MANIPULATION_RULE_ID_AND_EXEC_SCRIPT, sDataManipulationId, sExecScript);

				// append the script to the buidler
				scriptBuilder.append(NEWLINE).append(sExecScript);

			}// EO while there are more rule results

			// finally, if there were rule results, execute the script
			if (listRuleResults.size() == 0)
				logger.warn("No Data Manipulation Scripts were associated with rule details: " + ruleResults.toString());
			else
			{
				String sScript = scriptBuilder.toString();
				manipulateMessageDataScript(scriptIdBuilder.toString(), sScript);
			}
		}
		catch (Exception e)
		{
			ExceptionController.getInstance().handleException(e, this);
			ErrorAuditUtils.onError(e, response.getFeedback());
		}// EO catch block

		return response;
	}// EOM

	@LoadPDO
	@Expose
	public final SimpleResponseDataComponent manipulateMessageData(final String sManipulationDataID)
	{
		final SimpleResponseDataComponent response = new SimpleResponseDataComponent();

		final Prules dataManipulationMetadata = CacheKeys.PRulesUIDKey.getSingle(sManipulationDataID);
		try
		{
			manipulateMessageDataScript(sManipulationDataID, dataManipulationMetadata.getExecScript());
		}
		catch (Exception e)
		{
			ExceptionController.getInstance().handleException(e, this);
			ErrorAuditUtils.onError(e, response.getFeedback());
		}// EO catch block

		return response;
	}// EOC

	/**
	* 
	*/
	private final void manipulateMessageDataScript(final String sScriptId, String sScript) throws EventUncheckedException
	{
		/*final GlobalTracer tracer = Admin.m_contextTracer.get();
		final Map<String, ?> DATA_MANIPULATION_CONTEXT = new HashMap();
		logger.info(tracer.debug("About to execute the following script:\n" + script));

		m_EventBus.fireEvent(Admin.getContextAdmin().getFlowID(), ServerEvents.onDataManipulation, DATA_MANIPULATION_CONTEXT,
				new String[] { script }, BORuleExecution.getRulesInfrastructureScript());*/
		
		m_EventBus.fireDataManipulationScript(sScriptId, sScript, BORuleExecution.getRulesInfrastructureScript()) ;
	}

	/**
	 * Invokes the matching mapping rule, (rule type ID 156; the rule UID itself was defined in the passed MatchingCheck profile).
	 */
	@Expose(type = ExposureType.InternalInterface)
	public void invokeMatchingMappingRule(com.fundtech.cache.entities.MatchingCheck matchingCheck)
	{
		final String TRACE_BEFORE_MANIPULATE_MESSAGE_DATA = "Before executing 'BOMessageHandle.manipulateMessageData' with rule UID {}.";
		final String TRACE_AFTER_MANIPULATE_MESSAGE_DATA = "After executing 'BOMessageHandle.manipulateMessageData'.";
		final String TRACE_NO_MANIPULATE_MESSAGE_DATA_EXECUTION = "Null matching mapping rule UID; didn't execute message manipulation !";
		final String TRACE_NULL_MATCHING_CHECK_PROFILE = "Null matching check profile --> no matching mapping rule will be executed !!!";

		

		if (matchingCheck != null)
		{
			String sMatchingMappingRuleUID = matchingCheck.getMatchingMappingUidPrules();
			if (sMatchingMappingRuleUID != null)
			{
				logger.info(TRACE_BEFORE_MANIPULATE_MESSAGE_DATA, sMatchingMappingRuleUID);
				manipulateMessageData(sMatchingMappingRuleUID);
				logger.info(TRACE_AFTER_MANIPULATE_MESSAGE_DATA);
			}
			else
			{
				logger.info(TRACE_NO_MANIPULATE_MESSAGE_DATA_EXECUTION);
			}
		}

		else
		{
			logger.info(TRACE_NULL_MATCHING_CHECK_PROFILE);
		}

		
	}

	@SkipInputValidation
	@Expose
	public final SimpleResponseDataComponent generateMsgComponentFragment(final Map parametersMap)
	{

		final SimpleResponseDataComponent response = new SimpleResponseDataComponent();

		try
		{
			final Object[] arrDataArray = ScreensetPagesGenerator.generateComponentFragment(parametersMap);
			response.setDataArray(arrDataArray);
		}
		catch (Exception e)
		{
			ExceptionController.getInstance().handleException(e, this);
			ErrorAuditUtils.onError(e, response.getFeedback());
		}// EO catch block

		return response;
	}// EOM

	@Expose
	public final UserResponse saveScreenset(final MessageScreenSetSaveRequestData inputContainer)
	{
		return ScreensetPagesGenerator.saveScreenSet(inputContainer);
	}// EOM

	@Expose
	@AuthorizeUser(returnWebSessionInfo = true)
	public final SimpleResponseDataComponent invokeClientAjaxEvent(final MessageFieldsInputData parameterMap)
	{

		final SimpleResponseDataComponent response = new SimpleResponseDataComponent();

		try
		{
			// load the pdo
			final PDO pdo = CacheKeys.UserMessageKey.getSingleUserPDO(parameterMap.getMID());

			if (pdo == null)
			{
				ErrorAuditUtils.onError(ProcessErrorConstants.PDONoMinfRecord, response.getFeedback(), parameterMap.getMID());
				return response;
			}// EO if the pdo was null

			String sFieldId = parameterMap.getFragmentID();

			// merge any modified fields into the podo
			this.mergeModifiedFieldsWithPdo(pdo, parameterMap);

			// rertieve the event types array from the param map
			final EventType[] arrEventTypes = (EventType[]) parameterMap.get(EVENT_TYPES_KEY);

			final Map<EventType, List<ScriptResult>> mapEventResponses = m_EventBus.fireEvent(parameterMap.getScreenSetID(), parameterMap,
					new String[] { sFieldId }, arrEventTypes);

			List<ScriptResult> listResults = null;
			final StringBuilder responseBuilder = new StringBuilder();

			for (EventType eventType : arrEventTypes)
			{
				listResults = mapEventResponses.get(eventType);

				if (listResults == null)
					continue;

				// iterate over the responses and append them all into one String
				for (ScriptResult scriptResult : listResults)
				{
					responseBuilder.append(scriptResult.getScriptResult()).append(NEWLINE);
				}// EO while there are more event responses
			}// EO while there are more event types

			response.setDataArray(new Object[] { responseBuilder.toString() });

		}
		catch (EventUncheckedException t)
		{
			final String sMessage = t.getMessage();
			configureErrorFeedback(1, (sMessage == null ? "Null Pointer" : sMessage), response.getFeedback());
		}// EOM

		return response;
	}// EOM

	/**
	 * @author Guy Segev
	 * @date Aug 12, 2007 <br>
	 * <br>
	 *       Commits or rollsback SQL connection and JMS queue session in accordance with the bShouldCommit flag. <br>
	 *       The method will ensure that both the resources are not null. <br>
	 *       Moreover, each of the finalisation flows, is individually encapsulated in a try-catch block <br>
	 *       to ensure that the finalisation would occur for both in an event of an exception in one <br>
	 * @param sqlConnection {@link java.sql.Connection} instance to commit or rollback
	 * @param jmsSessionContext {@link JmsSessionContext} instance, encapsuating a {@link QueueSession} instance <br>
	 *            to commit or rollback
	 * @param bShouldCommit True to commit; False to rollback
	 * @param feedback {@link Feedback} instance indicating this method's results.
	 * @return The same formal args {@link Feedback} or if null a new one.
	 */
	private Feedback finaliseResources(Connection sqlConnection, JmsSessionContext jmsSessionContext, boolean bShouldCommit, Feedback feedback)
	{
		// Finalizes the SQL connection.
		try
		{
			if (sqlConnection != null)
			{
				if (bShouldCommit)
				{
					sqlConnection.commit();
				}
				else
				{
					sqlConnection.rollback();
				}
			}
		}

		catch (Exception e)
		{
			processException(e, feedback);
		}

		// Finalizes the JMS connection.
		try
		{
			if (jmsSessionContext != null && jmsSessionContext.isTransacted())
			{
				if (bShouldCommit)
				{
					jmsSessionContext.getSession().commit();
				}
				else
				{
					jmsSessionContext.getSession().rollback();
				}
			}
		}
		catch (Exception e)
		{
			processException(e, feedback);
		}

		return feedback;
	}

	/**
	 * Constructs and returns the message that will be sent using JMS to the background server.
	 */
	private String constructGroupActionMessageForJMS(String sFPID, String sActionID, String sUserID)
	{
		final String TRACE_MSG_CONTENT_PREFIX = "BOMessageHandler.constructGroupActionMessageForJMS - message: {}";

		String sGroupActionMessageForJMS = new StringBuffer(sFPID).append(ServerConstants.SEMI_COLON).append(sActionID).append(
				ServerConstants.SEMI_COLON).append(sUserID).toString();

		logger.info(TRACE_MSG_CONTENT_PREFIX, sGroupActionMessageForJMS);

		return sGroupActionMessageForJMS;
	}

	/**
	 * @author Guy Segev
	 * @date Aug 12, 2007 <br>
	 * <br>
	 *       In event wheree an error had occured during bulk processing, the current implemented policy, <br>
	 *       would mark all messages as 'failed' <br>
	 * @param arrGroupDataProcessingInput Structure containing the individual message details.
	 * @param arrGroupDataProcessingOutput Structure housing the message otuput report.
	 * @param sErrorMessage Error message configured for all messages uniformally.
	 */
	private void configureGroupActionOutputDataForMessage(GroupActionInputDataForMessage[] arrGroupDataProcessingInput,
			GroupActionOutputDataForMessage[] arrGroupDataProcessingOutput, String sErrorMessage)
	{
		int iLength = arrGroupDataProcessingOutput.length;
		String sMid = null;
		for (int iIndex = 0; iIndex < iLength; iIndex++)
		{

			sMid = arrGroupDataProcessingInput[iIndex].getMid();
			if (arrGroupDataProcessingOutput[iIndex] != null)

				arrGroupDataProcessingOutput[iIndex].setErrorDescription(sErrorMessage);
			else
				arrGroupDataProcessingOutput[iIndex] = new GroupActionOutputDataForMessage(sMid, sErrorMessage);
		}// while there are more messages output to configure
	}

	@Override
	public void businessObjectActivate()
	{
		super.businessObjectActivate();
	}// EOM

	@Override
	public void businessObjectPassivate()
	{
		super.businessObjectPassivate();
	}// EOM

	@Override
	public void businessObjectRemove()
	{
		super.businessObjectRemove();
	}// EOM

	/**
   * handles the association of a template to a user   
	*/
	@AuthorizeUser(returnWebSessionInfo = true)
	@Expose
  public GlobalResponseDataComponentText handleTemplateAssociation(final MessageFieldsInputData msgFieldsInput) 
	{
		

		GlobalResponseDataComponentText response = new UserResponse();
		Feedback feedback = response.getFeedback();

		try
		{
			final String sTemplateMID = msgFieldsInput.getMID();

			final PDO pdo = CacheKeys.UserMessageKey.getSingleUserPDO(sTemplateMID);
			if (pdo == null)
			{
				ErrorAuditUtils.onError(ProcessErrorConstants.PDONoMinfRecord, response.getFeedback(), sTemplateMID);
				return response;
			}

			// curently button ID comes in the form of ParentID.FieldID
			String[] aTemp = msgFieldsInput.getFragmentID().split(GlobalConstants.REGEX_DOT);
			final String sActionButtonID = (aTemp.length == 2) ? aTemp[1] : aTemp[0];

			final String sActionButtonName = msgFieldsInput.getFragmentValue();

			pdo.set(D_BUTTON_ID, sActionButtonID);

			final boolean[] arrMessageReadonlyPointer = new boolean[1];
			feedback = checkUserPermission(pdo, sActionButtonID, arrMessageReadonlyPointer, feedback);

			if (!feedback.isSuccessful())
			{
				response.setFeedback(feedback);
				return response;
			}

			// 'Associate Template' action.
			if (MESSAGE_BUTTON_ASSOCIATE_TEMPLATE.equals(sActionButtonID))
			{
				feedback = associateTemplate(sTemplateMID);
			}

			// inform the user operation is successful
       if (feedback.isSuccessful()) {
				feedback.setErrorCode(ProcessErrorConstants.MessageOperationCompletedSuccesssfully);
				feedback.setErrorVariables(new BindingParameter[] { new BindingParameter(sActionButtonName, DataType.STRING) });
			}

			// Adds NEWJOURNAL entry for the button execution; error code 40090: '|1 has been executed'.
			ProcessError processError = new ProcessError(ProcessErrorConstants.ButtonActionHasBeenExecuted, new Object[] { sActionButtonID });
			ErrorAuditUtils.setErrors(processError,pdo.getIsHistory());

			response.setFeedback(feedback);
		}

		catch (Throwable t)
		{
			ExceptionController.getInstance().handleException(t, this);
			ErrorAuditUtils.onError(t, feedback);
			feedback.getDialogs().getLast().setButtons(UserDialog.DIALOG_BUTTON_RELOAD_MSG);
			response.setFeedback(feedback);
		}

		

		return response;
	}

	/**
	*    
	*/
	private Feedback associateTemplate(String sTemplateMID)
	{
		

		Feedback feedback;
		final WebSessionInfo webSessionInfo = Admin.getContextAdmin().getWebSessionInfo();
		final String sUserID = webSessionInfo.getUserID();

		feedback = m_daoMessage.isUserTemplateExist(sUserID, sTemplateMID);
		if (feedback.isSuccessful())
		{
			feedback = m_daoMessage.associateTemplate(sUserID, sTemplateMID, 2);
		}

		

		return feedback;
	}

  /*
 * YONI S - not in use as for 10/2/2010
	*/
/*private Feedback cancelTemplate(String sTemplateMID,String sTemplateType)
	{
		
		final String ASSOCIATED = "A";
		Feedback feedback = new Feedback();

		// STEP 1 -
		// Standing orders treatment.
		// Implementation according tho the original requirement - validating through Standing Order profile
    DTODataHolder dtoActiveStandingOrders = m_daoMessage.checkAssociatedStandingOrder(sTemplateMID);
    Feedback feedback = dtoActiveStandingOrders.getFeedBack();
    
    if (feedback.isSuccessful())
    {
      if (!dtoActiveStandingOrders.isEmpty())//meaning we cannot cancel te Template since there are asocaited standing orders
      {
        final String STANDING_ORDER_NAME = "SO_NAME";
        StringBuilder sbAssociatedStandingORders = new StringBuilder();
        for(int i = 0; i < dtoActiveStandingOrders.getRowsNumber();i++)
        {
          sbAssociatedStandingORders.append(dtoActiveStandingOrders.getColumnDataByRow(STANDING_ORDER_NAME,i)).append(GlobalConstants.COMMA);
        }       
        feedback.setFailure();
        feedback.setErrorCode(40135);//Cannot cancel template
        feedback.setErrorVariables(new BindingParameter[]{new BindingParameter(sbAssociatedStandingORders.toString(), DataType.STRING)});
      }      
    }

		// Implementation according to the updated requirement - through Template tyep MINF logical field
		if (sTemplateType.equals(ASSOCIATED))
		{
			feedback.setFailure();
			feedback.setUserErrorText("Cannot cancel the template since there are standing orders associated with it.");
		}

		// STEP 2 -
		// Deletion from USER_TEMPLATES.
		if (feedback.isSuccessful())
		{
			feedback = m_daoMessage.cancelTemplate(sTemplateMID);
		}

		

		return feedback;
  }*/
  private Feedback handleUnchangedFields(PDO pdo, String unchangedFields) {
	  
	  
	  
		
	  String[] arrUnchangedFields = unchangedFields.split(GlobalConstants.COMMA);
	  StringBuilder sb =  new StringBuilder();
	  Feedback feedback = new Feedback();
	  String fieldName = null, sFieldElement = null ; 
	  int iIndexOfOccurrenceParenthesis = -1, iOccurrence = -1 ;  
	  
	  final Map<Object, PaymentFieldInterface> mapPaymentData = pdo.getDataMap() ; 
	  PaymentFieldInterface paymentField = null ; 
	  Object oValue = null ;  
	  
	  for (int i = 0; i< arrUnchangedFields.length; i++ ) {
		  sFieldElement = fieldName = arrUnchangedFields[i];
		
	   	//only fields with values are saved		   	
	   	if (sFieldElement.indexOf(GlobalConstants.DOT)>0) {
	   		//in case the fieldId is in format of <<parentId>>.<<childId>> - get the child Id 
	   		fieldName = sFieldElement.split(GlobalConstants.REGEX_DOT)[1];
	   	}else if((iIndexOfOccurrenceParenthesis = fieldName.indexOf('[')) != -1) { 
	   		iOccurrence = Integer.parseInt(sFieldElement.substring(iIndexOfOccurrenceParenthesis+1, sFieldElement.length()-1)) ; 
	   		fieldName = sFieldElement.substring(0, iIndexOfOccurrenceParenthesis) ; 
	   	}else {
	   		
	   	}//EO else if the field has no twist 
	   	
	   	if((paymentField = mapPaymentData.get(fieldName)) == null) continue ; 
	   	//else 
	   	//cr 110924 if you dont send the X_RMT_INF_USTRD in the requets or regular field
	   	if(iIndexOfOccurrenceParenthesis == -1 || !com.fundtech.core.paymentprocess.data.fields.FieldType.isXmlType(paymentField.getFieldType())) {
	   		oValue = paymentField.get();
	   	}
	    //cr 110924 when request  include  X_RMT_INF_USTRD iOccurrence - 1 becoude it start from 0 not 1
	   	else if(iIndexOfOccurrenceParenthesis != -1 && com.fundtech.core.paymentprocess.data.fields.FieldType.isXmlType(paymentField.getFieldType())){
	   		oValue = paymentField.get(new Object[]{fieldName, iOccurrence -1 });
	   	}
	   //	oValue = (iIndexOfOccurrenceParenthesis == -1 || !FieldType.isXmlType(paymentField.getFieldType()) ? paymentField.get() : paymentField.get(new Object[]{fieldName, iOccurrence})) ;
	   	//oValue = (iIndexOfOccurrenceParenthesis == -1 ? paymentField.get() : paymentField.get(new Object[]{fieldName, iOccurrence})) ; 
	   	if(oValue != null) sb.append(sFieldElement).append(GlobalConstants.COMMA);
	  }//EO while there are more template unmodifiable fields 
	   
	   //if there are unchanged fields save them in DB 
	   if (sb != null && sb.length()> 0) { 
		   sb.deleteCharAt(sb.length()-1) ; //delete the trailing comma 
		   pdo.setTemplateUnchangedFields(sb.toString());
	   }//EO if there were fields 

	   
	  
	   return feedback;
	}//EOM
  
  
  private boolean shouldContinueAfterTemplateManagement(PDO pdo, Admin admin, Feedback feedback) throws Throwable
  {
//	  At the beginning of the Message Submit service needs to do the following validations - 
//		  a.	If P_IS_HISTORY = 2 (Template) and the PDO has an MFAMILY entry with Relation type 'Original Template^Future Changes' then 
//		  	i.	Exit with failure - No action is permitted on a Template pending Future changes. 
//		  b.	If P_IS_HISTORY = 2 (Template) and the PDO has an MFAMILY entry with Relation type 'Future Changes^Original Template' and D_BUTTTON_ID = 'Cancel' then 
//	  		i.	Exit with failure - Cancel action is not permitted on a Template pending Future changes. 
//	  	  c.	If P_IS_HISTORY = 2 (Template) and the PDO has an MFAMILY entry with Relation type 'Future Changes^Original Template' and D_BUTTTON_ID = 'Retract' 
//	  	  					(new action available only on future pending action) then 
//			i.	Add NewJournal for the Retraction action
//			ii.	Copy all the NewJournal entries from the main PDO (Future Changes) to the Original PDO (Original Template)
//			iii.	Copy all the MSGNOTES entries from the main PDO (Future Changes) to the Original PDO (Original Template)
//			iv.	Delete physically the MINF entry of the main PDO.P_MID (Within the DB we have a trigger that will delete all the other message related tables)
//			v.	Commit and exit.

	  
	  
	  boolean shouldContinue = true;
//	  template
	  if (pdo.getInteger(PDOConstantFieldsInterface.P_IS_HISTORY) != null && pdo.getInteger(PDOConstantFieldsInterface.P_IS_HISTORY) ==2)
	  {
		  if (pdo.isRelationExist(MessageConstantsInterface.RELATION_TYPE_ORIGINAL_TEMPLATE, MessageConstantsInterface.RELATION_TYPE_FUTURE_CHANGES))
		  {
			  ErrorAuditUtils.setError(ProcessErrorConstants.NoActionIsNotPermited, pdo.getMID(), pdo.getIsHistory(), feedback);
			  shouldContinue = false;
		  }else if (pdo.isRelationExist(MessageConstantsInterface.RELATION_TYPE_FUTURE_CHANGES, MessageConstantsInterface.RELATION_TYPE_ORIGINAL_TEMPLATE)
				  && pdo.getString(PDOConstantFieldsInterface.D_BUTTON_ID).equals(MessageConstantsInterface.MESSAGE_BUTTON_CANCEL))
		  {	
			  ErrorAuditUtils.setError(ProcessErrorConstants.CancelActionIsNotPermited, pdo.getMID(), pdo.getIsHistory(), feedback);
			  shouldContinue = false;
		  }else if (pdo.isRelationExist(MessageConstantsInterface.RELATION_TYPE_FUTURE_CHANGES, MessageConstantsInterface.RELATION_TYPE_ORIGINAL_TEMPLATE)
				  && pdo.getString(PDOConstantFieldsInterface.D_BUTTON_ID).equals(MessageConstantsInterface.MESSAGE_BUTTON_RETRACT))
		  {	
			  ErrorAuditUtils.setError(ProcessErrorConstants.RetractionAction, pdo.getMID(), pdo.getIsHistory(), null);
			  
			  PDO futurePdo = pdo;
			  PDO originalPdo = pdo.getLinkedMsg(MessageConstantsInterface.RELATION_TYPE_ORIGINAL_TEMPLATE);
			  
			  
			  for (Newjournal newJournal : futurePdo.getNSetListNEWJOURNAL()) 
			  {
				  originalPdo.addNewjournal(newJournal);
			  }

			  for (MsgNotesLineType msgNote : futurePdo.getNSetListMSGNOTES()) 
			  {
				  originalPdo.addMsgnotes(msgNote);
			  }
			  
			  originalPdo.removeMfamily(MessageConstantsInterface.RELATION_TYPE_ORIGINAL_TEMPLATE, MessageConstantsInterface.RELATION_TYPE_FUTURE_CHANGES);
			  
			  PaymentDataFactory.deletePayments(futurePdo);
			  this.saveMessage(originalPdo.getMID());
			  
			  CacheKeys.ProcessPDOKey.removeFromLocalAndRemote(futurePdo);
			  shouldContinue = false;
		  }else
		  {
			  // Remove the first 6042 error code from msgErr CR 113450 add new boolean addError true will add error false will not.
			  GlobalAbstractResponseDataComponent response = m_matchingCheckLogging.performDuplicateCheck(admin, pdo.getMID(),false,false);
			  
			  if (MessageConstantsInterface.MESSAGE_STATUS_DUPEX.equals(pdo.getString(PDOConstantFieldsInterface.P_MSG_STS)))
			  {
				  ErrorAuditUtils.setError(ProcessErrorConstants.TemplateMessageIsAlreadyExist, pdo.getMID(), pdo.getIsHistory(), feedback);
				  pdo.set(PDOConstantFieldsInterface.P_MSG_STS, MessageConstantsInterface.MESSAGE_STATUS_REPAIR);
				  shouldContinue = false;
				  
				 // List<Msgerr> msgErrorslist = pdo.getListMSGERR();
				  //if((msgErrorslist != null) && (msgErrorslist.size() > 1)) {
	 			  	//	msgErrorslist.remove(0);
				  //}
	 			   
			  }
				  
		  }
			  
			  
		  
	  }
	
	  return shouldContinue;
  }
}
