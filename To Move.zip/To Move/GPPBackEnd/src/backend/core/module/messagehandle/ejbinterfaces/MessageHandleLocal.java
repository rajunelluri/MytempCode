package backend.core.module.messagehandle.ejbinterfaces;

import javax.ejb.Local;

/**
 * Local interface for MessageHandle.
 */
@Local
public interface MessageHandleLocal extends MessageHandle{} ; 