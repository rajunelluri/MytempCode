package backend.core.module.messagehandle.ejb;

import javax.ejb.Stateless;
import backend.core.SuperSLSB;
import com.fundtech.core.security.Admin;
import backend.businessobject.proxies.interceptors.InterceptorSetType;
import backend.core.module.messagehandle.businessobjects.BOMessageHandle;
import backend.core.module.messagehandle.ejbinterfaces.MessageHandleLocal;
import backend.core.module.messagehandle.ejbinterfaces.MessageHandle;

@Stateless
public class MessageHandleBean extends SuperSLSB<MessageHandle> implements MessageHandleLocal, MessageHandle{
	
	public MessageHandleBean() { super(backend.core.module.messagehandle.businessobjects.BOMessageHandle.class, InterceptorSetType.Complete) ; }//EOM
	
	
	/** 
	 * Audits an action.
	 */
	public com.fundtech.datacomponent.response.UserResponse auditAction(final Admin admin, com.fundtech.datacomponent.request.AuditActionInputData auditActionInputData ) {
		return this.m_bo.auditAction(admin, auditActionInputData ) ;
	}//EOM

	/** 
	 * @param fndtBatchMsg
	 * @return
	 */
	public java.io.Serializable submitMessageService(final Admin admin, java.io.Serializable fndtBatchMsg ) {
		return this.m_bo.submitMessageService(admin, fndtBatchMsg ) ;
	}//EOM

	/** 
	 * @param msgFieldsInput
	 * @param pdo
	 * @return
	 */
	public com.fundtech.datacomponent.response.GlobalResponseDataComponentText submitMessage(final Admin admin, com.fundtech.datacomponent.request.MessageFieldsInputData msgFieldsInput ) {
		return this.m_bo.submitMessage(admin, msgFieldsInput ) ;
	}//EOM

	public com.fundtech.datacomponent.response.GlobalResponseDataComponentText saveMessage(final Admin admin, com.fundtech.datacomponent.request.MessageFieldsInputData msgFieldsInput ) {
		return this.m_bo.saveMessage(admin, msgFieldsInput ) ;
	}//EOM

	public com.fundtech.datacomponent.response.UserResponse saveMessage(final Admin admin, java.lang.String sMID ) {
		return this.m_bo.saveMessage(admin, sMID ) ;
	}//EOM

	public com.fundtech.datacomponent.response.SimpleResponseDataComponent getMessageXml(final Admin admin, java.lang.String sMID, com.fundtech.core.paymentprocess.data.paymenttypes.PaymentType enumOutPaymentType, java.util.Map mapCustomizations, java.io.Serializable oFndtMsgSubsetXml, java.io.Serializable oSkelletonRootXml, java.io.Serializable oMergeInput ) {
		return this.m_bo.getMessageXml(admin, sMID, enumOutPaymentType, mapCustomizations, oFndtMsgSubsetXml, oSkelletonRootXml, oMergeInput ) ;
	}//EOM

	/** 
	 */
	public com.fundtech.datacomponent.response.Feedback formatOutMessage(final Admin admin, java.lang.String sMID ) {
		return this.m_bo.formatOutMessage(admin, sMID ) ;
	}//EOM

	/** 
	 * Returns Group Actions data. trace_todo: could not remove the user authorized as the action id is not a formal arg
	 */
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent performGroupAction(final Admin admin, com.fundtech.core.messagehandle.request.GroupActionRequestData groupActionRequestData ) {
		return this.m_bo.performGroupAction(admin, groupActionRequestData ) ;
	}//EOM

	public com.fundtech.datacomponent.response.SimpleResponseDataComponent manipulateMessageData(final Admin admin, java.lang.String sMID, java.lang.String[] arrObjectAttchments ) {
		return this.m_bo.manipulateMessageData(admin, sMID, arrObjectAttchments ) ;
	}//EOM

	public com.fundtech.datacomponent.response.SimpleResponseDataComponent manipulateMessageData(final Admin admin, java.lang.String sManipulationDataID ) {
		return this.m_bo.manipulateMessageData(admin, sManipulationDataID ) ;
	}//EOM

	public com.fundtech.datacomponent.response.SimpleResponseDataComponent generateMsgComponentFragment(final Admin admin, java.util.Map parametersMap ) {
		return this.m_bo.generateMsgComponentFragment(admin, parametersMap ) ;
	}//EOM

	public com.fundtech.datacomponent.response.UserResponse saveScreenset(final Admin admin, com.fundtech.datacomponent.request.MessageScreenSetSaveRequestData inputContainer ) {
		return this.m_bo.saveScreenset(admin, inputContainer ) ;
	}//EOM

	public com.fundtech.datacomponent.response.SimpleResponseDataComponent invokeClientAjaxEvent(final Admin admin, com.fundtech.datacomponent.request.MessageFieldsInputData parameterMap ) {
		return this.m_bo.invokeClientAjaxEvent(admin, parameterMap ) ;
	}//EOM

	/** 
	 * handles the association of a template to a user   
	 */
	public com.fundtech.datacomponent.response.GlobalResponseDataComponentText handleTemplateAssociation(final Admin admin, com.fundtech.datacomponent.request.MessageFieldsInputData msgFieldsInput ) {
		return this.m_bo.handleTemplateAssociation(admin, msgFieldsInput ) ;
	}//EOM

}//EOC