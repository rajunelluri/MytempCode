package backend.core.module.messagehandle.businessobjects;

import com.fundtech.core.security.Admin;

/**
 * internal interface for BOMessageHandle.
 */
public interface BOMessageHandleInterface{

	
	
	/** 
	 * Invokes the matching mapping rule, (rule type ID 156; the rule UID itself was defined in the passed MatchingCheck profile).
	 */
	public void invokeMatchingMappingRule(final Admin admin, com.fundtech.cache.entities.MatchingCheck matchingCheck ) ;

}//EOI  