package backend.core.module;

/*
 * Title:       MessageConstantsInterface
 * Description: Interface for holding all keys involved in message loading/processing 
 * Company:     Fundtech Israel
 * Author:      Asaf Levy
 * Date:        21/11/2007
 */
public interface MessageConstantsInterface
{
	// Caps constants
	static final String OPERATING = "Operating";
	static final String HIGH = "High";
	static final String MAX = "Max";
	static final String CAP = "Cap";

  // Database column names.
	static final String COLUMN_NEWJOURNAL_MODULEID = "MODULEID";
	static final String COLUMN_NEWJOURNAL_UPDATE_DATE = "UPDATE_DATE";
	static final String COLUMN_NEWJOURNAL_DESCRIPTION = "DESCRIPTION";
	static final String COLUMN_TIME_STAMP = "TIME_STAMP";
	static final String COLUMN_CONTENTS = "CONTENTS";
	static final String COLUMN_DIRECTION = "DIRECTION";
	static final String COLUMN_DESCRIPTION = "DESCRIPTION";
	static final String COLUMN_ZONE_CODE = "ZONE_CODE";
	static final String COLUMN_FLOW_ID = "FLOW_ID";
	static final String COLUMN_MID = "MID";
	static final String COLUMN_RULEID = "RULEID";
    
  // MIF.WHOSE_ERROR optional values.
	static final String WHOSE_ERROR_CUSTOMER = "C";
	static final String WHOSE_ERROR_OUR = "O";
	static final String WHOSE_ERROR_MANUAL_CREATE = "M";

  // NEWJOURNAL.MODULEID optional values.
	static final String MODULEID_9998_COMPLIANCE = "9998";
  //
  // Related table field names.
	static final String MSGERR_ASSOCAITED_FIELDNAME = "VIRTUAL.ERRORS";
	static final String AUDIT_TRAIL_ASSOCAITED_FIELDNAME = "VIRTUAL.AUDITTRAIL";
	static final String LINKS_ASSOCAITED_FIELDNAME = "VIRTUAL.LINKS";
	static final String RULE_LOG_ASSOCAITED_FIELDNAME = "VIRTUAL.MSGRULELOG";
  //
  // VIRTUAL field names.
	static final String FIELD_VIRTUAL_MESSAGE_READONLY = "VIRTUAL.MESSAGE_READONLY";
	static final String FIELD_VIRTUAL_IN_MSG_FILE = "VIRTUAL.IN_MSG_FILE";
	static final String FIELD_VIRTUAL_IN_MSG = "VIRTUAL.IN_MSG";
	static final String FIELD_VIRTUAL_OUT_MSG_FILE = "VIRTUAL.OUT_MSG_FILE";
	static final String FIELD_VIRTUAL_OUT_MSG = "VIRTUAL.OUT_MSG";
	static final String FIELD_VIRTUAL_MSGIMAGE = "VIRTUAL.MSGIMAGE";
	static final String FIELD_VIRTUAL_LINKS = "VIRTUAL.LINKS";
	static final String FIELD_VIRTUAL_MEMOPOSTTRANSACTION = "VIRTUAL.MEMOPOSTTRANSACTION";
	static final String FIELD_VIRTUAL_AUDITTRAIL = "VIRTUAL.AUDITTRAIL";
	static final String FIELD_VIRTUAL_COMPLIANCE = "VIRTUAL.COMPLIANCE";
	static final String FIELD_VIRTUAL_ERRORS = "VIRTUAL.ERRORS";
	static final String FIELD_VIRTUAL_MSG_SPECIAL_INST = "VIRTUAL.MSG_SPECIAL_INST";
	static final String FIELD_VIRTUAL_HISTORIC_ERR = "VIRTUAL.HISTORIC_ERR";
	static final String FIELD_VIRTUAL_NOTES = "VIRTUAL.NOTES";
	static final String FIELD_VIRTUAL_ADVISES = "VIRTUAL.ADVISES";
	static final String FIELD_VIRTUAL_FX_RATE = "VIRTUAL.FX_RATE";
	static final String FIELD_VIRTUAL_INV_REF = "VIRTUAL.INV_REF";
	static final String FIELD_VIRTUAL_FUNCTION_ID = "VIRTUAL.FUNCTION_ID";
	static final String FIELD_VIRTUAL_HV_LINKS = "VIRTUAL.HV_LINKS";
	static final String FIELD_VIRTUAL_LV_LINKS = "VIRTUAL.LV_LINKS";
	static final String FIELD_VIRTUAL_DUPEX = "VIRTUAL.DUPEX";
	static final String FIELD_VIRTUAL_RULE_LOG = "VIRTUAL.RULE_LOG";
	static final String FIELD_VIRTUAL_ACKNOWLEDGEMENTS = "VIRTUAL.ACKNOWLEDGEMENTS";
  
  // Additional fields.
	static final String FIELD_VIRTUAL_TABLES_PAGING_DATA = "VIRTUAL.TABLES_PAGING_DATA";

  // Compliance flags.
	static final String HIT_TYPE_COMPLIANCE = "C";
	static final String HIT_TYPE_FRAUD = "F";
	static final String HIT_TYPE_BOTH = "B";
  
	static final String CREDIT = "CR";
	static final String DEBIT = "DR";

  // Message statuses.
  String MESSAGE_STATUS_AUTHEX     = "AUTHEX";
  String MESSAGE_STATUS_AF_WAIT_PAYMENT = "AF_WAIT_PAYMENT";
  String MESSAGE_STATUS_CREATE     = "CREATE";
  String MESSAGE_STATUS_CANCELED       = "CANCELED";
  String MESSAGE_STATUS_CONFIRMED       = "CONFIRMED";
  String MESSAGE_STATUS_CDBWAIT       = "CDBWAIT";
  String MESSAGE_STATUS_CDBSTOP       = "CDBSTOP";
  String MESSAGE_STATUS_COMPLETE       = "COMPLETE";
  String MESSAGE_STATUS_DUPEX          = "DUPEX";
  String MESSAGE_STATUS_NSF            = "NSF";
  String MESSAGE_STATUS_CRNSF = CREDIT + MESSAGE_STATUS_NSF;
  String MESSAGE_STATUS_DRNSF = DEBIT + MESSAGE_STATUS_NSF;
  String MESSAGE_STATUS_REPAIR         = "REPAIR";
  String MESSAGE_STATUS_WAITSUBBATCH   = "WAITSUBBATCH";
  String MESSAGE_STATUS_WAITSCHEDSUBBATCH = "WAITSCHEDSUBBATCH";
  String MESSAGE_STATUS_WAIT_INDIVIDUAL = "WAIT_INDIVIDUAL";
  String MESSAGE_STATUS_RECEIVED       = "(RECEIVED)";
  String MESSAGE_STATUS_SCHEDULE       = "SCHEDULE";
  String MESSAGE_STATUS_PAYSET         = "PAYSET";
  String MESSAGE_STATUS_REJECTED       = "REJECTED";
  String MESSAGE_STATUS_REVERSED       = "REVERSED";
  String MESSAGE_STATUS_TIMEOUT       = "TIMEOUT";
  String MESSAGE_STATUS_WAITBULK       = "WAITBULK";
  String MESSAGE_STATUS_WAITHUB       = "WAIT_HUB";
  String MESSAGE_STATUS_PNDCHRG        = "PNDCHRG";
  String MESSAGE_STATUS_APPROVE_CANCEL    = "APPROVE_CANCEL";
  String APPROVE_CHANGE_HOLDTIME		= "APPROVE_CHANGE_HOLDTIME";
  String MESSAGE_STATUS_APPROVE_OVERRIDE    = "APPROVE_OVERRIDE";
  String MESSAGE_STATUS_POSTREST     = "POSTREST";
  String MESSAGE_STATUS_POST_EXCEPTION = "POSTEX";
  String MESSAGE_STATUS_POST_INTERIM = "INTERIM";
  String MESSAGE_STATUS_CDTRANSFERLIMIT = "CDTRANSFERLIMIT";
  String MESSAGE_STATUS_SERVICE_WAIT = "SERVICE_WAIT";
  String MESSAGE_STATUS_SERVICE_WAIT_ACK = "SERVICE_WAIT_ACK";
  String MESSAGE_STATUS_WAIT_OPI_ACK = "WAIT_OPI_ACK";
  String MESSAGE_STATUS_SERVICE_REJECTED = "SERVICE_REJECTED";
  String MESSAGE_STATUS_SERVICE_RELEASE = "SERVICE_RELEASE";
  String MESSAGE_STATUS_SERVICE_COMPLETE = "SERVICE_COMPLETE";
  String MESSAGE_STATUS_INCOMING71G = "INCOMING71G";
  String MESSAGE_STATUS_TIME_HOLD = "TIMEHOLD";
  String MESSAGE_STATUS_COMPEX = "COMPEX";
  String MESSAGE_STATUS_WAITRATE = "WAITRATE";
  String MESSAGE_STATUS_WAIT_ACK = "WAIT_ACK";
  String MESSAGE_STATUS_WAIT_CONFIRMATION = "WAIT_CONFIRMATION";
  String MESSAGE_STATUS_STOP = "STOP";
  String MESSAGE_STATUS_WAIT_RELEASE = "WAIT_RELEASE";
  String MESSAGE_STATUS_WAIT_RTR = "WAIT_RTR";
  String MESSAGE_STATUS_REJECTEDDUPEX = "REJECTEDDUPEX";
  String MESSAGE_STATUS_PENDING_FILE_APPROVAL = "PENDING_FILE_APPROVAL";
  String MESSAGE_STATUS_PEND_APPROV = "PEND_APPROV";
  String MESSAGE_STATUS_NAK = "NAK";
  String MESSAGE_STATUS_ROFI = "ROFI";
  String MESSAGE_STATUS_RETURNED = "RETURNED";
  String MESSAGE_STATUS_WAITRETURN = "WAITRETURN";
  String MESSAGE_STATUS_WAITREJECT = "WAITREJECT";
  String MESSAGE_STATUS_WAIT_LIMIT = "WAIT_LIMIT";
  String MESSAGE_STATUS_UNMATCHED_LEDGER = "UNMATCHED_LEDGER";
  String MESSAGE_STATUS_UNSOLICITED_DEBIT = "UNSOLICITED_DEBIT";
  String MESSAGE_STATUS_UNSOLICITED_CREDIT = "UNSOLICITED_CREDIT";
  String MESSAGE_STATUS_WAIT_MATCH = "WAIT_MATCH";
  String MESSAGE_STATUS_BANDS = "BANDS";
  String MESSAGE_STATUS_WAIT_HOLD = "WAIT_HOLD";
  String MESSAGE_STATUS_MP_WAIT = "MP_WAIT";
  String MESSAGE_STATUS_APPROVE_MAN_PSTNG_RSPNS="APPROVE_MAN_PSTNG_RSPNS";
  String MESSAGE_STATUS_WAIT_SEND = "WAIT_SEND";
  String MESSAGE_STATUS_WAIT_CHILD = "WAIT_CHILD";
  String MESSAGE_STATUS_MP_ERROR = "MP_ERROR";

	static final String MESSAGE_STATUS_UNMATCHED_OPIOSN = "UNMATCHED_OPIOSN";
	static final String MESSAGE_STATUS_LIQ_REJECTED = "LIQ_REJECTED";
	static final String MESSAGE_STATUS_LIQ_CANCELED = "LIQ_CANCELED";
	static final String MESSAGE_STATUS_APPROVE_LIQ_REJECT = "APPROVE_LIQ_REJECT";
	static final String MESSAGE_STATUS_SERVICE = "SERVICE";
  
  String MESSAGE_STATUS_BIWAITQ = "BIWAITQ";
  String MESSAGE_STATUS_COMEX = "COMEX";
  String MESSAGE_STATUS_WAITOFAC = "WAITOFAC";
  
  String MESSAGE_STATUS_RECON_FAIL = "RECON_FAIL";
  String MESSAGE_STATUS_RECON_PROCESS = "RECON_PROCESS";
  String MESSAGE_STATUS_STATEMENT_RECEIVED = "STATEMENT_RECEIVED";
  String MESSAGE_STATUS_STATEMENT_COMPLETE = "STATEMENT_COMPLETE";
  String MESSAGE_STATUS_RESOLUTION_FAIL = "RESOLUTION_FAIL";
  String MESSAGE_STATUS_VERIFY = "VERIFY";
  
  // NAGE PPC phase 1 statuses (Regarding PegaWorks processing)
	static final String MESSAGE_STATUS_WAIT_HOST_PROC = "WAIT_HOST_PROC"; 	// Waiting for Host Processing ("Host" meaning NAGE PegaWorks)
	static final String MESSAGE_STATUS_WAIT_HOST_REF = "WAIT_HOST_REF";		// Waiting for Host Reference - RFK ("Host" meaning NAGE PegaWorks)
	static final String MESSAGE_STATUS_HOST_EXCEPTION = "HOST_EXCEPTION";	// Host Processing Exception ("Host" meaning NAGE PegaWorks)
  
  // Message directions.
	static final String DIRECTION_INCOMING = "IN";
	static final String DIRECTION_I = "I";
	static final String DIRECTION_OUTGOING = "OUT";
	static final String DIRECTION_O = "O";
  
  // PRULE_SYS_ACTIONS table.
	static final String SYS_RULE_ACTION_CONT_FLOW = "CONT_FLOW";
	static final String SYS_RULE_ACTION_CONT_FLOW_NO_SAVE = "CONT_FLOW_NO_SAVE";
	static final String SYS_RULE_ACTION_NO_CHANGE = "NO_CHANGE";
	static final String SYS_RULE_ACTION_RETURN_TO_BASE_STATUS = "RETURN_TO_BASE_STATUS";
	static final String SYS_RULE_ACTION_BYPASS = "BYPASS";
	static final String SYS_RULE_ACTION_CONT_FLOW_UNTIL_HANDOFF = "CONT_FLOW_UNTIL_HANDOFF";
  
  // Rule type IDs.
  String RULE_TYPE_ID_DEPARTMENT = "1";
  String RULE_TYPE_ID_USER_DEFINED_QUEUE = "2";
  String RULE_TYPE_ID_GET_AVAILABLE_MOPS = "3";
  String RULE_TYPE_ID_FEE_FORMULA_SELECTION ="6";
  String RULE_TYPE_ID_PRODUCT = "12";
  String RULE_TYPE_ID_WORKFLOW_MANAGEMENT = "15";
  String RULE_TYPE_ID_VALIDATION = "20" ;
  String RULE_TYPE_ID_COMPLIANCE_VALIDATION = "21" ;
  String RULE_TYPE_ID_SPECIAL_INSTRUCTION = "23";  // 24
  String RULE_TYPE_ID_FEE_TYPE_SELECTION ="25";
  String RULE_TYPE_ID_MSG_FILTER = "26";
  String RULE_TYPE_ID_BUSINESS_AREA = "30";
  String RULE_TYPE_ID_DR_TRANSACTION_CODE = "31";
  String RULE_TYPE_ID_CR_TRANSACTION_CODE = "32";
  String RULE_TYPE_ID_PRIORITIZATION = "44" ;
  String RULE_TYPE_ID_FEE_BYPASS ="50";
  String RULE_TYPE_ID_FEE_ACCOUNT_SELECTION ="57";
  String RULE_TYPE_ID_BULK_VALIDATION = "97";
  String RULE_TYPE_ID_CALENDAR_SELECTION = "100";
  String RULE_TYPE_ID_PROCESSING_CUTOFF_SELECTION = "101";
  String RULE_TYPE_ID_TREASURY_CUTOFF_SELECTION = "102";
  String RULE_TYPE_ID_CLEARING_CUTOFF_SELECTION = "103";
  String RULE_TYPE_ID_PROCESSING_MISSED_CUTOFF = "104";
  String RULE_TYPE_ID_TREASURY_MISSED_CUTOFF = "105";
  String RULE_TYPE_ID_CLEARING_MISSED_CUTOFF = "106";
  String RULE_TYPE_ID_MESSAGE_SCREEN_SET_SELECTION = "107";
  String RULE_TYPE_ID_MESSAGE_FIELDS_SETS_SELECTION = "108";
  String RULE_TYPE_ID_MESSAGE_BUTTONS_SETS_SELECTION = "109";
  String RULE_TYPE_ID_BASE_RATE_USAGE_SELECTION = "110";
  String RULE_TYPE_ID_CREDIT_RATE_USAGE_SELECTION = "111";
  String RULE_TYPE_ID_DEBIT_RATE_USAGE_SELECTION = "112";
  String RULE_TYPE_ID_VIRTUAL_QUEUE_SELETION = "113";
  String RULE_TYPE_ID_VALIDATE_MOP = "115";
  String RULE_TYPE_ID_MSG_TYPE_SELECTION = "117";
  String RULE_TYPE_ID_OUTGOING_FORMAT = "121";
  String RULE_TYPE_ID_SKIP_DEBIT_AUTHORIZATION = "122";
  String RULE_TYPE_ID_ACCOUNT_LOOKUP = "123";
  String RULE_TYPE_ID_FIELD_VERIFICATION_PROFILE_SELECTION = "124"; 
  String RULE_TYPE_ID_GUI_WORKFLOW_STATUS_SELECTION = "125";  
  String RULE_TYPE_ID_GET_SOURCE_MOP = "133";
  String RULE_TYPE_ID_BULK_UNIQUE_GROUP_ID = "139";
  String RULE_TYPE_ID_UNIQUE_GROUPING_RULE_SELECTION = "140";
  String RULE_TYPE_ID_INCOMING_FILE_FILTER = "141";
  String RULE_TYPE_ID_OUTGOING_FILE_FILTER = "142";
  String RULE_TYPE_ID_SUB_BATCH_FILTER = "143";
  String RULE_TYPE_ID_OUT_BULK_GROUPING_ID = "144";
  String RULE_TYPE_ID_REPAIR_AND_ENRICHMENT_SELECTION = "145";
  String RULE_TYPE_ID_REPAIR_AND_ENRICHMENT_MANIPULATION = "146";
  String RULE_TYPE_ID_FILE_PRIORITY = "147";
  String RULE_TYPE_ID_PAYMENT_CLASSIFICATION = "148";
  String RULE_TYPE_ID_TRANSACTION_GENERATION_MAPPING = "149";
  String RULE_TYPE_ID_GENERATE_TRANSACTION_SELECTION = "150";
  String RULE_TYPE_ID_REQUEST_FOR_CHARGES_VALIDATION = "151";
  String RULE_TYPE_ID_MATCHING_CHECK_PROFILE_SELECTION = "152";
  String RULE_TYPE_ID_MATCHING_INDEX = "153";
  String RULE_TYPE_ID_AUTOMATIC_MATCHING_ALGORITHM = "154";
  String RULE_TYPE_ID_MANUAL_MATCHING_ALGORITHM = "155";
  String RULE_TYPE_ID_MATCHING_MAPPING = "156";
  String RULE_TYPE_ID_CANCELLATION_REQUEST_VALIDATION = "157";
  String RULE_TYPE_ID_BUSINESS_FLOW_SELECTION = "158";
  String RULE_TYPE_ID_DUAL_CONTROL = "159";
  String RULE_TYPE_ID_MAPPING_OUT_SELECTION = "161";
  String RULE_TYPE_ID_DEBIT_HOLD_UNTIL_TIME = "162";
  String RULE_TYPE_ID_CREDIT_HOLD_UNTIL_TIME = "163";
  String RULE_TYPE_ID_OFFICE_HOLD_UNTIL_TIME = "164";
  String RULE_TYPE_ID_PAYMENT_TRANSFORMATION = "166";
  String RULE_TYPE_ID_CREDIT_PARTY_CHAIN_ENRICHMENT = "168";
  String RULE_TYPE_ID_PAYMENT_TRANSACTION_GENERATION_MAPPING_SELECTION = "169";
  String RULE_TYPE_ID_MESSAGE_FORMAT_VALIDATION = "167";
  String RULE_TYPE_ID_CREDIT_ACCOUNT_ENRICHMENT = "170";
  String RULE_TYPE_ID_DEBIT_ACCOUNT_ENRICHMENT = "171";
  String RULE_TYPE_ID_ADVISING_TYPE_SELECTION= "172";
  String RULE_TYPE_ID_STP_RULES_SELECTION = "173";
  String RULE_TYPE_ID_PAYMENT_TYPE_SELECTION = "174";
  String RULE_TYPE_ID_STP_VALIDATION = "175";       // MESSAGE_STP_FIELD.
  String RULE_TYPE_ID_STP_FIELD_VALIDATION = "176"; // MESSAGE_STP_FIELD_RULE. 
  String RULE_TYPE_ID_STP_FIELD_MAPPING = "177";    // MESSAGE_STP_FIELD_RULE.
  String RULE_TYPE_ID_STP_FIELD_MAPPING_SELECTION = "178"; // MESSAGE_STP_FIELD_RULE.
  String RULE_TYPE_ID_PAYMENT_TYPE_MAPPING = "179";
  String RULE_TYPE_ID_STP_MAPPING = "180";           // MESSAGE_STP_FIELD.
  String RULE_TYPE_ID_STP_MAPPING_SELECTION = "181"; // MESSAGE_STP_FIELD.
  String RULE_TYPE_ID_OFFICE_GENERIC_SLA = "182";
  String RULE_TYPE_ID_DEBIT_SLA = "183";
  String RULE_TYPE_ID_CREDIT_SLA = "184";
  String RULE_TYPE_ID_COMPANY_LIMIT_CHECK = "185";
  String RULE_TYPE_ID_PARTY_DETAILS_ENRICHMENT = "186";
  String RULE_TYPE_ID_POSITION_FIGURE_SELECTION = "188";
  String RULE_TYPE_ID_PARTY_LIMIT_MESSAGE_FILTER = "189";
  String RULE_TYPE_ID_GROUP_OF_PARTIES  = "190";
  String RULE_TYPE_ID_PARTY_LIMIT_BYPASS_VALIDATION = "191";
  String RULE_TYPE_ID_BYPASS_PARTY_LIMIT = "192";
  String RULE_TYPE_ID_PAYMENT_CAPS_SELECTION = "193";
  String RULE_TYPE_ID_PAYMENT_OVERRIDE_BANDS = "194";
  String RULE_TYPE_ID_ADJUST_BASIC_PROPERTIES = "195";
  String RULE_TYPE_ID_INTERFACE_TYPE_SELECTION = "197";
  String RULE_TYPE_ID_MANDATE_VALIDATION = "199";
  String RULE_TYPE_ID_POSTING_TYPE_SELECTION = "200";
  String RULE_TYPE_ID_POSTING_SUSPENSE_ACCOUNT_SELECTION = "201";
  String RULE_TYPE_ID_BYPASS_STOP_FLAGS_SELECTION = "202";
  //************************************************************************************************
  //  NOTE:  Please add new rule_types with id > 220, to avoid conflicts in merge to 4.5 thanks!
  //  NOTE:  Please add new rule_types with id > 220, to avoid conflicts in merge to 4.5 thanks!
  //  NOTE:  Please add new rule_types with id > 220, to avoid conflicts in merge to 4.5 thanks!
  //  NOTE:  Please add new rule_types with id > 220, to avoid conflicts in merge to 4.5 thanks!
  //  NOTE:  Please add new rule_types with id > 220, to avoid conflicts in merge to 4.5 thanks!
  
  String RULE_TYPE_ID_LIQUIDITY_PRIORITY_SELECTION = "220";
  String RULE_TYPE_ID_DATA_MANIPULATION = "998";
  String RULE_TYPE_ID_TRANSACTION_SEARCH = "999"; 
  String RULE_TYPE_ID_HISTORY_SEARCH = "1000";
  String RULE_TYPE_ID_TEMPLATE_SEARCH = "1001";
  String RULE_TYPE_ID_BULK_SEARCH = "1002";
  
  
  
  // AF, (anticipated Funds, MT 210 in SWIFT), matching statuses. 
	static final String AF_MATCH_STATUS_NONE = "N";
	static final String AF_MATCH_STATUS_WAITING = "W";
	static final String AF_MATCH_STATUS_MATCHED = "M";
  
  // Monitor flags.
  String MONITOR_FLAG_SUCCESS = "S";
  String MONITOR_FLAG_FAILURE = "F";
  String MONITOR_FLAG_FINALIZED = "F";
  String MONITOR_FLAG_FOUND = "F";
  String MONITOR_FLAG_MATCH = "M";
  String MONITOR_FLAG_FORCE = "F";
  String MONITOR_CAP_FLAG_HIGH = "H";
  String MONITOR_CAP_FLAG_MAX = "M";
  String MONITOR_CAP_FLAG_OPERATING = "O";
  String MONITOR_FLAG_NONE = "N";
  String MONITOR_FLAG_WAITING = "W";
  String MONITOR_FLAG_IN_PROCESS = "P";
  String MONITOR_FLAG_PROCESSED = "P"; // For BI & Posting.
  String MONITOR_FLAG_TIMEOUT = "E"; //T is used for throttling
  String MONITOR_FLAG_NO_PAY = "N";    // For BI.
  String MONITOR_FLAG_DUPLICATE = "D";
  String MONITOR_FLAG_OVERRIDE = "O";
  String MONITOR_FLAG_NOT_OVERRIDE = "N";
  String MONITOR_FLAG_OVERRIDEABLE = "O";    // For stop flags.
  String MONITOR_FLAG_UN_OVERRIDEABLE = "U"; // For stop flags.
  String MONITOR_FLAG_MISSED_CUTOFF = "M";
  String MONITOR_FLAG_CUTOFF_ERROR = "E";
  String MONITOR_FLAG_ASSOCIATE_INVALID = "I";
  String MONITOR_FLAG_PENDING = "P";
  String MONITOR_FLAG_X = "X";
  String MONITOR_FLAG_GENERATE_191 = "G";
  String MONITOR_FLAG_GENERATED = "G";
  String MONITOR_FLAG_TIME_HOLD_HIT = "H";
  String MONITOR_FLAG_COMPLIANCE_BYPASSED = "B";
  String MONITOR_FLAG_BYPASS = "B";
  String MONITOR_FLAG_COMPLIANCE_NO_HIT = "N";
  String MONITOR_FLAG_COMPLIANCE_HIT = "H";
  String MONITOR_FLAG_COMPLIANCE_WAIT = "W";
  String MONITOR_FLAG_COMPLIANCE_INTERFACE_DOWN = "D";
  String MONITOR_FLAG_MANUAL_VALUE = "M";
  String MONITOR_FLAG_ACCOUNTING = "A";
  String MONITOR_FLAG_REJECTED = "R";
  String MONITOR_FLAG_LIMITATIONS = "L";
  String MONITOR_FLAG_TECHNICAL_ERRORS = "E";
  String MONITOR_FLAG_REVERSE = "R";
  String MONITOR_FLAG_REQUIRED = "R";
  String MONITOR_FLAG_WAIT_REFERENCE = "R";
  String MONITOR_FLAG_ENRICHED = "E";
  String MONITOR_FLAG_THROTLING = "T";
  String MONITOR_FLAG_HOLD = "H";
  String MONITOR_FLAG_SKIPPED = "S";
  String MONITOR_FLAG_NOT_SENT = "N";
  String MONITOR_FLAG_FUTURE_VALUE_DATE = "V";
  String MONITOR_FLAG_COMPLETED = "C";
  String MONITOR_FLAG_NSF = "N";
  String MONITOR_FLAG_NON_NSF_REJECT = "O";
  String MONITOR_FLAG_COVER = "C";
  String MONITOR_FLAG_SENT = "S";
  String MONITOR_FLAG_YES = "Y";
  String MONITOR_FLAG_ASSOCIATE = "A";
  String MONITOR_FLAG_TRUE = "T";
  String MONITOR_FLAG_DEFERRED = "D";
  String MONITOR_FLAG_NAK = "N";
  String MONITOR_FLAG_NO_MATCH = "N";
  String MONITOR_FLAG_ACCUMULATED_INCOMING = "I"; // Used as Party limit accumulation indication
  String MONITOR_FLAG_ACCUMULATED_OUTGOING = "O"; // Used as Party limit accumulation indication
  String MONITOR_FLAG_ACCUMULATED_INCOMING_OUTGOING = "B"; // Used as Party limit accumulation indication
  String MONITOR_FLAG_HANDLED = "H"; // Used for reconciliation repeat
  String MONITOR_FLAG_LAST_RETRY_ATTEMPT = "L"; //Used to indicate last retry attempt in timeout flow
  String MONITOR_FLAG_PENDING_CANCEL = "C"; //Used to indicate incoming cancelation before original posting response was received
  String MONITOR_FLAG_BACK_FROM_PENDING_CANCELATION = "B"; // set the monitor to b while we get cancellation(campbefore posting response 
  String MONITOR_FLAG_POSITIVE_POSTING = "P"; 
  String MONITOR_FLAG_NEGATIVE_POSTING = "N"; 
  String MONITOR_FLAG_TIMEOUT_FLOW = "T";
  String MONITOR_BULK_INDIVIDUAL_STATE_PRE_PROCESSING = "P"; // Used for bulk individual processing
  String MONITOR_BULK_INDIVIDUAL_STATE_COMPLETION = "C"; // Used for bulk individual processing
  
  //g3 split payment 
  String MONITOR_FLAG_PARENT_SPLIT = "P"; //for parent which is going to split into children payments
  String MONITOR_FLAG_PARENT_NON_SPLIT = "X"; //for non split parent payments
  String MONITOR_FLAG_CHILD = "C"; //for split children payments
  String MONITOR_FLAG_SPLIT_RF = "R"; //for non split parent payments
  
  // Message relation types.
	static final String RELATION_TYPE_INCOMING_MTn91 = "Incoming MTn91";
	static final String RELATION_TYPE_ORIGINAL_OUTGOING_PAYMENT = "Original Outgoing Payment";
	static final String RELATION_TYPE_OUT_GENERATED_PAYMENT = "Out Generated Payment";
	static final String RELATION_TYPE_ORIGINAL_PAYMENT = "Original Payment";
	static final String RELATION_TYPE_DUPLICATED = "Duplicated";
	static final String RELATION_TYPE_DUPLICATED_TEMPLATE = "Duplicated Template";
	static final String RELATION_TYPE_PI = "PI";
	static final String RELATION_TYPE_SN = "SN";
	static final String RELATION_TYPE_INCOMING_CANCELLATION_REQUEST = "Incoming Cancellation Request";
	static final String RELATION_TYPE_OUTGOING_CANCELLATION_REQUEST = "Outgoing Cancellation Request";
	static final String RELATION_TYPE_INCOMING_CANCELLATION_REQUEST_REFUSED = "Incoming Cancellation Request Refused";
	static final String RELATION_TYPE_OUTGOING_CANCELLATION_REQUEST_REFUSED = "Outgoing Cancellation Request Refused";
	static final String RELATION_TYPE_RELATED_MESSAGE = "Related Message";
	static final String RELATION_TYPE_ANSWER = "Answer";
	static final String RELATION_TYPE_QUERY = "Query";
	static final String RELATION_TYPE_FREE_TEXT = "Free Text";
	static final String RELATION_TYPE_OUT_REQUEST_FOR_CHARGES = "Out request for charges";
	static final String RELATION_TYPE_IN_PAYMENT = "In Payment";
	static final String RELATION_TYPE_COVER = "Cover";
	static final String RELATION_TYPE_DIRECT = "Direct";
	static final String RELATION_TYPE_PAYMENT = "Payment";
	static final String RELATION_TYPE_INTEROFFICE_PAYMENT = "Interoffice Payment";
	static final String RELATION_TYPE_CREDIT_ADVICE = "Credit Advice";
	static final String RELATION_TYPE_DEBIT_ADVICE = "Debit Advice";
	static final String RELATION_TYPE_FEE_CREDIT_ADVICE = "Fee Credit Advice";
	static final String RELATION_TYPE_FEE_DEBIT_ADVICE = "Fee Debit Advice";
	static final String RELATION_TYPE_ANTICIPATED_FUNDS = "AF";
	static final String RELATION_TYPE_LEDGER_CONFIRMATION = "LC";
	static final String RELATION_TYPE_ORIGINAL_TEMPLATE = "Original Template";
	static final String RELATION_TYPE_FUTURE_CHANGES = "Future Changes";
	static final String RELATION_TYPE_INCOMING_CAMT_052 = "Incoming CAMT_052";
	static final String RELATION_TYPE_OUTGOING_PACS_009 = "Outgoing Pacs_009";
	static final String RELATION_TYPE_INCOMING_REJECT_RETURN = "Incoming Reject Return";
	static final String RELATION_TYPE_OUTGOING_REJECT_RETURN = "Outgoing Reject Return";
	static final String RELATION_TYPE_OUTGOING_REJECT_RETURN_CANCELED = "Outgoing Reject Return Canceled";
    static final String RELATION_TYPE_RECALL_MATCHING_INDEX = "Recall Matching Index";
	static final String RELATION_TYPE_MAMBO_HUB = "MAM_H";
	static final String RELATION_TYPE_MAMBO_CHANNEL = "MAM_CH";
	static final String RELATION_TYPE_SC = "SC";
	static final String RELATION_TYPE_PAY = "PAY";
	static final String RELATION_TYPE_Paymeny = "Payment";
	static final String RELATION_TYPE_AF = "AF";
	static final String RELATION_TYPE_REVERSAL = "Reversal";
	static final String RELATION_TYPE_RETURN_FUNDS = "Return Funds";
	static final String RELATION_TYPE_CHILD_PAYMENT = "Child Message";
	static final String RELATION_TYPE_PARENT_PAYMENT = "Parent Message";
  
  // Message classes.
	static final String MSG_CLASS_OPI = "OPI";
	static final String MSG_CLASS_OSN = "OSN";
	static final String MSG_CLASS_PI = "PI";
	static final String MSG_CLASS_SN = "SN";
	static final String MSG_CLASS_PAY = "PAY";
	static final String MSG_CLASS_NAC = "NAC";
	static final String MSG_CLASS_AF = "AF";
	static final String MSG_CLASS_IRT = "IRT";
	static final String MSG_CLASS_ORT = "ORT";
	static final String MSG_CLASS_IRJ = "IRJ";
	static final String MSG_CLASS_ORJ = "ORJ";
	static final String MSG_CLASS_SC = "SC";
	static final String MSG_CLASS_LC = "LC";
	static final String MSG_CLASS_DD = "DD";
  String MSG_CLASS_IRC = "IRC";
  String MSG_CLASS_ORR = "ORR";
  String MSG_CLASS_ORC = "ORC";
  
  // Message buttons.
	static final String MESSAGE_BUTTON_PRINT = "Print";
	static final String MESSAGE_BUTTON_CANCEL = "Cancel";
	static final String MESSAGE_BUTTON_APPROVE = "Approve";
	static final String MESSAGE_BUTTON_REFUSE = "Refuse";
	static final String MESSAGE_BUTTON_CONFIRM = "Confirm";
	static final String MESSAGE_BUTTON_SAVE = "Save";
	static final String MESSAGE_BUTTON_MATCH_SN_PI = "MatchSN_PI";
	static final String MESSAGE_BUTTON_MATCH_SC_ANY = "MatchSC_";
	static final String MESSAGE_BUTTON_MATCH_SN_ANY = "MatchSN_";
	static final String MESSAGE_BUTTON_MATCH_LC_ANY = "MatchLC_";
	static final String MESSAGE_BUTTON_MATCH_AF_ANY = "MatchAF_";
	static final String MESSAGE_BUTTON_MATCH_DIRECT_ANY = "MatchDIRECT_";
	static final String MESSAGE_BUTTON_MATCH_COVER_ANY = "MatchCOVER_";
	static final String MESSAGE_BUTTON_SAVE_TEMPLATE = "SaveTemplate";
	static final String MESSAGE_BUTTON_ASSOCIATE_TEMPLATE = "AssociateTemplate";
	static final String MESSAGE_BUTTON_CANCEL_TEMPLATE = "CancelTemplate";
	static final String MESSAGE_BUTTON_FORCE_ACK_CONFIRMATION = "Force ACK/Confirmation";
	static final String MESSAGE_BUTTON_RELEASE_AS_POSITIVE_POSTING = "ReleaseAsPositivePosting";
	static final String MESSAGE_BUTTON_RELEASE_AS_NEGATIVE_POSTING = "ReleaseAsNegativePosting";
	static final String MESSAGE_BUTTON_APPROVE_AS_POSITIVE_POSTING = "ApproveManualPositiveResponse"; 
	static final String MESSAGE_BUTTON_APPROVE_AS_NEGATIVE_POSTING = "ApproveManualNegativeResponse";
	static final String MESSAGE_BUTTON_VALIDATE = "Validate";
	static final String MESSAGE_BUTTON_SUBMIT = "Submit";
	static final String MESSAGE_BUTTON_CREATE_FROM_TEMPLATE = "CreatePaymentFromTemplate";
	static final String MESSAGE_BUTTON_RETRACT = "Retract";
	static final String MESSAGE_BUTTON_SENT_TO_REPAIR = "Send to Repair";
	static final String MESSAGE_BUTTON_REFUSE_CANCEL = "RefuseCancel";
	static final String MESSAGE_BUTTON_APPROVE_CHANGE_TIME_HOLD = "ApproveChangeTimedHold";
	static final String MESSAGE_BUTTON_REFUSE_CHANGE_TIME_HOLD = "RefuseChangeTimedHold";
	static final String FORCE_PREFIX = "Force";
	static final String RETRY_PREFIX = "Retry";
	static final String MESSAGE_BUTTON_FORCE_CRNSF = FORCE_PREFIX
			+ MESSAGE_STATUS_CRNSF;
	static final String MESSAGE_BUTTON_RETRY_CRNSF = RETRY_PREFIX
			+ MESSAGE_STATUS_CRNSF;
  
	static final String MESSAGE_BUTTON_FORCE_DRNSF = FORCE_PREFIX
			+ MESSAGE_STATUS_DRNSF;
	static final String MESSAGE_BUTTON_RETRY_DRNSF = RETRY_PREFIX
			+ MESSAGE_STATUS_DRNSF;

  // MOP values.
	static final String MOP_BPAY = "BPAY";
	static final String MOP_BOOK = "BOOK";
	static final String MOP_SWIFT = "SWIFT";
	static final String MOP_INRTGS = "INRTGS";
	static final String MOP_INNEFT = "INNEFT";
	static final String MOP_CHAPS = "CHAPS";
	static final String MOP_DOWNST = "DOWNST";
	static final String MOP_G3 = "G3";
	static final String MOP_G3_BULK = "G3BULK";
  
  // Message types.
  String MESSAGE_TYPE_PAIN = "PAIN";
  String MESSAGE_TYPE_SWIFT = "SWIFT";
  String MESSAGE_TYPE_PAIN_001 = "Pain_001";
  String MESSAGE_TYPE_PAIN_002 = "Pain_002";  
  String MESSAGE_TYPE_PAIN_008 = "Pain_008";  
  String MESSAGE_TYPE_PACS_002 = "Pacs_002";
  String MESSAGE_TYPE_PACS_003 = "Pacs_003";
  String MESSAGE_TYPE_PACS_004 = "Pacs_004";
  String MESSAGE_TYPE_PACS_008 = "Pacs_008";
  String MESSAGE_TYPE_PACS_009 = "Pacs_009";
  String MESSAGE_TYPE_PACS_007 = "Pacs_007";
  String MESSAGE_TYPE_SWIFT_103 = "SWIFT_103";
  String MESSAGE_TYPE_SWIFT_200 = "SWIFT_200";
  String MESSAGE_TYPE_SWIFT_202 = "SWIFT_202";
  String MESSAGE_TYPE_SWIFT_202COV = "SWIFT_202COV";
  String MESSAGE_TYPE_SWIFT_210 = "SWIFT_210";
  String MESSAGE_SUB_TYPE_RVR = "RVR"; //SWIFT_210
  String MESSAGE_TYPE_910 = "910";
  String MESSAGE_TYPE_SWIFT_900 = "SWIFT_900";
  String MESSAGE_TYPE_SWIFT_910 = "SWIFT_910";
  String MESSAGE_TYPE_SWIFT_940 = "SWIFT_940";
  String MESSAGE_TYPE_SWIFT_941 = "SWIFT_941";
  String MESSAGE_TYPE_SWIFT_942 = "SWIFT_942";
  String MESSAGE_TYPE_SWIFT_950 = "SWIFT_950";
  String MESSAGE_TYPE_SWIFT_192 = "SWIFT_192";
  String MESSAGE_TYPE_SWIFT_292 = "SWIFT_292";
  String MESSAGE_TYPE_SWIFT_196 = "SWIFT_196";
  String MESSAGE_TYPE_SWIFT_296 = "SWIFT_296";
  String MESSAGE_TYPE_CAMT_056 = "Camt_056";
  String MESSAGE_TYPE_CAMT_029 = "Camt_029";
  String MESSAGE_TYPE_CAMT_053 = "CAMT_053";
  String MESSAGE_TYPE_SWIFT_970 = "SWIFT_970";
  String MESSAGE_TYPE_SWIFT_971 = "SWIFT_971";
  String MESSAGE_TYPE_SWIFT_972 = "SWIFT_972";
  
	static final String MESSAGE_TYPE_SWIFT_298_011 = "SWIFT_298_011";
	static final String MESSAGE_TYPE_SWIFT_298_012 = "SWIFT_298_012";
	static final String MESSAGE_TYPE_SWIFT_298_013 = "SWIFT_298_013";
	static final String MESSAGE_TYPE_SWIFT_298_014 = "SWIFT_298_014";
	static final String MESSAGE_TYPE_MAMBO_FTM401 = "MAMBO_FTM401";
	static final String MESSAGE_TYPE_MAMBO_FTM402 = "MAMBO_FTM402";
	static final String MESSAGE_TYPE_MAMBO_FTM411 = "MAMBO_FTM411";
	static final String MESSAGE_TYPE_MAMBO_FTM451 = "MAMBO_FTM451";
	static final String MESSAGE_TYPE_MAMBO_FTM452 = "MAMBO_FTM452";
	static final String MESSAGE_TYPE_MAMBO_FTM441 = "MAMBO_FTM441";

	static final String MESSAGE_TYPE_MAMBO_BPAY401 = "MAMBO_HUB401";
	static final String MESSAGE_TYPE_MAMBO_BPAY402 = "MAMBO_HUB402";
	static final String MESSAGE_TYPE_MAMBO_BPAY411 = "MAMBO_HUB411";
	static final String MESSAGE_TYPE_MAMBO_BPAY451 = "MAMBO_HUB451";
	static final String MESSAGE_TYPE_MAMBO_BPAY452 = "MAMBO_HUB452";
	static final String MESSAGE_TYPE_MAMBO_BPAY441 = "MAMBO_HUB441";

  //STMT messages (Reconciliation Process)
  static final String STMT_MESSAGE_TYPE = "STMT";
  static final String STMT_MESSAGE_SUB_TYPE_001 = "001";
  static final String STMT_MESSAGE_SUB_TYPE_002 = "002";
  
  //SNM messages (G3)
  String MESSAGE_TYPE_STMT_002_RESPONSE = "STMT_002";
  String MESSAGE_TYPE_STMT_001_REQUEST = "STMT_001";
  String MESSAGE_TYPE_SIGN_ON_REQUEST =  "ADMN_001";
  String MESSAGE_TYPE_SIGN_ON_RESPONSE = "ADMN_002";
  String MESSAGE_TYPE_SIGN_OFF_REQUEST = "ADMN_003";
  String MESSAGE_TYPE_SIGN_OFF_RESPONSE = "ADMN_004";
  String SIGN_IN_MSG_SUB_TYPE = "001";
  String SIGN_OFF_MSG_SUB_TYPE = "003";
  String SIGN_IN_RESP_MSG_SUB_TYPE = "002";
  String SIGN_OFF_RESP_MSG_SUB_TYPE = "004";
  String MESSAGE_TYPE_SYSTEM_NOTIFICATION =  "ADMI_004";
  String MESSAGE_TYPE_SYSTEM_REJECT =  "ADMI_002";
  String MESSAGE_TYPE_BANK_STATEMENT = "CAMT_053";
  //
  // N messages suffixes.
	static final String MESSAGE_TYPE_N92_SUFFIX = "92";
	static final String MESSAGE_TYPE_N95_SUFFIX = "95";
	static final String MESSAGE_TYPE_N96_SUFFIX = "96";
	static final String MESSAGE_TYPE_N99_SUFFIX = "99";
  String MESSAGE_TYPE_CAMT_56_SUFFIX = "56";
  String MESSAGE_TYPE_CAMT_29_SUFFIX = "29";  
  
  //Events
	static final String EVENT_RELEASE_FROM_SCHEDULE = "SCHEDULE";
	static final String EVENT_RELEASE_FROM_SCHEDULE_RTR = "SCHEDULE_RTR";
	static final String EVENT_RELEASE_FROM_SCHEDULE_SUB_BATCH = "SCHEDULE_SUB_BATCH";
	static final String EVENT_STANDING_ORDER = "STANDING_ORDER";
	static final String EVENT_RELEASE_WAITING_PAYMENTS = "POL";
	static final String RECONCILIATION_TYPE="RECONCILIATION_TYPE";
	static final String EVENT_WAITRATE = "WAITRATE";
	static final String EVENT_G3_GATEWAY_DOWN = "G3_GATEWAY_DOWN";
	static final String EVENT_MATCHING_RETRY = "MATCHING_RETRY";
	static final String EVENT_NSF = "NSF";
	static final String EVENT_WAITINTERFACE = "WAITINTERFACE";
	static final String EVENT_RELEASE_FROM_WAIT_RELEASE = "WAIT_RELEASE";
	static final String EVENT_RELEASE_FROM_WAIT_RELEASE_RTR = "WAIT_RELEASE_RTR";
	static final String EVENT_FILE_CANCELLATION = "FileCancelletion";
	static final String EVENT_STORED_INTERFACE_REQUEST = "STORED_INTERFACE_REQUEST";
	static final String EVENT_WAIT_ACCEPT_QUOTE = "WAIT_ACCEPT_QUOTE";
	static final String EVENT_WAIT_REQUEST_QUOTE = "WAIT_REQUEST_QUOTE";
	static final String EVENT_WAIT_TRADE_BOOK = "WAIT_TRADE_BOOK";
	static final String EVENT_Q_EXPLORER = "Q_EXPLORER";
	static final String EVENT_CLEAN_TASK = "CLEAN_TASK";
	static final String EVENT_RECHECK_PARTY_LIMIT = "PARTY_LIMIT";
	static final String RECHECK_SUFFIX = "_RECHECK";
	static final String EVENT_CRNSF_RECHECK = MESSAGE_BUTTON_FORCE_CRNSF
			+ RECHECK_SUFFIX;
	static final String EVENT_DRNSF_RECHECK = MESSAGE_BUTTON_FORCE_DRNSF
			+ RECHECK_SUFFIX;
	static final String EVENT_BANDS_RECHECK = "BANDS" + RECHECK_SUFFIX;
	static final String EVENT_HOLD_ACCOUNT_RECHECK = "HOLD_ACCOUNT"
			+ RECHECK_SUFFIX;
	static final String EVENT_AF_EXPIRATION = "AF_EXPIRATION";
	static final String EVENT_CLEAN_OLD_DYNAMIC_POL = "CLEAN_OLD_DYNAMIC_POL";
	static final String EVENT_RELEASE_FROM_WAREHOUSE = "WAREHOUSE";
    static final String EVENT_SUBMIT_BY_MIDS = "SUBMIT_BY_MIDS"; //One time event: group submit of payments based on MIDs (separated by ,)
    static final String EVENT_UPDATE_FILE_SUMMARY = "UPDATE_FILE_SUMMARY"; //One time event: group submit of payments based on MIDs (separated by ,)
    static final String EVENT_WAKE_PARENT_SPLIT = "WAKE_PARENT_SPLIT"; //for each split payment which going to final status check if all children in final status to wake parent to continue processing.
    static final String EVENT_CHECK_CANCELED_PAYMENTS = "CHECK_CANCELED_PAYMENTS"; 
    static final String EVENT_POSTING_REQ_FOR_ERROR_CORRECTION = "POST_REQ_ERR_CORRECTION";

  // Manish for Move History
	static final String EVENT_MOVE_TO_HISTORY = "MOVE_TO_HISTORY";
	static final String EVENT_FILE_TIMEOUT = "FILE_TIMEOUT";
	static final String EVENT_DL_FROM_HISTORY 					= "DL_FROM_HISTORY";
	
	// event extension:
	static final String EVENT_DL_FROM_HISTORY_PAYMENT 			= "PAYMENT";
	static final String EVENT_DL_FROM_HISTORY_IN_FILE_PAYMENT 	= "IN_FILE_PAYMENT";
	static final String EVENT_DL_FROM_HISTORY_OUT_FILE_PAYMENT 	= "OUT_FILE_PAYMENT"; 
	static final String EVENT_DL_FROM_HISTORY_LOG 				= "LOG";
	static final String EVENT_DL_FROM_HISTORY_IN_FILE 			= "IN_FILE";
	static final String EVENT_DL_FROM_HISTORY_OUT_FILE 			= "OUT_FILE";
	static final String EVENT_DL_FROM_MINF_RELATED_TABLES 	    = "MINF_RELATED";

  String EVENT_RECONCILIATION = "RECONCILIATION";

  //Routing Enrichment
	static final String D_COPY_DIRECT_MID = "D_COPY_DIRECT_MID";
  
	static final String AF_TYPE_ADJUSTMENT = "Adjustment";
	static final String AF_TYPE_EARMARK = "Earmark";
	static final String AF_TYPE_RESERVATION = "Reservation";
	static final String AF_TYPE_PREADVICE = "Pre-advice";
  
  //mass payment retrofit
  //File Types
  public static final String CVF_FILE_TYPE = "CVF";
  public static final String CCF_FILE_TYPE = "CCF";
  public static final String RETURN_RESASON_CODE_FOCR = "FOCR";
  public static final String MONITOR_FLAG_RETURNED= "R";
  public static final String RULE_TYPE_ID_SUSPENSE_ACCOUNT_ENRICHMENT = "198";
  String RULE_TYPE_ID_OUT_BULK_GROUPING_ID_SELECTION = "138";
  String RULE_TYPE_ID_TIME_TO_SEND_OF_BULK = "137";
  public static final String MESSAGE_STATUS_WAITREVERSAL = "WAITREVERSAL";
  public static final String RELATION_TYPE_ORIGINAL_FILE = "Original File";
  public static final String EVENT_CLOSE_OPEN_OUT_FILES = "CLOSE_OPEN_OUT_FILES";

  //mass payment retrofit
  
  String REJECTION_FLOW = "REJECTION";
  String BULK_INDIVIDUAL_REJECTION_FLOW = "BULK_INDIVIDUAL_REJECTION";
  String BULK_INDIVIDUAL_BOOK_REJECTION_FLOW="BULK_INDIVIDUAL_BOOK_REJECTION_FLOW";
  String ACCEPT_FLOW = "ACCEPTION";
  String MAIN_FLOW = "MAIN";
  String AFTER_POSTING_FLOW = "AFTER_POSTING";
  String REVERSAL_FLOW = "REVERSAL";
  String CANCELLATION_FLOW = "CANCELLATION";
  String BULK_SUBBACTH_FLOW = "BULK_SUBBACTH_FLOW";
  String BULK_ACCOUNTING_MSG_FLOW = "BULK_ACCOUNTING_MSG_FLOW";
  String BULK_MAIN_FLOW = "BULK_MAIN";
  String BULK_BOOK_MAIN_FLOW="BULK_BOOK_MAIN_FLOW";
  String RF_PAYMENT_FLOW="RF_PAYMENT_FLOW";
  String ERROR_CORRECTION = "ERROR_CORRECTION";
  String BULK_INDIVIDUAL_ERROR_CORRECTION = "BULK_INDIVIDUAL_ERROR_CORRECTION";
  String BULK_SUBBACTH_FLOW_ERROR_CORRECTION = "BULK_SUBBACTH_FLOW_ERROR_CORRECTION";
  String BULK_INDIVIDUAL_BK_REJECTION_FLOW = "BULK_INDIVIDUAL_BK_REJECTION_FLOW";
  
  	// Transaction categories
  public static final String TX_CATEGORY_CTI = "CTI";
  public static final String TX_CATEGORY_DDI = "DDI";
  public static final String TX_CATEGORY_REI = "REI";
  public static final String TX_CATEGORY_CTO = "CTO";
  public static final String TX_CATEGORY_DDO = "DDO";
  public static final String TX_CATEGORY_REO = "REO";
  public static final String TX_CATEGORY_CRI = "CRI";
  public static final String TX_CATEGORY_DRI = "DRI";
  public static final String TX_CATEGORY_DRO = "DRO";
  public static final String CREDIT_TRANSFER = "CT";
  public static final String DIRECT_DEBIT = "DD";
  //Payment source
  public static final String PMNT_SRC_FDR="FDR";
  public static final String PMNT_SRC_LOANS="LOANS";
 }