package backend.core.module.message.groupactions.businessobjects;



import java.io.Serializable;
import java.lang.reflect.Method;
import java.util.ArrayList;

import com.fundtech.annotations.Expose;
import com.fundtech.annotations.JMS;
import com.fundtech.annotations.Wrap;
import com.fundtech.cache.entities.EventDefinitions;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.cache.infrastructure.regions.CacheKeys.ProcessSessionsKey;
import com.fundtech.core.general.flows.FlowException;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.datacomponent.response.SimpleResponseDataComponent;
import com.fundtech.errors.ProcessErrorConstants;
import com.fundtech.scl.groupActions.GroupActionsDocument;
import com.fundtech.scl.groupActions.GroupActionsType;
import com.fundtech.util.ExceptionController;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import backend.businessobject.BOBasic;
import backend.businessobject.BOProxies;
import backend.businessobject.proxies.SkipInputValidation;
import backend.util.ServerConstants;

  
@Wrap(tx="Bean", jmsResources={@JMS(conFactoryJmsResourceKey="interfaces")}) 

public class BOGroupActions extends BOBasic {

	private final static Logger logger = LoggerFactory.getLogger(BOGroupActions.class);
	
	private static Method performGroupActionsInner  ;
	
	static { 
		try{ 
			performGroupActionsInner = BOGroupActions.class.getDeclaredMethod("performGroupActionsInner", Serializable.class) ; 
			performGroupActionsInner.setAccessible(true) ; 
		}catch(Throwable t) { 
			logger.error(t.getMessage()); 
		}//EO catch block 
	}//EO catch block 
	
	
	
	public BOGroupActions() {}//EOM    
	
	@Expose
	public final SimpleResponseDataComponent performGroupActions(final String sGroupActionsDocumentString) throws FlowException{
		Serializable xbeanRootDoc =  null ; 
		try{ 
			xbeanRootDoc = (Serializable) GroupActionsDocument.Factory.parse(sGroupActionsDocumentString).getGroupActions() ;
		}catch(Throwable t) { 			
			throw new FlowException(t) ;  
		}//EO catch block
		
		return this.performGroupActionsXBean( xbeanRootDoc);
	}//EOM
	
	/*@Expose
	public final SimpleResponseDataComponent performGroupActions(final String sGroupActionsDocumentString) throws FlowException{
		boolean bCommit = true ; 
		try{ 
			ThreadBoundCounterUTXWProxy.getStartedInstance() ;
			
			return this((Serializable) GroupActionsDocument.Factory.parse(sGroupActionsDocumentString).getGroupActions()) ;
		
		}catch(Throwable t) { 
			
			bCommit = false ; 
			
			throw new FlowException(t) ; 
		}finally{ 
			try{ 
				ThreadBoundCounterUTXWProxy.closeTx(bCommit) ;
			}catch(Throwable t) {
				//throw an exception so as to mark the transaction as rollback only in the client invoker
				throw new FlowException(t) ; 
			}//EO catch block 
		}//EO catch block 
	}//EOM
*/	
	
	@SkipInputValidation
	@Expose
	public final SimpleResponseDataComponent performGroupActionsXBean(final Serializable serGroupActionsXBean) throws FlowException{ 
		Admin.getContextAdmin().putSessionData(ProcessSessionsKey.KEY_SAME_PROCSS_SESSION_PROPAGATOR_JVM, true) ;
		
		try{ 
			final GroupActionsType groupActionsXBean = (GroupActionsType) serGroupActionsXBean ; 
			if( isExecuteEachInSeparateTransaction( groupActionsXBean.getName() ) && groupActionsXBean.getMIDArray().length > 1) {
				// Split the batch of MIDS into multiple batches of 1 MID each,
				// and run each in a separate transaction
				SimpleResponseDataComponent response = null;
				GroupActionsType groupActionXBeanSingleMID = (GroupActionsType) groupActionsXBean.copy();
				for( String mid : groupActionsXBean.getMIDArray()){
					groupActionXBeanSingleMID.setMIDArray( new String[]{ mid });
					try {
						response = (SimpleResponseDataComponent) this.executeInProtectedBoundaries(performGroupActionsInner, groupActionXBeanSingleMID);
					}
					catch( Exception e){
						ExceptionController.getInstance().handleException(e, "BOGroupActions.performGroupActionsXBean");
					}
				}
				// TODO : return Feedback composed of all executions ?
				return response;
			}
			else {
			return (SimpleResponseDataComponent) this.executeInProtectedBoundaries(performGroupActionsInner, serGroupActionsXBean) ;
			}
		}finally{ 
		}
	}//EOM 
	

	private final SimpleResponseDataComponent performGroupActionsInner(final Serializable serGroupActionsXBean) throws Throwable{ 
		
		 //for debug  
		  //if(true) throw new FlowException(new RuntimeException("this is the debug exception")) ;
		  //for debug 
		  
		final String INVALID_MID_MSG = "MID %s is invalid. Continuing to the next payment" ; 
		
		//final BackendTracer GlobalTracer = GlobalTracer ;

		final GroupActionsType groupActionsXBean = (GroupActionsType) serGroupActionsXBean ; 
				
		final SimpleResponseDataComponent response = new SimpleResponseDataComponent();
		Feedback feedback = response.getFeedback() ; 
		final StringBuilder errorMsgBuilder = new StringBuilder() ;  
		
		//iterate over the mid list and for each load the pdo, set the event id value and invoke the flow selector.  
		//check the flow selector's results and if the feedback indicates a failure, 
		//iterate over the accumulated pdo list and for each set the mode to thin remove from local cache 
		//finally set the transaction to marked as rollback.
		//if all payment flows had succeeded, batch save all 
		final ArrayList<PDO> listPdosBuffer = new ArrayList<PDO>() ;
		
		final String sEventId = groupActionsXBean.getName() ; 
		logger.info("{} --> Group Actions handler is about to invoke the flow for event {}", System.currentTimeMillis(), sEventId); 
		
		try{ 
			PDO pdo = null ;
			String sCurrentMID = null ;
				
			for(String sMID : groupActionsXBean.getMIDArray()) {  
				//save the MID for error trace message incase the processing had failed 
				sCurrentMID = sMID ; 
				 
				//load the pdo for the mid 
				pdo = PaymentDataFactory.load(sMID) ; 
				
				//if the pdo was empty (i.e) invalid raise an error and continue to the next one 
				if(pdo.isEmpty()) { 
					logger.error(INVALID_MID_MSG, sMID);
					if(errorMsgBuilder.length() > 0) errorMsgBuilder.append(", ") ;
					errorMsgBuilder.append(sMID) ; 
					continue ; 
				}//EO if the mid was invalid 
				
				//set the event id 
				pdo.set(PDOConstantFieldsInterface.D_EVENT_ID, sEventId) ;
				
				//add the pdo to the listPdosBuffer
				listPdosBuffer.add(pdo) ;
				
				  // The propagation action saves the PDO into the distributed cache in case the following 'executeFlow'
		        // will be executed on a different JVM; that way the remote JVM will get the latest PDO state.
		        CacheKeys.ProcessSessionsKey.propagate(false/*remove from local cache*/ , true/*same JVM*/);
				
				//invoke the flow selector for the mid passing a flag flag indicating that the payments should not be saved internally 
				feedback = BOProxies.m_businessFlowSelectorLogging.executeFlow(Admin.getContextAdmin(), sMID, false/*save pdo*/,ServerConstants.EMPTY_OBJECT_ARRAY) ;
				
				// For the 'CacheKeys.ProcessSessionsKey.propagate()' call in the 'finally' clause
		        // in the BOHighValueProcessWrraper class.
		        CacheKeys.ProcessSessionsKey.apply();
				
				//if the feedback indicates a failure, iterate over the accumulated pdos mark all as thin (so as to propagate them to the distributed 
				//cache only to reset the locks and be discarded) and mark the transaction for rollback
		        if(!feedback.isSuccessful()) {
		        	logger.warn("Message {} processing had failed during '{}' group actions, with Error Code {} due to {}.\nAs this is a " +
		        			"business errors, the group actions operation shall continue regardlessly", 
		        			new Object[] {
		        			sMID, 
		        			sEventId,
		        			feedback.getErrorCode(), 
		        			feedback.getErrorText()
		        	}) ;
		        }//EO if the flow had failed
	
			}//EO while there are more mids
			
			//if there was no error (no exception was thrown), save all pdos 
			PaymentDataFactory.batchSave(true /*remove from local and distribute*/, listPdosBuffer.toArray(new PDO[listPdosBuffer.size()])); 
			
			//now remove all pdos from local and propegate 
			CacheKeys.ProcessPDOKey.removeFromLocalAndPropagateToRemote(listPdosBuffer) ; 
			
			//if the errorMsgBuilder was not empty, reconfigure the feedback with its value 
			if(errorMsgBuilder.length() > 0) { 
				feedback.setFailure() ; 
				feedback.setErrorCode(ProcessErrorConstants.PDONoMinfRecord) ; 
				feedback.setErrorText("The Following MIDs are invalid:\n" + errorMsgBuilder.toString()) ; 
				response.setFeedback(feedback) ;
			}//OE if there were one or more invalid mids
			
		}
		catch (Throwable T){
			// To enable message lock unlock
			for (PDO pdo: listPdosBuffer){
				pdo.setThinMode(true);
			}
			throw T;
		}
		finally{ 

			//store the pdos list to the admin's session data against the pdo list context so that all pdos would be removed and propegated 
			Admin.getContextAdmin().putSessionData(Admin.CONTEXT_PDO_LIST, listPdosBuffer.toArray(new PDO[listPdosBuffer.size()])) ; 
		}//EO catch block 
				
		return response ;
	}//EOM 
	 
	private boolean isExecuteEachInSeparateTransaction( String eventName){
		EventDefinitions eventDef = CacheKeys.EventDefinitionsKey.getSingle( eventName);
		return eventDef == null ? false : eventDef.getBatchSize() == -1;
	}
	
	/*@SkipInputValidation
	@Expose    
	public final SimpleResponseDataComponent performGroupActionsInner(final Serializable serGroupActionsXBean) throws BusinessException{ 
		
		final String INVALID_MID_MSG = "MID %s is invalid. Continuing to the next payment" ; 
		
		final BackendTracer GlobalTracer = GlobalTracer ;

		final GroupActionsType groupActionsXBean = (GroupActionsType) serGroupActionsXBean ; 
				
		final SimpleResponseDataComponent response = new SimpleResponseDataComponent();
		Feedback feedback = response.getFeedback() ; 
		final StringBuilder errorMsgBuilder = new StringBuilder() ;  
		
		//iterate over the mid list and for each load the pdo, set the event id value and invoke the flow selector.  
		//check the flow selector's results and if the feedback indicates a failure, 
		//iterate over the accumulated pdo list and for each set the mode to thin remove from local cache 
		//finally set the transaction to marked as rollback.
		//if all payment flows had succeeded, batch save all 
		final List<PDO> listPdosBuffer = new ArrayList<PDO>() ;
		final String sEventId = groupActionsXBean.getName() ; 
		logger.info("{} --> Group Actions handler is about to invoke the flow for event {}", System.currentTimeMillis(), sEventId); 
		
		PDO pdo = null ;
		String sCurrentMID = null ;
		boolean bCommit = true ;
		
		try{ 
			
			ThreadBoundCounterUTXWProxy.getStartedInstance() ; 
			
			for(String sMID : groupActionsXBean.getMIDArray()) {  
				//save the MID for error trace message incase the processing had failed 
				sCurrentMID = sMID ; 
				
				//load the pdo for the mid 
				pdo = PaymentDataFactory.load(sMID) ; 
				
				//if the pdo was empty (i.e) invalid raise an error and continue to the next one 
				if(pdo.isEmpty()) { 
					logger.error(INVALID_MID_MSG, sMID);
					if(errorMsgBuilder.length() > 0) errorMsgBuilder.append(", ") ;
					errorMsgBuilder.append(sMID) ; 
					continue ; 
				}//EO if the mid was invalid 
				
				//set the event id 
				pdo.set(PDOConstantFieldsInterface.D_EVENT_ID, sEventId) ;
				
				//add the pdo to the listPdosBuffer
				listPdosBuffer.add(pdo) ;
				
				  // The propagation action saves the PDO into the distributed cache in case the following 'executeFlow'
		        // will be executed on a different JVM; that way the remote JVM will get the latest PDO state.
		        CacheKeys.ProcessSessionsKey.propagate(falseremove from local cache , truesame JVM);
				
				//invoke the flow selector for the mid passing a flag flag indicating that the payments should not be saved internally 
				feedback = m_flowSelectorDelegate.executeFlow(Admin.getContextAdmin(), sMID, falsesave pdo,ServerConstants.EMPTY_OBJECT_ARRAY) ;
				
				// For the 'CacheKeys.ProcessSessionsKey.propagate()' call in the 'finally' clause
		        // in the BOHighValueProcessWrraper class.
		        CacheKeys.ProcessSessionsKey.apply();
				
				
				//if the feedback indicates a failure, iterate over the accumulated pdos mark all as thin (so as to propagate them to the distributed 
				//cache only to reset the locks and be discarded) and mark the transaction for rollback
				if(!feedback.isSuccessful()) {
					logger.warn("Message {} processing had failed during '{}' group actions, with Error Code {} due to {}s.\nAs this is a " +
							"business errors, the group actions operation shall continue regardlessly", sMID,  sEventId, feedback.getErrorCode(), 
							feedback.getErrorText())) ;
				}//EO if the flow had failed
	
			}//EO while there are more mids
			
			//if there was no error (no exception was thrown), save all pdos 
			PaymentDataFactory.batchSave(true remove from local and distribute, pdoList.toArray(new PDO[listPdosBuffer.size()])); 
			
			//now remove all pdos from local and propegate 
			CacheKeys.ProcessPDOKey.removeFromLocalAndPropagateToRemote(listPdosBuffer) ; 
			
			//if the errorMsgBuilder was not empty, reconfigure the feedback with its value 
			if(errorMsgBuilder.length() > 0) { 
				feedback.setFailure() ; 
				feedback.setErrorCode(ProcessErrorConstants.PDONoMinfRecord) ; 
				feedback.setErrorText("The Following MIDs are invalid:\n" + errorMsgBuilder.toString()) ; 
				response.setFeedback(feedback) ;
			}//OE if there were one or more invalid mids 
			
		}catch(Throwable t) { 			
			logger.error("Group Actions handler had failed running flow for payment {}, due to {}. Aborting the group actions " +
					"operation and rolling back all previous payments associated with this group action invocation", sCurrentMID, t.getMessage() == null ? "NullPointerException" : t.getMessage())) ;
			
			bCommit = false ; 
			
			//throw an exception so as to mark the transaction as rollback only in the client invoker
			if(t instanceof FlowException) throw (FlowException) t; 
			else throw new FlowException(t) ; 
		}finally{ 
			try{ 
				ThreadBoundCounterUTXWProxy.closeTx(bCommit) ;
			}catch(Throwable t) {
				//throw an exception so as to mark the transaction as rollback only in the client invoker
				throw new FlowException(t) ; 
			}//EO catch block 
		}//EO catch block 
				
		return response ;
	}//EOM 
*/		
}//EOC 
