package backend.core.module.message.ejbinterfaces;

import javax.ejb.Remote;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;

/**
 * Remote interface for Message.
 */
@Remote
public interface Message{

	public static final String REMOTE_JNDI_NAME="ejb/MessageBean";
	
	
	/** 
	 * Retruns the ResponseDataComponentText object for the MT and MOP combo boxes. 
	 * This method will be invoked during the Login process and additionally, when the 
	 * user replaces the office. 
	 * <br> 
	 * @param admin an {@link Admin} containing the calling source and the user's sessionId  
	 * @param sOffice Alias of the office associated with the given user.
	 */
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent getMTandMOPComboBoxes(final Admin admin, java.lang.String sOffice ) ;
    public Feedback checkUserPermission(final String sMsgType, final String sMsgSubType, final String sMsgStatus,String sDepartment, 
    		final String sActionButtonId, final boolean[] arrMessageReadonly,String sMID, Feedback feedback);


}//EOI  