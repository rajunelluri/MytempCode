package backend.core.module.message.groupactions.ejb;

import javax.ejb.Stateless;
import backend.core.SuperSLSB;
import com.fundtech.core.security.Admin;
import backend.businessobject.proxies.interceptors.InterceptorSetType;
import backend.core.module.message.groupactions.businessobjects.BOGroupActions;
import backend.core.module.message.groupactions.ejbinterfaces.GroupActionsLocal;
import backend.core.module.message.groupactions.ejbinterfaces.GroupActions;

@Stateless
public class GroupActionsBean extends SuperSLSB<GroupActions> implements GroupActionsLocal, GroupActions{
	
	public GroupActionsBean() { super(backend.core.module.message.groupactions.businessobjects.BOGroupActions.class, InterceptorSetType.Complete) ; }//EOM
	
	
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent performGroupActions(final Admin admin, java.lang.String sGroupActionsDocumentString ) throws com.fundtech.core.general.flows.FlowException {
		return this.m_bo.performGroupActions(admin, sGroupActionsDocumentString ) ;
	}//EOM

	public com.fundtech.datacomponent.response.SimpleResponseDataComponent performGroupActionsXBean(final Admin admin, java.io.Serializable serGroupActionsXBean ) throws com.fundtech.core.general.flows.FlowException {
		return this.m_bo.performGroupActionsXBean(admin, serGroupActionsXBean ) ;
	}//EOM

}//EOC