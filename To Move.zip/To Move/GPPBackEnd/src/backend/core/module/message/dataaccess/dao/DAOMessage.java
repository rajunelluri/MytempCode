package backend.core.module.message.dataaccess.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import com.fundtech.core.general.StatementParameter;
import com.fundtech.datacomponent.response.Feedback;

import backend.businessobject.BOBasic;
import backend.dataaccess.dto.DTOBoolean;
import backend.dataaccess.dto.DTODataHolder;
import backend.dataaccess.dto.DTOSingleValue;
import backend.staticdata.dataaccess.dao.DAOStaticData;

/**
 * Title:		DAOMessage
 * Description: Data access object which provides message services
 * Company:		Fundtech Israel
 * Author:		Asaf Levy
 * Date:		02/05/05
 * @version		1.0
 */
public class DAOMessage extends DAOStaticData 
{
  private static final String COLUMN_SIZE_FIELD = "COLUMN_SIZE" ;  

  /**
   * Retrieve the content of the MSG_TYPES table for the given office and messageAccess profile formal arguments 
   * 
   * <B><P>Pre-Condition:</B></P> sMessageProfile' value must not be null and be in the following format: '<permission>','<permission>'
   * 
   * @param sOffice User's assocaited office 
   * @param sMessageProfile User's message access permission profile 
   * 
   * @return Instance of {@link DTODataHolder} 
   */
  public final DTODataHolder getMessageMTandMOPComboBoxes(String sOffice, String sMessageProfile) { 
      final String QUERY_STRING = 
          "SELECT DISTINCT MSG_TYPES.MSG_TYPE, RTRIM(MSG_TYPES.MSG_SUB_TYPE) " +
          "AS MSGSUBTYPE ,UPPER(MSG_TYPE_MOP.MOP) AS MOP FROM MSG_TYPES, V_MOP MOP, MSG_TYPE_MOP WHERE MSG_TYPE_MOP.MOP = " +
          "MOP.MOP AND MSG_TYPE_MOP.MSG_TYPE=MSG_TYPES.MSG_TYPE AND MSG_TYPE_MOP.MSG_SUB_TYPE=MSG_TYPES.MSG_SUB_TYPE " +
          "AND MOP.OFFICE = ? AND MOP.USER_SELECTABLE <> 0 AND MSG_TYPE_MOP.GUI_DISPLAY = 'Y' " +
          "AND "+ms_DBType.getToCharValue()+"(MSG_TYPES.MSG_TYPE || RTRIM(MSG_TYPES.MSG_SUB_TYPE)) IN (" ; 
      
      String sFinalQueryString = QUERY_STRING + sMessageProfile + ") ORDER BY MSG_TYPES.MSG_TYPE";
      
      StatementParameter[] parameters = new StatementParameter[]  {
              new StatementParameter(sOffice, Types.VARCHAR) 
      }; 
      
      return getData(sFinalQueryString, parameters) ;
  }//EOM
  
  /**
   * Updates LVMIF table for group action process; note that this update action 
   * might not perform any update and if so, appropriate action will be performed
   * in the caller BO class.
   */
  public Feedback updateLVMIFForGroupActionProcess(String sActionDescription, String sFPID, 
                                                   Connection connection, 
                                                   int[] arrAffectedRows, Feedback feedback)
  { 
    final String UPDATE_LVMIF_USER_ACTION_QUERY = 
        "UPDATE LVMIF SET USER_PEND_ACT = ? WHERE FPID = ? AND USER_PEND_ACT IS NULL";
    
    final String FIELD_LVMIF_FPID = "LVMIF.FPID";
    
    boolean bReturnConnection = true; 
    boolean bSetAutoCommit = false; 
    
    StatementParameter[] arrStatementParameters = 
                         {new StatementParameter(sActionDescription, Types.VARCHAR),
                          new StatementParameter(FIELD_LVMIF_FPID, sFPID, Types.CHAR)};               
      
    return this.update(UPDATE_LVMIF_USER_ACTION_QUERY, arrStatementParameters, arrAffectedRows, 
                       new Connection[]{connection}, bReturnConnection, bSetAutoCommit, feedback) ;
  }
  
  
  public Feedback isUserTemplateExist(String sUserID, String sTemplateMID)
  {
    Feedback feedback;
    final String USER_TEMPLATE_SELECT = "SELECT * FROM USER_TEMPLATES T WHERE USER_ID = ? AND TEMPLATE_MID = ?";
    final String ERROR_MESSAGE = "Unique Constraint violated - Combination of User ID and Template MID already exists.";
    
    StatementParameter spUserID = new StatementParameter(sUserID,Types.VARCHAR);
    StatementParameter spTemplateMID = new StatementParameter(sTemplateMID,Types.VARCHAR);
    
    
    StatementParameter[] arrParameters = new StatementParameter[]{spUserID,spTemplateMID};
    
    DTOBoolean dto = isRecordExistToBoolean(USER_TEMPLATE_SELECT, arrParameters);
    feedback = dto.getFeedBack();
    if(feedback.isSuccessful() && !dto.isEmpty())
    {
      BOBasic.configureErrorFeedback(1, ERROR_MESSAGE, feedback);
    }
   
    return feedback;
    
  }
  
  /**
   * associates a template to a user
   */
  public Feedback associateTemplate(String sUserID, String sTemplateMID, Integer partitionID) 
  {
    //SQLIntegrityConstraintViolationException
    final String GET_DESCRIPTION_STATEMENT = "SELECT * FROM (SELECT TEXT FROM MSGNOTES WHERE MID = ?  AND PARTITION_ID = ? ORDER BY TIME_STAMP ) WHERE ROWNUM <= 1";
    
    final String INSERT_USER_TEMPLATES_STATEMENT = "INSERT INTO USER_TEMPLATES " +
                                                   "(USER_ID, TEMPLATE_MID, TEMPLATE_DESCRIPTION) " +
                                                   "VALUES (?, ?, ?)";
    
    
    Feedback feedback = new Feedback();
    
    StatementParameter spTemplateMID = new StatementParameter(sTemplateMID,Types.VARCHAR);
    StatementParameter spPartitionID = new StatementParameter(partitionID,Types.NUMERIC);
   
    StatementParameter[] arrParameters = new StatementParameter[]{spTemplateMID, spPartitionID};
    
    // Gets the dealt template description.
    DTOSingleValue dto = getSingleValue(GET_DESCRIPTION_STATEMENT, arrParameters, null);
    
    // There must be an entry as when creating a template, the user is forced to enter a description for that template. 
    boolean bSuccess = dto.isFeedBackSuccess() && !dto.isEmpty();
    
    if(bSuccess)
    {
      String sTemplateDescription = dto.getValue();
      
      arrParameters = new StatementParameter[]{new StatementParameter(sUserID,Types.VARCHAR),
                                               spTemplateMID,
                                               new StatementParameter(sTemplateDescription,Types.VARCHAR)};
      
      feedback = super.update(INSERT_USER_TEMPLATES_STATEMENT, arrParameters, null, null, false, false, null);
    }
    
    else
    {
      if(!dto.isFeedBackSuccess()) feedback = dto.getFeedBack();
      
      else // No description was found.
      {
        final String ERROR_MESSAGE = "Can't continue process - no description was found for this template";
        BOBasic.configureErrorFeedback(1, ERROR_MESSAGE, feedback);
      }
    }
    
    return feedback;
  }
  
  public DTODataHolder checkAssociatedStandingOrder(String sTemplateMID)
  {
    
    final String STANDING_ORDER_EXISTANCE_STATEMENT = "SELECT SO_NAME FROM STANDING_ORDER WHERE TEMPLATE_MID = ?   " +
    		"AND REC_STATUS <> 'DL'  AND SO_CLOSED =0";//returned records are active Standing orders associated with this template
    return  getData(STANDING_ORDER_EXISTANCE_STATEMENT,new StatementParameter[]{new StatementParameter(sTemplateMID, Types.VARCHAR)});       
    
  }
  
  /*
   * YONI S - not in use as for 10/2/2010
   */
  /*public Feedback cancelTemplate(String sTemplateMID)
  {
    final String DELETE_STATEMENT = "DELETE FROM USER_TEMPLATES WHERE TEMPLATE_MID = ?";
    
    return doDelete(DELETE_STATEMENT, new StatementParameter[]{new StatementParameter(sTemplateMID, Types.VARCHAR)}, null, null);
  }
  */

}