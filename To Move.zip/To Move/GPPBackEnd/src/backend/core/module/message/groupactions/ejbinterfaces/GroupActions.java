package backend.core.module.message.groupactions.ejbinterfaces;

import javax.ejb.Remote;
import com.fundtech.core.security.Admin;

/**
 * Remote interface for GroupActions.
 */
@Remote
public interface GroupActions{

	public static final String REMOTE_JNDI_NAME="ejb/GroupActionsBean";
	
	
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent performGroupActions(final Admin admin, java.lang.String sGroupActionsDocumentString ) throws com.fundtech.core.general.flows.FlowException ;
	
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent performGroupActionsXBean(final Admin admin, java.io.Serializable serGroupActionsXBean ) throws com.fundtech.core.general.flows.FlowException ;

}//EOI  