package backend.core.module.message.ejbinterfaces;

import javax.ejb.Local;

/**
 * Local interface for Message.
 */
@Local
public interface MessageLocal extends Message{} ; 