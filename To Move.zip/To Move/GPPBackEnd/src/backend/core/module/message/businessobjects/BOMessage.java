package backend.core.module.message.businessobjects;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.PermissionHandler;
import backend.businessobject.proxies.AuthorizeUser;
import backend.core.module.BOCoreServices;
import backend.core.module.MessageConstantsInterface;
import backend.core.module.message.dataaccess.dao.DAOMessage;
import backend.core.module.security.businessobjects.UserEntitlementData;
import backend.dataaccess.dto.DTODataHolder;
import backend.services.cache.entitlements.EntitlementsDataFactory;

import com.fundtech.annotations.DataSource;
import com.fundtech.annotations.Expose;
import com.fundtech.annotations.Wrap;
import com.fundtech.cache.entities.LogicalFields;
import com.fundtech.cache.entities.WebSessionInfo;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.message.events.MessageEventBus;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.fields.FieldType;
import com.fundtech.core.paymentprocess.data.fields.PaymentFieldInterface;
import com.fundtech.core.paymentprocess.data.fields.PaymentFieldInterface.ModificationType;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.request.FieldsContainer;
import com.fundtech.datacomponent.request.MessageFieldsInputData;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.datacomponent.response.SimpleResponseDataComponent;
import com.fundtech.scl.commonTypes.ExtnDocument;
import com.fundtech.util.ExceptionController;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalUtils;


/**
 * Title:       BOMessage
 * Description: Business object for core message services
 * Company:     Fundtech Israel
 * Author:      Asaf Levy
 * Date:        19/11/06
 * @version     1.0
 * 
 */  
@Wrap(datasources={@DataSource(datasourceJndiKey="active")})

public class BOMessage extends BOCoreServices 
{
  protected final static Logger logger = LoggerFactory.getLogger(BOMessage.class);
  protected static DAOMessage m_daoMessage = new DAOMessage();
  protected static final MessageEventBus m_EventBus = new MessageEventBus() ;
  
  protected static final PermissionHandler m_permissionHandler = new PermissionHandler();
  
  public static final ExtnDocument RECEIVED_STATUS_EXTENSION_MERGE_DOCUMENT = ExtnDocument.Factory.newInstance();
  
  static { 
	  RECEIVED_STATUS_EXTENSION_MERGE_DOCUMENT.addNewExtn().addNewProcessingPersistentInfo().setPMSGSTS(MessageConstantsInterface.MESSAGE_STATUS_RECEIVED) ;
  }//EO static 
	
  
  /**
   * Constructor.
   */
  public BOMessage(){ super(); }//EOM 
  
  /**
   * Retruns the ResponseDataComponentText object for the MT and MOP combo boxes. 
   * This method will be invoked during the Login process and additionally, when the 
   * user replaces the office. 
   * <br> 
   * @param admin an {@link Admin} containing the calling source and the user's sessionId  
   * @param sOffice Alias of the office associated with the given user.
   * 
   */
  @Expose
  @AuthorizeUser(returnWebSessionInfo=true) 
  public final SimpleResponseDataComponent getMTandMOPComboBoxes(String sOffice) {
     
	  
      SimpleResponseDataComponent response = new SimpleResponseDataComponent();
      Feedback feedback = new Feedback() ;
      Object[][] arrMTandMOPsData = null ;
      String sMessageProfile = null ;
      final WebSessionInfo webSessionInfo = Admin.getContextAdmin().getWebSessionInfo() ; 
      String sUserEntitlementName = null ;
      UserEntitlementData userPermissions = null ;
      
      //step 1: authorize the user and get the user entitlement data so that the message permissions could be extracted from it 
      final String STEP1_TRACE_MSG = "Step 1: Authorize the user and as a by product, retrieve the Session from cache" ; 
      logger.trace(STEP1_TRACE_MSG) ; 
      
      //now get the user's respective permissions list from the EntitlementDataFactory cache using the 
      //sUserEntitlementName 
      sUserEntitlementName = webSessionInfo.getUEntName() ; 
            
      logger.trace(USER_AUTHORIZATION_SUCCESS_MSG + sUserEntitlementName) ;
      
      //step 2: get the message profile (permissions) string from the UserEntitlementData 
      //note that the value retrieved is already formatted for insertion into an 'in(...)' 
      //sql query thus does not required additional conversion steps
      final String STEP2_TRACE_MSG = "Step 2: Retrieve the user's message permission profile from the EntitlementsDataFactory using the entitlement name obtained earlier" ;
      logger.trace(STEP2_TRACE_MSG) ; 
      
      userPermissions = EntitlementsDataFactory.getInstance().getUserEntitlementData(sUserEntitlementName) ;
      
      sMessageProfile = userPermissions.getPERM_PROF_MSG() ;
      
      //step 3: retrieve the MessageMTandMOPComboBoxes data from persistence 
      final String STEP3_TRACE_MSG = "Step 3: retrieve the MessageMTandMOPComboBoxes data from persistence using office " ;
      logger.trace(STEP3_TRACE_MSG + sOffice) ; 
      
      DTODataHolder dtoResponse = this.m_daoMessage.getMessageMTandMOPComboBoxes(sOffice, sMessageProfile) ;
      
      //check the response and if the operation had failed, configure and return 
      feedback = dtoResponse.getFeedBack() ;
      if(!dtoResponse.getFeedBack().isSuccessful()) {
          response = this.configureErrorResponse(feedback.getErrorText(), feedback, false) ;
      } else { 
          
          //Step 4 : convert the retrieved data into a pivotted matrix data strcuture required by the NestedComboBox instance. 
          final String STEP4_TRACE_MSG = "Step 4 : convert the retrieved data into a pivotted matrix data strcuture required by the NestedComboBox instance." ; 
          logger.trace(STEP4_TRACE_MSG) ; 
      
          arrMTandMOPsData = this.convertMsgTypeAndMopStructToMatrixForNestedCB(dtoResponse) ;
      }//EO if the retrieval operation was successful 
      
      //finally set the feeedbak and arrMTandMOPsData in the response and return it   
      response.setDataArray(new Object[]{ arrMTandMOPsData }  ) ;                
      response.setFeedback(feedback) ;
          
      return response ;
  }//EOM
    
  /**
   * Converts the content of a DTODataHolder intance retrieved using the this.m_daoMessage.getMessageMTandMOPComboBoxes() method 
   * into a pivotted matrix required by the {@link NestedComboBox} instance displaying the data.
   * <br>
   * <h1>NOTE:</h1> the DTODataHolder rows must be ordered by MSG_TYPE !!!! 
   * <br>
   * @param dto {@link DTODataHolder} instance holdling the Message type and MOP data.
   * @return Null if the DTO was null or did no contain data <b>or:</b>
   * <br>
   * an Object[3][n] with an inverted strcuture using the following format: 
   * <br>
   * Object[0] - The content of the MSG_TYPE column (as a row).
   * <br>
   * Object[1] - The content of the MSG_SUB  column (as a row).
   * <br>
   * Object[2] - The content of the MOP column (as a row).
   * 
   */
  private final Object[][] convertMsgTypeAndMopStructToMatrixForNestedCB(DTODataHolder dto) { 
      final String MOP_COLUMN_NAME = "MOP" ;
      final String MESSAGE_TYPE_COLUMN_NAME = "MSG_TYPE" ;
      final String MESSAGE_SUB_TYPE_COLUMN_NAME = "MSGSUBTYPE" ;
      final int ONE_MT_AND_MOPS_RECORD_LENGTH = 3;
      
      Object[][] arrMTandMOPsData = null;
      
      if(dto != null && !dto.isEmpty())  {
          
          //initialise the matrix 
          int iRowCount = dto.getRowsNumber() ; 
          arrMTandMOPsData = new Object[ONE_MT_AND_MOPS_RECORD_LENGTH][iRowCount];
          
          Map hmRow ; 
          String sMessageType, sMessageSubType, sMop = null ;
          
          List lstRows = dto.getDataAL() ;
          
          for(int i=0; i < iRowCount; i++) { 
              hmRow = (Map) lstRows.get(i) ;
              //get the three values and set them in the matrix row 
              sMessageType = (String) hmRow.get(MESSAGE_TYPE_COLUMN_NAME) ;
              sMessageSubType = (String) hmRow.get(MESSAGE_SUB_TYPE_COLUMN_NAME) ;
              sMop =  (String) hmRow.get(MOP_COLUMN_NAME) ; 
              
              arrMTandMOPsData[0][i] = (sMessageType == null ? GlobalConstants.EMPTY_STRING : sMessageType) ;
              arrMTandMOPsData[1][i]=  (sMessageSubType == null ? GlobalConstants.EMPTY_STRING : sMessageSubType) ;
              arrMTandMOPsData[2][i] = (sMop == null ? GlobalConstants.EMPTY_STRING : sMop) ;
              
          }//EO while there are more rows returned 
      }//EO if there was data in the dto 
          
      return arrMTandMOPsData ;
  }//EOM 
  
  protected final Feedback checkUserPermission(final PDO pdo, final String sActionButtonId, 
		  	final boolean[] arrMessageReadonly, final Feedback feedback){
	  
	  return  Admin.getContextAdmin().getCallSource().checkUserPermission(
			  pdo.getString(PDOConstantFieldsInterface.P_MSG_TYPE), 
			  pdo.getString(PDOConstantFieldsInterface.P_MSG_SUB_TYPE), 
			  pdo.getString(PDOConstantFieldsInterface.P_MSG_STS), 
			  pdo.getString(PDOConstantFieldsInterface.P_DEPARTMENT), 
			  sActionButtonId, arrMessageReadonly, pdo.getMID(), feedback);
  }//EOM 
  
  
  
  /**
   * @author Guy Segev
   * @date Aug 12, 2007
   * <br><br>
   * Configures a feedback using the formal args Exception as details source. 
   * <br>
   * @param e Exception according to which to configure the feedback 
   * @param feedback {@link Feedback} instance to configure - must not be null 
   */
  protected void processException(Throwable e, Feedback feedback) { 
      ExceptionController.getInstance().handleException(e, this) ; 
      feedback.setFailure();
      feedback.setErrorCode(ERROR_CODE_GENERAL);
      feedback.setErrorText(feedback.getErrorText() + e.getMessage());
  }
  
  private static boolean isFieldShouldBeMarkedAsModified(String [] totalUserModified, String fieldsId) {
    if (totalUserModified == null) {
      return true;
    }
    for (String field : totalUserModified) {
      if (field.endsWith(fieldsId)){
        return true;
      }
    }
    return false;
  }
  
 
  protected final void mergeModifiedFieldsWithPdo(final PDO pdo, final MessageFieldsInputData msgFieldsInput) { 
	      
	  final String MULTI_METADATA_DEL = "~~" ; 
	  final String MULTI_INTER_OCCURRENCE_DEL = "\\|" ; 
	  final String MULTI_INTER_VALUE_DEL = "``" ; 
	  
      FieldsContainer fcUserInput =  msgFieldsInput.getUserModifiedFields() ;  
      
      Iterator<Map.Entry<String,String>> iterator = null ;  
      Map.Entry<String,String> entry = null ; 
     
      if(fcUserInput != null ) { 
	      //get the user modified fields
	      iterator = fcUserInput.getHmFields().entrySet().iterator() ;
		
	      String sFieldId = null ; 
		  Object oValue = null, oOccurrenceValue = null ;
		  LogicalFields logicalFieldObj = null, occurrenceLogicalField = null;
		  String sAssociatedMonitorFieldId = null ; 
		  String[] arrMetadataValuesTuple = null, arrMetadataFieldIds = null, 
		  	arrOccurrences = null, arrOccurrenceValues = null ;
		  LogicalFields[] arrOccurrenceLogicalFields = null ; 
		  boolean bInitializedOccurrenceMetadata = false ; 
		  
	      while(iterator.hasNext()) {
	          
                entry = iterator.next() ;  
                
                sFieldId = entry.getKey() ;
                logicalFieldObj = CacheKeys.LogicalFieldsIdKey.getSingleLogicalOrUserDefinedField(sFieldId);
                
                if (logicalFieldObj != null){
                	
                	oValue = entry.getValue() ; 
                	
                    if (logicalFieldObj.getFieldType() == FieldType.XML_MULTI){
                    	
                   
//                    	//first delete all occurrences                    	                   	
                    	pdo.deleteAllOccurrences(sFieldId) ;
                    	
                    	if (oValue != null){
                    		
                    		if(oValue instanceof String && ((String)oValue).indexOf(MULTI_METADATA_DEL) != -1 ) { 
                    			//X_INSTR_CDTR_AGT_CD``X_INSTR_CDTR_AGT_INF~~CHQB``1|HOLD``2|PHOA``3
                    			arrMetadataValuesTuple = ((String)oValue).split(MULTI_METADATA_DEL) ; 
                    			arrMetadataFieldIds = arrMetadataValuesTuple[0].split(MULTI_INTER_VALUE_DEL) ; 
                    			arrOccurrences = arrMetadataValuesTuple[1].split(MULTI_INTER_OCCURRENCE_DEL) ;
                    			int iNoOfFieldsInOccurrence = arrMetadataFieldIds.length ; 
                    			int iNoOfOccurrences = arrOccurrences.length ; 
                    			int iOccurrenceIndex = 0 ; 
                    			
                    			for(int i=0; i < iNoOfOccurrences; i++) { 
                    				
                    				arrOccurrenceValues = arrOccurrences[i].split(MULTI_INTER_VALUE_DEL) ; 
                    				if(arrOccurrenceValues == null || arrOccurrenceValues.length == 0) continue ; 
                    				
                    				for(int j=0; j < iNoOfFieldsInOccurrence; j++) { 
                    					
                    					if(!bInitializedOccurrenceMetadata) { 
                    						if(arrOccurrenceLogicalFields == null) 
                    							arrOccurrenceLogicalFields = new LogicalFields[iNoOfFieldsInOccurrence] ; 
                    						
                    						arrOccurrenceLogicalFields[j] = 
                    							CacheKeys.LogicalFieldsIdKey.getSingle(arrMetadataFieldIds[j]) ; 
                    					}//EO if not yet iniitialized 
                    					
                    					//retrieve the logical field from the occurrences arr 
                    					occurrenceLogicalField = arrOccurrenceLogicalFields[j] ;
                    					
                    					if(occurrenceLogicalField == null || arrOccurrenceValues.length <= j) continue ; 
                    					
                    					//retrieve the occurrence value from the arrOccurrenceValues array 
                    					//for the given field 
                    					oOccurrenceValue = arrOccurrenceValues[j] ; 
                    					//if the value is not empty string or null, convert the value 
                    					//using the occurrence logical field data type 
                    					//and set the value into the pdo using the logical field's 
                    					//path parent and the given occurence index 
                    					if(GlobalUtils.isNullOrEmpty((String)oOccurrenceValue)) continue ; 
                    					//else 
                    					oOccurrenceValue = occurrenceLogicalField.getDataType().convert(oOccurrenceValue) ; 
                    					pdo.set(oOccurrenceValue, occurrenceLogicalField.getPathParentId(), iOccurrenceIndex, occurrenceLogicalField.getFieldLogicalId()) ; 
                    					                    						
                    				}//EO while there are more fields in a given occurrence
                    				
                    				//flag the metadata as initialized 
                    				bInitializedOccurrenceMetadata = true ; 
                    				
                    				//increment the iOccurrenceIndex
                    				iOccurrenceIndex++ ;
                    				
                    			}//EO whlie there are more occurrences 
                    			
            					
                    			//clear the flag so that if there are more multi occurrences fields, the metadata should be reinitialized  
                    			bInitializedOccurrenceMetadata = false ; 
                    			
                    		}else { 
                    		 
	                    		Object[] arr = ((String)oValue).split(System.getProperty("line.separator"));
		                        
		                        for (int i =0; i<arr.length;i++){
		                            pdo.set(arr[i], new Object[]{sFieldId, i+1});
		                            if (! isFieldShouldBeMarkedAsModified(msgFieldsInput.getTotalUserModifiedFields(), sFieldId)) {
		                              pdo.clearFromModifiedFields(sFieldId);
		                            }
		                        }//EO while there are more values 
		                        
                    		}//EO else if not multi occurrence panel 
                    	}//EO if there is a value  
                    	PaymentFieldInterface<Object> field  = pdo.getField(sFieldId);
                    	if (field!=null){
                    		field.setModificationType(PaymentFieldInterface.ModificationType.User);
                    	}
                    	
                    	
                    }else{
                    	
                    	oValue = logicalFieldObj.getDataType().convert(entry.getValue()) ;
                    	
                    	System.out.printf("merge fields --> %s : %s\n", sFieldId, oValue) ; 
                        pdo.set(sFieldId, oValue, ModificationType.User) ;
                        if(sFieldId.equals("OX_STTLM_AMT")){
                        	pdo.set("X_STTLM_AMT", oValue, ModificationType.User) ;
                        }

                        
                        //if the given field has a ASSOCIATED_MONITOR_FIELD value, then if the field's value 
                        //is  null, reset the associated monitor field else set the flag to 'M' (manual flag)
                        if((sAssociatedMonitorFieldId = logicalFieldObj.getAssociatedMonitorFieldId()) != null) { 
                        	pdo.set(sAssociatedMonitorFieldId, (oValue == null ? PDOConstantFieldsInterface.EPMTY_FLAG : PDOConstantFieldsInterface.USER_MANUAL_CHANGE_FLAG)) ;  
                        }//EO if there was an associated monitor field ID                        
                        
                        if (! isFieldShouldBeMarkedAsModified(msgFieldsInput.getTotalUserModifiedFields(), sFieldId)) {
                          pdo.clearFromModifiedFields(sFieldId);
                        }
                    }//EO if not multi occurrence 
                }//EO if there was a logical field definition for the field id 
		  }//EO while there are more fields to initialise
      }//EO if there were user modified fields 
      
      //store the auto modified fields values 
      //Note: this is just an infrastructure; currently there
      //wouold be no auto mo
      fcUserInput =  msgFieldsInput.getAutoModifiedFields() ;
      
      if(fcUserInput != null) { 
	      
	      //get the auto modified fields
	      iterator = fcUserInput.getHmFields().entrySet().iterator() ;
		  
	      while(iterator.hasNext()) {
		  		entry = iterator.next() ;  
		  		pdo.set(entry.getKey(), entry.getValue()) ; 
		  }//EO while there are more fields to initialise
      }//EO if there were auto modified fields 
      
      //parse the dirty message tables
      pdo.mergeMsgTables(msgFieldsInput.getDirtyMessageTables()) ; 
	  
  }//EOM 

  
  
}//EOC 
