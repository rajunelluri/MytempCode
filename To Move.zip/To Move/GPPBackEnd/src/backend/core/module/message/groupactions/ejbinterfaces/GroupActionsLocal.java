package backend.core.module.message.groupactions.ejbinterfaces;

import javax.ejb.Local;

/**
 * Local interface for GroupActions.
 */
@Local
public interface GroupActionsLocal extends GroupActions{} ; 