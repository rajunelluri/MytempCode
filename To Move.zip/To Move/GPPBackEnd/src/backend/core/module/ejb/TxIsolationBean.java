package backend.core.module.ejb;

import javax.ejb.Stateless;

import backend.businessobject.proxies.interceptors.InterceptorSetType;
import backend.core.SuperSLSB;
import backend.core.module.ejbinterfaces.TxIsolation;
import backend.core.module.ejbinterfaces.TxIsolationLocal;

import com.fundtech.core.security.Admin;

@Stateless
public class TxIsolationBean extends SuperSLSB<TxIsolation> implements TxIsolationLocal, TxIsolation{
	
	public TxIsolationBean() { super(backend.core.module.txisolation.BOTxIsolation.class, InterceptorSetType.Complete) ; }//EOM
	
	
	public backend.paymentprocess.erroraudit.Errorlog persistErrorLogInTxIsolation(final Admin admin, com.fundtech.cache.entities.Journalmessages journalMess, com.fundtech.util.ErrorAuditInputData eaInputData, java.lang.String sEditedErrorText ) {
		return this.m_bo.persistErrorLogInTxIsolation(admin, journalMess, eaInputData, sEditedErrorText ) ;
	}//EOM

	public backend.dataaccess.dto.DTODataHolder executeSP_GET_OUT_FILE(final Admin admin, java.lang.String sAction, backend.paymentprocess.subbatchcompletion.businessobjects.BOSubBatchCompletion.OutGroupingIDData outGroupingIDData, int iOutFileIndex ) {
		return this.m_bo.executeSP_GET_OUT_FILE(admin, sAction, outGroupingIDData, iOutFileIndex ) ;
	}//EOM

	public com.fundtech.datacomponent.response.Feedback updateInterfaceTypesStatusTable(final Admin admin, java.lang.String office, java.lang.String interfaceName, java.lang.String status, java.lang.String notActiveBehavior, com.fundtech.datacomponent.response.Feedback feedback ) {
		return this.m_bo.updateInterfaceTypesStatusTable(admin, office, interfaceName, status, notActiveBehavior, feedback ) ;
	}//EOM

	public com.fundtech.datacomponent.response.Feedback updateCDT_DAILY_TRANSFER_Table(final Admin admin, java.lang.String sTotalDebitAmount, java.lang.String sFileSummaryCustCode, java.lang.String sBusinessDate, java.lang.Long lDailyCdtXferLimit, boolean bFileSummaryOverrideLimitCheck, int[] arrAffectedRows ) {
		return this.m_bo.updateCDT_DAILY_TRANSFER_Table(admin, sTotalDebitAmount, sFileSummaryCustCode, sBusinessDate, lDailyCdtXferLimit, bFileSummaryOverrideLimitCheck, arrAffectedRows ) ;
	}//EOM

	public com.fundtech.datacomponent.response.Feedback rollbackCDT_DAILY_TRANSFER_Changes(final Admin admin, java.lang.String sTotalBaseAmount, java.lang.String sFileSummaryCustCode, java.lang.String sBusinessDate, int[] arrAffectedRows ) {
		return this.m_bo.rollbackCDT_DAILY_TRANSFER_Changes(admin, sTotalBaseAmount, sFileSummaryCustCode, sBusinessDate, arrAffectedRows ) ;
	}//EOM

	public com.fundtech.datacomponent.response.Feedback executeTask(final Admin admin, java.io.Serializable boObject, java.lang.String methodName, java.io.Serializable input ) {
		return this.m_bo.executeTask(admin, boObject, methodName, input ) ;
	}//EOM

	public com.fundtech.datacomponent.response.Feedback executeFileUploadTask(final Admin admin, java.lang.String sFilewithPath, java.lang.String sTaskID, java.lang.String sFinancialInst, java.lang.String sCntCurIban, java.lang.String sVersion, java.lang.String sHandleMembership, java.lang.String sMode ) {
		return this.m_bo.executeFileUploadTask(admin, sFilewithPath, sTaskID, sFinancialInst, sCntCurIban, sVersion, sHandleMembership, sMode ) ;
	}//EOM

	public com.fundtech.datacomponent.response.Feedback execute_Accuity_Upload(final Admin admin, java.lang.String sTaskID, java.lang.String sOffice, java.lang.String sDept, java.lang.String sFilePath, java.lang.String sUploadType, java.lang.String[] sFiles ) {
		return this.m_bo.execute_Accuity_Upload(admin, sTaskID, sOffice, sDept, sFilePath, sUploadType, sFiles ) ;
	}//EOM

	public java.io.Serializable invokeInterfaceInNewTx(final Admin admin, backend.paymentprocess.interfaces.common.TransmissionType enumTransmissionType, java.io.Serializable message, java.lang.String mid, com.fundtech.cache.entities.InterfaceTypes mapProperties, com.fundtech.datacomponent.response.Feedback feedback, java.util.HashMap mapContext ) throws java.lang.Exception {
		return this.m_bo.invokeInterfaceInNewTx(admin, enumTransmissionType, message, mid, mapProperties, feedback, mapContext ) ;
	}//EOM

	public int updateACCOUNTS_TableForBIBlockDiffPayerBankAndPayeeBank(final Admin admin, java.lang.String sDebitAccountUID, java.lang.String sP_DBT_AMT, java.lang.String sP_CDT_AMT, java.lang.String sCreditAccountUID, java.lang.Long lDebitAsset ) {
		return this.m_bo.updateACCOUNTS_TableForBIBlockDiffPayerBankAndPayeeBank(admin, sDebitAccountUID, sP_DBT_AMT, sP_CDT_AMT, sCreditAccountUID, lDebitAsset ) ;
	}//EOM

	public int updateACCOUNTS_TableForBIBlockSamePayerBankAndPayeeBank(final Admin admin, java.lang.String sDebitAccountUID, java.lang.String sP_DBT_AMT ) {
		return this.m_bo.updateACCOUNTS_TableForBIBlockSamePayerBankAndPayeeBank(admin, sDebitAccountUID, sP_DBT_AMT ) ;
	}//EOM

	public int updateACCOUNTS_TableForBIUnblockDiffPayerBankAndPayeeBank(final Admin admin, java.lang.String sCreditAccountUID, java.lang.String sP_CDT_AMT, java.lang.String sP_DBT_AMT, java.lang.String sDebitAccountUID ) {
		return this.m_bo.updateACCOUNTS_TableForBIUnblockDiffPayerBankAndPayeeBank(admin, sCreditAccountUID, sP_CDT_AMT, sP_DBT_AMT, sDebitAccountUID ) ;
	}//EOM

	public int updateACCOUNTS_TableForBIUnblockSamePayerBankAndPayeeBank(final Admin admin, java.lang.String sCreditAccountUID, java.lang.String sP_CDT_AMT ) {
		return this.m_bo.updateACCOUNTS_TableForBIUnblockSamePayerBankAndPayeeBank(admin, sCreditAccountUID, sP_CDT_AMT ) ;
	}//EOM
	
	public int updateAccountsSelectedAttributes(final Admin admin, String setQuery, String [] params) {
		return this.m_bo.updateAccountsSelectedAttributes(admin, setQuery, params);
	}
	
	//masss payment retrofit
	public int incNumOfProcessChunksInFileSummary(Admin paramAdmin, String paramString)throws Exception {
		return this.m_bo.incNumOfProcessChunksInFileSummary(paramAdmin, paramString) ;
	}

  public int incNumOfCompletedChunksInFileSummary(Admin paramAdmin, String paramString)throws Exception {
	  return this.m_bo.incNumOfCompletedChunksInFileSummary(paramAdmin, paramString) ;
  }

  public int decNumOfProcessChunksInFileSummary(Admin paramAdmin, String paramString) throws Exception {
	  return this.m_bo.decNumOfProcessChunksInFileSummary(paramAdmin, paramString) ;
  }

  public  int decNumOfCompletedChunksInFileSummary(Admin paramAdmin, String paramString)    throws Exception {
	  return this.m_bo.decNumOfCompletedChunksInFileSummary(paramAdmin, paramString) ;
  }

  public java.io.Serializable executeInNewTx(final Admin admin, com.fundtech.core.general.threading.Callable callable ) throws java.lang.Exception {
		return this.m_bo.executeInNewTx(admin, callable ) ;
	}//EOM
  
//masss payment retrofit
}//EOC