package backend.core.module;

import static com.fundtech.util.GlobalConstants.AT_SIGN;
import static com.fundtech.util.GlobalConstants.PIPE;
import static com.fundtech.util.GlobalConstants.COLUMN_UDF_VAL_DATE;
import static com.fundtech.util.GlobalConstants.COLUMN_UDF_VAL_NUMBER;
import static com.fundtech.util.GlobalConstants.COLUMN_UDF_VAL_STRING;
import static com.fundtech.util.GlobalConstants.DEFAULT_SERVER_OFFICE_NAME;
import static com.fundtech.util.GlobalConstants.DOT;
import static com.fundtech.util.GlobalConstants.UDF_DATA_TYPE_DATE;
import static com.fundtech.util.GlobalConstants.UDF_DATA_TYPE_DATE_TIME;
import static com.fundtech.util.GlobalConstants.UDF_DATA_TYPE_DECIMAL;
import static com.fundtech.util.GlobalConstants.UDF_DATA_TYPE_NUMBER;
import static com.fundtech.util.GlobalConstants.UDF_DATA_TYPE_STRING;
import static com.fundtech.util.GlobalUtils.isNullOrEmpty;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fundtech.cache.entities.ProfileUDF;
import com.fundtech.cache.entities.WebSessionInfo;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.cache.syspar.SystemParametersInterface;
import com.fundtech.core.security.Admin;
import com.fundtech.core.security.Admin.CallSource;
import com.fundtech.datacomponent.request.FieldsContainer;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.datacomponent.response.GlobalAbstractResponseDataComponent;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalDateTimeUtil;
import com.fundtech.util.GlobalUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.PermissionHandler;
import backend.businessobject.BOBasic;
import backend.businessobject.proxies.SkipInputValidation;
import backend.core.module.security.businessobjects.UserEntitlementData;
import backend.dataaccess.dto.DTODataHolder;
import backend.dataaccess.dto.DTOSingleValue;
import backend.services.cache.entitlements.EntitlementsDataFactory;
import backend.staticdata.dataaccess.dao.DAOStaticData;
import backend.staticdata.dataaccess.dto.DTOModifiedField;
import backend.staticdata.module.layout.factory.StaticDataProfileFactory;
import backend.staticdata.profilehandler.BasicProfileHandler;
import backend.staticdata.profilehandler.ProfileHandlerFactory;
import backend.staticdata.profilehandler.system.dataaccess.DAOUDFS;
import backend.util.ServerConstants;


/*
 * Title:       BOCoreServices
 * Description: Business object for core services 
 * Company:		Fundtech Israel
 * Author:		Asaf Levy
 * Date:		01/01/2007
 */
/**
 *   Note: should be used in conjunction with the logging only decoration as 
 *   this class is not exposed externally 
 */

public class BOCoreServices extends BOBasic
{

  private final static Logger logger = LoggerFactory.getLogger(BOCoreServices.class);
  private static DAOStaticData m_daoStaticData = new DAOStaticData();
  protected static PermissionHandler m_permissionHandler = new PermissionHandler();

  // Constants.
  public static final int ERROR_CODE_GENERAL = 1;
  public static final int ERROR_CODE_SESSION_VIOLATION = 7;
  
  // Session ID related constants.
  public static final char[] SESSION_ID_PROPER_CHARS = {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','V','U','W','X','Y','Z','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','v','u','w','x','y','z'};
  public static final int SESSION_ID_PROPER_CHARS_LENGTH = SESSION_ID_PROPER_CHARS.length;
  public static final int SESSION_ID_LENGTH = 16;
  
  // Trace constants.
  private static final String TRACE_VALIDATE_USER_ACCESS_PERMISSION_START = "BOCoreServices.validateUserAccessPermission() - START";
  private static final String TRACE_VALIDATE_USER_ACCESS_PERMISSION_END = "BOCoreServices.validateUserAccessPermission() - END. Result = ";
  protected static final String USER_AUTHORIZATION_SUCCESS_MSG = "User was authorized. User Entitlement Nmae: " ;
  protected static final String USER_AUTH_FAILURE_TRACE_MSG = "Exiting. IsUserAuthorized() failed; Error Text is: " ;

  //Column types.
  protected static final String COLUMN_TYPE_INTEGER = "INTEGER";
  protected static final String COLUMN_TYPE_NUMBER = "NUMBER";
  protected static final String COLUMN_TYPE_BIT = "BIT";
  protected static final String COLUMN_TYPE_BOOL = "BOOL";
  protected static final String COLUMN_TYPE_MONEY = "MONEY";
  protected static final String COLUMN_TYPE_FLOAT = "FLOAT";
  protected static final String COLUMN_TYPE_VARCHAR = "VARCHAR";
  protected static final String COLUMN_TYPE_CHAR = "CHAR";
  public static final String COLUMN_TYPE_STRING = "STRING";
  protected static final String COLUMN_TYPE_BINARY = "BINARY";
  protected static final String COLUMN_TYPE_DATE = "DATE";
  protected static final String COLUMN_TYPE_DATETIME = "DATETIME";
  protected static final String COLUMN_TYPE_TIME = "TIME";
  protected static final String COLUMN_TYPE_EMPTY = "EMPTY";
  
 public static final String UDF_DATA_TYPE = "DATA_TYPE"; 
  public static final String COLUMN_UID_UDFS = "UID_UDFS";
  
  
  public static final String U_ENT_NAME_KEY = "U_ENT_NAME" ;
  
  public static final int UDF_INVALID_MIN_LENGTH = 40268;
  public static final int UDF_INVALID_MAX_LENGTH = 40269;
  public static final int UDF_INVALID_PRECISION = 40270;
  public static final int UDF_INVALID_NUMBER = 40272;
  
  
  public BOCoreServices() { }//EOM 
  
  public final boolean isUserAuthorized(final Feedback feedback){ 
	return (this.performUserAuthoization(feedback) != null) ; 
  }//EOM

  /**
   * 
   * Jul 29, 2009
   * Guys
   *
   * @param feedback
   * @return WebSessionInfo object is user was authorized and null if not 
   */
  public final WebSessionInfo performUserAuthoization(Feedback feedback){
	final String METHOD_RESULT_MESSAGE_START_1 = "isUserAuthorized: ";
	final String METHOD_RESULT_MESSAGE_START_2 = "isUserAuthorized for user ";
	final String METHOD_RESULT_MESSAGE_2 = ", result: ";
	
	
	  
	final String WEBIDLTME_DEFUALT_VALUE = "300";
	final Admin admin = Admin.getContextAdmin() ; 
	
	WebSessionInfo webSessionInfo = null ; 
		
    boolean bIsAuthorized = false;
    StringBuilder sbResultMessage = new StringBuilder() ; 
    String sUserID = null ; 
    final CallSource enumCallSource = admin.getCallSource() ; 
    
    // No session ID; an example for that case, is all calls made during web server start up.
    if(enumCallSource == CallSource.System  || enumCallSource == CallSource.Service){
    // CALL_SOURCE_GUI - we need to check session ID, etc.
    	//create a dummy websession info object and return it 
        if(admin.updateContextIDUsingUserID())
        {
          //retrieve the websession info java bean using the UserWebSessionInfoKey which would use the user ID 
          //as the key to the region map entry 
          webSessionInfo = admin.getNSetWebSessionInfo() ;    
          //if there was such as session, update the admin with the session id instead of the user id 
          if(webSessionInfo!= null){
            admin.setSessionId(webSessionInfo.getSessionID()) ;
          }else{
            webSessionInfo = admin.getWebSessionInfo();
          }
          
          admin.setUpdateContextIDUsingUserID(false);
        }
        else
        {
          webSessionInfo = CacheKeys.WebSessionInfoKey.getSingle(admin) ;
        }
          
        if(webSessionInfo == null)
        {
          webSessionInfo = new WebSessionInfo(); 
          webSessionInfo.setSessionID(admin.getSessionID()) ;
        }
    	
    	bIsAuthorized = true;
    }else{
    	final String sSessionID = admin.getSessionID();
    	logger.info("The session id is [{}]", sSessionID);
    	//if the session is empty or not userid and invalidm fail the authorization 
    	if(GlobalUtils.isNullOrEmpty(sSessionID) || (!admin.updateContextIDUsingUserID() && !this.validateSessionID(sSessionID))) {
    		final String ERROR_MESSAGE = "Session Violation";
      
    		feedback.setFailure();
    		feedback.setErrorCode(ERROR_CODE_SESSION_VIOLATION);
    		feedback.setErrorText(ERROR_MESSAGE);
    		feedback.setUserErrorText(ERROR_MESSAGE);
    		logger.info(GlobalUtils.printArray(Thread.currentThread().getStackTrace(),false));
    		logger.error(ERROR_MESSAGE);
    		
    		bIsAuthorized = false;
      
    		//Error: Session Violation
    		// TODO - write to ERRORLOG, from what IP the session violation has occured.
    	}//EO if the session id was invalid  
    	else { 
	    	 
    		// The context ID was previously set with the user ID and we need to replace it with
    		// the session ID of that user. 
    		// e.g. profile select list web service request in which teh user ID is passed. 
    		if(admin.updateContextIDUsingUserID()){
    	    
    		  //retrieve the websession info java bean using the UserWebSessionInfoKey which would use the user ID 
    		  //as the key to the region map entry 
    		  webSessionInfo = CacheKeys.UserWebSessionInfoKey.getSingle(admin) ; 		
    		  //if there was such as session, update the admin with the session id instead of the user id 
    		  admin.setSessionId(webSessionInfo.getSessionID()) ; 
    		  
    		  admin.setUpdateContextIDUsingUserID(false);
    		  
    		}//EO if the updateContextIDUsingUserID was true 
    		else { 
    			webSessionInfo = CacheKeys.WebSessionInfoKey.getSingle(admin) ;
    		}//EO else if the session id was really the session id 
    		
    		//if the websession is null, then there is no such session
    		if(webSessionInfo == null) { 
    		  
    		  final String ERROR_MESSAGE = "User wasn't found.";
  	          final String USER_ERROR_MESSAGE = "Session violation";
  	    
  	          feedback.setFailure();
  	          feedback.setErrorCode(ERROR_CODE_SESSION_VIOLATION);
  	          feedback.setErrorText(ERROR_MESSAGE);
  	          feedback.setUserErrorText(USER_ERROR_MESSAGE);
  	          
  	          logger.error(ERROR_MESSAGE);
  	          
  	          bIsAuthorized = false;
  	          
  	         sbResultMessage.append(METHOD_RESULT_MESSAGE_START_1).append(bIsAuthorized) ; 
    			
    		}else { 
    			bIsAuthorized = true;  
    			
    			sUserID = webSessionInfo.getUserID() ; 
    			
    			sbResultMessage.append(METHOD_RESULT_MESSAGE_START_2).append(sUserID)
                .append(METHOD_RESULT_MESSAGE_2).append(bIsAuthorized).toString();
    		}//EO else if the web session info was found 
    	}//EO else if session id was valid 
	  
    }//EO else if the context was GUI  
    
    logger.trace(sbResultMessage.toString());
    
    

	return webSessionInfo ; 
  }//EOM 
  
  /**
   * Returns whether the passed session ID is valid or not.
   */
  private boolean validateSessionID(String sSessionID)
  {
    boolean bValid = true;
    
    if(   sSessionID == null 
       || (sSessionID != null && sSessionID.equals(ServerConstants.EMPTY_STRING))
       || (sSessionID != null && sSessionID.length() < SESSION_ID_LENGTH) )
    {
      bValid = false;
    }
    
    for(int i=0; i<SESSION_ID_LENGTH && bValid; i++)
    {
      char currentChar = sSessionID.charAt(i);
      
      if(   (currentChar >= '0' && currentChar <='9')
         || (currentChar >= 'A' && currentChar <='Z')
         || (currentChar >= 'a' && currentChar <='z') )
      {
      }
      else
      {
        bValid = false;
      }
    }
    
    return bValid;
  }
  
  
  /**
   * Gets a permission list, (probably from WebSessionInfo Cache), a field to search
   * in that list, (can be an access level, a queue name, a department name, etc),
   * and a permission type, (0/1), and checks for its existence.
   * For no permission type check, send -1. 
   *
   */
  public boolean validateUserPermission( String sPermissionsList, String sFieldToSearch,
                                        int iPermissionType, String sDelimiter)
  { 
    final String FIELD_TO_SEARCH = "Field to search: ";
    final String PERMISSION_TYPE = ". Permission type: ";
    final String PERMISSION_DELIMITER = ". Permission delimiter: ";
    final String PERMISSIONS_LIST = "Permissions list: ";
    
    logger.trace( TRACE_VALIDATE_USER_ACCESS_PERMISSION_START);
    
    String sFinalDelimiter = sDelimiter != null && !sDelimiter.equals(ServerConstants.EMPTY_STRING) ?
                             sDelimiter : ServerConstants.PERMISSIONS_DELIMITER;
    
    String sInputTrace = new StringBuffer(FIELD_TO_SEARCH).append(sFieldToSearch)
                                  .append(PERMISSION_TYPE).append(iPermissionType)
                                  .append(PERMISSION_DELIMITER).append(sFinalDelimiter)
                                  .append(PERMISSIONS_LIST).append(sPermissionsList).toString();
    logger.trace( new StringBuffer(sInputTrace).toString());
    
    boolean bValidated = false;
    
    if(sPermissionsList != null && !sPermissionsList.equals(ServerConstants.EMPTY_STRING))
    {
      sPermissionsList = new StringBuffer(sFinalDelimiter).append(sPermissionsList).toString();
      
      StringBuffer sbStringToSearch = new StringBuffer(sFinalDelimiter).append(sFieldToSearch);
      
      // Permission type search is required.
      if(iPermissionType != -1)
      {
        sbStringToSearch.append(ServerConstants.OPENING_PARENTHESIS).append(iPermissionType)
                        .append(ServerConstants.CLOSING_PARENTHESIS);
      }
      
      bValidated = sPermissionsList.indexOf(sbStringToSearch.toString()) != -1;
    }
    
    logger.trace( new StringBuffer(TRACE_VALIDATE_USER_ACCESS_PERMISSION_END).append(bValidated).toString());
    
    return bValidated;
  }
  
  /**
   * Gets a permission list, (probably from WebSessionInfo Cache), an arrya of fields to search
   * in that list, (can be an access level, a queue name, a department name, etc),
   * and a permission type, (0/1), and checks for its existence that would be matched for all fields 
   * For no permission type check, send -1., 
   * the method would return true IFF all the permissions exist in the permission list 
   * and false if not
   */
  protected boolean validateUserPermission(String sPermissionsList, String[] arrFieldsToSearch,  int iPermissionType) { 
      
      int iLength = arrFieldsToSearch.length ;
      boolean bWhereUserPermissionsValidated  = true ; 
      
      for(int i=0; i < iLength; i++) { 
          bWhereUserPermissionsValidated = this.validateUserPermission(sPermissionsList, arrFieldsToSearch[i], iPermissionType, null) ;
          
          //no need to continue if one was not in the permissions list
          if(!bWhereUserPermissionsValidated) return bWhereUserPermissionsValidated ;
      }//EO while there are more fields to searc
      
      return bWhereUserPermissionsValidated ;
  }//EOM
  
  /**
   * Jul 30, 2009
   * Guys
   * 
   * populates the user entitlment name for the given user 
   * 
   * @param arrUserEntitlementDataHolder
   * @return
   */
  @SkipInputValidation
  public final Feedback getUserEntitlementData(final Object[] arrUserEntitlementDataHolder)
  {
    final String ERROR_MESSAGE = "Can't get user entitlement data from cache.";
    
    final Feedback feedback = new Feedback();
    
    final WebSessionInfo webSessionInfo = CacheKeys.WebSessionInfoKey.getSingle() ;
    if(webSessionInfo == null) { 
    	feedback.setFailure();
        feedback.setErrorCode(ERROR_CODE_GENERAL);
        feedback.setErrorText(ERROR_MESSAGE);
        feedback.setUserErrorText(ERROR_MESSAGE);
    }else { 
    	 final String sUserEntitlementName = webSessionInfo.getUEntName() ; 
         arrUserEntitlementDataHolder[0] = EntitlementsDataFactory.getInstance().getUserEntitlementData(sUserEntitlementName);
    }//EO else if the websessioninfo for the given session was found 
        
    return feedback;
  }//EOM 
  
  /**
   * Sets the final column type to be passed back to the client side.
   * @bo.skip
   */
  public static String getFinalColumnType( String sColumnType)
  {
      return getFinalColumnType( null, sColumnType) ;
  }//EOM
  
  /**
   * Sets the final column type to be passed back to the client side.
   * 
   * @bo.skip
   */
  public static String getFinalColumnType( String sColumnName, String sColumnType)
  {
    String sFinalColumnType = ServerConstants.EMPTY_STRING;
    
    sColumnType = sColumnType.trim().toUpperCase();
    
    if(sColumnType.equals(COLUMN_TYPE_INTEGER))
    {
      sFinalColumnType = COLUMN_TYPE_NUMBER;
    }
    else if(sColumnType.equals(COLUMN_TYPE_BIT))
    {
      sFinalColumnType = COLUMN_TYPE_BOOL;
    }
    else if(sColumnType.equals(COLUMN_TYPE_MONEY))
    {
      sFinalColumnType = COLUMN_TYPE_FLOAT;
    }
    else if(   sColumnType.equals(COLUMN_TYPE_VARCHAR) 
            || sColumnType.equals(COLUMN_TYPE_CHAR))
    {
      sFinalColumnType = COLUMN_TYPE_STRING;
    }
    else if(   sColumnType.equals(COLUMN_TYPE_BINARY) 
            || sColumnType.equals(COLUMN_TYPE_FLOAT)
            || sColumnType.equals(COLUMN_TYPE_DATE)
            || sColumnType.equals(COLUMN_TYPE_TIME)
            || sColumnType.equals(COLUMN_TYPE_DATETIME))
    {
      sFinalColumnType = sColumnType;
    }
    else
    {
      sFinalColumnType = COLUMN_TYPE_EMPTY;
      
      if(sColumnName != null)
      {
        final String ERROR_MESSAGE = "BOQueues.getFieldType() - unknown column type for column ";
        String sErrorMessage = new StringBuffer(ERROR_MESSAGE).append(sColumnName).toString();
        logger.error( sErrorMessage);
      }
    }
    
    
    return sFinalColumnType;
  }
  
   /**
    * @author Guy Segev
    * @date Jul 1, 2007
    * <br><br>
    * Popuplates a new instance of {@link CredentialsHolder} containing the following artifacts: 
    * <br> 
    * webSessionInfoMap 
    * <br> 
    * userEntitlement name and data 
    * <br>
    * population process feedback 
    * <br> 
    * permission types array (read\write) 
    * <br>
    * userId 
    * <br>
    * The method goes through the following steps: 
    * <br> 
    * 1.    Invokes the isUserAuthorized and if the result is false returning the credentials object with 
    * <br>  only the feedback  
    * 2.    Retreival of the entitlement name and data 
    * 3.    Invocation of the {@link PermissionHandler#checkUserAccessLevel(String, char[], String)} 
    * <br> 
    *       checking the given user's permission for the given profile id.
    * <br> 
    * 4.    population of the arrPermissionTypes (read/write) for the given user in the context 
    * <br> 
    *       of the given profile id 
    * <b>Note:</b> The method DOES NOT check the department level permissions for the given user for the given 
    * <br>  
    * profile id!!!
    * <br>
    * @param admin {@link Admin} containing the sessionId 
    * @param sProfileId The id for which to check the user permissions 
    * @return {@link CredentialsHolder} instance containing gathered credentials set.
    */
   protected CredentialsHolder popuplateUserPermissionsHolder( String sProfileId) { 
       
       HashMap hmWebSessionInfo = new HashMap() ;
       UserEntitlementData  userEntitlementData = null ;
       Feedback feedback = new Feedback();
       char[] arrPermissionType = new char[1];
       String sUserEntitlementName = null ;
       final Admin admin = Admin.getContextAdmin() ; 
       
       CredentialsHolder dtoCredentials = new CredentialsHolder(admin) ;
       
       //authorized the user and load the websession info in the process 
       //if the user was not authorized, return the feedback only
       final WebSessionInfo webSessionInfo = this.performUserAuthoization(feedback) ;  
       
       //if the user was not authorized, abort 
       if(webSessionInfo == null) return dtoCredentials ;
             
       // Gets the user entitlement name.
       DTOSingleValue dtoUserEntName = new DTOSingleValue(webSessionInfo.getUEntName());
       if(dtoUserEntName.getFeedBack().isSuccessful() && !dtoUserEntName.isEmpty())
       {
           sUserEntitlementName = dtoUserEntName.getValue();
           userEntitlementData = EntitlementsDataFactory.getInstance().getUserEntitlementData(sUserEntitlementName);  
           
           // Checks if the user has access permission for this profile ID. 
           String sUserAccessLevels = userEntitlementData.getORIG_PERM_PROF_ACCESS();
           feedback = m_permissionHandler.checkUserAccessLevel(sProfileId, arrPermissionType, sUserAccessLevels);
           
           if(feedback.isSuccessful()) { 
               dtoCredentials.setUserEntitlementName(sUserEntitlementName) ; 
               dtoCredentials.setUserEntitlementData(userEntitlementData) ;
               dtoCredentials.setWebSessionInfoMap(hmWebSessionInfo) ; 
               dtoCredentials.setUserPermissionTypesForProfile(arrPermissionType) ;
               String sUserID  = webSessionInfo.getUserID() ; 
               dtoCredentials.setUserId(sUserID) ;
           }//EO if the permission checking was successfull 
           
       }else
       {
           feedback.setFailure();
           
           // Error description: 'No entitlement name for this user's session ID'.
           feedback.setErrorCode(28721);
       }//EO no entitlement name for the user's session id
         
      
       //finally set the feedback and return 
       dtoCredentials.setFeedback(feedback) ; 
       
       return dtoCredentials ; 
   }//EOM
   
   /**
    * @author Guy Segev
    * @date Jul 1, 2007
    * copyrights: Fundtech 2007.
    * <br> 
    * Container class to hold user credentials.
    */
  public class CredentialsHolder { 
      
      private Feedback m_feedback ; 
      private HashMap m_hmWebSessionInfo ; 
      private char[] m_arrPermissionTypes ;
      private String m_sUserEntitlementName ; 
      private UserEntitlementData m_userEntitlementData ;
      private String m_sUserId ; 
      private Admin m_admin ; 
      
      public CredentialsHolder(final Admin admin) {
           this.m_admin = admin ; 
      }//EOM
      
      public final void setFeedback(Feedback feedback) { 
          this.m_feedback = feedback ; 
      }//EOM
            
      public final Feedback getFeedback() { 
          return this.m_feedback ; 
      }//EOM
      
      public final void setWebSessionInfoMap(HashMap hmWebSessionInfoMap) { 
          this.m_hmWebSessionInfo = hmWebSessionInfoMap ; 
      }//EOM 
      
      public final HashMap getWebSessionInfoMap() { 
          return this.m_hmWebSessionInfo ; 
      }//EOM
      
      public final void setUserPermissionTypesForProfile(char[] arrPermissionTypes) { 
          this.m_arrPermissionTypes = arrPermissionTypes ;
      }//EOM
      
      public final char[] getPermissionTypesForProfile() { 
          return this.m_arrPermissionTypes ; 
      }//EOM
      
      public final void setUserEntitlementName(String sUserEntitlementName) { 
          this.m_sUserEntitlementName = sUserEntitlementName ; 
      }//EOM 
      
      public final String getUserEntitlementName() { 
          return this.m_sUserEntitlementName ; 
      }//EOM
      
      public final void setUserEntitlementData(UserEntitlementData userEntitlementData){ 
          this.m_userEntitlementData = userEntitlementData ; 
      }//EOM 
      
      public final UserEntitlementData getUserEntitlementData() { 
          return this.m_userEntitlementData ; 
      }//EOM
      
      public final void setUserId(String sUserId) { 
          this.m_sUserId = sUserId ; 
      }//EOM 
      
      public final String getUserId() { 
          return this.m_sUserId ; 
      }//EOM
      
      /**
       * @author Guy Segev
       * @date Jul 1, 2007
       * <br><br>
       * Convenience method, for creating a response configured to represent a given error.
       * <br>
       * @return {@link GlobalAbstractResponseDataComponent} instance containing the description of the error which 
       * <br> 
       * had occured.
       * <br> 
       * @see {@link BOBasic#configureErrorFeedback(String, int, String, Feedback)}  
       */
      public final GlobalAbstractResponseDataComponent configureCredentialsErrorResponse() {
          return configureErrorResponse( USER_AUTH_FAILURE_TRACE_MSG  + this.m_feedback.getErrorText(), 
                     this.m_feedback, false) ;
      }//EOM
      
      /**
       * @author Guy Segev
       * @date Jul 1, 2007
       * <br><br>
       * Convenience method, interogating the internal permission types array members,
       * <br> 
       * and returning true if the given user has a write permission for a given profile id. 
       * <br>
       * @return true if the [0] location in the {@link #m_arrPermissionTypes} == to {@link PermissionHandler#PERMISSION_WRITE} 
       * <br> 
       * return false otherwise. 
       */
      public final boolean doesUserHaveWriteProfilePermission()  {
          return this.m_arrPermissionTypes[0] == PermissionHandler.PERMISSION_WRITE ; 
      }//EOM
      
      /**
       * @author Guy Segev
       * @date Jul 1, 2007
       * <br><br>
       * <br>
       * Convenience method, for returning the value of the isSuccess attribute of the feedback member.
       * <br>
       * If the feedback is null returns a failure state
       * <br>
       * @return the result of the {@link Feedback#isSuccessful()} method invocation.
       */
      public final boolean isFeedbackSuccessful() {
          return (this.m_feedback != null && this.m_feedback.isSuccessful() ) ; 
      }//EOM
  
  }//EO inner class DTOCredentials 
  
  /**
   * Create two lists of profile UDFs; one list for new profile udfs and the other
   * for the updated ones
   * @param profileID
   * @param uid
   * @patram fcModifiedFields
   * @param isUpdate - indicates if this is an update flow
   * @param allUDFS - array list including two Maps for the new and updated udfs.
   * The method populate the two maps and set them in allUDFS ArrayList
   */
    protected Feedback handleProfileUDFs(String profileID, String uid , FieldsContainer fcModifiedFields, boolean isUpdate,  ArrayList<Map<String,String>>allUDFS) {
	
    	Map<String,String> newUDFS = new HashMap();
    	Map<String,String>  updatedUDFS = new HashMap();

    	DAOUDFS daoUDFS = new DAOUDFS();
    	String office = getOffice();
    	List<com.fundtech.cache.entities.ProfileUDF> udfList = CacheKeys.profileUDFKey.get(null,profileID,office);


    	//in case of update flow - get all udfs that are related to profile Id and has a value
    	Map udfsValuesMap = new HashMap();
    	if (isUpdate) {
    		DTODataHolder dtoUDFValues = daoUDFS.getUDFValuesByProfileID(profileID, uid );
    		udfsValuesMap = setUDFsValuesInMap(dtoUDFValues);
    	}

    	Map<String,ProfileUDF> udfsProfileMap = setProfileUDFsInMap(udfList);  
    	Feedback feedback = new Feedback();
    	//get all request udfs
    	String sAllUDFs = (String)fcModifiedFields.getField("allUDFs");
    	if (!isNullOrEmpty(sAllUDFs)) {
    		String[] udfsArr = sAllUDFs.split(AT_SIGN);
    		ProfileUDF udf =  null;       
    		String value = null;
    		String updatedValue  = null;

    		for (int i = 0; i < udfsArr.length; i++) {
    			String udfUID = udfsArr[i];
    			udf = udfsProfileMap.get(udfUID);
    			if (udf !=null) {
    				updatedValue = fcModifiedFields.getField(udfUID);
    				//format the value before inserting it into DB
    				updatedValue = formatValue(updatedValue,udf.getDataType(),office);
    				//validate that the updated value is valid
    				feedback = udfValueValidations(udf,updatedValue,office);   				
    				//get the old value
    				value = (String)udfsValuesMap.get(udfUID); 
    				if (feedback.isSuccessful()) {
    					//if there is an old value - then add the udf to the updated list
    					// if its current value is not equal to the old value
    					if (value != null) {
    						if (!value.equals(updatedValue )) {					
    							updatedUDFS.put(udfUID,updatedValue);
    						}
    					}else {
    						newUDFS.put(udfUID,updatedValue);
    					}
    				}else { 
    					return feedback;

    				}
    			}
    		}
    	}	 
    	allUDFS.add(newUDFS);
    	allUDFS.add(updatedUDFS);

    	return feedback;
    }

    /**
     * Format the given value according to its givan dataType
     */
    private String formatValue (String value, String dataType, String office) {
    	String formattedValue = value;
    	if (UDF_DATA_TYPE_DECIMAL.equalsIgnoreCase(dataType) || UDF_DATA_TYPE_NUMBER.equalsIgnoreCase(dataType)) {
    		formattedValue = formatDecimalValue(value, office);
    	}else if (UDF_DATA_TYPE_DATE_TIME.equalsIgnoreCase(dataType)) {
    		formattedValue = formatDateTimeValue(value);
    	}else if (UDF_DATA_TYPE_DATE.equalsIgnoreCase(dataType)) {
    		formattedValue = formatDateValue(value);
    	}
    	return formattedValue;
    }
    
    /**
     * Format decimal value - removing the thousands seprator and
     * set the decimal seperator as a point    
     */
    private String formatDecimalValue (String value, String office) {
    	String formattedValue = value;
    	String sDecimalSeparator = CacheKeys.SystParKey.getSingleParmValue(office, SystemParametersInterface.SYS_PAR_AS_DECISEP);
    	String sThousandSeparator = CacheKeys.SystParKey.getSingleParmValue(office, SystemParametersInterface.SYS_PAR_AS_THOUSEP);
    	//remove all thousand seperator
    	formattedValue = formattedValue.replaceAll(sThousandSeparator,"");
    	//set the decimal seperator as a point
    	if (!DOT.equals(sDecimalSeparator)) {
    		formattedValue = formattedValue.replaceAll(sDecimalSeparator,DOT);
    	}
    	return formattedValue;
    }
    
     private String formatDateTimeValue (String value) {
    	String formattedValue = value;
    	formattedValue = GlobalDateTimeUtil.getFormattedDateString(formattedValue,"dd/MM/yyyy HH:mm:ss",GlobalDateTimeUtil.STATIC_DATA_DATE_TIME);
    	
    	return formattedValue;
    }
     
      private String formatDateValue (String value ) {
    	String formattedValue = value;
    	formattedValue = GlobalDateTimeUtil.getFormattedDateString(formattedValue, "dd/MM/yyyy",GlobalDateTimeUtil.STATIC_DATA_DATE);
    	    	
    	return formattedValue;
    }
      
      private String cutTimeFromDate(String value) {
    	  return GlobalDateTimeUtil.getFormattedDateString(value,GlobalDateTimeUtil.STATIC_DATA_DATE_TIME,GlobalDateTimeUtil.STATIC_DATA_DATE);
      }
     
     
    /**
     * Return a map from the given udfs (in a list) where key=udf uid value=udf object from cache
     */
    protected Map setProfileUDFsInMap(List<ProfileUDF> list) {
    	ProfileUDF profileUDF = null;
    	String dataType, uidUdfs, label, listID, listValues;
    	Map <String,ProfileUDF>udfsMap = new HashMap();

    	HashMap hmRow = null;
    	if (!list.isEmpty()) {
    		for (ProfileUDF cachedUdf : list) {			  
    			udfsMap.put(cachedUdf.getUidUdf(),cachedUdf);
    		} 
    	}
    	return udfsMap;
    }

    /**
     * Return a map where the key=udfs uid and value=udfs value
     */
    protected Map setUDFsValuesInMap(DTODataHolder dtoUDFs) {

    	Map udfsMap = new HashMap();
    	String value= null, dataType, uidUdfs;
    	HashMap hmRow = null;
    	if (dtoUDFs.getFeedBack().isSuccessful() && !dtoUDFs.isEmpty()) {
    		for (int i = 0; i < dtoUDFs.getRowsNumber(); i++) {
    			hmRow = dtoUDFs.getDataRow(i);
    			dataType = (String)hmRow.get(UDF_DATA_TYPE);
    			uidUdfs = (String)hmRow.get(COLUMN_UID_UDFS);
    			if (UDF_DATA_TYPE_STRING.equalsIgnoreCase(dataType)) {
    				value = (String)hmRow.get(COLUMN_UDF_VAL_STRING);        
    			}else if (UDF_DATA_TYPE_DECIMAL.equalsIgnoreCase(dataType) ||UDF_DATA_TYPE_NUMBER.equalsIgnoreCase(dataType) ) {
    				value = ((String)hmRow.get(COLUMN_UDF_VAL_NUMBER));
    			}else if (UDF_DATA_TYPE_DATE.equalsIgnoreCase(dataType)) {					
    				value = ((String)hmRow.get(COLUMN_UDF_VAL_DATE)).toString();
    				value = cutTimeFromDate(value);
    			}else if ( UDF_DATA_TYPE_DATE_TIME.equalsIgnoreCase(dataType) ) {
    				value = ((String)hmRow.get(COLUMN_UDF_VAL_DATE)).toString();
    			}
    			udfsMap.put(uidUdfs,value);
    		}
    	}
    	return udfsMap;
    }


    /**
     * Get all values of the given list ID
     */
    protected String getUDFSListValues(String listID) {
    	DAOUDFS daoUDFS = new DAOUDFS();
    	DTODataHolder dtoListValues = daoUDFS.getListValues(listID);
    	Feedback feedback = dtoListValues.getFeedBack();
    	StringBuilder strBuild = new StringBuilder();
    	if(feedback.isSuccessful() && !dtoListValues.isEmpty()){
    		for (int i = 0; i < dtoListValues.getRowsNumber(); i++) {
    			HashMap hmRow = dtoListValues.getDataRow(i);
    			strBuild.append((String)hmRow.get("LIST_CODE")).append("==");
    		}
    	}
    	return strBuild.toString();
    }

    /**
     * Validate the value according to its data type
     */
    private Feedback udfValueValidations(ProfileUDF profileUDF, String value, String office) {

    	boolean isValid = true;
    	Feedback feedback = new Feedback();
    	String dataType = profileUDF.getDataType();
    	//string validations
    	if (UDF_DATA_TYPE_STRING.equalsIgnoreCase(dataType)) {
    		feedback = minLengthValidation(profileUDF.getScreenLabel(),profileUDF.getMinLength(), value);
    		if (feedback.isSuccessful()) {
    			feedback = 	maxLengthValidation(profileUDF.getScreenLabel(),profileUDF.getMaxLength(), value);			
    		}else {
    			return feedback;
    		}
    	//number validations
    	}else if (UDF_DATA_TYPE_NUMBER.equalsIgnoreCase(dataType)) {
    		feedback = numberValidation(profileUDF.getScreenLabel(), value);
    		if (feedback.isSuccessful()) {
    			feedback = maxLengthValidation(profileUDF.getScreenLabel(),profileUDF.getMaxLength(), value);
    		}
    	//decimal validations
    	}else if (UDF_DATA_TYPE_DECIMAL.equalsIgnoreCase(dataType)) {
    		feedback = udfValueDecimalValidations(profileUDF,value, office);
    	}
    	return feedback;
    }

    private Feedback minLengthValidation(String udfName, Integer minLength, String value) {
    	Feedback feedback = new Feedback();
    	if (minLength != null) {
    		if (value.length() < minLength.intValue()) {
    			feedback.setFailure();
    			feedback.setErrorCode(UDF_INVALID_MIN_LENGTH);
    			feedback.setUserErrorText(GlobalUtils.getEditedErrorText(UDF_INVALID_MIN_LENGTH,udfName,minLength.toString()));
    		}
    	}
    	return feedback;

    }

    private Feedback numberValidation(String udfName, String value) {
    	Feedback feedback = new Feedback();
    	try {
    		new Integer(value);
    	}catch (NumberFormatException ex) {
    		feedback.setFailure();
    			feedback.setErrorCode(UDF_INVALID_NUMBER);
    			feedback.setUserErrorText(GlobalUtils.getEditedErrorText(UDF_INVALID_NUMBER,udfName));
    	}
    	return feedback;
    }
    
    private Feedback maxLengthValidation(String udfName, Integer maxLength, String value) {
    	Feedback feedback = new Feedback();
    	if (maxLength != null) {
    		if (value.length() > maxLength.intValue()) {
    			feedback.setFailure();
    			feedback.setErrorCode(UDF_INVALID_MAX_LENGTH);
    			feedback.setUserErrorText(GlobalUtils.getEditedErrorText(UDF_INVALID_MAX_LENGTH,udfName,maxLength.toString()));
    		}
    	}
    	return feedback;

    }

    private Feedback precisionValidation(String udfName, Integer numberPrecision, String value, String office) {
    	Feedback feedback = new Feedback();
    	if (numberPrecision != null) {
    		String sDecimalSeparator = CacheKeys.SystParKey.getSingleParmValue(office, SystemParametersInterface.SYS_PAR_AS_DECISEP); 

    		String sFieldValuePartAfterDecimalPoint = value.substring(value.lastIndexOf(sDecimalSeparator)+1);

    		boolean bFoundLastNotZeroDigit = false;
    		int iActualPrecision = -1;
    		int iLastNonZeroIndex = -1;
    		int iLength = sFieldValuePartAfterDecimalPoint.length();

    		for(int j=iLength; j>0 && !bFoundLastNotZeroDigit; j--)
    		{
    			if(sFieldValuePartAfterDecimalPoint.charAt(j-1) == '0') continue;
    			else
    			{
    				iLastNonZeroIndex = j-1;
    				bFoundLastNotZeroDigit = true;
    				iActualPrecision = j;
    			}
    		}

    		if(numberPrecision.intValue()< iActualPrecision)
    		{
    			feedback.setFailure();
    			feedback.setErrorCode(UDF_INVALID_PRECISION);
    			feedback.setUserErrorText(GlobalUtils.getEditedErrorText(UDF_INVALID_PRECISION,udfName,numberPrecision.toString()));
    		}
    	}
    	return feedback;	  
    }

    private Feedback udfValueDecimalValidations(ProfileUDF profileUDF, String value, String office) {
    	
    	Feedback feedback = new Feedback();
    	String sDecimalSeparator = CacheKeys.SystParKey.getSingleParmValue(office, SystemParametersInterface.SYS_PAR_AS_DECISEP); 
		
    	String sFieldValuePartBeforeDecimalPoint = value.substring(0,value.lastIndexOf(sDecimalSeparator));
		
    	feedback = maxLengthValidation(profileUDF.getScreenLabel(),profileUDF.getMaxLength(), sFieldValuePartBeforeDecimalPoint);
    	if (feedback.isSuccessful()) {
    		feedback = precisionValidation(profileUDF.getScreenLabel(),profileUDF.getNumberPrecision(),value,office);
    	}
    	return feedback;
    }



	/**
	 * Get the user's office from web session info
	 */
    protected String getOffice() {
    	final WebSessionInfo webSessionInfo = CacheKeys.WebSessionInfoKey.getSingle() ;
    	String office = DEFAULT_SERVER_OFFICE_NAME;
    	if (!isNullOrEmpty(webSessionInfo.getDefaultOffice())) {
    		office = webSessionInfo.getDefaultOffice();
    	}
    	return office;
    }
    
    protected void createAdminIfNotFound()
  	{
  		Admin admin = Admin.getContextAdmin() ; 
  		if(admin == null){
  			//TODO: check the error, change or explain
  			logger.error("No Admin was found, creating a default, anonymous context admin. Note:  subsequent user authorizations will fail!!"); 
  			admin = new Admin(GlobalConstants.ANONYMOUS_CONTEXT_ID, CallSource.Gui) ;
  	  		Admin.setContextAdmin(admin);
  		}	
  	}
    
	protected Feedback profileUserAudit(String sProfileID, String office, DTOModifiedField[] arrModifiedFields,String note,String department,String userName, String sUniqueRecID){
		
		DTODataHolder dtoProfileData = new DTODataHolder();
		FieldsContainer fieldsContainer = new FieldsContainer();
		
		String sEffectiveDate = GlobalDateTimeUtil.getSimpleDateFormatByFormat(GlobalDateTimeUtil.STATIC_DATA_DATE).format(new Date());
		
		String sMasterTable = StaticDataProfileFactory.getInstance().getProfile(sProfileID).getMasterTable();
		fieldsContainer.addField(sMasterTable + ServerConstants.DOT + ServerConstants.COLUMN_OFFICE, office);
		fieldsContainer.addField(sMasterTable + ServerConstants.DOT + ServerConstants.COLUMN_DEPARTMENT, department);
		
		String sTimeStamp = GlobalDateTimeUtil.getSimpleDateFormatByFormat(GlobalDateTimeUtil.STATIC_DATA_TIME_STAMP).format(new Date());
		BasicProfileHandler profileHandler = ProfileHandlerFactory.getInstance().getHandler(sProfileID);
		return profileHandler.customizedAudit(userName, sUniqueRecID, note, sEffectiveDate, sTimeStamp, arrModifiedFields, dtoProfileData, fieldsContainer, sProfileID);
	}

}
