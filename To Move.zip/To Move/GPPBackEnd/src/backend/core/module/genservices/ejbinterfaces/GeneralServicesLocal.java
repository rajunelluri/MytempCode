package backend.core.module.genservices.ejbinterfaces;

import javax.ejb.Local;

/**
 * Local interface for GeneralServices.
 */
@Local
public interface GeneralServicesLocal extends GeneralServices{} ; 