package backend.core.module.genservices.businessobjects;

import static backend.core.module.MessageConstantsInterface.RULE_TYPE_ID_HISTORY_SEARCH;
import static backend.core.module.MessageConstantsInterface.RULE_TYPE_ID_TEMPLATE_SEARCH;
import static backend.core.module.MessageConstantsInterface.RULE_TYPE_ID_TRANSACTION_SEARCH;


import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.fundtech.annotations.Expose;
import com.fundtech.annotations.Wrap;
import com.fundtech.cache.entities.QueuePreferences;
import com.fundtech.cache.entities.WebSessionInfo;
import com.fundtech.cache.infrastructure.CacheServiceInterface;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.general.CustomerLoadInputData;
import com.fundtech.core.general.prefs.ProfileUserPreferencesHolder;
import com.fundtech.core.general.prefs.QueueFilterPreferencesHolder;
import com.fundtech.core.general.prefs.UserPreferencesContainer;
import com.fundtech.core.queues.response.ToolbarButton;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.datacomponent.response.GlobalBasicComboBox;
import com.fundtech.datacomponent.response.GlobalHtmlComboBox;
import com.fundtech.datacomponent.response.SimpleResponseDataComponent;
import com.fundtech.datacomponent.response.message.MessageTableBasicData;
import com.fundtech.datacomponent.response.message.MessageTableCellData;
import com.fundtech.datacomponent.response.message.MessageTableHeaderData;
import com.fundtech.datacomponent.response.message.MessageTableKeysInterface;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import backend.businessobject.proxies.AuthorizeUser;
import backend.businessobject.proxies.Input;
import backend.businessobject.proxies.SkipInputValidation;
import backend.core.module.BOCoreServices;
import backend.core.module.genservices.dataaccess.dao.DAOGeneralServices;
import backend.dataaccess.dto.DTODataHolder;
import backend.paymentprocess.erroraudit.ErrorAuditUtils;
import backend.services.cache.ASCacheFactory;
import backend.util.ServerConstants;

/**
 * Title:       BOGeneralServices
 * Description: Business object for core general services
 * Company:     Fundtech Israel
 * Author:      Asaf Levy
 * Date:        19/11/06
 * @version     1.0
 * 
 */
@Wrap      

public class BOGeneralServices extends BOCoreServices implements MessageTableKeysInterface
{

  private final static Logger logger = LoggerFactory.getLogger(BOGeneralServices.class);
  private static DAOGeneralServices m_daoGeneralServices = new DAOGeneralServices();
  
  private static final String IS = "IS";
  private static final String EMPTY = "EMPTY";
  private static final String  PATTERN_FOR_STRING_ENDS_WITH_DATE = ".+(19|20)\\d\\d[- /.](0[1-9]|1[012])[- /.](0[1-9]|[12][0-9]|3[01])";
  private static final String QUEUE_NAME_WITH_DASH_PROCESSING_DATE = "-------";  
  
  /**
   * String[] of fully qualified column names (in a <i>[TableName].[ColumnName>]</i> format), sorted in the desired display 
   * order to be used when contrcuting the {@link #loadCustomer(Admin, CustomerLoadInputData)} response. 
   * <br> 
   * <b><i>Note: Colunms from multiple tables could be used in this array<i></b>
   */ 
  String ARR_CUSTOMER_LOAD_REQUIRED_COLUMN__NAMES_ORDER[] = {"CUSTOMRS.SWIFT_ID","CUSTOMRS.ABA","CUSTOMRS.ALIAS","CUSTOMRS.CUST_CODE","CUSTOMRS.CUST_NAME","CUSTOMRS.ADDRESS1","CUSTOMRS.ADDRESS2","CUSTOMRS.ADDRESS3","CUSTOMRS.CUST_TYPE","CUSTOMRS.CITY","ACCOUNTS.ACC_NO","ACCOUNTS.CURRENCY"} ;
  
  /**
   * Constructor.
   *
   */
  public BOGeneralServices()
  {
  }
  
  /**
   * Handles the request for getting the application combo boxes. 
   * Returns SimpleResponseDataComponent with Object[2] in which:
   *  Index 0: matrix of REGULAR combo boxes data.
   *  Index 1: matrix of TABLE TYPE combo boxes data.
   */
  @Expose
  public SimpleResponseDataComponent getComboBoxes()
  {
    SimpleResponseDataComponent response = new SimpleResponseDataComponent();
    Object[] arrComboBoxesHolder = new Object[2];
    Feedback feedback;
    
    // STEP 1 - 
    // Gets all data of REGULAR combo boxes.
    DTODataHolder dtoRegularComboBoxes = m_daoGeneralServices.getRegularComboBoxesData();
    feedback = dtoRegularComboBoxes.getFeedBack();

    if(feedback.isSuccessful())
    {
      arrComboBoxesHolder[0] = getRegularComboBoxesMatrix(dtoRegularComboBoxes);
    
      // STEP 2 - 
      // Gets all data of TABLE TYPE combo boxes. 
      DTODataHolder dtoTableTypeComboBoxes = (DTODataHolder)m_daoGeneralServices.getTableTypeComboBoxesData();
      
      feedback = dtoTableTypeComboBoxes.getFeedBack();
      
      if(feedback.isSuccessful())
      {
        arrComboBoxesHolder[1] = getTableTypeComboBoxesMatrix(dtoTableTypeComboBoxes);
        response.setDataArray(new Object[]{arrComboBoxesHolder});
      }
    }
    Object [][] a=new Object[3][];
    if(!feedback.isSuccessful())
    {
      feedback.setFailure();
      response.setFeedback(feedback);
    }
        
    return response;
  }
  
  /**
   * Returns Object[][] for REGULAR combo boxes.
   */
  private Object[][] getRegularComboBoxesMatrix( DTODataHolder dtoTableTypeComboBoxes)
  {
    final String COLUMN_COMBO_ID = "COMBO_ID";
    final String COLUMN_CODE = "CODE";
    final String COLUMN_DESCRIPT = "DESCRIPT";
    final Admin admin = Admin.getContextAdmin() ; 
    
        
    
    Object[][] arrData = null;
    
    HashMap hmDataRow;
    
    int iLength = dtoTableTypeComboBoxes.getRowsNumber();
    
    // There is an actual data.
    if(iLength > 0)
    {
      arrData = new Object[3][iLength];
      
      for(int i=0; i<iLength; i++)
      {
        hmDataRow = dtoTableTypeComboBoxes.getDataRow(i);
        
        // Combo ID.
        arrData[0][i] = (String)hmDataRow.get(COLUMN_COMBO_ID);
        
        // Value code.
        arrData[1][i] = (String)hmDataRow.get(COLUMN_CODE);
        
        // Value description.
        arrData[2][i] = (String)hmDataRow.get(COLUMN_DESCRIPT);
      }
    }
    
    else
    {
      arrData = new Object[0][0];
    }
    
    
    
    return arrData;
  }
  
  /**
   * Returns Object[][] for TABLE TYPE combo boxes.
   */
  private Object[][] getTableTypeComboBoxesMatrix(DTODataHolder dtoTableTypeComboBoxes)
  {
    final String COLUMN_COMBO_ID = "COMBO_ID";
    final String COLUMN_VALUE_CODE = "VALUE_CODE";
    final String COLUMN_VALUE_DESCR = "VALUE_DESCR";
    final String COLUMN_ACTIVE = "ACTIVE";
    final Admin admin = Admin.getContextAdmin() ; 
    
        
    
    Object[][] arrData = null;
    
    HashMap hmDataRow;
    
    int iLength = dtoTableTypeComboBoxes.getRowsNumber();
    
    // There is an actual data.
    if(iLength > 0)
    {
      arrData = new Object[4][iLength];
      
      for(int i=0; i<iLength; i++)
      {
        hmDataRow = dtoTableTypeComboBoxes.getDataRow(i);
        
        // Combo ID.
        arrData[0][i] = (String)hmDataRow.get(COLUMN_COMBO_ID);
        
        // Value code.
        arrData[1][i] = (String)hmDataRow.get(COLUMN_VALUE_CODE);
        
        // Value description.
        arrData[2][i] = (String)hmDataRow.get(COLUMN_VALUE_DESCR);
        
        // Active.
        String sActive = (String)hmDataRow.get(COLUMN_ACTIVE);
        arrData[3][i] = Boolean.valueOf(!sActive.equals(ServerConstants.ZERO_VALUE));
      }
    }
    
    else
    {
      arrData = new Object[0][0];
    }
    
    
    
    return arrData;
  }
  
  /**
   * Handles the request for getting the LTERM/VTERM options. 
   * Returns SimpleResponseDataComponent with Object[3] in which:
   *  Index 0: HashMap of LTERM options data.
   *  Index 1: HashMap of LTERM groups options data.
   *  Index 2: HashMap of VTERM options data.
   */
  @Expose
  public SimpleResponseDataComponent getLTermVTermOptions()
  {
	final Admin admin = Admin.getContextAdmin() ; 
	    
	SimpleResponseDataComponent response = new SimpleResponseDataComponent();
    
    Object[] arrLTermVTermOptionsHolder = new Object[3];
    
    // Gets all data of LTERM/VTERM options data.
    DTODataHolder[] arrLTermVTermData = m_daoGeneralServices.getLTermVTermOptions();
    
    Feedback feedback = checkMultipleFeedbackSuccess(arrLTermVTermData);
    
    if(feedback.isSuccessful())
    {
      updateLTermVTermOptionsHolder(arrLTermVTermData, arrLTermVTermOptionsHolder);
      response.setDataArray(new Object[]{arrLTermVTermOptionsHolder});
    }
    
    else
    {
      feedback.setFailure();
      response.setFeedback(feedback);
    }
        
    return response;
  }
  
  /**
   * Prepares all LTerm/VTerm data.
   */
  private void updateLTermVTermOptionsHolder(DTODataHolder[] arrLTermVTermData,
                                             Object[] arrLTermVTermOptionsHolder)
  {
    final String COLUMN_OFFICE = "OFFICE";
    final String COLUMN_MOP = "MOP";
    final String COLUMN_DESCRIPT = "DESCRIPT"; // Not an actual column; see DAO class.
    final String COLUMN_VTERM = "VTERM";
    final String COLUMN_VTERM_GRP = "VTERM_GRP";
	final Admin admin = Admin.getContextAdmin() ; 
	
     
    
    HashMap hmLTermOptions = new HashMap();
    HashMap hmLTermGroupOptions = new HashMap();
    HashMap hmVTermOptions = new HashMap();
    
    for(int i=0; i<arrLTermVTermData.length; i++)
    {
      DTODataHolder DTODataHolder = arrLTermVTermData[i];
      
      int iLength = DTODataHolder.getRowsNumber();
         
      for(int j=0; j<iLength; j++)
      {
        HashMap hmDataRow = DTODataHolder.getDataRow(j);
        
        String sOffice = (String)hmDataRow.get(COLUMN_OFFICE);
        String sMOP = (String)hmDataRow.get(COLUMN_MOP);
        
        String sDescript;
        
        // LTerm options.
        if(i == 0)
        {
          sDescript = (String)hmDataRow.get(COLUMN_DESCRIPT);
          updateSingleLTermVTermHM(hmLTermOptions, sOffice, sMOP, sDescript);
        }
        
        // LTerm group options.
        else if(i == 1)
        {
          sDescript = (String)hmDataRow.get(COLUMN_DESCRIPT);
          updateSingleLTermVTermHM(hmLTermGroupOptions, sOffice, sMOP, sDescript);
        }
        
        // VTerm options.
        else if (i == 2)
        {
          String sVTerm = (String)hmDataRow.get(COLUMN_VTERM);
          updateSingleLTermVTermHM(hmVTermOptions, sOffice, sMOP, sVTerm);
        }
        
        // VTerm group options.
        else if(i == 3)
        {
          String sVTermGroup = (String)hmDataRow.get(COLUMN_VTERM_GRP);
          updateSingleLTermVTermHM(hmVTermOptions, sOffice, sMOP, sVTermGroup);
        }
      }
    }
    
    arrLTermVTermOptionsHolder[0] = hmLTermOptions;
    arrLTermVTermOptionsHolder[1] = hmLTermGroupOptions;
    arrLTermVTermOptionsHolder[2] = hmVTermOptions;
    
     
  }
  
  /**
   * Gets a HashMap, an office, a MOP and a description and updates the HashMap.
   * The HashMap structure is: Key - Office
   *                           Value - HashMap in which: Key - MOP.
   *                                                     Value - ArrayList of descriptions.
   */
  private void updateSingleLTermVTermHM(HashMap hm, String sOffice, String sMOP, String sDescription)
  {
    HashMap hmMOPtoDescription = (HashMap)hm.get(sOffice);
    
    if(hmMOPtoDescription == null)
    {
      hmMOPtoDescription = new HashMap();
      hm.put(sOffice, hmMOPtoDescription);
    }
    
    ArrayList alMOPDescriptions = (ArrayList)hmMOPtoDescription.get(sMOP);
    
    if(alMOPDescriptions == null)
    {
      alMOPDescriptions = new ArrayList();
      hmMOPtoDescription.put(sMOP, alMOPDescriptions);
    }
    
    alMOPDescriptions.add(sDescription);
  }
    
  /**
   * Gets a DTODataHolder[], loops it and if finds a failure feedback in one
   * of the DTODataHolder objects, returns this feedback, otherwise a successfull 
   * feedback will be returned.
   */
  private Feedback checkMultipleFeedbackSuccess(DTODataHolder[] arrDTODataHolder)
  {
    Feedback feedback = new Feedback();
    
    boolean bContinue = true;
    
    int iLength = arrDTODataHolder.length;
    
    for(int i=0; bContinue && i<iLength; i++)
    {
      if(!arrDTODataHolder[i].isFeedBackSuccess())
      {
        feedback = arrDTODataHolder[i].getFeedBack();
        bContinue = false;
      }
    }
    
    return feedback;
  }
  
  /**
   * Handles the request for getting the ABA options. 
   * Returns SimpleResponseDataComponent with a HashMap in which:
   *  Key - Office
   *  Value - HashMap in which: Key - MOP.
   *                            Value - GlobalBasicComboBox object with ABA options for this MOP.
   */
  @Expose
  public SimpleResponseDataComponent getABAs()
  {    
    SimpleResponseDataComponent response = new SimpleResponseDataComponent();
    
    Feedback feedback;
    
    // Gets all ABA options data.
    DTODataHolder dtoABAData = m_daoGeneralServices.getABAsData();
    feedback = dtoABAData.getFeedBack();
    
    if(feedback.isSuccessful())
    {
      HashMap hmOfficeToMOP_ABA_Options = getOfficeToMOP_ABA_OptionsHM(dtoABAData);
      response.setDataArray(new Object[]{hmOfficeToMOP_ABA_Options});
    }
    
    else
    {
      feedback.setFailure();
      response.setFeedback(feedback);
    }
        
    return response;
  }//EOM 
  
  /**
   * Prepares all ABA data.
   */
  private HashMap getOfficeToMOP_ABA_OptionsHM(DTODataHolder dtoABAData)
  {
    final String COLUMN_OFFICE = "OFFICE";
    final String COLUMN_MOP = "MOP";
    final String COLUMN_SWIFT_ID = "SWIFT_ID";
    
    HashMap hmOfficeToMOP_ABA_Options = new HashMap();
    
    String sOffice, sMOP, sSwiftID;
    
    int iLength = dtoABAData.getRowsNumber();
    
    for(int i=0; i<iLength; i++)
    {
      HashMap hmDataRow = dtoABAData.getDataRow(i);
      
      sOffice = (String)hmDataRow.get(COLUMN_OFFICE);
      sMOP = (String)hmDataRow.get(COLUMN_MOP);
      sSwiftID = (String)hmDataRow.get(COLUMN_SWIFT_ID);
      
      updateOfficeToMOP_ABA_OptionsHM(hmOfficeToMOP_ABA_Options, sOffice, sMOP, sSwiftID);
    }

    // Builds the XML of each GlobalBasicComboBox object.
    Iterator iterOfficeKeys = hmOfficeToMOP_ABA_Options.keySet().iterator();
    while(iterOfficeKeys.hasNext())
    {
      sOffice = (String)iterOfficeKeys.next();
      HashMap hmMOPtoABAs = (HashMap)hmOfficeToMOP_ABA_Options.get(sOffice);
      
      Iterator iterMOPKeys = hmMOPtoABAs.keySet().iterator();
      while(iterMOPKeys.hasNext())
      {
        sMOP = (String)iterMOPKeys.next();
        GlobalBasicComboBox globalBasicCB_ABAs = (GlobalBasicComboBox)hmMOPtoABAs.get(sMOP);
        globalBasicCB_ABAs.buildXml();
      }
    }
    
    return hmOfficeToMOP_ABA_Options;
  }
  
  /**
   * Gets a HashMap, an office, a MOP and a swift ID and updates the HashMap.
   * The HashMap structure is: Key - Office
   *                           HashMap in which: Key - MOP.
   *                                             Value - GlobalBasicComboBox object with 
   *                                                     ABA options for this MOP.
   */
  private void updateOfficeToMOP_ABA_OptionsHM(HashMap hmOfficeToMOP_ABA_Options, String sOffice,
                                               String sMOP, String sSwiftID)
  {
    HashMap hmMOPtoABAs = (HashMap)hmOfficeToMOP_ABA_Options.get(sOffice);
    
    if(hmMOPtoABAs == null)
    {
      hmMOPtoABAs = new HashMap();
      hmOfficeToMOP_ABA_Options.put(sOffice, hmMOPtoABAs);
    }
    
    GlobalBasicComboBox globalBasicCB_ABAs = (GlobalBasicComboBox)hmMOPtoABAs.get(sMOP);
    
    if(globalBasicCB_ABAs == null)
    {
      globalBasicCB_ABAs = new GlobalBasicComboBox();
      hmMOPtoABAs.put(sMOP, globalBasicCB_ABAs);
    }
    
    globalBasicCB_ABAs.addEntry(ServerConstants.EMPTY_STRING, sSwiftID, 
                                new String[]{ServerConstants.ATTRIBUTE_LONG_VALUE}, new String[]{sSwiftID});
  }
  
  /**
   * Handles the request for getting the holidays data. 
   * Returns SimpleResponseDataComponent with matrix of all holidays data.
   */
  @Expose
  public SimpleResponseDataComponent getHolidays()
  {
    
    SimpleResponseDataComponent response = new SimpleResponseDataComponent();
    
    Feedback feedback;
    
    // Gets all ABA options data.
    DTODataHolder dtoHolidaysData = m_daoGeneralServices.getHolidaysData();
    feedback = dtoHolidaysData.getFeedBack();
    
    if(feedback.isSuccessful())
    {
      Object[][] arrHolidaysData = getHolidaysData(dtoHolidaysData);
      response.setDataArray(new Object[]{arrHolidaysData});
    }
    
    else
    {
      feedback.setFailure();
      response.setFeedback(feedback);
    }
        
    return response;
  }
  
  /**
   * Prepares all holidays data.
   */
  private Object[][] getHolidaysData(DTODataHolder dtoHolidaysData)
  {
    final String COLUMN_CALNAME = "CALNAME";
    final String COLUMN_HOLDATE = "HOLDATE";

    int iLength = dtoHolidaysData.getRowsNumber();
    
    Object[][] arrHolidaysData = new Object[2][iLength];
    
    String sCalName, sHoldDate;
    
    for(int i=0; i<iLength; i++)
    {
      HashMap hmDataRow = dtoHolidaysData.getDataRow(i);
      
      // Cal name.
      arrHolidaysData[0][i] = (String)hmDataRow.get(COLUMN_CALNAME);
      
      // Hold date.
      arrHolidaysData[1][i] = (String)hmDataRow.get(COLUMN_HOLDATE);
    }
    
    return arrHolidaysData;
  }  
  
  /**
   * Handles the request for getting the relationships data.
   * Returns SimpleResponseDataComponent with HashMap in which:
   *  Key - List type, (TMS_LIST_RELATION.LIST_TP column).
   *  Value - HashMap in which:
   *              Key - 'MT + MST' (no slash separating between),
   *                    which is equivalent to the TMS_LIST_RELATION.ITEM_NM column.
   *              Value - ArrayList of related number types for the related list type.
   *                      (e.g. TMS_LIST_RELATION.RELATED_LIST_TP is 'BFC',
   *                            and we'll have an ArrayList of TMS_LIST_RELATION.ITEM_NM columns).
   */
  @Expose
  public SimpleResponseDataComponent getRelationships()
  {
	  SimpleResponseDataComponent response = new SimpleResponseDataComponent();
    
    Feedback feedback;
    
    // Gets all relationships data.
    DTODataHolder dtoRelationshipsData = m_daoGeneralServices.getRelationshipsData();
    feedback = dtoRelationshipsData.getFeedBack();
    
    if(feedback.isSuccessful())
    {
      HashMap hmRelationshipsData = getRelationshipsDataHM(dtoRelationshipsData);
      response.setDataArray(new Object[]{hmRelationshipsData});
    }
    
    else
    {
      feedback.setFailure();
      response.setFeedback(feedback);
    }
        
    return response;
  }
  
  /**
   * Prepares all relationships data.
   */
  private HashMap getRelationshipsDataHM(DTODataHolder dtoRelationshipsData)
  {
    final String COLUMN_LIST_TP = "LIST_TP";
    final String COLUMN_ITEM_NM = "ITEM_NM";
    final String COLUMN_RELATED_LIST_TP = "RELATED_LIST_TP";
    final String COLUMN_RELATED_ITEM_DEFAULT_IN = "RELATED_ITEM_DEFAULT_IN";
    final String COLUMN_RELATED_ITEM_NM = "RELATED_ITEM_NM";

    int iLength = dtoRelationshipsData.getRowsNumber();
    
    HashMap hmRelationshipsData = new HashMap();
    
    String sListType, sItemNM, sRelatedListTP, sRelatedItemDefaultIn, sRelatedItemNM;
    
    for(int i=0; i<iLength; i++)
    {
      HashMap hmDataRow = dtoRelationshipsData.getDataRow(i);
      
      sListType = (String)hmDataRow.get(COLUMN_LIST_TP);
      
      // In relation to BFC, this value in the database is 'MT+MST'.
      sItemNM = (String)hmDataRow.get(COLUMN_ITEM_NM);
      
      sRelatedItemNM = (String)hmDataRow.get(COLUMN_RELATED_ITEM_NM);
      
      updateRelationshipsHM(hmRelationshipsData, sListType, sItemNM, sRelatedItemNM);
    }
    
    return hmRelationshipsData;
  }  
  
  /**
   * Gets a HashMap, a list type, a related list type and a related item and
   * updates the HashMap.
   * The HashMap structure is:
   *  Key - List type, (TMS_LIST_RELATION.LIST_TP column).
   *  Value - HashMap in which:
   *              Key - 'MT + MST' (no slash separating between),
   *                    which is equivalent to the TMS_LIST_RELATION.ITEM_NM column.
   *              Value - ArrayList of related number types for the related list type.
   *                      (e.g. TMS_LIST_RELATION.RELATED_LIST_TP is 'BFC',
   *                            and we'll have an ArrayList of TMS_LIST_RELATION.ITEM_NM columns).
   */
  private void updateRelationshipsHM(HashMap hmRelationships, String sListType,
                                     String sItemNM, String sRelatedItemNM)
  {
    HashMap hmSingleListTypeValues = (HashMap)hmRelationships.get(sListType);
    
    if(hmSingleListTypeValues == null)
    {
      hmSingleListTypeValues = new HashMap();
      hmRelationships.put(sListType, hmSingleListTypeValues);
    }
    
    ArrayList alRelatedItem_Items = (ArrayList)hmSingleListTypeValues.get(sItemNM);
    
    if(alRelatedItem_Items == null)
    {
      alRelatedItem_Items = new ArrayList();
      hmSingleListTypeValues.put(sItemNM, alRelatedItem_Items);
    }
    
    alRelatedItem_Items.add(sRelatedItemNM);
  }
    
  /**
   * Handles the request for getting the system parameters data.
   * Returns SimpleResponseDataComponent with a matrix of system parameters data 
   * taken from SYST_PAR table, according the required parameters in the passed 
   * 'arrBasicRequiredSystemParameters' parameter.
   * 
   */
  @Expose
  @SkipInputValidation
  public SimpleResponseDataComponent getWEBSystemParameters(Object[] arrBasicRequiredSystemParameters)
  {    
    SimpleResponseDataComponent response = new SimpleResponseDataComponent();
    
    Feedback feedback;
    
    // Gets all system parameters data.
    DTODataHolder dtoWEBSystemParametersData = m_daoGeneralServices.getWEBSystemParametersData(arrBasicRequiredSystemParameters);
    feedback = dtoWEBSystemParametersData.getFeedBack();
    
    if(feedback.isSuccessful())
    {
      Object[][] arrWEBSystemParametersData = getWEBSystemParametersData(dtoWEBSystemParametersData);
      response.setDataArray(new Object[]{arrWEBSystemParametersData});
    }
    
    else
    {
      feedback.setFailure();
      response.setFeedback(feedback);
    }
        
    return response;
  }
  
  /**
   * Prepares all statuses data.
   */
  private Object[][] getWEBSystemParametersData(DTODataHolder dtoWEBSystemParametersData)
  {
    final String COLUMN_OFFICE = "OFFICE";
    final String COLUMN_PARAM_NAME = "PARAM_NAME";
    final String COLUMN_PARM_VALUE = "PARM_VALUE";

    int iLength = dtoWEBSystemParametersData.getRowsNumber();
    
    Object[][] arrWEBSystemParametersData = new Object[3][iLength];
    
    for(int i=0; i<iLength; i++)
    {
      HashMap hmDataRow = dtoWEBSystemParametersData.getDataRow(i);
      
      // Office.
      arrWEBSystemParametersData[0][i] = (String)hmDataRow.get(COLUMN_OFFICE);
      
      // Parameter name.
      arrWEBSystemParametersData[1][i] = ((String)hmDataRow.get(COLUMN_PARAM_NAME));
      
      // Parameter value.      
      arrWEBSystemParametersData[2][i] = (String)hmDataRow.get(COLUMN_PARM_VALUE);
    }
    
    return arrWEBSystemParametersData;
  }
  
 
  

  
  /**
   * Gets a tag and if requires, updates it.
   */
  private String updateTag(String sTag)
  {
    final String TAG_PREFIX = "CW_";
    final String TAG_23E = "23E";
    final String TAG_71B = "71B";
    final String TAG_72 = "72";
    final String TAG_73 = "73";
    
    final String TAG_BBI = "CW_BBI";
    
    if(   sTag.equals(TAG_23E) 
       || sTag.equals(TAG_71B)
       || sTag.equals(TAG_73) )
    {
      sTag = new StringBuffer(TAG_PREFIX).append(sTag).toString();
    }
    
    else if(sTag.equals(TAG_72))
    {
      sTag = TAG_BBI;
    }
    
    return sTag;
  }
  
   
 
  /**
   * Handles the request for getting the message fee types combo boxes.
   * Returns SimpleResponseDataComponent with HashMap of message fee types
   * combo boxes data.
   */
  @Expose
  public SimpleResponseDataComponent getMessageFeeTypesComboBoxes()
  {
    SimpleResponseDataComponent response = new SimpleResponseDataComponent();
    Feedback feedback;
    
    // Gets all system parameters data.
    DTODataHolder dtoMessageFeeTypesData = m_daoGeneralServices.getMessageFeeTypesData();
    feedback = dtoMessageFeeTypesData.getFeedBack();
    
    if(feedback.isSuccessful())
    {
      HashMap hmMessageFeeTypesComboBoxes = getMessageFeeTypesDataHM(dtoMessageFeeTypesData);
      response.setDataArray(new Object[]{hmMessageFeeTypesComboBoxes});
    }
    
    else
    {
      feedback.setFailure();
      response.setFeedback(feedback);
    }
        
    return response;
  }
  
  /**
   * Prepares the message fee types combo boxes data.
   * The prepared HashMap structure is: 
   *  Key - Office.
   *  Value - GlobalHtmlComboBox object.
   */
  private HashMap getMessageFeeTypesDataHM(DTODataHolder dtoMessageFeeTypesData)
  {
    final String COLUMN_OFFICE = "OFFICE";
    final String COLUMN_FEE_TYPE_CODE = "FEE_TYPE_CODE";
    final String COLUMN_FEE_TYPE_DESCRIPTION = "FEE_TYPE_DESCRIPTION";
    
    HashMap hmMessageFeeTypesComboBoxes = new HashMap();
    
    String sOffice, sFeeTypeCode, sFeeTypeCodeDescription;
    
    int iLength = dtoMessageFeeTypesData.getRowsNumber();
    
    for(int i=0; i<iLength; i++)
    {
      HashMap hmDataRow = dtoMessageFeeTypesData.getDataRow(i);
      
      sOffice = (String)hmDataRow.get(COLUMN_OFFICE);
      sFeeTypeCode = (String)hmDataRow.get(COLUMN_FEE_TYPE_CODE);
      sFeeTypeCodeDescription = (String)hmDataRow.get(COLUMN_FEE_TYPE_DESCRIPTION);
      
      updateSingleMessageFeeTypesComboBoxEntry(hmMessageFeeTypesComboBoxes, sOffice, sFeeTypeCode, sFeeTypeCodeDescription);
    }
    
    return hmMessageFeeTypesComboBoxes;
  }
  
  /**
   * Updates single message fee type entry.
   */
  private void updateSingleMessageFeeTypesComboBoxEntry(HashMap hmMessageFeeTypesComboBoxes, 
                                                        String sOffice, String sFeeTypeCode, 
                                                        String sFeeTypeCodeDescription)
  {
    GlobalHtmlComboBox globalHtmlComboBox = (GlobalHtmlComboBox)hmMessageFeeTypesComboBoxes.get(sOffice);
    
    if(globalHtmlComboBox == null)
    {
      globalHtmlComboBox = new GlobalHtmlComboBox();
      hmMessageFeeTypesComboBoxes.put(sOffice, globalHtmlComboBox);
    }
    
    globalHtmlComboBox.addEntry(sFeeTypeCode, sFeeTypeCodeDescription);
  }
  
  /**
   * Handles the request for getting the ofac fields data.
   * Returns SimpleResponseDataComponent with matrix of ofac tags data.
   */
  @Expose
  public SimpleResponseDataComponent getOfacTags()
  {
    SimpleResponseDataComponent response = new SimpleResponseDataComponent();
    Feedback feedback;
    
    // Gets all system parameters data.
    DTODataHolder dtoOfacTagsData = m_daoGeneralServices.getOfacTagsData();
    feedback = dtoOfacTagsData.getFeedBack();
    
    if(feedback.isSuccessful())
    {
      Object[][] arrOfacTagsData = getOfacTagsData(dtoOfacTagsData);
      response.setDataArray(new Object[]{arrOfacTagsData});
    }
    
    else
    {
      feedback.setFailure();
      response.setFeedback(feedback);
    }
    
    
    return response;
  }
  
  /**
   * Prepares the matrix of the ofac tags data.
   */
  private Object[][] getOfacTagsData(DTODataHolder dtoOfacTagsData)
  {
    final String COLUMN_TAG_FAMILY = "TAG_FAMILY";
    final String COLUMN_FAMILY_FIELDS = "FAMILY_FIELDS";

    int iLength = dtoOfacTagsData.getRowsNumber();
    
    Object[][] arrOfacTagsData = new Object[iLength][2];
    
    for(int i=0; i<iLength; i++)
    {
      HashMap hmDataRow = dtoOfacTagsData.getDataRow(i);
      
      // Tag family.
      arrOfacTagsData[i][0] = (String)hmDataRow.get(COLUMN_TAG_FAMILY);
      
      // Family fields.
      arrOfacTagsData[i][1] = (String)hmDataRow.get(COLUMN_FAMILY_FIELDS);
    }
    
    return arrOfacTagsData;
  }
  
  /**
   * Handles the request for getting the data for the queue list toolbar buttons.
   * Returns SimpleResponseDataComponent with ArrayList of data for the queue list 
   * toolbar buttons.
   */
  @Expose
  public SimpleResponseDataComponent getQListToolbarButtonsData()
  {
    
    SimpleResponseDataComponent response = new SimpleResponseDataComponent();
    Feedback feedback;
    
    // Gets all system parameters data.
    DTODataHolder dto = m_daoGeneralServices.getQListToolbarButtonsData();
    feedback = dto.getFeedBack();
    
    if(feedback.isSuccessful())
    {
      ArrayList alData = prepareQListToolbarButtonsData(dto);
      response.setDataArray(new Object[]{alData});
    }
    
    else
    {
      feedback.setFailure();
      response.setFeedback(feedback);
    }
        
    return response;
  }
  
  /**
   * Prepares the matrix of the ofac tags data.
   */
  private ArrayList prepareQListToolbarButtonsData(DTODataHolder dto)
  {
    final String COLUMN_ID = "ID";
    final String COLUMN_QUEUE_TYPE = "QUEUE_TYPE";
    final String COLUMN_GROUPING = "GROUPING";
    final String COLUMN_NO_WRAP = "NO_WRAP";
    final String COLUMN_IS_TOGGLED = "IS_TOGGLED";
    final String COLUMN_CLASS = "CLASS";
    final String COLUMN_ON_MOUSE_OVER = "ON_MOUSE_OVER";
    final String COLUMN_ON_MOUSE_OUT = "ON_MOUSE_OUT";
    final String COLUMN_ON_MOUSE_DOWN = "ON_MOUSE_DOWN";
    final String COLUMN_ON_MOUSE_UP = "ON_MOUSE_UP";
    final String COLUMN_IMAGE_ID = "IMAGE_ID";
    final String COLUMN_IMAGE_SRC = "IMAGE_SRC";
    final String COLUMN_IMAGE_ALT = "IMAGE_ALT";
    final String COLUMN_ADD_SEPARATOR_AFTER = "ADD_SEPARATOR_AFTER";

    int iLength = dto.getRowsNumber();
    
    ArrayList alData = new ArrayList();
    
    for(int i=0; i<iLength; i++)
    {
      HashMap hmDataRow = dto.getDataRow(i);
      
      String sID = (String)hmDataRow.get(COLUMN_ID);
      String sQueueType = (String)hmDataRow.get(COLUMN_QUEUE_TYPE);
      
      String sInQueueGrouping = (String)hmDataRow.get(COLUMN_GROUPING);
      boolean bInQueueGrouping = ServerConstants.ONE_VALUE.equals(sInQueueGrouping);

      String sNoWrap = (String)hmDataRow.get(COLUMN_NO_WRAP);
      boolean bNoWrap = ServerConstants.ONE_VALUE.equals(sNoWrap);

      String sIsToggled = (String)hmDataRow.get(COLUMN_IS_TOGGLED);
      boolean bIsToggled = ServerConstants.ONE_VALUE.equals(sIsToggled);
      
      String sClass = (String)hmDataRow.get(COLUMN_CLASS);
      String sOnMouseOver = (String)hmDataRow.get(COLUMN_ON_MOUSE_OVER);
      String sOnMouseOut = (String)hmDataRow.get(COLUMN_ON_MOUSE_OUT);
      String sOnMouseDown = (String)hmDataRow.get(COLUMN_ON_MOUSE_DOWN);
      String sOnMouseUp = (String)hmDataRow.get(COLUMN_ON_MOUSE_UP);
      String sImageID = (String)hmDataRow.get(COLUMN_IMAGE_ID);
      String sImageSource = (String)hmDataRow.get(COLUMN_IMAGE_SRC);
      String sImageAlt = (String)hmDataRow.get(COLUMN_IMAGE_ALT);
      String sAddSeparatorAfter = (String)hmDataRow.get(COLUMN_ADD_SEPARATOR_AFTER);

      ToolbarButton tb = new ToolbarButton(sID, sQueueType, 
                                           bInQueueGrouping, bNoWrap, bIsToggled,
                                           sClass,
                                           sOnMouseOver, sOnMouseOut, sOnMouseDown, sOnMouseUp,
                                           sImageID, sImageSource, sImageAlt, 
                                           sAddSeparatorAfter);
      
      alData.add(tb);
    }
    
    return alData;
  }
  
  /**
   * Persists all user preferences at the end of the session.
   * <br>
   * @param userPreferencesContainer {@link UserPreferencesContainer} containing new user preference data.
   * @return {@link SimpleResponseDataComponent} instance, containing only failure data as this task is peformed at logout stage
   * 
   * Note: as the user can be forced logout (i.e. websession info records exists yet the logged_in state in users = 0) 
   * the custom user authorization shall be performed explictly in this method  
   */
  @Expose
  public final SimpleResponseDataComponent saveUserPreferences( UserPreferencesContainer userPreferencesContainer) {
      final String USER_AUTH_FAILURE_TRACE_MSG = "Exiting saveUserPreferences. IsUserAuthorized() failed; Error Text is: " ;
      final String KEY_USER_ID = "USER_ID" ;
      final String QUEUE_EXPLORER_FILTER_KEY = "EN_frmQExplorer" ;
      final String LAYOUT_PERSISTENCE_KEY_SUFFIX = "_layout" ;
      final String ADDIOTNAL_DATA_PERSISTENCE_KEY_SUFFIX = "_adtnlData" ;
           
      String traceMsg = null ;
        
      SimpleResponseDataComponent response = new SimpleResponseDataComponent(); 
      Feedback feedback = new Feedback() ;   
      
      final WebSessionInfo webSessionInfo = Admin.getContextAdmin().getNSetWebSessionInfo() ; 

      //if the webSessionInfo is null (no active session), then this is an invalid request 
      if(webSessionInfo == null)  { 
    	  final String ERROR_MESSAGE = "User wasn't found.";
          final String USER_ERROR_MESSAGE = "Session violation";
    
          feedback.setFailure();
          feedback.setErrorCode(ERROR_CODE_SESSION_VIOLATION);
          feedback.setErrorText(ERROR_MESSAGE);
          feedback.setUserErrorText(USER_ERROR_MESSAGE);
          
          logger.error(ERROR_MESSAGE); 
          
          response.setFeedback(feedback) ;
          return response ; 
      }//EO if this is an unauthorized request 
      
      final String sUserId = webSessionInfo.getUserID() ; 
      
      //Step1: persist the queue data, (the open folders of the queue explorer),
      // if it is not null.  
      String sQueueData = userPreferencesContainer.getQueueData() ; 
      
      final String STEP1_TRACE_MSG = "Step1: persist the queue data if it is not null" ;
      traceMsg = STEP1_TRACE_MSG + " frames data: " + sQueueData + " for user " + sUserId ; 
      
      logger.trace(traceMsg) ;  

      if(sQueueData != null) { 
          m_daoGeneralServices.updateUserExtraData(QUEUE_EXPLORER_FILTER_KEY, null, null, sQueueData, sUserId) ; 
      }//EO if there was queue preference data
      
//        check the output (if the operation took place at all, and if it is a failure, return 
      if(feedback != null && !feedback.isSuccessful()){
          response =  this.configureErrorResponse(feedback.getErrorText(), feedback, false) ;
      }else { //EO if the queue data update was successful
      
          //step 2: persist the generic data preferences
          final String STEP2_TRACE_MSG = "Step 2: persist the generic data preferences" ;
          logger.trace(STEP2_TRACE_MSG) ;  
          
          feedback = this.persistQueueFilterPreferences(userPreferencesContainer.getQueueFilterPreferencesHolder(), sUserId) ;
          
          //check the output and if it is a failure, return 
          if(!feedback.isSuccessful()){
              response =  this.configureErrorResponse(feedback.getErrorText(), feedback, false) ;
          }else { 
              
              //step 3: persist all profile preferences
              final String STEP3_TRACE_MSG = "Step 3: persist all profile preferences" ;  
              logger.trace(STEP3_TRACE_MSG) ;  
              
              feedback = this.persistProfilesPreferences(userPreferencesContainer.profileUserPreferencesHolderIterator(), sUserId) ;
              
              String sOtherWindowsUserPreferences = userPreferencesContainer.getOtherWindowsUserPreferencesString() ;
              
              if(sOtherWindowsUserPreferences != null && feedback.isSuccessful()){
                  //Step 4: process and persist all other windows preferences                       
                  feedback = this.persistFramesUserPreferences(sOtherWindowsUserPreferences, sUserId) ;
                  
                  //check the feedback and if a failure handle 
                  if(!feedback.isSuccessful()) { 
                      response =  this.configureErrorResponse(feedback.getErrorText(), feedback, false) ;
                  }//EO if the other windows perferences persistence operation had failed 
              }else { 
                  response =  this.configureErrorResponse(feedback.getErrorText(), feedback, false) ;
              }//EO if the profile preferences persistence operation failed   
              
          }//EO else if the generic search persistence had succeeded
      }//if there was queue preference peristence was successful
           
      return response  ; 
  }//EOM
  
  
  @Expose
  @AuthorizeUser(returnWebSessionInfo=true)
  public final SimpleResponseDataComponent cacheUserQueuePreferences(final UserPreferencesContainer userPreferencesContainer){ 
	
	  final WebSessionInfo webSessionInfo = Admin.getContextAdmin().getWebSessionInfo() ; 
            
      SimpleResponseDataComponent response = new SimpleResponseDataComponent(); 
      Feedback feedback = new Feedback() ;   
      
      
      final QueueFilterPreferencesHolder queueFilterPreferenceHolder =
    	  							userPreferencesContainer.getQueueFilterPreferencesHolder() ;
      
      String sQueueName = queueFilterPreferenceHolder.getRulename() ;
      
      final  String sUserId = queueFilterPreferenceHolder.getQPrefAction().equals("DEFINE_DEFAULT_Q_PREF") ? "********" : webSessionInfo.getUserID() ;  
      final  Boolean bToBeDeleted = queueFilterPreferenceHolder.getQPrefAction().equals("RESTORE_DEFAULT_Q_PREF") ? true : false;  
      
      // Determines the rule type ID.
      String sRuleTypeID;
     
      if(sQueueName.indexOf("HISTORY") != -1)
      {
        sRuleTypeID = RULE_TYPE_ID_HISTORY_SEARCH;
      }
      else if(sQueueName.indexOf("TEMPLATE_SRCH") != -1)
      {
        sRuleTypeID = RULE_TYPE_ID_TEMPLATE_SEARCH;
      }       
      else
      {
       sRuleTypeID = RULE_TYPE_ID_TRANSACTION_SEARCH;
      }
      
      //retrieve the queue preferences object from cache for the user id, rule name (queue name) 
      //and rule type id 999 (search selection) 
      //if there were no preferences, create a new instance 
      //attempt to retrieve the queue preferences from the cache  

      //String that ends with date (format equal to YYYY-MM-DD)
      final Pattern pDatePattern = Pattern.compile(PATTERN_FOR_STRING_ENDS_WITH_DATE);
      Matcher mDateMatcher = pDatePattern.matcher(sQueueName);
      if (mDateMatcher.matches() || sQueueName.indexOf(QUEUE_NAME_WITH_DASH_PROCESSING_DATE) > -1)
      {
         int iLength = (sQueueName.indexOf(QUEUE_NAME_WITH_DASH_PROCESSING_DATE) > -1) ?  16 : 13;
         sQueueName =  sQueueName.substring(0, sQueueName.length()-iLength); 
      }

     QueuePreferences queuePreferences = CacheKeys.QueuePreferencesKey.getSingle(sRuleTypeID, sQueueName, sUserId) ; 
      
  	 if(queuePreferences == null) 
  	 {
  		 queuePreferences = new QueuePreferences(sRuleTypeID, sQueueName, sUserId) ; 
  		//cache the new preferences 
  		 try{ 
  			CacheServiceInterface.eINSTANCE.putSingle(CacheKeys.QueuePreferencesKey, queuePreferences) ;
  		 }catch(Exception e) { 
  			return this.configureErrorResponse(e.getMessage(), feedback, true) ; 
  		 }//EO catch block
  		 
  	 }//EO if these are new preferences 
  		 		 
  	 //set the additional data (message type etc.) 
  	 queuePreferences.setAdditionalData(queueFilterPreferenceHolder.getAdditionalData()) ; 
     queuePreferences.setToBeDeleted(bToBeDeleted);
  	 
  	   	 
  	 //parse the column preferences 
  	 final String sColumnPreferences = queueFilterPreferenceHolder.getColumnPrefs() ;
  	 this.cacheColumnPreferences(sColumnPreferences, queuePreferences) ; 

  	 //QC : 290 Saving column settings 
     this.saveUserPreferences(userPreferencesContainer);
  	 
     return response ; 
  }//EOM 
  
  /**
   * process the filter string if exists and after retrieving all column metadata from the cache 
   * persists the entries into the user_queue_preferences table
   * @param sColumnPreferences
   * @param sUserId
   */
  private void cacheColumnPreferences(final String sColumnPreferences, final QueuePreferences queuePreferences) { 
      
      
      
      //if there are no column preferences warn and return 
      if(GlobalUtils.isNullOrEmpty(sColumnPreferences)) { 
    	  logger.warn("Failed to cache column preferences due to: Empty column preferences."); 
    	  return ;
      }//EO if there were no column preferences 
      
      //break the string in the format of: 
      //MIF.CURRENCY~100~0~0,MIF.MOP~199~0~0,MIF.AMOUNT~100~0~0,MIF.ROF_STATUS~100~0~0,MIF.REFERENCE~100~0~0,MIF.TIME~100~0~0,MIF.VALUE_DATE~100~0~0,MIF.DIRECTION~100~0~0,MIF.MID~100~0~0.
      //with regex and retrieve the culumn, field name and width (first number) and store them
      final String columnPrefsRegex = "(.*?)~(-{0,1}\\d+)~(-{0,1}\\d+)~(-{0,1}\\d+),{0,1}" ;
      //final String AVAILABLE_FOR_GROUING_KEY = "AVAILABLEFORGROUPING" ;
      
      final Pattern columnPrefsPattern = Pattern.compile(columnPrefsRegex) ;
      Matcher matcher = columnPrefsPattern.matcher(sColumnPreferences) ;
                        
      int iOrderCounter = 0 ;
      
      final List<String> listColumnNames = new ArrayList<String>() ; 
      final StringBuilder sbGroupOrder = new StringBuilder(), sbSortColumns = new StringBuilder() , 
      sbColumnNames = new StringBuilder(), sbColumnWidths = new StringBuilder() ; 
      				
            
      while(matcher.find()) { 
    	  listColumnNames.add(matcher.group(1)) ; 
    	  sbColumnNames.append(matcher.group(1)).append(",") ;
    	  
    	  sbColumnWidths.append(matcher.group(2)).append(",") ;
    	  
    	  sbSortColumns.append(matcher.group(3)).append(",") ; 
    	  sbGroupOrder.append(matcher.group(4)).append(",") ;
      }//EO while 
      
      sbSortColumns.deleteCharAt(sbSortColumns.length()-1) ;
      sbGroupOrder.deleteCharAt(sbGroupOrder.length()-1) ; 
      sbColumnNames.deleteCharAt(sbColumnNames.length()-1) ;
      sbColumnWidths.deleteCharAt(sbColumnWidths.length()-1) ;
      
      //cache the data 
      queuePreferences.setColumnNames(listColumnNames, sbColumnNames.toString()) ; 
      queuePreferences.setSortByFields(sbSortColumns.toString()) ; 
      queuePreferences.setColumnsSize(sbColumnWidths.toString()) ; 
       
      //qlist_todo: group order is still not cached 
      
  }//EOM
  
  /**
   * 
   * May 27, 2008
   * guys
   * 
   * <p><b>pre-condition:</p></b> All Queue Preferences entries require persistence 
   *
   * @param feedback
   * @return
   */
  private final Feedback persistQueuePrefernces(final Feedback feedback) { 
	  
	  
	  //Note: the iteration on the cache entries is not synchronized (i.e. 
	  //elements might be modified during the iteration 
	  this.m_daoGeneralServices.persistQueuePreferences(CacheServiceInterface.eINSTANCE.getCacheEntries(CacheKeys.QueuePreferencesKey), null) ; 
	  CacheServiceInterface.eINSTANCE.applyChanges(
              new String[] { CacheKeys.QueuePreferencesKey.name()}, null);
	  return new Feedback() ; 
  }//EOM 
   
  /**
   * Inserts or updates the user preferences entry in USERS_EXTRA_DATA for the given user and profileId. 
   * @param profileUserPreferencesHoldersIterator iterator over a list of {link ProfileUserPreferencesHolder} instances 
   * @param sUserId User Id against which to store the user preferences  
   * @param sSessionId Current User Session Id 
   * @return {link Feedback} instance 
   */
  private final Feedback persistProfilesPreferences( Iterator profileUserPreferencesHoldersIterator, String sUserId) {
      Feedback feedback = null ; 
            
      //step 1: iterate over the profile user prefences 
      final String STEP1_TRACE_MSG = "Step 1: iterate over the profile user prefences" ; 
      logger.trace(STEP1_TRACE_MSG) ; 
      
      ProfileUserPreferencesHolder profileUserPreferencesHolder = null ;
      
      String sProfilePrefAlias, sAdditionalData, sLayout, sFiltersString, 
             sSelectListColumnNames, sSelectListSortingOptions, sColumnWidths = null ; 
      
      while(profileUserPreferencesHoldersIterator.hasNext()) { 
          profileUserPreferencesHolder  = (ProfileUserPreferencesHolder) profileUserPreferencesHoldersIterator.next() ;
          
          //Step 2:persist the entry
          sProfilePrefAlias = profileUserPreferencesHolder.getPreferenceAlias() ; 
          sAdditionalData =   profileUserPreferencesHolder.getAdditionalData() ;  
          sLayout =           profileUserPreferencesHolder.getLayoutData() ; 
          sFiltersString = profileUserPreferencesHolder.getFilterElementsString() ;
          sSelectListColumnNames = profileUserPreferencesHolder.getColumnNamesString() ;
          sColumnWidths = profileUserPreferencesHolder.getColumnWidths() ;
          sSelectListSortingOptions = profileUserPreferencesHolder.getTableDataSortingOptions() ;
 
          
          this.m_daoGeneralServices.updateUserExtraData(sProfilePrefAlias, sLayout, 
                  sFiltersString, sAdditionalData,
                  sSelectListColumnNames, sColumnWidths, sSelectListSortingOptions, 
                  sUserId) ; 
          
      }//EO while there are more profile preference elements  
            
      return (feedback == null ? new Feedback(): feedback) ;
  }//EOM
 
  /**
   * Used for persisting user Preferences for Generic Search and Advanced filter Screens 
   * @param filterElementsContainer immutable java-bean style container housing the generic search user preferences  
   * @return {@link Feedback} instances containing the persistence results 
   */
  private Feedback persistQueueFilterPreferences(QueueFilterPreferencesHolder queueFilterPreferenceHolder, String sUserId)
  { 
      String traceMsg = null ;
      
      //String sFilterMethod = queueFilterPreferenceHolder.getFilterMethod();
      //String sRulename = queueFilterPreferenceHolder.getRulename() ;
      
      //String sColumnPreferences = queueFilterPreferenceHolder.getColumnPrefs() ;       
     // FilterElementsContainer filterElementsContainer = queueFilterPreferenceHolder.getFilterElementsContainer() ; 
      //FilterElement[] arrFilterElements = filterElementsContainer.getFilterElements() ;
      //Feedback feedback = persistQueueFilterPreferences(sFilterMethod, sRulename, arrFilterElements, sColumnPreferences, sUserId);
      
      //persist all QueuePreferences JPA objects using batch 
      Feedback feedback = this.persistQueuePrefernces(null) ;                
                
      //Check the feedback and if a success, update (or insert the additional data and the Layout position
      final String STEP3_TRACE_MSG = "Step 3: check the feedback and if a success, update (or insert the additional data and the Layout position" ; 
      traceMsg =  STEP3_TRACE_MSG +  "layout data: " + queueFilterPreferenceHolder.getLayoutData() + " and additional data: " +  queueFilterPreferenceHolder.getAdditionalData() ;     
      logger.trace(traceMsg) ; 
       
      String sLayout = queueFilterPreferenceHolder.getLayoutData() ; 
      String sAdditionalData = queueFilterPreferenceHolder.getAdditionalData() ;
      
      if(feedback.isSuccessful() && (sLayout != null && !sLayout.equals(GlobalConstants.EMPTY_STRING)) || (!sAdditionalData.equals(GlobalConstants.EMPTY_STRING)) )  {
          
          feedback = this.m_daoGeneralServices.updateUserExtraData(queueFilterPreferenceHolder.getPreferenceAlias(), sLayout, null, sAdditionalData, sUserId) ;
          
          //check the feedback and configure if a  failure 
          if(!feedback.isSuccessful())  {
              this.configureErrorResponse(feedback.getErrorText(), feedback, false ) ;
          }//EO if the layout persistence operation had failed 
          
      }else { //EO if the filter elements persistence operation was a success 
          this.configureErrorResponse(feedback.getErrorText(), feedback, false) ;
      }//EO if the filter elements persistence operation was a failure      
      
      return feedback;
  }//EOM

  

  private String arrayToString(String[] arr , String delimiter) { 
      if(delimiter == null) delimiter = GlobalConstants.EMPTY_STRING ;
      
      StringBuffer sbBuffer = new StringBuffer() ;
      
      int iLength = arr.length ; 
      for(int i=0; i < iLength; i++){ 
          sbBuffer.append(arr[i]) ; 
          
          if(i < iLength -1) sbBuffer.append(delimiter) ;
      }//EO while there are more elemets to concatenate
      
      return sbBuffer.toString() ;
  }//EOM
  
  private boolean isRangeOperator(String sOperator) { 
      final String BETWEEN_STRING = "BETWEEN" ;
      final String BT_STRING = "BT" ;
      final String NOT_BETWEEN_STRING = "NOT BETWEEN" ; 
      final String IN_STRING = "IN" ; 
      
     return sOperator.equals(BETWEEN_STRING) || sOperator.equals(NOT_BETWEEN_STRING) || sOperator.equals(IN_STRING) || sOperator.equals(BT_STRING); 
  }//EOM
  
  
  /**
   * splits the frames data user preferences with the @= delimiters and persists each tuple 
   * @param sFramesUserPreferences
   * @return
   */
  private Feedback persistFramesUserPreferences(String sFramesUserPreferences, String sUserId) { 
      
      Feedback feedback = null ; 
      
      final String regex = "(?:@@){0,1}(.*?)=(.*?)(?:@@)" ;

      Pattern pattern = Pattern.compile(regex) ;
      Matcher matcher = pattern.matcher(sFramesUserPreferences) ;
      
      String sFrameAlias, sPreferenceValue = null ;
      
      while(matcher.find()) { 
          
          sFrameAlias = matcher.group(1); 
          sPreferenceValue = matcher.group(2) ; 
          
          if(sFrameAlias == null || sPreferenceValue == null) continue ; 
          
          feedback = this.m_daoGeneralServices.updateUserExtraData(sFrameAlias, sPreferenceValue,null, null, sUserId) ;
          
          //if the feedback was - failure, stop and return 
          if(!feedback.isSuccessful()) break ; 
      }//EO while there are more elements 
      
      return (feedback == null ? new Feedback() : feedback ); 
  }//EOM

  
  /**
   * Utility method factorising the search criteria appendage to the query string.
   * 
   * @param queryBuffer Query string  body.  
   * @param sSearchOption Provided option according to which some elements of the query are added or ignored. 
   * @param sExpectedOption Expected option value according to which some elements of the query are added or ignored.
   * @param sFilterFieldName The '_____ like' part or the filter  
   * @param sFilterString    The '[filterFieldName] like '_____' ' part or the filter
   * @return The appended Query String 
   */
  private final StringBuffer appendFilter(StringBuffer queryBuffer, String sSearchOption, String sExpectedOption, String sFilterFieldName, String sFilterString) { 
      
      final String QUERY_FILTER_FORMAT = "{0} LIKE ''{1}{2}%'' AND " ;
      final String PERCENT = "%" ;
      final String EMPTY_CHAR = "" ;
      final String[] arrForamtParams = new String[3] ;
      
      arrForamtParams[0] = sFilterFieldName ; 
      arrForamtParams[2] = sFilterString ; 
 
      String sExtraFilterChar = (sSearchOption.equals(sExpectedOption) ? PERCENT :  EMPTY_CHAR) ;  
      
      arrForamtParams[1] = sExtraFilterChar ; 
      
      //create the filter 
      String sCompleteFilterString = MessageFormat.format(QUERY_FILTER_FORMAT, (Object[]) arrForamtParams) ;
          
      return queryBuffer.append(sCompleteFilterString) ;
  }//EOM
  
  /**
   * Handles the request for getting the column chooser fields.
   * @param admin  {@link Admin} instance containing the requesting user credentials.
   * @param sQueueName -the queue name
   * @param sQueueMT 
   * @return returns the available and selected chooser column fields.
   * 
   * @Input(type=1)
   * 
   */
  @Expose
  @AuthorizeUser(returnWebSessionInfo=true) 
  public SimpleResponseDataComponent getColumnSettingsFields(String sQueueName, String sQueueMT)
  {
	final String COLUMNNAME="COLUMNNAME";
	final String ALIASNAME="ALIASNAME";
	final String USER_AUTH_FAILURE_TRACE_MSG = "Exiting getColumnSettingsFields. IsUserAuthorized() failed; Error Text is: " ;
	
    String traceMsg = null ;
    final WebSessionInfo webSessionInfo = Admin.getContextAdmin().getWebSessionInfo() ; 
    SimpleResponseDataComponent response = new SimpleResponseDataComponent(); 
    Feedback feedback = new Feedback() ;  
    
    String sUserId = ServerConstants.EMPTY_STRING;
    
        //String that ends with date (format equal to YYYY-MM-DD)
        final Pattern pDatePattern = Pattern.compile(PATTERN_FOR_STRING_ENDS_WITH_DATE);
        Matcher mDateMatcher = pDatePattern.matcher(sQueueName);
        if (mDateMatcher.matches() || sQueueName.indexOf("-------") > -1)
        {
           int iLength = (sQueueName.indexOf("-------") > -1) ?  16 : 13;
           sQueueName =  sQueueName.substring(0, sQueueName.length()-iLength); 
        }
    
	 sUserId = webSessionInfo.getUserID() ; 
		traceMsg = "Getting Column Chooser Fields for userId = " + sUserId+ ", in Queue = " + sQueueName;
		logger.trace(traceMsg) ; 
		
		boolean bLowValue = sQueueMT.equals("L");
		DTODataHolder dtoColumnSettingsAvailableFields = m_daoGeneralServices.getColumnSettingsAvailableFields(sUserId, sQueueName,bLowValue);
		feedback = dtoColumnSettingsAvailableFields.getFeedBack();
		//in case one of the query failed all data failed and error will be sent.
		if (feedback.isSuccessful())
		{
		  DTODataHolder dtoColumnSettingsSelectedFields = m_daoGeneralServices.getColumnSettingsSelectedFields(sUserId, sQueueName,bLowValue);
		  feedback = dtoColumnSettingsSelectedFields.getFeedBack();
		  if(feedback.isSuccessful())
		  {
			   StringBuffer sbAvailableFields=new StringBuffer();
			   StringBuffer sbSelectedFields=new StringBuffer();
			   String sColumnName=null;
			   String sAliasName=null;
			   int iResultCount=dtoColumnSettingsAvailableFields.getRowsNumber();
			   for (int iRowNum = 0; iRowNum < iResultCount; iRowNum++)
			   {
				 sColumnName=dtoColumnSettingsAvailableFields.getColumnDataByRow(COLUMNNAME, iRowNum);
				 sAliasName=dtoColumnSettingsAvailableFields.getColumnDataByRow(ALIASNAME, iRowNum);
					 if(sbAvailableFields.length()>0)
					 {
						 sbAvailableFields.append(GlobalConstants.COMMA);
					 }
					 sbAvailableFields.append(sColumnName);
					 sbAvailableFields.append(GlobalConstants.TILDA);
					 sbAvailableFields.append(sAliasName);
			   }
			   iResultCount=dtoColumnSettingsSelectedFields.getRowsNumber();
			   for (int iRowNum = 0; iRowNum < iResultCount; iRowNum++)
			   {
				 sColumnName=dtoColumnSettingsSelectedFields.getColumnDataByRow(COLUMNNAME, iRowNum);
				 sAliasName=dtoColumnSettingsSelectedFields.getColumnDataByRow(ALIASNAME, iRowNum);
					 if(sbSelectedFields.length()>0)
					 {
						 sbSelectedFields.append(GlobalConstants.COMMA);
					 }
					 sbSelectedFields.append(sColumnName);
					 sbSelectedFields.append(GlobalConstants.TILDA);
					 sbSelectedFields.append(sAliasName);
			   }
			   
				response.setDataArray(new String[]{sbAvailableFields.toString(),sbSelectedFields.toString()});
		  }
		  else
		  {
			  feedback.setFailure();
			  response.setFeedback(feedback);
		  }
		}
		else
		{
			feedback.setFailure();
			response.setFeedback(feedback);
		}
    
    return response;
  }
  
	/** 
	 * Handles the request for getting message tables data. 
	 * Returns SimpleResponseDataComponent with a HashMap in which:
	 * Key - Table Name (equivalent to MESSAGE_TABLES.TABLE_NAME column).
	 * Value	- Object[3] in which: Index 0 - MessageTableBasicData object.
	 * Index 1 - MessageTableHeaderData[] object.
	 * Index 2 - MessageTableCellData[] object.
	 */
  @Expose
  public SimpleResponseDataComponent getMessageTables()
  {
    SimpleResponseDataComponent response = new SimpleResponseDataComponent();
    
    // Gets all Message tables data.
    DTODataHolder dtoMessageTables = m_daoGeneralServices.getMessageTables();
    Feedback feedback = dtoMessageTables.getFeedBack();
    
    if(feedback.isSuccessful())
    {
    	// Gets all Message tables fields data.
        DTODataHolder dtoMessageTableFields = m_daoGeneralServices.getMessageTableFields();
        feedback = dtoMessageTableFields.getFeedBack();
        if(feedback.isSuccessful())
        {
        	HashMap hmMessageTables = getMessageTablesHM(dtoMessageTables, dtoMessageTableFields);
        	response.setDataArray(new Object[]{hmMessageTables});
        }
        else
        {
          feedback.setFailure();
          response.setFeedback(feedback);
        }
    }
    else
    {
      feedback.setFailure();
      response.setFeedback(feedback);
    }
    
    return response;
  }
  
  /**
   * Prepares all Message Tables HM data.
   * @param dtoMessageTables - DTODataHolder of mesasge tables
   * @param dtoMessageTableFields - DTODataHolder of mesasge tables fields
   * @return HashMap of: Key - Table ID (MESSAGE_TABLES.TABLE_ID column).
						Value - Object[3] in which: Index 0 - MessageTableBasicData object.
						          					Index 1 - MessageTableHeaderData[] object.
							                  		Index 2 - MessageTableCellData[] object.
   */
  private HashMap getMessageTablesHM(DTODataHolder dtoMessageTables, DTODataHolder dtoMessageTableFields)
  {
	  HashMap hmMessageTables = new HashMap();
	  HashMap<String, String[]> hmMessageTableTypeToColumnsOrder = new HashMap< String, String[]>();

	  String sTableName, sScreenAlias, sCellSpacing, sCellPadding, sBorder, 
			 sOnKeyDown, sOnMouseDown, sTrStyle, sAllowPaging, sTableTagName;
      int[] arrIndex = new int[]{0};	  
	  int iLength = dtoMessageTables.getRowsNumber();
	  for(int i=0; i<iLength; i++)
	  {
		  HashMap hmDataRow = dtoMessageTables.getDataRow(i);
		  
		  sTableName = (String)hmDataRow.get(TABLE_NAME);
		  sScreenAlias = (String)hmDataRow.get(SCREEN_ALIAS);
		  sCellSpacing = (String)hmDataRow.get(CELL_SPACING);
		  sCellPadding = (String)hmDataRow.get(CELL_PADDING);
		  sBorder = (String)hmDataRow.get(BORDER);
		  sOnKeyDown = (String)hmDataRow.get(ON_KEY_DOWN);
		  sOnMouseDown = (String)hmDataRow.get(ON_MOUSE_DOWN);
		  sTrStyle = (String)hmDataRow.get(TR_STYLE);
		  sAllowPaging = (String)hmDataRow.get(ALLOW_PAGING);
          sTableTagName = (String)hmDataRow.get(TABLE_TAG_NAME);
          
          boolean[] arrFloatingTR = new boolean[]{false};
		  Object[] messageFields= getMessageTableFields(dtoMessageTableFields, sTableName, arrIndex, arrFloatingTR);

		  MessageTableBasicData messageTableBasicData = 
			  new MessageTableBasicData(sTableName, sScreenAlias, sCellSpacing, sCellPadding, sBorder, 
										sOnKeyDown, sOnMouseDown, arrFloatingTR[0], sTrStyle, sAllowPaging);
		  
		  Object[] messageTableData = new Object[]{messageTableBasicData, messageFields[0], messageFields[1]};
		  hmMessageTables.put(sTableName, messageTableData);
		  
		  hmMessageTableTypeToColumnsOrder.put(sTableTagName, (String[])messageFields[2]);
	  }
    
	  ASCacheFactory.getInstance().setMessageTableTypeToColumnsOrder(hmMessageTableTypeToColumnsOrder);
	  
	  return hmMessageTables;
  }
  
  /**
   * Prepares one Message Table data (all header & data columns for one row).
   * @param dtoMessageTableFields - dto of all message table fields data
   * @param sTableName - Table Name 
   * @param arrIndex - index to start running on dto 
   * @return Object[3] - in which: 	Index 0 - MessageTableHeaderData[] object.
	                             	Index 1 - MessageTableCellData[] object.
	                             	Index 2 - String[] object for Columns Order.
   */
  private Object[] getMessageTableFields(DTODataHolder dtoMessageTableFields, String sTableName, int[] arrIndex, boolean[] arrFloatingTR)
  {
	  String sCurrTableName, sMasterTable, sID, sIsHidden, sStyle, sIsFloating, sFT, sAlias, sOrder;
	  String sInnerElemID, sInnerElem, sInnerInputType, sInnerElemFT, sInnerElemStyle, sInnerElemDisabled, 
	  		 sInnerElemOnKeyPress, sInnerElemOnChange, sComboID, sExtraAttributes;
	  
	  ArrayList<MessageTableHeaderData> alMessageTableHeaderData = new ArrayList<MessageTableHeaderData>();
	  ArrayList<MessageTableCellData> alMessageTableCellData = new ArrayList<MessageTableCellData>();
	  ArrayList<String> alColumnsOrder = new ArrayList<String>();
	  
	  int iColumnsLen = dtoMessageTableFields.getRowsNumber();
	  for(int i = arrIndex[0]; i<iColumnsLen; i++)
	  {
		  HashMap hmDataRow = dtoMessageTableFields.getDataRow(i);
		  
		  //Header cell data:
		  sCurrTableName = (String)hmDataRow.get(TABLE_NAME);
		  if(!sCurrTableName.equalsIgnoreCase(sTableName))
		  {
			  arrIndex[0] = i;
			  break;
		  }
		  
		  sMasterTable = (String)hmDataRow.get(MASTER_TABLE);
		  sID = (String)hmDataRow.get(TH_ID);
		  sIsHidden = (String)hmDataRow.get(TH_HIDDEN);
		  sIsFloating = (String)hmDataRow.get(TR_IS_FLOATING);
		  sFT = (String)hmDataRow.get(TH_FORMAT);
		  sAlias = (String)hmDataRow.get(TH_ALIAS);
		  sOrder = (String)hmDataRow.get(TH_ORDER);
		  
		  if(!sIsFloating.equals(GlobalConstants.ZERO_VALUE)) //it's floating row
		  {
			  arrFloatingTR[0] = true;
		  }
		  else
		  {
			  MessageTableHeaderData messageTableHeaderData = 
				  new MessageTableHeaderData(sTableName, sID, sIsHidden, sIsFloating, sFT, sAlias, sOrder);
			  
			  alMessageTableHeaderData.add(messageTableHeaderData);
		  }
		  
		  // Cell data:
		  sInnerElem = (String)hmDataRow.get(TD_INNER_ELEMENT);
		  sInnerElemID = (String)hmDataRow.get(TD_ID);
		  sInnerInputType = (String)hmDataRow.get(TD_INNER_INPUT_TYPE);
		  sInnerElemFT = (String)hmDataRow.get(TD_INNER_ELEMENT_TYPE);
		  sInnerElemStyle = (String)hmDataRow.get(TD_INNER_ELEMENT_STYLE);
		  sInnerElemDisabled = (String)hmDataRow.get(TD_INNER_ELEMENT_DISABLED);
		  sInnerElemOnKeyPress = (String)hmDataRow.get(TD_INNER_ELEMENT_ON_KEYPRESS);
		  sInnerElemOnChange = (String)hmDataRow.get(TD_INNER_ELEMENT_ON_CHANGE);
		  sComboID = (String)hmDataRow.get(TD_COMBO_ID);
		  sExtraAttributes = (String)hmDataRow.get(TD_EXTRA_ATTRIBUTES);
		  
		  MessageTableCellData messageTableCellData = 
			  new MessageTableCellData(sTableName, sID, sIsHidden, sFT, sInnerElem, sInnerElemID, 
					  sInnerInputType, sInnerElemFT, sInnerElemStyle, sInnerElemDisabled, 
					  sInnerElemOnKeyPress, sInnerElemOnChange, sComboID, sExtraAttributes);
		  
		  alMessageTableCellData.add(messageTableCellData);
		  
		  alColumnsOrder.add(sID);
	  }
	  
	  //convert ArrayLists to arrays:
	  int iLen = alMessageTableHeaderData.size();
	  MessageTableHeaderData[] arrMessageTableHeaderData = new MessageTableHeaderData[iLen];
	  for(int i=0; i<iLen; i++)
	  {
		  arrMessageTableHeaderData[i] = alMessageTableHeaderData.get(i);
	  }
	  
	  iLen = alMessageTableCellData.size();
	  MessageTableCellData[] arrMessageTableCellData = new MessageTableCellData[iLen];
	  for(int i=0; i<iLen; i++)
	  {
		  arrMessageTableCellData[i] = alMessageTableCellData.get(i);
	  }

	  Object[] messageTableData = new Object[]{arrMessageTableHeaderData, arrMessageTableCellData, GlobalUtils.getStringArrayFromObjectArray(alColumnsOrder.toArray())};
	  
	  return messageTableData;
  }
  
  @Expose
  @AuthorizeUser
  public SimpleResponseDataComponent reportClientsideError(final String sErrorCode, @Input(skip=true) final String[] arrErrorParams){ 
  	String sFormattedErorrMsg = 
  			ErrorAuditUtils.getInstance().loadErrorAuditText(Long.parseLong(sErrorCode), (Object[])arrErrorParams) ;
  	
  	sFormattedErorrMsg = (sFormattedErorrMsg != null ? sFormattedErorrMsg : sErrorCode + " was'nt found") ;
  	    	
  	//log the error 
  	logger.error("Clientside error reported: {}", sFormattedErorrMsg); 
  	    	
  	return new SimpleResponseDataComponent(new Object[]{ sFormattedErorrMsg }) ; 
  }
}
