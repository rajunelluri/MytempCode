package backend.core.module.genservices.ejb;

import javax.ejb.Stateless;
import backend.core.SuperSLSB;
import com.fundtech.core.security.Admin;
import backend.businessobject.proxies.interceptors.InterceptorSetType;
import backend.core.module.genservices.businessobjects.BOGeneralServices;
import backend.core.module.genservices.ejbinterfaces.GeneralServicesLocal;
import backend.core.module.genservices.ejbinterfaces.GeneralServices;

@Stateless
public class GeneralServicesBean extends SuperSLSB<GeneralServices> implements GeneralServicesLocal, GeneralServices{
	
	public GeneralServicesBean() { super(backend.core.module.genservices.businessobjects.BOGeneralServices.class, InterceptorSetType.Complete) ; }//EOM
	
	
	/** 
	 * Handles the request for getting the application combo boxes. 
	 * Returns SimpleResponseDataComponent with Object[2] in which:
	 * Index 0: matrix of REGULAR combo boxes data.
	 * Index 1: matrix of TABLE TYPE combo boxes data.
	 */
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent getComboBoxes(final Admin admin ) {
		return this.m_bo.getComboBoxes(admin ) ;
	}//EOM

	/** 
	 * Handles the request for getting the LTERM/VTERM options. 
	 * Returns SimpleResponseDataComponent with Object[3] in which:
	 * Index 0: HashMap of LTERM options data.
	 * Index 1: HashMap of LTERM groups options data.
	 * Index 2: HashMap of VTERM options data.
	 */
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent getLTermVTermOptions(final Admin admin ) {
		return this.m_bo.getLTermVTermOptions(admin ) ;
	}//EOM

	/** 
	 * Handles the request for getting the ABA options. 
	 * Returns SimpleResponseDataComponent with a HashMap in which:
	 * Key - Office
	 * Value - HashMap in which: Key - MOP.
	 * Value - GlobalBasicComboBox object with ABA options for this MOP.
	 */
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent getABAs(final Admin admin ) {
		return this.m_bo.getABAs(admin ) ;
	}//EOM

	/** 
	 * Handles the request for getting the holidays data. 
	 * Returns SimpleResponseDataComponent with matrix of all holidays data.
	 */
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent getHolidays(final Admin admin ) {
		return this.m_bo.getHolidays(admin ) ;
	}//EOM

	/** 
	 * Handles the request for getting the relationships data.
	 * Returns SimpleResponseDataComponent with HashMap in which:
	 * Key - List type, (TMS_LIST_RELATION.LIST_TP column).
	 * Value - HashMap in which:
	 * Key - 'MT + MST' (no slash separating between),
	 * which is equivalent to the TMS_LIST_RELATION.ITEM_NM column.
	 * Value - ArrayList of related number types for the related list type.
	 * (e.g. TMS_LIST_RELATION.RELATED_LIST_TP is 'BFC',
	 * and we'll have an ArrayList of TMS_LIST_RELATION.ITEM_NM columns).
	 */
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent getRelationships(final Admin admin ) {
		return this.m_bo.getRelationships(admin ) ;
	}//EOM

	/** 
	 * Handles the request for getting the system parameters data.
	 * Returns SimpleResponseDataComponent with a matrix of system parameters data 
	 * taken from SYST_PAR table, according the required parameters in the passed 
	 * 'arrBasicRequiredSystemParameters' parameter.
	 */
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent getWEBSystemParameters(final Admin admin, java.lang.Object[] arrBasicRequiredSystemParameters ) {
		return this.m_bo.getWEBSystemParameters(admin, arrBasicRequiredSystemParameters ) ;
	}//EOM


	/** 
	 * Handles the request for getting the message fee types combo boxes.
	 * Returns SimpleResponseDataComponent with HashMap of message fee types
	 * combo boxes data.
	 */
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent getMessageFeeTypesComboBoxes(final Admin admin ) {
		return this.m_bo.getMessageFeeTypesComboBoxes(admin ) ;
	}//EOM

	/** 
	 * Handles the request for getting the ofac fields data.
	 * Returns SimpleResponseDataComponent with matrix of ofac tags data.
	 */
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent getOfacTags(final Admin admin ) {
		return this.m_bo.getOfacTags(admin ) ;
	}//EOM

	/** 
	 * Handles the request for getting the data for the queue list toolbar buttons.
	 * Returns SimpleResponseDataComponent with ArrayList of data for the queue list 
	 * toolbar buttons.
	 */
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent getQListToolbarButtonsData(final Admin admin ) {
		return this.m_bo.getQListToolbarButtonsData(admin ) ;
	}//EOM

	/** 
	 * Persists all user preferences at the end of the session.
	 * <br>
	 * @param userPreferencesContainer {@link UserPreferencesContainer} containing new user preference data.
	 * @return {@link SimpleResponseDataComponent} instance, containing only failure data as this task is peformed at logout stage
	 * Note: as the user can be forced logout (i.e. websession info records exists yet the logged_in state in users = 0) 
	 * the custom user authorization shall be performed explictly in this method  
	 */
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent saveUserPreferences(final Admin admin, com.fundtech.core.general.prefs.UserPreferencesContainer userPreferencesContainer ) {
		return this.m_bo.saveUserPreferences(admin, userPreferencesContainer ) ;
	}//EOM

	public com.fundtech.datacomponent.response.SimpleResponseDataComponent cacheUserQueuePreferences(final Admin admin, com.fundtech.core.general.prefs.UserPreferencesContainer userPreferencesContainer ) {
		return this.m_bo.cacheUserQueuePreferences(admin, userPreferencesContainer ) ;
	}//EOM

	/** 
	 * Handles the request for getting the column chooser fields.
	 * @param admin  {@link Admin} instance containing the requesting user credentials.
	 * @param sQueueName -the queue name
	 * @param sQueueMT 
	 * @return returns the available and selected chooser column fields.
	 */
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent getColumnSettingsFields(final Admin admin, java.lang.String sQueueName, java.lang.String sQueueMT ) {
		return this.m_bo.getColumnSettingsFields(admin, sQueueName, sQueueMT ) ;
	}//EOM

	/** 
	 * Handles the request for getting message tables data. 
	 * Returns SimpleResponseDataComponent with a HashMap in which:
	 * Key - Table Name (equivalent to MESSAGE_TABLES.TABLE_NAME column).
	 * Value	- Object[3] in which: Index 0 - MessageTableBasicData object.
	 * Index 1 - MessageTableHeaderData[] object.
	 * Index 2 - MessageTableCellData[] object.
	 */
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent getMessageTables(final Admin admin ) {
		return this.m_bo.getMessageTables(admin ) ;
	}//EOM

	public com.fundtech.datacomponent.response.SimpleResponseDataComponent reportClientsideError(final Admin admin, java.lang.String sErrorCode, java.lang.String[] arrErrorParams ) {
		return this.m_bo.reportClientsideError(admin, sErrorCode, arrErrorParams ) ;
	}//EOM

}//EOC