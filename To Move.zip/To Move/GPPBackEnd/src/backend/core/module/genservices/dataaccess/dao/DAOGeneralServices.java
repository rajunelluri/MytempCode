package backend.core.module.genservices.dataaccess.dao;

import static backend.core.module.MessageConstantsInterface.RULE_TYPE_ID_TRANSACTION_SEARCH;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.dataaccess.dao.DBType;
import backend.dataaccess.dto.DTOBoolean;
import backend.dataaccess.dto.DTODataHolder;
import backend.dataaccess.dto.DTOSingleValue;
import backend.mapping.config.AppServerConfigKeysInterface;
import backend.staticdata.dataaccess.dao.DAOStaticData;
import backend.util.ServerConstants;
import backend.util.ServerUtils;

import com.fundtech.cache.entities.QueuePreferences;
import com.fundtech.cache.infrastructure.CacheServiceInterface;
import com.fundtech.cache.infrastructure.misshandlers.CacheMissHandlerInterface.MissValue;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.general.StatementParameter;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.util.ExceptionController;
import com.fundtech.util.GlobalConstants;

/**
 * Title:       DAOServices
 * Description: Data access object which provides common services
 * Company:     Fundtech Israel
 * Author:      Asaf Levy
 * Date:        02/05/05
 * @version     1.0
 */
public class DAOGeneralServices extends DAOStaticData 
{

	private final static Logger logger = LoggerFactory.getLogger(DAOGeneralServices.class);
	
  /**
   * Populates a DTOGeneralServices object for all regular combo boxes of the application.
   * @return returns DTOGeneralServices object for all regular combo boxes of the application.
   */
  public DTODataHolder getRegularComboBoxesData()
  {
    String[] arrSelectStatementHolder = new String[1];
    getTotalComboBoxesSelectStatement(arrSelectStatementHolder);
    
    return getData(arrSelectStatementHolder[0], 0);
  }
  
  /**
   * Returns the total select statement for getting all regular combo boxes
   * of the application.
   */
  private Feedback getTotalComboBoxesSelectStatement(String[] arrSelectStatementHolder)
  {
  	// ORDER BY COMBO_ID, DESCRIPT
    final String END_SELECT_PART = " ORDER BY 1, 3";
    
    StringBuffer sbTotalComboBoxesSelectStatement = new StringBuffer();
    
    String[] arrSQL_RESOURCE_SelectStatementHolder = new String[1];
    Feedback feedback = getSQL_RESOURCE_SelectStatements(arrSQL_RESOURCE_SelectStatementHolder);
    
    boolean bSuccess = feedback.isSuccessful(); 
    
    if(bSuccess)
    {
      sbTotalComboBoxesSelectStatement.append(arrSQL_RESOURCE_SelectStatementHolder[0]);
      sbTotalComboBoxesSelectStatement.append(END_SELECT_PART);
      
      arrSelectStatementHolder[0] = sbTotalComboBoxesSelectStatement.toString();
    }
    
    return feedback;
  }
  
  /**
   * Returns the select statement part constructed from the SQL_RESOURCE table.
   */
  private Feedback getSQL_RESOURCE_SelectStatements(String[] arrSelectStatementHolder)
  {
    final String GET_SQL_RESOURCE_SELECT_STATEMENT = "SELECT "+ ms_DBType +" STATEMENTS FROM SQL_RESOURCE WHERE MODULE_NAME = 90000";
    final String UNION = " UNION ";
    final String sDatabaseNameColumn = "STATEMENTS"; 
    final String FETCH_FIRST_KEYWORD = "FETCH FIRST";
    
    Connection conn=null;
    ResultSet rs=null;
    PreparedStatement statement= null;
    Feedback feedback = new Feedback();
    
    StringBuilder sb = new StringBuilder();
    try    
    {
      String sStatement;
      conn = getConnection();
      statement= conn.prepareStatement(GET_SQL_RESOURCE_SELECT_STATEMENT);
      rs = statement.executeQuery();
      
      
      // There is an actual data.
        while(rs.next())
        {
          sStatement = (String)rs.getString(sDatabaseNameColumn);
          
          //special processing for db2 types only
          //apparently, using FETCH FIRST <num> ROWS only in a union requires the statement using it 
          //to be encapsulated by () 
          if(ms_DBType == DBType.DB2 && (sStatement.indexOf(FETCH_FIRST_KEYWORD) != -1)) {
        	  
        	  sStatement = ServerConstants.OPENING_PARENTHESIS + sStatement + ServerConstants.CLOSING_PARENTHESIS ; 
        	  
          }//EO if there was a FETCH FIRST query in the union
          
          sb.append(sStatement).append(UNION);
        }
        
      // Updates returned value while removing last UNION string.
      arrSelectStatementHolder[0] = sb.substring(0, (sb.length()-6)).toString();
    }
    catch(Exception e)
    {
    	logger.error(e.getMessage());
        feedback.setFailure();
    }
    finally
    {
        releaseResources(rs, statement, conn );
    }    
    return feedback;
  }
  
  /**
   * Populates a DTOGeneralServices object for all table type combo boxes data.
   * @return returns a DTOGeneralServices object for all table type combo boxes data.
   */
  public DTODataHolder getTableTypeComboBoxesData()
  {
    final String GET_TABLE_TYPE_COMBO_BOXES_SELECT_STATEMENT = 
             "SELECT UPPER(FIELD_TYPE) AS COMBO_ID, VALUE_CODE, VALUE_DESCR, ALLOW_USER_SELECTION AS ACTIVE " +
             "FROM FIELDS_VALUES " +
             "WHERE UPPER(FIELD_TYPE) IN ('DEALBOOKED', 'CUTOFF_STATUS', 'COL_CODE') AND ACTIVE <> 0 " +
             "ORDER BY COMBO_ID";
  
    return getData(GET_TABLE_TYPE_COMBO_BOXES_SELECT_STATEMENT, 0);
  }
  
  /**
   * Returns a DTOGeneralServices[4] with LTERM/VTERM data.
   */
  public DTODataHolder[] getLTermVTermOptions()
  {
    DTODataHolder[] arrLTermVTermData = new DTODataHolder[4];
    
    final String GET_LTERM_OPTIONS_SELECT_STATEMENT = 
             "SELECT OFFICE, MOP, LTERM || '@@' || DIRECTION AS DESCRIPT " +
             "FROM LTERMS " +
             "WHERE REC_STATUS = 'AC' " +
             "ORDER BY OFFICE, MOP";
    
    final String GET_LTERM_GROUP_OPTIONS_SELECT_STATEMENT = 
             "SELECT DISTINCT OFFICE, MOP, LTERM_GRP || '@@' || DIRECTION AS DESCRIPT " +
             "FROM LTERMS " +
             "WHERE REC_STATUS = 'AC' " +
             "ORDER BY OFFICE, MOP";

    final String GET_VTERM_OPTIONS_SELECT_STATEMENT = 
             "SELECT OFFICE, MOP, VTERM " +
             "FROM VTERMS " +
             "WHERE REC_STATUS = 'AC' " +
             "ORDER BY OFFICE, MOP";
    
    final String GET_VTERM_GROUP_OPTIONS_SELECT_STATEMENT = 
             "SELECT DISTINCT OFFICE, MOP, VTERM_GRP " +
             "FROM VTERMS " +
             "WHERE REC_STATUS = 'AC' " +
             "ORDER BY OFFICE, MOP";
    
    DTODataHolder dto;

    // LTERM options.
    arrLTermVTermData[0] = getData(GET_LTERM_OPTIONS_SELECT_STATEMENT, 0);
    
    // LTERM group options.
    arrLTermVTermData[1] = getData(GET_LTERM_GROUP_OPTIONS_SELECT_STATEMENT, 0);

    // VTERM options.
    arrLTermVTermData[2] = getData(GET_VTERM_OPTIONS_SELECT_STATEMENT, 0);
    
    // VTERM group options.
    arrLTermVTermData[3] = getData(GET_VTERM_GROUP_OPTIONS_SELECT_STATEMENT, 0);

    return arrLTermVTermData;
  }
  
  /**
   * Returns a DTOGeneralServices for ABA data.
   * @return returns a DTOGeneralServices for ABA data.
   */
  public DTODataHolder getABAsData()
  {
    final String GET_ABAs_SELECT_STATEMENT = 
             "SELECT OFFICE, MOP, SWIFT_ID FROM SWIFT_ID ORDER BY OFFICE, MOP";
    
    return getData(GET_ABAs_SELECT_STATEMENT, 0);
  }
  
  /**
   * Returns a DTOGeneralServices for holidays data.
   * @return returns a DTOGeneralServices for holidays data.
   */
  public DTODataHolder getHolidaysData()
  {
    final String GET_HOLIDAYS_SELECT_STATEMENT = 
              "SELECT CALNAME, NVL(TO_CHAR(HOLDATE,'YYYY-MM-DD'),' ') AS HOLDATE FROM HOLIDAYS " +
              "WHERE CALNAME IN (SELECT CALNAME FROM BANKS WHERE REC_STATUS = 'AC') or CALNAME IN (SELECT CALNAME FROM CURRENCY_CFG WHERE REC_STATUS = 'AC')" +
              "ORDER BY CALNAME, HOLDATE";
    
    return getData(GET_HOLIDAYS_SELECT_STATEMENT, 0);
  }
  
  /**
   * Returns a DTOGeneralServices for relationships data.
   * @return returns a DTOGeneralServices for relationships data.
   */
  public DTODataHolder getRelationshipsData()
  {
    final String GET_RELATIONSHIPS_SELECT_STATEMENT = 
              "SELECT * FROM TMS_LIST_RELATION " +
              "WHERE LIST_TP IN('MST')" +
              "ORDER BY LIST_TP, ITEM_NM, RELATED_LIST_TP, RELATED_ITEM_DEFAULT_IN DESC, RELATED_ITEM_NM";
    
    return getData(GET_RELATIONSHIPS_SELECT_STATEMENT, 0);
  }
  
  /**
   * Returns a DTOGeneralServices for offices data.
   * @return returns a DTOGeneralServices for offices data.
   */
  public DTODataHolder getOfficesData()
  {
    final String GET_OFFICES_SELECT_STATEMENT = 
              "SELECT OFFICE, FORCE_LEAD_ZERO, MIN_ACC_LENGTH, CALNAME " +
              "FROM BANKS " +
              "WHERE REC_STATUS ='AC'";
    
    return getData(GET_OFFICES_SELECT_STATEMENT, 0);
  }
  
  
  /**
   * Returns a DTOGeneralServices for statuses data.
   * @return returns a DTOGeneralServices for statuses data.
   */
  public DTODataHolder getWEBSystemParametersData(Object[] arrBasicRequiredSystemParameters)
  {
    final String GET_WEB_SYSTEM_PARAMETERS_SELECT_STATEMENT_1 = 
              "SELECT OFFICE, TRIM(PARAM_NAME) AS PARAM_NAME, PARM_VALUE " +
              "FROM SYST_PAR " +
              "WHERE PARAM_NAME IN ";
    
    final String GET_WEB_SYSTEM_PARAMETERS_SELECT_STATEMENT_2 = " AND REC_STATUS = 'AC' ORDER BY OFFICE ";
    
    String sSelectStatement = new StringBuffer(GET_WEB_SYSTEM_PARAMETERS_SELECT_STATEMENT_1)
                                       .append(getIN_PartFromObjectArray(arrBasicRequiredSystemParameters))
                                       .append(GET_WEB_SYSTEM_PARAMETERS_SELECT_STATEMENT_2).toString();
    
    return getData(sSelectStatement, 0);
  }
  
  /**
   * Gets an Object[] and returns well formed IN part for SQL statement.
   */
  private String getIN_PartFromObjectArray(Object[] arrParameters)
  {
    StringBuffer sb = new StringBuffer();
    
    sb.append(ServerConstants.OPENING_PARENTHESIS);
    
    if(arrParameters != null && arrParameters.length > 0)
    {
      int iLength = arrParameters.length;
      
      for(int i=0; i<iLength; i++)
      {
        sb.append(ServerConstants.APOSTROPHE).append(arrParameters[i]).append(ServerConstants.APOSTROPHE);
        
        if(i < (iLength-1))
        {
          sb.append(ServerConstants.COMMA);
        }
      }
    }
    
    sb.append(ServerConstants.CLOSING_PARENTHESIS);
    
    return sb.toString();
  }
  
  
  /**
   * Returns a DTOGeneralServices for the message fee types combo boxes data.
   * @return returns a DTOGeneralServices for the message fee types combo boxes data.
   */
  public DTODataHolder getMessageFeeTypesData()
  {
    final String GET_MESSAGE_FEE_TYPES_COMBO_BOXES_SELECT_STATEMENT = 
                        "SELECT OFFICE, FEE_TYPE_CODE, FEE_TYPE_DESCRIPTION " +
                        "FROM FEE_TYPES ORDER BY OFFICE,FEE_TYPE_DESCRIPTION";
    
    return getData(GET_MESSAGE_FEE_TYPES_COMBO_BOXES_SELECT_STATEMENT, 0);
  }
  
  /**
   * Returns a DTOGeneralServices for the ofac tags data.
   * @return returns a DTOGeneralServices for the ofac tags data.
   */
  public DTODataHolder getOfacTagsData()
  {
    final String GET_OFAC_TAGS_SELECT_STATEMENT = 
                        "SELECT TAG_FAMILY, FAMILY_FIELDS " +
                        "FROM OFAC_TAGS " +
                        "WHERE FAMILY_FIELDS IS NOT NULL " +
                        "ORDER BY TAG_FAMILY";
    
    return getData(GET_OFAC_TAGS_SELECT_STATEMENT, 0);
  }
  
  /**
   * Returns a DTOGeneralServices for the data of the queue list toolbar buttons.
   * @return returns a DTOGeneralServices for the data of the queue list toolbar buttons.
   */
  public DTODataHolder getQListToolbarButtonsData()
  {
    final String REC_STATUS_FILTER = "WHERE REC_STATUS = 'AC' ";
    
    final String GET_QLIST_TOOLBAR_BUTTONS_SELECT_STATMENT = 
                 "SELECT * FROM QLIST_TOOLBAR_BUTTONS " +
                 REC_STATUS_FILTER +
                  "ORDER BY SEQUENCE";
    
    return getData(GET_QLIST_TOOLBAR_BUTTONS_SELECT_STATMENT, 0);
  }

  public DTOSingleValue getBankProfileForUserEntitlement(String sUserEntitlmentName) { 
      final String GET_BANK_PROFILE_QUERY = "SELECT BANK_PROF FROM USER_ENTITLEMENT WHERE U_ENT_NAME = ?" ;
            
      StatementParameter[] queryParameters =  { new StatementParameter(sUserEntitlmentName, Types.VARCHAR) };
      
      return this.getSingleValue(GET_BANK_PROFILE_QUERY,queryParameters,  null) ;
  }//EOM
  
  public Feedback updateUserExtraData(String sDataType, String sLayout, String sFiltersString, String sAdditionalData, String sUserId) { 
      return this.updateUserExtraData(sDataType, sLayout, sFiltersString, sAdditionalData, null, null, null, sUserId) ;
  }//EOM
   
  /**
   * Performs a single entry update to the USERS_EXTRA_DATA table 
   * @param sKey filter 
   * @param sValue value to set 
   * @param sUserId 
   * @return feedback with execution results 
   */
  public Feedback updateUserExtraData(String sDataType, String sLayout, String sFiltersString, String sAdditionalData,
          String sSelectListColumnNames,String  sColumnWidths,String  sSelectListSortingOptions, String sUserId)  {
      final String sUpdatePrefix = "UPDATE USERS_EXTRA_DATA SET " ;  
      final String sWhereClase1 = " WHERE USER_ID = '" ;
      final String sWhereClase2 = "' AND DATA_TYPE = '" ; 
      final String LAYOUT_POS_COLUMN = "LAYOUT_POSITION" ;
      final String FILTER_FIELDS_COLUMN = "FILTER_FIELDS " ;
      final String ADDITIONAL_DATA_COLUMN = "ADDITIONAL_DATA" ; 
      final String SEARCH_COLUMNS_ORDER_COLUMN = "SEARCH_COLUMNS_ORDER" ; 
      final String SEARCH_COLUMNS_WIDTH = "SEARCH_COLUMNS_WIDTH" ; 
      final String SEARCH_COLUMNS_SORTING = "SEARCH_COLUMNS_SORTING" ;
      final String EAUQLS_STRING = GlobalConstants.SPACE + GlobalConstants.EQUAL_SIGN + GlobalConstants.SPACE ;
      final String QUOTE = GlobalConstants.APOSTROPHE ; 
      final char COMMA = ',' ;
      final StatementParameter[] EMPTY_STATEMENT_PARAMS = {} ; 
      boolean isFirstColumn = true ; 
    
      final int[] arrAffectedRows = new int[1] ; 
      
      StringBuffer sbQueryBuffer = new StringBuffer(sUpdatePrefix) ; 
      
      //append the layout if any 
      isFirstColumn = this.appendColumnValue(sbQueryBuffer, LAYOUT_POS_COLUMN, sLayout, true, isFirstColumn) ;
      //append the filter String if any 
      isFirstColumn = this.appendColumnValue(sbQueryBuffer, FILTER_FIELDS_COLUMN, sFiltersString, true, isFirstColumn) ;
      //append the additional data if any 
      isFirstColumn = this.appendColumnValue(sbQueryBuffer, ADDITIONAL_DATA_COLUMN, sAdditionalData, true, isFirstColumn) ;
      //append the select list column names if any 
      isFirstColumn = this.appendColumnValue(sbQueryBuffer, SEARCH_COLUMNS_ORDER_COLUMN, sSelectListColumnNames, true, isFirstColumn) ;
      //append the select list column widths if any 
      isFirstColumn = this.appendColumnValue(sbQueryBuffer, SEARCH_COLUMNS_WIDTH, sColumnWidths, true, isFirstColumn) ;
//    append the select list column sorting options if any 
      isFirstColumn = this.appendColumnValue(sbQueryBuffer, SEARCH_COLUMNS_SORTING, sSelectListSortingOptions, true, isFirstColumn) ;
      //append the where clause                                       
      sbQueryBuffer.append(sWhereClase1).append(sUserId).append(sWhereClase2).append(sDataType).append(QUOTE) ;
      
      Feedback feedback =  super.update(sbQueryBuffer.toString(), EMPTY_STATEMENT_PARAMS, arrAffectedRows, null, false, false, null);
                 
      //check the success of the operation and if success, continue 
      if(feedback.isSuccessful()) { 
          //check the number of affected rows and if there were non, (no entry, insert 
          if(arrAffectedRows[0] == 0) { 
              final String INSERT_TO_USERS_EXTRA_DATA_QUERY_STRING = "INSERT INTO USERS_EXTRA_DATA(DATA_TYPE, LAYOUT_POSITION, FILTER_FIELDS, ADDITIONAL_DATA,SEARCH_COLUMNS_ORDER,SEARCH_COLUMNS_WIDTH, SEARCH_COLUMNS_SORTING, USER_ID)  VALUES(?,?,?,?,?,?,?,?)" ; 
             
              StatementParameter[] arrParameters = { 
                 new StatementParameter(sDataType, Types.VARCHAR),
                 new StatementParameter(sLayout, Types.VARCHAR), 
                 new StatementParameter(sFiltersString, Types.VARCHAR), 
                 new StatementParameter(sAdditionalData, Types.VARCHAR), 
                 new StatementParameter(sSelectListColumnNames, Types.VARCHAR),
                 new StatementParameter(sColumnWidths, Types.VARCHAR),
                 new StatementParameter(sSelectListSortingOptions, Types.VARCHAR),
                 new StatementParameter(sUserId, Types.VARCHAR)  
              }; 
              
              feedback =  super.update(INSERT_TO_USERS_EXTRA_DATA_QUERY_STRING, arrParameters, null, null, false, false, null);
              
              //no need to check the insert as this is the last operation
          }//EO if there was no entry to update, peform an insert 
      }//EO if the operation was successul 

      return feedback ;
  }//EOM
  
  private boolean appendColumnValue(StringBuffer sbQueryBuffer, String columnName, String columnValue, boolean isVarchar, boolean isFirstColumn) { 
      final char COMMA = ',' ;
      final String QUOTE = GlobalConstants.APOSTROPHE ; 
      final String EAUQLS_STRING = GlobalConstants.SPACE + GlobalConstants.EQUAL_SIGN + GlobalConstants.SPACE ;
      
      if(columnValue != null) { 
          if(!isFirstColumn) sbQueryBuffer.append(COMMA) ;
                    
          sbQueryBuffer.append(columnName).append(EAUQLS_STRING) ;
          
          if(isVarchar) sbQueryBuffer.append(QUOTE) ; 
          
          sbQueryBuffer.append(columnValue);

          if(isVarchar) sbQueryBuffer.append(QUOTE) ; 
          
          isFirstColumn = false ; 
      }//EO if the columNames !=  null
      
      return isFirstColumn ;
  }//EOM
  
  /**
   * Returns generic search data from USERS_EXTRA_DATA table for this user ID.
   */
  public DTODataHolder getDataFromUSERS_EXTRA_DATA(String sDataType, String sUserID)
  {
    final String SELECT_STATEMENT = "SELECT LAYOUT_POSITION, ADDITIONAL_DATA FROM USERS_EXTRA_DATA WHERE DATA_TYPE = ? and USER_ID = ?";
  
    StatementParameter[] arrParameters = new StatementParameter[2];
    arrParameters[0] = new StatementParameter(sDataType, Types.VARCHAR);
    arrParameters[1] = new StatementParameter(sUserID, Types.VARCHAR);
    
    return getData(SELECT_STATEMENT, arrParameters, 0);
  }
  
  public DTODataHolder getColumnSettingsAvailableFields(String sUserId,String sQueueName, boolean bLowValue){
	//first attempt to retrieve the queue preferences from the cache using the constructed queue name key
   sQueueName = (bLowValue? ServerConstants.LOW_VALUE_PREFIX : ServerConstants.HIGH_VALUE_PREFIX) + sQueueName ;
	
	final CacheServiceInterface cache = CacheServiceInterface.eINSTANCE ; 
	
	QueuePreferences queuePreferences = CacheKeys.QueuePreferencesKey.getSingle(RULE_TYPE_ID_TRANSACTION_SEARCH, sQueueName, sUserId);  
	
	if (queuePreferences == null || queuePreferences.isToBeDeleted())
	{
	   queuePreferences = CacheKeys.QueuePreferencesKey.getSingle(RULE_TYPE_ID_TRANSACTION_SEARCH, sQueueName, "********");
	}
	
	final String LOGICAL_FIELDS_SELECT = "SELECT FIELD_LOGICAL_ID \"COLUMNNAME\",UPPER(ALIAS) \"Fake\", ALIAS \"ALIASNAME\" FROM LOGICAL_FIELDS";
	final String UDFS_SELECT = "SELECT UID_UDFS,UPPER(SCREEN_LABEL)\"Fake\", SCREEN_LABEL FROM UDFS";
	
	final String LOGICAL_FIELDS_WHERE_PREFS = "FIELD_LOGICAL_ID NOT IN (%s) AND (AVAILABLE_FOR_QVIEW <> 0 OR LOGICAL_FIELDS.DEFUALT_IN_QVIEW <> 0 OR MUST_HAVE_COLUMN_IND = 1)";
	final String LOGICAL_FIELDS_WHERE_NO_PREFS = "DEFUALT_IN_QVIEW = 0 AND MUST_HAVE_COLUMN_IND = 0 AND AVAILABLE_FOR_QVIEW <> 0";
	
	final String UDFS_WHERE_PREFS = "USAGE_TYPE = 'M' AND UID_UDFS NOT IN (%s) AND OBJECT_ID = '***'";
	final String UDFS_WHERE_NO_PREFS = "USAGE_TYPE = 'M' AND OBJECT_ID = '***'";
	
	 
	
	String sPreferecesColumnIds = null;
	String preferencesPart = null;
	
	if (queuePreferences != null && (sPreferecesColumnIds = queuePreferences.getColumns()) != null) {
		preferencesPart = "'" + sPreferecesColumnIds.replaceAll(",", "','") + "'";
	}
	
	StringBuffer selectQuery = new StringBuffer();
	selectQuery.append(LOGICAL_FIELDS_SELECT);
	selectQuery.append(" WHERE ");
	
	if (queuePreferences != null) {
		selectQuery.append(String.format(LOGICAL_FIELDS_WHERE_PREFS, preferencesPart));
	}
	else {
		selectQuery.append(LOGICAL_FIELDS_WHERE_NO_PREFS);
	}
	
	
	selectQuery.append(" UNION ");
	
	selectQuery.append(UDFS_SELECT);
	selectQuery.append(" WHERE ");
	
	if (queuePreferences != null) {
		selectQuery.append(String.format(UDFS_WHERE_PREFS, preferencesPart));
	}
	else {
		selectQuery.append(UDFS_WHERE_NO_PREFS);
	}
		
	return getData(selectQuery.toString(), -1); 			
  }//EOM 
  
  /**
   * Returns all selected chooser column fields for specific queue and user.
   */
  public DTODataHolder getColumnSettingsSelectedFields(String sUserId,String sQueueName, boolean bLowValue){
   		
	//first attempt retrieve the queue preferences from the cache using the constructed queue name key 
	sQueueName = (bLowValue? ServerConstants.LOW_VALUE_PREFIX : ServerConstants.HIGH_VALUE_PREFIX) + sQueueName ;
	
	QueuePreferences queuePreferences = CacheKeys.QueuePreferencesKey.getSingle(RULE_TYPE_ID_TRANSACTION_SEARCH, sQueueName, sUserId) ;
	
    if (queuePreferences == null || queuePreferences.isToBeDeleted())
    {
       queuePreferences = CacheKeys.QueuePreferencesKey.getSingle(RULE_TYPE_ID_TRANSACTION_SEARCH, sQueueName, "********");
    }

 
	List<String> listColumnNames = null ; 
	
	//if the preferences do not exist or there are no column preferences, return the default queue preferences 
	//CR#89968->Commented this line as it is not containing logical fields with condition MUST_HAVE_COLUMN_IND <> 0
	//if(queuePreferences == null || (listColumnNames = queuePreferences.getColumnNames()) == null) 
	//						return BOQueues.m_defaultColumnsMetadata.getColumnSettingsDefaultSelectedColumns(); 
	
	//of else if there were user preferences for the given queue, construct a new DTO, using the logical fields cache entries 
	//for metadata 
		 
	final String STATEMENT_START = "SELECT * FROM (SELECT FIELD_LOGICAL_ID \"COLUMNNAME\", ALIAS \"ALIASNAME\" FROM LOGICAL_FIELDS " +
			" WHERE (FIELD_XML_TYPE <> 'GROUP' OR FIELD_XML_TYPE IS NULL) AND " ;
	
	final String UDF_COLUMNS_UNION_TEMPLATE = " UNION SELECT UID_UDFS, SCREEN_LABEL FROM UDFS WHERE USAGE_TYPE = 'M' AND OBJECT_ID = '***' AND UID_UDFS IN (%s)" ; 

	final String LOGICAL_FIELD_COLUMNS_TEMPLATE = "LOGICAL_FIELDS.FIELD_LOGICAL_ID IN (%s) " ;
	
	String sFinalStatement = STATEMENT_START ; 
		
	final StringBuilder sbLogicalFieldsColumnNamesBuilder = new StringBuilder(),  sbUDFColumnNamesBuilder = new StringBuilder() ; 
	List<String> listPreferenceColumnIds = null ; 
	
	if(queuePreferences != null && (listPreferenceColumnIds = queuePreferences.getColumnNames()) != null){
		//select all User preferences columns as well as those which are MUST_HAVE (althrough the latter is redundant)
		//iterate over the column names list and divide to user defined and logical fields. 
		//if there is at least a single UDF, add the union section on udf to the query  
		for(String sColumnId : listPreferenceColumnIds) { 
			
			sColumnId = '\'' + sColumnId + '\'' ; 
			
			if(CacheKeys.UserDefinedFieldsIdKey.isUDF(sColumnId)) { 
				sbUDFColumnNamesBuilder.append(sColumnId).append(',') ;
			}else sbLogicalFieldsColumnNamesBuilder.append(sColumnId).append(',') ; 
			
		}//EO while there are more columns 
		
		int iLFBuilderLength = -1, iUDFBuilderLength = -1 ; 
		if((iLFBuilderLength = sbLogicalFieldsColumnNamesBuilder.length()) > 0) sbLogicalFieldsColumnNamesBuilder.deleteCharAt(iLFBuilderLength-1);
		if((iUDFBuilderLength = sbUDFColumnNamesBuilder.length()) > 0) sbUDFColumnNamesBuilder.deleteCharAt(iUDFBuilderLength-1); 
		
		//sFinalStatement += "LOGICAL_FIELDS.FIELD_LOGICAL_ID IN ('"+ sPreferecesColumnIds.replaceAll(",", "','") +"') " ; //OR MUST_HAVE_COLUMN_IND <> 0" ;
		//CR# 89743: (INSTR used to order the selection as per the values in sPreferecesColumnIds)
		//sFinalStatement += "ORDER BY INSTR ('''"+ sPreferecesColumnIds.replaceAll(",", "'',''") +"''',''''||FIELD_LOGICAL_ID||'''') " ;
		//final String sInstrString = (sbLogicalFieldsColumnNamesBuilder.toString() + sbUDFColumnNamesBuilder).replaceAll("'", "''") ;
		final String sInstrString = "'''"+ queuePreferences.getColumns().replaceAll(",", "'',''") + "'''" ;
		
		if(iLFBuilderLength > 0) sFinalStatement = sFinalStatement + String.format(LOGICAL_FIELD_COLUMNS_TEMPLATE, sbLogicalFieldsColumnNamesBuilder) ;
		if(iUDFBuilderLength > 0) sFinalStatement = sFinalStatement + String.format(UDF_COLUMNS_UNION_TEMPLATE, sbUDFColumnNamesBuilder) ;
				
		sFinalStatement = sFinalStatement + String.format(") ORDER BY INSTR(%s, ''''||COLUMNNAME||'''')", sInstrString) ; 
	}else{//EO if column queue preferences are present
		//select all default and must have columns 
		sFinalStatement += "MUST_HAVE_COLUMN_IND <> 0 OR DEFUALT_IN_QVIEW <> 0)" ; 
	}//EO else if queue preferences were not present 
	 
	return getData(sFinalStatement,-1) ; 		
  }//EOM 
  
  
  public final Feedback persistQueuePreferences(QueuePreferences...arrQueuePreferences) {
	  return this.persistQueuePreferences(Arrays.asList(arrQueuePreferences), null) ;
  }//EOC
  
  /**
   * 
   * May 27, 2008
   * guys
   * 
   * persists all QueuePreferences entries into the database using the {@link QueuePreferences#isNew()}
   * <br> 
   * to determine whether an insert or update is required  
   * 
   * @param iterator
   * @param feedback
   * @return
   */
  public synchronized final Feedback  persistQueuePreferences(final List<QueuePreferences> listqPrefs, Feedback feedback) { 
	  
	  feedback = ( feedback != null ? feedback : new Feedback() ) ; 
	  
	  final String INSERT_STATEMENT = "INSERT INTO USER_QUEUE_PREFERENCES (UID_USER_QUEUE_PREFERENCES, " +
	  		"QUEUE_NAME, RULE_TYPE_ID, USER_ID, ADDITIONAL_FILTER_PRESENTATION, ADDITIONAL_FILTER_WHERE, " +
	  		"ADDITIONAL_TABLES, SORT_BY_FIELDS, ADDITIONAL_DATA, COLUMNS, COLUMNS_SIZE, SCREEN_POSITION) " +
	  		"VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";
	  	
	  final String UPDATE_STATEMENT = "UPDATE USER_QUEUE_PREFERENCES SET " +
	  		"ADDITIONAL_FILTER_PRESENTATION = ?, " +
	  		"ADDITIONAL_FILTER_WHERE = ?, " +
	  		"ADDITIONAL_TABLES = ?, " +
	  		"SORT_BY_FIELDS = ?, " +
	  		"ADDITIONAL_DATA = ?, " +
	  		"COLUMNS = ?, " + 
	  		"COLUMNS_SIZE = ?, " +
	  		"SCREEN_POSITION = ? WHERE " +
	  		"UID_USER_QUEUE_PREFERENCES = ? " ; 
		 
      final String DELETE_STATEMENT = "DELETE FROM USER_QUEUE_PREFERENCES  WHERE UID_USER_QUEUE_PREFERENCES = ? " ;

      String sQPrefsUid = null ; 
	  	
	  	Connection conn  = null ; 
	  	PreparedStatement insertPs = null, updatePs = null, deletePs = null ;
	  	
	  	try{ 
	  	
	  		conn = this.getConnection() ;
	  		insertPs = conn.prepareStatement(INSERT_STATEMENT) ;  
			updatePs = conn.prepareStatement(UPDATE_STATEMENT) ; 
            deletePs = conn.prepareStatement(DELETE_STATEMENT) ; 
			
			int iInsertBatchCount = 0, iUpdateBatchCount = 0, iDeleteBatchCount = 0;  
	  		
			final String[] arrUidKeyParts = new String[3] ;  
			
			//might contain nulls which are place holders for miss values 
			//for(QueuePreferences queuePreferences : listqPrefs)
			int iSize = listqPrefs.size();
			for(int i=0; i<iSize; i++)
			{
			    Object obj = listqPrefs.get(i);
			  
			    if(obj == null || obj == MissValue.PlaceHolder) continue;
			  
				QueuePreferences queuePreferences = (QueuePreferences)obj;
				 
				sQPrefsUid = queuePreferences.getUidQueuePreferences() ; 
				
				//if the uid is null, then this is a new object an thus shall 
				//be batched with the insert statements 
				//else this is an update if modifications were detected  
				if(sQPrefsUid != null &&  !queuePreferences.isDirty()) continue ; 
				
				//Insert 
				/*
				 *  final String INSERT_STATEMENT = "INSERT INTO QUEUE_PREFERENCES (UID_QUEUE_PREFERENCES, " +
			  		"QUEUE_NAME, RULE_TYPE_ID, USER_ID, XML_CONDITIONS, FILTER_WHERE, " +
			  		"FILTER_WHERE_TABLES, SORT_BY_FIELDS, ADDITIONAL_DATA, COLUMNS, COLUMNS_SIZE, SCREEN_POSITION " +
			  		"VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";
				 */
                if (queuePreferences.isToBeDeleted()==true)
                {
                   deletePs.setString(1, sQPrefsUid);  
                   deletePs.addBatch() ; 

                   iDeleteBatchCount++;
                }
                else if(sQPrefsUid == null) { 
					//first generate the UID and set it in the queue preference instance 
					arrUidKeyParts[0] = queuePreferences.getRuleTypeId()  ;
					arrUidKeyParts[1] = queuePreferences.getQueueName()  ;
					arrUidKeyParts[2] = queuePreferences.getUserId()  ;
					sQPrefsUid = ServerUtils.generateUIDValue(null, arrUidKeyParts) ; 
					queuePreferences.setUidQueuePreferences(sQPrefsUid) ; 
					//add an insert batch 
					insertPs.setString(1, sQPrefsUid);  
					insertPs.setString(2, queuePreferences.getQueueName() );   
					com.fundtech.util.GlobalUtils.setObject(insertPs, 3, queuePreferences.getRuleTypeId() );
					insertPs.setString(4, queuePreferences.getUserId() );
					insertPs.setString(5, queuePreferences.getXmlConditions() );
					insertPs.setString(6, queuePreferences.getFilterWhere());
					insertPs.setString(7, queuePreferences.getFilterWhereTables());
					insertPs.setString(8, queuePreferences.getSortByFields());
					insertPs.setString(9, queuePreferences.getAdditionalData());
					insertPs.setString(10, queuePreferences.getColumns());
					insertPs.setString(11, queuePreferences.getColumnsSize());
					insertPs.setString(12, queuePreferences.getScreenPosition());
					
					insertPs.addBatch() ; 
					
					iInsertBatchCount++ ; 
				}else { 
					/*
					 *  final String UPDATE_STATEMENT = "UPDATE QUEUE_PREFERENCES SET " +
				  		"XML_CONDITIONS = ?, " +
				  		"FILTER_WHERE = ?, " +
				  		"FILTER_WHERE_TABLES = ?, " +
				  		"SORT_BY_FIELDS = ?, " +
				  		"ADDITIONAL_DATA = ? " +
				  		"COLUMNS = ? " + 
				  		"COLUMNS_SIZE = ? " +
				  		"SCREEN_POSITION = ? WHERE " +
				  		"UID_QUEUE_PREFERENCES = ? " ; 
					 */
					updatePs.setString(1, queuePreferences.getXmlConditions() );
					updatePs.setString(2, queuePreferences.getFilterWhere());
					updatePs.setString(3, queuePreferences.getFilterWhereTables());
					updatePs.setString(4, queuePreferences.getSortByFields());
					updatePs.setString(5, queuePreferences.getAdditionalData());
					updatePs.setString(6, queuePreferences.getColumns());
					updatePs.setString(7, queuePreferences.getColumnsSize());
					updatePs.setString(8, queuePreferences.getScreenPosition());
					updatePs.setString(9, sQPrefsUid);
					updatePs.addBatch() ; 
					
					iUpdateBatchCount++ ; 
				}//EO else update 
			 }//EO while there are more entries to persist
			
			//if the batching operation had succeeded, execute the statemetns
			//if their respective counts were bigger tham 0
			if(logger.isInfoEnabled()){
				final String TRACE_TEMPLATE = "There are {} {}. executing query:n{}" ; 
				logger.info(TRACE_TEMPLATE, new Object[] {iInsertBatchCount, "Inserts", INSERT_STATEMENT});
				logger.info(TRACE_TEMPLATE, new Object[] {iUpdateBatchCount, "Updates", UPDATE_STATEMENT});
				logger.info(TRACE_TEMPLATE, new Object[] {iDeleteBatchCount, "Delete", DELETE_STATEMENT});
			}
			if(iInsertBatchCount > 0) logger.info("Result of insertPs.executeBatch(): " +  ((int[])insertPs.executeBatch())[0]);
			if(iUpdateBatchCount > 0) logger.info("Result of updatePs.executeBatch(): " +  ((int[])updatePs.executeBatch())[0]);
            if(iDeleteBatchCount > 0) logger.info("Result of deletePs.executeBatch(): " +  ((int[])deletePs.executeBatch())[0]);
			
			//set the preference as dirty only after the batch was executed successfully 
            for(int i=0; i<iSize; i++)
            {
              Object obj = listqPrefs.get(i);
              
              if(obj == null || obj == MissValue.PlaceHolder) continue;		
              ((QueuePreferences)obj).resetDirtyFlag() ; 
            }
			
	  	}catch(Exception e) { 
	  		ExceptionController.getInstance().handleException(e, this) ; 
	  		feedback.setFailure() ;
	  		feedback.setErrorCode(1) ;
	  	}finally{ 
	  		this.releaseResources(insertPs, updatePs, deletePs, conn) ; 
	  	}//EO catch block 
	  return feedback ; 
  }//EOM 
  
  /**
   * Gets an array of table names, a key column name and its value, and returns the values
   * for the passed field names for that record in the table/s.
   * Restrictions/Notes:
   * 1) The passed 'sKeyColumnName' must be in a 'tablename.fieldname' format for
   *    cases of more than one table name.
   * 2) The passed 'arrFieldNamesTypes' array is mostly for date columns; it must 
   *    have the same length as the 'arrFieldNames' array.
   * 3) The passed 'arrFieldNamesTypes' array can be sent as null, and in that
   *    case, it will be ignored, assuming all required fields' SQL types are VARCHAR. 
   */
  public DTODataHolder getSpecificRecordDataFromTable(Connection conn,
                                                      String[] arrTableNames, String sKeyColumnName, 
                                                      int iKeyColumnSQLType, String sKeyColumnValue,
                                                      String[] arrFieldNames, int[] arrFieldNamesTypes)
  {
    final String SELECT_STATEMENT_1 = "SELECT ";
    final String SELECT_STATEMENT_2 = " FROM ";
    final String SELECT_STATEMENT_3 = " WHERE ";
    final String SELECT_STATEMENT_4 = " = ?";
    
    final String SELECT_ALL_FIELDS = " * ";
    
    final String DATE_COLUMN_1 = "TO_CHAR(";
    final String DATE_COLUMN_2 = ", 'YYYY-MM-dd')";
    
    StringBuilder sbFieldNames = new StringBuilder();
    
    if(ServerUtils.isArrayNotNullAndNotEmpty(arrFieldNames))
    {
      int iLength = arrFieldNames.length;
      for(int i=0; i<arrFieldNames.length; i++)
      {
        if(   arrFieldNamesTypes != null 
           && arrFieldNamesTypes[i] == Types.DATE)
        {
          sbFieldNames.append(DATE_COLUMN_1).append(arrFieldNames[i]).append(DATE_COLUMN_2)
                      .append(ServerConstants.SPACE).append(arrFieldNames[i]);
        }
        else
        {
          sbFieldNames.append(arrFieldNames[i]);
        }
        
        sbFieldNames.append(i < iLength - 1? ServerConstants.COMMA : ServerConstants.EMPTY_STRING);
      }
    }
    
    else
    {
      sbFieldNames.append(SELECT_ALL_FIELDS);
    }
    
    StringBuilder sbTableNames = new StringBuilder();
    
    int iLength = arrTableNames.length;
    for(int i=0; i<arrTableNames.length; i++)
    {
      sbTableNames.append(arrTableNames[i]).append(i < iLength - 1? ServerConstants.COMMA : ServerConstants.EMPTY_STRING);
    }
    
    String sSelectStatement = new StringBuilder(SELECT_STATEMENT_1).append(sbFieldNames)
                                        .append(SELECT_STATEMENT_2).append(sbTableNames)
                                        .append(SELECT_STATEMENT_3).append(sKeyColumnName)
                                        .append(SELECT_STATEMENT_4).toString();
    
    StatementParameter[] arrParameters = new StatementParameter[1];
    arrParameters[0] = new StatementParameter(sKeyColumnValue, iKeyColumnSQLType);
      
    String sDataSourceID = conn != null ? null : AppServerConfigKeysInterface.DATA_SOURCE_ID_ACTIVE;
    
    return getData(conn, sDataSourceID, sSelectStatement, arrParameters, 0);
  }
  
  /**
   * Returns a DTOGeneralServices for Message Tables data.
   * @return returns a DTOGeneralServices for Message Tables data.
   */
  public DTODataHolder getMessageTables()
  {
    final String GET_MESSAGE_TABLES_SELECT_STATEMENT = 
             "SELECT * FROM MESSAGE_TABLES ORDER BY TABLE_NAME";
    
    return getData(GET_MESSAGE_TABLES_SELECT_STATEMENT, 0);
  }
  
  /**
   * Returns a DTOGeneralServices for Message Tables Fields data.
   * @return returns a DTOGeneralServices for Message Tables Fields data.
   */
  public DTODataHolder getMessageTableFields()
  {
    final String GET_MESSAGE_TABLE_FIELDS_SELECT_STATEMENT = 
             "SELECT * FROM MESSAGE_TABLE_FIELDS WHERE TABLE_NAME IN (SELECT DISTINCT TABLE_NAME FROM MESSAGE_TABLES) ORDER BY TABLE_NAME, TH_ORDER";
    
    return getData(GET_MESSAGE_TABLE_FIELDS_SELECT_STATEMENT, 0);
  }
  
  public DTOBoolean isExistActiveUsersForEntitlement(String userEntitlement) {
    final String CHECK_FOR_ACTIVE_USERS_FOR_ENTITLEMENT = "SELECT COUNT(*) FROM users WHERE users.u_ent_name = ? AND users.rec_status ='AC'";
    StatementParameter[] param = new StatementParameter[1];
    param[0] = new StatementParameter(userEntitlement, Types.VARCHAR);
    return isRecordExistToBoolean(CHECK_FOR_ACTIVE_USERS_FOR_ENTITLEMENT, param);
  }
}
