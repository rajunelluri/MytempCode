package backend.core.module.qexplorer.ejbinterfaces;

import javax.ejb.Local;

/**
 * Local interface for QueueExplorer.
 */
@Local
public interface QueueExplorerLocal extends QueueExplorer{} ; 