package backend.core.module.qexplorer.businessobjects;

import static backend.businessobject.BOProxies.m_internalRuleExecutionLogging;
import static com.fundtech.util.GlobalUtils.isNullOrEmpty;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.SortedSet;
import java.util.TreeSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.core.module.BOCoreServices;
import backend.core.module.MessageConstantsInterface;
import backend.core.module.qexplorer.dataaccess.dao.DAOQExplorer;
import backend.core.module.qexplorer.dataaccess.dao.DAOQueueExplorer;
import backend.core.module.queues.common.QueueType;
import backend.core.module.security.businessobjects.UserEntitlementData;
import backend.dataaccess.dto.DTODataHolder;
import backend.dataaccess.dto.DTOSingleValue;
import backend.paymentprocess.erroraudit.ErrorAuditUtils;
import backend.util.ServerConstants;
import backend.util.ServerUtils;

import com.fundtech.annotations.Expose;
import com.fundtech.annotations.Expose.ExposureType;
import com.fundtech.annotations.Wrap;
import com.fundtech.cache.entities.Accounts;
import com.fundtech.cache.entities.Alerts;
import com.fundtech.cache.entities.Banks;
import com.fundtech.cache.entities.CounterDeltaPerMidHolder;
import com.fundtech.cache.entities.CounterDeltaPerMidHolder.CounterDelta;
import com.fundtech.cache.entities.Prules;
import com.fundtech.cache.entities.QExplorer;
import com.fundtech.cache.entities.QExplorerId;
import com.fundtech.cache.entities.QExplorerTaskInput;
import com.fundtech.cache.entities.Queuegroups;
import com.fundtech.cache.entities.RuleResult;
import com.fundtech.cache.entities.Statuses;
import com.fundtech.cache.infrastructure.CacheActionType;
import com.fundtech.cache.infrastructure.CacheException;
import com.fundtech.cache.infrastructure.CacheServiceInterface;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.cache.infrastructure.regions.CacheKeys.QExplorerKey;
import com.fundtech.cache.infrastructure.regions.CacheRegionKeyInterface;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.core.paymentprocess.errorhandling.ErrorSeverity;
import com.fundtech.core.paymentprocess.errorhandling.ProcessError;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.datacomponent.response.SimpleResponseDataComponent;
import com.fundtech.datacomponent.response.layout.LayoutConstants;
import com.fundtech.errors.ProcessErrorConstants;
import com.fundtech.spring.SpringApplicationContext;
import com.fundtech.util.ErrorAuditInputData;
import com.fundtech.util.ExceptionController;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalDateTimeUtil;
import com.fundtech.util.GlobalUtils;
import com.fundtech.util.QueueExplorerAndAlertsUtils;
import com.fundtech.util.datetime.NewASDateTimeUtils;


/**
 * Title:       BOQueueExplorer
 * Description: Business object for core queue explorer services
 * Company:     Fundtech Israel
 * Author:      Asaf Levy
 * Date:        24/01/2007
 * @version     1.0 
 */       
@Wrap

public class BOQueueExplorer extends BOCoreServices
{

  private final static Logger logger = LoggerFactory.getLogger(BOQueueExplorer.class);
	
  private static DAOQueueExplorer m_daoQueueExplorer = new DAOQueueExplorer();
  public static String EMPTY_DATE_VALUE =  "-------------";
  // Stands for the minimum settlement days to display as sub nodes for low value
  // statuses in the queue explorer.
  private static int m_iQExplorerMinSettlementDays;
  
  
  private static QExplorerComparator m_qExplorerComparator = new QExplorerComparator();
  
  // Stands for the default currency to display in sub nodes for low value
  // statuses in the queue explorer.
  private static String m_sDefaultCurrencyForLowValueStatuses;
  


  // STATUSES_COUNTERS table columns.
  private static final String COLUMN_STATUSES_COUNTERS_STATUS = "STATUS";
  private static final String COLUMN_STATUSES_COUNTERS_OFFICE_AMOUNT = "OFFICE_AMOUNT";
  private static final String COLUMN_STATUSES_COUNTERS_STTLM_DT = "STTLM_DT";
  private static final String COLUMN_STATUSES_COUNTERS_COUNT_STATUS = "COUNT_STATUS";
  private static final String COLUMN_STATUSES_COUNTERS_SUM_BASE_AMOUNT = "SUM_BASE_AMOUNT";
      
  private static final String HIGH_VALUE = "H";
  private static final String LOW_VALUE = "L";
  private static DAOQExplorer daoQExplorer = (DAOQExplorer)SpringApplicationContext.getBean("DAOQExplorer");
  
  // Static initializer.
//  static
//  {
//    initQExplorerMinSettlementDaysLowValueStatuses();
//    initDefaultCurrencyForLowValueStatuses();
//  }
  
  /**
   * Constructor.
   */
  public BOQueueExplorer()
  {
  }
 
//   * TODO: adapt to new API
  @Expose
  public QExplorerTaskInput updateCountersForDefinedQueue(String queueName) throws Exception 
  {
      
      String ruleUid = "***^2^"+queueName;
      
      Prules prule = CacheKeys.PRulesUIDKey.getSingle(ruleUid);
      
      Map<String, CounterDelta> deltaMap = new HashMap<String, CounterDelta>();
      
      if (prule != null)
      {
          DTODataHolder dataHolder = m_daoQueueExplorer.getQueuesData(prule.getExecWhere());
          
          
          
          if (dataHolder.getFeedBack().isSuccessful())
          {
              List<Map<String,String>> dataList = dataHolder.getDataAL();
              for (Map<String,String> map : dataList)
              {
                  String office = map.get("P_OFFICE");
                  String procDate = map.get("P_PROC_DT");
                  String baseAmt = map.get("AMOUNT");
                  String count = map.get("COUNT");
                  
                  procDate = GlobalUtils.isNullOrEmpty(procDate) ? EMPTY_DATE_VALUE : procDate.substring(0,10);
                  
                  try
                  {
                	  baseAmt = GlobalUtils.isNullOrEmpty(baseAmt) ? "0" : baseAmt;
                	  count = GlobalUtils.isNullOrEmpty(count) ? "0" : count;
                	  updateDataMap(ruleUid,office,procDate,1,Double.valueOf(baseAmt),Integer.valueOf(count),deltaMap);
                  }catch(Exception e)
                  {
                	  ExceptionController.getInstance().handleException(e, this);
                  }
              }
          }
          
          
      }
      
      return deltaMap.size() == 0 ? null : new QExplorerTaskInput(null, deltaMap); 
  }
  
  /** 
   * TODO: adapt to new API
   
  public final void performPendingCalculation(List<CounterDeltaPerMidHolder> deltasPerMidList, Map<String, String> refreshedMidMap)
  {
      for (CounterDeltaPerMidHolder deltaPerMid : deltasPerMidList)
      {
//              At the end of the full calculation need to go through the updated maps and find its related entry in the calculation processing cache. 
    	  
//              If it is not exist then need to add to the Qexplorer only the queues with plus sign.
          if (!refreshedMidMap.containsKey(deltaPerMid.getMID()))
          {
              queueExplorerDeltaUpdate(deltaPerMid.getCounterDeltaMap(), true,true);                  
          }
//              If it exists then need to compare the timestamp. If its timestamp in the full calculation cache is less than the its timestamp in the updated cache then 
//              apply the plus and the minus.
          else if (refreshedMidMap.get(deltaPerMid.getMID()).compareTo(deltaPerMid.getTimeStamp()) < 0)
          {
              queueExplorerDeltaUpdate(deltaPerMid.getCounterDeltaMap(), true,false);
          }
//                If it is not less (probably equal) then do not take into the calculation this updated entry.
          
      }

  }
  */           
     
  @Expose(type=ExposureType.InternalInterface)
  public Boolean shouldPerformSubtructions( Map<String, String> refreshedMidMap, CounterDeltaPerMidHolder deltaPerMid)
  {
	  String deltaMid = deltaPerMid.getMID();
	  boolean isRefreshedMapContainsMid = refreshedMidMap.containsKey(deltaMid);
	  
	  if (isRefreshedMapContainsMid && !(refreshedMidMap.get(deltaMid).compareTo(deltaPerMid.getTimeStamp()) < 0))
		  return null;
	  
	  return !isRefreshedMapContainsMid;
  }
  
  
  /** 
   * TODO: adapt to new API
   * 
  @Expose
  public final void performPendingCalculation(CounterDeltaPerMidHolder deltaPerMid, Map<String, String> refreshedMidMap)
  {
	  
  }
  
  private void putMidsList(List<String> midList)
  {
      if (midList.size() > 0)
      
      {
          Random random = new Random(new Date().getTime());
          String key = CacheKeys.qExplorerKey.isLocked() ? PENDING_PREFIX+random.nextLong() : random.nextLong()+""; 
          CacheKeys.pendingPDOKey.putSingle(key, midList);
      }
  }
  */ 
  
  /* 
   * TODO: adapt to new API
   
  public List performOngoingRecalculation(List<PDO> pdoList)
  {
//      Map<String, CounterDelta> deltaMap = new HashMap<String, CounterDelta>();
      
      List<CounterDeltaPerMidHolder> countersPerMidList = buildDeltaList(pdoList);

      if (CacheKeys.qExplorerKey.isLocked())
      {
          List<String> midList = buildMidsList(pdoList);
          if (midList.size() > 0)
          {
              Random random = new Random(new Date().getTime());
              CacheKeys.pendingPDOKey.putSingle(random.nextLong()+"", countersPerMidList);
          }
      }else
      {
          for (CounterDeltaPerMidHolder counterDeltaPerMidHolder : countersPerMidList)
          {
              queueExplorerDeltaUpdate(counterDeltaPerMidHolder.counterDeltaMap, true);
          }
      }
          
      
      //TODO: update MiscResources with time stamp if there was at least one iteration
      return countersPerMidList;        
  }
  */ 
  
  @Expose(type=ExposureType.InternalInterface)
  public final QExplorerTaskInput buildDeltaList(final List<PDO> pdoList) throws Exception{
	  
      final List<CounterDeltaPerMidHolder> countersPerMidList = new ArrayList<CounterDeltaPerMidHolder>();
     
      Map<String, CounterDelta> mapCountersDelta= null;
      
      Map<String, CounterDelta> mapGlobalCountersDelta= new HashMap<String, CounterDelta>();
      CounterDeltaPerMidHolder counterDeltaPerMid =  null ; 
      
      for (PDO pdo : pdoList) {
    	
    	  if(pdo.isThinMode() || pdo.isTransient()) continue ; 
    	  //else 
    	  counterDeltaPerMid = new CounterDeltaPerMidHolder(pdo.getMID()); 
    	  mapCountersDelta = counterDeltaPerMid.getCounterDeltaMap() ; 
    	  Admin.setContextPDO(pdo);
          
    	  //only exeucte the rules on the orignal payment if the payment is not a new one 
    	  //otherwise, execute both on the original and the current 
          if (!pdo.isNew()) this.deltaCalculation(mapCountersDelta,mapGlobalCountersDelta, true);
          
          this.deltaCalculation(mapCountersDelta, mapGlobalCountersDelta, false);
          
          counterDeltaPerMid.setTimeStamp(pdo.getString(PDOConstantFieldsInterface.P_TIME_STAMP)) ; 
          countersPerMidList.add(counterDeltaPerMid);
      }//EO while there are more pdos in the list 
       
      return (countersPerMidList.isEmpty() && mapGlobalCountersDelta.isEmpty() ? null : new QExplorerTaskInput(countersPerMidList, mapGlobalCountersDelta)) ; 
  }//EOM 
  
  private List<String> buildMidsList(List<PDO> pdoList)
  {
      List<String> midList = new ArrayList<String>();
      
      for (PDO pdo : pdoList)
      {
          midList.add(pdo.getMID());
      }
      
      return midList;
  }

  
  private List<String> buildMidsList(PDO[] pdoList)
  {
      List<String> midList = new ArrayList<String>();
      
      for (PDO pdo : pdoList)
      {
          midList.add(pdo.getMID());
      }
      
      return midList;
  }
  
  /**
   * TODO: adapt to new API
  
  private void queueExplorerDeltaUpdate(Map<String, CounterDelta> deltaMap, boolean isToAdd)
  {
      queueExplorerDeltaUpdate(deltaMap, isToAdd, false);
  }
  */ 
  
  /**
   * TODO: adapt to new API
   * 
  private void queueExplorerDeltaUpdate(Map<String, CounterDelta> deltaMap, boolean isToAdd, boolean onlyPositive)
  {
  //      boolean which indicates that queue explorer structure was updated, therefore, the queue explorer tree should be rebuild
      boolean isQueueExplorerStructureUpdated = false;

      Iterator iter = deltaMap.entrySet().iterator();
      while (iter.hasNext())
      {
          Entry<String, CounterDelta> entry = (Entry)iter.next();
          String key = entry.getKey();
          CounterDelta counterDelta = entry.getValue();
          if(this.queueExplorerDeltaUpdate(key, counterDelta, isToAdd, onlyPositive)) 
          {
			isQueueExplorerStructureUpdated = true;
          }
      }
//		queue explorer structure was updated, therefore, the queue explorer tree should be rebuild      
      if (isQueueExplorerStructureUpdated)
          CacheKeys.qExplorerKey.incVersion();
      
  }
  */ 
  
  /**
   * @returns Map<CacheActionType, Qexplorer> if the map is not empty, then there was a structure change. 
   * It is the responsibility of the client code to perform the actions on the cache   
   */
  @Expose(type=ExposureType.InternalInterface)
  public Map<QExplorer, CacheActionType> queueExplorerDeltaUpdate(String key, final CounterDelta counterDelta, boolean isToAdd, final boolean onlyPositive)
  {
	  final Map<QExplorer, CacheActionType> mapActions = new HashMap<QExplorer, CacheActionType>() ; 
	  
//	  final QExplorerKey qexplorerRegion = CacheKeys.qExplorerKey  ;
	  
	  final CacheRegionKeyInterface<QExplorer> qexplorerRegion = CacheKeys.qExplorerKey.getBackingRegion()  ;
	  CacheServiceInterface cache = CacheServiceInterface.eINSTANCE ; 
	  
	  boolean isQueueExplorerStructureUpdated = false;
      if(!onlyPositive || onlyPositive && counterDelta.counter >= 0 )
      {

          QExplorer qExplorer = (QExplorer) cache.getSingle(qexplorerRegion, key) ;
          
          if (counterDelta.counter != 0 || (counterDelta.counter == 0 && counterDelta.parentKey == null))
          {
//           new process date, create new cache entry according to office only 
              if (qExplorer == null && !GlobalUtils.isNullOrEmpty(counterDelta.parentKey))
              {
            	  qExplorer = (QExplorer) cache.getSingle(qexplorerRegion, counterDelta.parentKey) ;

            	  //                  new user defined queue which should be added during queue approval, this is the parent queue(without the process date)
//                  and it should be defined for child queue.
                  if (qExplorer == null)
                  {
                      qExplorer = new QExplorer(counterDelta.ruleUid,counterDelta.office, " ");
                      Prules prule = CacheKeys.PRulesUIDKey.getSingle(counterDelta.ruleUid);
                      
                      //TODO: talk with Dima about fixing the issue whereby the prules is null as the queue is not really a 
                      //new user defined rule and therefore should not enter this part 
                      if(prule == null) return mapActions;
                      
                      qExplorer.setAlias(prule.getRuleName());
                      qExplorer.setRuleName(prule.getRuleName());
                      qExplorer.setQueuegroupid(999l);
                      qExplorer.setQType(QueueType.UDQ.name());
                      updateQExplorer(qExplorer,0,0,1, true);
                      //qexplorerRegion.putSingle(qExplorer) ;
                      mapActions.put(qExplorer, CacheActionType.PutSingle) ; 
                  }
                   
                  qExplorer = new QExplorer(qExplorer);
                  qExplorer.getId().setProcessDate(counterDelta.processDate);
                  isQueueExplorerStructureUpdated = true;
              }else if (qExplorer == null)
              {//this is parent UDQ which has bee approved 
                  qExplorer = new QExplorer(counterDelta.ruleUid,counterDelta.office, " ");
                  Prules prule = CacheKeys.PRulesUIDKey.getSingle(counterDelta.ruleUid);
                  
                  //TODO: talk with Dima about fixing the issue whereby the prules is null as the queue is not really a 
                  //new user defined rule and therefore should not enter this part 
                  if(prule == null) return mapActions ; 
                  
                  qExplorer.setAlias(prule.getRuleName());
                  qExplorer.setQType(QueueType.UDQ.name());
                  qExplorer.setRuleName(prule.getRuleName());
                  qExplorer.setQueuegroupid(999l);
              } 
              
              if (qExplorer != null )
              {
                  updateQExplorer(qExplorer,counterDelta.amount,counterDelta.counter,1,isToAdd);
                  //qexplorerRegion.putSingle(qExplorer) ;
                  mapActions.put(qExplorer, CacheActionType.PutSingle) ; 
                  
//                  if the counter equals 0, then no entries for specified process date, therefore this entry should be removed.
                  if (qExplorer.getQCount() == 0 && qExplorer.getId().getProcessDate().length() > 2)
                  {
                	//qexplorerRegion.removeSingle(qExplorer);
                	mapActions.put(qExplorer, CacheActionType.RemoveSingle) ; 
                    isQueueExplorerStructureUpdated = true;
                  }
                  
              }else
              {
                  ErrorAuditInputData eaInputData=new ErrorAuditInputData();
                  eaInputData.setErrorCode((long)ProcessErrorConstants.StatusNotFound);
                  eaInputData.setNonPaymentsFields(new String[]{key});
                  eaInputData.setWriteToDB(false);
    
                  ErrorAuditUtils.handleErrorAndAudit(eaInputData);
              }
          }
      }
      
      return mapActions;
	  
  }
  
  private void deltaCalculation(Map<String, CounterDelta> deltaMap,Map<String, CounterDelta> globalDeltaMap, boolean onOriginal) throws Exception {
     
      int sign = onOriginal ? -1 : 1;
      PDO pdo = Admin.getContextPDO();
      String office=onOriginal ? (String)pdo.getOriginalValue(PDOConstantFieldsInterface.P_OFFICE) 
                        : pdo.getString(PDOConstantFieldsInterface.P_OFFICE);
      
      List<RuleResult> ruleResultList= m_internalRuleExecutionLogging.executeRule(Admin.getContextAdmin(), MessageConstantsInterface.RULE_TYPE_ID_USER_DEFINED_QUEUE,null,pdo.getMID()
                    ,onOriginal,new String[]{"***"}).getResults();
      double amount;
      
      Date historyProcDate = CacheKeys.banksKey.getSingle(office).getHistoryProcDt();
      Date processDate = onOriginal ? (Date)pdo.getOriginalValue(PDOConstantFieldsInterface.P_PROC_DT) : pdo.getDate(PDOConstantFieldsInterface.P_PROC_DT);
      String msgStatus = onOriginal ? (String)pdo.getOriginalValue(PDOConstantFieldsInterface.P_MSG_STS) : pdo.getString(PDOConstantFieldsInterface.P_MSG_STS);
      
      boolean isFinalStatus = isFinalStatus(msgStatus); 

      
//          check the history date
      if (historyProcDate == null || processDate == null || !isFinalStatus || GlobalDateTimeUtil.isDateAfterDate(processDate, historyProcDate))
      {
          if (processDate != null)
              processDate = new java.sql.Date(processDate.getTime());
          String strProcDate = processDate!= null ? processDate.toString() : BOQueueExplorer.EMPTY_DATE_VALUE;
          
          if (onOriginal)
              amount = pdo.getOriginalValue(PDOConstantFieldsInterface.P_BASE_AMT) != null 
                                ? ((BigDecimal)pdo.getOriginalValue(PDOConstantFieldsInterface.P_BASE_AMT)).doubleValue() : 0;
          else
              amount = pdo.getDecimal(PDOConstantFieldsInterface.P_BASE_AMT) != null 
                                    ? pdo.getDecimal(PDOConstantFieldsInterface.P_BASE_AMT).doubleValue() : 0;
          for (RuleResult ruleResult : ruleResultList)
          {
              updateDataMap(ruleResult.getRuleUID(),office,strProcDate,sign,amount,1,deltaMap);
              updateDataMap(ruleResult.getRuleUID(),office,strProcDate,sign,amount,1,globalDeltaMap);
          }
          String ruleUid = "***^2^"+(onOriginal ? (String)pdo.getOriginalValue(PDOConstantFieldsInterface.P_MSG_STS) 
                  : pdo.getString(PDOConstantFieldsInterface.P_MSG_STS));
          
          updateDataMap(ruleUid,office,strProcDate,sign,amount,1,deltaMap);
          updateDataMap(ruleUid,office,strProcDate,sign,amount,1,globalDeltaMap);
      }
  }
  
  
  private void updateDataMap(String ruleUid, String office,String strProcDate, int sign, double amount, int count, Map<String, CounterDelta> deltaMap)
  {
      
      String parentKey = ruleUid + GlobalConstants.POWER_SIGN + office + GlobalConstants.POWER_SIGN + " ";
      String childKey = ruleUid + GlobalConstants.POWER_SIGN + office + GlobalConstants.POWER_SIGN + strProcDate;
      
      CounterDelta counterDelta=null;
      if (!deltaMap.containsKey(childKey))
      {
          counterDelta = new CounterDelta();
//                      save the office key in case this is new entry for process date and it will be created according to 
//                      entry with office
          if (strProcDate.length() > 0)
          {
//                          the parent key is always without a process date, therefore the third place should be empty
              counterDelta.parentKey = parentKey;
              counterDelta.processDate = strProcDate;
              counterDelta.ruleUid = ruleUid;
              counterDelta.office = office;
          }
          
          deltaMap.put(childKey, counterDelta);
      }
      
      
      if (!deltaMap.containsKey(parentKey))
      {
          counterDelta = new CounterDelta();
          counterDelta.ruleUid = ruleUid;
          counterDelta.office = office;
          counterDelta.processDate = " ";
          deltaMap.put(parentKey, counterDelta);
      }
      counterDelta = deltaMap.get(childKey);
      setCounterDelta(counterDelta, sign, amount,count);                   

      counterDelta = deltaMap.get(parentKey);
      setCounterDelta(counterDelta, sign, amount,count);                   
      
  }
  
  
  private void ongoingAccumulationsUndo(Map<String, CounterDelta> deltaMap)
  {
      Iterator iter = deltaMap.entrySet().iterator();
      
      while (iter.hasNext())
      {
          Entry entry = (Entry)iter.next();
          String key = (String)entry.getKey();
          CounterDelta counterDelta = (CounterDelta)entry.getValue();
          QExplorer qExplorer = CacheKeys.qExplorerKey.getSingle(key);
          if (qExplorer != null)
          {
              qExplorer.setQCount(qExplorer.getQCount() - counterDelta.counter);
              qExplorer.setQTotalBaseAmount(qExplorer.getQTotalBaseAmount() - counterDelta.amount);
              qExplorer.setTimeStamp(qExplorer.getPrevTimeStamp());
          }
      }
      
  }
  
  private void setCounterDelta(CounterDelta counterDelta, int sign, double amount, int count)
  {
      counterDelta.counter+=(count*sign);
      counterDelta.amount+=(amount*sign);
//      counterDelta.timeStamp=GlobalDateTimeUtil.getCurrentDateAndTime(GlobalDateTimeUtil
//              .getSimpleDateFormatByFormat(GlobalDateTimeUtil.STATIC_DATA_TIME_STAMP), GlobalDateTimeUtil
//                                    .getSimpleDateFormatByFormat(GlobalDateTimeUtil.STATIC_DATA_TIME_STAMP))[0];
  }
  
  
  
  
//  private Feedback getNewQueuesData(Object[] arrQueuesDataHolder, int[] arrNumOf_STATUSES_COUNTERS_Entries)
//  {
//    long lStart = System.currentTimeMillis();
//    
////      arrNumOf_STATUSES_COUNTERS_Entries[0]=fillUpQExplorerCache();
//      Iterator iter=Cache.getInstance().getIterator(CacheKeys.qExplorerKey);
//      QExplorer qExplorer=null;
//      List<Object[]> list = new ArrayList<Object[]>();
//      Object[] arrOneQueueData;
//      Set<String> ruleSet = new HashSet<String>();
//      
//      while(iter.hasNext())
//      {
//          String key = (String)((Map.Entry)iter.next()).getKey();
//          qExplorer = CacheKeys.qExplorerKey.getSingle(key);
//          if (qExplorer == null)
//              continue ;
//          if (!ruleSet.contains(qExplorer.getRuleName()))
//          {
//              ruleSet.add(qExplorer.getRuleName());
//              arrOneQueueData = new Object[10];
//              arrOneQueueData[0] = qExplorer.getRuleName(); // Queue name.
//              arrOneQueueData[1] = qExplorer.getAlias(); // Alias.
//              arrOneQueueData[2] = qExplorer.getQueuegroupid(); // Parent ID.
//              arrOneQueueData[3] = 0; // Count status.
//              arrOneQueueData[4] = ServerConstants.EMPTY_STRING; // Not in use.
//              arrOneQueueData[5] = qExplorer.getQType().equals("STATUS") ? 1 : 0; // User define flag.
//              arrOneQueueData[6] = "0"; // Total amount.
//              arrOneQueueData[7] = ServerConstants.EMPTY_STRING; ; // Office.
//              arrOneQueueData[8] = ServerConstants.EMPTY_STRING; // Currency.
//              arrOneQueueData[9] = HIGH_VALUE; // 'H' for HIGH VALUE status. 
//              list.add(arrOneQueueData);
//          }
//          arrOneQueueData = new Object[10];
//          arrOneQueueData[0] = qExplorer.getRuleName(); // Queue name.
//          arrOneQueueData[1] = qExplorer.getAlias(); // Alias.
//          arrOneQueueData[2] = qExplorer.getQueuegroupid(); // Parent ID.
//          arrOneQueueData[3] = qExplorer.getQCount(); // Count status.
//          arrOneQueueData[4] = ServerConstants.EMPTY_STRING; // Not in use.
//          arrOneQueueData[5] = qExplorer.getQType().equals("STATUS") ? 1 : 0; // User define flag.
//          arrOneQueueData[6] = Double.toString(qExplorer.getQTotalBaseAmount()); // Total amount.
//          arrOneQueueData[7] = qExplorer.getQExplorerId().getOffice(); // Office.
//          arrOneQueueData[8] = qExplorer.getCurrency() == null ?ServerConstants.EMPTY_STRING : qExplorer.getCurrency(); // Currency.
//          arrOneQueueData[9] = HIGH_VALUE; // 'H' for HIGH VALUE status. 
//          list.add(arrOneQueueData);
//      }
//      int iQueuesDataSize = list.size();
//      Object[][] arrQueuesData = new Object[iQueuesDataSize][];
//      for(int i=0; i<iQueuesDataSize; i++)
//        arrQueuesData[i] = (Object[])list.get(i);
//
//      arrQueuesDataHolder[0] = arrQueuesData;
//      
//      System.out.println("XXXXXXXXXXXXXXX = " + (System.currentTimeMillis() - lStart));
//      return new Feedback();
//  }
  
  
  /**
   * TODO: adapt to new API
  private void performCountersCleanup()
  {
          QExplorer qExplorer;
          Iterator<QExplorer> iter= CacheKeys.qExplorerKey.getListIterator();
          while(iter.hasNext())
          {
             // String key = (String)((Map.Entry)iter.next()).getKey();
              //qExplorer = CacheKeys.qExplorerKey.getSingle(key);
        	  qExplorer = (QExplorer) ((Map.Entry)iter.next()).getValue();
              if (qExplorer != null && (qExplorer.getQCount() != 0 || qExplorer.getQTotalBaseAmount() != 0))
              {
                  qExplorer.setQCount(0l);
                  qExplorer.setQTotalBaseAmount(0d);
                  qExplorer.setTimeStamp(GlobalDateTimeUtil.getServerTimeStamp());
              }
          }
          

  }
  */ 
  
  private String queueCounterCalc(String mid, final Map<String, QExplorer> tempQexplorerBuffer)
  {
      return queueCounterCalc(mid, tempQexplorerBuffer, false);
  }
  
  
  private String queueCounterCalc(PDO pdo, final Map<String, QExplorer> tempQexplorerBuffer, boolean onOriginals)
  {
	  final CacheKeys.QExplorerKey qexplorerRegion = CacheKeys.qExplorerKey ; 
	  
	  
      QExplorer qExplorer;      
      String[] objectId = new String[1];
      Feedback feedback = new Feedback();
      String office=onOriginals ? (String)pdo.getOriginalValue(PDOConstantFieldsInterface.P_OFFICE) 
              : pdo.getString(PDOConstantFieldsInterface.P_OFFICE);

		String timeStamp = onOriginals ? (String)pdo.getOriginalValue(PDOConstantFieldsInterface.P_TIME_STAMP) 
		              : pdo.getString(PDOConstantFieldsInterface.P_TIME_STAMP);
		
		String msgStatus = onOriginals ? (String)pdo.getOriginalValue(PDOConstantFieldsInterface.P_MSG_STS) 
	              : pdo.getString(PDOConstantFieldsInterface.P_MSG_STS);
		objectId[0] = "***";
		int sign = onOriginals ? -1 : 1;
		try
		{
		double amount;
		if (onOriginals)
			amount = pdo.getOriginalValue(PDOConstantFieldsInterface.P_BASE_AMT) != null 
			                  ? ((BigDecimal)pdo.getOriginalValue(PDOConstantFieldsInterface.P_BASE_AMT)).doubleValue() : 0;
		else
			amount = pdo.getDecimal(PDOConstantFieldsInterface.P_BASE_AMT) != null 
			                  ? pdo.getDecimal(PDOConstantFieldsInterface.P_BASE_AMT).doubleValue() : 0;
			                  
		List<RuleResult> ruleResultList= m_internalRuleExecutionLogging.executeRule(Admin.getContextAdmin(), MessageConstantsInterface.RULE_TYPE_ID_USER_DEFINED_QUEUE,null,pdo.getMID()
		    ,onOriginals,objectId).getResults();
		Banks officeRec = CacheKeys.banksKey.getSingle(office);
		if (officeRec != null)
		{
			Date historyProcDate = officeRec.getHistoryProcDt();
			Date processDate = onOriginals ? (Date)pdo.getOriginalValue(PDOConstantFieldsInterface.P_PROC_DT) : pdo.getDate(PDOConstantFieldsInterface.P_PROC_DT);
			
	        boolean isFinalStatus = isFinalStatus(msgStatus);
			
			if (historyProcDate == null || processDate == null || !isFinalStatus || processDate.after(historyProcDate))
			{
				String strProcDate = processDate!= null ? processDate.toString() :EMPTY_DATE_VALUE;
				
				String sProcDateQExplorerKey = null ;
					
				for (RuleResult ruleResult : ruleResultList)
				{
				    String ruleUid = ruleResult.getRuleUID();
				    qExplorer = tempQexplorerBuffer.get(qexplorerRegion.constructCacheEntryKey(new Object[] { ruleUid,office, " " } ).get(0)) ; 
				    if (qExplorer == null)
				    {
				    	String status = "";
				    	
				    	if (ruleUid != null)
				    	{
				    		String[] arr = ruleUid.split("\\^");
				    		if (arr!= null && arr.length > 2) status = arr[2];
				    	}
				    	ErrorAuditUtils.setError(ProcessErrorConstants.QueueNotfound, null, feedback, status);
				    }else
				    {
				    	//as the instance refrence is already in the map, there is no need to put is again 
				        updateQExplorer(qExplorer,amount,sign);
				//        qExplorerMap.put(ruleUid+"^"+office, qExplorer);
				        
				    sProcDateQExplorerKey = qexplorerRegion.constructCacheEntryKey(new Object[] { ruleUid,office,strProcDate }).get(0)  ; 
				    QExplorer qExplorerForProcessDate =  tempQexplorerBuffer.get(sProcDateQExplorerKey) ; 
				    if (qExplorerForProcessDate == null)
				    {
				        qExplorerForProcessDate = new QExplorer(qExplorer);
				        qExplorerForProcessDate.getId().setProcessDate(strProcDate);
				        qExplorerForProcessDate.setCurrentTimestamp();
				        tempQexplorerBuffer.put(sProcDateQExplorerKey, qExplorerForProcessDate);
				        
				    }else//set status active to view the node
				    {
				    	qExplorerForProcessDate.setRecStatus(LayoutConstants.REC_STATUS_ACTIVE);
				    }
				    //as the instance refrence is already in the map, there is no need to put is again
				    updateQExplorer(qExplorerForProcessDate,amount,sign);
				//    qExplorerMap.put(ruleUid+"^"+office+"^"+strProcDate, qExplorerForProcessDate);
				    }
				}
				String status = onOriginals ? (String)pdo.getOriginalValue(PDOConstantFieldsInterface.P_MSG_STS) 
				        : pdo.getString(PDOConstantFieldsInterface.P_MSG_STS);
				String uid = "***^2^"+status;
				qExplorer = tempQexplorerBuffer.get(qexplorerRegion.constructCacheEntryKey(new Object[] { uid,office, " " } ).get(0)) ;
				if (qExplorer != null)
				{
					//as the instance refrence is already in the map, there is no need to put is again
				    updateQExplorer(qExplorer,amount,sign);
				//    qExplorerMap.put(uid+"^"+office, qExplorer);
				   
				    sProcDateQExplorerKey = qexplorerRegion.constructCacheEntryKey(new Object[] { uid,office,strProcDate }).get(0)  ; 
				    
				    QExplorer qExplorerForProcessDate = tempQexplorerBuffer.get(sProcDateQExplorerKey) ;
				    if (qExplorerForProcessDate == null)
				    {
				        qExplorerForProcessDate = new QExplorer(qExplorer);
				        qExplorerForProcessDate.setCurrentTimestamp();
				        qExplorerForProcessDate.getId().setProcessDate(strProcDate);
				        tempQexplorerBuffer.put(sProcDateQExplorerKey, qExplorerForProcessDate);
				    }else //set status active to view the node
				    {
				    	qExplorerForProcessDate.setRecStatus(LayoutConstants.REC_STATUS_ACTIVE);
				    }
				   //as the instance refrence is already in the map, there is no need to put is again
				    updateQExplorer(qExplorerForProcessDate,amount,sign);
				//    qExplorerMap.put(uid+"^"+office+"^"+processDate, qExplorerForProcessDate);
				    
				}else
					ErrorAuditUtils.setError(ProcessErrorConstants.QueueNotfound, null, feedback, status);
			}
			//{
			////office = processDate.toString();
			//String uid = "***^2^HISTORY";
			//qExplorer = CacheKeys.qExplorerKey.getSingle(uid,office);
			//if (qExplorer == null)
			//{
			//    qExplorer = new QExplorer(uid,office,"");
			//    qExplorer.setRuleName("HISTORY");
			//    qExplorer.setQType("STATUS");
			//    qExplorer.setAlias("History");
			//    qExplorer.setQueuegroupid(13);
			//    qExplorer.getQExplorerId().setProcessDate(processDate);
			//    CacheKeys.qExplorerKey.putSingle(qExplorer);
			//}
			//updateQExplorer(qExplorer,0,sign);
			//qExplorerMap.put(uid+"^"+office, qExplorer);
			//
			//}
			}
		}
		catch(Exception e)
		{
			logger.error(e.getMessage());
		}
		
		
	  return timeStamp;
  }
  
  
  private String queueCounterCalc(String mid, final Map<String, QExplorer> tempQexplorerBuffer, boolean onOriginals)
  {
    
      PDO pdo = PaymentDataFactory.load(mid);
      return this.queueCounterCalc(pdo, tempQexplorerBuffer, onOriginals);
  }
  
  
   
  private void updateQExplorer(QExplorer qExplorer, double amount, int sign)
  {
      this.updateQExplorer(qExplorer,amount,1,sign, true);
  }

  
  
  private void updateQExplorer(QExplorer qExplorer, double amount, int count, int sign, boolean isToAdd)
  {
      qExplorer.setQCount(isToAdd ? qExplorer.getQCount()+(count*sign) : (count*sign));
      qExplorer.setQTotalBaseAmount(isToAdd ? qExplorer.getQTotalBaseAmount() + (amount*sign) : (amount*sign));
      qExplorer.setPrevTimeStamp(qExplorer.getTimeStamp());
      qExplorer.setCurrentTimestamp() ; 
      
//      CacheKeys.qExplorerKey.putSingle(qExplorer);
  }
  
  
  
  @Expose(type=ExposureType.InternalInterface)
  public Map<String, String> fillUpQExplorerCache(final Map<String, QExplorer> qExplorerMap){
    String MID_COLUMN ="P_MID"; 
    Connection conn = null;
    PreparedStatement ps = null; 
    ResultSet rs = null;
    Map<String, String> midMap = new HashMap<String, String>();
    try
    {
    	conn = m_daoQueueExplorer.getConnection();
    	
    	ps = m_daoQueueExplorer.getFullCalcPrepareStatement(conn);

    	rs = ps.executeQuery();
    	int i=0;
    	while(rs.next())
    	{
    		PDO pdo = PaymentDataFactory.load(rs);
    		String timeStamp = queueCounterCalc(pdo, qExplorerMap, false);
    		midMap.put(pdo.getMID(), timeStamp);
    		
    		System.err.println("PDO number = "+(i++));
    	}
    }catch(Exception e){
    	ExceptionController.getInstance().handleException(e, this);
    }finally
    {
    	m_daoQueueExplorer.releaseResources(rs,ps,conn);
    }
    return midMap;
  }
  

  @Expose(type=ExposureType.InternalInterface)
  public void calcluateSinglePayment(ResultSet rs, Map<String, QExplorer> qExplorerMap, Map<String, String> midMap)
  {
		PDO pdo = PaymentDataFactory.load(rs);
		String timeStamp = queueCounterCalc(pdo, qExplorerMap, false);
		midMap.put(pdo.getMID(), timeStamp);
  }
  
  @Expose(type=ExposureType.InternalInterface)
  public PreparedStatement getPaymentsForCalculation(Connection conn)
  {
	  
	  PreparedStatement ps = null; 
	  Map<String, String> midMap = new HashMap<String, String>();
	  try
	  {
		  conn = m_daoQueueExplorer.getConnection();
	    	
		  ps = m_daoQueueExplorer.getFullCalcPrepareStatement(conn);
	    	
	  }catch(Exception e){
		  ExceptionController.getInstance().handleException(e, this);
	  }
	  
	  return ps;
  }
  /**
   * Returns the value of the settlement date which is the minimum date to display
   * as a sub node in a LOW VALUE status.
   */
  private String getMinSettlementDateForLowValueStatuses()
  {
    final String ERROR_MESSAGE_PREFIX = "BOQueueExplorer.getMinSettlementDateForLowValueStatuses - ";
    
     
    
    String sMinSettlementDate = null;
    
    DTOSingleValue dto = m_daoQueueExplorer.getMinSettlementDateForLowValueStatuses(m_iQExplorerMinSettlementDays);
    
    Feedback feedback = dto.getFeedBack();
    
    if(feedback.isSuccessful() && !dto.isEmpty())
    {
      sMinSettlementDate = dto.getValue();
    }
    
    else
    {
      final String ERROR_MESSAGE_NO_SETTLEMENT_DATE = "can't get minimum settlement date from ACC_POS table; table is probably empty !!!";
      
      boolean bEmptyDTO = dto.isEmpty();
      
      String sErrorMessage = new StringBuffer(ERROR_MESSAGE_PREFIX)
                                      .append(bEmptyDTO? ERROR_MESSAGE_NO_SETTLEMENT_DATE :ServerUtils.getFeedbackString(feedback)).toString();
      logger.error(sErrorMessage);
    }
    
    // Couldn't get settlement date from ACC_POS table; takes instead the value of
    // MOP.MOPBUSINESSDATE for MOP 'FPS'.
    if(sMinSettlementDate == null)
    {
      final String[] ARR_TABLE_NAMES = {ServerConstants.TABLE_NAME_MOP};
      final String COLUMN_NAME_MOP = "MOP";
      final String COLUMN_VALUE = "FPS";
      final String[] ARR_FIELD_NAMES = {"MOPBUSINESSDATE"};
      final int[] ARR_FIELD_NAMES_TYPES = {Types.DATE};

      DTODataHolder dtoMOPBusinessDate = 
             m_daoQueueExplorer.getSpecificRecordDataFromTable(null, ARR_TABLE_NAMES, COLUMN_NAME_MOP,
                                                               Types.VARCHAR, COLUMN_VALUE, 
                                                               ARR_FIELD_NAMES, ARR_FIELD_NAMES_TYPES);
      
     feedback = dtoMOPBusinessDate.getFeedBack();
    
     if(feedback.isSuccessful() && !dto.isEmpty())
     {
       sMinSettlementDate = (String)dtoMOPBusinessDate.getDataRow().get(ARR_FIELD_NAMES[0]);
     }
     
     else
     {
      final String ERROR_MESSAGE_NO_BUSINESS_DATE_FOR_MOP_FPS = "can't get business date (MOP.MOPBUSINESSDATE) for MOP 'FPS' from MOP table; check if record exists !!!";
      
      boolean bEmptyDTO = dto.isEmpty();
      
      String sErrorMessage = new StringBuffer(ERROR_MESSAGE_PREFIX)
                                      .append(bEmptyDTO? ERROR_MESSAGE_NO_BUSINESS_DATE_FOR_MOP_FPS :ServerUtils.getFeedbackString(feedback)).toString();
      logger.error(sErrorMessage);
     }
    }
    
    final String RESULT_MESSAGE = "Minimum settlement date is: ";
    String sResultMessage = new StringBuffer(RESULT_MESSAGE).append(sMinSettlementDate).toString();
    logger.trace(sResultMessage);
    
     
    
    return sMinSettlementDate;
  }
  
  /**
   * Returns a HashMap in which: 
   *  Key - Low value status.
   *  Value - Object[2] in which:
   *           index 0 - sum of COUNT_STATUS column for all settlement dates for this status.
   *           index 1 - sum of SUM_BASE_AMOUNT column for all settlement dates for this status.
   */
  private HashMap getLowValueStatusesParentsDataHM()
  {
    HashMap hmLowValueStatusesParents = new HashMap();
    
    DTODataHolder dto = m_daoQueueExplorer.getLowValueStatusesParentsDataFromSTATUSES_COUNTERS();
    
    Feedback feedback = dto.getFeedBack();
    
    if(feedback.isSuccessful())
    {
      ArrayList alData = dto.getDataAL();
      int iSize = alData.size();
      
      for(int i=0; i<iSize; i++)
      {
        HashMap hmCurrentStatus = (HashMap)alData.get(i);
        
        String sStatus = (String)hmCurrentStatus.get(COLUMN_STATUSES_COUNTERS_STATUS);
        
        String sCountStatus = (String)hmCurrentStatus.get(COLUMN_STATUSES_COUNTERS_COUNT_STATUS);
        Long lCountStatus = Long.valueOf(sCountStatus);
        
        String sSumBaseAmount = (String)hmCurrentStatus.get(COLUMN_STATUSES_COUNTERS_SUM_BASE_AMOUNT);
        sSumBaseAmount = sSumBaseAmount.equals(ServerConstants.EMPTY_STRING) ? ServerConstants.ZERO_VALUE : sSumBaseAmount;
        
        hmLowValueStatusesParents.put(sStatus, new Object[]{lCountStatus, sSumBaseAmount});
      }
    }
    
    else
    {
      final String ERROR_MESSAGE_PREFIX = "BOQueueExplorer.getLowValueStatusesParentsHM - ";
      String sErrorMessage = new StringBuffer(ERROR_MESSAGE_PREFIX).append(ServerUtils.getFeedbackString(feedback)).toString();
      logger.error(sErrorMessage);
    }
    return hmLowValueStatusesParents;
  }
  
  /**
   * Parses the queues data.
   */
  private Feedback parseQueuesData(ArrayList alStatusesData, Object[] arrQueuesDataHolder)
  {
    final String COLUMN_STATUSES_MSG_STATUS = "MSG_STATUS";
    final String COLUMN_STATUSES_ALIAS = "ALIAS";
    final String COLUMN_STATUSES_QUEUEGROUPID = "QUEUEGROUPID";
    final String COLUMN_STATUSES_USERDEFINE = "USERDEFINE";
    final String COLUMN_STATUSES_MSG_TABLE = "MSG_TABLE";
    
    final Object[] ARR_EMPTY_LOW_VALUE_STATUS_PARENT_DATA = {Long.valueOf(0), ServerConstants.EMPTY_STRING};
    
     
    
    Feedback feedback = new Feedback();
    ArrayList alQueuesData = new ArrayList();
    
    int iSize = alStatusesData.size();
    
    // This minimum settlement date is determined only ONCE and being used
    // for all LOW VALUE statuses.                       
    String sMinSettlementDate = getMinSettlementDateForLowValueStatuses();
    
    // HashMap in which: Key - Low value status.
    //                   Value - Object[2] in which:
    //                            index 0 - sum of COUNT_STATUS column for all settlement dates for this status.
    //                            index 1 - sum of SUM_BASE_AMOUNT column for all settlement dates for this status.   
    HashMap hmLowValueStatusesParentsData = getLowValueStatusesParentsDataHM();
    
    for(int i=0; i<iSize; i++)
    {
      // Gets current status data.
      HashMap hmOneStatusData = (HashMap)alStatusesData.get(i);
      
      String sMsgStatus = (String)hmOneStatusData.get(COLUMN_STATUSES_MSG_STATUS);
      String sAlias = (String)hmOneStatusData.get(COLUMN_STATUSES_ALIAS);
      String sQueueGroupID = (String)hmOneStatusData.get(COLUMN_STATUSES_QUEUEGROUPID);
      String sUserDefine = (String)hmOneStatusData.get(COLUMN_STATUSES_USERDEFINE);
      
      // The MSG_TABLE value from STATUSES table which specifies if this status 
      // is related to a high value payment or a low value payment, where possible 
      // options are 'MIF'/'LVMIF', for high/low.      
      String sMsgTable = (String)hmOneStatusData.get(COLUMN_STATUSES_MSG_TABLE);
      sMsgTable = !sMsgTable.equals(ServerConstants.EMPTY_STRING) ? sMsgTable : ServerConstants.TABLE_NAME_MIF;
      boolean bHighValueStatus = ServerConstants.TABLE_NAME_MIF.equalsIgnoreCase(sMsgTable);
      
      // Gets right DTO according to HV or LV.
      DTODataHolder dto = bHighValueStatus ?
                          m_daoQueueExplorer.getOneHighValueStatusDataFromSTATUSES_COUNTERS(sMsgStatus) :
                          m_daoQueueExplorer.getOneLowValueStatusDataFromSTATUSES_COUNTERS(sMsgStatus, sMinSettlementDate);
        
      feedback = dto.getFeedBack();
      
      if(feedback.isSuccessful())
      {
        boolean bEmptyDTO = dto.isEmpty();
        
        // HV status.
        if(bHighValueStatus)
        {
          updateQueuesDataALForHighValueStatus(sMsgStatus, sAlias, sQueueGroupID, sUserDefine, dto, alQueuesData);
        }
          
        // LV status.
        else
        {
          Object[] arrLowValueStatusParentData = null;
          
          if(!bEmptyDTO)
          {
            // Gets the sum of COUNT_STATUS and the sum of SUM_BASE_AMOUNT for all
            // settlement dates of this low value status.
            // This will be used for the parent node of this status.
            arrLowValueStatusParentData = (Object[])hmLowValueStatusesParentsData.get(sMsgStatus);
          }
          
          else
          {
            arrLowValueStatusParentData = ARR_EMPTY_LOW_VALUE_STATUS_PARENT_DATA;
            
            // Writes notification into the trace file.
            final String WARNING_MESSAGE = "BOQueueExplorer.parseQueuesData() - no data found in STATUSES_COUNTERS table for ";
            final String LOW_VALUE_STATUS = "LOW value status: ";
            final String HIGH_VALUE_STATUS = "HIGH value status: ";
            
            String sWarningMessage = new StringBuffer(WARNING_MESSAGE)
                                              .append(bHighValueStatus? HIGH_VALUE_STATUS : LOW_VALUE_STATUS)
                                              .append(sMsgStatus).toString();
            logger.warn(sWarningMessage);
          }
          
          updateQueuesDataALForLowValueStatus(sMsgStatus, sAlias, sQueueGroupID, sUserDefine, dto, 
                                              alQueuesData, arrLowValueStatusParentData);
        }
      }
    }
    
    // // Updates the passed holder array.
    int iQueuesDataSize = alQueuesData.size();
    Object[][] arrQueuesData = new Object[iQueuesDataSize][];
    for(int i=0; i<iQueuesDataSize; i++)
    {
      arrQueuesData[i] = (Object[])alQueuesData.get(i);
    }
    //
    arrQueuesDataHolder[0] = arrQueuesData;
    
     
    
    return feedback;
  }
  
  /**
   * Updates the passed queues data ArrayList with one HIGH VALUE status data 
   * along with all sub queues of this status per office.
   */
  private void updateQueuesDataALForHighValueStatus(String sMsgStatus, String sAlias, 
                                                    String sQueueGroupID, String sUserDefine,
                                                    DTODataHolder dtoStatusData,
                                                    ArrayList alQueuesData)
  {
     
    
    Object[] arrOneQueueData = null;
    
    HashMap hmTotalStatusData = new HashMap();
    int iSize = dtoStatusData.getRowsNumber();
    
    ArrayList alOfficeAmountData = new ArrayList();
    
    int iCountStatus = 0;
    int iSumBaseAmount = 0;
    
    // STEP 1 - 
    // Loops all entries for this status and prepares the required data.
    for(int i=0; i<iSize; i++)
    {
      HashMap hmOneStatusData = dtoStatusData.getDataRow(i);
      
      // STATUSES_COUNTERS.COUNT_STATUS column.
      String sCountStatus = (String)hmOneStatusData.get(COLUMN_STATUSES_COUNTERS_COUNT_STATUS);
      iCountStatus += Integer.valueOf(sCountStatus).intValue();
      
      // STATUSES_COUNTERS.SUM_BASE_AMOUNT column.
      String sSumBaseAmount = (String)hmOneStatusData.get(COLUMN_STATUSES_COUNTERS_SUM_BASE_AMOUNT);
      sSumBaseAmount = sSumBaseAmount.equals(ServerConstants.EMPTY_STRING) ? ServerConstants.ZERO_VALUE : sSumBaseAmount;
      iSumBaseAmount += Integer.valueOf(sSumBaseAmount).intValue();
      
      // STATUSES_COUNTERS.OFFICE_AMOUNT column.
      alOfficeAmountData.add((String)hmOneStatusData.get(COLUMN_STATUSES_COUNTERS_OFFICE_AMOUNT));
    }
    
    // STEP 2 - 
    // Enters the data for the top level queue, (i.e. the one that includes data of
    // all offices).
    arrOneQueueData = new Object[10];
    arrOneQueueData[0] = sMsgStatus; // Queue name.
    arrOneQueueData[1] = sAlias; // Alias.
    arrOneQueueData[2] = Integer.valueOf(sQueueGroupID); // Parent ID.
    arrOneQueueData[3] = Integer.valueOf(iCountStatus); // Count status.
    arrOneQueueData[4] = ServerConstants.EMPTY_STRING; // Not in use.
    arrOneQueueData[5] = sUserDefine; // User define flag.
    arrOneQueueData[6] = Integer.valueOf(iSumBaseAmount).toString(); // Total amount.
    arrOneQueueData[7] = ServerConstants.EMPTY_STRING; // Office.
    arrOneQueueData[8] = ServerConstants.EMPTY_STRING; // Currency.
    arrOneQueueData[9] = HIGH_VALUE; // 'H' for HIGH VALUE status.
    
    alQueuesData.add(arrOneQueueData);
    
    // STEP 3 - 
    // Handles the sub-queues, (i.e. the queues that specifies data per office).
    if(!alOfficeAmountData.isEmpty())
    {
      int iOfficeAmountDataSize = alOfficeAmountData.size();
      
      // HashMap in which: Key - office.
      //                   Value - Object[10] of queue data for this office.
      HashMap hmOfficeAmountData = new HashMap();
      
      for(int i=0; i<iOfficeAmountDataSize; i++)
      {
        String sCurrentOfficeAmountData = (String)alOfficeAmountData.get(i);
        
        int iLastIndex = 0;
        
        while(iLastIndex < sCurrentOfficeAmountData.length())
        {
          String sCurrOfficeData = sCurrentOfficeAmountData.substring(iLastIndex, iLastIndex+51);
          
          arrOneQueueData = new Object[10];
          arrOneQueueData[0] = sMsgStatus; // Queue name.
          arrOneQueueData[1] = sAlias; // Alias.
          arrOneQueueData[2] = Integer.valueOf(sQueueGroupID); // Parent ID.
          
          String sStatusCount = sCurrOfficeData.substring(44, sCurrOfficeData.length()).trim();
          arrOneQueueData[3] = Integer.valueOf(sStatusCount); // Count status.
          
          arrOneQueueData[4] = ServerConstants.EMPTY_STRING; // Not in use.
          arrOneQueueData[5] = sUserDefine; // User define flag.
          arrOneQueueData[6] = sCurrOfficeData.substring(6, 44).trim(); // Total amount.
          arrOneQueueData[7] = sCurrOfficeData.substring(0, 3); // Office.
          arrOneQueueData[8] = sCurrOfficeData.substring(3, 6); // Currency.
          arrOneQueueData[9] = HIGH_VALUE; // 'H' for HIGH VALUE status.
          
          updateOfficeAmountDataHM(hmOfficeAmountData, arrOneQueueData, i);
      
          iLastIndex += 51;
        }
      }
      
      // Updates the 'alQueuesData' parameter for the caller method.
      if(!hmOfficeAmountData.isEmpty())
      {
        Iterator iterValues = hmOfficeAmountData.values().iterator();
        while(iterValues.hasNext())
        {
          alQueuesData.add(iterValues.next());
        }
      }
    }
    
     
  }
  
  /**
   * Updates the passed queues data ArrayList with one LOW VALUE status data 
   * along with all sub queues of this status per office.
   */
  private void updateQueuesDataALForLowValueStatus(String sMsgStatus, String sAlias, 
                                                   String sQueueGroupID, String sUserDefine,
                                                   DTODataHolder dtoStatusData,
                                                   ArrayList alQueuesData,
                                                   Object[] arrLowValueStatusParentData)
  {
    final String CURRENCY_GBP = "GBP";
    
     
    
    Object[] arrOneQueueData = null;
    
    HashMap hmTotalStatusData = new HashMap();
    int iSize = dtoStatusData.getRowsNumber();
    
    // STEP 1 - 
    // Prepares the parent node.
    arrOneQueueData = new Object[10];
    
    arrOneQueueData[0] = sMsgStatus; // Queue name.
    arrOneQueueData[1] = sAlias; // Alias.
    arrOneQueueData[2] = Integer.valueOf(sQueueGroupID); // Parent ID.
    arrOneQueueData[3] = (Long)arrLowValueStatusParentData[0]; // Count status.
    arrOneQueueData[4] = ServerConstants.EMPTY_STRING; // Not in use.
    arrOneQueueData[5] = sUserDefine; // User define flag.
    arrOneQueueData[6] = (String)arrLowValueStatusParentData[1]; // Total amount.
    arrOneQueueData[7] = ServerConstants.EMPTY_STRING; // Settlement date.
    
    // CR #59373 - setting the currency to 'GBP' in case of non-empty total amount;
    // Note: for future FPS multi-currency system a new solution should be introduced.
    arrOneQueueData[8] = !arrOneQueueData[6].equals(ServerConstants.EMPTY_STRING) ? 
                          CURRENCY_GBP : ServerConstants.EMPTY_STRING; // Currency.
    
    arrOneQueueData[9] = LOW_VALUE; // 'L' for LOW VALUE status.
    
    alQueuesData.add(arrOneQueueData);

    // STEP 2 - 
    // Loops all entries for this status and prepares the required data.
    for(int i=0; i<iSize; i++)
    {
      HashMap hmOneStatusData = dtoStatusData.getDataRow(i);
      
      // STATUSES_COUNTERS.STTLM_DT column.
      String sSettlementDate = (String)hmOneStatusData.get(COLUMN_STATUSES_COUNTERS_STTLM_DT);
      
      // STATUSES_COUNTERS.COUNT_STATUS column.
      String sCountStatus = (String)hmOneStatusData.get(COLUMN_STATUSES_COUNTERS_COUNT_STATUS);
      //int iCountStatus = Integer.valueOf(sCountStatus).intValue();
      Long lCountStatus = Long.valueOf(sCountStatus);
      
      // STATUSES_COUNTERS.SUM_BASE_AMOUNT column.
      String sSumBaseAmount = (String)hmOneStatusData.get(COLUMN_STATUSES_COUNTERS_SUM_BASE_AMOUNT);
      sSumBaseAmount = sSumBaseAmount.equals(ServerConstants.EMPTY_STRING) ? ServerConstants.ZERO_VALUE : sSumBaseAmount;
    
      arrOneQueueData = new Object[10];
      
      arrOneQueueData[0] = sMsgStatus; // Queue name.
      arrOneQueueData[1] = sAlias; // Alias.
      arrOneQueueData[2] = Integer.valueOf(sQueueGroupID); // Parent ID.
      arrOneQueueData[3] = lCountStatus; // Count status.
      arrOneQueueData[4] = ServerConstants.EMPTY_STRING; // Not in use.
      arrOneQueueData[5] = sUserDefine; // User define flag.
      arrOneQueueData[6] = sSumBaseAmount; // Total amount.
      arrOneQueueData[7] = sSettlementDate; // Settlement date.
      arrOneQueueData[8] = m_sDefaultCurrencyForLowValueStatuses; // Currency.
      arrOneQueueData[9] = LOW_VALUE; // 'L' for LOW VALUE status.
      
      alQueuesData.add(arrOneQueueData);
    }
    
     
  }
  
  /**
   * Updates the passed HashMap with data for an office/status from the STATUSES_COUNTERS
   * table; see caller method.
   */
  private void updateOfficeAmountDataHM(HashMap hmOfficeAmountData, Object[] arrOneQueueData, int iIndex)
  {
    String sOffice = (String)arrOneQueueData[7];
    
    // First time; just updates the HashMap.
    if(iIndex == 0)
    {
      hmOfficeAmountData.put(sOffice, arrOneQueueData);
    }
    
    else
    {
      Object[] arrExistingOneQueueData = (Object[])hmOfficeAmountData.get(sOffice);
      
      if(arrExistingOneQueueData != null)
      {
        // Count status.
        int iExistingCountStatus = ((Integer)arrExistingOneQueueData[3]).intValue();
        int iCountStatusToAdd = ((Integer)arrOneQueueData[3]).intValue();
        arrExistingOneQueueData[3] = Integer.valueOf(iExistingCountStatus + iCountStatusToAdd);
        
        // Total amount.
        int iExistingTotalAmount = Integer.valueOf((String)arrExistingOneQueueData[6]).intValue();
        int iTotalAmountToAdd = Integer.valueOf((String)arrOneQueueData[6]).intValue();
        arrExistingOneQueueData[6] = Integer.valueOf(iExistingTotalAmount + iTotalAmountToAdd).toString();
      }
      
      else
      {
        hmOfficeAmountData.put(sOffice, arrOneQueueData);
      }
    }
  }

  /**
   * Prepares the groups data.
   */
  private Feedback getGroupsData(Object[] arrGroupsDataHolder)
  {
     
    
    Feedback feedback = new Feedback();
    
    DTODataHolder dtoGroupsData = m_daoQueueExplorer.getGroupsData();
    feedback = dtoGroupsData.getFeedBack();
        
    if(feedback.isSuccessful())
    {
      if(!dtoGroupsData.isEmpty())
      {
//        feedback = parseGroupsData(dtoGroupsData.getDataAL(), arrGroupsDataHolder);
      }
      
      else
      {
        final String ERROR_MESSAGE = "ERROR: BOQueueExplorer.getGroupsData() - got back 0 records from QUEUE_GROUPS table.";
        logger.error(ERROR_MESSAGE);
        
        feedback.setFailure();
        feedback.setErrorCode(ERROR_CODE_GENERAL);
        feedback.setErrorText(ERROR_MESSAGE);
      }
    }
    
     
    
    return feedback;
  }
  
  
  /**
   * Removes from the queue explorer cache all entries that their office equals the passed office name
   * and their processing date is not empty and equals or earlier then the passed history processing date.
  */  
  @Expose(type=ExposureType.InternalInterface)
  public final Map<QExplorer, CacheActionType> pruneHistoricProcessingDatesFromStructure(final String sOffice, final Date dateHistoryProcessingDate){

	Map<QExplorer, CacheActionType> mapRequiredActions=new HashMap<QExplorer, CacheActionType>() ; 
	
	final QExplorerKey qexplorerRegion = CacheKeys.qExplorerKey ;
    try{    
	     final String sNewHistoryProcessingDate = new java.sql.Date(dateHistoryProcessingDate.getTime()).toString();
	  
	     final Iterator<QExplorer> iterQExplorer = qexplorerRegion.getListIterator();
	      
	     QExplorer qExplorer, parentQexplorer = null ; 
	     QExplorerId qExplorerId = null ; 
	     String sProcessingDate = null, ruleId = null ; 
	     while(iterQExplorer.hasNext()){
	    	qExplorer = iterQExplorer.next();
	        
	    	qExplorerId = qExplorer.getId();
	        sProcessingDate = qExplorerId.getProcessDate();
	        
	        boolean isFinalStatus = isFinalStatus(qExplorer.getRuleName()); 

	        // Entry should be removed if:
	        // 1) Entry's office equals the passed office name.
	        // 2) Entry's processing date is not empty and equals or earlier then the passed history processing date.
	        if(   sOffice.equals(qExplorerId.getOffice())
	           && !isNullOrEmpty(sProcessingDate) 
	           && !BOQueueExplorer.EMPTY_DATE_VALUE.equals(sProcessingDate) // processing date might equal '-------------'.
	           && sProcessingDate.length() > 1 // "empty" processing date is actualy a space
	           && sProcessingDate.compareTo(sNewHistoryProcessingDate) <= 0
	           && isFinalStatus)
	        {
	        	
	        	 //add the entry to the mapRequiredActions against the remove action 
        		mapRequiredActions.put(qExplorer, CacheActionType.RemoveSingle );
//			        update the time stamps.
		    	 qExplorer.setPrevTimeStamp(qExplorer.getTimeStamp());
		    	 qExplorer.setCurrentTimestamp();

		    	 
		    	 
		        //update the parent queue (with office)
		        ruleId = qExplorer.getId().getUidPrules();
		        parentQexplorer = qexplorerRegion.getSingle(ruleId, sOffice); 
		        
		        parentQexplorer.setQCount(parentQexplorer.getQCount() - qExplorer.getQCount());
		        parentQexplorer.setQTotalBaseAmount(parentQexplorer.getQTotalBaseAmount() - qExplorer.getQTotalBaseAmount());
		        
//		        update the time stamps.
		        parentQexplorer.setPrevTimeStamp(parentQexplorer.getTimeStamp());
		        parentQexplorer.setCurrentTimestamp();
		        //put the queueExplorer parent entry back 
		        //add the entry to the mapRequiredActions against the put action 
        		mapRequiredActions.put(parentQexplorer, CacheActionType.PutSingle);
	        }//EO if the qexplorer entry should be removed
	        
	      }//EO while there are more qexplorer entries 
	      
    }catch(Exception e) { 
    	throw new RuntimeException(e)  ;
    }//EO catch block 
    
    return mapRequiredActions ; 
  }//EOM 
  
  

  

  
  //////////////////////////////////////
  ///// END QUEUE EXPLORER METHODS /////
  //////////////////////////////////////
  
  //////////////////////////
  ///// ALERTS METHODS /////
  //////////////////////////

  /**
   * Returns alerts data. 
   */
  @Expose
  public SimpleResponseDataComponent getAlertsData()
  {
    SimpleResponseDataComponent response = new SimpleResponseDataComponent();
    Object[][] arrAlertsData = parseAlertsData(null,null,null);
    if (arrAlertsData != null)
        response.setDataArray(arrAlertsData);

    return response;
  }

  
  public SimpleResponseDataComponent getAlertsData(String office, Long type, Boolean status)
  {
    SimpleResponseDataComponent response = new SimpleResponseDataComponent();
    Object[][] arrAlertsData = parseAlertsData(office, type, status);
    if (arrAlertsData != null)
        response.setDataArray(arrAlertsData);

    return response;
  }
  
   @Expose
  public final SimpleResponseDataComponent getFilteredAlertsData()
  {
	   Feedback feedback;
	   final SimpleResponseDataComponent response;
	   //first, fetch alerts data unfiltered
	   response = this.getAlertsData();
	   
	   feedback = response.getFeedback();	   
	   if (!feedback.isSuccessful()) return response;
	   
	   //second, prepare permission parameters for filtering the results
	   Object[] arrUserEntitlementDataHolder = new Object[1];
       feedback = getUserEntitlementData(arrUserEntitlementDataHolder);
       if (!feedback.isSuccessful()) return response;
       
       UserEntitlementData userEntitlementData = (UserEntitlementData)arrUserEntitlementDataHolder[0];
       String sAlertsPermissions = userEntitlementData.getORIG_PERM_PROF_ALERTS();
       Serializable[][] alertsData = (Serializable [][]) response.getDataArray();
       
       //third, fetch the filtered queues data 
       List<Serializable> list = this.filterAlertsData(alertsData,sAlertsPermissions);
       Serializable[] alertsDataFiltered=  (Serializable[]) list.toArray(new Serializable[list.size()]);
       
       response.setDataArray(alertsDataFiltered);
       
       return response;
      
	   
	   
	   
  }
  
  private ArrayList filterAlertsData(Serializable[][] alertsData,String sAlertsPermissions)
  {
	  return  QueueExplorerAndAlertsUtils.initAlertsArray(alertsData, sAlertsPermissions);
  }
  
  
  public Feedback updateAlertsStatus()
  {
    Alerts alert = null;
    
    Feedback feedback = new Feedback();
    
    try
    {
    	
        Iterator<Alerts> iter=	CacheKeys.alertsKey.getListIterator();
        List<Alerts> modifiedAlerts = new ArrayList<Alerts>();
        while (iter.hasNext())
        {
          alert = iter.next();
          
          updateAlertStatus(alert);
          
          modifiedAlerts.add(alert);
        }
        
        //TODO: have not dealt with alerts yet 
       // CacheKeys.alertsKey.lock(true);
        CacheKeys.alertsKey.putAll(modifiedAlerts);
       // CacheKeys.alertsKey.unlock();
    }catch(Exception e)
    {
        ExceptionController.getInstance().handleException(e, this);
        feedback.setFailure();
    }
    return feedback;  
  }
  
  /**
   * Parses alerts data.
   */
  private Object[][] parseAlertsData(String office,  Long type, Boolean status)
  {
    
     
    
    List<Serializable[]> alertsList = new ArrayList<Serializable[]>();
    
    //TODO: have not dealt with alerts yet 
    //if (!CacheKeys.alertsKey.isLocked())
  //  {
        
        Iterator<Alerts> iter = CacheKeys.alertsKey.getListIterator();
        Alerts alert = null;
        int fieldsNum;
        
        while (iter.hasNext())
        {
          alert = iter.next();
          if (alert != null && alert.getAlertStatus() != null && alert.getAlertStatus()==true )
          {
              if ((GlobalUtils.isNullOrEmpty(office)|| office.equals(alert.getOffice()))
                      && (null == type || type.equals(alert.getAlertCategory()))
                      && (null == status || status.equals(alert.getAlertStatus())))
               {
            	  
            	  fieldsNum  = (alert.getAlertCategory() == GlobalConstants.ALERT_CATEGORY_POSITION_FIGURE)? 20 : 14;
            	  
            	  Serializable[] arrAlertsData = new Serializable[20];
                  
            	  // Name. 
                  arrAlertsData[0] = alert.getAlertName() != null ? alert.getAlertName() : "";
                  
                  // Category.
                  arrAlertsData[1] = alert.getAlertCategory() != null ? alert.getAlertCategory() : "";
            
                  // Label.
                  arrAlertsData[2] = alert.getAlertCaption() != null ? alert.getAlertCaption() : "";
            
                  // Gif.
                  arrAlertsData[3] = "";
                  
                  // Status.
                  arrAlertsData[4] = alert.getAlertStatus() != null ? alert.getAlertStatus() : "";
            
                  // Action.
                  arrAlertsData[5] = alert.getAlertDblcAction()!= null ? alert.getAlertDblcAction() : "";
            
                  // Alias.
                  arrAlertsData[6] = "";
            
                  // Tool tip.
                  arrAlertsData[7] = alert.getAlertTooltip() != null ? alert.getAlertTooltip() : "";
            
                  // Background color.
                  arrAlertsData[8] = alert.getAlertBgColor() != null ? alert.getAlertBgColor() : "";
            
                  // Foreground color.
                  arrAlertsData[9] = alert.getAlertFgColor() != null ? alert.getAlertFgColor() : "";
            
                  // Distribution
                  arrAlertsData[10] = alert.getDistribution() != null ? alert.getDistribution() : "";
            
                  // ID.
                  arrAlertsData[11] = alert.getUidAlerts() != null ? alert.getUidAlerts() : "";
                  
                  // Pay by approaching 
                  arrAlertsData[12] = alert.getPayByApproaching() != null ? alert.getPayByApproaching() : "";
                  
                  // Description
                  arrAlertsData[13] = alert.getDescription() != null ? alert.getDescription() : "";
                 
            	  // Alert Account Office Account number Currency
                  arrAlertsData[14] = alert.getAccountUID() != null ? alert.getAccountUID() : "";
                  
	              // Alert Account Office
	              arrAlertsData[15] = alert.getOffice() != null ? alert.getOffice() : "";
	              
	              // Alert Position Figure
	              arrAlertsData[16] = alert.getPositionFigure() != null ? alert.getPositionFigure() : "";
	              
	              // Alert Position Figure Value
	              arrAlertsData[17] = alert.getPositionFigureValue() != null ? alert.getPositionFigureValue() : "";
	              
	              // Alert TimeStamp
	              arrAlertsData[18] = alert.getLastEvalTimeStamp() != null ? alert.getLastEvalTimeStamp() : "";
	              
	              arrAlertsData[19] = "";
	              
	              if(arrAlertsData[14] != ""){
	            	  	Accounts account = CacheKeys.accountsKey.getSingle(alert.getAccountUID());
	            	  	String accountName = account.getAccountname();
	            	  	arrAlertsData[19] = accountName;
	              }
                  
                  alertsList.add(arrAlertsData);
               }
          }
        }
    //}    
     
    
    Serializable[][] arrToReturn = null;
    
    int size =alertsList.size(); 
    if (size > 0)
    {
        arrToReturn = new Serializable[size][];
        for (int i=0; i<size;i++)
        {
            arrToReturn[i] = alertsList.get(i);
        }
    }
    
    return arrToReturn;
  }
  
  /**
   * Method which  enables/disable alert.
   * @param alert 
   *
   */
  @Expose(type=ExposureType.InternalInterface)
  public final void updateAlertStatus(Alerts alert)
  {
      if (alert != null)    
      {
    	  // do not treat position figures alerts
    	  if(alert.getAlertCategory() == GlobalConstants.ALERT_CATEGORY_POSITION_FIGURE)
    		  return;

          String ruleUid = alert.getRuleId();
          String ruleName = ruleUid != null ? ruleUid.split(GlobalConstants.REGEX_POWER_SIGN)[2] : null;
          String office = alert.getOffice();  
          logger.debug("*****   Alert Validation   *****");        
          
    //      retrieve queue explorer entry from cache according to rule uid defined in alert profile.
          QExplorerSingleQData udqData = ((QExplorerAllQsData) SpringApplicationContext.getBean("QExplorerAllQsData")).getSingleQueueDataForUDQAllCurrent(office, ruleName);
          
          boolean raiseAnError = false;
          
          if (udqData != null)
          {
    //          check if queue explorer count and/or total base amount exceeds count and amount defined in alert profile.
              boolean isCountAmount = alert.getAndOr() ? udqData.getCount() > alert.getTotalCount() && udqData.getTotalBaseAmount() > alert.getAmount() :
            	  										 udqData.getCount() > alert.getTotalCount() || udqData.getTotalBaseAmount() > alert.getAmount();
              logger.debug("alertID/RuleId[{}/{}], Queue count =  " + udqData.getCount() + " > Alert count = " + alert.getTotalCount() + (alert.getAndOr() ? " AND " : " OR ") + "Queue amount = " + udqData.getTotalBaseAmount() + " > Alert amount = " + alert.getAmount(), alert.getUidAlerts(), ruleUid);                                            
              logger.debug("Count/Amount validation has " + (isCountAmount ? "passed" : "NOT passed"));                                                   
    //          if count and amount exceed
              if (isCountAmount)
              {
                  String conditionedOfficeDate = alert.getConditionedOfficeTime();
                  if (conditionedOfficeDate == null)
                  {
                      raiseAnError = !alert.getAlertStatus();
    //                   if conditioned office date not defined, turn on the alert
                      alert.setAlertStatus(true);
                     
                  }else
                  {
                       //get office time in hh:mm format
                       Date officeCurrentTime = NewASDateTimeUtils.getCurrentDateAndZoneByOffice(office).getDate(); 
                       String zone = NewASDateTimeUtils.getCurrentDateAndZoneByOffice(office).getZone();
                       
                       Calendar officeCalendar = Calendar.getInstance();
                       officeCalendar.setTime(officeCurrentTime);
                       
                       String officeTime = String.format("%02d:%02d", officeCalendar.get(Calendar.HOUR_OF_DAY), officeCalendar.get(Calendar.MINUTE));                    
                                 
                       //alert.getAfterBefore() = 1 -> before checked ; alert.getAfterBefore() = 0 - > after checked 
                       boolean isTimeLimitation = alert.getAfterBefore() ?  
                           officeTime.compareTo(conditionedOfficeDate) <= 0 : officeTime.compareTo(conditionedOfficeDate) >= 0;
                       logger.info("Office  time = " + officeTime + (alert.getAfterBefore()? " Before" : " After" ) +" Alert time = " + conditionedOfficeDate );
                       logger.info("Time validation has " + (isTimeLimitation ? "passed" : "NOT passed"));               
                      if (isTimeLimitation)
                      {
                          if (!alert.getPayByApproaching())
                          {
                              
                              raiseAnError = !alert.getAlertStatus();
    //                          if pay by approaching not check turn on the alert
                              alert.setAlertStatus(true);
                          }else
                          {
                              logger.info("Pay by approaching functionality is not in use...");
                              Prules prule = CacheKeys.PRulesUIDKey.getSingle(alert.getRuleId());
                              Connection conn = null;
                              PreparedStatement ps = null;
                              ResultSet rs = null;
                              try
                              {
                                  conn = m_daoQueueExplorer.getConnection();
    //                              retrieve the count and total base amount from minf according condition defined in rule and pay by alert time <= current office time   
                                  ps = m_daoQueueExplorer.getAlertsData(conn, prule.getExecWhere(), office);
                                  rs= ps.executeQuery();
            
                                  if (rs.next())
                                  {
                                      long count = rs.getLong(1);
                                      double baseAmt = rs.getDouble(2);
    //                                  check if  count and/or total base amount exceeds count and amount defined in alert profile.
                                      isCountAmount = alert.getAndOr() ? count > alert.getTotalCount() && baseAmt > alert.getAmount() :
                                                                                 count > alert.getTotalCount() || baseAmt > alert.getAmount();
                                      if (isCountAmount)
                                      {
                                          raiseAnError = !alert.getAlertStatus();
    //                                      if exceeds, turn on the error.
                                          alert.setAlertStatus(true);
                                      }else
                                      {
                                          alert.setAlertStatus(false);
                                      }
                                  }
                              }catch(Exception e)
                              {
                                ExceptionController.getInstance().handleException(e, this);   
                              }finally
                              {
                            	  m_daoQueueExplorer.releaseResources(conn,ps,rs);
                              }
                          }
                          
                      }else
                      {
                          alert.setAlertStatus(false);
                      }
                  }
              }else
              {
                  alert.setAlertStatus(false);
              }
              
              if (raiseAnError)
              {
    //              raise an error when alert status changed from off to on
                  ProcessError pError=new ProcessError(ProcessErrorConstants.AlertIsOn, (Object[])new String[]{alert.getAlertName()});
                  pError.setSeverity(ErrorSeverity.informative);
                  configureErrorFeedback(pError.getErrorCode(),pError.getDescription(),null);
                  ErrorAuditUtils.setErrors(pError);
                  
              }
              
              alert.setLastEvalTimeStamp( GlobalDateTimeUtil.getServerTimeStamp());
    
              logger.debug("Alert UID [{}] is {}.",alert.getUidAlerts(),  ((alert.getAlertStatus() ? "ON" : "OFF")));
                                                         
          }
          else
          {
        	logger.trace("Alert UID [{}] is missing a qexplorer object.", alert.getUidAlerts()); 
          }
          
          logger.debug("*****   End of Alert Validation   *****");

      }        
  }

  @Expose
  public final SimpleResponseDataComponent getQueuesData()
  {
    final SimpleResponseDataComponent response = new SimpleResponseDataComponent();
    boolean flag = false;
    //first acquire a read lock from the cache region key so as to ensure that no refresh operation is in progress 
    //Note: lock acquisition shall then block the thread (i.e. browser reqeust) until the refresh prodecure is finished 
    try{ 
    	CacheKeys.qExplorerKey.acquireReadLock()  ;
    
    
    	long lStart = System.currentTimeMillis();
    
      Iterator<QExplorer> iter= CacheKeys.qExplorerKey.getListIterator();
      com.fundtech.cache.entities.QExplorer qExplorer=null;
      List<Object[]> finalList = new ArrayList<Object[]>(); 
      SortedSet<Object[]> mainList = new TreeSet<Object[]>(m_qExplorerComparator);
      List<Object[]> allList = new ArrayList<Object[]>();
      
      List<Object[]> officeList = new ArrayList<Object[]>();
      List<Object[]> processDateList = new ArrayList<Object[]>();
      Serializable[] arrOneQueueData;
      Map<String, Serializable[]> ruleMap = new HashMap<String, Serializable[]>();
      String NOT_FINAL = "NOT_FINAL";
      
      String procDtEmpty = " MINF.P_PROC_DT IS NULL ";
      String OR = " OR ";
      String procDtEqConditionPattern=" MINF.P_PROC_DT = TO_DATE(\\'%s\\',\\'%s\\') ";
      String procDtGrAndOfficeConditionPattern=" (MINF.P_PROC_DT > TO_DATE(\\'%s\\',\\'%s\\') AND MINF.P_OFFICE = \\'%s\\')";
      String procDtLessOrEqualsAndOfficeConditionPattern=" (TO_DATE(\\'%s\\',\\'%s\\') >= MINF.P_PROC_DT  AND MINF.P_OFFICE = \\'%s\\')";
      
    	  
      
      while(iter.hasNext())
      {
    	  flag = true;
          qExplorer = iter.next(); 
          //if the qexplorer does not exist (bug) or the qexplorer is in fact a subclass of qexplorer (QexplorerTaskInput for instance) continue 
          if (qExplorer == null || qExplorer.getClass().getSuperclass() == QExplorer.class)
              continue ;
          
          
          boolean isFinalStatus = isFinalStatus(qExplorer.getRuleName()); 
          
          if (!ruleMap.containsKey(qExplorer.getRuleName()))
          {
        	  arrOneQueueData = getSerializableArr(qExplorer.getRuleName(),qExplorer.getAlias(),qExplorer.getQueuegroupid(),0l,qExplorer.getQType(),0d,ServerConstants.EMPTY_STRING
            		  ,ServerConstants.EMPTY_STRING,HIGH_VALUE," ",ServerConstants.EMPTY_STRING);
        	  ruleMap.put(qExplorer.getRuleName(), arrOneQueueData);
              
              mainList.add(arrOneQueueData);
          }
          
          
//          if this is 'not final' queue, then I need to gather all the history dates for queue list query
          if (qExplorer.getRuleName().equals(NOT_FINAL))
          {
        	  if (!GlobalUtils.isNullOrEmpty(qExplorer.getId().getOffice()))
        	  {
        		  String office = qExplorer.getId().getOffice();
            	  Banks bank = CacheKeys.banksKey.getSingle(office);
            	  Date historyDate = bank != null ? bank.getHistoryProcDt() : null;
            	  String condition = historyDate != null ? String.format(procDtLessOrEqualsAndOfficeConditionPattern, historyDate.toString()
            			  , GlobalDateTimeUtil.STATIC_DATA_DATE, qExplorer.getId().getOffice()) : "";
            	  
                  if (condition.length() > 0)
                  {
                	  Serializable[] mainNode = ruleMap.get(qExplorer.getRuleName());
                	  
                	  if (((String)mainNode[11]).length() == 0 )
                		  mainNode[11] = condition;
                	  else
                		  mainNode[11] = mainNode[11] + OR + condition;
                  }
        		  
        	  }
          }
          else
          {
	          arrOneQueueData = getSerializableArr(qExplorer.getRuleName(),qExplorer.getAlias(),qExplorer.getQueuegroupid(),qExplorer.getQCount(),qExplorer.getQType()
	        		  ,qExplorer.getQTotalBaseAmount(),qExplorer.getId().getOffice(),qExplorer.getCurrency(),HIGH_VALUE,qExplorer.getId().getProcessDate(),ServerConstants.EMPTY_STRING);
	          
	//          all this conditions are performed in order to preserve the order of queues, the node with process date should be
	//          after the node with office.
	          if (GlobalUtils.isNullOrEmpty(qExplorer.getId().getOffice())
	                  && (GlobalUtils.isNullOrEmpty(qExplorer.getId().getProcessDate()) || qExplorer.getId().getProcessDate().length() < 2))
	          {
	            allList.add(arrOneQueueData);
	          }
	          else if (!GlobalUtils.isNullOrEmpty(qExplorer.getId().getOffice())
	                  && (GlobalUtils.isNullOrEmpty(qExplorer.getId().getProcessDate()) || qExplorer.getId().getProcessDate().length() < 2))
	          {
	        	  Banks bank = CacheKeys.banksKey.getSingle(qExplorer.getId().getOffice());
	        	  Date historyDate = bank != null ? bank.getHistoryProcDt() : null;
	        	  
	        	  if (qExplorer.getQType().equals(QueueType.UDQ.name()))
	        	  {
		        	  String condition = historyDate != null && isFinalStatus ? String.format(procDtGrAndOfficeConditionPattern, historyDate.toString()
		        			  , GlobalDateTimeUtil.STATIC_DATA_DATE, qExplorer.getId().getOffice()) : GlobalConstants.EMPTY_STRING;
		        	  
		        	  arrOneQueueData[11] = condition.length() > 0 ? procDtEmpty + OR + condition : condition;
		              
		              Serializable[] mainNode = ruleMap.get(qExplorer.getRuleName());
		              if (condition.length() > 0)
		              {
		            	  if (((String)mainNode[11]).length() == 0 )
		            		  mainNode[11] = procDtEmpty + OR + condition;
		            	  else
		            		  mainNode[11] = mainNode[11] + OR + condition;
		              }else if (historyDate != null)
		              {
		            	  mainNode[11] = GlobalConstants.EMPTY_STRING;
		              }
	        	  }
	        	  officeList.add(arrOneQueueData);
	              
	          }else
	          {
	        	  if (!qExplorer.getId().getProcessDate().equals(EMPTY_DATE_VALUE))
	        		  arrOneQueueData[11] = String.format(procDtEqConditionPattern, qExplorer.getId().getProcessDate(), GlobalDateTimeUtil.STATIC_DATA_DATE) ;
	        	  else
	        		  arrOneQueueData[11] = procDtEmpty  ;
	        	  
	              processDateList.add(arrOneQueueData);
	          }
          
          }
      }
      
      if (ruleMap.size() > 0 && ruleMap.containsKey(NOT_FINAL))
      {
    	  arrOneQueueData = ruleMap.get(NOT_FINAL); 
    	  officeList.add(getSerializableArr((String)arrOneQueueData[0], (String)arrOneQueueData[1],(Long)arrOneQueueData[2],(Long)arrOneQueueData[3],(Integer)arrOneQueueData[5]
                                ,(String)arrOneQueueData[6],GlobalConstants.DEFAULT_SERVER_OFFICE_NAME, (String)arrOneQueueData[8], (String)arrOneQueueData[9], (String)arrOneQueueData[10]
                                , (String)arrOneQueueData[11]));
    	  
      }
      
      if (flag)
      {
	      finalList.addAll(mainList);
	      finalList.addAll(allList);
	      finalList.addAll(officeList);
	      finalList.addAll(processDateList);
	      int iQueuesDataSize = finalList.size();
	      Serializable[][] arrQueuesData = new Serializable[iQueuesDataSize][];
	      for(int i=0; i<iQueuesDataSize; i++)
	        arrQueuesData[i] = (Serializable[])finalList.get(i);
	      
	      
	      response.setDataArray(arrQueuesData);
      }
    }catch(Exception e) { 
    	ExceptionController.getInstance().handleException(e, this) ; 
    	response.getFeedback().setFailure() ;
    	ErrorAuditUtils.onError(ProcessErrorConstants.GenericError, response.getFeedback()) ;
    }finally{ 
    	//relinquish the readlock 
    	CacheKeys.qExplorerKey.relinquishLock() ; 
    }//EO catch block 
      
      return response;
  }//EOM 
  
  
  @Expose
  public void applyChanges(String str)
  {
	  try {
			CacheServiceInterface.eINSTANCE.applyChanges(new String[]{"QExplorer"}, null) ;
  	  } catch (CacheException e) {
  		  logger.error(e.getMessage());
  	  }

  }  

  
  
  
  private Serializable[] getSerializableArr(String ruleName, String alias, Long queueGroupId, Long qCount, String qType, Double totalBaseAmt, String office
		  , String ccy, String sts, String procDt,String condition )
  {
      return getSerializableArr(ruleName, alias, queueGroupId, qCount, qType.equals("STATUS") ? 0 : 1, Double.toString(totalBaseAmt != null ? totalBaseAmt : 0d), office, ccy,sts, procDt,condition );
  }

  private Serializable[] getSerializableArr(String ruleName, String alias, Long queueGroupId, Long qCount, Integer qType, String totalBaseAmt, String office
		  , String ccy, String sts, String procDt,String condition )
  {
	  Serializable[] arrOneQueueData = new Serializable[12];
      arrOneQueueData[0] = ruleName; // Queue name.
      arrOneQueueData[1] = alias; // Alias.
      arrOneQueueData[2] = queueGroupId; // Parent ID.
      arrOneQueueData[3] = qCount; // Count status.
      arrOneQueueData[4] = ServerConstants.EMPTY_STRING; // Not in use.
      arrOneQueueData[5] = qType; // User define flag.
      arrOneQueueData[6] = totalBaseAmt ; // Total amount.
      arrOneQueueData[7] = office; // Office.
      arrOneQueueData[8] = ccy == null ?ServerConstants.EMPTY_STRING : ccy; // Currency.
      arrOneQueueData[9] = sts; // 'H' for HIGH VALUE status.
      arrOneQueueData[10]= procDt;
      arrOneQueueData[11]=condition;
      
      return arrOneQueueData;
  }
  
  
  private Iterator<QExplorer> orderQueuesByAlias(Iterator<QExplorer> iterator)
  {
	List<QExplorer> list = new ArrayList<QExplorer>(3000);
	while (iterator.hasNext())
	{
		list.add(iterator.next());
	}
	Collections.sort(list);
	return list.iterator();
	
  }

  @Expose
	public List<Queuegroups> getGroupsData()
	{

		ArrayList<Queuegroups> queueQroups = new ArrayList<Queuegroups>();
		
		Iterator<Queuegroups> iterator = CacheKeys.queuegroupsKey.getListIterator();
		
		while (iterator.hasNext())
		{
			Queuegroups queueGroup = iterator.next();
			queueQroups.add(queueGroup);
		}

		return queueQroups;
	}
	
	@Expose
	public List<Statuses> getStatusesData()
	{

		ArrayList<Statuses> statuses = new ArrayList<Statuses>();
		
		Iterator<Statuses> iterator = CacheKeys.statusesKey.getListIterator();
		
		while (iterator.hasNext())
		{
			try
			{
				Statuses status = iterator.next();
				statuses.add(status);
			}
			catch (Exception e)
			{
				logger.error(e.getMessage());
			}
		}

		return statuses;
	}
	@Expose
	public List<String> getUDQsData()
	{
		return daoQExplorer.getAllUdqs();
	}
/**
   * Parses the groups data.
   */
  @Expose
  @Deprecated
  public SimpleResponseDataComponent parseGroupsData()
  {
    
    boolean flag = false;
    SimpleResponseDataComponent response = new SimpleResponseDataComponent();
    
    int iSize = CacheKeys.queuegroupsKey.getSize();
    Object[][] arrGroupsData = new Object[iSize][3];
    
    Iterator<Queuegroups> iter = CacheKeys.queuegroupsKey.getListIterator() ;
    int i=0;
    while(iter.hasNext())
    {
        Queuegroups queueGroup = iter.next();
        
        arrGroupsData[i][0] = new BigDecimal(queueGroup.getQueuegroupid());
        arrGroupsData[i][1] = queueGroup.getQueuegroupname();
        arrGroupsData[i++][2] = queueGroup.getQueuegroupparent() != null ? queueGroup.getQueuegroupparent().toString() : null;
        
        flag = true;
    }
    
    // Updates the passed holder array.
    
    if (!flag)
    	arrGroupsData = null;
    
    response.setDataArray(arrGroupsData);
    return response;
  }  
  
    
  static class QExplorerComparator implements Comparator<Object[]>
  {

	@Override
	public int compare(Object[] o1, Object[] o2) 
	{
		// TODO Auto-generated method stub
		return ((String)o1[1]).compareTo((String)o2[1]);
	}
  }
  
  
  private boolean isFinalStatus(String msgSts)
  {
	  boolean isFinalStatus = false;
	  
      Statuses status = CacheKeys.statusesKey.getSingle(msgSts);
      
//      if status not found in statuses table, that means that it is UDQ -> final status
      if (status == null)
      {
    	  isFinalStatus = true;
      }
      else if (status.getFinalStatus() != null)
      {
    	  isFinalStatus = status.isFinalStatus();
      }
      
      return isFinalStatus;
  }

 
  //////////////////////////////
  ///// END ALERTS METHODS /////
  //////////////////////////////
  
  
  
}