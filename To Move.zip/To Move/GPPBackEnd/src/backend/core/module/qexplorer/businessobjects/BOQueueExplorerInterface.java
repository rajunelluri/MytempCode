package backend.core.module.qexplorer.businessobjects;

import com.fundtech.core.security.Admin;

/**
 * internal interface for BOQueueExplorer.
 */
public interface BOQueueExplorerInterface{

	
	
	/** 
	 * TODO: adapt to new API
	 * public final void performPendingCalculation(List<CounterDeltaPerMidHolder> deltasPerMidList, Map<String, String> refreshedMidMap)
	 * {
	 * for (CounterDeltaPerMidHolder deltaPerMid : deltasPerMidList)
	 * {
	 * //              At the end of the full calculation need to go through the updated maps and find its related entry in the calculation processing cache. 
	 * //              If it is not exist then need to add to the Qexplorer only the queues with plus sign.
	 * if (!refreshedMidMap.containsKey(deltaPerMid.getMID()))
	 * {
	 * queueExplorerDeltaUpdate(deltaPerMid.getCounterDeltaMap(), true,true);                  
	 * }
	 * //              If it exists then need to compare the timestamp. If its timestamp in the full calculation cache is less than the its timestamp in the updated cache then 
	 * //              apply the plus and the minus.
	 * else if (refreshedMidMap.get(deltaPerMid.getMID()).compareTo(deltaPerMid.getTimeStamp()) < 0)
	 * {
	 * queueExplorerDeltaUpdate(deltaPerMid.getCounterDeltaMap(), true,false);
	 * }
	 * //                If it is not less (probably equal) then do not take into the calculation this updated entry.
	 * }
	 * }
	 */
	public java.lang.Boolean shouldPerformSubtructions(final Admin admin, java.util.Map<java.lang.String,java.lang.String> refreshedMidMap, com.fundtech.cache.entities.CounterDeltaPerMidHolder deltaPerMid ) ;
	
	/** 
	 * TODO: adapt to new API
	 * @Exposepublic final void performPendingCalculation(CounterDeltaPerMidHolder deltaPerMid, Map<String, String> refreshedMidMap)
	 * {
	 * }
	 * private void putMidsList(List<String> midList)
	 * {
	 * if (midList.size() > 0)
	 * {
	 * Random random = new Random(new Date().getTime());
	 * String key = CacheKeys.qExplorerKey.isLocked() ? PENDING_PREFIX+random.nextLong() : random.nextLong()+""; 
	 * CacheKeys.pendingPDOKey.putSingle(key, midList);
	 * }
	 * }
	 */
	public com.fundtech.cache.entities.QExplorerTaskInput buildDeltaList(final Admin admin, java.util.List<com.fundtech.core.paymentprocess.data.PDO> pdoList ) throws java.lang.Exception ;
	
	/** 
	 * @returns Map<CacheActionType, Qexplorer> if the map is not empty, then there was a structure change. 
	 * It is the responsibility of the client code to perform the actions on the cache   
	 */
	public java.util.Map<com.fundtech.cache.entities.QExplorer,com.fundtech.cache.infrastructure.CacheActionType> queueExplorerDeltaUpdate(final Admin admin, java.lang.String key, com.fundtech.cache.entities.CounterDeltaPerMidHolder.CounterDelta counterDelta, boolean isToAdd, boolean onlyPositive ) ;
	
	public java.util.Map<java.lang.String,java.lang.String> fillUpQExplorerCache(final Admin admin, java.util.Map<java.lang.String,com.fundtech.cache.entities.QExplorer> qExplorerMap ) ;
	
	public void calcluateSinglePayment(final Admin admin, java.sql.ResultSet rs, java.util.Map<java.lang.String,com.fundtech.cache.entities.QExplorer> qExplorerMap, java.util.Map<java.lang.String,java.lang.String> midMap ) ;
	
	public java.sql.PreparedStatement getPaymentsForCalculation(final Admin admin, java.sql.Connection conn ) ;
	
	/** 
	 * Removes from the queue explorer cache all entries that their office equals the passed office name
	 * and their processing date is not empty and equals or earlier then the passed history processing date.
	 */
	public java.util.Map<com.fundtech.cache.entities.QExplorer,com.fundtech.cache.infrastructure.CacheActionType> pruneHistoricProcessingDatesFromStructure(final Admin admin, java.lang.String sOffice, java.util.Date dateHistoryProcessingDate ) ;
	
	/** 
	 * Method which  enables/disable alert.
	 * @param alert 
	 */
	public void updateAlertStatus(final Admin admin, com.fundtech.cache.entities.Alerts alert ) ;

}//EOI  