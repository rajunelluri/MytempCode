package backend.core.module.qexplorer.businessobjects;

import java.util.Date;


public class UDQStatus {
	private Date lastUpdateTime;
	private boolean shouldDelete;
	public Date getLastUpdateTime() {
		return lastUpdateTime;
	}
	public void setLastUpdateTime(Date lastUpdateTime) {
		this.lastUpdateTime = lastUpdateTime;
	}
	public boolean isShouldDelete() {
		return shouldDelete;
	}
	public void setShouldDelete(boolean shouldDelete) {
		this.shouldDelete = shouldDelete;
	}
	@Override
	public String toString(){
		return "Last update time="+lastUpdateTime+", shouldDelete="+shouldDelete;
				
	}
}
