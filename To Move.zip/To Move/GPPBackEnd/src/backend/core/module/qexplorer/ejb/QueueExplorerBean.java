package backend.core.module.qexplorer.ejb;

import javax.ejb.Stateless;
import backend.core.SuperSLSB;
import com.fundtech.core.security.Admin;
import backend.businessobject.proxies.interceptors.InterceptorSetType;
import backend.core.module.qexplorer.businessobjects.BOQueueExplorer;
import backend.core.module.qexplorer.ejbinterfaces.QueueExplorerLocal;
import backend.core.module.qexplorer.ejbinterfaces.QueueExplorer;

@Stateless
public class QueueExplorerBean extends SuperSLSB<QueueExplorer> implements QueueExplorerLocal, QueueExplorer{
	
	public QueueExplorerBean() { super(backend.core.module.qexplorer.businessobjects.BOQueueExplorer.class, InterceptorSetType.Complete) ; }//EOM
	
	
	/** 
	 * Returns queue explorer data. 
	 */
	public com.fundtech.cache.entities.QExplorerTaskInput updateCountersForDefinedQueue(final Admin admin, java.lang.String queueName ) throws java.lang.Exception {
		return this.m_bo.updateCountersForDefinedQueue(admin, queueName ) ;
	}//EOM

	/** 
	 * Returns alerts data. 
	 */
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent getAlertsData(final Admin admin ) {
		return this.m_bo.getAlertsData(admin ) ;
	}//EOM

	public com.fundtech.datacomponent.response.SimpleResponseDataComponent getFilteredAlertsData(final Admin admin ) {
		return this.m_bo.getFilteredAlertsData(admin ) ;
	}//EOM

	public com.fundtech.datacomponent.response.SimpleResponseDataComponent getQueuesData(final Admin admin ) {
		return this.m_bo.getQueuesData(admin ) ;
	}//EOM

	public com.fundtech.datacomponent.response.SimpleResponseDataComponent getFilteredQueuesData(final Admin admin ) {
		return this.m_bo.getFilteredQueuesData(admin ) ;
	}//EOM

	/** 
	 * Parses the groups data.
	 */
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent parseGroupsData(final Admin admin ) {
		return this.m_bo.parseGroupsData(admin ) ;
	}//EOM
	
	public java.util.List<com.fundtech.cache.entities.Queuegroups> getGroupsData(final Admin admin ) {
		return this.m_bo.getGroupsData(admin) ;
	}
	
	public java.util.List<com.fundtech.cache.entities.Statuses> getStatusesData(final Admin admin ) {
		return this.m_bo.getStatusesData(admin) ;
	}
	
	public java.util.List<String> getUDQsData(final Admin admin ) {
		return this.m_bo.getUDQsData(admin) ;
	}
	public void applyChanges(Admin admin, String str)
	{
		this.m_bo.applyChanges(admin, str);
	}


}//EOC