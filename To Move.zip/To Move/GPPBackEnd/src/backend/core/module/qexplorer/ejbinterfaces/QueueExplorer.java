package backend.core.module.qexplorer.ejbinterfaces;

import javax.ejb.Remote;
import com.fundtech.core.security.Admin;

/**
 * Remote interface for QueueExplorer.
 */
@Remote
public interface QueueExplorer{

	public static final String REMOTE_JNDI_NAME="ejb/QueueExplorerBean";
	
	
	/** 
	 * Returns queue explorer data. 
	 */
	public com.fundtech.cache.entities.QExplorerTaskInput updateCountersForDefinedQueue(final Admin admin, java.lang.String queueName ) throws java.lang.Exception ;
	
	/** 
	 * Returns alerts data. 
	 */
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent getAlertsData(final Admin admin ) ;
	
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent getFilteredAlertsData(final Admin admin ) ;
	
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent getQueuesData(final Admin admin ) ;
	
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent getFilteredQueuesData(final Admin admin ) ;
	
	/** 
	 * Parses the groups data.
	 */
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent parseGroupsData(final Admin admin ) ;
	
	public java.util.List<com.fundtech.cache.entities.Queuegroups> getGroupsData(final Admin admin);
	
	public java.util.List<com.fundtech.cache.entities.Statuses> getStatusesData(final Admin admin);
	
	public java.util.List<String> getUDQsData(final Admin admin);
	public void applyChanges(final Admin admin, String str ) ;

}//EOI  