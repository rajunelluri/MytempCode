package backend.core.module.qexplorer.businessobjects;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.Trigger;
import org.springframework.scheduling.TriggerContext;

import com.fundtech.util.GlobalUtils;


public class QExplorerAllQsDataRefreshScheduler implements Trigger{
	
	final static Logger logger = LoggerFactory.getLogger(QExplorerAllQsDataRefreshScheduler.class);

	private String fixedInterval; 
	private long maxInterval;
	
	public QExplorerAllQsDataRefreshScheduler(String fixedInterval, String maxInterval) {
		this.fixedInterval = fixedInterval;
		this.maxInterval = GlobalUtils.isNullOrEmpty(maxInterval) ? 0 : Long.parseLong(maxInterval);
	}

	/**
	 * This method schedules the refresh event of local queue explorer object.
	 * fixed interval value is set on spring-beans.properties file in config directory (one for cache server and one for GPP server)
	 * for cache server we expect to get empty/null fixed interval value which will cause the event to stop running.
	 * this event should run only on GPP server.
	 * @see org.springframework.scheduling.Trigger#nextExecutionTime(org.springframework.scheduling.TriggerContext)
	 */
	@Override
	public Date nextExecutionTime(TriggerContext context) {
		//fixedInterval should get null/empty value when execution is from cache server. 
		if (!GlobalUtils.isNullOrEmpty(fixedInterval)){ 
			if (context.lastScheduledExecutionTime() == null){ // first run
				return new Date();
			}
			if (context.lastCompletionTime().getTime() + maxInterval < System.currentTimeMillis()){ // MAX_INTERVAL passed, start a new job
				return new Date();
			}
			return new Date(context.lastCompletionTime().getTime() + Long.parseLong(fixedInterval));
		}
		
		return null;
	}
	
	

}
