package backend.core.module.qexplorer.businessobjects;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.core.module.qexplorer.dataaccess.dao.DAOQExplorer;

import com.fundtech.spring.SpringApplicationContext;


public class QExplorerUDQsDataRefresh {
	
	final static Logger logger = LoggerFactory.getLogger(QExplorerUDQsDataRefresh.class);
	
	private static DAOQExplorer daoQExplorer = (DAOQExplorer) SpringApplicationContext
			.getBean("DAOQExplorer");
	
	
	/**
	 * Refresh the singleton QExplorerAllQsData with new calculated counters for system queues and user defined queues
	 * This method is scheduled to run in a predefined interval (see spring-backend-beans.xml)
	 */
	public void refresh(){
		Map<String, QExplorerSingleQData> qData = daoQExplorer.getUserDefinedQueuesData();
		
		((QExplorerAllQsData) SpringApplicationContext.getBean("QExplorerAllQsData")).refreshAllUDQsData(qData);
		logger.info("Queue explorer - UDQs local data is refreshed");
	}


}
