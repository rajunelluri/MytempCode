package backend.core.module.qexplorer.dataaccess.dao;

import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_MSG_STS;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_OFFICE;
import static com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface.P_PROC_DT;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.lang.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;

import backend.core.module.MessageConstantsInterface;
import backend.core.module.qexplorer.businessobjects.QExplorerAllQsData;
import backend.core.module.qexplorer.businessobjects.QExplorerSingleQData;
import backend.core.module.qexplorer.businessobjects.QExplorerSingleQData.ProcessDateGroup;
import backend.core.module.qexplorer.businessobjects.UDQStatus;
import backend.util.ServerConstants;
import backend.util.ServerUtils;

import com.fundtech.cache.entities.Prules;
import com.fundtech.cache.entities.Statuses;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.util.GlobalDateTimeUtil;

public class DAOQExplorer{
	
	final static Logger logger = LoggerFactory
			.getLogger(DAOQExplorer.class);

	private JdbcTemplate jdbcTemplate;
	private final int millisTolerance = 2000;
	
	public void setDataSource(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	
	/**
	 * Count all system queues from MINF and return a list that holds all queues data
	 * @param businessDate
	 * @return
	 */
	public Map<String, QExplorerSingleQData> getSystemQueuesData(){
		
		String selectStatement = "select p_msg_sts, p_office, p_proc_dt, count(*) as COUNT, sum(p_base_amt) as AMOUNT from minf " +
				"where p_is_history = 0 group by p_msg_sts, p_office, p_proc_dt";
		
		final Map<String, Date> offices = getAllOffices();
		final Map<String, Statuses> statuses = getStatusesList();
		
		long startTime = System.currentTimeMillis();
		Map<String, QExplorerSingleQData> allQueuesData = jdbcTemplate.query(selectStatement,	new ResultSetExtractor<Map<String, QExplorerSingleQData>>() {
					
			@Override
			public Map<String, QExplorerSingleQData> extractData(ResultSet rs) throws SQLException, DataAccessException {
				Map<String, QExplorerSingleQData> qData = new HashMap<String, QExplorerSingleQData>();
				
				while (rs.next()){
					String office = rs.getString(P_OFFICE);
					String msgSts = rs.getString(P_MSG_STS);
					Date officeDate = offices.get(office);
					Date procDt = rs.getDate(P_PROC_DT);
					List<ProcessDateGroup> processDateGroups = ProcessDateGroup.determineProcessDateGroups(procDt, officeDate, msgSts, statuses);

					for (ProcessDateGroup processDateGroup : processDateGroups) {
						String QKey = QExplorerAllQsData.buildQDataKey(office, msgSts, processDateGroup.toString(), false);
						QExplorerSingleQData qExplorerData = qData.get(QKey);

						if (qExplorerData != null) { // incase already part of the map, add count and amount
							qExplorerData.setCount(qExplorerData.getCount()	+ rs.getInt("COUNT"));
							qExplorerData.setTotalBaseAmount(qExplorerData.getTotalBaseAmount()	+ rs.getDouble("AMOUNT"));
						} else { // incase this key is not part of the map, create new entry
							qExplorerData = new QExplorerSingleQData();
							qExplorerData.setName(msgSts);
							qExplorerData.setCount(rs.getInt("COUNT"));
							qExplorerData.setOffice(office);
							qExplorerData.setProcessDateGroup(processDateGroup);
							qExplorerData.setTotalBaseAmount(rs.getDouble("AMOUNT"));
							qExplorerData.setUDQ(false);
							qData.put(QKey, qExplorerData);
						}
					}
				}
				return qData;
			}
		});
		logger.debug("Getting counters for system queues took {} milliseconds",	System.currentTimeMillis() - startTime);
		return allQueuesData;
	}
	
	
	/**
	 * Get all offices with business dates from banks table
	 * @return
	 */
	private Map<String,Date> getAllOffices(){
		
		String selectStatement = "select office, bsnessdate from banks";
		
		return jdbcTemplate.query(selectStatement, new ResultSetExtractor<Map<String,Date>>(){
			@Override
			public Map<String, Date> extractData(ResultSet rs) throws SQLException, DataAccessException {
				Map<String,Date> offices = new HashMap<String, Date>();
				while (rs.next()){
					offices.put(rs.getString("office"), rs.getDate("bsnessdate"));
				}
				
				return offices;
			}
		});
		
	}
	
	/**
	 * Count all user defined queues from MID_UDQ and MINF and return a list that holds all queues data
	 * @return
	 */
	public Map<String, QExplorerSingleQData> getUserDefinedQueuesData(){
			
		Map<String, QExplorerSingleQData> udqData = new HashMap<String, QExplorerSingleQData>();
		
		final Map<String, Statuses> statuses = getStatusesList();
		
		String selectStatement = "select /*+ USE_HASH(minf,mid_udq) */ udq_name,p_office,p_proc_dt,p_msg_sts,count(*) as COUNT,sum(p_base_amt)as AMOUNT " +
								 "from minf join mid_udq on p_mid = mid " + 
				                 "group by udq_name,p_office,p_proc_dt,p_msg_sts";
		
		final Map<String, Date> offices = getAllOffices();

		long startTime = System.currentTimeMillis();
		udqData = jdbcTemplate.query(selectStatement,new ResultSetExtractor<Map<String, QExplorerSingleQData>>() {
			
			@Override
			public Map<String, QExplorerSingleQData> extractData(ResultSet rs) throws SQLException, DataAccessException {
				Map<String, QExplorerSingleQData> qData = new HashMap<String, QExplorerSingleQData>();

				while (rs.next()){
					String office = rs.getString(P_OFFICE);
					String msgSts = rs.getString("udq_name");
					Date officeDate = offices.get(office);
					Date procDt = rs.getDate(P_PROC_DT);
					String msgStatus = rs.getString(P_MSG_STS);
					List<ProcessDateGroup> processDates = ProcessDateGroup.determineProcessDateGroups(procDt, officeDate, msgStatus, statuses);

					for (ProcessDateGroup processDate : processDates) {
						String QKey = QExplorerAllQsData.buildQDataKey(office, msgSts, processDate.toString(), true);
						QExplorerSingleQData qExplorerData = qData.get(QKey);

						if (qExplorerData != null) { // incase already part of the map, add count and amount
							qExplorerData.setCount(qExplorerData.getCount()	+ rs.getInt("COUNT"));
							qExplorerData.setTotalBaseAmount(qExplorerData.getTotalBaseAmount()	+ rs.getDouble("AMOUNT"));
						} else { // incase this key is not part of the map, create new entry
							qExplorerData = new QExplorerSingleQData();
							qExplorerData.setName(msgSts);
							qExplorerData.setCount(rs.getInt("COUNT"));
							qExplorerData.setOffice(office);
							qExplorerData.setProcessDateGroup(processDate);
							qExplorerData.setTotalBaseAmount(rs.getDouble("AMOUNT"));
							qExplorerData.setUDQ(true);
							qData.put(QKey, qExplorerData);
						}
					}
				}
				return qData;
			}
		});
		
		logger.debug("Getting counters for user defined queues took {} milliseconds",	System.currentTimeMillis() - startTime);

		return udqData;
	}
	
	/**
	 * Get all statuses list with indication of final status
	 * @return
	 */
	private Map<String,Statuses> getStatusesList(){
		String selectStatement = "select msg_status, final_status from statuses";
		return jdbcTemplate.query(selectStatement, new ResultSetExtractor<Map<String,Statuses>>(){

			@Override
			public Map<String, Statuses> extractData(ResultSet rs) throws SQLException, DataAccessException {
				Map<String,Statuses> statuses = new HashMap<String,Statuses>();
				while (rs.next()){
					Statuses status = new Statuses();
					status.setMsgStatus(rs.getString("msg_status"));
					status.setFinalStatus(rs.getInt("final_status"));
					statuses.put(status.getMsgStatus(), status);
				}
				
				return statuses;
			}
			
		});
	}
	
	
	
	
	/**
	 * return a list of all UDQ names from udq_qexplorer_last_update table
	 * @return
	 */
	public List<String> getAllUdqs(){
		String select = "select udq_name from udq_qexplorer_last_update";
		return jdbcTemplate.queryForList(select, String.class);
	}
	
	/**
	 * Get UDQ status and last update time.
	 * if null, record does not exist in udq_qexplorer_last_update table
	 * @param udqName
	 * @return
	 */
	public UDQStatus getUdqStatus(String udqName){
		String selectStatement = "select last_update_time,should_delete from udq_qexplorer_last_update where udq_name=?";
		UDQStatus udqStatus = jdbcTemplate.query(selectStatement, new Object[]{udqName}, new ResultSetExtractor<UDQStatus>(){

			@Override
			public UDQStatus extractData(ResultSet rs) throws SQLException,	DataAccessException {
				UDQStatus udqStatus = null;
				if (rs.next()){
					udqStatus = new UDQStatus();
                            udqStatus.setLastUpdateTime(rs.getTimestamp("last_update_time"));
					udqStatus.setShouldDelete(rs.getInt("should_delete") == 1);
				}
				return udqStatus;
			}
			
		});
		return udqStatus;
	}
	
	private Date getDBSysDateTime(){
		String selectStatement = "select sysdate from dual";
		Date currentTime = jdbcTemplate.queryForObject(selectStatement, Date.class);
		return currentTime;
	}
	
	
	public boolean refreshUdqContent(String udqName){
		Date lastUpdateTime = (getUdqStatus(udqName)!=null)?getUdqStatus(udqName).getLastUpdateTime():null;
		Date now = getDBSysDateTime();
		try{
			deleteAllNewlyNonRelevantMidsFromUdq(udqName,lastUpdateTime,now);			
			addAllNewlyAddedMidsToUdq(udqName,lastUpdateTime,now);
			updateUdqLastUpdateTimeInLastUpdateTable(udqName,now);
		}catch(Exception e){
			logger.error(e.getMessage());
			return false;
		}
		return true;
	}
	
	public boolean deleteUdqContent(String udqName){
		try{
			String deleteStatement = "delete from mid_udq where udq_name=?";
			jdbcTemplate.update(deleteStatement, new Object[]{udqName});
			deleteFromLastUpateTable(udqName);
		}catch(Exception e){
			logger.error(e.getMessage());
			return false;
		}
		return true;
	}
	
	private void deleteAllNewlyNonRelevantMidsFromUdq(String udq,Date from,Date to){
		String deleteStatement = "delete from mid_udq where udq_name=? and mid in (select m.p_mid from minf m where m.p_time_stamp>? and m.p_time_stamp<?)";
		
		String fromTimeStamp = getFromTimeStamp(from);
		String toTimeStamp = GlobalDateTimeUtil.getFormattedDateString(to, GlobalDateTimeUtil.STATIC_DATA_TIME_STAMP);
		
		int numberOfEffectedRows = jdbcTemplate.update(deleteStatement, new Object[]{udq,fromTimeStamp,toTimeStamp});
		logger.debug("{} rows were deleted from MID_UDQ table for UDQ {} between {} to {}", new Object[]{numberOfEffectedRows, udq, fromTimeStamp, toTimeStamp});
	}
	
	private void addAllNewlyAddedMidsToUdq(String udq,Date from,Date to) throws Exception{
		String ruleUidKey = ServerUtils.generateUIDValue(null, new String[] {ServerConstants.DEFAULT_SERVER_OFFICE_NAME, 
				MessageConstantsInterface.RULE_TYPE_ID_USER_DEFINED_QUEUE, 
				udq});
		Prules udqMetadata = CacheKeys.PRulesUIDKey.getSingle(ruleUidKey) ; 
		
		if (udqMetadata==null){
			throw new Exception("Could not find rule conditions in cache for "+ruleUidKey+" (probably apply changes is needed for a new added UDQ), will not perform any action for UDQ "+udq);
		}
		String matchUdqCriteriaQuery = "("+udqMetadata.getExecWhere()+")";
		String insertStatement ="insert into mid_udq (mid,udq_name) (select m.p_mid mid,? udq_name from minf m where m.p_is_history=0 and m.p_time_stamp > ? and m.p_time_stamp < ? and "+matchUdqCriteriaQuery+")";
		
		String fromTimeStamp = getFromTimeStamp(from);
		String toTimeStamp = GlobalDateTimeUtil.getFormattedDateString(to, GlobalDateTimeUtil.STATIC_DATA_TIME_STAMP);
		logger.debug("UDQ {} from {} to {} insert statement is: {}" ,new Object[]{udq, fromTimeStamp, toTimeStamp, insertStatement});
		
		int numberOfEffectedRows = jdbcTemplate.update(insertStatement, new Object[]{udq, fromTimeStamp, toTimeStamp});
		logger.debug("{} rows were inserted to MID_UDQ table for UDQ {} between {} to {}", new Object[]{numberOfEffectedRows, udq, fromTimeStamp, toTimeStamp});
	}
	
	private String getFromTimeStamp(Date from){
		String fromTimeStamp = "0000-00-00 00:00:00.000";
		if (from!=null){
			fromTimeStamp = GlobalDateTimeUtil.getFormattedDateString(DateUtils.addMilliseconds(from,millisTolerance*(-1)), GlobalDateTimeUtil.STATIC_DATA_TIME_STAMP);
		}
		
		return fromTimeStamp;
	}
	
	
	/**
     * Add a record with udqName, null last_update_time and shouldDelete=0 to udq_qexplorer_last_update table
	 * @param udqName
	 */
	public void addUdqToLastUpdateTable(String udqName){
		String insert = "insert into udq_qexplorer_last_update (udq_name,last_update_time,should_delete) values (?, ?, ?)";
		jdbcTemplate.update(insert, new Object[]{udqName, null,0});
	}
	
	
	/**
	 * update the lastUpdateTime of the record with udqName in udq_qexplorer_last_update table
	 * @param udqName
	 * @param lastUpdateTime
	 */
	public void updateUdqLastUpdateTimeInLastUpdateTable(String udqName, Date lastUpdateTime){
		String udpateStatement = "update udq_qexplorer_last_update set last_update_time = ? where udq_name = ?";
		jdbcTemplate.update(udpateStatement, new Object[]{lastUpdateTime, udqName});
	}
	
	
	public void deleteFromLastUpateTable(String udqName){
		String deleteStatement = "delete from udq_qexplorer_last_update where udq_name = ?";
		jdbcTemplate.update(deleteStatement, new Object[]{udqName});
	}
	
	/**
	 * Change should_deleted value of udqName to 1 (will be deleted on next refresh) 
	 * @param udqName
	 */
	public void changeUdqStatusToDelete(String udqName){
		String insert = "update udq_qexplorer_last_update set should_delete = ? where udq_name = ?";
		jdbcTemplate.update(insert, new Object[]{1, udqName});
	}
	
	
}
