package backend.core.module.qexplorer.businessobjects;


import static com.fundtech.util.GlobalConstants.POWER_SIGN;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

public class QExplorerAllQsData {
	
	private Map<String,QExplorerSingleQData> systemQueuesDataMap;
	private Map<String,QExplorerSingleQData> udqsDataMap;
	private static Date systemQueuesLastUpdateTime;
	private static Date UDQsLastUpdateTime;
	
	private static String UDQ = "UDQ";
	private static String SYSTEM_Q = "SYS";

	//private constructor
	private QExplorerAllQsData() {
		systemQueuesDataMap = new HashMap<String, QExplorerSingleQData>();
		udqsDataMap = new HashMap<String, QExplorerSingleQData>();
	}

	
	/**
	 * Gets data for a specific user defined queue
	 * @param office UDQueue's office
	 * @param qName name of UDQ
	 * @return DataObject which holds the information for this UDQ, for all processing dates.
	 */
	public QExplorerSingleQData getSingleQueueDataForUDQAllCurrent(String office,String qName){
		return udqsDataMap.get(buildQDataKey(office,qName,QExplorerSingleQData.ProcessDateGroup.ALL_CURRENT.name(),true));
	}
	
	
	/**
	 * Gets all queues data which is stored in this local data object.
	 * @return an unmodifiable list of all queues data. Attempts to make changes to this list, will result in UnsupportedOperationException.
	 */
	public List<QExplorerSingleQData> getAllQueuesData(){
		//list is wrapped by unmodifiableList to make sure it won't be changed by client and cause a change in backing map. 
		ArrayList<QExplorerSingleQData> allQueues = new ArrayList<QExplorerSingleQData>();
		allQueues.addAll(systemQueuesDataMap.values());
		allQueues.addAll(udqsDataMap.values());
		return java.util.Collections.unmodifiableList(allQueues);
	}
	
	
	
	/**
	 * Gets a map with system queues data, and refreshes this local object with it.
	 * @param allSystemQueuesData A map with system queues data
	 */
	public void refreshAllSystemQueuesData(Map<String, QExplorerSingleQData> allSystemQueuesData){
		QExplorerAllQsData.systemQueuesLastUpdateTime = getCurrentGmtTime();
		
		systemQueuesDataMap = allSystemQueuesData;
	}
	
	/**
	 * Gets a map with user defined queues data, and refreshes this local object with it.
	 * @param allUDQsData A map with all user defined queues data
	 */
	public void refreshAllUDQsData(Map<String, QExplorerSingleQData> allUDQsData){
		QExplorerAllQsData.UDQsLastUpdateTime =  getCurrentGmtTime();
		
		udqsDataMap = allUDQsData;
	}
	
	public static String buildQDataKey(String office,String qName, String processDateName,boolean isUDQ){
		return new StringBuilder().append(office).append(POWER_SIGN).append(qName).append(POWER_SIGN).append(processDateName).append(POWER_SIGN).append(isUDQ ? UDQ : SYSTEM_Q).toString();
	}
	
	/**
	 * Return last update time (GMT) of system queues
	 * @return
	 */
	public Date getSystemQueuesLastUpdateTime(){
		return systemQueuesLastUpdateTime;
	}
	
	/**
	 * Return last update time (GMT) of user defined queues
	 * @return
	 */
	public Date getUserDefinedQueuesLastUpdateTime(){
		return UDQsLastUpdateTime;
	}
	
	
	/**
	 * return a date representing current server time in GMT
	 * @return
	 */
	private Date getCurrentGmtTime(){
		Calendar calendar = GregorianCalendar.getInstance(TimeZone.getTimeZone("GMT"));
		return calendar.getTime();
	}
	

}
