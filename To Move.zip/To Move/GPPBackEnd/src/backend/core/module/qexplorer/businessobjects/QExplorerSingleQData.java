package backend.core.module.qexplorer.businessobjects;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.fundtech.cache.entities.Statuses;


public class QExplorerSingleQData {
	
    private String name;
    
    private String office;
    
    private ProcessDateGroup processDateGroup;

    private boolean isUDQ;

    private long count;

    private double totalBaseAmount;



	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getOffice() {
		return office;
	}

	public void setOffice(String office) {
		this.office = office;
	}

	public ProcessDateGroup getProcessDateGroup() {
		return processDateGroup;
	}

	public void setProcessDateGroup(ProcessDateGroup processDateGroup) {
		this.processDateGroup = processDateGroup;
	}

	public boolean isUDQ() {
		return isUDQ;
	}

	public void setUDQ(boolean isUDQ) {
		this.isUDQ = isUDQ;
	}

	public long getCount() {
		return count;
	}

	public void setCount(long count) {
		this.count = count;
	}

	public double getTotalBaseAmount() {
		return totalBaseAmount;
	}

	public void setTotalBaseAmount(double totalBaseAmount) {
		this.totalBaseAmount = totalBaseAmount;
	}

	@Override
	public String toString(){
		return name+"^"+office+"^"+(isUDQ?"UDQ":"SYS")+"^"+processDateGroup.name()+"^"+count+"^"+totalBaseAmount;
	}
	
	public enum ProcessDateGroup {    
		
		ALL_CURRENT, PROCESSING_TODAY, PROCESSING_FUTURE, COMPLETED_TODAY; 
		
		/**
		 * Return a list of all relevant process date groups for a specific date compare to office business date
		 * @param processDate
		 * @param officeBusinessDate
		 * @return
		 */
		public static List<ProcessDateGroup> determineProcessDateGroups(Date processDate, Date officeBusinessDate, String msgStatus, Map<String, Statuses> statuses){

			List<ProcessDateGroup> processDateGroups = new ArrayList<ProcessDateGroup>();
			if (processDate == null){
				processDateGroups.add(ALL_CURRENT);
				return processDateGroups;
			}

			switch (processDate.compareTo(officeBusinessDate)) {
			case 0:
				processDateGroups.add(PROCESSING_TODAY);
				processDateGroups.add(ALL_CURRENT);
				Statuses status = statuses.get(msgStatus);
				if (status.isFinalStatus()){
					processDateGroups.add(COMPLETED_TODAY);
				}
	
				break;

			case 1:
				processDateGroups.add(PROCESSING_FUTURE);
				processDateGroups.add(ALL_CURRENT);
				break;

			case -1:
				processDateGroups.add(ALL_CURRENT);
				break;
			}

			return processDateGroups;
		} 
 }

}//EOC