package backend.core.module.qexplorer.interfacehandler;

import com.fundtech.interfaces.gateway.MessageContext;
import com.fundtech.scl.qExplorerUDQRefresh.UpdateUDQMessageType;
import backend.paymentprocess.interfaces.handlers.InterfaceTypesHandlerAdapter;

public class QExplorerUDQRefreshInterfaceHandler extends InterfaceTypesHandlerAdapter{

	@Override
	public Object fromMessage(final Object oInput, final MessageContext context) throws Throwable {
        UpdateUDQMessageType udqMsg = UpdateUDQMessageType.Factory.parse(oInput.toString());
		return udqMsg;
	}
}
