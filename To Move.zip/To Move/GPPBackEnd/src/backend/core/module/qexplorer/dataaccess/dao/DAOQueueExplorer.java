package backend.core.module.qexplorer.dataaccess.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.Date;

import com.fundtech.core.general.StatementParameter;
import com.fundtech.lang.OperatorType;

import backend.core.module.genservices.dataaccess.dao.DAOGeneralServices;
import backend.dataaccess.dto.DTODataHolder;
import backend.dataaccess.dto.DTOSingleValue;
import backend.util.ServerConstants;
import com.fundtech.util.datetime.NewASDateTimeUtils;

/**
 * Title:       DAOQueueExplorer
 * Description: Data access object which provides queue explorer services
 * Company:     Fundtech Israel
 * Author:      Asaf Levy
 * Date:        24/01/2007
 * @version     1.0
 */
public class DAOQueueExplorer extends DAOGeneralServices 
{
  
  /**
   * Returns number of STATUSES_COUNTERS records for the passed statuses
   */
  public DTOSingleValue getNumOf_STATUSES_COUNTERS_Entries(String sStatuses)
  {
    final String SELECT_STATEMENT = "SELECT COUNT(*) FROM STATUSES_COUNTERS WHERE STATUS IN ";
    
    String sSelectStatement = new StringBuffer(SELECT_STATEMENT).append(sStatuses).toString();
    
    return getSingleValue(sSelectStatement, null);
  }
  
  /**
   * Returns data for one HIGH VALUE status from the STATUSES_COUNTERS table.
   */
  public DTODataHolder getOneHighValueStatusDataFromSTATUSES_COUNTERS(String sMsgStatus)
  {
    final String SELECT_STATEMENT = 
         "SELECT COUNT_STATUS, SUM_BASE_AMOUNT, OFFICE_AMOUNT, MSG_TABLE FROM STATUSES_COUNTERS " +
         "WHERE STATUS = ? AND MSG_TABLE = 'MIF'";
  
    StatementParameter[] arrParameters = new StatementParameter[1];
    arrParameters[0] = new StatementParameter(sMsgStatus, Types.VARCHAR);
    
    return getData(SELECT_STATEMENT, arrParameters, 0);
  }
  
  /**
   * Returns data for one LOW VALUE status from the STATUSES_COUNTERS table.
   */
  public DTODataHolder getOneLowValueStatusDataFromSTATUSES_COUNTERS
                                  (String sMsgStatus, String sMinSettlementDate)
  {
    final String SELECT_STATEMENT_SELECTIVE_SETTLEMENTS_DATES = 
         "SELECT STATUS, TO_CHAR(STTLM_DT, 'YYYY-MM-DD') STTLM_DT, SUM(COUNT_STATUS) COUNT_STATUS, SUM(SUM_BASE_AMOUNT) SUM_BASE_AMOUNT " +
         "FROM STATUSES_COUNTERS " +
         "WHERE MSG_TABLE = 'LVMIF' AND TO_CHAR(STTLM_DT, 'YYYY-MM-dd') >= ? " +
         "AND STATUS = ? " +
         "GROUP BY STATUS, STTLM_DT " +
         "ORDER BY STTLM_DT";
    
    StatementParameter[] arrParameters = new StatementParameter[2];
    arrParameters[0] = new StatementParameter(sMinSettlementDate, Types.VARCHAR);
    arrParameters[1] = new StatementParameter(sMsgStatus, Types.VARCHAR);
    
    return getData(SELECT_STATEMENT_SELECTIVE_SETTLEMENTS_DATES, arrParameters, -1);
  }
  
  /**
   * Returns data for ALL low value parent nodes from the STATUSES_COUNTERS table;
   * i.e. the data for each status that summarizes the entire settlement dates for this status.
   */
  public DTODataHolder getLowValueStatusesParentsDataFromSTATUSES_COUNTERS()
  {
    final String SELECT_STATEMENT = 
         "SELECT STATUS, ' ', SUM(COUNT_STATUS) COUNT_STATUS, SUM(SUM_BASE_AMOUNT) SUM_BASE_AMOUNT " +
         "FROM STATUSES_COUNTERS " +
         "WHERE MSG_TABLE = 'LVMIF' " +
         "GROUP BY STATUS, ' '";
    
    return getData(SELECT_STATEMENT, 0);
    
  }
  
  /**
   * Returns the value of the settlement date which is the minimum date to display
   * as a sub node in a LOW VALUE status. 
   */
  public DTOSingleValue getMinSettlementDateForLowValueStatuses(int iQExplorerMinSettlementDays)
  {
    final String SELECT_STATEMENT = "SELECT TO_CHAR(MIN(STTLM_DT), 'YYYY-MM-dd') " +
                                    "FROM (SELECT STTLM_DT FROM (SELECT DISTINCT STTLM_DT " +
                                    "FROM ACC_POS " +
                                    "WHERE MEMBER_BK_CODE = '****' " +
                                    "ORDER BY STTLM_DT DESC) " +
                                    ms_DBType.getWhereClauseRownum(false,  
                                    			OperatorType.LTE, 
                                    			iQExplorerMinSettlementDays) + 
                                    ServerConstants.CLOSING_PARENTHESIS ; 
                                      
    return getSingleValue(SELECT_STATEMENT, null, null);
  }
  
  /**
   * Returns groups data for queue explorer data population.
   */
  public DTODataHolder getGroupsData()
  {
    final String SELECT_STATEMENT = 
         "SELECT QUEUEGROUPID, QUEUEGROUPNAME, NVL(QUEUEGROUPPARENT,0) AS QUEUEGROUPPARENT FROM QUEUEGROUPS ORDER BY QUEUEGROUPID";
  
    return getData(SELECT_STATEMENT, 0);
  }
  
 
  
  public PreparedStatement getFullCalcPrepareStatement(Connection conn) throws SQLException
  {
      final String SELECT_STATEMENT = "SELECT * FROM MINF WHERE P_IS_HISTORY = 0";
      
      return conn.prepareStatement(SELECT_STATEMENT);
  }
  
  
  
  
  public DTODataHolder getQueuesData(String condition)
  {
      String query = "select p_office, p_proc_dt, sum(AMOUNT) as AMOUNT, sum(COUNT) as COUNT from (" + 
                     "select p_office, p_proc_dt, p_base_amt as AMOUNT, 1 as COUNT" + 
                     "  from minf, banks" + 
                     " where ( " + condition + " ) and minf.p_office = banks.office" + 
                     "   and p_is_history = 0" + 
                     "   and (p_proc_dt is null or p_proc_dt > banks.history_proc_dt)" + 
                     " union all " + 
                     " select office as p_office, null as p_proc_dt, 0 as AMOUNT, 0 as COUNT" + 
                     "  from banks" + 
                     " where rec_status = 'AC')" + 
                     " group by p_office, p_proc_dt";
      
      return getData(query,0);
          
  }
  
  /**
   * Returns alerts data.
   */
  public PreparedStatement getAlertsData(Connection conn, String condition, String office) throws Exception
  {
      String query = "select count(*) as count, sum(p_base_amt) as amount from minf where ( "+condition+" ) and p_office = ? and P_SLA_NOTIFY_DATETIME <= ? and p_is_history = 0";
      PreparedStatement ps = conn.prepareStatement(query);
      
      com.fundtech.util.GlobalUtils.setObject(ps, 1,office);
      com.fundtech.util.GlobalUtils.setObject(ps, 2,new Timestamp(new Date().getTime()));
      
      return ps;
  }
}