package backend.core.module;

import java.math.BigInteger;

public interface MandateInquryConstantInterface

{

	public static final String MANDATE_INQURY_SERVICE_NAME="CBS-DirectDebitAuthInfo-I";
	public static final BigInteger ZERO_CONSTANT=new BigInteger("0");
	public static final String TRANSACTION_MODE="SEND";
	public static final String SUB_SYSTEM="Sys";
    public static final String TRANSACTION_CODE="0051";
    public static final String MANDATE_ID="GPP";
    public static final String ORGANIZATION="OCBC";
    public static final String REGION_AND_COUNTRY_CODE="SG";
    public static final String BLANK="";
    public static final String RQDETAILS_STATUS="ENQUIRY";
    public static final String SERVICE_LEVEL_CODE="IBG";
    public static final String GROUP_CODE="001";
    public static final String CURRENCY_CODE="SGD";
    public static final String SERVICE_CODE="IBG";
    public static final String AMOUNT_IND="Y";
  }
