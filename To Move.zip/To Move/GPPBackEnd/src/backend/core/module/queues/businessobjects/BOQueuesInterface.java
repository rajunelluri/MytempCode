package backend.core.module.queues.businessobjects;

import com.fundtech.core.security.Admin;

/**
 * internal interface for BOQueues.
 */
public interface BOQueuesInterface{

	
	
	/** 
	 * Inter-bean (system internal method) constructing the qlist query 
	 * based on the context configuration
	 * @Returns the select statement for the queue grid data.
	 * @bo.internalInterfaceqlist_todo: used in getQueueData_new
	 */
	public java.lang.StringBuilder getQueueListQuery(final Admin admin, backend.core.module.queues.businessobjects.BOQueues.Context ctx ) ;

}//EOI  