package backend.core.module.queues.ejbinterfaces;

import javax.ejb.Local;

/**
 * Local interface for Queues.
 */
@Local
public interface QueuesLocal extends Queues{} ; 