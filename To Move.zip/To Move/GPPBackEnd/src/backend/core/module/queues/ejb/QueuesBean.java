package backend.core.module.queues.ejb;

import javax.ejb.Stateless;
import backend.core.SuperSLSB;
import com.fundtech.core.security.Admin;
import backend.businessobject.proxies.interceptors.InterceptorSetType;
import backend.core.module.queues.ejbinterfaces.QueuesLocal;
import backend.core.module.queues.ejbinterfaces.Queues;

@Stateless
public class QueuesBean extends SuperSLSB<Queues> implements QueuesLocal, Queues{
	
	public QueuesBean() { super(backend.core.module.queues.businessobjects.BOQueues.class, InterceptorSetType.Complete) ; }//EOM
	
	
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent getMatchingActions(final Admin admin, java.lang.String mid ) throws java.lang.Exception {
		return this.m_bo.getMatchingActions(admin, mid ) ;
	}//EOM

	/** 
	 * Returns Group Actions data. 
	 * @bo.authorizeUser returnWebSessionInfo="true"
	 * qlist_todo: separate flow required!!
	 */
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent getGroupActions(final Admin admin, java.lang.String sMIDsList, boolean bLowValue ) {
		return this.m_bo.getGroupActions(admin, sMIDsList, bLowValue ) ;
	}//EOM

	/** 
	 * Returns queue list data. 
	 * @bo.authorizeUser returnWebSessionInfo="true"
	 */
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent getQueueData(final Admin admin, com.fundtech.core.queues.request.QueueListRequestData queueListRequestData ) {
		return this.m_bo.getQueueData(admin, queueListRequestData ) ;
	}//EOM

	/** 
	 * Returns Acknowledgments data. 
	 * @bo.authorizeUser returnWebSessionInfo="true"
	 */
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent getAcknowledgmentsData(final Admin admin, com.fundtech.core.queues.request.AcknowledgmentsRequestData acknowledgmentsRequestData ) {
		return this.m_bo.getAcknowledgmentsData(admin, acknowledgmentsRequestData ) ;
	}//EOM

	/** 
	 * Returns list of user defined queues in which the passed MID is included.
	 * @bo.authorizeUser returnWebSessionInfo="true"
	 */
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent getUserDefinedQueuesList(final Admin admin, java.lang.String sMID ) {
		return this.m_bo.getUserDefinedQueuesList(admin, sMID ) ;
	}//EOM

	@Override
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent getMidsDrillDownQueue(final Admin admin, com.fundtech.core.queues.request.QueueListRequestData requestData, java.lang.String[] midsArray) {
		return this.m_bo.getMidsDrillDownQueue(admin, requestData, midsArray);
	}

	@Override
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent getQueueDataForAccountPosition(final Admin admin, com.fundtech.core.queues.request.AccountPositionQueueListRequestData queueListRequestData) {
		return this.m_bo.getQueueDataForAccountPosition(admin,  queueListRequestData ) ;
	}

}//EOC