package backend.core.module.queues.businessobjects;

import static backend.businessobject.BOProxies.m_internalRuleExecutionLogging;
import static backend.core.module.MessageConstantsInterface.RULE_TYPE_ID_HISTORY_SEARCH;
import static backend.core.module.MessageConstantsInterface.RULE_TYPE_ID_TEMPLATE_SEARCH;
import static backend.core.module.MessageConstantsInterface.RULE_TYPE_ID_TRANSACTION_SEARCH;
import static backend.core.module.MessageConstantsInterface.RULE_TYPE_ID_BULK_SEARCH;
import static com.fundtech.cache.infrastructure.regions.CacheKeys.SystParKey;
import static com.fundtech.cache.infrastructure.regions.CacheKeys.statusesKey;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.apache.xmlbeans.impl.values.XmlObjectBase;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.businessobject.proxies.AuthorizeUser;
import backend.core.module.MessageConstantsInterface;
import backend.core.module.genservices.businessobjects.BOGeneralServices;
import backend.core.module.queues.dataaccess.dao.DAOQueues;
import backend.core.module.security.businessobjects.UserEntitlementData;
import backend.dataaccess.dao.DAOBasic;
import backend.dataaccess.dao.DBType;
import backend.dataaccess.dto.DTODataHolder;
import backend.dataaccess.dto.DTOSingleValue;
import backend.paymentprocess.positionkeeping.dao.DAOPositionKeeping;
import backend.paymentprocess.ruleexecution.businessobjects.BORuleExecution;
import backend.services.cache.ASCacheFactory;
import backend.staticdata.module.layout.factory.StaticDataFieldFactory;
import backend.staticdata.profilehandler.message.dataaccess.dao.PositionFiguresDAO;
import backend.util.ServerConstants;
import backend.util.ServerUtils;

import com.fundtech.annotations.DataSource;
import com.fundtech.annotations.Expose;
import com.fundtech.annotations.Wrap;
import com.fundtech.annotations.Expose.ExposureType;
import com.fundtech.cache.entities.LogicalFields;
import com.fundtech.cache.entities.MatchingCheck;
import com.fundtech.cache.entities.Prules;
import com.fundtech.cache.entities.PrulesFunctions;
import com.fundtech.cache.entities.QExplorer;
import com.fundtech.cache.entities.QueuePreferences;
import com.fundtech.cache.entities.Relationtypes;
import com.fundtech.cache.entities.RuleResult;
import com.fundtech.cache.entities.RuleResults;
import com.fundtech.cache.entities.SqlResource;
import com.fundtech.cache.entities.Statuses;
import com.fundtech.cache.entities.WebSessionInfo;
import com.fundtech.cache.infrastructure.CacheServiceInterface;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.cache.syspar.SystemParametersInterface;
import com.fundtech.core.general.PluginFactory;
import com.fundtech.core.general.StatementParameter;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.core.paymentprocess.data.das.DASInterface;
import com.fundtech.core.paymentprocess.data.das.PaymentInputSourceType;
import com.fundtech.core.paymentprocess.data.das.DASInterface.XmlLocationType;
import com.fundtech.core.paymentprocess.data.fields.DataType;
import com.fundtech.core.paymentprocess.data.fields.FieldType;
import com.fundtech.core.paymentprocess.ruleFunctions.FunctionInterface;
import com.fundtech.core.queues.request.AccountPositionQueueListRequestData;
import com.fundtech.core.queues.request.AcknowledgmentsRequestData;
import com.fundtech.core.queues.request.QueueListRequestData;
import com.fundtech.core.queues.response.NewAcknowledgmentsData;
import com.fundtech.core.queues.response.NewQueueListColumnMetaData;
import com.fundtech.core.queues.response.NewQueueListData;
import com.fundtech.core.queues.response.PageDirectionType;
import com.fundtech.core.queues.response.QueuesGetActionsResponse;
import com.fundtech.core.security.Admin;
import com.fundtech.core.security.Admin.CallSource;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.datacomponent.response.SimpleResponseDataComponent;
import com.fundtech.datacomponent.response.layout.FieldMetaData;
import com.fundtech.lang.OperatorType;
import com.fundtech.scl.commonTypes.FndtMsgType;
import com.fundtech.scl.commonTypes.impl.FndtMsgDocumentImpl;
import com.fundtech.spring.SpringApplicationContext;
import com.fundtech.util.ExceptionController;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalDateTimeUtil;
import com.fundtech.util.GlobalUtils;


/**
 * Title:       BOQueues
 * Description: Business object for core queues services
 * Company:     Fundtech Israel
 * Author:      Asaf Levy
 * Date:        01/01/2007
 * @version     1.0
 * 
 * @bo.wrap
 * @bo.internalInterface
 */ 
@Wrap(datasources={@DataSource(datasourceJndiKey="active"), 
		@DataSource(datasourceJndiKey="reporting")}, tx="Bean")
		
public class BOQueues extends BOGeneralServices  
{

	private final static Logger logger = LoggerFactory.getLogger(BOQueues.class);
	private static DAOQueues m_daoQueues = new DAOQueues();
	private PositionFiguresDAO m_posFiguresDAO = null;

	private static final String DEFAULT_COLUMN_WIDTH = "100";
	private static final String AND = " AND ";
	private static final String FALSE_CONDITION = "1=2 ";
	//multi values
	private static final String OCCURANCE_REGX = ".+\\[[\\d+]\\]";
	private static final String XML_MULTI      = "XML_MULTI";
	private static final String EXTRACTVALUE   = "EXTRACTVALUE";
	private static final String EXTRACT 	   = "EXTRACT";
	//
	private static final String DEFAULT_MAX_WEB_QUEUE = "500";
	private static final int INT_DEFAULT_MAX_WEB_QUEUE = 500;

	private static final String  PATTERN_FOR_STRING_ENDS_WITH_DATE = ".+(19|20)\\d\\d[- /.](0[1-9]|1[012])[- /.](0[1-9]|[12][0-9]|3[01])";
	private static final String QUEUE_NAME_WITH_DASH_PROCESSING_DATE = "-------";  
	// Queue types.
	public static final int QUEUE_TYPE_REGULAR  = 1;
	private static final int QUEUE_TYPE_GROUPING = 3;
	private static final int QUEUE_TYPE_VIRTUAL = 4;
	private static final int QUEUE_TYPE_USER_DEFINE = 5;

	private static final String QUEUE_TYPE_NAME_HISTORY  = "HISTORY";
	// List of LOW value columns to verify their existence in the queue list.
	private static final String FIELD_LVMIF_MID = "LVMIF.MID";
	private static final String FIELD_LVMIF_MSG_STATUS = "LVMIF.MSG_STATUS";
	private static final String FIELD_LVMIF_OFFICE = "LVMIF.OFFICE";
	final static String[] ARR_LOW_VALUE_COLUMNS_TO_CHECK = 
	{FIELD_LVMIF_MID, FIELD_LVMIF_MSG_STATUS, FIELD_LVMIF_OFFICE};

	// List of HIGH value columns to verify their existence in the queue list.
	private static final String FIELD_MIF_MID = "MIF.MID";
	private static final String FIELD_MIF_MSG_STATUS = "MIF.MSG_STATUS";
	private static final String FIELD_MIF_OFFICE = "MIF.OFFICE";
	private static final String FIELD_MIF_ORIG_MOP = "MIF.ORIG_MOP";
	private static final String FIELD_MIF_TIME_STAMP = "MIF.TIME_STAMP";
	final static String[] ARR_HIGH_VALUE_COLUMNS_TO_CHECK = 
	{FIELD_MIF_MID, FIELD_MIF_MSG_STATUS, FIELD_MIF_OFFICE, FIELD_MIF_ORIG_MOP, FIELD_MIF_TIME_STAMP};

	// Calling methods.
	public static final int CALLING_METHOD_GET_QUEUE_DATA  = 1;
	private static final int CALLING_METHOD_GET_SORTED_QUEUE_DATA  = 2;
	private static final int CALLING_METHOD_GET_QUEUE_GROUPING = 3;

	// Queue names.
	private static final String QUEUE_NAME_LVMIF = "LVMIF"; // TODO - remove when implementing low value statuses.
	private static final String QUEUE_NAME_HISTORY = "HISTORY";
	private static final String QUEUE_NAME_TRSR_HIS = "TRSR_HIS";
	private static final String QUEUE_NAME_NOT_FINAL = "NOT_FINAL";
	public static final String QUEUE_NAME_TRANS_SEARCH = "TRN_SRCH"; // old: TRANS_SEARCH
	public static final String QUEUE_NAME_BULK_SEARCH = "BULK_SRCH"; // old: TRANS_SEARCH
	private static final String QUEUE_NAME_TRANS_SEARCH_HISTORY = "TRSR_HIS"; //old: "TRANS_SEARCH_HISTORY";
	private static final String QUEUE_NAME_TRANS_SEARCH_TEMPLATE = "TEMPLATE_SRCH";
	private static final String QUEUE_NAME_RECON210 = "RECON210";	// TODO: Moran: I think this is an old remain that should be removed 
	//CR#87485 exclude HISOTRY search from queue permission
	private static final String[] ARR_SPECIAL_QUEUES = {QUEUE_NAME_BULK_SEARCH,QUEUE_NAME_LVMIF, QUEUE_NAME_TRANS_SEARCH, QUEUE_NAME_TRANS_SEARCH_HISTORY, QUEUE_NAME_RECON210, QUEUE_NAME_HISTORY, QUEUE_NAME_TRANS_SEARCH_TEMPLATE, "V_DD_OUTSTD", "V_DD_AC_AMNT", "V_DD_ACC_POS"};
	private List<String> LIST_SPECIAL_QUEUES = Arrays.asList(ARR_SPECIAL_QUEUES);
	
	private static final String[] DRILDOWN_QUEUES = {"V_DD_OUTSTD", "V_DD_AC_AMNT", "V_DD_ACC_POS"};
	private List<String> LIST_DRILDOWN_QUEUES = Arrays.asList(DRILDOWN_QUEUES);
	
	
	private final static String COUNT_COLUMN_FULL_NAME = "V.COUNT";


	final String QUEUE_NAME = "Queue name: ";

	private static final Map<String, String> m_mapXmlColumnsCache = new HashMap<String, String>() ; 
	public static ColumnMedataSet m_defaultColumnsMetadata ; 
	public static ColumnMedataSet m_mandatoryColumnsMetadata ; 

	private static LogicalFields m_defaultCountColumnLogicalField ; 
	private static NewQueueListColumnMetaData m_defaultCountColumnMetaData;

	private static final String COLUMN_INTERFACE_CONTENT = "INTERFACE_CONTENT"; 

	public enum FilterOptionType { 
		NONE, 
		USER, 
		SYSTEM
	}//EO enum 

	// Matrix holding meta data for the the toolbar 'Show queue' button' table.
	private static Object[][] arrUserDefinedQueuesListMetaData;

	// Static initializer.
	static{
		initDeafultCountColumn();
		initialiseDefaultColumnsMetadata() ; 
		initialiseJoinOnMinfClasues() ; 
		initUserDefinedQueuesListMetaDataMatrix();
	}//EO static block 

	/**
	 * Initializes the meta data matrix for the toolbar 'Show queue' button' table.
	 */
	private static void initUserDefinedQueuesListMetaDataMatrix()
	{
		arrUserDefinedQueuesListMetaData = new Object[4][2];
		arrUserDefinedQueuesListMetaData[0][0] = "SEARCH_SCREEN.V_QUEUE_NAME";
		arrUserDefinedQueuesListMetaData[0][1] = "PRULES.DESCRIPTION";

		arrUserDefinedQueuesListMetaData[1][0] = "STRING";
		arrUserDefinedQueuesListMetaData[1][1] = "STRING";

		arrUserDefinedQueuesListMetaData[2][0] = "25";
		arrUserDefinedQueuesListMetaData[2][1] = "25";

		StaticDataFieldFactory staticDataFieldFactory = StaticDataFieldFactory.getInstance();
		arrUserDefinedQueuesListMetaData[3][0] = staticDataFieldFactory.getField((String)arrUserDefinedQueuesListMetaData[0][0]).getAlias();
		arrUserDefinedQueuesListMetaData[3][1] = staticDataFieldFactory.getField((String)arrUserDefinedQueuesListMetaData[0][1]).getAlias();
	}

	/**
	 * qlist_todo: Add tableName - join clasue on minf tuples to this map  
	 * 
	 * May 28, 2008
	 * guys
	 *
	 */
	private static final void initialiseJoinOnMinfClasues() { 
		//m_mapJoinOnMinfClasuesCache
	}//EOM 

	private static final void initialiseDefaultColumnsMetadata() { 

		//rerieve all the logical fields from loigical fields whose 
		//default in queue view is 1 (logical fields cache) 
		//once the initialisation had completed clear the cache 
		final List<LogicalFields> listFields = new ArrayList<LogicalFields>() ; 

		CacheKeys.DefaultInQViewLogicalFieldsKey.get(listFields) ; 

		m_defaultColumnsMetadata =  initialiseColumnMetadataSet(false, null, listFields) ;

		//initialise the must have fields
		listFields.clear() ; 

		CacheKeys.MandatoryInQViewLogicalFieldsKey.get(listFields) ; 

		m_mandatoryColumnsMetadata = initialiseColumnMetadataSet(true, m_defaultColumnsMetadata, listFields) ;          
	}//EOM 

	private final static ColumnMedataSet initialiseColumnMetadataSet(final boolean bHideQlistColumns, 
			final ColumnMedataSet mergeColumnMetadata, final List<LogicalFields> listFields) {

		final ColumnMedataSet columnMetadataSet = new ColumnMedataSet() ; 

		//iterate over the fields and construct QueueListColumnMetaData for each
		final int iLength = listFields.size() ; 

		LogicalFields field  = null ; 

		for(int i=0; i < iLength; i++) { 
			field = listFields.get(i)  ; 

			columnMetadataSet.addNewColumn(field, (bHideQlistColumns ? -1 : i));        

			//if there is a merge set look up the field in the set and if it does not exist
			//add the field to the list (with visible order) 
			if(mergeColumnMetadata != null && !mergeColumnMetadata.contains(field))
				mergeColumnMetadata.addNewColumn(field, i) ;          

		}//EO while there are more default columns to initialise 

		return columnMetadataSet ; 
	}//EOM 

	/**
	 * Initializes the 'm_defaultColumnCountMetaData' class member.
	 */
	private static void initDeafultCountColumn(){
		m_defaultCountColumnLogicalField = new LogicalFields(COUNT_COLUMN_FULL_NAME, DataType.NUMBER, FieldType.DERIVED) ;
		m_defaultCountColumnLogicalField.setAlias("COUNT") ;
		m_defaultCountColumnLogicalField.setLocation("VIRTUAL") ; 
		m_defaultCountColumnLogicalField.setFieldDataType(DataType.NUMBER.name())  ;

		m_defaultCountColumnMetaData = new NewQueueListColumnMetaData(m_defaultCountColumnLogicalField, "0", 0, 2, DEFAULT_COLUMN_WIDTH);

		//sort-->will be done later depends on the num of column that needs to be displayed
	}//EOM 


	/**
	 * Constructor.
	 */
	public BOQueues()
	{
	}

	////////////////////////////////////////
	///// START 'getQueueData' METHODS /////
	////////////////////////////////////////

	/*
	 * Retruns the queue preferences buttons to be added to the queue toolbar
	 */
	private Object[] getQueuePreferencesButtons(String sOrigPermProfAccess)
	{
		// 'Define default queue preferences' button constants.
		final String BUTTON_ID_DEFINE_DEFAULT_Q_PREF = "Define default queue preferences";

		// 'Restore default queue preferences' button constants.
		final String BUTTON_ID_RESTORE_DEFAULT_Q_PREF = "Restore default queue preferences";
		final String ACCESS_LEVEL_DEFINE_DEFAULT_Q_PREF = "90256";

		Object[] arrQPrefButtons = new Object[2];
		arrQPrefButtons[0] = BUTTON_ID_RESTORE_DEFAULT_Q_PREF;

		//Checks the permission for button 'Define default queue preferences'
		if (sOrigPermProfAccess.contains(ACCESS_LEVEL_DEFINE_DEFAULT_Q_PREF))
		{
			arrQPrefButtons[1] = BUTTON_ID_DEFINE_DEFAULT_Q_PREF;
		}
		else
		{
			arrQPrefButtons[1] = null;
		}

		return arrQPrefButtons;
	}    

	/**
	 * Returns the dynamic buttons for the passed queue name, to be added to the 
	 * queue toolbar.
	 * 
	 * qlist_todo: used in getQueueData_new
	 */
	private Object[][] getVirtualQueueDynamicButtons(String sQueueName,String sPermissions)
	{

		final String COLUMN_BUTTON_ID = "BUTTON_ID";
		final String COLUMN_BUTTONDESCRIPTION = "BUTTONDESCRIPTION";
		final String COLUMN_ACCESS_LEVEL = "ACC_LVL_ID";

		Object[][] arrVirtualQueueDynamicButtons = null;

		DTODataHolder dto = m_daoQueues.getVirtualQueueDynamicButtons(sQueueName);

		Feedback feedback = dto.getFeedBack();

		if(feedback.isSuccessful() && !dto.isEmpty())
		{
			ArrayList alData = dto.getDataAL();
			int iSize = alData.size();

			List<Object[]> listVirtualQueueDynamicButtons = new ArrayList<Object[]>();

			for(int i=0; i<iSize; i++)
			{
				HashMap hmData = (HashMap)alData.get(i);

				String sButtonID = (String)hmData.get(COLUMN_BUTTON_ID);
				String sButtonDescription = (String)hmData.get(COLUMN_BUTTONDESCRIPTION);
				String sButtonAccessLevel = (String)hmData.get(COLUMN_ACCESS_LEVEL);
				//Permissions check for buttons with access level attached
				if(validateUserPermission(sPermissions,sButtonAccessLevel,-1,null) || 
						GlobalUtils.isNullOrEmpty(sButtonAccessLevel)) {
					listVirtualQueueDynamicButtons.add(new Object[] {sButtonID, sButtonDescription});     	  	  
				}
			}
			int iListSize = listVirtualQueueDynamicButtons.size();
			arrVirtualQueueDynamicButtons =  (iListSize > 0) ? listVirtualQueueDynamicButtons.toArray(new Object[iListSize][2]): null;

			if(!feedback.isSuccessful())
			{
				logger.error(ServerUtils.getFeedbackString(feedback));
			}
		}
		return arrVirtualQueueDynamicButtons;
	}



	/**
	 * Sets the queue type for the passed queue.
	 * 
	 * qlist_todo: used in getQueueData_new
	 */
	private int setQueueType(String sQueueName, boolean bVirtualQueue, boolean bHistoryQueue, boolean bIsQueueGroupingContext)
	{
		

		int iQueueType = QUEUE_TYPE_REGULAR;

		sQueueName = sQueueName.trim().toUpperCase();

		boolean bIsRecon210 = QUEUE_NAME_RECON210.equals(sQueueName);
		boolean bTransSearch =    QUEUE_NAME_TRANS_SEARCH.equals(sQueueName) 
		|| QUEUE_NAME_TRANS_SEARCH_HISTORY.equals(sQueueName)
		|| QUEUE_NAME_TRANS_SEARCH_TEMPLATE.equals(sQueueName);

		// TODO - Implement the second part of the 'GetQueueType(p_stAdmin, p_strQueueName)' method 
		//        from the '// Leonid D. Build additional WHERE conditions' part.
		if(bVirtualQueue){ 
			iQueueType = QUEUE_TYPE_VIRTUAL;
		}else if(!bVirtualQueue){       
			final Statuses msgSatusEntry = statusesKey.getSingle(sQueueName) ;

			/* DTOSingleValue dto = m_daoQueues.isUserDefineStatus(sQueueName);

      String sUserDefineQueue = ServerConstants.ZERO_VALUE;

      if(dto.isFeedBackSuccess() && !dto.isEmpty())
      {
        sUserDefineQueue = dto.getValue();
      }*/

			if(bIsRecon210)
			{
				iQueueType = QUEUE_TYPE_VIRTUAL;

				// Note:
					// In C++, there is a call to 'GetVirtualQueueCriteria', which calls the 
				// 'SP_GET_Q_CONDITION' store procedure; we call it in the 'getStartOfSelectStatementForQueueGridData' method.
			}

			else if(bTransSearch)
			{
				//qlist_todo: doont know why transaction search is treated as a virtual queue 
				iQueueType = QUEUE_TYPE_REGULAR;
				//iQueueType = QUEUE_TYPE_VIRTUAL;
			}

			else if(msgSatusEntry == null)
			{
				iQueueType = QUEUE_TYPE_USER_DEFINE;
			}

		}
		else if(bIsQueueGroupingContext) { 
			iQueueType = QUEUE_TYPE_GROUPING ; 
		}else
		{
			iQueueType = QUEUE_TYPE_USER_DEFINE;
		}


		logger.trace("Final queue type is : {}",  iQueueType);

		

		return iQueueType;
	}//EOM 

	/**
	 * Returns the page size.
	 * 
	 * qlist_todo: used in getQueueData_new
	 */
	private int getPageSize(){
		int iPageSize = INT_DEFAULT_MAX_WEB_QUEUE;

		//final String sWEBMAXQ = ((SystPar)Cache.getInstance().getSingle(CacheKeys.SystParKey,CacheKeys.SystParKey.prepareCacheEntryKey(SystemParametersInterface.SYS_PAR_WEBMAXQ))).getParmValue();

		final String sWEBMAXQ = SystParKey.getSingle(SystemParametersInterface.SYS_PAR_WEBMAXQ).getParmValue(); 

		if(!GlobalUtils.isNullOrEmpty(sWEBMAXQ)) iPageSize = Integer.valueOf(sWEBMAXQ).intValue();

		return iPageSize; 


	}//EOM 

	/**
	 * Checks permissions for some special queues.
	 * 
	 * qlist_todo: used in getQueueData_new
	 */
	private Feedback checkSpecialQueuesPermissions(String sQueueName, boolean bVirtualQueue,
			String sORIG_PERM_PROF_QUEUE){
		final String ERROR_MESSAGE = "You don't have permission to perform this action.";


		Feedback feedback = new Feedback();

		if( !(LIST_SPECIAL_QUEUES.contains(sQueueName) || bVirtualQueue) )
		{
			if(!validateUserPermission(sORIG_PERM_PROF_QUEUE, sQueueName, -1, null))
			{
				feedback.setFailure();
				feedback.setErrorCode(ERROR_CODE_GENERAL);
				feedback.setErrorText(ERROR_MESSAGE);
				feedback.setUserErrorText(ERROR_MESSAGE);
			}
		}

		

		return feedback;
	}//EOM 

	/**
	 * Gets a queue name, returns whether it's a search type queue, and checks if
	 * the user has permissions for message search.  
	 * 
	 * qlist_todo: used in getQueueData_new
	 * 
	 */
	private boolean checkTransactionSearchPermissions(String sQueueName, 
			String sORIG_PERM_PROF_ACCESS,
			Feedback feedback){

		final String ERROR_MESSAGE = "You don't have permission to perform this action.";
		final String ACCESS_LEVEL_MESSAGE_SEARCH = "20524";

		

		boolean bTransactionSearch = false;

		if(   QUEUE_NAME_TRANS_SEARCH.equals(sQueueName)
				|| QUEUE_NAME_TRANS_SEARCH_HISTORY.equals(sQueueName)
				|| QUEUE_NAME_TRANS_SEARCH_TEMPLATE.equals(sQueueName))
		{
			bTransactionSearch = true;

			if(!validateUserPermission(sORIG_PERM_PROF_ACCESS, ACCESS_LEVEL_MESSAGE_SEARCH, -1, null))
			{
				feedback.setFailure();
				feedback.setErrorCode(ERROR_CODE_GENERAL);
				feedback.setErrorText(ERROR_MESSAGE);
				feedback.setUserErrorText(ERROR_MESSAGE);
			}
		}

		

		return bTransactionSearch;
	}//EOM 


	/**
	 * Validates user permission for a non user defined queue.
	 * 
	 * qlist_todo: to be removed once the flow is merged with the getQueueData_new
	 */
	private boolean validateUserPermissionForNonUDQueue(String sPermission, String sQueueName)
	{
		String sFinalFieldToSearch = new StringBuffer(ServerConstants.APOSTROPHE)
		.append(sQueueName)
		.append(ServerConstants.APOSTROPHE).toString();

		return sPermission.indexOf(sFinalFieldToSearch) != -1;
	}


	//////////////////////////////////////
	///// END 'getQueueData' METHODS /////
	//////////////////////////////////////
	
	///////////////////////////////////////////
	///// START 'getGroupActions' METHODS /////
	///////////////////////////////////////////

	@Expose
	@AuthorizeUser(returnWebSessionInfo=true)  
	public SimpleResponseDataComponent getMatchingActions(String mid) throws Exception
	{
		SimpleResponseDataComponent response = new SimpleResponseDataComponent();
		Iterator<Relationtypes> iter = CacheKeys.relationtypesKey.getListIterator();

		PDO pdo = PaymentDataFactory.load(mid);
		QueuesGetActionsResponse queueActionResponse = null;

		Relationtypes relationType;
		List<String> relationTypesList = new ArrayList<String>();
		List<String> matchingCheckList = new ArrayList<String>();
		while(iter.hasNext())
		{
			relationType = (Relationtypes)iter.next();

			if (relationType.getSupportManualMatching())
			{
				RuleResults ruleResults = m_internalRuleExecutionLogging.executeRule(Admin.getContextAdmin(), MessageConstantsInterface.RULE_TYPE_ID_MATCHING_CHECK_PROFILE_SELECTION, 
						relationType.getUidRelationtypes(), pdo.getMID(), new String[]{pdo.getString(PDOConstantFieldsInterface.P_OFFICE), ServerConstants.DEFAULT_SERVER_OFFICE_NAME});


				List<RuleResult> listRuleResults = ruleResults.getResults();

				if(ruleResults.getCompletionCode() != RuleResults.CompletionCode.STOP && listRuleResults.size() > 0)
				{
					if (relationType.getMatchingButtonid() != null)
					{
						relationTypesList.add(relationType.getMatchingButtonid());
						matchingCheckList.add(listRuleResults.get(0).getAction());
					}
				}

			}
		}

		if (relationTypesList != null && relationTypesList.size() > 0)
		{
			queueActionResponse = new QueuesGetActionsResponse(relationTypesList.toArray(new String[relationTypesList.size()]), 
					matchingCheckList.toArray(new String[matchingCheckList.size()]) ,pdo.getString(PDOConstantFieldsInterface.P_OFFICE));
		}else
		{
			queueActionResponse = new QueuesGetActionsResponse();
		}

		response.setDataArray(new Object[]{queueActionResponse});

		return response;
	}

	/**
	 * Returns Group Actions data. 
	 * 
	 * @bo.authorizeUser returnWebSessionInfo="true"
	 * 
	 * qlist_todo: separate flow required!!
	 */
	@Expose
	@AuthorizeUser(returnWebSessionInfo=true)
	public SimpleResponseDataComponent getGroupActions(String sMIDsList, boolean bLowValue)
	{
		String sUserID = null;

		SimpleResponseDataComponent response = new SimpleResponseDataComponent();
		Feedback feedback = new Feedback();
		final WebSessionInfo webSessionInfo = Admin.getContextAdmin().getWebSessionInfo() ; 

		sUserID = webSessionInfo.getUserID() ; 

		String[] arrMIDs = sMIDsList.split(ServerConstants.TILDA);
		String sMIDs = null;
		String sPERM_PROF_ACCESS = null;
		String sMsgStatusCount = ServerConstants.ZERO_VALUE;
		String sMsgStatuses = null;

		// Step 1: check MIDs length:
			int iArrMidsLen = arrMIDs.length;
			boolean bIsMIDGroup = (iArrMidsLen>1)? true : false;
			if(iArrMidsLen==0) 
			{
				final String ERROR_MESSAGE = "No MINF Supplied";

				feedback.setFailure();
				feedback.setErrorCode(ERROR_CODE_GENERAL);
				feedback.setErrorText(ERROR_MESSAGE);
				feedback.setUserErrorText(ERROR_MESSAGE);

				logger.error(ServerUtils.getFeedbackString(feedback));
			}

			// Step 2: find Profiles access level (=PERM_PROF_ACCESS):
			if(feedback.isSuccessful())
			{ 
				sMIDs = ServerUtils.getDelimitedStringFromObjectArray(arrMIDs, ServerConstants.COMMA); // build comma seperated MID list
				sMIDs = ServerUtils.generateInForSelectClause(sMIDs);

				Object[] arrUserEntitlementDataHolder = new Object[1];
				feedback = getUserEntitlementData(arrUserEntitlementDataHolder);
				if(feedback.isSuccessful())
				{
					UserEntitlementData userEntitlementData = (UserEntitlementData)arrUserEntitlementDataHolder[0];
					sPERM_PROF_ACCESS = userEntitlementData.getPERM_PROF_ACCESS();
				}
			}                

			// Step 3: find Message statuses for selected MIDs:
			if(feedback.isSuccessful())
			{   
				String[] arrMsgStatus = new String[]{sMsgStatuses,sMsgStatusCount};
				feedback = getMsgStatusesForMIDs(sMIDs, bLowValue, arrMsgStatus, sUserID);
				sMsgStatuses = arrMsgStatus[0];
				sMsgStatusCount = arrMsgStatus[1];
			}

			// Step 4: check if the user selected any messages that he has no group permision for his status    
			if(feedback.isSuccessful())
			{   
				feedback = checkAllowedGroupActions(bIsMIDGroup, sMIDs, bLowValue, sUserID);
			}

			// Step 5: find group actions, sub-actions and payment office:
			if(feedback.isSuccessful())
			{
				QueuesGetActionsResponse queuesGetGroupActionsResponse = addGroupActions(sMIDs, sMsgStatuses, bIsMIDGroup, sPERM_PROF_ACCESS,
						sMsgStatusCount, bLowValue, sUserID);
				response.setDataArray(new Object[]{queuesGetGroupActionsResponse});
			}

			if(!feedback.isSuccessful())
			{
				response.setFeedback(feedback);
			}


			return response;
	}

	/**
	 * Returns String of message statuses for the passed MIDs
	 */ 
	private Feedback getMsgStatusesForMIDs(String sArrMIDs, boolean bLowValue, String[] arrMsgStatus,
			String sUserID){
		final String COLUMN_MSG_STATUS = "P_MSG_STS";

		

		DTODataHolder dto = m_daoQueues.getMsgStatuses(sArrMIDs, bLowValue);
		Feedback feedback = dto.getFeedBack();

		if(feedback.isSuccessful() && !dto.isEmpty())
		{
			ArrayList alData = dto.getDataAL();
			int iMsgStatusCount = alData.size();

			String[] arrMsgStatuses = new String[iMsgStatusCount];

			for(int i=0; i<iMsgStatusCount; i++)
			{
				HashMap hmData = (HashMap)alData.get(i);
				arrMsgStatuses[i] = (String)hmData.get(COLUMN_MSG_STATUS);
			}

			arrMsgStatus[0] = ServerUtils.getDelimitedStringFromObjectArray(arrMsgStatuses, ServerConstants.COMMA);
			arrMsgStatus[1] = Integer.toString(iMsgStatusCount);
		}

		else 
		{
			final String ERROR_MESSAGE = "Supplied MIDs are not in the database";

			feedback.setFailure();
			feedback.setErrorCode(ERROR_CODE_GENERAL);
			feedback.setErrorText(ERROR_MESSAGE);
			feedback.setUserErrorText(ERROR_MESSAGE);

			logger.error(ServerUtils.getFeedbackString(feedback));
		}

		

		return feedback;
	}//EOM 

	/**
	 * Check if the user selected any messages that he has no group permision for his status 
	 * 
	 * qlist_todo: used in getGroupActions
	 */
	private Feedback checkAllowedGroupActions(boolean bIsMIDGroup, String sArrMIDs, boolean bLowValue, 
			String sUserID){     
		

		Feedback feedback  = new Feedback();

		String sStatuses = getAllowedStatuses(bIsMIDGroup, sUserID);
		int iCount = getCountMsgStatus(sArrMIDs, sStatuses, bLowValue, sUserID);
		if(iCount>0) //There are MIDs with not allowed statuses for the user 
		{
			final String ERROR_MESSAGE = "One of the selected messages is in a none allowed group action";

			feedback.setErrorCode(ERROR_CODE_GENERAL);
			feedback.setErrorText(ERROR_MESSAGE);
			feedback.setUserErrorText(ERROR_MESSAGE);

			logger.error(ServerUtils.getFeedbackString(feedback));
		}

		

		return feedback;
	}//EOM 


	/**
	 * Returns String of allowed statuses for group actions
	 * 
	 * qlist_todo: used in getGroupActions
	 */
	private String getAllowedStatuses(boolean bIsMIDGroup, 
			String sUserID)
	{
		final String COLUMN_STATUS = "STATUS";

		

		String sStatuses = null;

		DTODataHolder dto = m_daoQueues.getAllowedStatuses(bIsMIDGroup);

		Feedback feedback = dto.getFeedBack();

		if(feedback.isSuccessful() && !dto.isEmpty())
		{
			ArrayList alData = dto.getDataAL();
			int iSize = alData.size();

			String[] arrStatuses = new String[iSize];

			for(int i=0; i<iSize; i++)
			{
				HashMap hmData = (HashMap)alData.get(i);
				arrStatuses[i] = (String)hmData.get(COLUMN_STATUS);
			}

			sStatuses = ServerUtils.getDelimitedStringFromObjectArray(arrStatuses, ServerConstants.COMMA);
		}

		if(!feedback.isSuccessful())
		{
			logger.error(ServerUtils.getFeedbackString(feedback));
		}

		

		return sStatuses;
	}//EOM

	/**
	 * Returns count of not allowed statuses for the passed MIDs.
	 * 
	 * qlist_todo: used in getGroupActions(via checkAllowedGroupActions)
	 */
	private int getCountMsgStatus(String sMIDs, String sMsgStatuses, boolean bLowValue,
			String sUserID)
	{
		

		int iCount = 0;

		DTOSingleValue dto = m_daoQueues.getMsgStatusCount(sMIDs, sMsgStatuses, bLowValue);

		if(dto.isFeedBackSuccess())    
		{
			iCount = Integer.valueOf(dto.getValue()).intValue();
		}
		else
		{
			logger.trace(ServerUtils.getFeedbackString(dto.getFeedBack()));
		}

		

		return iCount;
	}//EOM

	/**
	 * Returns group actions, sub-actions and payment office accroding to allowed statuses and permissions.
	 * 
	 */
	private QueuesGetActionsResponse addGroupActions(String sArrMIDs, String sMsgStatusesFromMIF, boolean bIsMIDGroup,
			String sPERM_PROF_ACCESS, String sMsgStatusCount, boolean bLowValue,
			String sUserID)
	{     
		final String COLUMN_BUTTONID = "BUTTONID";
		final String COLUMN_ACCS_LVL_ID = "ACCS_LVL_ID";

		String sOffice = null;
		Object[] arrActions = new Object[0];
		QueuesGetActionsResponse queuesGetGroupActionsResponse = new QueuesGetActionsResponse();;

		DTODataHolder dto = m_daoQueues.getButtonIds(sMsgStatusesFromMIF, bIsMIDGroup, sPERM_PROF_ACCESS, sMsgStatusCount, bLowValue);
		Feedback feedback = dto.getFeedBack();

		// loop through resultset and add sub-actions
		if(feedback.isSuccessful() && !dto.isEmpty())
		{
			ArrayList alData = dto.getDataAL();
			int iSize = alData.size();
			arrActions = new Object[iSize];
			for(int i=0; i<iSize; i++)
			{
				HashMap hmData = (HashMap)alData.get(i);
				String sButtonID = (String)hmData.get(COLUMN_BUTTONID);
				String sButtonPermission  = (String) hmData.get(COLUMN_ACCS_LVL_ID) ;

				//add the permissions to the button permissions cache in the as cache factory 
				//if does not exist already 
				ASCacheFactory.getInstance().putButtonGroupActionPermission(sButtonID, sButtonPermission) ;

				arrActions[i] = sButtonID;
			}

			queuesGetGroupActionsResponse = new QueuesGetActionsResponse(arrActions, null, sOffice);
		}

		if(!feedback.isSuccessful())
		{
			logger.error(ServerUtils.getFeedbackString(feedback));
		}

		

		return queuesGetGroupActionsResponse;
	}//EOM 

	///////////////////////////////////////////
	///// END 'getGroupActions' METHODS /////
	///////////////////////////////////////////

	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//NEW METHODS     NEW METHODS     NEW METHODS     NEW METHODS     NEW METHODS     NEW METHODS     NEW METHODS                   
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	/**
	 * Returns queue list data. 
	 * 
	 *  @bo.authorizeUser returnWebSessionInfo="true"
	 */
	@Expose
	@AuthorizeUser(returnWebSessionInfo=true)
	public SimpleResponseDataComponent getQueueData(QueueListRequestData queueListRequestData){

		//initialize the flow context which shall be the thread connecting all methods 
		//queueListRequestData.setFilterXml("<pruleConditions xmlns=\"http://Fundtech.com/prule-metadata-dto.xsd\"><cond lineNumber=\"01\"><leftVal CT=\"Field\" value =\"[P_IS_HISTORY]\"></leftVal><op><![CDATA[>=]]></op><rightVal CT=\"Value\" value =\"20141014\"></rightVal></cond><cond lineNumber=\"11\"><andOr>AND</andOr><leftVal CT=\"Field\" value =\"[P_IS_HISTORY]\"></leftVal><op><![CDATA[<=]]></op><rightVal CT=\"Value\" value =\"20141015\"></rightVal></cond></pruleConditions>");
		//queueListRequestData.setQueueName("TRN_SRCH");
		final Context ctx = new Context(queueListRequestData) ; 
		
		queueListRequestData.getFilter().toString(false, false , null) ;
		SimpleResponseDataComponent response = new SimpleResponseDataComponent();

		ctx.iQueueType = QUEUE_TYPE_REGULAR; 

		final WebSessionInfo webSessionInfo = Admin.getContextAdmin().getWebSessionInfo() ; 

		ctx.sUserID = webSessionInfo.getUserID() ; 

		final Object[] arrUserEntitlementDataHolder = new Object[1];

		Feedback feedback = this.getUserEntitlementData(arrUserEntitlementDataHolder);

		//if the getUserEntitlementData operation had failed 
		if(!feedback.isSuccessful()) { 
			response.setFeedback(feedback);
			return response ; 
		}//EO if the getUserEntitlementData operation had failed 

		ctx.userEntitlementData = (UserEntitlementData)arrUserEntitlementDataHolder[0];
		final String sORIG_PERM_PROF_QUEUE = ctx.userEntitlementData.getORIG_PERM_PROF_QUEUE();


		feedback = this.checkSpecialQueuesPermissions(ctx.sQueueName, ctx.bIsVirutalQueue, sORIG_PERM_PROF_QUEUE);


		//if the checkSpecialQueuesPermissions operation had failed 
		if(!feedback.isSuccessful()) { 
			response.setFeedback(feedback);
			return response ; 
		}//EO if the checkSpecialQueuesPermissions operation had failed 

		final String sORIG_PERM_PROF_ACCESS = ctx.userEntitlementData.getORIG_PERM_PROF_ACCESS();
		ctx.bTransactionSearch = this.checkTransactionSearchPermissions(ctx.sQueueName, sORIG_PERM_PROF_ACCESS, feedback); 
		ctx.bIsDrillDownQueue = this.isDrilDownQueue(ctx.sQueueName);

		// For web service - change the input page size only if it greater than the default one
		int defaultPageSize = getPageSize();
		if (Admin.getContextAdmin().getCallSource() == CallSource.Service) {
			boolean changePageSize = ctx.iPageSize > 0 && ctx.iPageSize > defaultPageSize;
			ctx.iPageSize = changePageSize ? defaultPageSize : ctx.iPageSize;		
		} else { // Not web service call
			//    use big pade for transaction search
			ctx.iPageSize = (ctx.bTransactionSearch || ctx.bIsDrillDownQueue) && !ctx.bExportToExcel ? getPageSize() : ctx.iPageSize;
		}

		//if the checkTransactionSearchPermissions operation had failed 
		if(!feedback.isSuccessful()) { 
			response.setFeedback(feedback);
			return response ; 
		}//EO if the checkTransactionSearchPermissions operation had failed 

		ctx.bHistoryQueue = ctx.sQueueName.indexOf(QUEUE_NAME_HISTORY) != -1 || ctx.sQueueName.indexOf(QUEUE_NAME_TRANS_SEARCH_HISTORY) != -1;

		// Sets the queue type.
		ctx.iQueueType = this.setQueueType(ctx.sQueueName, ctx.bIsVirutalQueue, ctx.bHistoryQueue,  ctx.bIsQueueGroupingContext);

		// attempt to retrieve the meta data from queuePreferences cache
		ctx.sUserID = webSessionInfo.getUserID() ; 
		//ctx.sFilterXml = "<pruleConditions xmlns=\"http://Fundtech.com/prule-metadata-dto.xsd\"><cond lineNumber=\"01\"><leftVal CT=\"Field\" value =\"[Department]\"></leftVal><op>Between</op><rightVal CT=\"Between\" value =\"LDN,[Office]\"></rightVal></cond></pruleConditions>" ;
		boolean bFilterExist = !GlobalUtils.isNullOrEmpty(ctx.sFilterXml) ; 

		//initialize the filter option which shall indicate whether to use request or cached filter.   
		//if the former, then whether to cacheit thus overriding existing one or not.
		ctx.enumFilterType = (queueListRequestData.getFilterOption() == null ? FilterOptionType.NONE : 
			FilterOptionType.valueOf(queueListRequestData.getFilterOption())) ; 


		//qlist_todo: dont know if virtual queues conditions should be added in all request contexts
		if(ctx.iQueueType == QUEUE_TYPE_VIRTUAL){

			String mid = StringUtils.isNotEmpty(ctx.sSelectedMID)? ctx.sSelectedMID : ctx.sMID ;
			
			//first, as this is not a part of a payment process, the pdo corresponding to the given 
			//MID must be loaded 
			final PDO pdo = PaymentDataFactory.load(mid) ; 

			// special handling for matching button.
			if (!GlobalUtils.isNullOrEmpty(queueListRequestData.getMatchingCheckUid()))
			{
				String matchingCheckUid = queueListRequestData.getMatchingCheckUid();
				boolean shouldContinueWithMatching = true;
				//          When the virtual queue is open and the user move the focus in the upper window to another message in the Qlist, 
				//          need to check if the last relation type (opened virtual queue) is also relevant for this new message 
				//          (run the Matching profile selection rule only with the opened virtual queue relation type) and if yes then invoke the SQL statement as described in the above item
				if (queueListRequestData.getVerifyMatching())
				{
					try
					{
						shouldContinueWithMatching = false;                  
						Object[] dataResponseArr = getMatchingActions(pdo.getMID()).getDataArray();
						if (dataResponseArr != null && dataResponseArr.length > 0)
						{
							QueuesGetActionsResponse matchingReslt= (QueuesGetActionsResponse)dataResponseArr[0];
							String[] actionArr = (String[])matchingReslt.getGroupActions();
							String[] matchingCheckUidArr = matchingReslt.getMatchingCheckProfileArr();
							if (actionArr != null && matchingCheckUidArr !=null)
							{
								int length = actionArr.length; 
								for (int i=0; i< length && !shouldContinueWithMatching; i++)
								{
									//                             verify that the same found for the new mid.
									if (actionArr[i].equals(queueListRequestData.getActionId()) && matchingCheckUidArr[i].equals(matchingCheckUid))
										shouldContinueWithMatching = true;
								}
							}
						}
					}catch(Exception e)
					{
						ExceptionController.getInstance().handleException(e, this);
					}
				}
				if (shouldContinueWithMatching)
				{
					try
					{
						MatchingCheck matchingCheck = CacheKeys.matchingCheckKey.getSingle(matchingCheckUid);
	
						if (matchingCheck != null)
						{
							String ruleUid = matchingCheck.getManualMatchAlgUidPrules();
							if (ruleUid != null)
							{
								Prules rule =  CacheKeys.PRulesUIDKey.getSingle(ruleUid);
	
								ctx.sVirtualQueueFilterPart = rule.getExecWhere() ;
	
								final List<Object[]> listBindingParameters = rule.getBindWhereBindingParameters() ; 
	
								if(!listBindingParameters.isEmpty()) { 
	
									final String TRACE_FIELD_LOGICAL_ID_AND_VALUE = "Field logical ID: {}, Value: {}.";
									final String TRACE_FUNCTION_VALUE = "Function: {}, Value: {}.";
	
									ctx.listStatementParameters = new ArrayList<StatementParameter>() ;
									LogicalFields bindingField = null ; 
									Object oValue =  null ; 
									
									for(Object[] arrFieldMetadata : listBindingParameters) 
									{
										if(arrFieldMetadata[0] instanceof LogicalFields)
										{
											bindingField = (LogicalFields) arrFieldMetadata[0] ;
											String sFieldLogicalID = bindingField.getFieldLogicalId();
											oValue = pdo.get(sFieldLogicalID) ; 
											ctx.listStatementParameters.add(new StatementParameter(oValue, bindingField.getDataType().getSqlDataType(), false)) ;
											logger.info(TRACE_FIELD_LOGICAL_ID_AND_VALUE, sFieldLogicalID, oValue);
										}
										else // Assumes function.
										{
											// Edits the binding data array to include only the relevant items. 
											final String ITEM_TO_OMIT = "@#";
											Object[] arrOrigBindingData = (Object[])arrFieldMetadata[1];
											List listEditedBindingData = new ArrayList<String>();
											
											for(int k=0; k<arrOrigBindingData.length; k++)
											{
												if(!arrOrigBindingData[k].equals(ITEM_TO_OMIT)) listEditedBindingData.add(arrOrigBindingData[k]);
											}
											
											// Invokes the function.
											oValue = ((FunctionInterface)arrFieldMetadata[0]).invoke(listEditedBindingData.toArray());
											
											int iDataType = ((FunctionInterface)arrFieldMetadata[0]).getDataType();
											PrulesFunctions prulesFunctions = CacheKeys.PRulesFunctionsKey.getSingle(((FunctionInterface)arrFieldMetadata[0]).getAlias());
											String sFuncRetType = prulesFunctions.getOutputParameterType();
											
											// e.g. MULTI_RECORD_EXISTS.
											if(iDataType == -7 && FieldMetaData.FIELD_TYPE_BOOL.equals(sFuncRetType)) oValue = (Boolean)oValue ? ServerConstants.STRING_BOOLEAN_VALUE_TRUE : ServerConstants.STRING_BOOLEAN_VALUE_FALSE;
											
											ctx.listStatementParameters.add(new StatementParameter(oValue, iDataType)) ;
											logger.info(TRACE_FUNCTION_VALUE, ((FunctionInterface)arrFieldMetadata[0]).getAlias(), oValue);
										}
									}//EO while there are more binding parameters 
	
								}//EO if there were binding parameters                 
							}
						}
					}
					catch(Exception e)
					{
						ExceptionController.getInstance().handleException(e, this);
					}
				}
			}else
			{
				//set the action id into the pdo so as to make it available for rules
				pdo.set(PDOConstantFieldsInterface.D_BUTTON_ID, queueListRequestData.getActionId()) ; 

				//secondly, execute the rule which shall return the reskey with which to extract the condition 
				//from sqlResource cache, use the following data: 
				//rule type id 107, payment MID and payment office retrieved from the PDO 
				final Admin admin = Admin.getContextAdmin() ; 

				try{ 
					final List<RuleResult> listRuleResults = 
						m_internalRuleExecutionLogging.executeRule(admin, MessageConstantsInterface.RULE_TYPE_ID_VIRTUAL_QUEUE_SELETION, 
								null, mid, new String[]{pdo.getString(PDOConstantFieldsInterface.P_OFFICE), ServerConstants.DEFAULT_SERVER_OFFICE_NAME}).getResults(); 

					//CR#82067-->>Added this condition to avoid null pointer exception if listRuleResults is null for virtual queue data
					if(!listRuleResults.isEmpty())
					{
						//use the message status returned as the key to the statuses cache
						final Statuses msgStatusEntry = statusesKey.getSingle(listRuleResults.get(0).getAction()) ;

						//qlist_todo: for debug
						/*final Statuses msgSatusEntry = (Statuses) Cache.getInstance().getSingle(CacheKeys.statusesKey,
                        CacheKeys.statusesKey.prepareCacheEntryKey("COMEX")) ; //REPAIR */ 
						//qlist_todo: for debug

						ctx.setQueueName(msgStatusEntry.getMsgStatus()) ; 

						//use the status's content source as the key to the sqlResource cache 
						final SqlResource sqlResourceEntry = 
							CacheKeys.SqlResourceKey.getSingle(msgStatusEntry.getContentSource()) ; 

						//store the actual filter part in the context 
						ctx.sVirtualQueueFilterPart = sqlResourceEntry.getExecScript() ;            

						//create statement parameters bindings from the sqlResourceEntry logical fields list. 
						final List<Object[]> listBindingParameters = sqlResourceEntry.getBindingParameters() ; 

						if(!listBindingParameters.isEmpty()) { 
							ctx.listStatementParameters = new ArrayList<StatementParameter>() ;
							LogicalFields bindingField = null ; 
							Object oValue =  null ; 
							DataType enumDataType = null ; 

							for(Object[] arrFieldMetadata : listBindingParameters) {
								bindingField = (LogicalFields) arrFieldMetadata[0] ;  

								oValue = pdo.get(bindingField.getFieldLogicalId()) ; 
								enumDataType = bindingField.getDataType() ; 

								ctx.listStatementParameters.add(enumDataType.newStatementParameter(bindingField, oValue)) ;  
							}//EO while there are more binding parameters 

						}//EO if there were binding parameters 
					} //EO if listRuleResults is not empty

				}catch(Exception e) { 
					ExceptionController.getInstance().handleException(e, this) ; 
				}//EO catch block
			}

		}//EO if the queue type was Virtual Queue 

		String tranSrcFilterWhereOrig = GlobalConstants.EMPTY_STRING;
		String tranXmlConditionOrig = GlobalConstants.EMPTY_STRING;
		
		try{

			//CR#87485->Modifying queue preference for History search, transaction search & template search.
			String strRuleTypeID = RULE_TYPE_ID_TRANSACTION_SEARCH;
			if(ctx.sActualQueueName.indexOf(QUEUE_NAME_HISTORY) != -1)
			{
				strRuleTypeID = RULE_TYPE_ID_HISTORY_SEARCH;
			}
			
			else if(ctx.sActualQueueName.indexOf(QUEUE_NAME_TRSR_HIS) != -1)
			{
				strRuleTypeID = RULE_TYPE_ID_HISTORY_SEARCH;
			}
			
			
			else if(ctx.sActualQueueName.indexOf(QUEUE_NAME_TRANS_SEARCH_TEMPLATE) != -1)
			{
				strRuleTypeID = RULE_TYPE_ID_TEMPLATE_SEARCH;
			}

			String sQueueName  = ctx.sActualQueueName;
			//String that ends with date (format equal to YYYY-MM-DD)
			final Pattern pDatePattern = Pattern.compile(PATTERN_FOR_STRING_ENDS_WITH_DATE);
			Matcher mDateMatcher = pDatePattern.matcher(sQueueName);
			if (mDateMatcher.matches() || sQueueName.indexOf(QUEUE_NAME_WITH_DASH_PROCESSING_DATE) > -1)
			{
				int iLength = (sQueueName.indexOf(QUEUE_NAME_WITH_DASH_PROCESSING_DATE) > -1) ?  16 : 13;
				sQueueName =  sQueueName.substring(0, sQueueName.length()-iLength); 
			}

			//attempt to reriteve the queue preferences from the cache  
			String preferQueueName = ctx.bTransactionSearch ? sQueueName.split("\\|\\|\\|")[0] : sQueueName;
			//String preferQueueName = sQueueName.split("\\|\\|\\|")[0];
			
			
			//This is Zachi
			if (ctx.isBulkSearch)
			{
				strRuleTypeID = RULE_TYPE_ID_BULK_SEARCH;
				preferQueueName = preferQueueName.replace(QUEUE_NAME_TRANS_SEARCH, QUEUE_NAME_BULK_SEARCH);
			}
			
			ctx.queuePreferences =  CacheKeys.QueuePreferencesKey.getSingle(strRuleTypeID, preferQueueName, ctx.sUserID) ;
			if(null != ctx.queuePreferences)
			{
				tranSrcFilterWhereOrig = ctx.queuePreferences.getFilterWhere();
				tranXmlConditionOrig = ctx.queuePreferences.getXmlConditions();
			}
			
			
			boolean bIsUserPrefNotDefined = ctx.queuePreferences == null;
			//if queue pref is null & queue preferences is not to be deleted for specific user then needs to take defined default queue preferences for user id  = '********'
			if( bIsUserPrefNotDefined || ctx.queuePreferences.isToBeDeleted() == true)
			{
				ctx.queuePreferences =  CacheKeys.QueuePreferencesKey.getSingle(strRuleTypeID, preferQueueName, "********") ;         
			}


			//if a filter string exists, whether user or system, parse it to produce the sql additional 
			//where clasue condition to use     
			if(bFilterExist) { 

				if (ctx.isBulkSearch)
				{
					strRuleTypeID = RULE_TYPE_ID_TRANSACTION_SEARCH;
				}
				
				//if the filter exists, then this is either a new or a modified one which 
				//in both cases means that it should be parsed. 
				final Admin admin = Admin.getContextAdmin() ; 
				final BORuleExecution.ConditionParsingResults conditionParsingResponse = 
					m_internalRuleExecutionLogging.processRuleConditions(admin, strRuleTypeID, null, ctx.sFilterXml, null/*connection*/, null/*preparedStatmeent*/, true/*for immediate use*/, ctx.isBulkSearch) ; 

				//This is Zachi
				if (ctx.isBulkSearch)
				{
					strRuleTypeID = RULE_TYPE_ID_BULK_SEARCH;
				}
								
				
				//If there was a condition parsing error 
				if(!conditionParsingResponse.isSuccessful()) { 
					response.setFeedback(conditionParsingResponse.getFeedback()) ;  
					return response ; 
				}//If there was a condition parsing error 

				//if the preferences instance does not exist, then this is a new filter, 
				//create a new cache entry as cache it if the filter is a user filter 
				if( bIsUserPrefNotDefined) {

					//This is Zachi
					if (ctx.isBulkSearch)
					{
						strRuleTypeID = RULE_TYPE_ID_BULK_SEARCH;
						sQueueName = sQueueName.replaceAll(QUEUE_NAME_TRANS_SEARCH, QUEUE_NAME_BULK_SEARCH);
					}
					
					
					QueuePreferences queuePreferences = new QueuePreferences(strRuleTypeID, sQueueName, ctx.sUserID);//zachi
					//if default preferences exist
					if(ctx.queuePreferences != null) {
						//copy queue preferences from default
						queuePreferences.setColumns( ctx.queuePreferences.getColumns());
						queuePreferences.setColumnsSize( ctx.queuePreferences.getColumnsSize());
						queuePreferences.setSortByFields( ctx.queuePreferences.getSortByFields());                                       
					}
					ctx.queuePreferences = queuePreferences;  

					//cache the new preferences 
					if(ctx.enumFilterType == FilterOptionType.USER) 
						//This is Zachi
						if (ctx.isBulkSearch)
						{
							String tempQueueName = ctx.queuePreferences.getQueueName();
							tempQueueName = tempQueueName.replaceAll(QUEUE_NAME_TRANS_SEARCH, QUEUE_NAME_BULK_SEARCH );
							ctx.queuePreferences.setQueueName(tempQueueName);
							ctx.queuePreferences.setRuleTypeId(RULE_TYPE_ID_BULK_SEARCH);
						}
						
						CacheServiceInterface.eINSTANCE.putSingle(CacheKeys.QueuePreferencesKey, ctx.queuePreferences) ;
					//EO if the queue preferences did not exist
				}else if(ctx.enumFilterType == FilterOptionType.SYSTEM) {
					ctx.orginalPreferences = ctx.queuePreferences ; 
					ctx.queuePreferences = ctx.queuePreferences.clone() ; 
				}//EO else if the filter is a system filter and there is an already cached existing preferences instance  

				//set the parsed script values into the queue preferences which may override an 
				//existing value 
				

					
					ctx.queuePreferences.setFilterWhereTables(conditionParsingResponse.getWhereClauseTables()) ;
					ctx.queuePreferences.setXmlConditions(ctx.sFilterXml) ;
					ctx.queuePreferences.setFilterWhere(conditionParsingResponse.getWhereClasueScript()) ;
	
					ctx.queuePreferences.initTableNames() ;
					
					if(ctx.enumFilterType == FilterOptionType.USER) 
					{
						
						
						//This is Zachi
						if (ctx.isBulkSearch)
						{
							String tempQueueName = ctx.queuePreferences.getQueueName();
							tempQueueName = tempQueueName.replaceAll(QUEUE_NAME_TRANS_SEARCH, QUEUE_NAME_BULK_SEARCH );
							ctx.queuePreferences.setQueueName(tempQueueName);
							ctx.queuePreferences.setRuleTypeId(RULE_TYPE_ID_BULK_SEARCH);
						}

						
						
			//			CacheServiceInterface.eINSTANCE.putSingle(CacheKeys.QueuePreferencesKey, ctx.queuePreferences) ;
					}
					
					
				//}
			}else if(ctx.queuePreferences != null && ctx.enumFilterType == FilterOptionType.NONE && 
					ctx.queuePreferences.getFilterWhere() != null){//EO if the filter should be used
				ctx.orginalPreferences = ctx.queuePreferences ; 
				//if there are no column prefernces nullify the context prefernces else clone 
				if(ctx.queuePreferences.getColumns() == null) ctx.queuePreferences = null ;  
				else ctx.queuePreferences = ctx.queuePreferences.clone() ; 
			}//EO else if no filter was received from the client but there were preferences and they contained a filter (which should not be used) AND they conatined column preferences


		}catch(Exception e) { 
			logger.error(e.getMessage());
			feedback.setFailure() ; 
			feedback.setErrorCode(ERROR_CODE_GENERAL);
			feedback.setErrorText(e.getMessage());
			feedback.setUserErrorText(e.getMessage());
			response.setFeedback(feedback);
			return response ; 
		}//EO catch block 

		// Gets the meta data.
		
		
		 if (ctx.isBulkSearch)
		{
			String tempQueueName = ctx.queuePreferences.getQueueName();
			tempQueueName = tempQueueName.replaceAll(QUEUE_NAME_BULK_SEARCH,QUEUE_NAME_TRANS_SEARCH );
			
			
			ctx.queuePreferences.setQueueName(tempQueueName);
			ctx.queuePreferences.setRuleTypeId(RULE_TYPE_ID_TRANSACTION_SEARCH);
		}
		
		this.getQueueGridMetaData(ctx) ; 

		//if the getQueueGridMetaData_new operation had failed 
		if(!ctx.feedback.isSuccessful()) { 
			response.setFeedback(ctx.feedback);
			return response ; 
		}//EO if the getQueueGridMetaData_new operation had failed 

		ctx.sOffice = webSessionInfo.getDefaultOffice() ; 

		//if the queue counter is above the threshold of a give systpar, the convert the queue type to ordered 
		//and set the P_MID as the sort by column
		///qlist_todo: get the systpar and the counter

		//uncomment this when the systpar was defined 
		// String sMAXQMSGS = ((SystPar)Cache.getInstance().getSingle(CacheKeys.SystParKey,CacheKeys.SystParKey.prepareCacheEntryKey(SystemParametersInterface.SYS_PAR_MAXQMSGS))).getParmValue();
		//if(GlobalUtils.isNullOrEmpty(sMAXQMSGS)) sMAXQMSGS = DEFAULT_MAX_QUEUE_MESSAGES;
		//if(ctx.iQueueMessageCounter > sMAXQMSGS) {

		// Page direction check.

		//parse and validate the page direction in the context of the MID 
		this.validatePageDirection(queueListRequestData, ctx);

		//if the validatePageDirection_new operation had failed 
		if(!ctx.feedback.isSuccessful()) { 
			response.setFeedback(ctx.feedback);
			return response ; 
		}//EO if the validatePageDirection_new operation had failed	
		
		this.getQueueGridData(ctx);
		
		/*if (ctx.isBulkSearch)
		{
			ctx.queuePreferences.setFilterWhere(tranSrcFilterWhereOrig) ;
			ctx.queuePreferences.setXmlConditions(tranXmlConditionOrig) ;
		}
		*/

		//if the getQueueGridData_new operation had failed 
		if(!ctx.feedback.isSuccessful()) { 
			response.setFeedback(ctx.feedback);
			return response ; 
		}//EO if the getQueueGridData_new operation had failed 

		// Gets dynamic buttons for virtual queues; no need for that in LOW value queues.
		final Object[][] arrVirtualQueueDynamicButtons = ctx.bLowValue ? null : this.getVirtualQueueDynamicButtons(ctx.sQueueName,sORIG_PERM_PROF_ACCESS);

		// Gets the queue buttons flags, in a 3-length array.
		// Order is: first, next, previous.
		final boolean[] arrQueueButtonFlags = this.getQueueButtonFlags(ctx); ;

		// Gets the queue filter preferences for this queue.
		//qlist_todo: as the filter would now be rertieved from servecr at each 
		//client open-search screen request there is no need to send it to the client 
		// qlist_todo: dont think this will be reuired here but in the do before create of 
		//the search screen
		/*
    final Object[] arrQueueFilterPrefs = new Object[3];
    this.getQueueFilterPrefs_new(sFilterXml, sQueueName, sUserID, arrQueueFilterPrefs, bLowValue);

    final String sQueueOtherCriteria = (arrQueueFilterPrefs[2] != null ? 
                                       (String)arrQueueFilterPrefs[2] : 
                                        null
                                       ); 
		 */ 

		//if this is a sorted queue requeset remove the direction and navigation buttons 
		boolean bDisplayFirstPageButton = false;
		boolean bDisplayLastPageButton = false;  
		boolean bDisplayNextPageButton = false ; 
		boolean bDisplayPreviousPageButton = false ; 


		//Gets the Queue Preferences Buttons
		Object[] arrQPrefButtons = getQueuePreferencesButtons(sORIG_PERM_PROF_ACCESS);

		if(!ctx.bIsSortedQueue) { 
			bDisplayFirstPageButton = arrQueueButtonFlags[0] ;
			bDisplayLastPageButton = arrQueueButtonFlags[1] ;
			bDisplayNextPageButton =  arrQueueButtonFlags[2] ; 
			bDisplayPreviousPageButton = arrQueueButtonFlags[3] ;
		}else{//EO if the queue was not sorted 
			ctx.enumPageDirection = PageDirectionType.None ; 
		}//EO if the queue was sorted
		
		
		final NewQueueListData queueListData = 
			new NewQueueListData(ctx.sQueueName, String.valueOf(ctx.iQueueType), ctx.enumPageDirection,
					String.valueOf(ctx.iPageSize), ctx.sMode,
					ctx.listMetaData, ctx.arrGridData, 
					bDisplayFirstPageButton, bDisplayLastPageButton, bDisplayNextPageButton, bDisplayPreviousPageButton, 
					arrVirtualQueueDynamicButtons,arrQPrefButtons);
		
		if (ctx.queuePreferences != null)  
		{
			String columns = ctx.queuePreferences.getColumns();
			queueListData.setM_columns(columns);
		}
		
		response.setDataArray(new Object[]{queueListData});
		return response;
	}//EOM 
	
	private boolean isDrilDownQueue(String sQueueName) {
		return LIST_DRILDOWN_QUEUES.contains(sQueueName);
	}

	/**
	 * Returns queue list data. 
	 * 
	 *  @bo.authorizeUser returnWebSessionInfo="true"
	 */
	@Expose
	@AuthorizeUser(returnWebSessionInfo=true)
	public SimpleResponseDataComponent getMidsDrillDownQueue(QueueListRequestData requestData, java.lang.String[] midsArray){

		String filterXML = null;
		String joinedMids = StringUtils.join(midsArray, GlobalConstants.COMMA);
		logger.debug("Account Position fetching queue for mids: {}", joinedMids);
		filterXML = "<pruleConditions xmlns=\"http://Fundtech.com/prule-metadata-dto.xsd\"><cond lineNumber=\"01\"><leftVal CT=\"Field\" value =\"[P_MID]\"></leftVal><op>In</op><rightVal CT=\"InList\" value =\"" +
		joinedMids +
		"\"></rightVal></cond></pruleConditions>";
		requestData.setQueueName(QUEUE_NAME_TRANS_SEARCH);
		requestData.setFilterXml(filterXML);
		return getQueueData(requestData);
	} 

	
	/**
	 * Returns queue list data. 
	 * 
	 *  @bo.authorizeUser returnWebSessionInfo="true"
	 */
	@Expose
	@AuthorizeUser(returnWebSessionInfo=true)
	public SimpleResponseDataComponent getQueueDataForAccountPosition(AccountPositionQueueListRequestData queueListRequestData){

		m_posFiguresDAO = (PositionFiguresDAO) SpringApplicationContext.getBean("PositionFiguresDAO");
		List<String> midsList = null;
		String filterXML = null;
		try {
			midsList = m_posFiguresDAO.getPositionFigureMids(queueListRequestData.getuIdAccount(),
					queueListRequestData.getPositionDate(),queueListRequestData.getPositionCycle(), queueListRequestData.getCdtDbtInd(), 
					queueListRequestData.getFigureTypeName(), queueListRequestData.getPositionDaysBack());
		} catch (Exception e) {			
			logger.error("Error getting Account's Position Queue for Account {}, Date {}, Cycle {},Direction {}, Position Type{}",
					new Object[] {queueListRequestData.getuIdAccount(),
					queueListRequestData.getPositionDate(), queueListRequestData.getPositionCycle(),queueListRequestData.getCdtDbtInd(), 
					queueListRequestData.getFigureTypeName()});
			SimpleResponseDataComponent response = new SimpleResponseDataComponent();
			final Feedback feedback = new Feedback();
			feedback.setFailure() ; 
			feedback.setErrorCode(ERROR_CODE_GENERAL);
			feedback.setErrorText(e.getMessage());
			feedback.setUserErrorText(e.getMessage());
			response.setFeedback(feedback);
			return response ; 
		}
		logger.debug("Account Position fetching queue for mids: {}", StringUtils.join(midsList,GlobalConstants.COMMA));
		
		filterXML = queueListRequestData.getFilterXmlString();
		if (filterXML != null){
        	String andOrTag = filterXML.indexOf("<cond") == -1 ? GlobalConstants.EMPTY_STRING : "<andOr>AND</andOr>";
        	String midsCond = "<cond lineNumber=\"01\">"+andOrTag+"<leftVal CT=\"Field\" value =\"[P_MID]\"></leftVal><op>In</op><rightVal CT=\"InList\" value =\"" + StringUtils.join(midsList,GlobalConstants.COMMA) +"\"></rightVal></cond>";
        	filterXML = filterXML.substring(0 , filterXML.indexOf("</pruleConditions>")) + midsCond + "</pruleConditions>";
		}else{
			filterXML = "<pruleConditions xmlns=\"http://Fundtech.com/prule-metadata-dto.xsd\"><cond lineNumber=\"01\"><leftVal CT=\"Field\" value =\"[P_MID]\"></leftVal><op>In</op><rightVal CT=\"InList\" value =\"" + StringUtils.join(midsList,GlobalConstants.COMMA)  + "\"></rightVal></cond></pruleConditions>";
		}
		queueListRequestData.setQueueName("V_DD_ACC_POS");
		queueListRequestData.setFilterXml(filterXML);
		return getQueueData(queueListRequestData);
		}//EOM
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	/**
	 * Returns Acknowledgments data. 
	 * 
	 *  @bo.authorizeUser returnWebSessionInfo="true"
	 */
	@Expose
	@AuthorizeUser(returnWebSessionInfo=true)
	public SimpleResponseDataComponent getAcknowledgmentsData(AcknowledgmentsRequestData acknowledgmentsRequestData) {
		XmlObjectBase responseXbean = null;
		SimpleResponseDataComponent response = new SimpleResponseDataComponent();

		String sMID = acknowledgmentsRequestData.getMID();
		String sInterfaceName = acknowledgmentsRequestData.getInterfaceName();
		String sInterfaceType = acknowledgmentsRequestData.getInterfaceType();
		String sInterfaceSubType = acknowledgmentsRequestData.getInterfaceSubType();

		final DTODataHolder dtoAcknowledgmentsData = this.m_daoQueues.getAcks(sMID, sInterfaceName, sInterfaceType, sInterfaceSubType);

		Feedback feedback = dtoAcknowledgmentsData.getFeedBack();

		if(feedback.isSuccessful() && !dtoAcknowledgmentsData.isEmpty()) {
			ArrayList alData = dtoAcknowledgmentsData.getDataAL();
			List<XmlObjectBase> contentList = new ArrayList<XmlObjectBase>();

			for (Object mapObject: alData) {
				HashMap hmData = (HashMap)mapObject;	
				Object oInput = hmData.get(COLUMN_INTERFACE_CONTENT);
				try {
					responseXbean = PaymentInputSourceType.toXbean(oInput) ;
					FndtMsgType oFndtMsgType = ((FndtMsgDocumentImpl)responseXbean).getFndtMsg();
					XmlObjectBase docuemntXbean  = ((XmlObjectBase)oFndtMsgType.getMsg().getPmnt()).toDocumentFirstChild();
					contentList.add(docuemntXbean);

				} catch (Exception e) {
					ExceptionController.getInstance().handleException(e, this);
				}
			}

			String[] arrMetadata = (String[]) acknowledgmentsRequestData.getArrSanitizedColumns()[0];
			Object[][] arrGridData = getAcknowledgmentsDataMatrix(contentList, arrMetadata);

			final NewAcknowledgmentsData acknowledgmentsData = new NewAcknowledgmentsData(arrMetadata, arrGridData);

			response.setDataArray(new Object[]{acknowledgmentsData});
			return response;

		}

		response.setFeedback(feedback);
		return response ;
	}

	/**
	 * Returns queue grid meta data for the passed parameters.
	 * 
	 * qlist_todo: used in getQueueData_new
	 */
	private final void getQueueGridMetaData(final Context ctx) {

		

		logger.trace(QUEUE_NAME + ctx.sActualQueueName) ;   

		//if the preferences were present for the user and the queue name use them for the creation 
		//if the NewQueueListColumnMetadata array.
		//Note: the existence of the QueuePreferences is not a non-equivocal indication that there 
		//is columns metedata as only filter data might have been persisted 
		ctx.bHistorySearch = QUEUE_NAME_TRANS_SEARCH_HISTORY.equalsIgnoreCase(ctx.sQueueName);

		/* qlist_todo: will probably need to extract the sort and groupings 
    final NewQueueListColumnMetaData[] arrMetaData = 
        this.processQueuePreferences(bLowValue, bHistorySearch, queuePreferences, arrOrderedColumnsNamesHolder) ;
		 */

		Collection<NewQueueListColumnMetaData> listColumnsMetaData = null ; 

		List<String> listColumnNames = (ctx.queuePreferences != null ? ctx.queuePreferences.getColumnNames() : null ) ; 
		String sColumnNamesString = null ; //used in the order by parsing column enrichment process 

		//if the request context was for queue groupnig 
		if(ctx.bIsQueueGroupingContext) { 

			listColumnsMetaData = new ArrayList<NewQueueListColumnMetaData>() ;
			sColumnNamesString = this.consturctGridMetadataFromGroupFields(ctx, listColumnsMetaData) ;

		}else if(listColumnNames == null) { 
			listColumnsMetaData = new ArrayList<NewQueueListColumnMetaData>(m_defaultColumnsMetadata.m_mapQListColumns.values());  

			//set the table names as the from part table names
			ctx.setFromPartTableNames.addAll(m_defaultColumnsMetadata.m_setTableNames) ; 

			//get the column names string 
			sColumnNamesString = m_defaultColumnsMetadata.m_sColumnNamesString ; 
		}else { 

			//get the column names string from the preferences 
			sColumnNamesString  = ctx.queuePreferences.getColumns() ; 

			//Note: the columns order of appearance in the delimited string is also the order   
			final String arrColumnWidths[] = ctx.queuePreferences.getColumnWidths() ;
			listColumnsMetaData = new ArrayList<NewQueueListColumnMetaData>() ; 

			final List<String> listSortByColumns = ctx.queuePreferences.getSortByColumns() ; 

			final int iNumberOfColumns = arrColumnWidths.length ; 

			//qlist_todo: process sort and group position, currently the preferences has these members 
			//but still not sure how the data is set 
			final int iGroupPosition = 0 ; 

			for(int i=0; i < iNumberOfColumns; i++) { 
				if(listColumnNames.get(i).trim().matches(OCCURANCE_REGX)&& (Admin.getContextAdmin().getCallSource() == CallSource.Service)) {
					listColumnsMetaData.add(

							new NewQueueListColumnMetaData(listColumnNames.get(i).substring(0,listColumnNames.get(i).indexOf('[')), listSortByColumns.get(i), 
									iGroupPosition, i, arrColumnWidths[i])  
					) ; 
				}
				else {
					listColumnsMetaData.add(

							new NewQueueListColumnMetaData(listColumnNames.get(i), listSortByColumns.get(i), 
									iGroupPosition, i, arrColumnWidths[i])  
					) ; 
				}

			}//EO while there are more columns to add

			//add all the table names to the set 
			ctx.setFromPartTableNames.addAll(ctx.queuePreferences.getTableNames()) ; 

			//find any missing defualt columns and add them as well 
			final Set<String> setMissingColumns = new HashSet<String>(m_mandatoryColumnsMetadata.m_mapQListColumns.keySet()) ;  
			setMissingColumns.removeAll(listColumnNames) ; 

			NewQueueListColumnMetaData missingColumnMetadata = null ; 
			for(String sColumnId : setMissingColumns) { 
				missingColumnMetadata = m_mandatoryColumnsMetadata.m_mapQListColumns.get(sColumnId) ; 

				listColumnsMetaData.add(missingColumnMetadata) ;

				//add the colum's table to the table names as well 
				if(missingColumnMetadata.isRelational()) 
					ctx.setFromPartTableNames.add(missingColumnMetadata.getFieldLocation()) ; 

				//append the column field id to the sColumnNamesString
				sColumnNamesString = sColumnNamesString + ',' + missingColumnMetadata.getFieldID() ; 
			}//EO while there are more missing columns  to add

		}//EO else if the user had column preferences for this queue 


		//if the context is that of a sorted queue and there xml columns which 
		//are present in the order by clause but are not selected, 
		//add the column as a default at the end of the list.
		this.handleOrderByPart(ctx, listColumnsMetaData, sColumnNamesString) ;  

		// No meta data at all.
		if(listColumnsMetaData  == null || listColumnsMetaData.isEmpty()){
			final String ERROR_MESSAGE = "No meta data was found - can't display the queue !!!";

			ctx.feedback.setFailure();
			ctx.feedback.setErrorCode(ERROR_CODE_GENERAL);
			ctx.feedback.setErrorText(ERROR_MESSAGE);
			ctx.feedback.setUserErrorText(ERROR_MESSAGE);

			logger.error(ERROR_MESSAGE);
			//EO if there was no metadata
		}else  ctx.listMetaData = listColumnsMetaData ; 



		

	}//EOM 

	/**
	 * 
	 * Jun 12, 2008
	 * Guys
	 * 
	 *  Constructs the order by parts as well as enriches the grid metadata (column set) with 
	 *  any non-relational coulmns which are in the order by part and not in the existing column set 
	 *  
	 * @param ctx
	 * @param listColumnsMetaData
	 */
	private final void handleOrderByPart(final Context ctx, final Collection<NewQueueListColumnMetaData> listColumnsMetaData, 
			String sColumnNamesString) { 

		final StringBuilder builder = new StringBuilder(" ORDER BY ") ;  

		//enclose sColumnNamesString with ',' so as to ensure that the search would be an exact one 
		sColumnNamesString = ',' + sColumnNamesString + ',' ; 

		if(!GlobalUtils.isNullOrEmpty(ctx.sSortOrder)){

			//the order by sent from the client contains the field's aliases, and require conversion to field ids 
			//Note: the field alias might contain the 'DESC' key word which should be stripped prior to the lookup and appended 
			//thereafter 
			final String[] arrFieldAliases = ctx.sSortOrder.split(",") ;
			int iLength = arrFieldAliases.length ;
			LogicalFields sortByField = null ; 
			String sFieldAlias = null, sFieldId = null ; 
			int iIndexOfDescending = -1 ; 

			for(int i=0; i < iLength; i++){ 

				sFieldAlias = arrFieldAliases[i].trim() ; 

				//first determine whether the alias contains the DESC keyword and if so remove it 
				iIndexOfDescending = arrFieldAliases[i].indexOf(" DESC") ;  
				if(iIndexOfDescending != -1) sFieldAlias = sFieldAlias.substring(0, iIndexOfDescending) ;  

				/*
            sortByField = (LogicalFields) 
                cache.getSingle(CacheKeys.LogicalFieldsAliasKey, 
                        CacheKeys.LogicalFieldsAliasKey.prepareCacheEntryKey(sFieldAlias)) ;
				 */ 

				sortByField = CacheKeys.LogicalFieldsIdKey.getSingleLogicalOrUserDefinedField(sFieldAlias) ; 

				sFieldId = sortByField.getFieldLogicalId() ; 

				builder.append(sFieldId);

				//if the DESC was present 
				if(iIndexOfDescending != -1) { 
					builder.append(" DESC ") ; 
					//reset for next iteration 
					iIndexOfDescending = -1 ; 
				}//EO if the DSEC was presnet 

				if(i < iLength-1) builder.append(",") ;

				//if the field is not realtional and does not exist in the sColumnNamesString
				//create a new column metadata for it and add it to the listColumnsMetaData
				if(sortByField.getFieldType() != FieldType.RELATIONAL && 
						sColumnNamesString.indexOf(','+sFieldId+',') == -1) { 

					listColumnsMetaData.add(
							new NewQueueListColumnMetaData(sFieldId, "0", 0, listColumnsMetaData.size(), DEFAULT_COLUMN_WIDTH)  
					) ; 

					//if the context user preferencese exist, add the field id to it (null for table name as not relational)
					if(ctx.queuePreferences != null)  { 
						ctx.queuePreferences.addColumn(sFieldId, null) ;
						//if there were original prefernces then the current ones area a clone update them as well
						if(ctx.orginalPreferences != null) ctx.orginalPreferences.addColumn(sFieldId, null) ; 
					}//EO if there were preferences 

				}//EO if the field was not relational and was not already present in the metadata set 

			}//EO while there are amore fields 

			builder.append(ServerConstants.SPACE);
		}//EO if the order by part exists 

		//store the order by part in the context 
		ctx.sOrderByPart = builder.toString() ;     
	}//EOM 

	private final String consturctGridMetadataFromGroupFields(final Context ctx, final Collection<NewQueueListColumnMetaData> listColumnsMetaData) { 

		/*
		 * split the group fields into alias and an optional user range value and for each 
		 * create a new NewQueueListColumnMetaData
		 * using the following values: 
		 *  order (iteration order) 
		 *  metadata width 
		 *  sort order = 0 
		 *  group position = 0 
		 *  caption = alias 
		 *  if the range indicator from user != null then set it 
                otherwise set the default (metadata) range indicator
		 */  
		final Pattern GROUP_FIELDS_REGEX = Pattern.compile("(.+?)(?:~(.*?)){0,1}(?:,|$)") ; 
		final Matcher matcher = GROUP_FIELDS_REGEX.matcher(ctx.sGroupFields) ; 

		final StringBuilder sbColumnNamesBuilder = new StringBuilder() ;
		String sFieldAlias; 
		LogicalFields groupField = null ; 

		int iOrderCounter = 0 ; 

		while(matcher.find()) { 
			sFieldAlias = matcher.group(1) ; 
			//retreive the logical fields instance from the cache for the alias 
			/*
          groupField = (LogicalFields) cache.getSingle(CacheKeys.LogicalFieldsAliasKey, 
                    CacheKeys.LogicalFieldsAliasKey.prepareCacheEntryKey(sFieldAlias)) ; 
			 */ 

			groupField = CacheKeys.LogicalFieldsIdKey.getSingleLogicalOrUserDefinedField(sFieldAlias) ;

			//create a new NewQueueListColumnMetaData for the given field  
			listColumnsMetaData.add(

					new NewQueueListColumnMetaData(groupField, ServerConstants.ZERO_VALUE, 
							0, iOrderCounter++, groupField.getFldDisplayWidth().toString(), matcher.group(2))  
			) ; 

			//add the colum's table to the table names as well 
			if(groupField.getFieldType() == FieldType.RELATIONAL) 
				ctx.setFromPartTableNames.add(groupField.getLocation()) ; 

			//append the field name to the sbColumnNamesBuilder for futher use during the order by enrichment process 
			sbColumnNamesBuilder.append(groupField.getFieldLogicalId()).append(",") ; 
		}//EO while there are more fields to add 

		//finally, add the default count column
		final NewQueueListColumnMetaData defaultCountColumnMetadata = (NewQueueListColumnMetaData) m_defaultCountColumnMetaData.clone() ;
		defaultCountColumnMetadata.setOrder(iOrderCounter) ; 
		listColumnsMetaData.add(defaultCountColumnMetadata) ; 

		sbColumnNamesBuilder.deleteCharAt(sbColumnNamesBuilder.length()-1) ; 

		return sbColumnNamesBuilder.toString() ; 
	}//EOM 

	/**
	 * Validates the sent page direction.
	 * 
	 * qlist_todo: used in getQueueData_new
	 */
	@Expose(type = ExposureType.InternalInterface)
	private final void validatePageDirection(final QueueListRequestData queueListRequestData, Context ctx){

		final String ERROR_MESSAGE_1 = "Error: wrong page direction parameter";
		final String ERROR_MESSAGE_2 = "Error: page direction parameter 'P' or 'N' cannot come with empty MID parameter";

		final String sPageDirectionAlias = queueListRequestData.getPageDirection();
		final PageDirectionType enumPageDirection = PageDirectionType.reverseValueOf(sPageDirectionAlias) ; 

		ctx.enumPageDirection = enumPageDirection  ; 

		if(enumPageDirection == null){
			ctx.feedback.setFailure();
			ctx.feedback.setErrorCode(ERROR_CODE_GENERAL);

			String sErrorText = new StringBuffer(ERROR_MESSAGE_1).append(ServerConstants.COLON)
			.append(ServerConstants.SPACE)
			.append(sPageDirectionAlias).toString();
			ctx.feedback.setErrorText(sErrorText);

			ctx.feedback.setUserErrorText(ERROR_MESSAGE_1);
		}//EO if the page direction was not a valid one 
		else if(enumPageDirection == PageDirectionType.Refresh && ctx.sMID.equals(ServerConstants.EMPTY_STRING)){

			ctx.enumPageDirection = PageDirectionType.First;
		}//EO else if the page direction is refresh and there was no MID     
		else if( (enumPageDirection == PageDirectionType.Next || enumPageDirection == PageDirectionType.Previous) 
				&& ctx.sMID.equals(ServerConstants.EMPTY_STRING)){
			ctx.feedback.setFailure();
			ctx.feedback.setErrorCode(ERROR_CODE_GENERAL);
			ctx.feedback.setErrorText(ERROR_MESSAGE_2);
			ctx.feedback.setUserErrorText(ERROR_MESSAGE_2);
		}//EO else if the direction was next or previous and the MID was not provided 
		else if(enumPageDirection == PageDirectionType.Last) {
			final String mID = getMIDForBeforeLastPage(queueListRequestData, ctx);
			ctx.sMID = mID;
			ctx.enumPageDirection = PageDirectionType.Next;
		}//EO else if the page direction is last

	}//EOM 
	private final String getMIDForBeforeLastPage(final QueueListRequestData queueListRequestData, Context ctx) {
		// get where and other filters used to retrieve data sets
		final String sSelectQueryClauses = this.getSelectQueryClauses(queueListRequestData, ctx).toString();
		
		// get total row count in resulted data set
		StringBuilder sbSelectCountStatement = new StringBuilder();
		sbSelectCountStatement.append("SELECT COUNT(*)").append(sSelectQueryClauses);
		final DTOSingleValue rowCount = BOQueues.m_daoQueues.getSingleValue(sbSelectCountStatement.toString(), null);
		final int rowsCount = Integer.parseInt(rowCount.getValue(), 10);
		
		logger.debug("before last query", sbSelectCountStatement.toString());
		
		// calculate rownum of last row on page before last
		final int rowsPerPage = ctx.iPageSize;
		final int beforeLastRow = (rowsCount / rowsPerPage * rowsPerPage)-((rowsCount % rowsPerPage) == 0? rowsPerPage : 0);
		
		// get mID for desired row
		StringBuilder sbSelectRowStatement = new StringBuilder();
		sbSelectRowStatement
			.append("SELECT P_MID FROM (")
			.append("SELECT  /*+ INDEX_DESC (MINF IX_MINF_1) */ ROWNUM ROW_N, MINF.P_MID P_MID").append(sSelectQueryClauses)
			.append(") ")
			.append("WHERE ROW_N=").append(beforeLastRow);
		final DTOSingleValue mID = BOQueues.m_daoQueues.getSingleValue(sbSelectRowStatement.toString(), null);
		
		logger.debug("before last mID: ", mID.getValue());
		
		return mID.getValue();
		
	}//EOM

	@Expose(type = ExposureType.InternalInterface)
	private final StringBuilder getSelectQueryClauses(final QueueListRequestData queueListRequestData, Context ctx) {
		StringBuilder sbSelectStatement = new StringBuilder();
		
		ctx.iCallingMethod = (!ctx.bIsSortedQueue ? CALLING_METHOD_GET_QUEUE_DATA : CALLING_METHOD_GET_SORTED_QUEUE_DATA);
		
		Prules userDefinedQueueMetadata = null ;
		if(ctx.iQueueType == QUEUE_TYPE_USER_DEFINE){

			//retrieve extra conditions from cache 
			//office, rule type, rule name 
			userDefinedQueueMetadata = CacheKeys.PRulesUIDKey.getSingle(
					ServerUtils.generateUIDValue(null, new String[] {ServerConstants.DEFAULT_SERVER_OFFICE_NAME, 
							MessageConstantsInterface.RULE_TYPE_ID_USER_DEFINED_QUEUE, 
							ctx.sQueueName})) ;         

		}//EO if the queue was user defined 
		
		// sbSelectStatement.append("SELECT COUNT(*)");
		sbSelectStatement = this.constructFromPartOfSelectStatementForQueueGridData(sbSelectStatement, ctx, userDefinedQueueMetadata);
		sbSelectStatement = this.constructBasicFilterPartForQueueGridData(sbSelectStatement, ctx, userDefinedQueueMetadata);

		sbSelectStatement = this.constructModeAdditionalConditions(sbSelectStatement, ctx);
		
		if(!ctx.bSkipMidConstruction && !GlobalUtils.isNullOrEmpty(ctx.sMID))
			sbSelectStatement = this.constructNonEmptyMIDAdditionalCondition(sbSelectStatement, ctx) ;  

		final String sUserFilterPart = (ctx.bIsVirutalQueue || ctx.queuePreferences == null ? null : ctx.queuePreferences.getFilterWhere()) ;
		if(!GlobalUtils.isNullOrEmpty(sUserFilterPart))
			sbSelectStatement.append(AND).append('(').append(sUserFilterPart).append(')') ;

		if(ctx.iCallingMethod == CALLING_METHOD_GET_SORTED_QUEUE_DATA) sbSelectStatement.append(ctx.sOrderByPart).append(") ") ;

		/* if((!ctx.bIsQueueGroupingContext) && !ctx.isPageMode2) sbSelectStatement =
			this.constructRowNumCondition(sbSelectStatement, ctx, false); */


		//    HINT not working in DB2, therefore, check if DB2 add order by 
		if (DAOBasic.ms_DBType == DBType.DB2)
		{
			sbSelectStatement =  this.constructEndOfSelectStatementForQueueGridData(sbSelectStatement, ctx);
		}
		//add the group by part if the ctx.bIsQueueGroupingContext is true  
		if(ctx.bIsQueueGroupingContext) sbSelectStatement.append(ctx.sGroupByPart) ; 

		constructPageMode2QueueGridData(sbSelectStatement, ctx);

		return sbSelectStatement;
	}
	
	/**
	 * Returns queue grid data for the passed parameters.
	 * 
	 * qlist_todo: used in getQueueData_new
	 */
	private final void getQueueGridData(final Context ctx) {

		

		logger.trace(QUEUE_NAME + ctx.sActualQueueName) ;   

		ctx.iCallingMethod = (!ctx.bIsSortedQueue ? CALLING_METHOD_GET_QUEUE_DATA : CALLING_METHOD_GET_SORTED_QUEUE_DATA);

		String sSelectStatement = this.getQueueListQuery(ctx).toString() ; 


		StatementParameter[] arrStatementParameters = null ; 

		//initialize the statement parameters array if the ctx.listStatementParameters is not unll 
		if(ctx.listStatementParameters != null) { 
			arrStatementParameters = new StatementParameter[ctx.listStatementParameters.size()] ; 
			ctx.listStatementParameters.toArray(arrStatementParameters) ; 
		}//EO if there were statement parameters 

		//if this is a group by operation, no need to add rownum condition
		int iPageSize = ctx.bIsQueueGroupingContext ? -1 : ctx.iPageSize;
		// Gets the data itself.    
		final DTODataHolder dtoGridData = 
			this.m_daoQueues.getQueueGridData(sSelectStatement, arrStatementParameters,iPageSize, ctx.bLowValue);

		//if the data retrieval operation had failed 
		if(!dtoGridData.isFeedBackSuccess()) { 
			ctx.feedback = dtoGridData.getFeedBack();
			return ; 
			//EO if the data retrieval operation had failed
		}else if(dtoGridData.isEmpty()) { 
			ctx.arrGridData = new Object[0][0]; ;
			return ; 
		}//EO if there was no data 

		// Gets list of order columns' names for building the queue data matrix.
		ctx.arrGridData = this.getQueueDataMatrix(dtoGridData.getDataAL(), ctx) ; 

		// if the method returned null queue data grid, it is assumed that the problem is no
		// matching between number of meta data columns to number of columns in
		// one row data, (see 'getQueueDataMatrix_new' method for that check).
		if(ctx.arrGridData == null){ 

			final String ERROR_MESSAGE = "ERROR: Number of meta data columns IS DIFFERENT than number of columns in one row data.";

			ctx.feedback.setFailure();
			ctx.feedback.setErrorCode(ERROR_CODE_GENERAL);
			ctx.feedback.setErrorText(ERROR_MESSAGE);
			ctx.feedback.setUserErrorText(ERROR_MESSAGE);
		}//EO if there was a Discrepancy in the number of columns in the metadata and actual data 

		

	}//EOM 

	/**
	 * Returns the queue button flags array.
	 * 
	 * qlist_todo: used in getQueueData_new
	 */
	private final boolean[] getQueueButtonFlags(final Context ctx){

		

		final int iNumOfRows = ctx.arrGridData.length ; 

		boolean bFirstButton = false;
		boolean bPreviousButton = false;
		boolean bNextButton = false;

		boolean bDirectionFirst = ctx.enumPageDirection == PageDirectionType.First; 

		if(!ctx.sQueueName.equals(QUEUE_NAME_TRANS_SEARCH)
				&&!ctx.sQueueName.equals(QUEUE_NAME_TRANS_SEARCH_HISTORY)
				&& !ctx.sQueueName.equals(QUEUE_NAME_TRANS_SEARCH_TEMPLATE))
		{
			// No data.
			if(iNumOfRows == 0)
			{
				if(   ctx.enumPageDirection == PageDirectionType.Next 
						|| ctx.enumPageDirection == PageDirectionType.Refresh )
				{
					bFirstButton = true;
					bPreviousButton = true;
				}
			}

			else
			{
				if(   iNumOfRows < ctx.iPageSize
						&& ctx.enumPageDirection == PageDirectionType.Previous   ) 
				{
					bDirectionFirst = true;
				}

				// We have more data in the database.
				if(ctx.bMoreData)
				{
					bNextButton = true;


					if(!bDirectionFirst)
					{
						bFirstButton = true;
						bPreviousButton = true;
					}
				}

				else
				{
					//bFirstButton = true;

					if( ctx.enumPageDirection == PageDirectionType.Next 
							|| ctx.enumPageDirection == PageDirectionType.Refresh )
					{
						bFirstButton = true;
						bPreviousButton = true;
					}

					if(ctx.enumPageDirection == PageDirectionType.Previous)
					{
						bNextButton = true;
					}
				}
			}
		}

		// last button = next button
		return new boolean[]{bFirstButton, bNextButton, bNextButton, bPreviousButton};
	}//EOM 

	/**
	 * Returns matrix of the queue data from the passed ArrayList of data.
	 * 
	 * qlist_todo: used in getQueueData_new
	 */
	private Object[][] getQueueDataMatrix(List alQueueData, final Context ctx){

		

		Object[][] arrQueueData = null;

		final int iNumOfColumns = ctx.listMetaData.size();

		NewQueueListColumnMetaData[] arrMetadata = 
			ctx.listMetaData.toArray( (arrMetadata = new NewQueueListColumnMetaData[iNumOfColumns]) ) ; 

		// SECURITY CHECK FOR MATCHING BETWEEN NUMBER OF META DATA COLUMNS TO NUMBER
		// OF COLUMNS IN ONE DATA ROW.
		//
		// Number of columns MUST equal size of one HashMap data, which stands for
		// one row in the queue grid.
		final int iOneRowDataSize = ((HashMap)alQueueData.get(0)).size();
		
		// No matching between meta data columns to row data columns.
		if(iNumOfColumns != iOneRowDataSize){
			final String ERROR_MESSAGE = "ERROR: Number of meta data columns IS DIFFERENT than number of columns in one row data: %s, %s";

			logger.error(ERROR_MESSAGE, iNumOfColumns, iOneRowDataSize);  
			return arrQueueData ; 
		}//EO number of column Discrepancy 

		//else no Discrepancy 
		int iNumOfRows = alQueueData.size();

		if(iNumOfRows == (ctx.iPageSize+1)){
			// Sets this flag for later use.
			ctx.bMoreData = true;

			// Removes last row, which was fetched only for checking if we have more
			// data, aside the requested rows, which is determined according to 'iPageSize'.
			alQueueData.remove(iNumOfRows-1);

			iNumOfRows = iNumOfRows-1;
		}//EO if there were more rows 

		arrQueueData = new Object[iNumOfRows][iNumOfColumns];
		String coulmnName ="";
		boolean bPreviousPageDirection = (ctx.enumPageDirection == PageDirectionType.Previous) ; 

		HashMap hmCurrentRowData = null ;
		String sCurrentRowCellData = null ; 
		List<String> coulmnNames = null;
		if(ctx.queuePreferences != null) {
			coulmnNames = ctx.queuePreferences.getColumnNames();
		}
		for(int i=0; i<iNumOfRows; i++){

			hmCurrentRowData= (HashMap)alQueueData.get(i);

			// Gets all columns data for the current row, where the fetch is according
			// to the 'arrOrderedColumnsNames' parameter, which was constructed during
			// the meta data construction, and matches the order of the columns in the
			// select statment taht we used for getting the data.
			for(int j=0; j<iNumOfColumns; j++){
				if((Admin.getContextAdmin().getCallSource() == CallSource.Service) && (coulmnNames != null && j < coulmnNames.size())) {
					if((Admin.getContextAdmin().getCallSource() == CallSource.Service) && (coulmnNames != null && coulmnNames.get(j).trim().matches(OCCURANCE_REGX))) {
						coulmnName = coulmnNames.get(j);
						sCurrentRowCellData = (String) hmCurrentRowData.get(coulmnName);
					}
					else {
						sCurrentRowCellData = (String) hmCurrentRowData.get(arrMetadata[j].getFieldID());
					}
				}
				else {	
					sCurrentRowCellData = (String) hmCurrentRowData.get(arrMetadata[j].getFieldID());
					if((Admin.getContextAdmin().getCallSource() == CallSource.Service) && (sCurrentRowCellData == null))
					 
						sCurrentRowCellData = (String) hmCurrentRowData.get(coulmnNames.get(j));{
						
					}
				}
				sCurrentRowCellData = (!ServerUtils.isNullOrEmpty(sCurrentRowCellData) ?
						sCurrentRowCellData : ServerConstants.EMPTY_STRING ) ; 

				//if the value was a range indication clear it 
				if(sCurrentRowCellData.equals(GlobalConstants.MINUS_SIGN) && arrMetadata!=null && 
						arrMetadata[j].getRangeIndicator() == 1)  sCurrentRowCellData = ServerConstants.EMPTY_STRING;

				//only attempt to retrieve the data type if the skip formatting flag was set to false  
				DataType dataType = (ctx.bSkipFormatting ? null : Enum.valueOf(DataType.class,arrMetadata[j].getType()) ) ;

				//Decimal represent the amount field which should be formatted in the GUI level so the DHTMLX will consider it as a number for sorting
				//also note that for DHTML purpose DECIMAL fields are being translated to DHTMLX_type_ron in Table.java
				if (dataType != null && dataType != DataType.DECIMAL) sCurrentRowCellData = dataType.guiAdjust(sCurrentRowCellData, ctx.sOffice);

				// The location assignement is according to the page direction;
				// in case of 'P', we start filling the data matrix fromthe end.
				arrQueueData[bPreviousPageDirection ? ((iNumOfRows-1)-i) : i][j] = sCurrentRowCellData;
			}//EO while there are more columns in the row 
		}//EO while there are more data rows 

		

		return arrQueueData;
	}//EOM 

	/**
	 * Returns matrix of the queue data from the passed ArrayList of data.
	 * 
	 * qlist_todo: used in getQueueData_new
	 */
	private Object[][] getAcknowledgmentsDataMatrix(List<XmlObjectBase> alXmlContent, String[] arrMetadata){

		

		final DASInterface das = PluginFactory.get(DASInterface.class) ;

		Object[][] arrQueueData = null;

		final int iNumOfColumns = arrMetadata.length;

		int iNumOfRows = alXmlContent.size();

		arrQueueData = new Object[iNumOfRows][iNumOfColumns];

		String sCurrentRowCellData = null ; 

		for(int i=0; i<iNumOfRows; i++){

			XmlObjectBase docuemntXbean = (XmlObjectBase)alXmlContent.get(i);

			for(int j=0; j<iNumOfColumns; j++){

				sCurrentRowCellData = (String)das.getFieldFromXml(arrMetadata[j], docuemntXbean);

				sCurrentRowCellData = (!ServerUtils.isNullOrEmpty(sCurrentRowCellData) ?
						sCurrentRowCellData : ServerConstants.EMPTY_STRING ) ; 

				arrQueueData[i][j] = sCurrentRowCellData;
			}//EO while there are more columns in the row 
		}//EO while there are more data rows 

		

		return arrQueueData;
	}//EOM 

	/**
	 * Inter-bean (system internal method) constructing the qlist query 
	 * based on the context configuration
	 *  
	 * @Returns the select statement for the queue grid data.
	 * 
	 * @bo.internalInterface
	 * 
	 * qlist_todo: used in getQueueData_new
	 */
	@Expose(type = ExposureType.InternalInterface) 
	public final StringBuilder getQueueListQuery(final Context ctx){

		logger.trace(QUEUE_NAME + ctx.sActualQueueName) ;

		StringBuilder sbSelectStatement = new StringBuilder();

		//add the MINF table to the hash 
		//qlist_todo: as there must be at least one column from minf in the select clause, 
		//the minf table would already exist in the columns + where clause table names set 
		//setTableNames.add("MINF") ; 

		//if the queue is a user defined queue, rerieve the ObjectRuleSet cache entry for 
		//office '***' rule type id 2 as the where clause as well as the table names should be used
		//in the flow to come. 
		Prules userDefinedQueueMetadata = null ; 

		if(ctx.iQueueType == QUEUE_TYPE_USER_DEFINE){

			//retrieve extra conditions from cache 
			//office, rule type, rule name 
			userDefinedQueueMetadata = CacheKeys.PRulesUIDKey.getSingle(
					ServerUtils.generateUIDValue(null, new String[] {ServerConstants.DEFAULT_SERVER_OFFICE_NAME, 
							MessageConstantsInterface.RULE_TYPE_ID_USER_DEFINED_QUEUE, 
							ctx.sQueueName})) ;         

		}//EO if the queue was user defined 


		// Appends the start of the select statement; that includes the used index plus
		// all fields' names.
		sbSelectStatement =  this.constructStartOfSelectStatementForQueueGridData(sbSelectStatement, ctx);

		// Appends the 'from' part of the select statement.
		sbSelectStatement = this.constructFromPartOfSelectStatementForQueueGridData(sbSelectStatement, ctx,  
				userDefinedQueueMetadata);

		// Constructs the basic filter part.
		sbSelectStatement = this.constructBasicFilterPartForQueueGridData(sbSelectStatement, ctx, userDefinedQueueMetadata);

		// Gets mode additional conditions.

		sbSelectStatement = this.constructModeAdditionalConditions(sbSelectStatement, ctx);

		if(!ctx.bSkipMidConstruction && !GlobalUtils.isNullOrEmpty(ctx.sMID))
			sbSelectStatement = this.constructNonEmptyMIDAdditionalCondition(sbSelectStatement, ctx) ;  


		// Appends the sent user filter part if the queue not virtual.

		final String sUserFilterPart = (ctx.queuePreferences == null ? null : ctx.queuePreferences.getFilterWhere()) ;
		if(!GlobalUtils.isNullOrEmpty(sUserFilterPart))
			sbSelectStatement.append(AND).append('(').append(sUserFilterPart).append(')') ;

		//if this was a request for a sorted queue then a "SELECT * FROM (" was constructed at the beginning of the query 
		//which would require a closing parenthesis here, preceded by the order by clause 
		if(ctx.iCallingMethod == CALLING_METHOD_GET_SORTED_QUEUE_DATA) sbSelectStatement.append(ctx.sOrderByPart).append(") ") ;

		// Appends the row number part; if filter exists, there is no need for that
		// because the row number will be added during the 'getQueueGridData' method,
		// which will call the right 'DAOBasic.getData' method which will add the 
		// row number part. 
		//    in case of page mode 2, the row num will be added after page mode 2 construction. 
		//if((ctx.iCallingMethod == CALLING_METHOD_GET_SORTED_QUEUE_DATA || GlobalUtils.isNullOrEmpty(sUserFilterPart) && !ctx.bIsQueueGroupingContext) && !ctx.isPageMode2) sbSelectStatement =
		// For CR No :- 100949 updated the condition - paginations buttons needs to be shown 
		if((!ctx.bIsQueueGroupingContext) && !ctx.isPageMode2) sbSelectStatement =
			this.constructRowNumCondition(sbSelectStatement, ctx, false);


		//    HINT not working in DB2, therefore, check if DB2 add order by 
		if (DAOBasic.ms_DBType == DBType.DB2)
		{
			sbSelectStatement =  this.constructEndOfSelectStatementForQueueGridData(sbSelectStatement, ctx);
		}
		//add the group by part if the ctx.bIsQueueGroupingContext is true  
		if(ctx.bIsQueueGroupingContext) sbSelectStatement.append(ctx.sGroupByPart) ; 


		constructPageMode2QueueGridData(sbSelectStatement, ctx);
		

		return sbSelectStatement ;
	}//EOM 

	/**
	 * TODO - handle filter for HISTORY queue.
	 * Returns the basic filter part for the queue grid data.
	 */
	private final StringBuilder constructBasicFilterPartForQueueGridData(final StringBuilder builder,
			final Context ctx, final Prules userDefinedQueueMetadata){

		final String WHERE_PART = " WHERE ";
		final String MINF_MSG_STATUS_PART = "MINF.P_MSG_STS = '";
		final String MINF_IS_NOT_HISTORY_PART = " MINF.P_IS_HISTORY = 0 ";
		final String MINF_IS_HISTORY_PART = " MINF.P_IS_HISTORY = 1 ";    
		final String MINF_TEMPLATES_PART = " MINF.P_IS_HISTORY = 2 ";
		final String MINF_PROCESSING_DATE_PART = " MINF.P_PROC_DT %s TO_DATE(\'%s\',\'%s\')";
		final String LOW_VALUE_MSG_STATUS_PART = "" ; //qlist_todo: NYI    
		final String AND = " AND ";
		final String FALSE_PART = "1=2";
		String sCondition = GlobalConstants.EMPTY_STRING;
		

		//first append the ' WHERE ' part 
		builder.append(WHERE_PART) ;

		final int WHERE_PART_LENGTH = builder.length() ;

		//EO if the context was that of a virtual queue append the extra condition 
		if(ctx.iQueueType == QUEUE_TYPE_VIRTUAL)
		{ 
			//CR#82067-->>Added this condition to check whether Virtual Queue Filter is available or not e.g. 210 Consile
			sCondition = (ctx.sVirtualQueueFilterPart != null) ? ctx.sVirtualQueueFilterPart: FALSE_PART ;
			builder.append(sCondition);

		}

		// MINF.P_MSG_STS handling.
		if(   ctx.iCallingMethod == CALLING_METHOD_GET_QUEUE_DATA
				|| ctx.iCallingMethod == CALLING_METHOD_GET_SORTED_QUEUE_DATA 
				|| ctx.iCallingMethod == CALLING_METHOD_GET_QUEUE_GROUPING){

			Date historyDate = CacheKeys.banksKey.getSingle(ctx.sOffice).getHistoryProcDt(); 
			Date procDate = CacheKeys.banksKey.getSingle(ctx.sOffice).getBsnessdate();
			//if the quue type was 'User-Defined' then add the execWhere from userDefinedQueueMetadata
			if(QUEUE_TYPE_NAME_HISTORY.equals(ctx.sFromTab) || ctx.sQueueName.equals(QUEUE_NAME_TRANS_SEARCH_HISTORY))
			{
				builder.append(MINF_IS_HISTORY_PART).append(ServerConstants.SPACE);
				if(QUEUE_TYPE_NAME_HISTORY.equals(ctx.sFromTab))
				{
					builder.append(" AND ").append(ctx.bLowValue? LOW_VALUE_MSG_STATUS_PART : MINF_MSG_STATUS_PART).append(ctx.sQueueName)
					.append(ServerConstants.APOSTROPHE).append(ServerConstants.SPACE);
				}
			}else if(QUEUE_NAME_TRANS_SEARCH_TEMPLATE.equals(ctx.sFromTab) || ctx.sQueueName.equals(QUEUE_NAME_TRANS_SEARCH_TEMPLATE))
			{
				builder.append(MINF_TEMPLATES_PART).append(ServerConstants.SPACE);
				if(QUEUE_NAME_TRANS_SEARCH_TEMPLATE.equals(ctx.sFromTab))
				{
					builder.append(" AND ").append(ctx.bLowValue? LOW_VALUE_MSG_STATUS_PART : MINF_MSG_STATUS_PART).append(ctx.sQueueName)
					.append(ServerConstants.APOSTROPHE).append(ServerConstants.SPACE);
				}
			} else{
				if (! builder.toString().endsWith(WHERE_PART))
				{
					builder.append(AND);
				}
				
				if (!ctx.isBulkSearch)
				{
					builder.append(MINF_IS_NOT_HISTORY_PART);
				}

				if(!ctx.bTransactionSearch && historyDate != null)
				{
					if (!GlobalUtils.isNullOrEmpty(ctx.sProcDtCondition))
					{
						String op = ctx.sProcDtCondition.equals("1") ? "=" : (ctx.sProcDtCondition.equals("0") ? ">" : "<");
						String condition = String.format(MINF_PROCESSING_DATE_PART, op, procDate.toString(), GlobalDateTimeUtil.STATIC_DATA_DATE);
						builder.append(ServerConstants.SPACE).append(ServerConstants.SPACE).append(" AND (").append(condition).append(")");
					}
				}
				if(ctx.iQueueType == QUEUE_TYPE_USER_DEFINE && userDefinedQueueMetadata != null){

					builder.append(" AND ").append(" ( ").append(userDefinedQueueMetadata.getExecWhere()).append(" ) ");              
				}//EO if the queue type was User-Defined

				//          else if(ctx.sQueueName.equals(QUEUE_NAME_TRANS_SEARCH))
				//          {
				//              //CR#87485 Added condition P_IS_HISTORY = 0 to exclude history payment in normal search
				//              builder.append(MINF_IS_NOT_HISTORY_PART).append(ServerConstants.SPACE);
				//          }
				else if(   (ctx.iQueueType == QUEUE_TYPE_REGULAR || ctx.iQueueType == QUEUE_TYPE_GROUPING)
						&& !ctx.sQueueName.equals(QUEUE_NAME_TRANS_SEARCH)
						&& !ctx.sQueueName.equals(QUEUE_NAME_TRANS_SEARCH_HISTORY)
						&& !ctx.sQueueName.equals(QUEUE_NAME_TRANS_SEARCH_TEMPLATE)
						&& !ctx.sQueueName.equals(QUEUE_NAME_NOT_FINAL)){

					builder.append(" AND ").append(ctx.bLowValue? LOW_VALUE_MSG_STATUS_PART : MINF_MSG_STATUS_PART).append(ctx.sQueueName)
					.append(ServerConstants.APOSTROPHE).append(ServerConstants.SPACE);

				}//EO else if the queue type was Regual or Grouping and the context Generic Search, Template search or History          

			}
			if (ctx.payByApproaching)
			{
				//          Date officeCurrentTime = NewASDateTimeUtils.getCurrentDateAndZoneByOffice(ctx.sOffice).getDate();
				//          builder.append(" AND P_SLA_NOTIFY_DATETIME <= TO_DATE('" 
				//                  + GlobalDateTimeUtil.getFormattedDateString(officeCurrentTime, GlobalDateTimeUtil.STATIC_DATA_DATE_TIME)+"','"+DAOBasic.SQL_FORMAT_DATE_TIME+"') ");

				builder.append(" AND P_SLA_NOTIFY_DATETIME <= TO_DATE('" 
						+ GlobalDateTimeUtil.getFormattedDateString(new Date(), GlobalDateTimeUtil.STATIC_DATA_DATE_TIME)+"','"+DAOBasic.SQL_FORMAT_DATE_TIME+"') ");      	
			}

			//if the sChildQueueFilterValue exists, then this is a sub queue, thus add the 
			//harcoded filter of P_OFFICE = '<office>' for high value and X_STTLM_DT = '<date>' for low value 
			if(ctx.sChildQueueFilterValue != null )
			{
				String offices = ctx.sChildQueueFilterValue.replace(",", "','");
				builder.append(" AND P_OFFICE IN ('").append(offices).append("') ") ;
			}

		}//EO if the context was a get queue data, sorted data or grouping 

		//qlist_todo: Not sure how to incorporate the Queue count (inner select) with this 
		// MINF.P_MID handling.
		if((ctx.iCallingMethod == CALLING_METHOD_GET_QUEUE_DATA || ctx.iCallingMethod == CALLING_METHOD_GET_QUEUE_GROUPING) && !ctx.bIsQueueGroupingContext){

			final String MIF_MID_PART = "MINF.P_MID<'~~~~~~~~~~~~~~~~' ";
			final String LOW_VALUE_MID_PART_ORACLE = "NYI"; //qlist_todo: NYI

			if( ServerUtils.isNullOrEmpty(ctx.sMID) && !ctx.bSkipMidConstruction && !ctx.sQueueName.equals(QUEUE_NAME_RECON210) ){

				if(builder.length() > WHERE_PART_LENGTH) builder.append(AND);


				builder.append(ctx.bLowValue? LOW_VALUE_MID_PART_ORACLE :MIF_MID_PART );
			}//EO if the MID is empty and the queue name is not RECON210 
		}//EO if the context is get queue data or get queue grouping 

		boolean bUserHasStatusPermission = true;

		boolean bUserHasMessageTypePermissions = true;

		if(!ctx.bHistorySearch){

			final String sORIG_PERM_PROF_QUEUE_NOUDQ = (ctx.bLowValue? 
					ctx.userEntitlementData.getORIG_PERM_PROF_QUEUE_NOUDQ_LV_MESSAGES() : 
						ctx.userEntitlementData.getORIG_PERM_PROF_QUEUE_NOUDQ_HV_MESSAGES()
			) ;   
			// Checks if the user has permission to this status.
			if( (ctx.iQueueType == QUEUE_TYPE_REGULAR || ctx.iQueueType == QUEUE_TYPE_GROUPING)
					&& !ctx.sQueueName.equals(QUEUE_NAME_TRANS_SEARCH)
					&& !ctx.sQueueName.equals(QUEUE_NAME_TRANS_SEARCH_HISTORY)
					&& !ctx.sQueueName.equals(QUEUE_NAME_TRANS_SEARCH_TEMPLATE)){

				// User has no permission to see this status.
				if(!this.validateUserPermissionForNonUDQueue(sORIG_PERM_PROF_QUEUE_NOUDQ, ctx.sQueueName)){
					if(builder.length() > WHERE_PART_LENGTH) builder.append(AND);

					builder.append(FALSE_CONDITION);

					bUserHasStatusPermission = false;
				}// permission validation failed 
			}//EO complex calling context condition 
			// This isn't a regular queue; messages with allowed user statuses must be rertieved 
			else {

				// User has status permissions.
				if(!GlobalUtils.isNullOrEmpty(sORIG_PERM_PROF_QUEUE_NOUDQ)){
					final String MINF_MSG_STATUS_IN = "MINF.P_MSG_STS IN (";
					final String LOW_VALUE_MSG_STATUS_IN = "NYI"; //qlist_todo: NYI

					if(builder.length() > WHERE_PART_LENGTH) builder.append(AND);

					builder.append(ctx.bLowValue ? LOW_VALUE_MSG_STATUS_IN : MINF_MSG_STATUS_IN).
					append(sORIG_PERM_PROF_QUEUE_NOUDQ).append(ServerConstants.CLOSING_PARENTHESIS).
					append(ServerConstants.SPACE);
				}//EO if the user had permissions for one or more statuses    
				// User has no status permissions.
				else{
					if(builder.length() > WHERE_PART_LENGTH) builder.append(AND);

					builder.append(FALSE_CONDITION);

					bUserHasStatusPermission = false;
				}//EO else if no status permission was found 
			}//EO else if the context request was not for a regular queue 
		}//EO if this was not a request for a history queue 

		// No need to continue if the user don't have permission to see this queue status
		// or doesn't have any statuses permissions.
		if(!bUserHasStatusPermission) return builder ; 

		final String sPERM_PROF_MSG = ctx.userEntitlementData.getPERM_PROF_MSG(); 

		// User has message type permissions. 
		if(!GlobalUtils.isNullOrEmpty(sPERM_PROF_MSG)){

			final String MINF_MESSAGE_TYPE_CONDITION_PART_1 = "(TRIM(MINF.P_MSG_TYPE) || NVL(TRIM(MINF.P_MSG_SUB_TYPE),'') IN (";
			final String MINF_MESSAGE_TYPE_CONDITION_PART_2 = ") OR TRIM(MINF.P_MSG_TYPE)IS NULL)";

			final String LOW_VALUE_MESSAGE_TYPE_CONDITION_PART_1 = "NYI"; //qlist_todo: NYI 
			final String LOW_VALUE_MESSAGE_TYPE_CONDITION_PART_2 = "NYI"; //qlist_todo: NYI 

			if(builder.length() > WHERE_PART_LENGTH) builder.append(AND);

			builder.append(ctx.bLowValue ? LOW_VALUE_MESSAGE_TYPE_CONDITION_PART_1 :MINF_MESSAGE_TYPE_CONDITION_PART_1)
			.append(sPERM_PROF_MSG)
			.append(ctx.bLowValue ? LOW_VALUE_MESSAGE_TYPE_CONDITION_PART_2 :MINF_MESSAGE_TYPE_CONDITION_PART_2)
			.append(ServerConstants.SPACE);
		}//EO if there were message type permissions  
		// User has no message type permissions.
		else{
			if(builder.length() > WHERE_PART_LENGTH) builder.append(AND);

			builder.append(FALSE_CONDITION);

			bUserHasMessageTypePermissions = false;
		}//EO else if the user did not have message type permissions 

		// No need to continue if the user don't have message type permissions.
		if(!bUserHasMessageTypePermissions) return builder ;

		final String sPERM_PROF_DEPARTMENT = ctx.userEntitlementData.getPERM_PROF_DEPARTMENT(); 

		// User has department permissions.
		if(!GlobalUtils.isNullOrEmpty(sPERM_PROF_DEPARTMENT)){
			final String MINF_DEPARTMENT_IN = "MINF.P_DEPARTMENT IN (";
			final String LOW_VALUE_DEPARTMENT_IN = "NYI"; //qlist_todo: NYI 

			if(builder.length() > WHERE_PART_LENGTH) builder.append(AND);

			builder.append(ctx.bLowValue ? LOW_VALUE_DEPARTMENT_IN :MINF_DEPARTMENT_IN)
			.append(sPERM_PROF_DEPARTMENT).append(ServerConstants.CLOSING_PARENTHESIS).
			append(ServerConstants.SPACE);
		}//EO if department permissions were found 
		// User has no department permissions.
		else{
			if(builder.length() > WHERE_PART_LENGTH) builder.append(AND);

			builder.append(FALSE_CONDITION);
		}//EO else if no department permissions were found 

		// TODO - complete implementation for UD queue, history queue, etc 
		//        from 'buildSQL' C++ method from line: 'if (m_strQueueName != "~ALL~")'

		

		return builder ; 
	}//EOM 

	/**
	 * Appends extra condition to the passed select statement for the non-empty passed MID.
	 *
	 */
	private final StringBuilder constructRowNumCondition(final StringBuilder sbSelectStatement, 
			final Context ctx, boolean isFirstCondtion){

		String sFinalPageSize = null ; 

		if(ctx.iCallingMethod == CALLING_METHOD_GET_QUEUE_DATA || ctx.bSortedDueToCounterThresehold){
			// The '+1' is for checking if we have more data than the requested page size;
			// when getting the data, a check will be done if we actually (iPageSize+1)
			// rows, and if so it means we have more data, so the 'Next' button flag should
			// be true; in addition, in that case the last row will be removed from
			// the queue grid data, (see 'getQueueDataMatrix' method).
			sFinalPageSize = ctx.iPageSize+1 +  ServerConstants.EMPTY_STRING;  
		}//EO if the context was a 'get data for virtual queue' 
		// Assumes this is a sorted queue call which is not configured due to performance enhancment feature of the queue counter  
		else if(!ctx.bSortedDueToCounterThresehold){

			//String sWEBMAXQ = ((SystPar)Cache.getInstance().getSingle(CacheKeys.SystParKey,CacheKeys.SystParKey.prepareCacheEntryKey(SystemParametersInterface.SYS_PAR_WEBMAXQ))).getParmValue();
			String sWEBMAXQ = SystParKey.getSingleParmValue(SystemParametersInterface.SYS_PAR_WEBMAXQ) ;  

			if(GlobalUtils.isNullOrEmpty(sWEBMAXQ)) sWEBMAXQ = DEFAULT_MAX_WEB_QUEUE;

			sFinalPageSize = sWEBMAXQ ; 
		}//EO else  if the context was not a  'get data for virtual queue' 

		//Call is coming from web service, we need to take value that came as service input not system option.
		if (Admin.getContextAdmin().getCallSource() == CallSource.Service)
		{
			sFinalPageSize = String.valueOf(ctx.iPageSize);
		}

		//if the queue request context is sorted queue then the row num would be an added to the extrnal query as the firts condition o/w if its first condition, then WHERE part should be added
		final boolean bIsRowNumLastCondition = isFirstCondtion ? false :  ctx.iCallingMethod != CALLING_METHOD_GET_SORTED_QUEUE_DATA  ;
		final String ROWNUM_PART = DAOBasic.ms_DBType.getWhereClauseRownum(bIsRowNumLastCondition, OperatorType.LTE, sFinalPageSize)  ;

		sbSelectStatement.append(ROWNUM_PART);

		return sbSelectStatement ; 
	}//EOM


	/**
	 * Returns the start of the select statement for the queue grid data.
	 */
	private StringBuilder constructStartOfSelectStatementForQueueGridData(StringBuilder builder, final Context ctx){

		

		final String SELECT_PART = "SELECT ";

		// MINF table.
		final String MINF_INDEX_PART = " /*+ INDEX_DESC (MINF IX_MINF) */ ";
		final String MINF_INDEX_1_PART = " /*+ INDEX_DESC (MINF IX_MINF_1) */ ";
		final String ORDER_BY_FIELDS_INDEX_FOR_TRANS_SEARCH_HISTORY = " /*+ ALL_ROWS INDEX(MINF IX_MINF_COMPSEARCH) */ ";

		final String INDEX_DESC = "INDEX_DESC";
		final String INDEX = "INDEX";
		// Low value table.
		final String LOW_VALUE_INDEX_PART = "NYI" ; //qlist_todo: NYI
		ctx.isPageMode2 = false;
		logger.trace(QUEUE_NAME + ctx.sActualQueueName) ; 

		//if the queue is a sorted queue, create a wrapping query 
		if(ctx.iCallingMethod == CALLING_METHOD_GET_SORTED_QUEUE_DATA) builder.append("SELECT * FROM (") ; 

		builder.append(SELECT_PART);

		// For the SP_GET_Q_CONDITION stored procedure, which will be called for
		// user define queues.    
		if(   ctx.iCallingMethod == CALLING_METHOD_GET_QUEUE_DATA && !ctx.bIsQueueGroupingContext) { 

			// TODO: Use getPageSize() for the PAGING and not GUI hard coded 30/300
			if(ctx.iQueueType == QUEUE_TYPE_USER_DEFINE  || ctx.iQueueType == QUEUE_TYPE_VIRTUAL)
			{
					builder.append(MINF_INDEX_PART);
			}//EO if the queue type is 'User-Defined'
			else if(ctx.bHistoryQueue){
				builder.append(MINF_INDEX_PART);
			}else if(ctx.iQueueType == QUEUE_TYPE_REGULAR && !ctx.bTransactionSearch && !ctx.bHistorySearch && !ctx.bIsQueueGroupingContext){
				builder.append(ctx.bLowValue ? LOW_VALUE_INDEX_PART : MINF_INDEX_1_PART);   
			}//EO if the queue type was regularand queue name was not transaction or transaction history 

			// Will be null for a call originated from the 'getSortedQueue' method.
			if(ctx.enumPageDirection == PageDirectionType.None || ctx.enumPageDirection == PageDirectionType.Previous){

				final String sSelectStatement = builder.toString();
				builder = new StringBuilder(sSelectStatement.replaceAll(INDEX_DESC, INDEX));

			}//EO if the direction was previous or none
		}//EO if the calling context was get queue data or sorted data and queue name not transaction histrory

		else if(   ctx.iCallingMethod == CALLING_METHOD_GET_SORTED_QUEUE_DATA && ctx.bHistorySearch ){
			builder.append(ORDER_BY_FIELDS_INDEX_FOR_TRANS_SEARCH_HISTORY);
		}//EO if the calling context is sorted queue and the queue name is transaction history

		// Appends the columns part.
		builder = this.constructFieldsPartForQueueGridData(ctx, builder, ctx.listMetaData) ; 

		

		return builder ;
	}//EOM


	private StringBuilder constructPageMode2QueueGridData(StringBuilder builder, Context ctx)
	{
		final String ORDER_BY_MID_ASC = " ORDER BY P_MID ASC ";
		final String ORDER_BY_MID_DESC = " ORDER BY P_MID DESC ";
		final String SELECT = "SELECT * FROM (";
		final String SELECT_END = ") ";

		if (ctx.isPageMode2)
		{
			if(!ctx.bIsQueueGroupingContext && !ctx.bIsSortedQueue)
			{
				if(ctx.enumPageDirection != PageDirectionType.Previous) 
				{
					builder.append(ORDER_BY_MID_DESC);
				}else
				{
					builder.append(ORDER_BY_MID_ASC);
				}
			}

			builder.insert(0, SELECT).append(SELECT_END);
			constructRowNumCondition(builder, ctx, true);
		}

		return builder;
	}

	private StringBuilder constructEndOfSelectStatementForQueueGridData(StringBuilder builder, final Context ctx){

		


		// MINF table.
		final String MINF_INDEX_PART = " ORDER BY MINF.P_MID DESC ";
		final String MINF_INDEX_1_PART = " ORDER BY MINF.P_MSG_STS, MINF.P_MID DESC  ";

		final String INDEX_DESC = "MINF.P_MID DESC";
		final String INDEX = "MINF.P_MID";
		// Low value table.
		final String LOW_VALUE_INDEX_PART = "NYI" ; //qlist_todo: NYI

		logger.trace(QUEUE_NAME + ctx.sActualQueueName) ; 

		// For the SP_GET_Q_CONDITION stored procedure, which will be called for
		// user define queues.    
		if(   ctx.iCallingMethod == CALLING_METHOD_GET_QUEUE_DATA && !ctx.bIsQueueGroupingContext) {	     

			if(ctx.iQueueType == QUEUE_TYPE_USER_DEFINE)
			{
				builder.append(MINF_INDEX_PART);
			}//EO if the queue type is 'User-Defined'
			else if(ctx.bHistoryQueue){
				builder.append(MINF_INDEX_PART);
			}else if(ctx.iCallingMethod != CALLING_METHOD_GET_SORTED_QUEUE_DATA && ctx.iQueueType == QUEUE_TYPE_REGULAR && !ctx.bTransactionSearch && !ctx.bHistorySearch && !ctx.bIsQueueGroupingContext){

				builder.append(ctx.bLowValue ? LOW_VALUE_INDEX_PART : MINF_INDEX_1_PART);   
			}//EO if the queue type was regularand queue name was not transaction or transaction history 

			// Will be null for a call originated from the 'getSortedQueue' method.
			if(ctx.enumPageDirection == PageDirectionType.None || ctx.enumPageDirection == PageDirectionType.Previous){

				final String sSelectStatement = builder.toString();
				builder = new StringBuilder(sSelectStatement.replaceAll(INDEX_DESC, INDEX));

			}//EO if the direction was previous or none
		}//EO if the calling context was get queue data or sorted data and queue name not transaction histrory

		//	    else if(   ctx.iCallingMethod == CALLING_METHOD_GET_SORTED_QUEUE_DATA && ctx.bHistorySearch ){
		//	      builder.append(ORDER_BY_FIELDS_INDEX_FOR_TRANS_SEARCH_HISTORY);
		//	    }//EO if the calling context is sorted queue and the queue name is transaction history

		

		return builder ;
	}//EOM 


	/**
	 * Returns the fields part for the queue group grid data select statement.
	 */
	private StringBuilder constructFieldsPartForQueueGridData(final Context ctx, final StringBuilder builder, 
			final Collection<NewQueueListColumnMetaData> listMetaData){

		final String DATE_FIELD_PART_1 = "NVL(TO_CHAR(";
		final String DATE_TIME_FIELD_PART_2 = ",'YYYY-MM-DD HH24:MI:SS'),'') AS ";
		final String DATE_FIELD_PART_2 = ",'YYYY-MM-DD'),'') AS ";

		final String RANGE_FIELD_FORMAT_FOR_SELECT="TO_CHAR(FLOOR(%1$s/%2$s)*%2$s)||'-'|| TO_CHAR(FLOOR(%1$s/%2$s)*%2$s+%2$s-1) AS %3$s";
		final String GROUP_BY_RANGE_FIELD_FORMAT = "FLOOR(%s/%s)";
		final String COUNT_COLUMN_FORMAT_FOR_SELECT="COUNT(*) AS \"V.COUNT\"";
		final String sXmlColumnStringTemplate = "'<MultiValues xmlns=\"http://fundtech.com/SCL/QueueListService\">' || %s  || '</MultiValues>'  %s " ;          
		String sFieldId = null, sColumnBlock = null, sGroupByBlock = null, sRangeColumnBlock = null; 
		DataType enumDataType = null ; 
		int iRangeIndicator = 0 ; 
		boolean bIsXmlColumn = false  ;
		final StringBuilder groupByBuilder = new StringBuilder(" GROUP BY ") ;
		List<String> coulmnNames = null;
		if(ctx.queuePreferences != null) {
			coulmnNames = ctx.queuePreferences.getColumnNames();
		}
		
		int index = 0;
		for(NewQueueListColumnMetaData columnMetadata : listMetaData) { 

			sFieldId = columnMetadata.getFieldID() ; 
			enumDataType = columnMetadata.getDataType() ; 
			iRangeIndicator = columnMetadata.getRangeIndicator() ; 
			bIsXmlColumn = columnMetadata.isXmlColumn(); 
			
			if(ctx.bIsQueueGroupingContext && sFieldId.equals(COUNT_COLUMN_FULL_NAME)){ 

				builder.append(COUNT_COLUMN_FORMAT_FOR_SELECT);

				sColumnBlock = sGroupByBlock = "" ; 

			}
			
			// ASAF: Remarked this code - XML type columns that their original value is taken from MINF.XML_MSG or MINF.XML_ORIG_MSG
			//       will be entered into the MINF view as relational columns.
			else if(bIsXmlColumn) {
				String coulmnName = null;
				if(coulmnNames != null) {
					 coulmnName = coulmnNames.get(index);
				}
				//first attmept to retrieve the from the m_xmlColumnsCache, and if not present construct it 
				String sXmlColumnString = null;
				if((coulmnName != null) && (coulmnName.trim().matches(OCCURANCE_REGX)) && (Admin.getContextAdmin().getCallSource() == CallSource.Service)) {
					sXmlColumnString = m_mapXmlColumnsCache.get(coulmnName) ; 
				}
				else {
					sXmlColumnString = m_mapXmlColumnsCache.get(sFieldId) ; 
				}
				if(sXmlColumnString == null) { 
					final LogicalFields logicalFieldMetadata = CacheKeys.LogicalFieldsIdKey.getSingleLogicalOrUserDefinedField(sFieldId) ;
					boolean isParentInd = logicalFieldMetadata.getPathParentInd();
					if((coulmnName != null) && (coulmnName.trim().matches(OCCURANCE_REGX)) && (Admin.getContextAdmin().getCallSource() == CallSource.Service))
					{
						String  occurance = coulmnName.substring(coulmnName.indexOf('[')+1,coulmnName.indexOf(']'));
						sXmlColumnString = DAOBasic.ms_DBType.getXmlDao().constructPaymentXmlColumnCaseMultiForQueueList(sFieldId,false,occurance,XmlLocationType.XML_MSG);
						if(!isParentInd) 
						{
							sXmlColumnString = sXmlColumnString.replaceAll(EXTRACT,EXTRACTVALUE);
						}
						m_mapXmlColumnsCache.put(coulmnName, sXmlColumnString);
					}
					else {
						LogicalFields logicalFieldMetadataParent = null;
						sXmlColumnString = CacheKeys.LocicalFieldsXpathColumnDefinitionsKey.getColumnDefinition(sFieldId, false/*bIsInWhereClause*/, null/*sOccurenceIndex*/);
						if((sXmlColumnString != null) && (Admin.getContextAdmin().getCallSource() == CallSource.Service)) {
							String pathParentId = logicalFieldMetadata.getPathParentId();
							if(pathParentId != null) {
								 logicalFieldMetadataParent = CacheKeys.LogicalFieldsIdKey.getSingleLogicalOrUserDefinedField(pathParentId) ;
							}
							if (columnMetadata.getLogicalField().getFieldType().name().equals(XML_MULTI) || (logicalFieldMetadataParent != null && logicalFieldMetadataParent.getFieldType().name().equals(XML_MULTI))){
								String sqlPart =  DAOBasic.ms_DBType.getXmlDao().constructPaymentXmlColumnCaseMultiForQueueList(sFieldId,false,null,XmlLocationType.XML_MSG);
								if(isParentInd) 
								{
									sXmlColumnString  = sqlPart;
									sXmlColumnString = sXmlColumnString.replaceAll(EXTRACTVALUE,EXTRACT);
								}
								else 
								{
									String prefixSQL = "";
									String suffixSQL = "";
									if(sqlPart.contains("CASE")) {
										 prefixSQL = sqlPart.substring(0, sqlPart.indexOf("END)") + 4);
										 suffixSQL = sqlPart.substring(sqlPart.indexOf("END)") + 4 , sqlPart.length());
										 sXmlColumnString = sqlPart.replaceAll(EXTRACTVALUE,EXTRACT);
									}
									else {
										 prefixSQL = sqlPart.substring(0, sqlPart.indexOf("))") + 2);
										 suffixSQL = sqlPart.substring(sqlPart.indexOf("))") + 2 , sqlPart.length());
										 sXmlColumnString = sqlPart.replaceAll(EXTRACTVALUE,EXTRACT);
									}
									if(!prefixSQL.contains("<MultiValues")) {
										sXmlColumnString = String.format(sXmlColumnStringTemplate, prefixSQL,suffixSQL);
										sXmlColumnString = sXmlColumnString.replaceAll(EXTRACTVALUE,EXTRACT);
									}
								}
							}
						}
						m_mapXmlColumnsCache.put(sFieldId, sXmlColumnString);
					}
				//finally cache the clause 
			}//EO if the column was not constructed yet 
				//builder.append(sXmlColumnString) ;
				//append without the alias identifier 
				//if(ctx.bIsQueueGroupingContext) groupByBuilder.append(sXmlColumnString.substring(0, sXmlColumnString.indexOf("END")+3)) ;
				sColumnBlock = sXmlColumnString ; 
				if(ctx.bIsQueueGroupingContext) sGroupByBlock = sXmlColumnString.substring(0, sXmlColumnString.indexOf("END")+3)  ;   
			}
			// ASAF: Added the '!bIsXmlColumn' condition because query is now against the MINF view in which the 
			//       XML date fields are already formatted correctly so no need for the date function wrapping.
			else if((enumDataType == DataType.DATE || enumDataType == DataType.DATE_TIME) /*&& !bIsXmlColumn*/){

				sColumnBlock = DATE_FIELD_PART_1 + sFieldId + (enumDataType == DataType.DATE ? DATE_FIELD_PART_2 : DATE_TIME_FIELD_PART_2) + sFieldId  ; 

				sGroupByBlock = sFieldId ; 

				//builder.append(DATE_FIELD_PART_1).append(sFieldId).append(DATE_FIELD_PART_2).append(sFieldId);

				//if(ctx.bIsQueueGroupingContext) groupByBuilder.append(sFieldId)  ;

				//TODO: hardcoded for now, if the field id is 'F_AUDIT_ERROR_PARAMS' create a nested query which 
				//retrieves the last NEWJOURNAL error params column value and strips it of the '@@' prenthesis 
			}else if(sFieldId.equals(PDOConstantFieldsInterface.F_AUDIT_ERROR_PARAMS)) { 
				sColumnBlock = "(SELECT  SUBSTR(NJ.ERROR_PARAMS, 3, (INSTR( SUBSTR(NJ.ERROR_PARAMS, 3) , '@@')-1))\r\n" + 
				"FROM NEWJOURNAL NJ WHERE NJ.MID = MINF.P_MID  AND NJ.PARTITION_ID = MINF.P_IS_HISTORY \r\n" + 
				"AND ROWNUM < 2 AND NJ.ERROR_CODE = 40202 ) F_AUDIT_ERROR_PARAMS" ; 

				sGroupByBlock = "" ; 
			}else  { 
				sGroupByBlock = sColumnBlock = sFieldId ; 
			}//EO else if standard field 

			//handle range indication 
			if(ctx.bIsQueueGroupingContext && iRangeIndicator > 1) {

				//if the field was an xml one, then the sColumnBlock would contain an alias which should be removed 
				sRangeColumnBlock = (!bIsXmlColumn ? sFieldId : sColumnBlock.substring(0, sColumnBlock.indexOf("END")+3) ) ;

				sColumnBlock = String.format(RANGE_FIELD_FORMAT_FOR_SELECT, sRangeColumnBlock, iRangeIndicator, sFieldId) ; 
				sGroupByBlock = String.format(GROUP_BY_RANGE_FIELD_FORMAT, sGroupByBlock, iRangeIndicator) ; 

				//builder.append(String.format(RANGE_FIELD_FORMAT_FOR_SELECT, sFieldId, iRangeIndicator, sFieldId));

				//append the group by part 
				//groupByBuilder.append(String.format(GROUP_BY_RANGE_FIELD_FORMAT, sFieldId, iRangeIndicator)) ;
			}//EO if a range indicator bigger than 1 exists 

			builder.append(sColumnBlock).append(ServerConstants.COMMA) ;
			if(ctx.bIsQueueGroupingContext && !sFieldId.equals(COUNT_COLUMN_FULL_NAME)) groupByBuilder.append(sGroupByBlock).append(ServerConstants.COMMA);

			//qlist_todo: added during the metadata construcion 
			//if the field is relational, add the table name (location) to the setTableNames
			// if(columnMetadata.isRelational()) setTableNames.add(columnMetadata.getFieldLocation()) ;
			index++;
		}//EO while there are more columns to iterate over 

		//delete the last comma 
		builder.deleteCharAt(builder.length()-1) ;
		builder.append(ServerConstants.SPACE);

		if(ctx.bIsQueueGroupingContext) { 

			groupByBuilder.deleteCharAt(groupByBuilder.length()-1) ;

			groupByBuilder.append(ServerConstants.SPACE);

			//set the group by part to the ctx 
			ctx.sGroupByPart = groupByBuilder.toString() ;
		}//EO if bIsQueueGroupingContext istrue 


		return builder ; 
	}//EOM 

	/**
	 * TODO - add Filter support.
	 * Appends to the passed 'start' StringBuffer the 'from' part of the select statement
	 * for the queue grid data.
	 */ 
	private StringBuilder constructFromPartOfSelectStatementForQueueGridData(StringBuilder sbStartPart, final Context ctx,  
			final Prules userDefinedQueueMetadata){

		final String FROM = " FROM ";
		

		logger.trace(QUEUE_NAME + ctx.sActualQueueName)   ;

		//if the queuePreferences instance exists, then it might contain either system or user preference , 
		//which in both cases requires addition to the set 
		// final Collection<String> setPrefsTableNames = (ctx.queuePreferences == null ? null : ctx.queuePreferences.getColumnNames() ) ; 
		//if(setPrefsTableNames != null && !setPrefsTableNames.isEmpty()) ctx.setFromPartTableNames.addAll(setPrefsTableNames) ;  

		//if the queue type is user deefined, extract the table names from the userDefinedQueueMetadata

		if(ctx.iQueueType == QUEUE_TYPE_USER_DEFINE && userDefinedQueueMetadata != null && userDefinedQueueMetadata.getExecWhere() != null) { 
			final String sUserdefinedWhereTables = userDefinedQueueMetadata.getWhereTables() ;
			if(sUserdefinedWhereTables != null) { 
				final List<String> listWhereTables = Arrays.asList(sUserdefinedWhereTables.split(",")) ;  
				ctx.setFromPartTableNames.addAll(listWhereTables) ;
			}//EO if ther were tables 
		}//EO if user define queue

		sbStartPart.append(FROM);

		//if the ctx.setFromPartTableNames is empty, then it might be that only non relational columns were selected 
		//thus add the default MINF table 
		if(ctx.setFromPartTableNames.isEmpty()) sbStartPart.append("MINF") ;
		else { 

			// Assures that only MINF and not MINF is included in the related tables set.
			ctx.setFromPartTableNames.remove("MINF");
			ctx.setFromPartTableNames.add("MINF");

			for(String sTableName : ctx.setFromPartTableNames) { 
				sbStartPart.append(sTableName).append(',') ; 
			}//EO while there are more tables to add to the query

			//delete the last comma
			sbStartPart.deleteCharAt(sbStartPart.length()-1) ; 
		}//EO else if hte table list is not empty 

		

		return sbStartPart ;
	}//EOM 

	/**
	 * Gets additional conditions according to the sent queue mode.
	 */
	private final StringBuilder constructModeAdditionalConditions(final StringBuilder builder, final Context ctx)
	{
		final String MODE_SHOW = "SHOW"; // Call initiated from the queue explorer.
		final String MODE_EDIT = "EDIT"; // Call initiated from the "Pencil" button in the toolbar.

		// Queue request was initiated from the queue explorer, not from the 'Mode' button,
		// and this is not the history queue.
		if(   ServerConstants.SPACE.equals(ctx.sMode) && ctx.iQueueType == QUEUE_TYPE_REGULAR 
				&& !ctx.bTransactionSearch && !ctx.bHistorySearch && !ctx.bHistoryQueue)
		{
			ctx.sMode = MODE_SHOW;
		}

		boolean bContinue = true;

		// Queue permissions check which is not required for:
		// - User defined queue.
		// - Transaction search.
		// - History search & HISTORY queue, (CR #87485).
		// - Low value queue.
		if(   ctx.iQueueType != QUEUE_TYPE_USER_DEFINE
				&& !ctx.bTransactionSearch 
				&& !ctx.bHistorySearch && !ctx.bHistoryQueue
				&& !ctx.bLowValue) 
		{
			final String sORIG_PERM_PROF_QUEUE = ctx.userEntitlementData.getORIG_PERM_PROF_QUEUE();
			//if user has read permission for a queue, then he should be able to see all the messages belonging to that queue 
			if(!validateUserPermission(sORIG_PERM_PROF_QUEUE, ctx.sQueueName, -1, null))
			{
				builder.append(AND).append(FALSE_CONDITION);
				bContinue = false;
			}
		}

		if(bContinue) 
		{
			final String PART_1 = " AND NVL(P_DUAL_USERS, ' ') NOT LIKE '%";
			final String PART_2 = "%' ";

			// For mode 'Edit' we DON'T want to display the messages that the user
			// has performed the last action on them; i.e. messages that require dual control
			// according to setup of rule type ID 159, (dual control).
			//
			// For mode 'Show', (i.e. call was initiated from the queue explorer),
			// and for mode 'View', (i.e. call was initiated after the user pressed the "Pencil"
			// button in the toolbar), we want to display all messages.
			if(MODE_EDIT.equals(ctx.sMode))
			{
				builder.append(PART_1).append(ctx.sUserID).append(PART_2);
			}
		}

		return builder ; 
	}//EOM

	/**
	 * Appends extra condition to the passed select statement for the non-empty passed MID.
	 */
	private final StringBuilder constructNonEmptyMIDAdditionalCondition(final StringBuilder sbSelectStatement, 
			final Context ctx){
		final String AND_MINF_MID = " AND MINF.P_MID ";
		final String AND_LOW_VALUE_MID = "NYI"; //qlist_todo: NYI !!

		if(ctx.enumPageDirection == PageDirectionType.Next || ctx.enumPageDirection == PageDirectionType.Previous) { 

			sbSelectStatement.append(ctx.bLowValue ? AND_LOW_VALUE_MID : AND_MINF_MID).
			append(ctx.enumPageDirection == PageDirectionType.Next ? ServerConstants.LESS_THEN : ServerConstants.GREATER_THEN).      
			append(ServerConstants.SPACE).append(ServerConstants.APOSTROPHE).append(ctx.sMID).
			append(ServerConstants.APOSTROPHE);

		}//EO if the page direction was next or previous 

		return sbSelectStatement ; 
	}//EOM 

	public static final class Context  {

		public boolean isBulkSearch;
		public String sQueueName ; 
		public String sActualQueueName ;
		public String sQueueProcessDate ;
		public int iQueueType ; 
		public int iCallingMethod; 
		public PageDirectionType enumPageDirection ; 
		public String sMID ; 
		public boolean bHistoryQueue ; 
		public String sMode ; 
		public int iPageSize ; 
		public boolean bLowValue ; 
		public UserEntitlementData userEntitlementData ; 
		public Collection<NewQueueListColumnMetaData> listMetaData ; 
		public String sFilterXml ; 
		public Object[][] arrGridData ; 
		public String[] arrOrderedColumnsNames ;
		public String sUserID ; 
		public String sOffice ; 
		public String sSortOrder;   
		public QueuePreferences queuePreferences ; 
		public QueuePreferences orginalPreferences ;
		public FilterOptionType enumFilterType ; 
		public boolean bIsSortedQueue ; 
		public boolean bIsVirutalQueue ; 
		public boolean bTransactionSearch ;  
		public boolean bIsDrillDownQueue ;  
		public boolean bHistorySearch ; 
		public boolean bMoreData ;
		public boolean bSkipMidConstruction;
		public boolean bSortedDueToCounterThresehold ;
		public boolean bIsQueueGroupingContext ; 
		public List<StatementParameter> listStatementParameters  ;
		public Feedback feedback ; 
		public Set<String> setFromPartTableNames ; 
		public String sChildQueueFilterValue ; 
		public String sGroupFields ; 
		public String sGroupByPart ; 
		public String sOrderByPart ; 
		public String sVirtualQueueFilterPart ; 
		public String sButtonId ; 
		public boolean payByApproaching;
		public String sProcDtCondition;
		public boolean isPageMode2;
		public boolean bSkipFormatting ; 
		public String sSelectedMID;
		public String sFromTab;
		public boolean bExportToExcel;

		public Context(){} 

		public Context(final String sQueueName, final QueuePreferences queuePrefs, 
				final int iQueueType, final int iCallingMethod, PageDirectionType enumPageDirection, 
				final int iPageSize, Collection<NewQueueListColumnMetaData> listMetaData, 
				final FilterOptionType enumFilterOption, final boolean bSkipMidConstruction) { 

			this.isBulkSearch = false;
			this.setQueueName(sQueueName) ; 
			this.queuePreferences = queuePrefs ; 
			this.iQueueType = iQueueType ; 
			this.iCallingMethod = iCallingMethod ; 
			this.enumPageDirection = enumPageDirection ; 
			this.iPageSize = iPageSize ; 
			this.listMetaData = listMetaData ; 
			this.enumFilterType = enumFilterOption ; 
			this.bSkipMidConstruction = bSkipMidConstruction ; 

			this.feedback = new Feedback() ; 
			this.setFromPartTableNames = new HashSet<String>() ; 
		}//EOM 

		public Context(QueueListRequestData queueListRequestData){ 
			//used in the queue name initialisation process and thus must come prior to the setting.
			
			if (queueListRequestData.getQueueName().startsWith(QUEUE_NAME_BULK_SEARCH)  )
			{
				queueListRequestData.setQueueName(QUEUE_NAME_TRANS_SEARCH);
				//String sQueueName = queueListRequestData.getQueueName();
				//sQueueName = sQueueName.replace(QUEUE_NAME_BULK_SEARCH, QUEUE_NAME_TRANS_SEARCH);
				//queueListRequestData.setQueueName(sQueueName);
				this.isBulkSearch = true;
			}
			else
			{
				this.isBulkSearch = false;
			}

			
			this.bLowValue = queueListRequestData.isLowValue() ;

			this.setQueueName(queueListRequestData.getQueueName()) ; 

			this.setMID(queueListRequestData.getMID()) ;   
			this.iPageSize = queueListRequestData.getPageSize() ; 
			this.sMode = queueListRequestData.getMode() == null ? null : queueListRequestData.getMode().toUpperCase() ;
			this.bIsVirutalQueue = queueListRequestData.isVirtualQueue() ; 
			this.sFilterXml = queueListRequestData.getFilterXmlString() ; 
			this.sSortOrder = queueListRequestData.getSortOrder() ; 
			this.bIsSortedQueue = queueListRequestData.shouldUseSortOrder() ;
			this.bIsQueueGroupingContext = queueListRequestData.isQueueGroupingContext() ; 
			this.sGroupFields = queueListRequestData.getQueueGroupingFields() ; 
			this.sButtonId = queueListRequestData.getActionId() ;

			this.feedback = new Feedback() ; 
			this.setFromPartTableNames = new HashSet<String>() ;  
			this.payByApproaching = !GlobalUtils.isNullOrEmpty(queueListRequestData.getPayByApproaching()) && queueListRequestData.getPayByApproaching().equals("true") ? true:false;
			this.sProcDtCondition = queueListRequestData.getProcDtCondition();
			this.bSkipFormatting = queueListRequestData.skipFormatting() ; 
			this.setSelectedMID(queueListRequestData.getSelectedMID());
			this.sFromTab = queueListRequestData.getFromTab();
			this.bExportToExcel = queueListRequestData.isExportToExcel();
		}//EOM 

		private final void setMID(final String sMID){ 
			this.sMID = sMID == null ? "" : sMID.trim();
		}//EOM 

		public final void setQueueName(String sQueueName) { 

			this.sQueueName = sQueueName.trim(); 
			this.sActualQueueName = this.bLowValue? GlobalConstants.LOW_VALUE_PREFIX: GlobalConstants.HIGH_VALUE_PREFIX + this.sQueueName ;

			//finally, if there is a '|||' delimiter in the queue name remove it 
			//          final int iIndexOfDelimiter = sQueueName.indexOf("|||") ; 
			//          if(iIndexOfDelimiter != -1) { 
			//                          
			//            //assign the substring after the ||| to the sChildQueueFilterValue's value
			//              this.sChildQueueFilterValue = this.sQueueName.substring(iIndexOfDelimiter + 3) ;
			//              
			//              this.sQueueName = this.sQueueName.substring(0, iIndexOfDelimiter) ;
			//          }//EO if there was a child queue addtional filter


			String[] queueNamePartsArr = sQueueName.split("\\|\\|\\|");

			if (queueNamePartsArr.length > 1)
			{
				this.sQueueName = queueNamePartsArr[0];
				this.sChildQueueFilterValue = queueNamePartsArr[1];
				if (queueNamePartsArr.length >2 ) this.sQueueProcessDate = queueNamePartsArr[2];
			}


		}//EOM 

		private final void setSelectedMID(final String sSelectedMID){ 
			this.sSelectedMID = sSelectedMID == null ? "" : sSelectedMID.trim();
		}//EOM

		public final Context clone() { 
			return new Context(this.sQueueName, this.queuePreferences, 
					this.iQueueType, this.iCallingMethod, this.enumPageDirection, 
					this.iPageSize, this.listMetaData, this.enumFilterType, this.bSkipMidConstruction) ; 
		}//EOM 

	}//EO inner class Context 

	/**
	 * 
	 * Jun 2, 2008
	 * BOQueues.java
	 * @author guys
	 * 
	 * used for storing default and must have queue list cached metadata
	 * such as column chooser default selected columns, queue list columns and table name set 
	 * for the 'from' clause  
	 *
	 */
	public static final class ColumnMedataSet { 
		private Map<String,NewQueueListColumnMetaData> m_mapQListColumns  ;   
		private DTODataHolder m_dtoColumnSettingsSelectedColumns ; 
		private Set<String> m_setTableNames ; 
		private String m_sColumnNamesString ; 

		public ColumnMedataSet() { 
			this.m_mapQListColumns  = new LinkedHashMap<String, NewQueueListColumnMetaData>() ;
			this.m_dtoColumnSettingsSelectedColumns = new DTODataHolder() ; 
			this.m_setTableNames = new HashSet<String>() ; 
		}//EOM 

		public final void addNewColumn(final LogicalFields field, final int iOrder) {
			final String sFieldId = field.getFieldLogicalId() ; 

			//add a new qlist column 
			this.m_mapQListColumns.put(sFieldId, 
					new NewQueueListColumnMetaData(field, "0", 0, iOrder , null) // sort position, group postion, order, width 
			) ;

			//add a new column chooser selected column row  
			final HashMap<String, String> hmRow = new HashMap<String, String>()  ; 
			hmRow.put(ServerConstants.COLUMN_NAME_KEY, sFieldId) ; 
			hmRow.put(ServerConstants.ALIAS_NAME_KEY, field.getAlias()) ;
			this.m_dtoColumnSettingsSelectedColumns.addDataRow(hmRow) ; 

			//add the table name to the set if the field type is relational  
			if(field.getFieldType() == FieldType.RELATIONAL) this.m_setTableNames.add(field.getLocation()) ;

			//append the column name to the m_sColumnNamesString which wouuld be used 
			//during the order by enrichment process 
			m_sColumnNamesString += "," + sFieldId ; 
		}//EOM 

		public final boolean contains(final LogicalFields field) { 
			return this.m_mapQListColumns.containsKey(field.getFieldLogicalId()) ; 
		}//EOM 

		public final DTODataHolder getColumnSettingsDefaultSelectedColumns() { return this.m_dtoColumnSettingsSelectedColumns ; } 

	}//EO inner class ColumnMetadataSet 

	/**
	 * Returns list of user defined queues in which the passed MID is included.
	 * 
	 * @bo.authorizeUser returnWebSessionInfo="true"
	 */
	@Expose
	@AuthorizeUser(returnWebSessionInfo=true)
	public SimpleResponseDataComponent getUserDefinedQueuesList(String sMID)
	{
		
		SimpleResponseDataComponent response = new SimpleResponseDataComponent();

		try
		{
			BORuleExecution boRuleExecution = new BORuleExecution();

			final PDO pdo = PaymentDataFactory.load(sMID);

			// Gets the message status and description of the system queue to which this MID belongs. 
			String sMessageStatus = pdo.getString(PDOConstantFieldsInterface.P_MSG_STS);
			String sMessageStatusDescription = CacheKeys.statusesKey.getSingle(sMessageStatus).getAlias();

			String[] arrObjectIDs = new String[]{ServerConstants.DEFAULT_SERVER_OFFICE_NAME};
			List<RuleResult> listRuleResults = boRuleExecution.executeRule(MessageConstantsInterface.RULE_TYPE_ID_USER_DEFINED_QUEUE, null,
					sMID, arrObjectIDs).getResults();

			Object[][] arrData;

			if(!listRuleResults.isEmpty())
			{
				int iSize = listRuleResults.size();

				arrData = new Object[2][iSize+1];

				for(int i=0; i<iSize; i++)
				{
					String sRuleUID = listRuleResults.get(i).getRuleUID();

					Prules pRules = CacheKeys.PRulesUIDKey.getSingle(sRuleUID);

					arrData[0][i] = pRules.getRuleName();
					arrData[1][i] = pRules.getDescription();
				}

				// Adds the system queue to which this MID belongs.
				arrData[0][iSize] = sMessageStatus;
				arrData[1][iSize] = sMessageStatusDescription;
			}

			// Minimum size of the returned list is 1, for the non-user defined queue,
			// (i.e. the system queue), to which this MID belongs.
			else
			{
				arrData = new Object[][]{{sMessageStatus}, {sMessageStatusDescription}};
			}

			response.setDataArray(new Object[]{arrData, arrUserDefinedQueuesListMetaData});
		}

		catch(Exception e)
		{
			ExceptionController.getInstance().handleException(e, this);
			response.getFeedback().setFailure();
		}

		

		return response;
	}
		}
