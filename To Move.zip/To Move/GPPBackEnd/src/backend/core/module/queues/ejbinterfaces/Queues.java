package backend.core.module.queues.ejbinterfaces;

import javax.ejb.Remote;

import com.fundtech.core.queues.request.QueueListRequestData;
import com.fundtech.core.security.Admin;

/**
 * Remote interface for Queues.
 */
@Remote
public interface Queues{

	public static final String REMOTE_JNDI_NAME="ejb/QueuesBean";
	
	
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent getMatchingActions(final Admin admin, java.lang.String mid ) throws java.lang.Exception ;
	
	/** 
	 * Returns Group Actions data. 
	 * @bo.authorizeUser returnWebSessionInfo="true"
	 * qlist_todo: separate flow required!!
	 */
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent getGroupActions(final Admin admin, java.lang.String sMIDsList, boolean bLowValue ) ;
	
	/** 
	 * Returns queue list data. 
	 * @bo.authorizeUser returnWebSessionInfo="true"
	 */
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent getQueueData(final Admin admin, com.fundtech.core.queues.request.QueueListRequestData queueListRequestData ) ;
	
	/** 
	 * Returns queue list data. 
	 * @bo.authorizeUser returnWebSessionInfo="true"
	 */
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent getQueueDataForAccountPosition(final Admin admin, com.fundtech.core.queues.request.AccountPositionQueueListRequestData queueListRequestData ) ;
	
	/** 
	 * Returns Acknowledgments data. 
	 * @bo.authorizeUser returnWebSessionInfo="true"
	 */
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent getAcknowledgmentsData(final Admin admin, com.fundtech.core.queues.request.AcknowledgmentsRequestData acknowledgmentsRequestData ) ;
	
	/** 
	 * Returns list of user defined queues in which the passed MID is included.
	 * @bo.authorizeUser returnWebSessionInfo="true"
	 */
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent getUserDefinedQueuesList(final Admin admin, java.lang.String sMID ) ;

	/** 
	 * Returns queue list data
	 * @bo.authorizeUser returnWebSessionInfo="true"
	 */
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent getMidsDrillDownQueue(Admin admin, com.fundtech.core.queues.request.QueueListRequestData requestData, java.lang.String[] midsArray);

}//EOI  