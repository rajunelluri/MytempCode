package backend.core.module.queues.common;

public enum QueueType 
{
	STATUS, UDQ;
}
