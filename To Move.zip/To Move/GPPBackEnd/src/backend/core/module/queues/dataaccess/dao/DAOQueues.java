package backend.core.module.queues.dataaccess.dao;

import java.sql.Types;

import org.apache.commons.lang.StringUtils;

import com.fundtech.core.general.StatementParameter;
import com.fundtech.util.GlobalConstants;

import backend.core.module.genservices.dataaccess.dao.DAOGeneralServices;
import backend.dataaccess.dto.CallableStatementParameter;
import backend.dataaccess.dto.DTODataHolder;
import backend.dataaccess.dto.DTOSingleValue;
import backend.mapping.config.AppServerConfigKeysInterface;
import backend.util.ServerConstants;
import backend.util.ServerUtils;

/**
 * Title:       DAOQueues
 * Description: Data access object which provides queue services
 * Company:     Fundtech Israel
 * Author:      Asaf Levy
 * Date:        02/05/05
 * @version     1.0
 */
public class DAOQueues extends DAOGeneralServices 
{
  /**
   * Returns data according to the passed select statment.
   */
  public DTODataHolder getQueueGridData(String sSelectStatement, 
                                        StatementParameter[] arrStatementParameters,
                                        int iPageSize, boolean bLowValue)
  {
	boolean bAlreadyAppendedRowNum = ms_DBType.doesWhereClauseRownumExist(sSelectStatement) ;
	  
    int iNumOfRows = bAlreadyAppendedRowNum ? -1 : iPageSize;
    
//    String sDataSourceID = bLowValue ? AppServerConfigKeysInterface.DATA_SOURCE_ID_REPORTING :
//                                       AppServerConfigKeysInterface.DATA_SOURCE_ID_ACTIVE;
    String sDataSourceID = AppServerConfigKeysInterface.DATA_SOURCE_ID_REPORTING;
	
    DTODataHolder dto = arrStatementParameters != null ?
                        getData(sDataSourceID, sSelectStatement, arrStatementParameters, iNumOfRows) :
                        getData(sDataSourceID, sSelectStatement, iNumOfRows);
	
	return dto;
  }
  
  /**
   * Perform call to SP_GET_Q_CONDITION stored procedure.
   */
  public DTODataHolder executeSP_GET_Q_CONDITION(String sQueueName)
  {
    final String SP_GET_Q_CONDITION = "{call SP_GET_Q_CONDITION(?,?,?,?,?,?)}";
    
    final int INDEX_QUEUE_NAME = 0; // IN VARCHAR2
    final int INDEX_CONDITION = 1;  // OUT VARCHAR2
    final int INDEX_HINT = 2;       // OUT VARCHAR2
    final int INDEX_JOIN_MTF = 3;   // OUT NUMBER
    final int INDEX_STATUS = 4;     // OUT VARCHAR2
    final int INDEX_RETCODE = 5;    // OUT NUMBER

    CallableStatementParameter[] arrParams = new CallableStatementParameter[6];

    // In queue name.
    arrParams[INDEX_QUEUE_NAME] = new CallableStatementParameter();
    arrParams[INDEX_QUEUE_NAME].init(sQueueName, Types.VARCHAR);

    // OUT condition.
    arrParams[INDEX_CONDITION] = new CallableStatementParameter(CallableStatementParameter.OUTPUT_ONLY);
    arrParams[INDEX_CONDITION].init(GlobalConstants.EMPTY_STRING, Types.VARCHAR);

    // OUT index hint.
    arrParams[INDEX_HINT] = new CallableStatementParameter(CallableStatementParameter.OUTPUT_ONLY);
    arrParams[INDEX_HINT].init(GlobalConstants.EMPTY_STRING, Types.VARCHAR);
    
    // OUT join MTF.
    arrParams[INDEX_JOIN_MTF] = new CallableStatementParameter(CallableStatementParameter.OUTPUT_ONLY);
    arrParams[INDEX_JOIN_MTF].init(GlobalConstants.EMPTY_STRING, Types.NUMERIC);

    // OUT status.
    arrParams[INDEX_STATUS] = new CallableStatementParameter(CallableStatementParameter.OUTPUT_ONLY);
    arrParams[INDEX_STATUS].init(GlobalConstants.EMPTY_STRING, Types.VARCHAR);
    
    // OUT condition.
    arrParams[INDEX_RETCODE] = new CallableStatementParameter(CallableStatementParameter.OUTPUT_RETURN_CODE);
    arrParams[INDEX_RETCODE].init(GlobalConstants.EMPTY_STRING, Types.NUMERIC);

    return executeCallableStatement(SP_GET_Q_CONDITION, arrParams);
  }   
  
  /**
   * Returns object for one virtual queue's dynamic buttons.
   */
  public DTODataHolder getVirtualQueueDynamicButtons(String sQueueName)
  {//TODO: TO MODIFY Q_LIST_ACTIONS TO USE THE BUTTON IDS FROM THE BUTTON TABLE OR CREATE AN EXTRA COLUMN FOR FIELD_ID
    final String SELECT_STATEMENT =
                       "SELECT QLA.BUTTON_ID,MB.BUTTONDESCRIPTION, MB.ACC_LVL_ID" +
                       " FROM Q_LIST_ACTIONS QLA LEFT OUTER JOIN MESSAGEBUTTONS MB" +
                       " ON TO_CHAR(QLA.BUTTON_ID) = MB.BUTTONID WHERE Q_NAME = ?" ;
    
    StatementParameter[] arrParameters = new StatementParameter[1];
    arrParameters[0] = new StatementParameter(sQueueName, Types.VARCHAR);
    
    return getData(SELECT_STATEMENT, arrParameters);
  }
  
  /**
   * Returns count of records from MFAMILY for the passed MID and relation.
   */
  public DTOSingleValue getCountFromMFAMILY(String sMID, String sRelation)
  {
    final String SELECT_STATEMENT = "SELECT COUNT(*) FROM MFAMILY " +
                                    "WHERE CHILDMID = ? AND RELATION = ?";
    
    StatementParameter[] arrParameters = new StatementParameter[2];
    arrParameters[0] = new StatementParameter(sMID, Types.VARCHAR);
    arrParameters[1] = new StatementParameter(sRelation, Types.VARCHAR);
      
    return getSingleValue(SELECT_STATEMENT, arrParameters, null);
  }
  
  ////////////// Start Group Actions methods /////////////////////
  /**
   * Returns the values of MSG_STATUS from MIF or LVMIF according to passed MIDs.
   */
  public DTODataHolder getMsgStatuses(String sMIDs, boolean bLowValue)
  {
	  final String SELECT_STATEMENT_1 = "SELECT DISTINCT P_MSG_STS FROM ";
	  final String SELECT_STATEMENT_2 = " WHERE P_MID IN (";
	  
	  String sTableName = bLowValue? ServerConstants.TABLE_NAME_LVMIF: ServerConstants.TABLE_NAME_MINF;
	  
	  StringBuffer sbSelectStatement = new StringBuffer(SELECT_STATEMENT_1)
	  				.append(sTableName).append(SELECT_STATEMENT_2)
	  				.append(sMIDs).append(ServerConstants.CLOSING_PARENTHESIS);
	  
	  return getData(sbSelectStatement.toString(), 0);
  }
  
  /**
   * Returns the values of STATUS from ESSAGE_GROUP_ACTIONS.
   */
  public DTODataHolder getAllowedStatuses(boolean bIsMIDGroup)
  {
    final String SELECT_STATEMENT_1 = "SELECT DISTINCT STATUS FROM MESSAGE_GROUP_ACTIONS";
    final String SELECT_STATEMENT_2 = " WHERE ALLOW_GROUP <> 0";
    
    StringBuffer sbSelectStatement = new StringBuffer(SELECT_STATEMENT_1);
    if(bIsMIDGroup)
	{
    	sbSelectStatement.append(SELECT_STATEMENT_2);
	}    
              
    return getData(sbSelectStatement.toString(), 0);
  }
  
  /**
   * Returns count of records from MIF/LVMIF for the passed MIDs and Msg statuses.
   */
  public DTOSingleValue getMsgStatusCount(String sMIDs, String sMsgStatuses, boolean bLowValue)
  {
    final String SELECT_STATEMENT_1 = "SELECT COUNT(P_MSG_STS) AS COUNT_OF_NONE_ALLOWED_ACTIONS FROM ";
    final String SELECT_STATEMENT_2 = " WHERE P_MID IN (";
    final String SELECT_STATEMENT_3 = ") AND NOT P_MSG_STS IN (";
    
    String sTableName = bLowValue? ServerConstants.TABLE_NAME_LVMIF: ServerConstants.TABLE_NAME_MINF;
    
    StringBuffer sbSelectStatement = new StringBuffer(SELECT_STATEMENT_1)
    	.append(sTableName).append(SELECT_STATEMENT_2).append(sMIDs)
		.append(SELECT_STATEMENT_3).append(ServerUtils.generateInForSelectClause(sMsgStatuses)).append(ServerConstants.CLOSING_PARENTHESIS);
      
    return getSingleValue(sbSelectStatement.toString(), null);
  }
  
  /**
   * Returns the values of BUTTON_ID from the MESSAGE_GROUP_ACTIONS of the passed MIDs and statuses.
   */
  public DTODataHolder getButtonIds(String sStatuses, boolean bIsMIDGroup, 
		  							String sPERM_PROF_ACCESS, String sMsgStatusCount, boolean bLowValue)
  {
    final String SELECT_STATEMENT_1 = "SELECT BUTTONID, ACCS_LVL_ID FROM MESSAGE_GROUP_ACTIONS WHERE (STATUS IN ("; //=sStatuses
    final String SELECT_STATEMENT_2 =")) ";
    final String SELECT_STATEMENT_3 = "AND (ALLOW_GROUP <> 0) ";
    final String SELECT_STATEMENT_4 = "AND ACCS_LVL_ID IN ("; //=sPERM_PROF_ACCESS
    final String SELECT_STATEMENT_5 = ") GROUP BY BUTTONID, ACCS_LVL_ID HAVING (COUNT(BUTTONID) = "; //=iMsgStatusCount
    final String SELECT_STATEMENT_6 = " UNION SELECT BUTTONID, ACCS_LVL_ID FROM MESSAGE_GROUP_ACTIONS WHERE (STATUS IS NULL OR STATUS = 'ANY') ";
    final String SELECT_STATEMENT_7 = "AND ACCS_LVL_ID IN (";//=sPERM_PROF_ACCESS;
    
    StringBuffer sbSelectStatement = new StringBuffer(SELECT_STATEMENT_1)
    						.append(ServerUtils.generateInForSelectClause(sStatuses)).append(SELECT_STATEMENT_2);
    if(bIsMIDGroup)
	{
    	sbSelectStatement.append(SELECT_STATEMENT_3);
	}  
    sbSelectStatement.append(SELECT_STATEMENT_4).append(sPERM_PROF_ACCESS)
    	.append(SELECT_STATEMENT_5).append(sMsgStatusCount).append(ServerConstants.CLOSING_PARENTHESIS);

    //Currently, only for high value queues - add default action of print:
    if(!bLowValue)
    {
	    sbSelectStatement.append(SELECT_STATEMENT_6);
		if(bIsMIDGroup)
		{
			sbSelectStatement.append(SELECT_STATEMENT_3);
		}
		sbSelectStatement.append(SELECT_STATEMENT_7)
			.append(sPERM_PROF_ACCESS).append(ServerConstants.CLOSING_PARENTHESIS);
    }
    
    return getData(sbSelectStatement.toString(), 0);
  }
  
  /**
   * Returns the value of OFFICE from the MIF/LVMIF record of the passed MIDs.
   */
  public DTODataHolder getOffice(String sMIDs, boolean bLowValue)
  {
	  final String SELECT_STATEMENT_1 = "SELECT DISTINCT OFFICE FROM ";
	  final String SELECT_STATEMENT_2 = " WHERE MID IN (";
	  
	  String sTableName = bLowValue? ServerConstants.TABLE_NAME_LVMIF: ServerConstants.TABLE_NAME_MIF;
	  
	  StringBuffer sbSelectStatement = new StringBuffer(SELECT_STATEMENT_1).append(sTableName)
	  			.append(SELECT_STATEMENT_2).append(sMIDs).append(ServerConstants.CLOSING_PARENTHESIS);
	  
	  return getData(sbSelectStatement.toString(), 0);
  }
  
  ////////////// End Group Actions methods /////////////////////
  
  public final DTOSingleValue  getQueueAdditionalConditions(final String sQueueName, final String sUserId) { 
	  final String STATEMENT = "SELECT XML_CONDITIONS FROM QUEUE_PREFERENCES WHERE USER_ID = ? AND QUEUE_NAME = ?" ;
	  final StatementParameter[] arrStatementParameteres = { new StatementParameter(sQueueName, Types.VARCHAR), 
			  	new StatementParameter(sUserId, Types.VARCHAR) 
	  	}; 
	  return this.getSingleValue(STATEMENT, arrStatementParameteres, null) ; 
  }//EOM 
  
  /**
   * Returns acknowledgments (INTERFACE_CONTENT) for the passed MID and optional interface fields.
   */
  public DTODataHolder getAcks(String sMID, String sInterfaceName, String sInterfaceType, String sInterfaceSubType)
  {
    final String SELECT_STATEMENT_1 = "SELECT INTERFACE_CONTENT FROM MESSAGE_EXTERNAL_INTERACTION " +
                                    "WHERE MID = '";
    final String SELECT_STATEMENT_2 = "' AND INTERFACE_NAME = '";
    final String SELECT_STATEMENT_3 = "' AND INTERFACE_TYPE = '";
    final String SELECT_STATEMENT_4 = "' AND INTERFACE_SUB_TYPE = '";
    final String SELECT_STATEMENT_5 = "'";
    
    StringBuffer sbSelectStatement = new StringBuffer(SELECT_STATEMENT_1).append(sMID);
    if(StringUtils.isNotEmpty(sInterfaceName)) {
    	sbSelectStatement.append(SELECT_STATEMENT_2).append(sInterfaceName);	
    }
    if(StringUtils.isNotEmpty(sInterfaceType)) {
    	sbSelectStatement.append(SELECT_STATEMENT_3).append(sInterfaceType);	
    }
    if(StringUtils.isNotEmpty(sInterfaceSubType)) {
    	sbSelectStatement.append(SELECT_STATEMENT_4).append(sInterfaceSubType);	
    }
    sbSelectStatement.append(SELECT_STATEMENT_5);
    
    return getData(sbSelectStatement.toString(), 0);
  }
}