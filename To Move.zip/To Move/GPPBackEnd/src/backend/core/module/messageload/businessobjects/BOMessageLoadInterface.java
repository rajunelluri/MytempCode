package backend.core.module.messageload.businessobjects;

import com.fundtech.core.security.Admin;

/**
 * internal interface for BOMessageLoad.
 */
public interface BOMessageLoadInterface{

	
	
	/** 
	 */
	public com.fundtech.core.paymentprocess.data.PDO newMessage(final Admin admin, java.io.Serializable oInput ) ;

}//EOI  