package backend.core.module.messageload.ejbinterfaces;

import javax.ejb.Local;

/**
 * Local interface for MessageLoad.
 */
@Local
public interface MessageLoadLocal extends MessageLoad{} ; 