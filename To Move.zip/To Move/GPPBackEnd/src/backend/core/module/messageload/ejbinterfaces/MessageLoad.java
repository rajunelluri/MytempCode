package backend.core.module.messageload.ejbinterfaces;

import javax.ejb.Remote;
import com.fundtech.core.security.Admin;

/**
 * Remote interface for MessageLoad.
 */
@Remote
public interface MessageLoad{

	public static final String REMOTE_JNDI_NAME="ejb/MessageLoadBean";
	
	
	/** 
	 * Performs locked message release for one or two messages. Returns boolean[] with success/failure notifications.
	 */
	public com.fundtech.datacomponent.response.Feedback releaseLockedMessage(final Admin admin, com.fundtech.datacomponent.request.CloseMessageInputData closeMessageInputData ) ;
	
	public com.fundtech.datacomponent.response.GlobalResponseDataComponentText loadMessageScreenObject(final Admin admin, com.fundtech.datacomponent.request.LoadMessageInputData loadMessageInputData ) ;
	
	/** 
	 */
	public com.fundtech.datacomponent.response.Feedback loadMessage(final Admin admin, java.lang.String sMID, java.io.Serializable oAdditionalInput ) ;
	
	/** 
	 */
	public com.fundtech.core.paymentprocess.data.PDO newMessage(final Admin admin, java.io.Serializable oInput ) ;

}//EOI  