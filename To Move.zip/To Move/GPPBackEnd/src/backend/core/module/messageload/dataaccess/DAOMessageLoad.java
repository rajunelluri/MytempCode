package backend.core.module.messageload.dataaccess;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.core.module.MessageConstantsInterface;
import backend.core.module.genservices.dataaccess.dao.DAOGeneralServices;
import backend.core.module.messageload.businessobjects.BOMessageLoad;
import backend.dataaccess.dao.DAOBasic;
import backend.dataaccess.dao.DBType;
import backend.dataaccess.dto.DTODataHolder;
import backend.dataaccess.dto.DTOSingleValue;
import backend.paymentprocess.erroraudit.ErrorAuditUtils;
import backend.staticdata.profilehandler.rule.dataaccess.dao.DAOPRules;
import backend.util.ServerConstants;
import backend.util.ServerUtils;

import com.fundtech.cache.entities.Prules;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.general.StatementParameter;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.das.DASInterface.XmlLocationType;
import com.fundtech.core.security.Admin;

import com.fundtech.errors.ProcessErrorConstants;
import com.fundtech.lang.OperatorType;
import com.fundtech.util.ExceptionController;

/**
 * Data access object for the {@link BOMessageLoad} class. 
 * <br> 
 * The class supports low and high value message type related load operations  
 * @author Guy Segev
 * @date Apr 29, 2007
 * copyrights: Fundtech 2007.
 */
public class DAOMessageLoad extends DAOGeneralServices implements MessageConstantsInterface
{

	private final static Logger logger = LoggerFactory.getLogger(DAOMessageLoad.class);
	private final static String USERNAME = "USERNAME";
	
  
  /**
   * Returns data from the NEWJOURNAL table.
   * @param sMID the related message ID.
   * @param bIncludeChildrenPart true - this MID stands for a message with message 
   *                                    class in (PI,PAY,OPI,DD), and we need to get
   *                                    children audit trail.
   *                             otherwise, false and no need to get children audit trail.      
   * @param iHighEndPageLimit page navigation variable marking the highend limit of the recordset to fetch.
   * @param iLowerEndPageLimit page navigation variable marking the lowend limit of the recordset to fetch.
   */
  public DTODataHolder getNEWJOURNAL_Data(Connection conn, String sMID, boolean bIncludeChildrenPart,
                                          int iHighEndPageLimit, int iLowerEndPageLimit, Integer partitionID)
  {
    // Defined for ORACLE - difference is in the DURATION/RELATION columns.
    String SELECT_STATEMENT_WITH_NO_CHILDREN_ORACLE = 
      "SELECT * FROM (SELECT ORDERED_PACKET.*, " + 
      DAOBasic.ROWNUM_VARIABLE + " RNUM " +
      "FROM (SELECT IP_ADDRESS, HIT_INFO, MID, MODULE_ID, " +  
      "TO_CHAR(UPDATE_DATE, 'YYYY-MM-DD HH24:MI:SS') || CASE WHEN ZONE_CODE IS NULL " + 
      "THEN '' ELSE ' (' || ZONE_CODE || ')' END AS UPDATE_DATE,"+
      "TO_CHAR(ENDDATE, 'YYYY-MM-DD HH24:MI:SS') || CASE WHEN ZONE_CODE IS NULL " + 
      "THEN '' ELSE ' (' || ZONE_CODE || ')' END AS ENDDATE," +
      
      // 'DURATION' column.
      " ( ( TO_NUMBER(SUBSTR( CAST( UPDATE_DATE AS TIMESTAMP) - CAST( ENDDATE AS TIMESTAMP) ,2,9) )*24 + " +
      "TO_NUMBER(SUBSTR(CAST( UPDATE_DATE AS TIMESTAMP) - CAST( ENDDATE AS TIMESTAMP) ,12,2)) ) " +
      "||SUBSTR(CAST( UPDATE_DATE AS TIMESTAMP) - CAST( ENDDATE AS TIMESTAMP) ,14,6) ) AS DURATION, " +
      
      "USERNAME, ACTIONID1, ACTIONID2, STATUS, ERROR_CODE,  ERROR_PARAMS, TIME_STAMP, CLASS, CAST(NULL AS VARCHAR(1)) RELATION, " +
      "CASE WHEN XML_RELATED_FIELDS_DATA IS NOT NULL THEN 'Yes' ELSE 'No' END AS ZOOM_INDICATOR " +
      "FROM VR_NEWJOURNAL NEWJOURNAL " +
      "WHERE MID = ? AND PARTITION_ID = ? " +
      "ORDER BY TIME_STAMP DESC) " + 
      "ORDERED_PACKET %s) WHERE RNUM >= ?";
    
    // Defined for DB2 - difference is in the DURATION/RELATION columns.
    String SELECT_STATEMENT_WITH_NO_CHILDREN_DB2 = 
      "SELECT * FROM (SELECT ORDERED_PACKET.*, " + 
      DAOBasic.ROWNUM_VARIABLE + " RNUM " +
      "FROM (SELECT IP_ADDRESS, HIT_INFO, MID, MODULE_ID, " +  
      "TO_CHAR(UPDATE_DATE) || CASE WHEN ZONE_CODE IS NULL " + 
      "THEN '' ELSE ' (' || ZONE_CODE || ')' END AS UPDATE_DATE,"+
      "TO_CHAR(ENDDATE) || CASE WHEN ZONE_CODE IS NULL " + 
      "THEN '' ELSE ' (' || ZONE_CODE || ')' END AS ENDDATE, " +
      
      // 'DURATION' column.
      "LPAD(FLOOR(((DAYS(UPDATE_DATE) - DAYS(ENDDATE)) * 86400 + (MIDNIGHT_SECONDS(UPDATE_DATE) - MIDNIGHT_SECONDS(ENDDATE)))/3600),2,'0') || ':' ||" +
      "LPAD(FLOOR((MOD(((DAYS(UPDATE_DATE) - DAYS(ENDDATE)) * 86400 +(MIDNIGHT_SECONDS(UPDATE_DATE) - MIDNIGHT_SECONDS(ENDDATE))),3600))/60),2,'0')  || ':' || " +
      "LPAD(MOD((MOD(((DAYS(UPDATE_DATE) - DAYS(ENDDATE)) * 86400 + (MIDNIGHT_SECONDS(UPDATE_DATE) - MIDNIGHT_SECONDS(ENDDATE))),3600)), 60),2,'0') AS DURATION, " +
      "USERNAME, ACTIONID1, ACTIONID2, STATUS, ERROR_CODE,  ERROR_PARAMS, TIME_STAMP, CLASS, CAST(NULL AS VARCHAR(1)) RELATION, " +
      "CASE WHEN XML_RELATED_FIELDS_DATA IS NOT NULL THEN 'Yes' ELSE 'No' END AS ZOOM_INDICATOR " +
      "FROM VR_NEWJOURNAL NEWJOURNAL " +
      "WHERE MID = ? AND PARTITION_ID = ? " +
      "ORDER BY TIME_STAMP DESC) " + 
      "ORDERED_PACKET %s) WHERE RNUM >= ?";
    
    // THIS IS THE 'SELECT_STATEMENT_NO_CHILDREN' PARALLEL C++ QUERY - 
    // RETURNS SAME RESULTS BUT IN DIFFRENT ORDER
    // SELECT * FROM ( SELECT ORDERED_PACKET.*, ROWNUM RNUM FROM ( SELECT IP_ADDRESS, HIT_INFO, MID,MODULE_ID,TO_CHAR(UPDATE_DATE, 'YYYY-MM-DD HH24:MI:SS') || NVL2(NEWJOURNAL.ZONE_CODE,' (' || NEWJOURNAL.ZONE_CODE || ')',  ' (EST)'),TO_CHAR(ENDDATE, 'YYYY-MM-DD HH24:MI:SS') || NVL2(NEWJOURNAL.ZONE_CODE, ' (' || NEWJOURNAL.ZONE_CODE || ')', ' (EST)'),TO_CHAR((TRUNC(SYSDATE) + (UPDATE_DATE - ENDDATE)),'HH24:MI:SS'),USERNAME, ACTIONID1, ACTIONID2, STATUS,ERROR_PARAMS, NEWJOURNAL.TIME_STAMP, CLASS, NULL RELATION FROM VR_NEWJOURNAL NEWJOURNAL WHERE MID ='0731416200601E00'  ORDER BY TIME_STAMP DESC) ORDERED_PACKET WHERE ROWNUM <= 100 )  WHERE RNUM >= 0
    
    // Defined for ORACLE - difference is in the DURATION/RELATION columns.
    String SELECT_STATEMENT_WITH_CHILDREN_ORACLE = 
      "SELECT * FROM (SELECT ORDERED_PACKET.*, " +
      DAOBasic.ROWNUM_VARIABLE + " RNUM " +
      "FROM (SELECT IP_ADDRESS, HIT_INFO, MID, MODULE_ID, " +  
      "TO_CHAR(UPDATE_DATE, 'YYYY-MM-DD HH24:MI:SS') || CASE WHEN ZONE_CODE IS NULL " + 
      "THEN '' ELSE ' (' || ZONE_CODE || ')' END AS UPDATE_DATE," +
      "TO_CHAR(ENDDATE, 'YYYY-MM-DD HH24:MI:SS') || CASE WHEN ZONE_CODE IS NULL " + 
      "THEN '' ELSE ' (' || ZONE_CODE || ')' END AS ENDDATE," +

      // 'DURATION' column.
		      " ( ( TO_NUMBER(SUBSTR( CAST( UPDATE_DATE AS TIMESTAMP) - CAST( ENDDATE AS TIMESTAMP) ,2,9) )*24 + " +
      "TO_NUMBER(SUBSTR(CAST( UPDATE_DATE AS TIMESTAMP) - CAST( ENDDATE AS TIMESTAMP) ,12,2)) ) " +
      "||SUBSTR(CAST( UPDATE_DATE AS TIMESTAMP) - CAST( ENDDATE AS TIMESTAMP) ,14,6) ) AS DURATION, " +
      
      "USERNAME, ACTIONID1, ACTIONID2, STATUS,  ERROR_PARAMS, TIME_STAMP, CLASS, CAST(NULL AS VARCHAR(1)) RELATION, " +
      "CASE WHEN XML_RELATED_FIELDS_DATA IS NOT NULL THEN 'Yes' ELSE 'No' END AS ZOOM_INDICATOR " +
      "FROM VR_NEWJOURNAL NEWJOURNAL " +
      "WHERE MID = ? AND PARTITION_ID = ? " +
      "UNION ALL " +
      "SELECT IP_ADDRESS, HIT_INFO, MID,MODULE_ID, " +
      "TO_CHAR(UPDATE_DATE, 'YYYY-MM-DD HH24:MI:SS') || NVL2(NEWJOURNAL.ZONE_CODE,' (' || NEWJOURNAL.ZONE_CODE || ')',  ' (EST)') AS UPDATE_DATE, " +
      "TO_CHAR(ENDDATE, 'YYYY-MM-DD HH24:MI:SS') || NVL2(NEWJOURNAL.ZONE_CODE, ' (' || NEWJOURNAL.ZONE_CODE || ')', ' (EST)') AS ENDDATE, " +
      
      // 'DURATION' column.
      "TO_CHAR((TRUNC(SYSDATE) + (UPDATE_DATE - ENDDATE)),'HH24:MI:SS') AS DURATION, " +
      
      "USERNAME, ACTIONID1, ACTIONID2, STATUS, ERROR_CODE, ERROR_PARAMS, NEWJOURNAL.TIME_STAMP, CLASS, " +
      "(SELECT DISTINCT RELATION FROM MFAMILY " + 
 	     "WHERE PARENTMID = ? AND CHILDMID = MID  AND PARTITION_ID = ? ) AS RELATION " +
      "'No' AS ZOOM_INDICATOR " +
      "FROM VR_NEWJOURNAL NEWJOURNAL, MFAMILY " + 
      "WHERE PARENTMID = ? AND RELATION <> 'REFILE' AND MID = CHILDMID  AND PARTITION_ID = ?" +  
      "ORDER BY TIME_STAMP DESC) " + 
      "ORDERED_PACKET %s) WHERE RNUM >= ?";
    
    // Defined for DB2 - difference is in the DURATION/RELATION columns.
    String SELECT_STATEMENT_WITH_CHILDREN_DB2 = 
      "SELECT * FROM (SELECT ORDERED_PACKET.*, " +
      DAOBasic.ROWNUM_VARIABLE + " RNUM " +
      "FROM (SELECT IP_ADDRESS, HIT_INFO, MID, MODULE_ID, " +  
      "CHAR(UPDATE_DATE) || CASE WHEN ZONE_CODE IS NULL " + 
      "THEN '' ELSE ' (' || ZONE_CODE || ')' END AS UPDATE_DATE," +
      "CHAR(ENDDATE) || CASE WHEN ZONE_CODE IS NULL " + 
      "THEN '' ELSE ' (' || ZONE_CODE || ')' END AS ENDDATE, " +

      // 'DURATION' column.
      "LPAD(FLOOR(((DAYS(UPDATE_DATE) - DAYS(ENDDATE)) * 86400 + (MIDNIGHT_SECONDS(UPDATE_DATE) - MIDNIGHT_SECONDS(ENDDATE)))/3600),2,'0') || ':' ||" +
      "LPAD(FLOOR((MOD(((DAYS(UPDATE_DATE) - DAYS(ENDDATE)) * 86400 +(MIDNIGHT_SECONDS(UPDATE_DATE) - MIDNIGHT_SECONDS(ENDDATE))),3600))/60),2,'0')  || ':' || " +
      "LPAD(MOD((MOD(((DAYS(UPDATE_DATE) - DAYS(ENDDATE)) * 86400 + (MIDNIGHT_SECONDS(UPDATE_DATE) - MIDNIGHT_SECONDS(ENDDATE))),3600)), 60),2,'0') AS DURATION, " +
      
      "USERNAME, ACTIONID1, ACTIONID2, STATUS,  ERROR_PARAMS, TIME_STAMP, CLASS, CAST(NULL AS VARCHAR(1)) AS RELATION, " +
      "CASE WHEN XML_RELATED_FIELDS_DATA IS NOT NULL THEN 'Yes' ELSE 'No' END AS ZOOM_INDICATOR " +
      "FROM VR_NEWJOURNAL NEWJOURNAL " +
      "WHERE MID = ? AND PARTITION_ID = ? " +
      "UNION ALL " +
      "SELECT IP_ADDRESS, HIT_INFO, MID,MODULE_ID, " +
      "CHAR(UPDATE_DATE) || NVL(NEWJOURNAL.ZONE_CODE,' (' || NEWJOURNAL.ZONE_CODE || ')',  ' (EST)') AS UPDATE_DATE, " +
      "CHAR(ENDDATE) || NVL(NEWJOURNAL.ZONE_CODE, ' (' || NEWJOURNAL.ZONE_CODE || ')', ' (EST)') AS ENDDATE, " +

      // 'DURATION' column.
      // TODO: Get DB2 version for the following Oracle part:
      // "TO_CHAR((TRUNC(SYSDATE) + (UPDATE_DATE - ENDDATE)),'HH24:MI:SS') AS DURATION, "
      "CAST(NULL AS VARCHAR(1)) AS DURATION, " +
      
      "USERNAME, ACTIONID1, ACTIONID2, STATUS,ERROR_PARAMS, NEWJOURNAL.TIME_STAMP, CLASS, " +
      "(SELECT DISTINCT RELATION FROM MFAMILY " + 
      "WHERE PARENTMID = ? AND CHILDMID = MID AND PARTITION_ID = ?) AS RELATION, " +
      "'No' AS ZOOM_INDICATOR " +
      "FROM VR_NEWJOURNAL NEWJOURNAL, MFAMILY " + 
      "WHERE PARENTMID = ? AND RELATION <> 'REFILE' AND MID = CHILDMID AND PARTITION_ID = ?" +  
      "ORDER BY TIME_STAMP DESC) " + 
      "ORDERED_PACKET %s) WHERE RNUM >= ?";
    
    StatementParameter spMID = new StatementParameter(sMID,Types.VARCHAR);
    StatementParameter spPartitionID = new StatementParameter(partitionID,Types.NUMERIC);
    
    StatementParameter[] arrParams;
    String sFinalSelectStatement;
    
    final String sHighEndRowNumPart =
           ms_DBType.getWhereClauseRownum(false,
                                          OperatorType.LTE,
                                          ServerConstants.EMPTY_STRING+iHighEndPageLimit);
    
    boolean bOracle = DAOBasic.ms_DBType == DBType.Oracle;
    
    if(bIncludeChildrenPart)
    {
      String sFinalStatementWithChildern = bOracle ?
                                           SELECT_STATEMENT_WITH_CHILDREN_ORACLE :
                                           SELECT_STATEMENT_WITH_CHILDREN_DB2;  
      sFinalSelectStatement = String.format(sFinalStatementWithChildern, sHighEndRowNumPart);
      
      arrParams = new StatementParameter[6];
      arrParams[0] = spMID;
      arrParams[1] = spPartitionID;
      arrParams[2] = spMID;
      arrParams[3] = spPartitionID;
      arrParams[4] = spMID;
      arrParams[5] = spPartitionID;
      arrParams[6] = new StatementParameter(Integer.valueOf(iLowerEndPageLimit).toString(),Types.NUMERIC);
    }
    
    else
    {
      String sFinalStatementWithNoChildern = bOracle ?
                                             SELECT_STATEMENT_WITH_NO_CHILDREN_ORACLE :
                                             SELECT_STATEMENT_WITH_NO_CHILDREN_DB2;  
      sFinalSelectStatement = String.format(sFinalStatementWithNoChildern, sHighEndRowNumPart);
      
      arrParams = new StatementParameter[3];
      arrParams[0] = spMID;
      arrParams[1] = spPartitionID;
      arrParams[2] = new StatementParameter(Integer.valueOf(iLowerEndPageLimit).toString(),Types.NUMERIC);
      
    }
    
    //return getData(conn, null, sFinalSelectStatement, arrParams, -1);
    return this.getErrorRelatedTableContent(conn, sFinalSelectStatement, true, arrParams) ; 

  }//EOM 
  
  private final DTODataHolder getErrorRelatedTableContent(final Connection conn, 
		  final String sStatement, final boolean bIsMultiRowError,
		  final StatementParameter...arrStatementParameters) { 
	  
	  final String ERROR_DESCRIPTION_COL_NAME = "DESCRIPTION" ;
	  final String ERROR_CODE_COL_NAME = "ERROR_CODE" ; 
	  final String ERROR_PARAMS_COL_NAME = "ERROR_PARAMS" ; 
	  
	  final DTODataHolder dto = new DTODataHolder() ; 
	    PreparedStatement ps = null ; 
	    ResultSet rs = null ; 
	    try{
	    	ps = conn.prepareStatement(sStatement) ; 	    	
	    	
	        logger.info(ServerUtils.getPreparedStatementFinalString(sStatement, arrStatementParameters)) ; 
	        
	        //populate the prepared statement 
	        this.populatePreparedStatement(ps, arrStatementParameters) ; 
	        
	        final PDO pdo = Admin.getContextPDO();
	        //if the pdo is empty, then the context is that of a queue floating window
	        //user the user offide 
	        final String sMessageOffice = ( pdo == null ? 
	        		Admin.getContextAdmin().getWebSessionInfo().getDefaultOffice() :
	        		pdo.getString(PDOConstantFieldsInterface.P_OFFICE) ) ; 
	        
	        //execute and poopulate 
	        rs = ps.executeQuery() ;
	      
	        final ResultSetMetaData rsmd = rs.getMetaData() ; 
	        
	        Object oValue = null ;
	        Map mapDataRow = null ; 
	        int iErrorCode = -1 ; 
	        String sErrorParamsString = null, sErrorDescription = null ; 
	        
	        final int iColNo = rsmd.getColumnCount() ;  
	        
	        while(rs.next()) { 
	        	
	        	mapDataRow = new HashMap(); 
	        	
	        	for(int i=0; i < iColNo; i++) { 
	        		 
	        		oValue = this.getColumnValue(i+1, rs, rsmd)  ;
	        		
	        		//set the value in the dto's map 
	        		mapDataRow.put(rsmd.getColumnName(i+1), oValue) ; 
	        		
	        	}//EO while there are more columns required  
	        	
	        	//retrieve the error code and error parameters and construct the error description 
	        	iErrorCode = rs.getInt(ERROR_CODE_COL_NAME) ; 
	        	
	        	// USERNAME includes value, only for action made by the user
	        	if (iErrorCode != ProcessErrorConstants.ButtonActionHasBeenExecuted && iErrorCode != ProcessErrorConstants.UserHasChangedFields && iErrorCode != ProcessErrorConstants.UserHasAddedNewNote)
	        	{
	        			mapDataRow.put(USERNAME, ServerConstants.EMPTY_STRING);
	        	}
	        	sErrorParamsString = rs.getString(ERROR_PARAMS_COL_NAME) ; 
	        	if(sErrorParamsString == null) sErrorParamsString = ServerConstants.EMPTY_STRING ; 
	        	
	        	sErrorDescription = ErrorAuditUtils.getInstance().loadErrorAuditText((long)iErrorCode, sErrorParamsString,  sMessageOffice,  null, (Object[]) null, bIsMultiRowError) ; 
	        		        	
	        	//put the error description in the data row 
	        	mapDataRow.put(ERROR_DESCRIPTION_COL_NAME, sErrorDescription) ; 
	        	
	        	//add the row to the dto
	        	dto.addDataRow(mapDataRow) ; 
	        }//EO while there are more records 
	      	    	
	    }catch(Exception e) { 
	    	ExceptionController.getInstance().handleException(e, this) ;  
	    	ErrorAuditUtils.onError(e, dto.getFeedBack()) ; 
	    }finally{ 
	    	releaseResources(rs, ps) ; 
	    }//EO catch block 
	             
	    return dto ;     
  }//EOM 
  
  /**
   * Returns data from the MSGERR table.
   * @param sMID the related message ID.
   * @param bGetHistoricalErrors true/false flag for what errors data to return.
   * @param sLastSubmitTimeStamp the last submit's time stamp;
   *                             not relevant when 'bGetHistoricalErrors = true'.  
   * @param iHighEndPageLimit page navigation variable marking the highend limit of the recordset to fetch.
   *                          not relevant when 'bGetHistoricalErrors = false'.
   * @param iLowerEndPageLimit page navigation variable marking the lowend limit of the recordset to fetch.
   *                          not relevant when 'bGetHistoricalErrors = false'.
   */
  public DTODataHolder getMSGERR_Data(Connection conn, String sMID, boolean bGetHistoricalErrors, 
                                      String sLastSubmitTimeStamp, 
                                      int iHighEndPageLimit, int iLowerEndPageLimit, Integer partitionID)
  {
//    String SELECT_STATEMENT_NON_HISTORICAL_ERRORS =
////      "SELECT TO_CHAR(CREATE_DATE,'YYYY-MM-DD HH24:MI:SS') || " +
//    	"SELECT TIME_STAMP || " +
//      "CASE WHEN ZONE_CODE IS NULL THEN '' ELSE ' (' || ZONE_CODE || ')' END CREATE_DATE, " +  
//      "ERROR_CODE, FAULT, FIELD_LOGICAL_ID, ERROR_PARAMS ,'Z' AS Z_TYPE FROM MSGERR " +
//      "WHERE MID = ? AND TIME_STAMP >= ' ' " +
//      "UNION " + 
////      "SELECT TO_CHAR(CREATE_DATE, 'YYYY-MM-DD HH24:MI:SS') || " +
//      "SELECT TIME_STAMP || " +
//      "CASE WHEN ZONE_CODE IS NULL THEN '' ELSE ' (' || ZONE_CODE || ')' END CREATE_DATE, " +  
//      "ERROR_CODE, FAULT, FIELD_LOGICAL_ID, ERROR_PARAMS ,'Z' AS Z_TYPE " +
//      "FROM MSGERR WHERE MID = ? " +  
//      "AND TIME_STAMP >= ? " +
//      "ORDER BY Z_TYPE DESC ,CREATE_DATE DESC";    
    
    String SELECT_STATEMENT_NON_HISTORICAL_ERRORS =
      "SELECT " +
      "CASE WHEN TIME_STAMP > ? THEN 'New' ELSE 'Historic' END NEW_OLD, " +
      "CREATE_DATE, ZONE_CODE, ERROR_CODE, FAULT, FIELD_LOGICAL_ID, ERROR_PARAMS " +
      "FROM MSGERR " +
      "WHERE MID = ? " +
      "AND PARTITION_ID = ? " +
      "ORDER BY TIME_STAMP DESC";        
    
    String SELECT_STATEMENT_HISTORICAL_ERRORS = 
      "SELECT * FROM(SELECT MSG_ERR_ORDERD.*, " +
      DAOBasic.ROWNUM_VARIABLE + " RNUM FROM( " +
      "SELECT TO_CHAR(CREATE_DATE, 'YYYY-MM-DD HH24:MI:SS') || " +
      "CASE WHEN ZONE_CODE IS NULL THEN '' ELSE ' (' || ZONE_CODE || ')' END CREATE_DATE, " +
      "ERROR_CODE, FAULT, ERROR_PARAMS, FIELD_LOGICAL_ID " +
      "FROM MSGERR WHERE MID = ? AND PARTITION_ID = ? ORDER BY TIME_STAMP DESC)MSG_ERR_ORDERD " +
      " %s ) WHERE RNUM >= ?";

    String sFinalSelectStatement = null;
    
    StatementParameter[] arrParams = null;
    
    StatementParameter spMID = new StatementParameter(sMID, Types.VARCHAR);
    StatementParameter spPartitionID = new StatementParameter(partitionID, Types.NUMERIC);
    
    // Historical errors.
    if(bGetHistoricalErrors)
    {
       final String sHighEndRowNumPart = ms_DBType.getWhereClauseRownum(false, OperatorType.LTE, 
                                                                        (ServerConstants.EMPTY_STRING + iHighEndPageLimit));
      
      sFinalSelectStatement = String.format(SELECT_STATEMENT_HISTORICAL_ERRORS, sHighEndRowNumPart) ;

      arrParams = new StatementParameter[3];
      arrParams[0] = spMID;
      arrParams[1] = new StatementParameter(Integer.valueOf(iLowerEndPageLimit).toString(),Types.NUMERIC);
      arrParams[2] = spPartitionID;
    }
    
    // Non-historical errors.
    else
    {
      sFinalSelectStatement = SELECT_STATEMENT_NON_HISTORICAL_ERRORS;
      
      arrParams = new StatementParameter[3];
      arrParams[0] = new StatementParameter(sLastSubmitTimeStamp, Types.CHAR);
      arrParams[1] = spMID;
      arrParams[2] = spPartitionID;
      
    }
       
    //TODO: deal with HISTORICAL ERRORS 
    //return bGetHistoricalErrors ? getData(conn, null, sFinalSelectStatement, arrParams, -1) :
                                //  getData(conn, sFinalSelectStatement, arrParams);
    
    return this.getErrorRelatedTableContent(conn, sFinalSelectStatement, false, arrParams) ;
    //return new DTODataHolder();
  }
  
  public DTODataHolder getMSG_SPECIAL_INST_Data(Connection conn, String sMID, Integer sPartitionID)
  {
    
    String SELECT_STATEMENT_NON_HISTORICAL_ERRORS =
      "SELECT " +
      "SI_STATUS, ERROR_CODE, ERROR_PARAMS, USER_ID, TIME_STAMP " +
      "FROM MSG_SPECIAL_INSTRUCTIONS " +
      "WHERE MID = ? AND SI_STATUS in (0,1) AND PARTITION_ID = ?" +
      "ORDER BY TIME_STAMP DESC";        
    
    String sFinalSelectStatement = null;
    
    StatementParameter[] arrParams = null;
    
    StatementParameter spMID = new StatementParameter(sMID,Types.VARCHAR);
    StatementParameter spPartitionID = new StatementParameter(sPartitionID,Types.INTEGER);
    
    sFinalSelectStatement = SELECT_STATEMENT_NON_HISTORICAL_ERRORS;
      
    arrParams = new StatementParameter[2];
    arrParams[0] = spMID;
    arrParams[1] = spPartitionID;
       
    return this.getErrorRelatedTableContent(conn, sFinalSelectStatement, false, arrParams) ;
  }
  
  
  
  public final DTODataHolder getBeforeAfterData(final Connection conn, final String sMID, int iIsHistoryValue) { 
	  final String sQUERY = "SELECT XML_ORIG_MSG  CONTENTS, 'IN' DIRECTION FROM MINF WHERE P_MID = ? AND P_IS_HISTORY = ?" + 
	  	"UNION ALL SELECT XML_MSG CONTENTS, 'OUT' DIRECTION FROM MINF WHERE P_MID = ? AND P_IS_HISTORY = ?" ; 
	  
	  //final StatementParameter midStatementParameter = new StatementParameter(sMID, Types.VARCHAR) ;
	  final StatementParameter[] arrStatementParameters = new StatementParameter[4];
	  arrStatementParameters[0] = new StatementParameter(sMID, Types.VARCHAR);
	  arrStatementParameters[1] = new StatementParameter(iIsHistoryValue, Types.INTEGER);
	  arrStatementParameters[2] = new StatementParameter(sMID, Types.VARCHAR);
	  arrStatementParameters[3] = new StatementParameter(iIsHistoryValue, Types.INTEGER);
	  
	  return this.getData(conn, sQUERY, arrStatementParameters) ;
	  /*final StatementParameter[] arrStatementParameters = { midStatementParameter, midStatementParameter} ; 
	  
	  return this.getData(conn, sQUERY, arrStatementParameters) ;*/  
  }
  
  /**
   * Returns data from the ADVICES table.
   * @param sMID the related message ID.
   */
  public DTODataHolder getADVICES_Data(Connection conn, String sMID)
  {
    String SELECT_STATEMENT = "SELECT DESCRIPT, STATUS, DR_CR_IND, CHILD_MID, " +
                              DAOBasic.ROWNUM_VARIABLE + " \"ROWID\" " +
                              " FROM ADVICES, ADVCTYPE " +
                              "WHERE MID  = ? AND WARNED = 0 AND ADVICES.ADVC_CODE = ADVCTYPE.ADVC_CODE";
    
    StatementParameter[] arrParams = new StatementParameter[1];
    arrParams[0] = new StatementParameter(sMID, Types.VARCHAR);
       
    return getData(conn, SELECT_STATEMENT, arrParams);
  }
  
  public final DTODataHolder getHVMessageLinks(final Connection conn, final String sSourceMID, final String internalFileId, final String uniqueGroupingId
          , final String batchPaymentType, String outInternalFileId, String outGroupingId, String duplicateIndex, String msgSts, Integer partitionID) { 
	  	
	final CacheKeys.LocicalFieldsXpathColumnDefinitionsKey columnsCacheRegion = CacheKeys.LocicalFieldsXpathColumnDefinitionsKey ; 
  
  	String STATEMENT = "SELECT MFAMILY.RELATED_TYPE, MFAMILY.RELATED_MID, " +
                       "MINF.P_MSG_TYPE, MINF.P_MSG_SUB_TYPE, MINF.P_MSG_STS, " +
                       columnsCacheRegion.getColumnDefinition(PDOConstantFieldsInterface.X_INSTR_ID, false/*bIsInWhereClause*/, null/*sOccurrenceIndex*/) + "," + 
                       columnsCacheRegion.getColumnDefinition(PDOConstantFieldsInterface.X_END_TO_END_ID , false/*bIsInWhereClause*/, null/*sOccurrenceIndex*/) +
	                 " FROM MFAMILY INNER JOIN MINF " + 
	                 "ON MFAMILY.RELATED_MID = MINF.P_MID " +
	                 "WHERE MFAMILY.P_MID = ? AND PARTITION_ID = ?" ;
	  
	  return this.getData(conn, STATEMENT, new StatementParameter(sSourceMID,Types.VARCHAR), new StatementParameter(partitionID,Types.NUMERIC)) ;
  }//EOM 
  
  public final PreparedStatement getDupexLinks(final Connection conn, PDO pdo, final String ruleUid ) throws Throwable 
  { 
      
      Prules prule = CacheKeys.PRulesUIDKey.getSingle(ruleUid);
      
      DAOPRules daoPrules = new DAOPRules();
      
      final CacheKeys.LocicalFieldsXpathColumnDefinitionsKey columnsCacheRegion = CacheKeys.LocicalFieldsXpathColumnDefinitionsKey ;
      final String STATEMENT = "SELECT P_MID, P_MSG_TYPE, P_MSG_SUB_TYPE, P_MSG_STS, " +
		columnsCacheRegion.getColumnDefinition(PDOConstantFieldsInterface.OX_END_TO_END_ID, false/*bIsInWhereClause*/, null/*sOccurrenceIndex*/) + "," +
		columnsCacheRegion.getColumnDefinition(PDOConstantFieldsInterface.X_END_TO_END_ID, false/*bIsInWhereClause*/, null/*sOccurrenceIndex*/) +
      " FROM MINF "+
      " WHERE ("+prule.getExecWhere() +") AND (P_MID <> '"+pdo.getMID()+"') AND P_IS_HISTORY IN (0,1)"; 
      logger.debug("Dupex SQL Statment: [{}]", STATEMENT);
      
     
          
      return daoPrules.getRuleExeuctionPreparedStatement(STATEMENT,prule.getBindWhereBindingParameters(),pdo,false,conn, prule.getRuleTypeId(),prule.getRuleName());
  }  
  
  /**
   * Returns the check dual control value for the passed button ID.
   */
  public DTOSingleValue getCheckDualControlForButtonID(String sButtonID)
  {
    final String SELECT_STATEMENT = "SELECT CHECK_DUAL_CONTROL FROM MESSAGEBUTTONS WHERE BUTTONID = ?";

    StatementParameter[] arrParams = new StatementParameter[1];
    arrParams[0] = new StatementParameter(sButtonID,Types.VARCHAR);
       
    return getSingleValue(SELECT_STATEMENT, arrParams, null);
  }
  
  /**
   * Returns data from the MSG_RULE_LOG table.
   * @param sMID the related message ID.
   */
  public DTODataHolder getMSG_RULE_LOG_Data(Connection conn, String sMID, Integer iPartitionID)
  {
    
     String SELECT_STATEMENT = "SELECT MRL.MID, "+
         " MRL.TIME_STAMP, "+
         " MRL.ZONE_CODE, "+
         " MRL.FLOW_ID, "+
         " MRL.DESCRIPTION "+
         " FROM MSG_RULE_LOG MRL "+
         " WHERE MID = ? "+
         " AND PARTITION_ID = ? "+
         " ORDER BY TIME_STAMP ";
    

    final StatementParameter[] arrParams = { new StatementParameter(sMID, Types.VARCHAR) , new StatementParameter(iPartitionID, Types.NUMERIC)} ; 
       
    return getData(conn, SELECT_STATEMENT, arrParams);
  }//EOM 
  

  /**
   * Returns rule IDs data for the MSG_RULE_LOG table.
   * @param sRuleIDs comma delimited rule IDs.
   */
  public DTODataHolder getRuleIDsDataForMSG_RULE_LOG_Table(Connection conn, String sRuleIDs)
  {
    String SELECT_STATEMENT = "SELECT DISTINCT P.RULE_TYPE_ID, T.RULE_TYPE_NAME, P.RULE_ACTION, P.UID_PRULES, " +
                              "P.RULE_NAME, P.DESCRIPTION, ' ' AS TIME_STAMP, ' ' AS ZONE_CODE " +
                              "FROM PRULES P INNER JOIN PRULE_TYPES T ON P.RULE_TYPE_ID = T.RULE_TYPE_ID " +
                              "WHERE P.UID_PRULES IN %s " +
                              "ORDER BY P.UID_PRULES";  

    String sSelectStatament = String.format(SELECT_STATEMENT, sRuleIDs);
    
    return getData(conn, sSelectStatament);
  }
  
  public final DTODataHolder getDualConfirmationStatuses() { 
	  final String STATEMENT = "SELECT MSG_STATUS  FROM STATUSES_CONTEXT WHERE CONTEXT_TYPE LIKE 'DUAL_CONFIRMATION%'" ;
	  return this.getData(STATEMENT, -1) ; 
  }//EOM 
  
  /**
   * 
   */
  public DTODataHolder getVerificationFields(Connection conn, String sFieldVerificationProfileName, String sOffice)
  {
    final String SELECT_STATEMENT = "select FIELD_LOGICAL_ID, REKEY_VERIFICATION from FIELD_VERIFICATION_FIELDS where FV_NAME = ? AND OFFICE = ?";
    
    StatementParameter[] arrParams = new StatementParameter[2];
    arrParams[0] = new StatementParameter(sFieldVerificationProfileName, Types.VARCHAR);
    arrParams[1] = new StatementParameter(sOffice, Types.CHAR);

    return getData(conn, SELECT_STATEMENT, arrParams);
  }
  
  /**
   * retrieves the template's unchanged fields in order to load them to template/message created from template
   * @param conn - Connection
   * @param sMID - the template's MID
   * @return DTODataHolder - contains relevant unchanged fields for the input MID
   */
  public DTODataHolder getUnchangedFields (Connection conn, String sMID, Integer iPartitionID)
  {
	  final String SELECT_STATEMENT = "SELECT UNCHANGED_FIELDS FROM TEMPLATE_UNCHANGED_FIELDS T WHERE MID = ? AND PARTITION_ID = ?";
	  
	  StatementParameter[] arrParams = new StatementParameter[2];
      arrParams[0] = new StatementParameter(sMID, Types.VARCHAR);
      arrParams[1] = new StatementParameter(iPartitionID, Types.NUMERIC);
	  
	  return getData(conn, SELECT_STATEMENT, arrParams);	  
  }
  
   public DTODataHolder getAcknowledgements_Data(Connection conn, String sMID)
   {
        StringBuilder sb = new StringBuilder();
	    sb.append("SELECT ");
	    sb.append(DAOBasic.ms_DBType.getXmlDao().constructPaymentXmlColumnCase("X_TX_STS",false,null,XmlLocationType.INTERFACE_CONTENT));
	    sb.append(",");
	    sb.append(DAOBasic.ms_DBType.getXmlDao().constructPaymentXmlColumnCase("X_STS_RSN_PRTRY",false,null,XmlLocationType.INTERFACE_CONTENT));
	    sb.append(",");
	//    sb.append(DAOBasic.ms_DBType.getXmlDao().constructPaymentXmlColumnCase("X_RTR_RSN_ADDTL_INF",false,null,XmlLocationType.INTERFACE_CONTENT));
	//    sb.append(",");
	    sb.append(DAOBasic.ms_DBType.getXmlDao().constructPaymentXmlColumnCase("X_CLR_SYS_REF",false,null,XmlLocationType.INTERFACE_CONTENT));
	    sb.append(",");
	    sb.append(DAOBasic.ms_DBType.getXmlDao().constructPaymentXmlColumnCase("X_STS_ID",false,null,XmlLocationType.INTERFACE_CONTENT));
	    sb.append(",");
	    sb.append(DAOBasic.ms_DBType.getXmlDao().constructPaymentXmlColumnCase("X_ACCT_SVCR_REF",false,null,XmlLocationType.INTERFACE_CONTENT));
	    sb.append(" FROM MESSAGE_EXTERNAL_INTERACTION");
	    sb.append("	WHERE MESSAGE_EXTERNAL_INTERACTION.INTERFACE_NAME IN ('CLEARING_ACK','Acknowledgment')");
	    sb.append("	AND MESSAGE_EXTERNAL_INTERACTION.MID = ? ORDER BY TIME_STAMP DESC");
	
	    final StatementParameter[] arrParams = { new StatementParameter(sMID, Types.VARCHAR) } ; 
	    return getData(conn, sb.toString(), arrParams);
   
  }//EOM 
}
