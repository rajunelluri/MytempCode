package backend.core.module.messageload.ejb;

import javax.ejb.Stateless;
import backend.core.SuperSLSB;
import com.fundtech.core.security.Admin;
import backend.businessobject.proxies.interceptors.InterceptorSetType;
import backend.core.module.messageload.businessobjects.BOMessageLoad;
import backend.core.module.messageload.ejbinterfaces.MessageLoadLocal;
import backend.core.module.messageload.ejbinterfaces.MessageLoad;

@Stateless
public class MessageLoadBean extends SuperSLSB<MessageLoad> implements MessageLoadLocal, MessageLoad{
	
	public MessageLoadBean() { super(backend.core.module.messageload.businessobjects.BOMessageLoad.class, InterceptorSetType.Complete) ; }//EOM
	
	
	/** 
	 * Performs locked message release for one or two messages. Returns boolean[] with success/failure notifications.
	 */
	public com.fundtech.datacomponent.response.Feedback releaseLockedMessage(final Admin admin, com.fundtech.datacomponent.request.CloseMessageInputData closeMessageInputData ) {
		return this.m_bo.releaseLockedMessage(admin, closeMessageInputData ) ;
	}//EOM

	public com.fundtech.datacomponent.response.GlobalResponseDataComponentText loadMessageScreenObject(final Admin admin, com.fundtech.datacomponent.request.LoadMessageInputData loadMessageInputData ) {
		return this.m_bo.loadMessageScreenObject(admin, loadMessageInputData ) ;
	}//EOM

	/** 
	 */
	public com.fundtech.datacomponent.response.Feedback loadMessage(final Admin admin, java.lang.String sMID, java.io.Serializable oAdditionalInput ) {
		return this.m_bo.loadMessage(admin, sMID, oAdditionalInput ) ;
	}//EOM

	/** 
	 */
	public com.fundtech.core.paymentprocess.data.PDO newMessage(final Admin admin, java.io.Serializable oInput ) {
		return this.m_bo.newMessage(admin, oInput ) ;
	}//EOM

}//EOC