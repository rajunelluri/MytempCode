package backend.core.module.messageload.businessobjects;

import static backend.businessobject.BOProxies.m_generateTransactionLogging;
import static backend.businessobject.BOProxies.m_internalRuleExecutionLogging;
import static backend.businessobject.BOProxies.m_matchingCheckLogging;
import static com.fundtech.cache.infrastructure.regions.CacheKeys.SystParKey;
import static com.fundtech.util.GlobalConstants.EMPTY_STRING;
import static com.fundtech.util.GlobalUtils.isNullOrEmpty;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

import org.apache.xmlbeans.XmlOptions;
import org.apache.xmlbeans.impl.values.XmlObjectBase;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.businessobject.BOProxies;
import backend.businessobject.proxies.AuthorizeUser;
import backend.businessobject.proxies.Input;
import backend.businessobject.proxies.SkipInputValidation;
import backend.core.module.MessageConstantsInterface;
import backend.core.module.message.businessobjects.BOMessage;
import backend.core.module.messageload.dataaccess.DAOMessageLoad;
import backend.core.module.security.businessobjects.UserEntitlementData;
import backend.dataaccess.dto.DTODataHolder;
import backend.mapping.config.AppServerConfigKeysInterface;
import backend.paymentprocess.erroraudit.ErrorAuditUtils;
import backend.paymentprocess.layout.MessageLayoutCache;
import backend.paymentprocess.loadpostinginfo.common.PostingRequestType;
import backend.paymentprocess.loadpostinginfo.output.LoadPostingInfoOutputData;
import backend.paymentprocess.matchingcheck.output.MatchingCheckOutputData;
import backend.services.cache.ASCacheFactory;
import backend.services.cache.entitlements.EntitlementsDataFactory;
import backend.util.ServerConstants;
import backend.util.ServerUtils;

import com.fundtech.annotations.DataSource;
import com.fundtech.annotations.Expose;
import com.fundtech.annotations.Expose.ExposureType;
import com.fundtech.annotations.Wrap;
import com.fundtech.cache.entities.LogicalFields;
import com.fundtech.cache.entities.MsgTypes;
import com.fundtech.cache.entities.Msgerr;
import com.fundtech.cache.entities.PruleTypes;
import com.fundtech.cache.entities.Prules;
import com.fundtech.cache.entities.RuleResult;
import com.fundtech.cache.entities.Statuses;
import com.fundtech.cache.entities.WebSessionInfo;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.cache.syspar.SystemParametersInterface;
import com.fundtech.core.general.PluginFactory;
import com.fundtech.core.message.MessageCloseConstantsInterface;
import com.fundtech.core.message.MessageLayoutCacheInterface;
import com.fundtech.core.message.MessageLoadConstantsInterface;
import com.fundtech.core.paymentprocess.PDOPermissionType;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PDOConstantFieldsInterface;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.core.paymentprocess.data.das.DASInterface;
import com.fundtech.core.paymentprocess.data.fields.DataType;
import com.fundtech.core.paymentprocess.data.fields.FieldType;
import com.fundtech.core.paymentprocess.errorhandling.ProcessError;
import com.fundtech.core.paymentprocess.events.EventType;
import com.fundtech.core.paymentprocess.events.EventUncheckedException;
import com.fundtech.core.paymentprocess.events.ServerEvents;
import com.fundtech.core.security.Admin;
import com.fundtech.core.security.Admin.CallSource;
import com.fundtech.datacomponent.request.CloseMessageInputData;
import com.fundtech.datacomponent.request.LoadMessageInputData;
import com.fundtech.datacomponent.request.LoadMessageInputData.PaymentRequestMetadata;
import com.fundtech.datacomponent.request.RequestKeys;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.datacomponent.response.GlobalResponseDataComponentText;
import com.fundtech.datacomponent.response.SimpleResponseDataComponent;
import com.fundtech.datacomponent.response.UserResponse;
import com.fundtech.datacomponent.response.layout.MessageButton;
import com.fundtech.datacomponent.response.layout.MessageLayout;
import com.fundtech.datacomponent.response.layout.MessageScreenObject;
import com.fundtech.datacomponent.response.layout.ProfileScreenObject;
import com.fundtech.datacomponent.response.layout.ScreenObject;
import com.fundtech.datacomponent.response.message.HitInformation;
import com.fundtech.errors.ProcessErrorConstants;
import com.fundtech.util.ExceptionController;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalUtils;


/**
 * Title: BOMessageLoad Description: Business object for encapsulating all message load actions Company: Fundtech Israel Author: Asaf Levy Date:
 * 19/11/06
 * 
 * @version 1.0
 */
@Wrap(datasources = { @DataSource(datasourceJndiKey = "active") })

public class BOMessageLoad extends BOMessage implements MessageConstantsInterface, MessageLoadConstantsInterface, PDOConstantFieldsInterface
{

	private final static Logger logger = LoggerFactory.getLogger(BOMessageLoad.class);
	private static DAOMessageLoad m_daoMessageLoad;
	private static DASInterface m_das = PluginFactory.get(DASInterface.class);
	private static List<String> afterTagDisplayBulkList = Arrays.asList(new String[]{MessageConstantsInterface.MESSAGE_STATUS_COMPLETE,MessageConstantsInterface.MESSAGE_STATUS_RETURNED});
	private static List<String> INTERMEDIATE_STATUSES = Arrays.asList(new String[]{ MESSAGE_STATUS_REPAIR ,MESSAGE_STATUS_PAYSET});

	//private static BOQueues.Context autoFeederQueryBuildlingContext;

	public static final String DEFAULT_LAST_SUBMIT_TIME_STAMP = "2999-12-31 24:00:00.999";

	// Traces
	private static final String GENERIC_ERROR_MESSAGE = "Server error while trying to perform this action.";
	private static final String USER_HAS_NO_PEREMISSION_TO_PERFORM_ACTION = "You don't have permission to perform this action.";
	private static final String TRACE_BOOLEAN_METHOD_RESULT = "Result: ";

	// Error constants.
	private static final int ERROR_MSG_LOCKED_ASK_USER = 97;
	private static final int ERROR_LOCK_MSG_FAILED = 98;
	private static final int ERROR_AUTO_FEEDER_NO_MORE_MESSAGES = 99;

	private static final String USER_ERROR_MESSAGE = "ERROR: empty MID was received - lock message failure !!!";

	// application return code
	// autofeeder_todo: might need to remove this
	private static final int RET_CODE_NO_MORE_MID_FOR_AUTO_FEEDER = 2;

	private static final String QUEUE_NAME_TARNS_SEARCH_FOR_SP_LOCK_MSG_BY_MID = "TRANSRCH";
	private static final ScreenObject m_screenObject;

	// Static initializer.
	static
	{
		m_daoMessageLoad = new DAOMessageLoad();
		
		m_screenObject = new ProfileScreenObject();
		//initAutofeederCachedResources();
	}// EO static block

	/**
	 * Constructor.
	 */
	public BOMessageLoad()
	{
		super();
	}

	/**
	 * Returns a list of load message loads.
	 */
	private final List<String> getLoadMessageStepList(final List<LoadMessageStep> arrLoadMessageStep)
	{
		List<String> listLoadMessageStep = new ArrayList<String>();

		if (arrLoadMessageStep != null)
		{
			for (int i = 0; i < arrLoadMessageStep.size(); i++)
			{
				listLoadMessageStep.add(arrLoadMessageStep.get(i).name());
			}
		}

		return listLoadMessageStep;
	}// EOM

	/**
	 * Returns Active/History Connection object.
	 */
	private final Feedback getConnection(final boolean bHistoryMessage, final Connection[] arrConnection)
	{

		Feedback feedback = new Feedback();

		try
		{
			arrConnection[0] = m_daoMessageLoad.getConnection(AppServerConfigKeysInterface.DATA_SOURCE_ID_ACTIVE);
		}
		catch (SQLException sqle)
		{
			ExceptionController.getInstance().handleException(sqle, this);
			feedback = new Feedback();
			feedback.setFailure();
			feedback.setErrorCode(28560);
			feedback.setException(sqle);
		}

		return feedback;
	}// EOM

	/**
	 * Traces the user's default office and related system parameters.
	 */
	private final String traceOfficeAndRelatedSystemParams(final WebSessionInfo webSessionInfo, final HashMap hmOfficeRelatedSysPars)
	{
		

		final String USER_DEFAULT_OFFICE = "BOMessageLoad - user's default office is: ";
		final String RELATED_SYS_PARS = " .Related system parameters: ";

		final String MAXRECINPY_DEFAULT_VALUE = "100";

		String sDefaultOffice = webSessionInfo.getDefaultOffice();

		// MAXRECINPY.
		String sMAXRECINPY_Value = SystParKey.getSingle(sDefaultOffice, SystemParametersInterface.SYS_PAR_MAXRECINPY).getParmValue();

		sMAXRECINPY_Value = !ServerUtils.isNullOrEmpty(sMAXRECINPY_Value) ? sMAXRECINPY_Value : MAXRECINPY_DEFAULT_VALUE;
		hmOfficeRelatedSysPars.put(SystemParametersInterface.SYS_PAR_MAXRECINPY, sMAXRECINPY_Value);

		// M_SCND_OPN.
		final String sM_SCND_OPN_Value = SystParKey.getSingle(sDefaultOffice, SystemParametersInterface.SYS_PAR_M_SCND_OPN).getParmValue();

		hmOfficeRelatedSysPars.put(SystemParametersInterface.SYS_PAR_M_SCND_OPN, sM_SCND_OPN_Value);

		// WEBUSERLIV.
		final String sWEBUSERLIV_Value = SystParKey.getSingle(sDefaultOffice, SystemParametersInterface.SYS_PAR_WEBUSERLIV).getParmValue();

		hmOfficeRelatedSysPars.put(SystemParametersInterface.SYS_PAR_WEBUSERLIV, Integer.valueOf(sWEBUSERLIV_Value));

		StringBuilder sb = new StringBuilder(USER_DEFAULT_OFFICE).append(sDefaultOffice).append(RELATED_SYS_PARS).append(
				GlobalUtils.printMap(hmOfficeRelatedSysPars, ServerConstants.SEMI_COLON));
		
		logger.trace(sb.toString());

		

		return sDefaultOffice;
	}// EOM

	/**
	 * Traces the load message steps.
	 */
	private final void traceLoadMessageSteps(final List<String> listLoadMessageStep)
	{
		

		final String TRACE_PREFIX = "BOMessageLoad - load message steps are: ";

		StringBuilder sb = new StringBuilder(TRACE_PREFIX);

		int iSize = listLoadMessageStep.size();

		for (int i = 0; i < iSize; i++)
		{
			sb.append(listLoadMessageStep.get(i)).append(ServerConstants.COMMA).append(ServerConstants.SPACE);
		}

		sb.deleteCharAt(sb.length() - 2);
		logger.trace(sb.toString());

		
	}// EOM
	
	/**
	 * Removes the MIDs from the web ssession info's mids list and synchronizes the session copy in the distributed<br>
	 * cache
	 * <P><B>Pre-Condition</B></P> WebSessionInfo instance should already be injected into the context admin   
	 */
	private final Feedback releaseLocks(String...arrMIDs) {
		

		final WebSessionInfo webSessionInfo = Admin.getContextAdmin().getWebSessionInfo() ; 
				
		for(String sMID : arrMIDs) { 
			webSessionInfo.removeMid(sMID);
		}//EO while there are more MIDs to remove 
		
		CacheKeys.WebSessionInfoKey.putSingle(webSessionInfo);

		
		return new Feedback() ; 
	}//EOM 
	
	public static Feedback releaseLockedMessage(boolean isReadOnly, boolean shouldPerformAuditTrail,String...arrMIDs)
	{
		Feedback feedback = new Feedback();
		try{
			String sMID = arrMIDs[0];
			
			PDO pdo = PaymentDataFactory.load(sMID); 
			
			Object oFieldsWereNotModified = pdo.getTransient(D_FIELDS_WERE_NOT_MODIFIED);
			boolean bFieldsWereNotModified = oFieldsWereNotModified != null ? ((Boolean)oFieldsWereNotModified).booleanValue() : pdo.fieldsWereNotModified(true/*bIgnoreAutomatedModifications*/) ;
			
			logger.info("MID: {}, bFieldsWereNotModified: {}", sMID, bFieldsWereNotModified);

			if (!isReadOnly && !pdo.isNew())
			{
				// Adds audit for no action by the user prior to closing the message (done on intermediate payment status Repair and PAYSET (Defect #66642)).
				String status = pdo.getStatus();

				if (shouldPerformAuditTrail && INTERMEDIATE_STATUSES.contains(status))
				{
					// Clears all PDO data for the future "THIN" save process; the only thing to save for
					// this message is a new error to be entered into NEWJOURNAL table.
					pdo.setThinMode(true);
					
					// Error code 113: 'User has exit message without performing any action'.
					ProcessError processError = new ProcessError(ProcessErrorConstants.UserHasExitMessageWithoutPerformingAnyAction);
					ErrorAuditUtils.setErrors(processError, pdo);
					
					m_das.batchSave(false, pdo); 
					// removed as the isGlobal would cause the message not to be propegated to the distributed cache
					// which would leave the message locked by the current user.
					// as this code was added to solve another issue, it is left here as a remainder
					// ensure that PDO is not propogated into distributed cache.!!!!
					// pdo.setIsGlobalPDO(false);
					pdo.setThinMode(true);
				}//if the perform audit trail flag was set to true 
				
				// If no fields modifications were done to this PDO then sets the PDO to thin mode, so the PDO won't be copied to the distributed cache.
				else if(bFieldsWereNotModified)
				{
					pdo.setThinMode(true);
				}
			}//EO if the message was not in readonly mode 

		}catch (Throwable t){
			//the method shall trace the exception and configure the feedback 
			handleError(t, feedback) ;
		}//EO no user modifications catch block 
				
		//Step 2: Release the actual locks from the pdos corresponding to the mids in arrMIDs by removing them 
		//from the local container, and propegating them into the distributed one (if they are not readonly, new or non-global) 
		//whereby they would be updated and their respective locks would be removed.
		//Note: The only current scenario where more than one message MID should be present in the array is an abort autofeeder
		//scherio whereby a max of two MIDs would be present: the first, the current opened and the second the next one loaded in the 
		//background. Each MID would have a corresponding PDO and a message screenObject 		
		logger.debug("Step 2: Releasing the locks on the PDOs and messageScreenObjects corresponding to the following MIDS {} as well as removing them from " +
				"the local container", Arrays.toString(arrMIDs)) ; 
		
		try{
			// Removes the message screen object from the cache.
			for (int i = 0; i < arrMIDs.length; i++){
				
				if (isNullOrEmpty(arrMIDs[i])) continue ; 
					
					CacheKeys.UserMessageKey.removeSingle(arrMIDs[i]);
				 
					PDO primaryPDO = null ; 
					
					try{ 
						// remove the pdo and its linked associations from the local cache and if the pdo is not in thin or read mode (failed save or
						// read only permission) propegate to the distributed
						// one (the check would be conducted in the miss handler
						primaryPDO = CacheKeys.ProcessPDOKey.getSingle(arrMIDs[i]);
						CacheKeys.ProcessPDOKey.removeFromLocalAndPropagateToRemote(primaryPDO.addLinkedMsgsToList(null));
					}catch(Throwable t) {
						ExceptionController.trace(t, null) ;
						//ensure that all pdos are removed from distributed and local cache as their state is invalid
						PaymentDataFactory.performFailureCompensation(primaryPDO.addLinkedMsgsToList(null).toArray(new PDO[]{}));
					}//EO catch block 
					
			}//EO while there messages to release 
		}catch (Throwable t){
			//the method shall trace the exception and configure the feedback 
			handleError(t, feedback) ;
		}//EO catech block 
		
		
		return feedback;

	}
	
	/**
	 * Performs locked message release for one or two messages. Returns boolean[] with success/failure notifications.
	 */
	@Expose
	@AuthorizeUser(returnWebSessionInfo = true)
	public final Feedback releaseLockedMessage(final CloseMessageInputData closeMessageInputData){
		
		final WebSessionInfo webSessionInfo = Admin.getContextAdmin().getWebSessionInfo();
		Feedback feedback = new Feedback();

		final String[] arrMIDs = closeMessageInputData.getMIDsArray();
				
		logger.debug("Step 1: if the message is not in readonly mode or new and the user had not performed any modifications \r\n" + 
				"(the closeMessageInputData.performAuditTrail flag would be set to true, persist an audit trail record to indicate this") ; 
		releaseLockedMessage(closeMessageInputData.isMessageReadOnly(), closeMessageInputData.performAuditTrail(),arrMIDs);
		return feedback ;
	}//EOM 

	// /////////////////////////////
	// /// LOAD MESSAGE AS JSP /////
	// /////////////////////////////

	@Expose
	@AuthorizeUser(returnWebSessionInfo = true)
	public GlobalResponseDataComponentText loadMessageScreenObject(LoadMessageInputData loadMessageInputData)
	{
		//final BackendTracer logger = GlobalTracer;

		// In case of success, the response type will be changed to MessageScreenObject.
		GlobalResponseDataComponentText response = new UserResponse();
		MessageScreenObject messageScreenObject = null;

		final Connection[] arrConnection = new Connection[1];
		Connection conn = null;
		Feedback feedback = null;
		PDO pdo = null;

		try{
			
			// The 'getRequestType' method returns LoadMessageStep[], which can
			// hold more than one request step.
			final List<String> listLoadMessageStep = this.getLoadMessageStepList(loadMessageInputData.getLoadMessageStep());
			
			//attempt to rerieve the current MID using either the getMID() or by extracting it from the getPaymentRequestsList IFF the size is 1
			String sMID = loadMessageInputData.getMID() ; 
			if(GlobalUtils.isNullOrEmpty(loadMessageInputData.getMID()) && !listLoadMessageStep.contains(LoadMessageStep.STEP_LOAD_GENERATED_MESSAGE.name())) { 
				
				final List<PaymentRequestMetadata> listPayments = loadMessageInputData.getPaymentRequestsList() ; 
				if(!loadMessageInputData.isBackgroundLoad() && listPayments != null && listPayments.size() == 1) sMID = listPayments.get(0).getMID() ;  
			}//EOM 
						
			// 2. if exists, check permissions
			// 3. perform previous message (both for reg and feeder) lock releaseea.
			// 4. only load the read only tables which are in the message layout cache
			// for the screen_fragement key
			// 5.deal with other message steps
			// 6. process get message screenset object error feedback for all scenarios
			// 7. do not store in cache for all other steps

			feedback = this.getConnection(loadMessageInputData.isHistoryMessage(), arrConnection);
			conn = arrConnection[0];

			// if the connection retrieval had failed, abort
			if (!feedback.isSuccessful())
			{
				response.setFeedback(feedback);
				return response;
			}// EO if the connection initialation had failed
			// else

			final WebSessionInfo webSessionInfo = Admin.getContextAdmin().getWebSessionInfo();
			String sDefaultOffice = null;
			HashMap hmOfficeRelatedSysPars = new HashMap();

			// Traces user default office and related system parameters.
			sDefaultOffice = this.traceOfficeAndRelatedSystemParams(webSessionInfo, hmOfficeRelatedSysPars);
			final String sMAXRECINPY_Value = (String) hmOfficeRelatedSysPars.get(SystemParametersInterface.SYS_PAR_MAXRECINPY);

			// Traces the load message steps.
			this.traceLoadMessageSteps(listLoadMessageStep);

			final boolean bFullLoad = (listLoadMessageStep.contains(LoadMessageStep.STEP_CREATE_CUSTOMER_MESSAGE.name())
					|| listLoadMessageStep.contains(LoadMessageStep.STEP_CREATE_CUSTOMER_MESSAGE_CT_PAYMENT.name())
					|| listLoadMessageStep.contains(LoadMessageStep.STEP_CREATE_CUSTOMER_MESSAGE_CT_TEMPLATE.name())
					|| listLoadMessageStep.contains(LoadMessageStep.STEP_CREATE_CUSTOMER_MESSAGE_DD_PAYMENT.name())
					|| listLoadMessageStep.contains(LoadMessageStep.STEP_CREATE_CUSTOMER_MESSAGE_DD_TEMPLATE.name())
					|| listLoadMessageStep.contains(LoadMessageStep.STEP_CREATE_BANK_MESSAGE.name())
					|| listLoadMessageStep.contains(LoadMessageStep.STEP_CREATE_AF_MESSAGE.name())
					|| listLoadMessageStep.contains(LoadMessageStep.STEP_CREATE_CUSTOMER_MESSAGE_TEMPLATE.name())
					|| listLoadMessageStep.contains(LoadMessageStep.STEP_CREATE_BANK_MESSAGE_TEMPLATE.name())
					|| listLoadMessageStep.contains(LoadMessageStep.STEP_CREATE_MT300_MESSAGE.name())
					|| listLoadMessageStep.contains(LoadMessageStep.STEP_LOAD_MESSAGE_AS_JSP.name())
					|| listLoadMessageStep.contains(LoadMessageStep.STEP_RELOAD_MESSAGE_AS_JSP.name())
					|| listLoadMessageStep.contains(LoadMessageStep.STEP_LOAD_MESSAGE.name())
					|| listLoadMessageStep.contains(LoadMessageStep.STEP_LOAD_GENERATED_MESSAGE.name())
					|| listLoadMessageStep.contains(LoadMessageStep.STEP_LOAD_MESSAGE_ALL_AUTO_FEEDER.name()) || 
					listLoadMessageStep.contains(LoadMessageStep.STEP_MESSAGE_FRAGMENT.name()));

			loadMessageInputData.put("FULL_LOAD_FLAG", (bFullLoad ? true : null)) ; 
			
			//  attempt to retrieve from cache the message screenobjet stored against
			// the user session id and the MID if the mid exists and the context is not that of full load 
			final String NEW_PAYMENT_INDICATOR = "-1" ; 
			if(!GlobalUtils.isNullOrEmpty(sMID) && !sMID.equals(NEW_PAYMENT_INDICATOR) && 
					(!bFullLoad || (bFullLoad && listLoadMessageStep.contains(LoadMessageStep.STEP_MESSAGE_FRAGMENT.name())) ) ) 
				
				messageScreenObject = CacheKeys.UserMessageKey.getSingle(sMID);
			   
			// if the message screenobject was already initialise for the given user
			// authorise the current request and merge the request input
			if (messageScreenObject != null)
			{

				pdo = messageScreenObject.getData();

				feedback = this.checkUserPermission(pdo, null, new boolean[] { false }, feedback);

				if (!feedback.isSuccessful())
				{
					response.setFeedback(feedback);
					return response;
				}// EO if the connection initialation had failed
				// else

				// merge the input data with the current pdo
				this.mergeModifiedFieldsWithPdo(pdo, loadMessageInputData.getMesasgeFieldsInputData());
				try
				{
					// if the context is that of complete load invoke the onload and server derivation events otherwise, invoke
					// the onlazyload

					m_EventBus.fireEvent(loadMessageInputData.getScreenSetID(), loadMessageInputData, new String[] { loadMessageInputData
							.getFragmentID() }, ServerEvents.onLazyLoad);
				}
				catch (EventUncheckedException t)
				{
					configureErrorFeedback(1, t.getMessage(), feedback);
				}// EOM
				
				//MSG_TODO: Guys : 2/9/2009 --> I cannot think of a currently present scenario in which the release 
				//should be performed from the context of a load as each load must first close the message screen tab 
				//which would sent a release request any way. Nevertheless, I leave this code commented here 
				//so that it would act as a remainder that such scenario did exist in the past and might again 
				// if there was a previous MID from either an auto feeder or a multi selection flow
				/* 
				if (!GlobalUtils.isNullOrEmpty(loadMessageInputData.getPreviousMID()))
				{
					feedback = this.releaseLockedMessage(pdo.getMID(), webSessionInfo, this.getWebUserAliveFor_SP_LOCK_MSG_BY_MID(sDefaultOffice),
							loadMessageInputData.getQueueName());

					if (!feedback.isSuccessful())
					{
						response.setFeedback(feedback);
						return response;
					}// EO if the previous message release prcedure had failed
				}// EO if there was a previous mid
				*/ 
				
			}// EO if the messageScreenObjectWas already loaded and cached 
			
			// Full message data load process.
			if (messageScreenObject == null && bFullLoad)
			{
				
				messageScreenObject = this.getMessageScreenObject(conn, webSessionInfo, hmOfficeRelatedSysPars, listLoadMessageStep,
						loadMessageInputData);
				// CR#86401 & CR#86330->Added code to check whether user has permission for message or not
				feedback = messageScreenObject.getFeedback();
				
				if (!feedback.isSuccessful())
				{
					response.setFeedback(feedback);
					return response;
				}

				BOProxies.m_feeCalculationLogging.setDerivedFeeAmountLogicalFields(Admin.getContextAdmin());
			}
			else if (!bFullLoad)
			{
				// CR#90064->Needs to load the MessageScreenObject again if it is null
				/*if (messageScreenObject == null)
				{
					messageScreenObject = this.getMessageScreenObject(conn, webSessionInfo, hmOfficeRelatedSysPars, listLoadMessageStep,
							loadMessageInputData);
					pdo = messageScreenObject.getData();
				}
				else
				{
					// CR#90064->if messageScreenObject already found then just load the readonly tables
					feedback = this.initialiseReadOnlyTables(conn, sMAXRECINPY_Value, pdo.getString(P_LAST_SUBMIT_TS), loadMessageInputData,
							messageScreenObject);
				}*/
			  
			    
			     //if the message screenobgject was not already cached (which could only occur in a scenario 
			    //whereby a payment was already opened when the floating table open request was issued for the 
			    //very same payment) create a mock object for the floating table load  
			     final boolean bMsgScreenObjectAlreadyCached = (messageScreenObject != null) ;  
  			     try { 
    			     if(!bMsgScreenObjectAlreadyCached) { 
        			     messageScreenObject = new MessageScreenObject();
        			     pdo = PaymentDataFactory.load(sMID, null, PDOPermissionType.NoLock) ;        			       
        			     messageScreenObject.initialise(sMID, null, pdo, true, null, false) ;         			      
    			     }//EO if the message screen object was already cached 
			     
    			     /*
    			      final List<PaymentRequestMetadata> listPayments = loadMessageInputData.getPaymentRequestsList() ;
    			     // check the following user permissions:
                      // status/department/message type (button permission is irellevant and hence the null)
                      //the permission check is performed here as if the user was not authorized for the given 
                      //load operation, there is no need to load & lock the message 
                      feedback = this.checkUserPermission(
                              paymentRequestMetadata.getMsgType(), 
                              paymentRequestMetadata.getMsgSubType(), 
                              paymentRequestMetadata.getMsgStatus(), 
                              paymentRequestMetadata.getDepartment(), 
                              null   , arrReadOnlyMsgFlagHolder, feedback);
                              
                      if (!feedback.isSuccessful()) {
                            messageScreenObject.setFeedback(feedback);
                            return messageScreenObject;
                        }// EO if the user permission checks have failed
                     */
			     			     
    			     feedback = this.initialiseReadOnlyTables(conn, sMAXRECINPY_Value, pdo.getString(P_LAST_SUBMIT_TS), loadMessageInputData,
                                messageScreenObject, EnumSet.of(loadMessageInputData.getLoadMessageStep().get(0)));
    			     
    
    				if (!feedback.isSuccessful())
    				{
    					response.setFeedback(feedback);
    					return response;
    				}// EO if the other table's data population had failed
  			     }finally { 
  			       try { 
  			           if(!bMsgScreenObjectAlreadyCached) PaymentDataFactory.releasePDO(pdo) ;
  			       }catch(Throwable t) { 
  			           handleError(t, messageScreenObject.getFeedback()) ; 
  			       }//EO inner block
  			     }//EO catch block 

			}// EO else if only a read only table was required

			// verify the load process succeess
			feedback = messageScreenObject.getFeedback();

			if (!feedback.isSuccessful())
			{
				logger.error(feedback.getErrorText());
				response.setFeedback(feedback);
				return response;
			}// EO else if the load operation had failed
			// else

			// assign the message screenobject to the response reference
			response = messageScreenObject;

		}
		catch (Exception e)
		{
			ExceptionController.getInstance().handleException(e, this);
			ErrorAuditUtils.onError(e, feedback);
			response.setFeedback(feedback);
		}
		finally
		{
			m_daoMessageLoad.releaseResources(conn);
		}// EO catch block

		return response;
	}// EOM

	/**
   * 
   */
	/**
	 *
	 */
	private final MessageScreenObject getMessageScreenObject(final Connection conn, final WebSessionInfo webSessionInfo,
			final HashMap hmOfficeRelatedSysPars, final List<String> listLoadMessageStep, final LoadMessageInputData loadMessageInputData)
	{

		//final BackendTracer logger = GlobalTracer;
		
		logger.trace(loadMessageInputData.toString());

		final MessageScreenObject messageScreenObject = new MessageScreenObject();
		Feedback feedback = messageScreenObject.getFeedback();
		PDO pdo = null;
		
		final boolean[] arrReadOnlyMsgFlagHolder = new boolean[1];
		 
		final boolean bLoadFragmentMode = listLoadMessageStep.contains(LoadMessageStep.STEP_MESSAGE_FRAGMENT.name());
		
		String sMID = loadMessageInputData.getMID();
		final List<PaymentRequestMetadata> listPaymentRequestMetadata = loadMessageInputData.getPaymentRequestsList() ; 

		try{
			
			//handle the pdo load/creation 
			//if the load is in the context of message creation, create a new pdo and ommit the authorization 
			if (listLoadMessageStep.contains(LoadMessageStep.STEP_CREATE_CUSTOMER_MESSAGE.name())
					    || listLoadMessageStep.contains(LoadMessageStep.STEP_CREATE_CUSTOMER_MESSAGE_CT_PAYMENT.name())
					    || listLoadMessageStep.contains(LoadMessageStep.STEP_CREATE_CUSTOMER_MESSAGE_CT_TEMPLATE.name())
					    || listLoadMessageStep.contains(LoadMessageStep.STEP_CREATE_CUSTOMER_MESSAGE_DD_PAYMENT.name())
					    || listLoadMessageStep.contains(LoadMessageStep.STEP_CREATE_CUSTOMER_MESSAGE_DD_TEMPLATE.name())
						|| listLoadMessageStep.contains(LoadMessageStep.STEP_CREATE_BANK_MESSAGE.name())
						|| listLoadMessageStep.contains(LoadMessageStep.STEP_CREATE_AF_MESSAGE.name())
						|| listLoadMessageStep.contains(LoadMessageStep.STEP_CREATE_CUSTOMER_MESSAGE_TEMPLATE.name())
						|| listLoadMessageStep.contains(LoadMessageStep.STEP_CREATE_BANK_MESSAGE_TEMPLATE.name())
						|| listLoadMessageStep.contains(LoadMessageStep.STEP_CREATE_MT300_MESSAGE.name())){
	
					pdo = PaymentDataFactory.newPDO(listLoadMessageStep);
					pdo.set(PDOConstantFieldsInterface.P_PMNT_SRC, GlobalConstants.CREATE);
					//assign the MID - the sMID variable for future use 
					sMID = pdo.getMID(); 
					
					// Sets default debit MOP.
					pdo.set(P_DBT_MOP, MOP_BOOK);
					// Sets default displayed message type; currently the one of 'Pacs_008'.
					MsgTypes msgTypes = CacheKeys.msgTypesKey.getSingle(pdo.get(PDOConstantFieldsInterface.P_MSG_TYPE).toString(), ServerConstants.EMPTY_STRING);
					String sDisplayMsgType = msgTypes.getDisplayMsgType();
					pdo.set(P_DISPLAY_MSG_TYPE, !isNullOrEmpty(sDisplayMsgType) ? sDisplayMsgType : msgTypes.getMsgType());
					// set the default department into the pdo
					pdo.set(P_DEPARTMENT, listPaymentRequestMetadata.get(0).getDepartment());
					// set the user's office into the pdo
					pdo.set(P_OFFICE, loadMessageInputData.getOffice());
	
					// set the mid in the loadMessageInputData so that the rest of the flow will behave normally
					loadMessageInputData.put(LoadMessageInputData.KEY_MESSAGE_ID, pdo.getMID());
	
					if (listLoadMessageStep.contains(LoadMessageStep.STEP_CREATE_CUSTOMER_MESSAGE_CT_TEMPLATE.name()) ||
						listLoadMessageStep.contains(LoadMessageStep.STEP_CREATE_CUSTOMER_MESSAGE_DD_TEMPLATE.name()) ||
						listLoadMessageStep.contains(LoadMessageStep.STEP_CREATE_CUSTOMER_MESSAGE_TEMPLATE.name()) || 
						listLoadMessageStep.contains(LoadMessageStep.STEP_CREATE_BANK_MESSAGE_TEMPLATE.name())	)
					{
						pdo.set(P_IS_HISTORY, 2);
						pdo.set(P_TEMPLATE_TYPE,loadMessageInputData.getTemplateType());
					}
					
					// Sets default Credit MOP for the DD outgoing payment
					if (listLoadMessageStep.contains(LoadMessageStep.STEP_CREATE_CUSTOMER_MESSAGE_DD_PAYMENT.name()))
					{
						pdo.set(P_DBT_MOP, GlobalConstants.EMPTY_STRING);
						pdo.set(P_CDT_MOP, MOP_BOOK);
					}
					
			}else if(listLoadMessageStep.contains(LoadMessageStep.STEP_LOAD_MESSAGE_ALL_AUTO_FEEDER.name())) { 
				
				//iterate over the mid list and retrieve the next lockable pdo
				
				if(listPaymentRequestMetadata == null || listPaymentRequestMetadata.size() == 0) { 
					logger.error("One or more MIDs must be available for selection in Autofeeder mode yet there were none");
				}//EO if there were no mids for selection 
				//else 
				for(PaymentRequestMetadata paymentRequestMetadata : listPaymentRequestMetadata) { 
					
					//first attempt to ahuthorize the user against the given payment metadata and if not authorized, 
					//continue to the next payment 
					// check the following user permissions:
					// status/department/message type (button permission is irellevant and hence the null)
					//the permission check is performed here as if the user was not authorized for the given 
					//load operation, there is no need to load & lock the message 
					sMID = paymentRequestMetadata.getMID();
					feedback = m_permissionHandler.checkUserPermission(paymentRequestMetadata.getMsgType(), 
							paymentRequestMetadata.getMsgSubType(), 
							paymentRequestMetadata.getMsgStatus(), 
							paymentRequestMetadata.getDepartment(), 
							null /*sActionID*/ , arrReadOnlyMsgFlagHolder, sMID, feedback);
					
					if (!feedback.isSuccessful())
					{
						releaseLockedMessage(false,false,sMID);
						continue ; 
					}
					//else 
					
					//attempt to load the payment and if the payment was already locked contiune
					pdo = PaymentDataFactory.load(sMID); 
					
					//check that the request status is still the same as the pdo's one to accomodate the scenario 
					//whereby another user had already processed the payment and its status had changed 					
					if(!pdo.get(P_MSG_STS).equals(paymentRequestMetadata.getMsgStatus()) || 
						this.handleGuiOrientedLocking(messageScreenObject, pdo, loadMessageInputData, webSessionInfo, arrReadOnlyMsgFlagHolder) ) { 
						//assign the MID - the sMID variable for future use 
						sMID = pdo.getMID(); 
						
						break ;  
					}//EO if the message was locked successfully 
					else { 
						//remove the pdo from local cache 
						CacheKeys.ProcessPDOKey.removeFromLocalAndPropagateToRemote(pdo);
					}//EO else if the pdo was already locked 
					
				}//EO while there are more payment RequestMetadata instances 
				
				//if the pdo is in in readonly mode or null, abort load 
				if(pdo == null || pdo.isReadOnly()) {
					final StringBuilder builder = new StringBuilder("AutoFeeder was not able to load any of the following payments:\n\n") ; 
					
					for(PaymentRequestMetadata paymentMetadata : listPaymentRequestMetadata) { 
						builder.append(paymentMetadata).append("\n") ;
					}//EO while there are more payments 
					
					final String sErrorMsg = builder.toString() ;
					handleError(-1, sErrorMsg, null, messageScreenObject.getFeedback()) ; 
					return messageScreenObject ; 
				}//EO if the no payment could be loaded & locked
				//else set the D_AUTOFEEDER_MODE transient in the pdo so as to initialize the hidden input 
				else pdo.setTransient(D_AUTOFEEDER_MODE , "1") ;
				
			//}else if(loadMessageInputData.get("FULL_LOAD_FLAG") != null) {   		
			}else { 
						
				//several load scenarios exist currnetly: 
				//1. load generated message, in which the message would be created using the m_generateTransaction service delegate 
				//2. template load 
				//3. standard load 
				
				if (listLoadMessageStep.contains(LoadMessageStep.STEP_LOAD_GENERATED_MESSAGE.name()))
				{
					String sOrigButtonID = loadMessageInputData.getTriggeredMessageButtonID();
					if(!isNullOrEmpty(sOrigButtonID))
					{
						pdo = PaymentDataFactory.load(sMID);
						pdo.set(D_BUTTON_ID, sOrigButtonID);
					}
					
					SimpleResponseDataComponent response = m_generateTransactionLogging.generateRelatedTransaction(Admin.getContextAdmin(),
							loadMessageInputData.getMID(), loadMessageInputData.getTriggeredMsg(), loadMessageInputData.getGeneratedMsg());
					
	
					if (response != null && response.getFeedback().isSuccessful() && response.getDataArray() != null
							&& response.getDataArray().length == 1)
					{
						pdo = PaymentDataFactory.load((String) response.getDataArray()[0]);
						//assign the MID - the sMID variable for future use 
						sMID = pdo.getMID(); 
						
	                MsgTypes msgTypes = CacheKeys.msgTypesKey.getSingle(pdo.getString(P_MSG_TYPE), ServerConstants.EMPTY_STRING);
	                String sDisplayMsgType = msgTypes.getDisplayMsgType();
	                pdo.set(P_DISPLAY_MSG_TYPE, !isNullOrEmpty(sDisplayMsgType) ? sDisplayMsgType : msgTypes.getMsgType());
						
						loadMessageInputData.put(KEY_MESSAGE_ID, pdo.getMID());
					}
				
				}else{
					
					//rertieve the first payment request metadata instance 
					final PaymentRequestMetadata paymentRequestMetadata = listPaymentRequestMetadata.get(0) ; 
					
					// check the following user permissions:
					// status/department/message type (button permission is irellevant and hence the null)
					//the permission check is performed here as if the user was not authorized for the given 
					//load operation, there is no need to load & lock the message 
					feedback = m_permissionHandler.checkUserPermission(
							paymentRequestMetadata.getMsgType(), 
							paymentRequestMetadata.getMsgSubType(), 
							paymentRequestMetadata.getMsgStatus(), 
							paymentRequestMetadata.getDepartment(), 
							null /*sActionID*/ , arrReadOnlyMsgFlagHolder, sMID, feedback);

					// if the permissions checks have failed, abort
					if (!feedback.isSuccessful()) {
						releaseLockedMessage(false,false,sMID);
						messageScreenObject.setFeedback(feedback);
						return messageScreenObject;
					}// EO if the user permission checks have failed
	
					sMID = loadMessageInputData.getMID() ; 
					
					//load the pdo 
					if(loadMessageInputData.isTemplateLoad()) { 
						
						//create an extension and put the new message status in it 
						pdo = PaymentDataFactory.clonePDO(sMID, null,RECEIVED_STATUS_EXTENSION_MERGE_DOCUMENT) ; 
						
						//the flow should continue with the newly created MID						
						sMID = pdo.getMID(); 
						
						//if the message status is not TEMPLATE, then there is an error 
						//Yoni S. (12/1/2010) - removed this check since in new template imp. status is not TEMPLATE
						/*if(!pdo.getString(D_ORIG_CLONED_MSG_STS).equals("TEMPLATE")) { 
							
							//NYI --> write this to error log as well 
							ErrorAuditUtils.onError(ProcessErrorConstants.invalidTemplatePDO, messageScreenObject.getFeedback(), sMID);
							return messageScreenObject;
						}*///EO if the message was not a valid template 
						
						// Moran: Added for BOC POC
						pdo.set(PDOConstantFieldsInterface.P_MSG_STS, MessageConstantsInterface.MESSAGE_STATUS_RECEIVED);
						
						
						//else insert a new journal message indicating that the pdo was created from a template 
						// journal message code 40129: 'Payment was created from Template Message : |1'
						final ProcessError processError = new ProcessError(ProcessErrorConstants.ClonedFromTemplateMsg, sMID);
					    ErrorAuditUtils.setErrors(processError,pdo.getIsHistory());
												
					}else{
						pdo = PaymentDataFactory.load(sMID) ;
						MsgTypes msgTypes = CacheKeys.msgTypesKey.getSingle(pdo.getString(P_MSG_TYPE), ServerConstants.EMPTY_STRING);
		                String sDisplayMsgType = msgTypes.getDisplayMsgType();
		                pdo.set(P_DISPLAY_MSG_TYPE, !isNullOrEmpty(sDisplayMsgType) ? sDisplayMsgType : msgTypes.getMsgType());
						
					} 
					
				}// EO if a load was required
				
				//lock handling for both STEP_LOAD_GENERATED_MESSAGE and STANDARD NORNAL LOAD scenarios: 
				
				//invoke the message locking configuration method which would determine whether the pdo was already locked by another entity.   
				//If so, it would configure an error which would be displayed using the userNotices mechanism and. in this scenario the load 
				//flow should continue to its normal termination and not aborted here as the message should be displayed in readonly mode to the user 
				//if the message was not locked by any other entity, the method should update the context websessioninfo with the pdo's MID 
				//and sync it with the distributed container 
				this.handleGuiOrientedLocking(messageScreenObject, pdo, loadMessageInputData, webSessionInfo, arrReadOnlyMsgFlagHolder) ;
				
			}//EO else if the message should have been loaded rather than created 			 
		 
		}catch (Throwable e){
			handleError(e, feedback) ; 
			return messageScreenObject;
		}// EO catch block

		// merge all modified fields and tables into the pdo
		this.mergeModifiedFieldsWithPdo(pdo, loadMessageInputData.getMesasgeFieldsInputData());

		final String sUserDefOffice = webSessionInfo.getDefaultOffice();
		final String sUserEntitlementName = webSessionInfo.getUEntName();

		// create the message layout
		final MessageLayout messageLayout = this.getMessageLayout(sMID, pdo, webSessionInfo.getUEntName(), arrReadOnlyMsgFlagHolder[0],
				(bLoadFragmentMode ? loadMessageInputData.getScreenSetID() : null));

		// if there was no error abort
		if (messageLayout == null)
		{
			final String ERROR_MESSAGE = "No layout was found !!!";
			configureErrorFeedback(1, ERROR_MESSAGE, messageScreenObject.getFeedback());
			return messageScreenObject;
		}// EO if there was no message layout
		// else

		final UserEntitlementData userEntitlementData = EntitlementsDataFactory.getInstance().getUserEntitlementData(sUserEntitlementName);

		// Gets a string of access levels & W/R permissions in the following structure:
		// 'ACCESS_LEVEL@PERMISSION,ACCESS_LEVEL@PERMISSION, ACCESS_LEVEL@PERMISSION...,ACCESS_LEVEL@PERMISSION'.
		// e.g. '40016@W,40017@R,40021@W,40024@W'.
		final String sUserButtonsAccessLevels = userEntitlementData.getPERM_PROF_BUTTONS();

		messageScreenObject.initialise(sMID, messageLayout, pdo, arrReadOnlyMsgFlagHolder[0], sUserButtonsAccessLevels, loadMessageInputData.isBackgroundLoad());

		this.assignStatusFlags(messageScreenObject);

		if (messageScreenObject.isVERIFYMessage())
		{
			this.setVerificationFieldsMap(conn, messageScreenObject.getMID(), messageScreenObject.getData().getString(P_OFFICE),
							messageScreenObject);
		}// EO if the message was in verify status
		if(messageScreenObject.isREPAIRMessage()) 
		{	
			String sTemplateType = pdo.getString(P_TEMPLATE_TYPE);
			//decide whether to take MID (for loading template) or Template MID (for loading message from template)
			String sID  = (messageScreenObject.isMessageFromTemplate())? 
									messageScreenObject.getData().getString(P_TEMPLATE_MID):
									//When create message from template take message mid and not template mid
									//24/11/2010messageScreenObject.getMID():
									(
										(sTemplateType != null && (sTemplateType.equals("P")))? 
												messageScreenObject.getMID():
												null
									);
			if (sID != null)
			{
				this.setTemplateUnchangedFields(conn,sID,messageScreenObject, pdo.getIsHistory());
			}
		}// EO if the message was in REPAIR status

		messageScreenObject.setUserNotices(this.getUserNotices(messageScreenObject));

		// set the fragement id if the getScreenSetID is true
		if (bLoadFragmentMode)
			messageScreenObject.putScreenObjectAdditionalData(RequestKeys.FRAGMENT_ID_KEY, loadMessageInputData.getFragmentID());

		// set the message layout in the loadmessage input data so that
		// it would be available to the scripts
		loadMessageInputData.put(LoadMessageInputData.MESAGE_LAYOUT_KEY, messageLayout);

		// invoke the onload event
		try
		{
			// if the context is that of complete load invoke the onload and server derivation events otherwise, invoke
			// the onlazyload
			String[] arrFieldIds = null;
			EventType[] arrEvents = null;

			if (bLoadFragmentMode)
			{
				arrFieldIds = new String[] { loadMessageInputData.getFragmentID() };
				arrEvents = new EventType[] { ServerEvents.onLazyLoad };
			}
			else
			{
				arrFieldIds = null;
				arrEvents = new EventType[] { ServerEvents.onServerload, ServerEvents.onServerDerivations };
			}// EO eles if the context was that of full load

			m_EventBus.fireEvent(messageLayout.getScreenSetID(), loadMessageInputData, arrFieldIds, arrEvents);
		}
		catch (EventUncheckedException t)
		{
			configureErrorFeedback(1, t.getMessage(), feedback);
		}// EOM

		// Updates to the MessageScreenObject for formatting issues.
		final ASCacheFactory asCacheFactory = ASCacheFactory.getInstance();
		final Object[] arrFormattingValues = asCacheFactory.getFormattingValues(sUserDefOffice);
		messageScreenObject.setDateTimeFormatsArray((SimpleDateFormat[]) arrFormattingValues[0]);
		messageScreenObject.setDecimalAndThousandSeparatorsArray((char[]) arrFormattingValues[1]);
		messageScreenObject.setUserOffice(sUserDefOffice);

		if (!pdo.isNew())
		{
		  // retrieve the grid list for the given fragment
        final MessageLayoutCache layoutCache = (MessageLayoutCache) CacheKeys.MiscResoucesKey.getSingle(MessageLayoutCacheInterface.class);
        final EnumSet<LoadMessageStep> enumSetFragmentGrids = layoutCache.getFragmentGrids(loadMessageInputData.getFragmentID());
        
		// populate all read only tables included in the current screenset
		feedback = this.initialiseReadOnlyTables(conn, (String) hmOfficeRelatedSysPars.get(SystemParametersInterface.SYS_PAR_MAXRECINPY), pdo
					.getString(P_LAST_SUBMIT_TS), loadMessageInputData, messageScreenObject, enumSetFragmentGrids);
		}

		// Failure during message load process.
		if (!feedback.isSuccessful()){

			//release the pdo lock and remove the message screenobject from local cache
			final CloseMessageInputData closeMessageInputData = new CloseMessageInputData() ; 
			
			messageScreenObject.setFeedback(feedback);
			
			closeMessageInputData.put(MessageCloseConstantsInterface.KEY_MIDS_ARRAY, new String[] { sMID } ) ; 
			Feedback releaseMsgFeedback = this.releaseLockedMessage(closeMessageInputData) ; 
			
			if(!releaseMsgFeedback.isSuccessful()) logger.error(feedback.getErrorText()); 
			 
			return messageScreenObject;

		}// EO if there was a failure
		//else 
		
		// if the message request did not contain the isTransientMsg flag 
		// indicating that the message should not be cached and a subsquent remove operation 
		//shall be be issued (e.g print) 
		//set the screen object in the cache for reuse until user closes the message
		if(!loadMessageInputData.isTransientMsg()) CacheKeys.UserMessageKey.addMessage(messageScreenObject);

		

		return messageScreenObject;
	}// EOM
		

	/**
	 * 
	 * Sep 3, 2009
	 * Guys
	 *
	 * @param messageScreenObject
	 * @param pdo
	 * @param loadMessageInputData
	 * @param webSessionInfo
	 * @param arrReadOnlyMsgFlagHolder
	 * @return true if the message was successfully locked and false if otherwise
	 */
	private final boolean handleGuiOrientedLocking(final MessageScreenObject messageScreenObject, PDO pdo, final LoadMessageInputData loadMessageInputData, 
			final WebSessionInfo webSessionInfo, final boolean[] arrReadOnlyMsgFlagHolder)
	{
		
		boolean bSuccessfulLockOperation = false ; 		
		// if the pdo's context id is not the same as the requestor's one,
		// and the pdo is in readonly mode, then the message was already locked
		// by another user, and the requestor did not have sufficient permissions to
		// force unlock.
		final Admin admin = Admin.getContextAdmin();		
		// if the pdo is null, then the message was not in the database not cache - thus abort
		if (pdo == null)
		{
			ErrorAuditUtils.onError(ProcessErrorConstants.PDONoMinfRecord, messageScreenObject.getFeedback(), loadMessageInputData.getMID());
			return false ; 
		}// EO if there was no pdo
		//else 
		
		//if the pdo's owner is not the the requestor, determine whether the current owner is still active 
		//by retriving the current owner's websession info instance
		//if the owner is not active, assume that the current owner was a GUI user whose browser had crashed 
		//prior to logging off properly. this also means that the user's permission would have to be promoted to force override 
		//so that on save this pdo's copy would override the global one which might still be locked by the inactive user  
		WebSessionInfo websessionInfo = null ; 		
		boolean bSameOwner = ( pdo.getOwnerContextId().equals(admin.getSessionID()) )  ; 
		final boolean bSystemCallSource = (pdo.getOwnerCallSource() != CallSource.Gui)  ;
		
        if(bSystemCallSource) 
        {	//if call source is Service - the lock validation is not relevant.
        	logger.debug("service call source skipped lock validation for mid {}",pdo.getMID());
            return true;
        }
		
		if(!bSameOwner)
		{ 			
			websessionInfo = CacheKeys.WebSessionInfoKey.getSingle(pdo.getOwnerContextId()) ;// Get the web session info.
			//if a session exists or the call source was no GUI determine whether the current user permission 
			//allows force and if so, propose the option 
			if(websessionInfo != null) 
			{ 
				// if the permission was not sufficient, return a message already locked exception
				final String userID = (bSystemCallSource ? pdo.getOwnerCallSource().name() : CacheKeys.WebSessionInfoKey.getSingle(pdo.getOwnerContextId()).getUserID()) ;
				Msgerr msgerr = new Msgerr();
				msgerr.setErrorCode((long) ProcessErrorConstants.MessageAlreadyLocked);
				msgerr.setFieldLogicalId(EMPTY_STRING);
				msgerr.setErrorParams("@@" + userID + "@@STRING");
				pdo.addMsgerror(msgerr);
				arrReadOnlyMsgFlagHolder[0] = true;
				pdo.setTransient("D_NOTICE_TITLE", "Message Locked");
				//ensure that the pdo is in readonly mode so that it would not be propegated to the distributed container on release oepration
				pdo.setReadonly() ; 				
			}//EO if the user was in fact active 
			else 
			{ 
				bSameOwner = true ; 
				//replace the owner and promote the permission to override so that this pdo copy would override the global one on save  
				pdo.setOwnerContextId(admin.getSessionID(), PDOPermissionType.GUIForce, admin .getCallSource()) ; 
			}//EO else if not the same owner by current one is inactive 
		}//EO if not the same owner 
		
		//if the pdo's owner is the requestor, perform a lock on the pdo and add the lock to the requetor's websession info
		if(bSameOwner) 
		{ 			
			//add the mid to the list of locked messages stored in the websessin info instance 
			//and sync it with the distributed container
			admin.getNSetWebSessionInfo().addMid(pdo.getMID());
			CacheKeys.WebSessionInfoKey.putSingle(webSessionInfo);			
			logger.debug("Message {} was successfully locked by user {}", pdo.getMID(),webSessionInfo.getUserID());  			
			bSuccessfulLockOperation = true ; 
		}//EO same owner scenario		
		return bSuccessfulLockOperation ; 
	}//EOM 

	/**
   * 
   */
	private final List<LogicalFields> getUserNotices(final MessageScreenObject mso)
	{

		// Step 1: construct the questions from the P_USER_STATE_MONITOR monitor
		// where by the 'P' value stands for a pending question
		final String WARNING_LOGICAL_FIELD_ID_RPEFIX = "WARNING_";

		final List<LogicalFields> listNotices = new LinkedList<LogicalFields>();

		final PDO pdo = mso.getData();

		// first attmept to retrive the value of the orignal user state monitor from the mso
		// if the field's value exist, then use it to construct the notice board list (currently used in rekey verification)
		// D_OP_USER_STATE_MONITOR
		String sStateMonitor = mso.getOrignalUserStateMonitor();
		if (sStateMonitor == null)
			sStateMonitor = mso.getData().getString(P_USER_STATE_MONITOR);

		if (sStateMonitor != null)
		{

			final char[] arrMonitor = sStateMonitor.toCharArray();

			final int iLength = arrMonitor.length;

			for (int i = 0; i < iLength; i++)
			{
				// retrieve the logical field
				//defect# 40110: for "release posting" functionality - the P value is used, but it means Posting and not Pending
				//we skip here the monitor MU_MAN_1ST_PSTNG_RSPNS and MU_MAN_2ND_PSTNG_RSPNS which is expected to be at 27th place in the P_USER_STATE_MONITOR string 
				if (arrMonitor[i] == PENDING_STATUS_FLAG && i != 27 && i != 28){
					listNotices.add(CacheKeys.MonitorFieldsKey.getSingle(P_USER_STATE_MONITOR, i));
				}
			}// EO While there are more monitor flags

		}// EO if there was a monitor

		// Step 2: construct transient errors which reside in the msg errors pdo list member
		// as watnings.
		// Each error shall take the form of a new logical field initialised with the bare nessecities values
		final List<Msgerr> listMsgErrors = pdo.getListMSGERR();

		if (listMsgErrors != null)
		{

			LogicalFields noticeField = null;
			long lErrorCode = -1;

			for (Msgerr msgErrInst : listMsgErrors)
			{
				if (msgErrInst.isTransient())
				{

					lErrorCode = msgErrInst.getErrorCode();
					noticeField = new LogicalFields(WARNING_LOGICAL_FIELD_ID_RPEFIX + lErrorCode, DataType.STRING, FieldType.DERIVED);
					noticeField.setJournalMsgCode((int)lErrorCode);
					// generate the error description and set in the logical field
					noticeField.setJournalMsgDescription(ErrorAuditUtils.getInstance().loadErrorAuditText(msgErrInst.getErrorCode(),
							msgErrInst.getErrorParams(), pdo.getString(P_OFFICE), null, null, false));

					// add the warning instance to the listNotices
					listNotices.add(noticeField);
				}// EO if the msg was tranisent
			}// EO while there are more message errors
		}// EO if there were warnings

		return listNotices;
	}// EOM

	/**
	 * Returns the message layout for the passed PDO, while executing the following 3 system rules: 1) Message screen set selection rule. 2) Message
	 * fields setting selection rule. 3) Message buttons setting selection rule. Note that the returned MessageLayout's buttons include only buttons
	 * that the user has permissions to; this will be done in the MessageLayoutFactory class using the passed 'sUserEntitlementName' parameter.
	 */
	private final MessageLayout getMessageLayout(final String sMID, final PDO pdo, final String sUserEntitlementName,
			final boolean bUserHasReadOnlyPermission, String sScreenSetID)
	{
		MessageLayout messageLayout = null;
		List<RuleResult> listRuleResults;

		// String sOffice = pdo.getString(P_OFFICE);
		String[] arrObjectIDs = new String[] { pdo.getString(P_OFFICE), ServerConstants.DEFAULT_SERVER_OFFICE_NAME };

		try
		{
			if (sScreenSetID == null)
			{
				// STEP 1 - if the sScreenSetID formal argument was not null
				// Executes message screen set selection rule for getting the screen set ID for the message.
				listRuleResults = m_internalRuleExecutionLogging.executeRule(Admin.getContextAdmin(), RULE_TYPE_ID_MESSAGE_SCREEN_SET_SELECTION, null,
						sMID, arrObjectIDs).getResults();

				// Found screen set ID.
				if (!listRuleResults.isEmpty())
				{
					sScreenSetID = listRuleResults.get(0).getAction();
				}
			}// EO if the screenset Id was not null
			

			// Screen set ID was found.
			if (sScreenSetID != null)
			{
				// STEP 2 -
				// Executes message fields setting selection rule for getting a list of
				// 0 to N action IDs, where each one of them stands for a fields sets ID
				// from the MESSAGE_FIELDS_SETTING table.
				listRuleResults = m_internalRuleExecutionLogging.executeRule(Admin.getContextAdmin(), RULE_TYPE_ID_MESSAGE_FIELDS_SETS_SELECTION, null,
						sMID, arrObjectIDs).getResults();
				String[] arrFieldsSetsIDs = getRuleResultsActionsArray(listRuleResults);

				// STEP 3 -
				// Executes message buttons setting selection rule for getting a list of
				// 0 to N action IDs, where each one of them stands for a buttons sets ID
				// from the MESSAGE_BUTTONS_SETTING table.
				// TODO: REMOVE THE RESET FOR NOW SET SET THE FIELDS SET ARRAY AS AN ADDON
				// listRuleResults = m_boRuleExecution.executeRule(RULE_TYPE_ID_MESSAGE_BUTTONS_SETS_SELECTION, null, sMID, arrObjectIDs).getResults()
				// ;
				// String[] arrButtonsSetsLogicalIDs = getRuleResultsActionsArray(listRuleResults);

				// Calls MessageLayoutFactory for getting final layout.
				// messageLayout = MessageLayoutFactory.getInstance().getLayout(sScreenSetID, arrFieldsSetsLogicalIDs, arrButtonsSetsLogicalIDs,
				// sUserEntitlementName, bUserHasReadOnlyPermission);
				// sUserEntitlementName, bUserHasReadOnlyPermission
				// TODO: REMOVE THE RESET FOR NOW SET SET THE FIELDS SET ARRAY AS AN ADDON

				messageLayout = new MessageLayout(sScreenSetID, null, new TreeSet<MessageButton>());

				final MessageLayoutCacheInterface layoutCache = (MessageLayoutCacheInterface) CacheKeys.MiscResoucesKey
						.getSingle(MessageLayoutCacheInterface.class);

				messageLayout.setConfigurationDelta(layoutCache.getFieldsSetsDelta(sScreenSetID, arrFieldsSetsIDs));

				// set the readonly mode within the pdo's transient data
				pdo.setTransient(D_READ_ONLY_MODE, bUserHasReadOnlyPermission);

			}
		}

		catch (Exception e)
		{
			ExceptionController.getInstance().handleException(e, this);
		}

		return messageLayout;
	}// EOM

	/**
	 * Gets a list of RuleResult objects and returns a String[] of the rule actions.
	 */
	private final String[] getRuleResultsActionsArray(final List<RuleResult> listRuleResults)
	{
		String[] arrActions = new String[0];

		if (!listRuleResults.isEmpty())
		{
			arrActions = new String[listRuleResults.size()];

			for (int i = 0; i < arrActions.length; i++)
			{
				RuleResult ruleResult = listRuleResults.get(i);
				arrActions[i] = ruleResult.getAction();
			}
		}

		return arrActions;
	}// EOM

	/**
   *   
   */
	private final Feedback initialiseReadOnlyTables(final Connection conn, final String sMAXRECINPY_Value, final String sLastSubmitTimeStamp,
			final LoadMessageInputData loadMessageInputData, final MessageScreenObject messageScreenObject, 
			final EnumSet<LoadMessageStep> enumSetFragmentGrids)
	{

		//final BackendTracer logger = GlobalTracer;
		

		Feedback feedback = messageScreenObject.getFeedback();
		final String sMID = messageScreenObject.getMID() ;
		PDO pdo = PaymentDataFactory.load(sMID);
		Integer partitionID = pdo.getIsHistory();
		
		for (LoadMessageStep enumGrid : enumSetFragmentGrids)
		{

			switch (enumGrid)
			{

				case STEP_LOAD_MEMOPOST:
				{
					feedback = this.getMEMOPOST_Data(conn, sMID, messageScreenObject, 0);
				}
					break;
				case STEP_LOAD_NEWJOURNAL:
				{
					feedback = this.getNEWJOURNAL_Data(conn, sMID, sLastSubmitTimeStamp, sMAXRECINPY_Value, -1, true, messageScreenObject, 0);
				}
					break;
				case STEP_LOAD_MSGERR:
				{
					// MSG_TODO: should in fact be initialised from the pdo
					feedback = this.getMSGERR_Data(conn, sMID, false, sLastSubmitTimeStamp, sMAXRECINPY_Value, -1, messageScreenObject, partitionID);
				}
					break;
				case STEP_LOAD_MSGERR_HISTORICAL:
				{
					feedback = this.getMSGERR_Data(conn, sMID, true, sLastSubmitTimeStamp, sMAXRECINPY_Value, -1, messageScreenObject, partitionID);
				}
					break;
				case STEP_LOAD_MSGNOTES:
				{
					messageScreenObject.getData().getNSetListMSGNOTES(); 
				}
					break;
				case STEP_LOAD_ADVICES:
				{
					// MSG_TODO: NYI
					// feedback = getADVICES_Data(conn, sMID, messageScreenObject);
				}
					break;
				case STEP_LOAD_MSG_INVOICE_REF:
				{
					// MSG_TODO: Not to be handled by now, (Eli).
					// feedback = getADVICES_Data(conn, sMID, messageScreenObject);
				}
					break;
				case STEP_LOAD_MSG_BEFORE_AFTER:
				{
					feedback = this.getMessageBeforeAfterData(conn, sMID, messageScreenObject);
				}
					break;
				case STEP_LOAD_MSG_RULE_LOG:
				{
					feedback = this.getMSG_RULE_LOG(conn, sMID, messageScreenObject, 0);
				}
					break;
				case STEP_LOAD_MFAMILY_HV:
				{
					feedback = this.getMFAMILY_Data(conn, sMID, false, messageScreenObject, partitionID);
				}
					break;
				case STEP_LOAD_DUPEX:
				{
					feedback = this.getDupexData(conn, sMID, messageScreenObject);
				}
					break;
				case STEP_LOAD_MSG_SPECIAL_INST:
				{
					feedback = this.getMSG_SPECIAL_INST_Data(conn, sMID, -1, messageScreenObject, partitionID);
				}
					break;
					
				case STEP_LOAD_MSG_MESSAGE_EXTERNAL_INTERACTION:
				{
					feedback = this.getAcknowledgements_Data(conn, sMID,  messageScreenObject);
				}
					break;	
					

			}// EO switch

			if (!feedback.isSuccessful())
				return feedback;

		}// EO while there are more grids

		
		return feedback;
	}// EOM

	/**
	 * Gets data from the MEMOPOST table.
	 */
	private final Feedback getMEMOPOST_Data(final Connection conn, final String sMID, final MessageScreenObject messageScreenObject, Integer partitionID)
	{
		

		Feedback feedback = messageScreenObject.getFeedback();

		// if the grid data already exists, abort
		if (!messageScreenObject.getGridData(LoadMessageStep.STEP_LOAD_MEMOPOST).equals(GlobalConstants.EMPTY_STRING))
			return feedback;

		// Gets MEMOPOST table data for the passed MID.
		messageScreenObject.getData().set(PDOConstantFieldsInterface.D_POSTING_REQUEST, PostingRequestType.LOAD.name());
		LoadPostingInfoOutputData output = BOProxies.m_internalLoadPostingInfoPdoHandling.performLoadPostingInfo(Admin.getContextAdmin(), sMID, partitionID);

		feedback = output.getFeedback();
		if (feedback.isSuccessful())
		{
			Object[][] data = output.getData();
			
			if (data != null && data.length > 0 && data[0] != null)
			{
				for (Object[] objects : data) 
				{
//					double values larger then 9999999 represented as exponentials numbers, therefore - format
					if (objects[6] != null)
					{
						
						Object[] seperators = ASCacheFactory.getInstance().getFormattingValues(Admin.getContextPDO().getString(PDOConstantFieldsInterface.P_OFFICE));
						m_screenObject.setDecimalAndThousandSeparatorsArray((char[])seperators[1]);
						objects[6] = m_screenObject.getFormattedAmountValueWithDecimalPoint(ScreenObject.FORMAT_STYLE_FLOATS, BigDecimal.valueOf((Double)objects[6]).toPlainString());
						
					}
				}
			}
			
			
			messageScreenObject.addGridData(LoadMessageStep.STEP_LOAD_MEMOPOST, data);
		}

		

		return feedback;
	}// EOM

	/**
	 * Gets data from the NEWJOURNAL table.
	 */
	private final Feedback getNEWJOURNAL_Data(final Connection conn, final String sMID, final String sLastSubmitTimeStamp,
			final String sMAXRECINPY_Value, int iTablePageNumber, final boolean bAddComplianceData, final MessageScreenObject messageScreenObject, Integer partitionID)
	{
		

		Feedback feedback = messageScreenObject.getFeedback();

		// if the grid data already exists, abort
		if (!messageScreenObject.getGridData(LoadMessageStep.STEP_LOAD_NEWJOURNAL).equals(GlobalConstants.EMPTY_STRING))
			return feedback;

		iTablePageNumber = iTablePageNumber != -1 ? iTablePageNumber : 1;

		// Determines lower end page limit and max end page limit, where
		// the 'iHighEndPageLimit' is always the required one plus 1,
		// for required-paging notification; later on, if we do have an extra row,
		// it will be removed from the received DTODataHolder object.
		int iMaxRowsPerPageLimit = Integer.parseInt(sMAXRECINPY_Value);
		int iLowerEndPageLimit = iMaxRowsPerPageLimit * (iTablePageNumber - 1);
		int iHighEndPageLimit = iLowerEndPageLimit + iMaxRowsPerPageLimit + 1;

		// TODO: what is the parallel field in MINF?
		// String sMSG_CLASS = messageScreenObject.getFieldValue(""/*FIELD_MIF_MSG_CLASS*/).trim();
		// boolean bIncludeChildrenPart = MessageFunctions.isMessageClassRequiresNEWJOURNAL_Children(sMSG_CLASS);
		boolean bIncludeChildrenPart = false;

		// Gets NEWJOURNAL table data for the passed MID.
		String[] arrColumnNamesOrder = ASCacheFactory.getInstance().getMessageTableColumnOrderArray(FIELD_VIRTUAL_AUDITTRAIL);

		DTODataHolder dtoTableData = m_daoMessageLoad.getNEWJOURNAL_Data(conn, sMID, bIncludeChildrenPart, iHighEndPageLimit, iLowerEndPageLimit, partitionID);

		Object[][] arrData = null;
		boolean bMoreRowsAvailable = false;

		feedback = dtoTableData.getFeedBack();
		if (feedback.isSuccessful() && !dtoTableData.isEmpty())
		{
			// If the returned number of rows is bigger than the 'sMAXRECINPY_Value'
			// parameter, than it means that we have paging and that we need to remove
			// the last fetched row from the DTODataHolder object.
			bMoreRowsAvailable = dtoTableData.getRowsNumber() == (iMaxRowsPerPageLimit + 1);
			if (bMoreRowsAvailable)
			{
				// Remove the last fetched row.
				dtoTableData.getDataAL().remove(dtoTableData.getDataAL().size() - 1);
			}

			arrData = dtoTableData.getRowsMatrix(arrColumnNamesOrder);

			if (bAddComplianceData)
			{
				getComplianceAndHitInfoData(sLastSubmitTimeStamp, dtoTableData, messageScreenObject);
			}
		}

		else
		{
			arrData = GlobalConstants.EMPTY_MATRIX;
		}

		messageScreenObject.addGridData(LoadMessageStep.STEP_LOAD_NEWJOURNAL, arrData);
		updateMessageDataWithTablesPagingData(FIELD_VIRTUAL_AUDITTRAIL, iTablePageNumber, bMoreRowsAvailable, messageScreenObject);

		

		return feedback;
	}// EOM

	/**
	 * Gets compliance and hit info data.
	 */
	private void getComplianceAndHitInfoData(String sLastSubmitTimeStamp, DTODataHolder dtoNEWJOURNALTableData,
			MessageScreenObject messageScreenObject)
	{
		

		ArrayList alNEWJOURNALData = dtoNEWJOURNALTableData.getDataAL();
		int iSize = alNEWJOURNALData.size();

		// TODO: what is the parallel field in MINF?
		// String sMSG_CLASS = messageScreenObject.getFieldValue(""/*FIELD_MIF_MSG_CLASS*/).trim();

		ArrayList alComplianceData = new ArrayList();
		ArrayList<HitInformation> alHitInformationData = new ArrayList<HitInformation>();

		// Prepares compliance ArrayList.
		// Reversed 'for' loop !!!
		for (int i = iSize - 1; i >= 0; i--)
		{
			HashMap hmCurrentRow = (HashMap) alNEWJOURNALData.get(i);

			String sMODULE_ID = (String) hmCurrentRow.get(COLUMN_NEWJOURNAL_MODULEID);

			// This row is required for the compliance data.
			if (MODULEID_9998_COMPLIANCE.equals(sMODULE_ID))
			{
				String sTIME_STAMP = (String) hmCurrentRow.get(COLUMN_TIME_STAMP);

				if (sTIME_STAMP.compareTo(sLastSubmitTimeStamp) > 0)
				{
					// STEP 1 - COMPLIANCE.
					String sUPDATE_DATE = (String) hmCurrentRow.get(COLUMN_NEWJOURNAL_UPDATE_DATE);
					String sDESCRIPTION = (String) hmCurrentRow.get(COLUMN_NEWJOURNAL_DESCRIPTION);
					alComplianceData.add(new Object[] { sUPDATE_DATE, sDESCRIPTION });

					// STEP 2 - HIT INFORMATION.
					// The hit info shouldn't be displayed in the 'Cover' tab, because
					// the party fields in the 'Cover' tab are reversed - the user will see
					// the compliance table but in case he wants to see the hit info, he should
					// open the direct message.
					/*
					 * if(!MESSAGE_CLASS_SI.equals(sMSG_CLASS)) { String sHITINFO = ((String)hmCurrentRow.get(COLUMN_NEWJOURNAL_HIT_INFO)).trim();
					 * if(!ServerUtils.isNullOrEmpty(sHITINFO)) { // Figures hit type. String sHitType = sHITINFO.substring(0,1); short shHitType =
					 * FIELD_ACTION_COLOR_COMPLIANCE; try { shHitType = MessageFunctions.getHitTypeShortValue(sHitType); } catch(Exception e) {
					 * ExceptionController.getInstance().handleException(e, this); } String sPartyName = sHITINFO.substring(1); String sHitText =
					 * (String)hmCurrentRow.get(COLUMN_NEWJOURNAL_REFERENCE); alHitInformationData.add(new HitInformation(shHitType, sPartyName,
					 * sHitText)); } }
					 */
				}
			}
		}

		// Prepares compliance Object[][].
		if (!alComplianceData.isEmpty())
		{
			Object[][] arrComplianceData = ServerUtils.getMatrixFromArrayListOfSingleObjectArrays(alComplianceData, false);
			messageScreenObject.addGridData(FIELD_VIRTUAL_COMPLIANCE, arrComplianceData);
		}

		// Prepares HitInformation[].
		if (!alHitInformationData.isEmpty())
		{
			HitInformation[] arrHitInformation = new HitInformation[alHitInformationData.size()];
			for (int i = 0; i < arrHitInformation.length; i++)
			{
				arrHitInformation[i] = alHitInformationData.get(i);
			}
			messageScreenObject.setHitInformationData(arrHitInformation);
		}

		
	}

	/**
	 * Updates the passed MessageScreenObject object with paging data for the passed table tag name.
	 */
	private final void updateMessageDataWithTablesPagingData(final String sTableTagName, final int iTablePageNumber,
			final boolean bMoreRowsAvailable, final MessageScreenObject messageScreenObject)
	{
		HashMap hmTablesWithPagingData = (HashMap) messageScreenObject.getScreenObjectAdditionalData(FIELD_VIRTUAL_TABLES_PAGING_DATA);
		hmTablesWithPagingData = hmTablesWithPagingData != null ? hmTablesWithPagingData : new HashMap();

		Object[] arrTablePagingData = new Object[] { iTablePageNumber, bMoreRowsAvailable };
		hmTablesWithPagingData.put(sTableTagName, arrTablePagingData);

		messageScreenObject.putScreenObjectAdditionalData(FIELD_VIRTUAL_TABLES_PAGING_DATA, hmTablesWithPagingData);
	}// EOM

	/**
	 * Gets data from the MSGERR table.
	 */
	private final Feedback getMSGERR_Data(final Connection conn, final String sMID, final boolean bGetHistoricalErrors, String sLastSubmitTimeStamp,
			final String sMAXRECINPY_Value, int iTablePageNumber, final MessageScreenObject messageScreenObject, Integer partitionID)
	{
		

		Feedback feedback = messageScreenObject.getFeedback();

		final LoadMessageStep enumStep = (bGetHistoricalErrors ? LoadMessageStep.STEP_LOAD_MSGERR_HISTORICAL : LoadMessageStep.STEP_LOAD_MSGERR);

		// if the grid data already exists, abort
		if (!messageScreenObject.getGridData(enumStep).equals(GlobalConstants.EMPTY_STRING))
			return feedback;

		DTODataHolder dtoTableData = null;

		boolean bMoreRowsAvailable = false;

		iTablePageNumber = iTablePageNumber != -1 ? iTablePageNumber : 1;

		int iMaxRowsPerPageLimit = Integer.parseInt(sMAXRECINPY_Value);

		// NOTE: Currently, the 2 errors table have the same columns; thus, it doesn't matter
		// if we get the columns names order using VIRTUAL.ERRORS or VIRTUAL.HISTORIC_ERR.
		// This should be modified in case, the actual columns will ne different in the future.
		final String[] arrColumnNamesOrder = ASCacheFactory.getInstance().getMessageTableColumnOrderArray(FIELD_VIRTUAL_ERRORS);

		// Historical errors.
		if (bGetHistoricalErrors)
		{
			// Determines lower end page limit and max end page limit, where
			// the 'iHighEndPageLimit' is always the required one plus 1,
			// for required-paging notification; later on, if we do have an extra row,
			// it will be removed from the received DTODataHolder object.
			int iLowerEndPageLimit = iMaxRowsPerPageLimit * (iTablePageNumber - 1);
			int iHighEndPageLimit = iLowerEndPageLimit + iMaxRowsPerPageLimit + 1;

			// Gets MSGERR table data for the passed MID.
			dtoTableData = m_daoMessageLoad.getMSGERR_Data(conn, sMID, bGetHistoricalErrors, null, iHighEndPageLimit, iLowerEndPageLimit, partitionID);

			feedback = dtoTableData.getFeedBack();

			if (feedback.isSuccessful() && !dtoTableData.isEmpty())
			{
				// If the returned number of rows is bigger than the 'sMAXRECINPY_Value'
				// parameter, than it means that we have paging and that we need to remove
				// the last fetched row from the DTODataHolder object.
				bMoreRowsAvailable = dtoTableData.getRowsNumber() == (iMaxRowsPerPageLimit + 1);
				if (bMoreRowsAvailable)
				{
					// Remove the last fetched row.
					dtoTableData.getDataAL().remove(dtoTableData.getDataAL().size() - 1);
				}
			}
		}

		// Non-historical errors.
		else
		{
			sLastSubmitTimeStamp = sLastSubmitTimeStamp != null && !sLastSubmitTimeStamp.equals(DEFAULT_LAST_SUBMIT_TIME_STAMP) ? sLastSubmitTimeStamp
					: ServerConstants.SPACE;

			// Gets MSGERR table data for the passed MID.
			dtoTableData = m_daoMessageLoad.getMSGERR_Data(conn, sMID, bGetHistoricalErrors, sLastSubmitTimeStamp, -1, -1, partitionID);
			feedback = dtoTableData.getFeedBack();
		}

		// if(feedback.isSuccessful() && !dtoTableData.isEmpty())
		if (feedback.isSuccessful())
		{
			Object[][] arrData = dtoTableData.getRowsMatrix(arrColumnNamesOrder);

			// messageScreenObject.addGridData(bGetHistoricalErrors? FIELD_VIRTUAL_HISTORIC_ERR : FIELD_VIRTUAL_ERRORS, arrData);
			messageScreenObject.addGridData(enumStep, arrData);

			// For both errro types we use VIRTUAL.ERRORS.
			updateMessageDataWithTablesPagingData(bGetHistoricalErrors ? FIELD_VIRTUAL_HISTORIC_ERR : FIELD_VIRTUAL_ERRORS, iTablePageNumber,
					bMoreRowsAvailable, messageScreenObject);
		}

		

		return feedback;
	}

	private final Feedback getMSG_SPECIAL_INST_Data(final Connection conn, final String sMID, int iTablePageNumber,
			final MessageScreenObject messageScreenObject, Integer iPartitionID)
	{
		

		Feedback feedback = messageScreenObject.getFeedback();

		final LoadMessageStep enumStep = LoadMessageStep.STEP_LOAD_MSG_SPECIAL_INST;

		// if the grid data already exists, abort
		if (!messageScreenObject.getGridData(enumStep).equals(GlobalConstants.EMPTY_STRING))
			return feedback;

		DTODataHolder dtoTableData = null;

		boolean bMoreRowsAvailable = false;

		iTablePageNumber = iTablePageNumber != -1 ? iTablePageNumber : 1;

		// NOTE: Currently, the 2 errors table have the same columns; thus, it doesn't matter
		// if we get the columns names order using VIRTUAL.ERRORS or VIRTUAL.HISTORIC_ERR.
		// This should be modified in case, the actual columns will ne different in the future.
		final String[] arrColumnNamesOrder = ASCacheFactory.getInstance().getMessageTableColumnOrderArray(FIELD_VIRTUAL_MSG_SPECIAL_INST);

		// Historical errors.

		// Gets MSGERR table data for the passed MID.
		dtoTableData = m_daoMessageLoad.getMSG_SPECIAL_INST_Data(conn, sMID, iPartitionID);
		feedback = dtoTableData.getFeedBack();

		// if(feedback.isSuccessful() && !dtoTableData.isEmpty())
		if (feedback.isSuccessful() && arrColumnNamesOrder != null)
		{
			Object[][] arrData = dtoTableData.getRowsMatrix(arrColumnNamesOrder);

			// messageScreenObject.addGridData(bGetHistoricalErrors? FIELD_VIRTUAL_HISTORIC_ERR : FIELD_VIRTUAL_ERRORS, arrData);
			
			if (arrData != null)
			{
				for (Object[] objects : arrData) 
				{
					if (objects != null) 
					{
						objects[0] = ((String)objects[0]).equals("0") ? "New" : "Approved";
					}
				}
			}
			messageScreenObject.addGridData(enumStep, arrData);

			// For both errro types we use VIRTUAL.ERRORS.
			updateMessageDataWithTablesPagingData(FIELD_VIRTUAL_MSG_SPECIAL_INST, iTablePageNumber, bMoreRowsAvailable, messageScreenObject);
		}

		

		return feedback;
	}

	/**
	 * Gets data from the MFAMILY table.
	 */
	private Feedback getMFAMILY_Data(Connection conn, String sMID, boolean bLowValue, MessageScreenObject messageScreenObject, Integer partitionID)
	{
		

		Feedback feedback =  getHighValueMFAMILY_Data(conn, sMID, messageScreenObject, partitionID);
		return feedback;
	}

	/**
	 * Gets data from the MFAMILY table for HIGH value messages.
	 */
	private Feedback getHighValueMFAMILY_Data(Connection conn, String sMID, MessageScreenObject messageScreenObject, Integer partitionID)
	{
		

		Feedback feedback = messageScreenObject.getFeedback();

		// if the grid data already exists, abort
		if (!messageScreenObject.getGridData(LoadMessageStep.STEP_LOAD_MFAMILY_HV).equals(GlobalConstants.EMPTY_STRING))
			return feedback;
		PDO pdo = messageScreenObject.getData();
		// Gets a list of MIDs.
		final DTODataHolder dto = m_daoMessageLoad.getHVMessageLinks(conn, sMID, pdo.getString("P_IN_INTERNAL_FILEID"), pdo
				.getString("P_UNIQUE_GROUPING_ID"), pdo.getString("P_BATCH_MSG_TP"), pdo.getString(P_OUT_INTERNAL_FILEID), pdo
				.getString(P_OUT_GROUPING_ID), pdo.getString(P_DUPLICATE_INDEX), pdo.getString(P_MSG_STS), partitionID);

		feedback = dto.getFeedBack();

		if (feedback.isSuccessful())
		{
			ArrayList alData = dto.getDataAL();

			int iLength = alData.size();

			final String RELATION_CURRENT = "Current";
			final String ORIG_INDICATOR = "=>";

			Object[][] arrLinksData = new Object[iLength][];
			Map hmOutputData = null;
			String sRelationName, sStatus, sMessageType, sMessageSubType, sLinkedMID, sOrigReference, sReference;

			boolean bOriginalMID = false;

			for (int i = 0; i < iLength; i++)
			{

				hmOutputData = (Map) alData.get(i);

				sRelationName = (String) hmOutputData.get("RELATED_TYPE");
				sLinkedMID = (String) hmOutputData.get("RELATED_MID");
				sMessageType = (String) hmOutputData.get("P_MSG_TYPE");
				sMessageSubType = (String) hmOutputData.get("P_MSG_SUB_TYPE");
				sStatus = (String) hmOutputData.get("P_MSG_STS");
				sOrigReference = (String) hmOutputData.get("X_INSTR_ID");
				sReference = (String) hmOutputData.get("X_END_TO_END_ID");

				bOriginalMID = sLinkedMID.equals(sMID);

				// orig indicator
				// name (name as parent)
				// mid
				// msg type
				// msg status
				// orig reference
				// reference

				arrLinksData[i] = new Object[] {

				bOriginalMID ? ORIG_INDICATOR : ServerConstants.EMPTY_STRING, bOriginalMID ? RELATION_CURRENT : sRelationName,
						bOriginalMID ? sMID : sLinkedMID, sMessageType, sMessageSubType, sStatus, sOrigReference, sReference };

			}// EO while there are more link rows

			// Prepares the data for the message MID
			// feedback = getOneLinksRow(conn, sMID, null, arrOneLinksRowHolder, true);

			messageScreenObject.addGridData(LoadMessageStep.STEP_LOAD_MFAMILY_HV, arrLinksData);
		}
		else
		{
			final String TRACE_MESSAGE = "ERROR: can't get data for original MID {} !!!";
			logger.trace(TRACE_MESSAGE, sMID);
		}// EO else if failure

		

		return feedback;
	}

	/**
	 * Gets data from the MFAMILY table for LOW value messages.
	 */
	private Feedback getDupexData(Connection conn, String sMID, MessageScreenObject messageScreenObject)
	{
	

		Feedback feedback = messageScreenObject.getFeedback();

		// if the grid data already exists, abort
		if (!messageScreenObject.getGridData(LoadMessageStep.STEP_LOAD_DUPEX).equals(GlobalConstants.EMPTY_STRING))
			return feedback;
		PDO pdo = messageScreenObject.getData();
		// Gets a list of MIDs.
		PreparedStatement ps = null;
		ResultSet rs = null;
		try
		{
			String sUid = ((MatchingCheckOutputData) m_matchingCheckLogging.performDuplicateCheck(Admin.getContextAdmin(), sMID, true,true))
					.getMatchingRuleUID();
			if (!GlobalUtils.isNullOrEmpty(sUid))
			{
				ps = m_daoMessageLoad.getDupexLinks(conn, pdo, sUid);

				final String RELATION_CURRENT = "Current";
				final String ORIG_INDICATOR = "=>";

				List linksDataList = new ArrayList();
				Map hmOutputData = null;
				String sStatus, sMessageType, sMessageSubType, sLinkedMID, sOrigReference, sReference;

				rs = ps.executeQuery();
				while (rs.next())
				{

					sMID = rs.getString(1);
					sMessageType = rs.getString(2);
					sMessageSubType = rs.getString(3);
					sMessageSubType = sMessageSubType == null ? "" : sMessageSubType;

					sStatus = rs.getString(4);
					// sOrigReference = (String) hmOutputData.get("OX_END_TO_END_ID") ;
					// sReference = (String) hmOutputData.get("X_END_TO_END_ID") ;

					// orig indicator
					// name (name as parent)
					// mid
					// msg type
					// msg sub type
					// msg status
					// orig reference
					// reference

					linksDataList.add(new Object[] { sMID, sMessageType, sMessageSubType, sStatus
					// sOrigReference,
							// sReference
							});

				}// EO while there are more link rows

				// Prepares the data for the message MID
				// feedback = getOneLinksRow(conn, sMID, null, arrOneLinksRowHolder, true);
				int size = linksDataList.size();
				Object[][] linksDataArr = new Object[size][];

				for (int i = 0; i < size; i++)
				{
					linksDataArr[i] = (Object[]) linksDataList.get(i);
				}
				messageScreenObject.addGridData(LoadMessageStep.STEP_LOAD_DUPEX, linksDataArr);
			}
		}
		catch (Throwable e)
		{
			ExceptionController.getInstance().handleException(e, this);
		}
		finally
		{
			m_daoMessageLoad.releaseResources(rs, ps);
		}

		

		return feedback;

	}

	/**
   * 
   */
	private final Feedback getMSG_RULE_LOG(final Connection conn, final String sMID, final MessageScreenObject mso, Integer iPartitionID)
	{

		
		
		// if the grid data already exists, abort
		if (!mso.getGridData(LoadMessageStep.STEP_LOAD_MSG_RULE_LOG).equals(GlobalConstants.EMPTY_STRING))
			return mso.getFeedback();

		final DTODataHolder dtoTableData = m_daoMessageLoad.getMSG_RULE_LOG_Data(conn, sMID, iPartitionID);
		final Feedback feedback = dtoTableData.getFeedBack();

		if (!feedback.isSuccessful())
			return feedback;
		// else

		final String REGEX = "\\n";

		List alData = dtoTableData.getDataAL();

		int iSize = alData.size();
		List<String[]> arrDataList = new ArrayList<String[]>();
		String[] descriptionArr =  null;
		for (int i =0; i < iSize ; i++)
		{
			HashMap hmCurrentRow = (HashMap) alData.get(i);

			String zoneCode = (String) hmCurrentRow.get(COLUMN_ZONE_CODE);
			String timeStamp = (String) hmCurrentRow.get(COLUMN_TIME_STAMP);
			String flowId = (String) hmCurrentRow.get(COLUMN_FLOW_ID);
			String description = ((String) hmCurrentRow.get(COLUMN_DESCRIPTION));
			
			if (description.indexOf(";") > 0 )
			{
				descriptionArr = description.split(";");
				arrDataList.addAll(parseMsgRule(descriptionArr, zoneCode, flowId, timeStamp)) ;
				
			}else // support for previos format
			{
				descriptionArr = description.split(REGEX);
				arrDataList.addAll(parseMsgRuleOldFormat(descriptionArr, zoneCode, flowId, timeStamp)) ;
			}
			
			
			  
		}
		
		String[][] dataMatrix = null;
		
		if(!GlobalUtils.isListNullOrEmpty(arrDataList))
		{
			dataMatrix = new String[arrDataList.size()][];
			
			for (int i = 0; i < dataMatrix.length; i++) {
				dataMatrix[i] = arrDataList.get(i);
			}			
		}
		else
		{
			dataMatrix = GlobalConstants.EMPTY_STRING_MATRIX;
		}
		 
		mso.addGridData(LoadMessageStep.STEP_LOAD_MSG_RULE_LOG, dataMatrix);

		return feedback;
	}// EOM
	
	private List<String[]> parseMsgRule(String[] rowsInDescriptionArr, String zoneCode, String flowId, String timeStamp)
	{
		List<String[]> arrDataList = new ArrayList<String[]>();
		final String BACK_SLASH_AND_COMMA = "\\,";
		int iCountLength = rowsInDescriptionArr.length;
		String pruleUid;
		String executionTime;
		for (int j = 0; j < iCountLength; j++)
		{
			if (rowsInDescriptionArr[j].length() > 0)
			{
				String[] arrColsIn_DESCRIPTION_Field = rowsInDescriptionArr[j].split(BACK_SLASH_AND_COMMA);
				String[] arrData = new String[9];
				pruleUid = arrColsIn_DESCRIPTION_Field[0];
				executionTime = arrColsIn_DESCRIPTION_Field[1];
				
	            Prules prule = CacheKeys.PRulesUIDKey.getSingle(pruleUid);
	            
	            if (prule != null)
	            {
		            PruleTypes pruleType = CacheKeys.PRulesTypeKey.getSingle(prule.getRuleTypeId());
		        
					// rule type id
					arrData[1] = prule.getRuleTypeId();
					// rule type name
					arrData[2] = pruleType.getRuleTypeName();
					// rule name
					arrData[4] = prule.getRuleName();
					// rule action uid
					arrData[5] = prule.getRuleAction();
					// sub type
					arrData[3] = prule.getRuleSubType() != null ? prule.getRuleSubType() : GlobalConstants.EMPTY_STRING;
					// execution time
					arrData[0] = executionTime;
					arrData[6] = zoneCode;
					arrData[7] = flowId;
					arrData[8] = timeStamp;
					
					arrDataList.add(arrData);
	            }
			}
		}
		
		return arrDataList;
	}
	
	private List<String[]> parseMsgRuleOldFormat(String[] rowsInDescriptionArr, String zoneCode, String flowId, String timeStamp)
	{
		List<String[]> arrDataList = new ArrayList<String[]>();
		final String BACK_SLASH_AND_COMMA = "\\,";
		int iCountLength = rowsInDescriptionArr.length;
		for (int j = 0; j < iCountLength; j++)
		{

			String[] arrColsIn_DESCRIPTION_Field = rowsInDescriptionArr[j].split(BACK_SLASH_AND_COMMA);
			String[] arrData = new String[9];

			// rule type id
			arrData[1] = arrColsIn_DESCRIPTION_Field[0];
			// rule type name
			arrData[2] = arrColsIn_DESCRIPTION_Field[1];
			// rule name
			arrData[4] = arrColsIn_DESCRIPTION_Field[3];
			// rule action uid
			arrData[5] = arrColsIn_DESCRIPTION_Field[4];
			// sub type
			arrData[3] = arrColsIn_DESCRIPTION_Field[2];
			// execution time
			arrData[0] = arrColsIn_DESCRIPTION_Field[5];
			arrData[6] = zoneCode;
			arrData[7] = flowId;
			arrData[8] = timeStamp;
			
			arrDataList.add(arrData);
		}
		
		return arrDataList;
		
	}

	/**
	 * Gets data from the MSG_RULE_LOG table.
	 */
	private final Feedback getMSG_RULE_LOG_Data(Connection conn, String sMID, MessageScreenObject messageScreenObject, Integer iPartitionID)
	{
		final String REGEX = "\\n";
		final String BACK_SLASH_AND_COMMA = "\\,";

		
		// Gets MSG_RULE_LOG table data for the passed MID.
		DTODataHolder dtoTableData = m_daoMessageLoad.getMSG_RULE_LOG_Data(conn, sMID, iPartitionID);
		Feedback feedback = dtoTableData.getFeedBack();

		if (feedback.isSuccessful() && !dtoTableData.isEmpty())
		{
			HashMap hmRuleIDWithTimeStampZoneCode = new HashMap();

			StringBuilder sbRuleIDs = new StringBuilder(GlobalConstants.OPENING_PARENTHESIS);
			ArrayList alData = dtoTableData.getDataAL();

			int iSize = alData.size();
			for (int i = 0; i < iSize; i++)
			{
				HashMap hmCurrentRow = (HashMap) alData.get(i);

				String[] arrRowsIn_DESCRIPTION_Field = ((String) hmCurrentRow.get(COLUMN_DESCRIPTION)).split(REGEX);
				String sZoneCode = (String) hmCurrentRow.get(COLUMN_ZONE_CODE);

				for (int iCount = 0; iCount < arrRowsIn_DESCRIPTION_Field.length; iCount++)
				{
					String sRuleID = arrRowsIn_DESCRIPTION_Field[iCount].split(BACK_SLASH_AND_COMMA)[1];
					String sTimeStamp = arrRowsIn_DESCRIPTION_Field[iCount].split(BACK_SLASH_AND_COMMA)[2];

					if (sbRuleIDs.length() > 1)
					{
						sbRuleIDs.append(GlobalConstants.COMMA);
					}
					sbRuleIDs.append(sRuleID);
					hmRuleIDWithTimeStampZoneCode.put(sRuleID, new String[] { sTimeStamp, sZoneCode });
				}
			}
			sbRuleIDs.append(GlobalConstants.CLOSING_PARENTHESIS);

			dtoTableData = m_daoMessageLoad.getRuleIDsDataForMSG_RULE_LOG_Table(conn, sbRuleIDs.toString());

			// Sets the time stamp and zone code from MSG_RULE_LOG table.
			if (dtoTableData.isFeedBackSuccess() && !dtoTableData.isEmpty())
			{
				ArrayList alRuleIDsData = dtoTableData.getDataAL();
				int iRuleIDsSize = alRuleIDsData.size();

				for (int i = 0; i < iRuleIDsSize; i++)
				{
					HashMap hmCurrentRow = (HashMap) alRuleIDsData.get(i);
					String sRuleID = (String) hmCurrentRow.get(COLUMN_RULEID);
					hmCurrentRow.put(COLUMN_TIME_STAMP, ((String[]) hmRuleIDWithTimeStampZoneCode.get(sRuleID))[0]);
					hmCurrentRow.put(COLUMN_ZONE_CODE, ((String[]) hmRuleIDWithTimeStampZoneCode.get(sRuleID))[1]);
				}

				// Re-orders the DTO object according to the time stamp column.
				dtoTableData.sortPerColumn(COLUMN_TIME_STAMP);

				String[] arrColumnNamesOrder = ASCacheFactory.getInstance().getMessageTableColumnOrderArray(FIELD_VIRTUAL_RULE_LOG);
				Object[][] arrData = dtoTableData.getRowsMatrix(arrColumnNamesOrder);
				messageScreenObject.addGridData(FIELD_VIRTUAL_RULE_LOG, arrData);
			}
		}

		

		return feedback;
	}

	/**
	 * Gets data from the SWFMIDS table for the message before after table.
	 */
	private final Feedback getMessageBeforeAfterData(Connection conn, String sMID, MessageScreenObject messageScreenObject)
	{
		
		String beginOrigXmlWrapper = "<ns0:FndtMsg xmlns:ns0='http://fundtech.com/SCL/CommonTypes'><ns0:Msg>";
		String endOrigXmlWrapper = "</ns0:Msg></ns0:FndtMsg>";
		String beginCurrentXmlWrapper = "<FndtMsg xmlns='http://fundtech.com/SCL/CommonTypes'><Msg>";
		String endCurrentXmlWrapper = "</Msg></FndtMsg>";
		String emptyOrigMsgExtn = "<xml-fragment/>";
		// if the grid data already exists, abort
		if (!messageScreenObject.getGridData(LoadMessageStep.STEP_LOAD_MSG_BEFORE_AFTER).equals(GlobalConstants.EMPTY_STRING)) 
																							return messageScreenObject.getFeedback();
		//else retrieve the orig xml from the given pdo (must not be null at this point  
		PDO pdo = messageScreenObject.getData() ; 
		if(pdo ==  null) pdo = PaymentDataFactory.load(sMID) ; 
		
		/*
		 * check if msg extn exist  
		 */
		String sBeforeElementContent = null;
		final XmlOptions xmloptions = new XmlOptions().setSaveOuter() ;
		XmlObjectBase pmntXbean = pdo.getXml(DASInterface.ORIG_XML_MSG_KEY) ;
		XmlObjectBase origExtnXbean = pdo.getXml(DASInterface.ORIG_XML_MSG_EXTN_KEY);
		logger.debug("mid {}, xml message extn is : {}",pdo.getMID(),origExtnXbean!=null ? origExtnXbean.toString() : null);
		if(origExtnXbean==null || origExtnXbean.toString().matches(emptyOrigMsgExtn)){
			sBeforeElementContent = pmntXbean.xmlText(xmloptions) ;
		}
		else{
			sBeforeElementContent = beginOrigXmlWrapper + "<ns0:Pmnt>" + pmntXbean.xmlText(xmloptions) + "</ns0:Pmnt> <ns0:Extn>" + origExtnXbean.xmlText(xmloptions) + "</ns0:Extn>" + endOrigXmlWrapper ;
		}
			
		//only retrieve the current xml data if the payment is in complete mode
		String sAfterElementContent = null ; 
		//TODO
		if(afterTagDisplayBulkList.contains(pdo.getString(PDOConstantFieldsInterface.P_MSG_STS))|| 
			pdo.getString(PDOConstantFieldsInterface.MF_FORMAT_OUT).equals(MessageConstantsInterface.MONITOR_FLAG_PROCESSED)) { 
			pmntXbean = pdo.getXml(DASInterface.CURRENT_XML_MSG_KEY) ; 
			XmlObjectBase currentExtnXbean = pdo.getXml(DASInterface.CURRENT_XML_MSG_EXTN_KEY) ;
			logger.debug("mid {}, xml message extn is : {}",pdo.getMID(),currentExtnXbean!=null ? currentExtnXbean.toString() : null);
			if(currentExtnXbean==null || currentExtnXbean.toString().matches(emptyOrigMsgExtn)){
				sAfterElementContent = pmntXbean.xmlText(xmloptions) ;
			}
			else{
				sAfterElementContent = beginCurrentXmlWrapper + "<Pmnt>" + pmntXbean.xmlText(xmloptions) + "</Pmnt> <Extn>" + currentExtnXbean.xmlText(xmloptions) + "</Extn>" + endCurrentXmlWrapper  ;
			}
			
		}//EO if the payment was in complete 

		messageScreenObject.addGridData(LoadMessageStep.STEP_LOAD_MSG_BEFORE_AFTER, new String[][] { { sBeforeElementContent,
			sAfterElementContent } });

		

		return new Feedback();
	}
	
	
	/**
   * 
   */
	@Expose
	public Feedback loadMessage(final String sMID, @Input(skip = true) Serializable oAdditionalInput){
		
		Feedback feedback = new Feedback();
		try{
			final PDO pdo = PaymentDataFactory.load(sMID, oAdditionalInput);

			if (pdo == null || pdo.getString(P_MSG_STS).equals(MESSAGE_STATUS_AUTHEX)) { 
				ErrorAuditUtils.onError(ProcessErrorConstants.PDONoMinfRecord, feedback, sMID);
			}else { 
				feedback = this.checkUserPermission(pdo, null, new boolean[] { false }, feedback);
			}//EO if the pdo was loaded properly 
				
		}catch (Throwable e){
			// configure feedback and trace exception
			ErrorAuditUtils.onError(e, feedback);
		}// EO catch block

		return feedback;
	}// EOM

	/**
   * 
   */
	@Expose(type = ExposureType.All)
		@SkipInputValidation
	public PDO newMessage(final Serializable oInput){
		//Guys 31/5/10 removed the admin session generation as already has a UID 
		//final Admin admin = Admin.getContextAdmin();
		//admin.setSessionId(m_boSecurity.generateSessionID(admin, admin.getContextID()));
		return PaymentDataFactory.newPDO(oInput);
	}// EOM


	/**
	 * Sets the verification fields map for the passed MessageScreenObject, (verify rekey and sight verify), according to the field verification
	 * profile attached to this screen object's office, (the payment office or the default office), and in which: Key - field logical ID. Value -
	 * boolean: true - verify rekey field, false - sight verify field.
	 */
	private void setVerificationFieldsMap(Connection conn, String sMID, String sOffice, MessageScreenObject mso)
	{
		final String COLUMN_FIELD_LOGICAL_ID = "FIELD_LOGICAL_ID";
		final String COLUMN_REKEY_VERIFICATION = "REKEY_VERIFICATION";

		try
		{
			String[] arrObjectIDs = new String[] { sOffice, GlobalConstants.DEFAULT_SERVER_OFFICE_NAME };
			List<RuleResult> listRuleResults = m_internalRuleExecutionLogging.executeRule(Admin.getContextAdmin(),
					MessageConstantsInterface.RULE_TYPE_ID_FIELD_VERIFICATION_PROFILE_SELECTION, null, sMID, arrObjectIDs).getResults();

			Map<String, Boolean> mapVerificationFields = new HashMap<String, Boolean>();

			if (!listRuleResults.isEmpty())
			{
				RuleResult ruleResult = listRuleResults.get(0);

				String sFieldVerificationProfileName = ruleResult.getAction();
				String sRuleResultOffice = ruleResult.getObjectUid();

				DTODataHolder dtoVerificationFields = m_daoMessageLoad.getVerificationFields(conn, sFieldVerificationProfileName, sRuleResultOffice);
				Feedback feedback = dtoVerificationFields.getFeedBack();

				if (feedback.isSuccessful())
				{
					ArrayList alData = dtoVerificationFields.getDataAL();
					int iSize = alData.size();

					for (int i = 0; i < iSize; i++)
					{
						HashMap hmCurrentRow = (HashMap) alData.get(i);

						String sFIELD_LOGICAL_ID = (String) hmCurrentRow.get(COLUMN_FIELD_LOGICAL_ID);
						String sREKEY_VERIFICATION = (String) hmCurrentRow.get(COLUMN_REKEY_VERIFICATION);

						mapVerificationFields.put(sFIELD_LOGICAL_ID, !sREKEY_VERIFICATION.equals(ServerConstants.ZERO_VALUE) ? true : false);
					}
				}
			}

			// This line is out of the 'if' clause for cases when no field verification rule was defined.
			// Updates the passed MessageScreenObject object.
			mso.setVerificationFieldsMap(mapVerificationFields);
		}

		catch (Exception e)
		{
			ExceptionController.getInstance().handleException(e, this);
		}
	}

	/**
   *   
   */
	private void assignStatusFlags(MessageScreenObject messageScreenObject)
	{
		final String REPAIR_MODE = "REPAIR_MODE";
		final String VERIFY_MODE = "VERIFY_MODE";
		final String COMPEX_MODE = "COMPEX_MODE";

		PDO pdo = messageScreenObject.getData();

		String sTemplateMID = pdo.getString(P_TEMPLATE_MID);
		String sMsgStatus = pdo.getString(P_MSG_STS);
		Statuses statuses = CacheKeys.statusesKey.getSingle(sMsgStatus);

		if (statuses != null)
		{
			String sStatusAffiliation = statuses.getAffiliation();

			if (!isNullOrEmpty(sStatusAffiliation))
			{
				if(REPAIR_MODE.equals(sStatusAffiliation))
				{
					messageScreenObject.setIsREPAIRMessage(true);
				}

				else if(VERIFY_MODE.equals(sStatusAffiliation))
				{
					messageScreenObject.setIsVERIFYMessage(true);
				}
				
				else if(COMPEX_MODE.equals(sStatusAffiliation))
				{
					messageScreenObject.setIsCOMPEXMessage(true);
				}				
			}
		}

		// New message; no status.
		else if (pdo.isNew())
		{
			messageScreenObject.setIsREPAIRMessage(true);
		}
		if(sTemplateMID != null) 
		{
			messageScreenObject.setIsMessageFromTemplate(true);
		}		
	}
	/**
	 * Sets the Template Unchanged Fields SET for the passed MessageScreenObject,  
	 * according to the Template MID given as an input.
	 */
	private void setTemplateUnchangedFields(Connection conn, String sMID, MessageScreenObject mso, Integer iPartitionID)
	{
		final String COLUMN_FIELD_UNCHANGED_FIELDS = "UNCHANGED_FIELDS";
		try
		{
			List<String> listUnchangedFields = new LinkedList<String>();
			
			DTODataHolder dtoUnchangedFields = m_daoMessageLoad.getUnchangedFields(conn, sMID, iPartitionID);
			Feedback feedback = dtoUnchangedFields.getFeedBack();
			if (feedback.isSuccessful() && !dtoUnchangedFields.isEmpty())
			{
				HashMap hmResult = dtoUnchangedFields.getDataRow();
				String sUnchangedFields = (String) hmResult.get(COLUMN_FIELD_UNCHANGED_FIELDS);	
				String[] arrUnchangedFields = sUnchangedFields.split(GlobalConstants.COMMA);
				mso.setUnchangedFields(new HashSet<String>(Arrays.asList(arrUnchangedFields)));
			}		
		}

		catch (Exception e)
		{
			ExceptionController.getInstance().handleException(e, this);
		}
	}
	
	public final Feedback getAcknowledgements_Data(final Connection conn, final String sMID,MessageScreenObject messageScreenObject)
	{
		
		DTODataHolder acknowledgementsDATAdto = m_daoMessageLoad.getAcknowledgements_Data(conn,sMID);
		if(acknowledgementsDATAdto != null) {
			String[] arrColumnNamesOrder = new String[]{PDOConstantFieldsInterface.X_TX_STS,PDOConstantFieldsInterface.X_STS_RSN_PRTRY,PDOConstantFieldsInterface.X_STS_ID,PDOConstantFieldsInterface.X_CLR_SYS_REF,PDOConstantFieldsInterface.X_ACCT_SVCR_REF};
			//ASCacheFactory.getInstance().getMessageTableColumnOrderArray(FIELD_VIRTUAL_ACKNOWLEDGEMENTS);
			Object[][] arrData = acknowledgementsDATAdto.getRowsMatrix(arrColumnNamesOrder);
			messageScreenObject.addGridData(LoadMessageStep.STEP_LOAD_MSG_MESSAGE_EXTERNAL_INTERACTION, arrData);
			Feedback feedback = acknowledgementsDATAdto.getFeedBack();
			return feedback;
		}
		else {
			  return new Feedback ();
		}
		
	}
 
}
