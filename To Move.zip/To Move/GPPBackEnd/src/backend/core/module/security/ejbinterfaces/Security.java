package backend.core.module.security.ejbinterfaces;

import java.util.Map;

import javax.ejb.Remote;
import com.fundtech.core.security.Admin;

/**
 * Remote interface for Security.
 */
@Remote
public interface Security{

	public static final String REMOTE_JNDI_NAME="ejb/SecurityBean";
	
	
	/** 
	 * Performs Integrated login.
	 * @ejb.business  
	 */
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent login(final Admin admin, com.fundtech.datacomponent.request.UserCredentials credentials ) ;
	
	/** 
	 * Performs logout.
	 * @ejb.business  
	 */
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent logout(final Admin admin ) ;
	
	/** 
	 * Returns the session data for the current active users.
	 * @ejb.business  
	 */
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent getUsersSessionData(final Admin admin ) ;
	
	/** 
	 * Returns the session data for one user.
	 * @ejb.business  
	 */
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent getOneUserSessionData(final Admin admin ) ;
	
	/** 
	 * Performs keep user alive.
	 * @ejb.business  
	 */
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent keepUserAlive(final Admin admin ) ;
	
	/** 
	 * Performs change password.
	 * @ejb.business  
	 */
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent changePassword(final Admin admin, com.fundtech.datacomponent.request.PasswordDetails passwordDetails, java.lang.Boolean isEventChangePasswordAtLogin ) ;
	
	/** 
	 * Aggregates and constructs the userLogin data required for a non login operations such as internal system cleanup 
	 * tasks
	 * @param admin
	 * @param sUserId
	 * @ejb.business  
	 */
	public com.fundtech.datacomponent.response.SimpleResponseDataComponent getUserData(final Admin admin, java.lang.String sUserId ) ;
	
	/** 
	 * Returns map of profile id to access code
	 * @ejb.business  
	 */
	public Map<String, Map<String,String>> getAccessLevelMap();

}//EOI  