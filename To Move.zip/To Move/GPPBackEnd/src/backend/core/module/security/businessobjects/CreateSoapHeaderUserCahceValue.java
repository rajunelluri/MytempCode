package backend.core.module.security.businessobjects;

import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.cache.entities.WebSessionInfo;
import com.fundtech.cache.infrastructure.CreateCacheValueInterface;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.datacomponent.response.SimpleResponseDataComponent;
import com.fundtech.util.GlobalUtils;

import backend.core.module.security.dataaccess.dao.DAOSecurity;
import backend.dataaccess.dto.DTODataHolder;

public class CreateSoapHeaderUserCahceValue implements CreateCacheValueInterface<WebSessionInfo> {

	private final static Logger logger = LoggerFactory.getLogger(CreateSoapHeaderUserCahceValue.class);
	
	private static final String COLUMN_BANKS_BSNESSDATE = "BSNESSDATE";
	protected static final String COLUMN_USERS_USER_NAME = "USER_NAME";
	protected static final String COLUMN_USERS_OFFICE = "OFFICE";
	protected static final String COLUMN_USERS_DEPARTMENT = "DEPARTMENT";	
	protected static final String COLUMN_USERS_MAX_AMOUNT = "MAX_AMOUNT";
	protected static final String COLUMN_USERS_BUSINESS_AREA = "BUSINESS_AREA";
	protected static final String COLUMN_USERS_MAX_FORCE_AMOUNT = "MAX_FORCE_AMOUNT";
	protected static final String COLUMN_USERS_U_ENT_NAME = "U_ENT_NAME";
	private static final DAOSecurity m_dao = new DAOSecurity() ;

	public WebSessionInfo createCacheValue(Object key) {
		
		boolean[] arrInvalidUserID = new boolean[1];
		
		SimpleResponseDataComponent response = new SimpleResponseDataComponent();
		DTODataHolder dtoUsers = m_dao.getUserData(key.toString());// getUserProfile(key.toString(),arrInvalidUserID);
		
		Feedback feedback = dtoUsers.getFeedBack();
      	dtoUsers.getDataAL();
		final WebSessionInfo webSessionInfo = new WebSessionInfo() ; 
		webSessionInfo.setUserID(key.toString());
		HashMap hmData = dtoUsers.getDataRow();
		
		//String sessionId = generateSessionID(key.toString());
		final String sessionId  = GlobalUtils.generateGUID() ;
		// Office.
		String sOffice = (String) hmData.get(COLUMN_USERS_OFFICE);
		// Department.
		String sDepartment = (String) hmData.get(COLUMN_USERS_DEPARTMENT);
		// Max amount; this might be updated during the 'saveSessionInfo' method.
		String sMaxAmount = (String) hmData.get(COLUMN_USERS_MAX_AMOUNT);
		// Business area.
		String sBusinessArea = (String) hmData.get(COLUMN_USERS_BUSINESS_AREA);
		// Max amount force NSF.
		String sMaxAmountForceNSF = (String) hmData.get(COLUMN_USERS_MAX_FORCE_AMOUNT);
		// User entitlement name.
		String sUserEntitlementName = (String) hmData.get(COLUMN_USERS_U_ENT_NAME);

		webSessionInfo.setSessionID(sessionId);
		webSessionInfo.setUEntName(sUserEntitlementName);
		webSessionInfo.setMaxAmountForceNSF(sMaxAmountForceNSF);
		webSessionInfo.setDefualtBusinessArea(sBusinessArea);
		webSessionInfo.setMaxAmountForceNSF(sMaxAmount);
		webSessionInfo.setDefaultOffice(sOffice);
		webSessionInfo.setDefaultDepartment(sDepartment);
		webSessionInfo.setExistInDB(true);
		
		Admin.getContextAdmin().setWebSessionInfo(webSessionInfo);
		return webSessionInfo;
	}

}
