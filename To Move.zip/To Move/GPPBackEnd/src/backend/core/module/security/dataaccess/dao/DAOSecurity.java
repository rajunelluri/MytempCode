package backend.core.module.security.dataaccess.dao;

import java.sql.Types;

import com.fundtech.core.general.StatementParameter;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalDateTimeUtil;

import backend.core.module.genservices.dataaccess.dao.DAOGeneralServices;
import backend.dataaccess.dto.DTOBoolean;
import backend.dataaccess.dto.DTODataHolder;
import backend.dataaccess.dto.DTOSingleValue;
import backend.services.cache.ASCacheFactory;

/**
 * Title:       DAOSecurity
 * Description: Data access object which provides security services
 * Company:     Fundtech Israel
 * Author:      Asaf Levy
 * Date:        02/05/05
 * @version     1.0
 */
public class DAOSecurity extends DAOGeneralServices
{
  /**
   * Returns DTODataHolder for user data from the USERS table.
   */
  public DTODataHolder getUserData(String sUserID) {
      
   return this.getUserData(sUserID, null, false) ; 
  }//EOM
  
  /**
   * @param bUseEntitlementName is required as a security measure to ensure that even if the name is null 
   * and the bUseEntitlementName flag is true, it should be used !
   * 
   * @return DTODataHolder for user data from the USERS table.
   */
  public DTODataHolder getUserData(String sUserID, String sUserEntitlementName, boolean bUseEntitlementName)
  {
      final String GET_USER_DATA_SELECT_STATEMENT = "SELECT USERS.*, USER_ENTITLEMENT.U_ENT_NAME " +
      "FROM USERS INNER JOIN " +
      "USER_ENTITLEMENT ON " +
      "USER_ENTITLEMENT.U_ENT_NAME = USERS.U_ENT_NAME " +
      "WHERE UPPER(USER_ID) = ? " ;   
  
    String sFinalSelectStatement = GET_USER_DATA_SELECT_STATEMENT ;
    int iArrLength = 1 ; 
    StatementParameter[] arrStatementParameters = null ; 
        
    if(bUseEntitlementName) { 
        sFinalSelectStatement = sFinalSelectStatement +  " AND U_ENT_NAME = ?" ;  
        iArrLength = 2 ; 
        arrStatementParameters = new StatementParameter[iArrLength] ;
        arrStatementParameters[1] = new StatementParameter(sUserEntitlementName, Types.NUMERIC) ;
    }else { 
        arrStatementParameters = new StatementParameter[iArrLength] ;
    }//EO if the userEntitlement should not be used 
    
    arrStatementParameters[0] = new StatementParameter(sUserID, Types.VARCHAR);
    
    return getData(sFinalSelectStatement, arrStatementParameters, -1/*noOfRows -- as many as possible*/);
  }//EOM
  
  /**
   * Returns DTODataHolder for department data.
   * @param sPERM_PROF_DEPARTMENT list of department codes separated by commas.
   */
  public DTODataHolder getDepartmentData(String sPERM_PROF_DEPARTMENT)
  {
      String query = java.text.MessageFormat.format(
              "SELECT DEPARTMENT.OFFICE, DEPARTMENT.NCC, DEPARTMENT.DEPARTMENTCODE, DEPARTMENT.DESCRIPTION, BANKS.CUST_CODE, CUSTOMRS.SWIFT_ID FROM DEPARTMENT, BANKS, CUSTOMRS WHERE DEPARTMENTCODE in ({0}) and BANKS.OFFICE(+) = DEPARTMENT.OFFICE and CUSTOMRS.CUST_CODE(+) = BANKS.CUST_CODE and DEPARTMENT.REC_STATUS = ''AC''",
              sPERM_PROF_DEPARTMENT);
    return getData(query, 0);
  }
  
  /**
   * Returns DTODataHolder for user entitlement data from the USER_ENTITLEMENT table.
   * @param sUserEntitlementName user entitlement name.
   */
  public DTODataHolder getUserEntitlementData(String sUserEntitlementName)
  {
    final String GET_USER_ENTITLEMENT_DATA_SELECT_STATEMENT = "SELECT * FROM USER_ENTITLEMENT WHERE U_ENT_NAME = ?";
  
    StatementParameter[] arrParameters = new StatementParameter[1];
    arrParameters[0] = new StatementParameter();
    arrParameters[0].init(sUserEntitlementName, Types.VARCHAR);
    
    return getData(GET_USER_ENTITLEMENT_DATA_SELECT_STATEMENT, arrParameters, -1/*NoOfRows --> no limit*/);
  }
  
  /**
   * Returns DTODataHolder for user vacation data from the USER_VACATION table.
   * @param sUserID user ID.
   */
  public DTODataHolder getUserVacationData(String sUserID)
  {
    final String GET_USER_VACATION_DATA_SELECT_STATEMENT = 
            "SELECT TO_CHAR(V_START_DATE, '" + SQL_FORMAT_DATE + "') AS V_START_DATE, " +
            "TO_CHAR(V_END_DATE, '" + SQL_FORMAT_DATE + "') AS V_END_DATE " +
            "FROM USER_VACATION WHERE UPPER(USER_ID) = ? AND REC_STATUS = 'AC'";
  
    StatementParameter[] arrParameters = new StatementParameter[1];
    arrParameters[0] = new StatementParameter(sUserID, Types.VARCHAR);
    
    return getData(GET_USER_VACATION_DATA_SELECT_STATEMENT, arrParameters, 0);
  }
  
  /**
   * Sets the passed user ID as suspended.
   */
  public Feedback setUserAsSuspended(String sUserID, String sLoginFailuresCount)
  {
    final String SET_USER_AS_SUSPENDED_UPDATE_STATEMENT = 
            "UPDATE USERS " +
            "SET SUSPENDED = '1', TEMPPASSWD = '1', BAD_LOGIN = ? " +
            "WHERE UPPER(USER_ID) = ?";
  
    StatementParameter[] arrParameters = new StatementParameter[2];
    arrParameters[0] = new StatementParameter();
    arrParameters[0].init(sLoginFailuresCount, Types.NUMERIC);
    
    arrParameters[1] = new StatementParameter(sUserID, Types.VARCHAR);
    
    return super.update(SET_USER_AS_SUSPENDED_UPDATE_STATEMENT, arrParameters, null, null, false, false, null);
  }
  
  /**
   * Checks if the passed user ID & password combination exists in the OLDPSWDS table.
   */
  public DTOBoolean doesPasswordExistInOLDPSWDS_Table(String sUserID, String sEncryptedPassword)
  {
    final String SELECT_STATEMENT = "SELECT COUNT(1) FROM OLDPSWDS " +
                                    "WHERE UPPER(USER_ID) = ? AND USERPASSWD = ?";
  
    StatementParameter[] arrParameters = new StatementParameter[2];
    arrParameters[0] = new StatementParameter(sUserID, Types.VARCHAR);
    arrParameters[1] = new StatementParameter(sEncryptedPassword, Types.VARCHAR);
    DTOSingleValue dtoSingleValue = isRecordExist(SELECT_STATEMENT, arrParameters);
    DTOBoolean dtoBoolean=new DTOBoolean();
    if(dtoSingleValue.isFeedBackSuccess() && !dtoSingleValue.isEmpty())
    {
        dtoBoolean.setValue(!dtoSingleValue.getValue().equals(GlobalConstants.ZERO_VALUE));
    }
    else
    {
        dtoBoolean.setFeedback(dtoSingleValue.getFeedBack());
    }
    
    return dtoBoolean;
  }

  /**
   * Updates the OLDPSWDS table.
   */
  public Feedback updateOLDPSWDS_Table(String sUserID, String sUserPassword,
                                       String sPasswordDate, String sPasswordTime)
  {
	//Explicit cast of the to date bound parameter to its respective datatype is 
	//mandatory in DB2 and supported in oracle
    final String INSERT_STATEMENT = "INSERT INTO OLDPSWDS (USER_ID, USERPASSWD, PASSWDDATE, PASSWDTIME, FPRINT) " +
                                    "VALUES(?, ?, TO_DATE(?, 'yyyy-MM-dd'), ?, NULL) ";
  
    StatementParameter[] arrParameters = new StatementParameter[4];
    arrParameters[0] = new StatementParameter(sUserID, Types.VARCHAR);
    arrParameters[1] = new StatementParameter(sUserPassword, Types.VARCHAR);
    arrParameters[2] = new StatementParameter(sPasswordDate, Types.VARCHAR);
    arrParameters[3] = new StatementParameter(sPasswordTime, Types.VARCHAR);
    
    return super.update(INSERT_STATEMENT, arrParameters, null, null, false, false, null);
  }
  
  /**
   * Checks if the user ID is already logged in through the WEB.
   */
  public DTOBoolean userIsAlreadyLoggedIn(String sUserID, Float fWebUserAlive)
  {
	//SYSDATE is a proprietary keyword reserved to oracle. Replaced with runtime determined value. 
    final String SELECT_STATEMENT = "SELECT COUNT(1) FROM USERS " +
                                    "WHERE UPPER(USER_ID) = ? AND LOGGED_IN > 1 AND " + 
                                    ms_DBType.getCurrTsDiffSecs("USERS.CHECKDATE_WEB") + " < ";
    
    final String SELECT_USERS_STATEMENT = "SELECT COUNT(1) FROM USERS " +
                                    "WHERE UPPER(USER_ID) = ? ";
        
    
    String sUserIsAlreadyLoggedInStatement = 
                 new StringBuffer(SELECT_STATEMENT).append(fWebUserAlive).toString();
  
    StatementParameter[] arrParameters = new StatementParameter[1];
    arrParameters[0] = new StatementParameter(sUserID, Types.VARCHAR);
    
    return isRecordExistToBoolean(sUserIsAlreadyLoggedInStatement, arrParameters);   
  }
  
  
  /**
   * Checks if the user Id exists in DB
   */
  public DTOBoolean isUserInDB(String sUserID)
  {
	
    final String SELECT_USERS_STATEMENT = "SELECT COUNT(1) FROM USERS " +
                                    "WHERE UPPER(USER_ID) = ? ";
               
             
    StatementParameter[] arrParameters = new StatementParameter[1];
    arrParameters[0] = new StatementParameter(sUserID, Types.VARCHAR);
    
    return isRecordExistToBoolean(SELECT_USERS_STATEMENT, arrParameters);   
  }
  
  /**
   * NOTE: This method is also called from the EntitlementsDataFactory class.
   *       
   * Returns the access profile data for the passed access profile.
   */
  public DTODataHolder getUserAccessProfileData(String sAccessProfile)
  {
    final String GET_ACCESS_PROFILE_DATA_SELECT_STATEMENT_DEPLOYMENT_MODE = 
             "SELECT FIELD_NAME, PERMISIONTYPE FROM ACCESSPROFILEVIEW WHERE ACCS_PROF = ? ORDER BY FIELD_NAME";
    
    //Modified the statement to conform to ANSI 92 by converting the (+) oracle join sign to a JOIN Structure
    //whereby (+) sign on the left would be converted into a right join 
    //and (+) sign on the right would be converted into a left join
    final String GET_ACCESS_PROFILE_DATA_SELECT_STATEMENT_DEVELOPMENT_MODE = 
             "SELECT ACCS_LVL.FIELD_NAME, APROFILE.PERMISIONTYPE FROM ACCS_LVL LEFT JOIN APROFILE " +
             "ON ACCS_LVL.FIELD_NAME = APROFILE.FIELD_NAME " + 
             "WHERE ACCS_PROF = ? ORDER BY FIELD_NAME" ; 
        
    String sSelectStatement = null;
    
    StatementParameter[] arrParameters = new StatementParameter[1];
    arrParameters[0] = new StatementParameter(sAccessProfile, Types.VARCHAR);
    

	// Workaround to provide developers with a full view of the menu tree regardless of 
    // the profile access level being active or inactive
    if(ASCacheFactory.isDevelopmentState())
    {
      sSelectStatement = GET_ACCESS_PROFILE_DATA_SELECT_STATEMENT_DEVELOPMENT_MODE ;
    }
    else
    {
      sSelectStatement = GET_ACCESS_PROFILE_DATA_SELECT_STATEMENT_DEPLOYMENT_MODE ; 
    } 
       
    return getData(sSelectStatement, arrParameters, -1/*noOfRows no limit*/);
  }
  
  /**
   * NOTE: This method is also called from the EntitlementsDataFactory class.
   *       
   * Returns the department profile data for the passed department profile.
   */
  public DTODataHolder getUserDepartmentProfileData(String sDepartmentProfile)
  {
    final String GET_DEPARTMENT_PROFILE_DATA_SELECT_STATEMENT = 
             "SELECT OFFICE, PERMISIONTYPE FROM BPROFILE WHERE BANK_PROF = ? ORDER BY OFFICE";
  
    StatementParameter[] arrParameters = new StatementParameter[1];
    arrParameters[0] = new StatementParameter(sDepartmentProfile, Types.VARCHAR);
    
    return getData(GET_DEPARTMENT_PROFILE_DATA_SELECT_STATEMENT, arrParameters, -1/*noOfRows no limit*/);
  }
  
  /**
   * NOTE: This method is also called from the EntitlementsDataFactory class.
   *       
   * Returns the approve access levels for the passed access profile.
   */
  public DTODataHolder getApproveAccessLevelsData(String sAccessProfile)
  {
	//Derives the char conversion keyword dynamically from the database type Enum
    final String SELECT_STATEMENT = 
                 "SELECT FIELD_NAME FROM aprofile X, " +
                 "( SELECT DISTINCT APPROVE_ACCS_LVL " +
                 "FROM profile_ctrl WHERE PROFILE_CTRL.APPROVE_ACCS_LVL IS NOT NULL) A WHERE " +
				 ms_DBType.getToCharValue()+" (A.APPROVE_ACCS_LVL) = X.field_name " +
				 "AND ACCS_PROF = ? " +
				 "ORDER BY A.APPROVE_ACCS_LVL";

    StatementParameter[] arrParameters = new StatementParameter[1];
    arrParameters[0] = new StatementParameter(sAccessProfile, Types.VARCHAR);
    
    return getData(SELECT_STATEMENT, arrParameters, -1/*noOfRows no limit*/);
  }
  
  /**
   * NOTE: This method is also called from the EntitlementsDataFactory class.
   *       
   * Returns the message profile data for the passed message profile.
   */
  public DTODataHolder getUserMessageProfileData(String sMessageProfile)
  {
    final String GET_MESSAGE_PROFILE_DATA_SELECT_STATEMENT = 
             "SELECT TRIM(MSG_TYPE) MSG_TYPE, TRIM(MSGSUBTYPE) MSGSUBTYPE, PERMISIONTYPE FROM MPROFILE " +
             "WHERE MSG_PROF = ? " +
             "ORDER BY MOP";
  
    StatementParameter[] arrParameters = new StatementParameter[1];
    arrParameters[0] = new StatementParameter(sMessageProfile, Types.VARCHAR);
    
    return getData(GET_MESSAGE_PROFILE_DATA_SELECT_STATEMENT, arrParameters, -1/*noOfRows no limit*/);
  }
  
  /**
   * NOTE: This method is also called from the EntitlementsDataFactory class.
   *       
   * Returns the queue profile data for the passed queue profile.
   */
  public DTODataHolder getUserQueueProfileData(String sQueueProfile)  
  {
    final String GET_QUEUE_PROFILE_DATA_SELECT_STATEMENT = 
         "SELECT ST.FIELD_NAME AS MSG_STATUS, QPROFILE.PERMISIONTYPE AS PERMISIONTYPE , USERDEFINE FROM (SELECT 0 AS USERDEFINE, MSG_STATUS  AS FIELD_NAME, ALIAS AS DESCRIPT FROM STATUSES WHERE (ACTIVEQUEUE <> 0) AND STATUSES.Userdefine = 0 UNION ALL "+
        "SELECT 1 AS USERDEFINE, RULE_NAME AS FIELD_NAME, RULE_NAME AS DESCRIPT FROM PRULES WHERE RULE_TYPE_ID = 2 AND REC_STATUS = 'AC') ST, QPROFILE WHERE FIELD_NAME = QPROFILE.MSG_STATUS and MSG_STATUS = FIELD_NAME AND PROFILE = ? ORDER BY FIELD_NAME";

    
    

    StatementParameter[] arrParameters = new StatementParameter[1];
    arrParameters[0] = new StatementParameter(sQueueProfile, Types.VARCHAR);
    
    return getData(GET_QUEUE_PROFILE_DATA_SELECT_STATEMENT, arrParameters, -1/*noOfRows no limit*/);
  }
  
  public DTODataHolder getNonMenuProfilesData()
  {
    final String SELECT_STATEMENT = 
        "SELECT DISTINCT PROFILE_ID, SCREEN_ALIAS  FROM SD_PROFILES WHERE PROFILE_ID NOT IN (SELECT ITEM_ID FROM MENU_ITEMS WHERE ITEM_TYPE = 'PROFILE_CTRL') ORDER BY PROFILE_ID";

	  return getData(SELECT_STATEMENT, 0);
  }
  public DTODataHolder getUserRuleTypeProfileData(String sRuleType)  
  {
       final String GET_RULE_TYPE_LEVEL_PROFILE_DATA_SELECT_STATEMENT = 
                 "SELECT PRULE_TYPE_PROFILES.RULE_TYPE_ID, PERMISIONTYPE, SYSTEM_IND FROM PRULE_TYPES, PRULE_TYPE_PROFILES " +
                 "WHERE RULE_TYPE_PROF = ? " +
                 "AND PRULE_TYPES.RULE_TYPE_ID = PRULE_TYPE_PROFILES.RULE_TYPE_ID " +
                 "ORDER BY PRULE_TYPE_PROFILES.RULE_TYPE_ID";       
      
        StatementParameter[] arrParameters = new StatementParameter[1];
        arrParameters[0] = new StatementParameter(sRuleType, Types.VARCHAR);
        
        return getData(GET_RULE_TYPE_LEVEL_PROFILE_DATA_SELECT_STATEMENT, arrParameters, -1/*noOfRows no limit*/);
  }//getUserRuleTypeProfileData
  
  /**
   * NOTE: This method is also called from the EntitlementsDataFactory class.
   *       
   * Returns the alert profile data for the passed alert profile and user ID.
   */
  public DTODataHolder getUserAlertProfileData(String sAlertProfile, String sUserID)  
  {
    final String GET_ALERT_PROFILE_DATA_SELECT_STATEMENT_1 = 
             "SELECT ALERTS_UID FROM ALERT_PROFILES WHERE ALERT_PROFILE_NAME = ? ";
             
    final String GET_ALERT_PROFILE_DATA_SELECT_STATEMENT_2 =             
             "UNION " +
             "SELECT ALERTS_UID FROM USER_ALERTS WHERE UPPER(USER_ID) = ? " +
             "ORDER BY ALERTS_UID";
    
    StatementParameter[] arrParameters = null;
    StringBuffer sbSelectStatement = new StringBuffer(GET_ALERT_PROFILE_DATA_SELECT_STATEMENT_1);
    
    if(sUserID != null)
    {
      arrParameters = new StatementParameter[2];
      arrParameters[0] = new StatementParameter(sAlertProfile, Types.VARCHAR);
      arrParameters[1] = new StatementParameter(sUserID, Types.VARCHAR);
      
      sbSelectStatement.append(GET_ALERT_PROFILE_DATA_SELECT_STATEMENT_2);
    }
    
    else
    {
      arrParameters = new StatementParameter[1];
      arrParameters[0] = new StatementParameter(sAlertProfile, Types.VARCHAR);
    }
    
    return getData(sbSelectStatement.toString(), arrParameters, -1/*noOfRows no limit*/);
  }
  
  /**
   * Returns the business area options for the passed user ID.
   */
  public DTODataHolder getUserBusinessAreaOptions(String sUserID)  
  {
    final String GET_BA_OPTIONS_SELECT_STATEMENT = 
             "SELECT BUSINESS_AREA FROM USER_BUSINESS_AREAS WHERE UPPER(USER_ID) = ? ORDER BY BUSINESS_AREA";
    
    StatementParameter[] arrParameters = new StatementParameter[1];
    arrParameters[0] = new StatementParameter(sUserID, Types.VARCHAR);
    
    return getData(GET_BA_OPTIONS_SELECT_STATEMENT, arrParameters, -1/*NoOfRows --> no limit*/);
  }
  
  /**
   * Cleans the WEB_PROFILE_LOCK table from records with the passed user ID. 
   */ 
  public final Feedback cleanUserIDExistingLockRecords(final String sUserID){
    
    final String WEB_PROFILE_LOCK_DELETE_STATEMENT = "DELETE FROM WEB_PROFILE_LOCK WHERE UPPER(USER_ID) = ?" ; 
        
    final StatementParameter[] arrParameters = {  new StatementParameter(sUserID, Types.VARCHAR) }; 
    
    Feedback feedback = doDelete(WEB_PROFILE_LOCK_DELETE_STATEMENT, arrParameters, null, null);
    
    if(!feedback.isSuccessful())  feedback.setUserErrorText(String.format("Failed to prune user %s Static Aata Profile Locks from persistence.", sUserID)) ; 
    
    return feedback ; 
        
  }//EOM 
  
  /**
   * Updates the USERS table with a new bad login count.
   */
  public Feedback updateBadLoginCount(String sUserID, int iBadLoginCount)
  {
    final String SET_BAD_LOGIN_UPDATE_STATEMENT = "UPDATE USERS " +
                                                  "SET BAD_LOGIN = ? " +
                                                  "WHERE UPPER(USER_ID) = ?";
  
    StatementParameter[] arrParameters = new StatementParameter[2];
    arrParameters[0] = new StatementParameter();
    arrParameters[0].init(String.valueOf(iBadLoginCount), Types.NUMERIC);
    
    arrParameters[1] = new StatementParameter(sUserID, Types.VARCHAR);
    
    return super.update(SET_BAD_LOGIN_UPDATE_STATEMENT, arrParameters, null, null, false, false, null);
  }
  
  /**
   * Returns additional data from BANKS table.
   */
  public DTODataHolder getAdditionalDataFromBANKS(String sOffice)  
  {
    final String GET_ADDITIONA_DATA_FROM_BANKS_SELECT_STATEMENT = 
             "SELECT CALNAME, CURRENCY, BSNESSDATE FROM BANKS WHERE OFFICE = ?";
    
    StatementParameter[] arrParameters = new StatementParameter[1];
    arrParameters[0] = new StatementParameter(sOffice, Types.VARCHAR);
    
    return getData(GET_ADDITIONA_DATA_FROM_BANKS_SELECT_STATEMENT, arrParameters, 0);
  }
  
  /**
   * Gets the default value date from CURRENCY_BU. 
   */
  public DTOSingleValue getDefaultValueDateFromCURRENCY_BU(String sCurrency, String sOffice)
  {
    final String SELECT_STATEMENT = "SELECT DEFAULTVALUEDATE FROM CURRENCY_BU WHERE CURRENCY = ? AND OFFICE = ?";
  
    StatementParameter[] arrParameters = new StatementParameter[2];
    arrParameters[0] = new StatementParameter(sCurrency, Types.VARCHAR);
    arrParameters[1] = new StatementParameter(sOffice, Types.VARCHAR);
    
    return getSingleValue(SELECT_STATEMENT, arrParameters, null);
  }
  
  /**
   * NOTE: This method is also called from the EntitlementsDataFactory class'.
   *       
   * Returns user buttons permissions data.
   */
  public DTODataHolder getUserButtonsPermissionsData(String sAccessProfile)
  {
    final String GET_USER_BUTTONS_PERMISSIONS_DATA_SELECT_STATEMENT = 
             "SELECT FIELD_NAME, PERMISIONTYPE FROM ACCESSPROFILEVIEW " +
             "WHERE ACCS_PROF = ? AND FIELD_NAME IN (SELECT ACC_LVL_ID FROM MESSAGEBUTTONS WHERE NVL(TRIM(ACC_LVL_ID),'*') <> '*') ORDER BY FIELD_NAME";
    
    StatementParameter[] arrParameters = new StatementParameter[1];
    arrParameters[0] = new StatementParameter(sAccessProfile, Types.VARCHAR);
    
    return getData(GET_USER_BUTTONS_PERMISSIONS_DATA_SELECT_STATEMENT, arrParameters, -1/*noOfRows no limit*/);
  }
  
  public DTODataHolder getRUseruleTypesPermissionsData(String sAccessProfile)
  {
    final String GET_USER_BUTTONS_PERMISSIONS_DATA_SELECT_STATEMENT = 
             "SELECT FIELD_NAME, PERMISIONTYPE FROM ACCESSPROFILEVIEW " +
             "WHERE ACCS_PROF = ? AND FIELD_NAME IN (SELECT ACC_LVL_ID FROM MESSAGEBUTTONS WHERE NVL(TRIM(ACC_LVL_ID),'*') <> '*') ORDER BY FIELD_NAME";
    
    StatementParameter[] arrParameters = new StatementParameter[1];
    arrParameters[0] = new StatementParameter(sAccessProfile, Types.VARCHAR);
    
    return getData(GET_USER_BUTTONS_PERMISSIONS_DATA_SELECT_STATEMENT, arrParameters, 0);
  }//getRUseruleTypesPermissionsData
  
  /**
   * NOTE: This method is also called from the EntitlementsDataFactory class.
   *       
   * Returns the office permissions for the passed department list.
   */
  public DTODataHolder getUserOfficePermissionsData(String sPERM_PROF_DEPARTMENT)
  {
    final String GET_USER_OFFICE_PERMISSIONS_DATA_SELECT_STATEMENT = 
                                    "SELECT DISTINCT OFFICE FROM DEPARTMENT " +
                                    "WHERE DEPARTMENTCODE IN (" + sPERM_PROF_DEPARTMENT + ") ORDER BY OFFICE";

    return getData(GET_USER_OFFICE_PERMISSIONS_DATA_SELECT_STATEMENT, 0);
  }
  
  /**
   * Returns the office permissions for the passed department list.
   * 
   * TODO - remove 2nd parameter implementing FTEncryptor call.
   */
  public Feedback updateUSERS_TableForLogin(String sUserID)
  {
	//Explicit cast of the to date bound parameter to its respective datatype is 
	//mandatory in DB2 and supported in oracle
    String USERS_TABLE_UPDATE_STATEMENT = 
                 "UPDATE USERS " +
                 "SET LOGGED_IN = 2, BAD_LOGIN = 0, LASTLOGIN_DATE = TO_DATE(? , 'MM/DD/YYYY HH24:MI:SS'), " +
                 "CHECKDATE_WEB = TO_DATE(? , 'MM/DD/YYYY HH24:MI:SS') " +
                 "WHERE UPPER(USER_ID) = ?";
  
    
    
    String sSystemDate = getSystemDateAndTimeFromDatabase();
    sSystemDate = GlobalDateTimeUtil.getFormattedDateString(sSystemDate, GlobalDateTimeUtil.STATIC_DATA_DATE_TIME, GlobalDateTimeUtil.STATIC_DATA_DATE_TIME_2);

   final StatementParameter[] arrParameters = { 
			new StatementParameter(sSystemDate, Types.VARCHAR), 
			new StatementParameter(sSystemDate, Types.VARCHAR), 
			new StatementParameter(sUserID, Types.VARCHAR)
		}; 
    
    return super.update(USERS_TABLE_UPDATE_STATEMENT, arrParameters, null, null, false, false, null);
  }
  
  public Feedback setUserLoggedIn(String sUserId)
  { 
    return this.setUserLoggedIn(sUserId, null) ; 
  }//EOM
  
  public Feedback setUserLoggedIn(String sUserId, int[] arrAffectedRows) { 
	  //Explicit cast of the to date bound parameter to its respective datatype is 
	  //mandatory in DB2 and supported in oracle
	  //Logged in value was converted into an integer as DB2 is data type intolerant  
      final String UPDATE_QUERY = "UPDATE USERS SET LOGGED_IN = 2, LASTLOGIN_DATE = TO_DATE(? , 'MM/DD/YYYY HH24:MI:SS'), " +
      		"CHECKDATE_WEB = TO_DATE(?, 'MM/DD/YYYY HH24:MI:SS') WHERE UPPER(USER_ID) = ?" ;
      
      StatementParameter[] arrParameters = new StatementParameter[3];
      
      String sSystemDate = getSystemDateAndTimeFromDatabase();
      sSystemDate = GlobalDateTimeUtil.getFormattedDateString(sSystemDate, GlobalDateTimeUtil.STATIC_DATA_DATE_TIME, GlobalDateTimeUtil.STATIC_DATA_DATE_TIME_2);
      
      arrParameters[0] = new StatementParameter(sSystemDate, Types.VARCHAR);
      arrParameters[1] = new StatementParameter(sSystemDate, Types.VARCHAR);
           
      arrParameters[2] = new StatementParameter(sUserId, Types.VARCHAR);
      
      return super.update(UPDATE_QUERY, arrParameters, arrAffectedRows, null, false, false, null);
  }//EOM
  
  public Feedback setActiveUserLoggedIn(String sUserId, int[] arrAffectedRows) { 
	  //Explicit cast of the to date bound parameter to its respective datatype is 
	  //mandatory in DB2 and supported in oracle
	  //Logged in value was converted into an integer as DB2 is data type intolerant  
      final String UPDATE_QUERY = "UPDATE USERS SET LOGGED_IN = 2, LASTLOGIN_DATE = TO_DATE(? , 'MM/DD/YYYY HH24:MI:SS'), " +
      		"CHECKDATE_WEB = TO_DATE(?, 'MM/DD/YYYY HH24:MI:SS') WHERE UPPER(USER_ID) = ? AND SUSPENDED = 0 AND REC_STATUS='AC'" ;
      
      StatementParameter[] arrParameters = new StatementParameter[3];
      
      String sSystemDate = getSystemDateAndTimeFromDatabase();
      sSystemDate = GlobalDateTimeUtil.getFormattedDateString(sSystemDate, GlobalDateTimeUtil.STATIC_DATA_DATE_TIME, GlobalDateTimeUtil.STATIC_DATA_DATE_TIME_2);
      
      arrParameters[0] = new StatementParameter(sSystemDate, Types.VARCHAR);
      arrParameters[1] = new StatementParameter(sSystemDate, Types.VARCHAR);
           
      arrParameters[2] = new StatementParameter(sUserId, Types.VARCHAR);
      
      return super.update(UPDATE_QUERY, arrParameters, arrAffectedRows, null, false, false, null);
  }//EOM
  
  public DTOBoolean isUserSuspended(String sUserId) {
	  final String SELECT_STATEMENT_FOR_IS_USER_SUSPENDED =  "SELECT COUNT(1) FROM USERS WHERE UPPER(USER_ID) = ? AND (SUSPENDED = 1 OR REC_STATUS <> 'AC' )";
		StatementParameter[] arrParameters = new StatementParameter[1];

		arrParameters[0] = new StatementParameter(sUserId, Types.VARCHAR);

		return isRecordExistToBoolean(SELECT_STATEMENT_FOR_IS_USER_SUSPENDED, arrParameters);
	}
  
  /**
   * Gets the static data profiles preferences for this user ID.
   */
  public DTODataHolder getStaticDataProfilesUserPrefs(String sUserID)
  {
    final String GET_STATIC_DATA_PROFILES_PREFERENCES_SELECT_STATEMENT = 
                       "SELECT DATA_TYPE, LAYOUT_POSITION, FILTER_FIELDS, ADDITIONAL_DATA FROM USERS_EXTRA_DATA WHERE DATA_TYPE LIKE 'STP_%' AND UPPER(USER_ID) = ?";
    
    StatementParameter[] arrParameters = new StatementParameter[1];
    arrParameters[0] = new StatementParameter(sUserID, Types.VARCHAR);
    
    return getData(GET_STATIC_DATA_PROFILES_PREFERENCES_SELECT_STATEMENT, arrParameters, 0);
  }
  
  /**
   * Gets the queue explorer open folders IDs for this user ID.
   */
  public DTOSingleValue getQExplorerOpenedFoldersIDs(String sUserID)
  {
    final String SELECT_STATEMENT = "SELECT ADDITIONAL_DATA FROM USERS_EXTRA_DATA WHERE DATA_TYPE ='EN_frmQExplorer' and UPPER(USER_ID) = ?";
  
    StatementParameter[] arrParameters = new StatementParameter[1];
    arrParameters[0] = new StatementParameter(sUserID, Types.VARCHAR);
    
    return getSingleValue(SELECT_STATEMENT, arrParameters, null);
  }
  
  /**
   * Gets the windows layout positions data for this user ID.
   */
  public DTODataHolder getWindowsLayoutPositionData(String sUserID)
  {
    final String GET_WINDOWS_LAYOUT_POSITION_DATA_SELECT_STATEMENT = 
                       "SELECT DATA_TYPE, LAYOUT_POSITION FROM USERS_EXTRA_DATA WHERE DATA_TYPE LIKE 'WP_%' AND UPPER(USER_ID) = ?";
    
    // ASAF - USE THIS QUERY IF INSTEAD OF THE ABOVE YOU WANT THE QUEUE LIST  
    //        FLOATING WINDOWS TO BE SENT AS WELL TO THE BROWSER.
    //final String GET_WINDOWS_LAYOUT_POSITION_DATA_SELECT_STATEMENT = 
    //                "SELECT DATA_TYPE, LAYOUT_POSITION FROM USERS_EXTRA_DATA WHERE (DATA_TYPE LIKE 'WP_%' OR DATA_TYPE LIKE '%_FL%') AND UPPER(USER_ID) = ?";
    
    StatementParameter[] arrParameters = new StatementParameter[1];
    arrParameters[0] = new StatementParameter(sUserID, Types.VARCHAR);
    
    return getData(GET_WINDOWS_LAYOUT_POSITION_DATA_SELECT_STATEMENT, arrParameters, 0);
  }
  
  /**
   * Returns the generic search filter method for this rule ID.
   */
  public DTOSingleValue getGenericSearchFilterMethod(String sRuleID)  
  {
    final String SELECT_STATEMENT = "SELECT RULEMETHOD FROM UDRULE WHERE RULEID = ?";
  
    StatementParameter[] arrParameters = new StatementParameter[1];
    arrParameters[0] = new StatementParameter(sRuleID, Types.VARCHAR);
    
    return getSingleValue(SELECT_STATEMENT, arrParameters, null);
  }
  
  /**
   * Returns the default business date for this office.
   */
  @Override
  public DTOSingleValue getDefaultBusinessDate(final String sOffice)
  {
    final String SELECT_STATEMENT = "SELECT TO_CHAR(BSNESSDATE,'YYYY-MM-DD') FROM BANKS WHERE OFFICE = ?";
  
    StatementParameter[] arrParameters = new StatementParameter[1];
    arrParameters[0] = new StatementParameter(sOffice, Types.VARCHAR);
    
    return getSingleValue(SELECT_STATEMENT, arrParameters, null);
  }
  
  /**
   * Returns the office permissions for the passed department list.
   */
  public Feedback updateUSERS_TableForLogout(String sUserID)
  {
	//Modified the logged_in value to numeric as DB2 is datatype intolerant. 
    String USERS_TABLE_UPDATE_STATEMENT = 
                 "UPDATE USERS " +
                 "SET LOGGED_IN = 0 " +
                 "WHERE UPPER(USER_ID) = ?";
  
    StatementParameter[] arrParameters = new StatementParameter[1];
    arrParameters[0] = new StatementParameter(sUserID, Types.VARCHAR);
    
    return super.update(USERS_TABLE_UPDATE_STATEMENT, arrParameters, null, null, false, false, null);
  }

  
  /**
   * Updates the USERS.CHECKDATE_WEB column.
   */
  public Feedback updateCHECKDATE_WEB(String sUserID)
  {
    final String UPDATE_USERS_CHECKDATE_WEB_STATEMENT = 
                   "UPDATE USERS SET CHECKDATE_WEB = TO_DATE(? , 'MM/DD/YYYY HH24:MI:SS') WHERE UPPER(USER_ID) = ?";
  
    StatementParameter[] arrParameters = new StatementParameter[2];
    
    String sSystemDate = getSystemDateAndTimeFromDatabase();
    sSystemDate = GlobalDateTimeUtil.getFormattedDateString(sSystemDate, GlobalDateTimeUtil.STATIC_DATA_DATE_TIME, GlobalDateTimeUtil.STATIC_DATA_DATE_TIME_2);
    
    arrParameters[0] = new StatementParameter(sSystemDate, Types.VARCHAR);
    arrParameters[1] = new StatementParameter(sUserID, Types.VARCHAR);
    
    return super.update(UPDATE_USERS_CHECKDATE_WEB_STATEMENT, arrParameters, null, null, false, false, null);
  }
  
  /**
   * Get num of times user changed his password today.
   * @param sUserId
   * @return Num of password changed today for specific user
   */
  public DTOSingleValue  getNumUserPasswordsChangesToday(String sUserId) 
  {
	 //Explicit cast of the to date bound parameter to its respective datatype is 
	 //mandatory in DB2 and supported in oracle 
	final String GET_NUM_PASSWD_CHANGED_STATEMENT = 
		"SELECT COUNT(1) FROM OLDPSWDS WHERE PASSWDDATE = TO_DATE(? ,'YYYY/MM/DD')  AND UPPER(USER_ID) = ?";

	String sSystemDate = getFormattedSystemDateFromDatabase(null, GlobalDateTimeUtil.DATE_FORMAT_4);
	
	StatementParameter[] arrParameters = new StatementParameter[2];
	arrParameters[0] = new StatementParameter(sSystemDate, Types.VARCHAR);
	arrParameters[1] = new StatementParameter(sUserId, Types.VARCHAR);
	
	return getSingleValue(GET_NUM_PASSWD_CHANGED_STATEMENT, arrParameters, null);  
  }
  
  /**
   * Deletes an old passwords from OLDPSWDS table.
   */
  public Feedback deleteOldPasswordsFromOLDPSWDS_Table(String sUserID, String sOldPasswordDate,
                                                       String sOldPasswordTime)
  {
	final String DELETE_STATEMENT = "DELETE FROM OLDPSWDS WHERE UPPER(USER_ID) = ? AND " +
	                                "PASSWDDATE = TO_DATE(?, 'yyyy-MM-dd') AND " +
	                                "PASSWDTIME = ?";
	
	StatementParameter[] arrParameters = new StatementParameter[3];
	arrParameters[0] = new StatementParameter(sUserID, Types.VARCHAR);
	arrParameters[1] = new StatementParameter(sOldPasswordDate, Types.VARCHAR);
	arrParameters[2] = new StatementParameter(sOldPasswordTime, Types.VARCHAR);
	
    return update(DELETE_STATEMENT, arrParameters, null, null, false, false, null);
  }
  
  /**
   *  get PK from OLDPSWDS table
   */
  public DTODataHolder get_OLDPSWDS_Data(String sUserId) 
  {
    final String SELECT_STATEMENT = "SELECT TO_CHAR(PASSWDDATE, '" + SQL_FORMAT_DATE + "') AS PASSWDDATE, PASSWDTIME FROM OLDPSWDS WHERE UPPER(USER_ID) = ? ORDER BY PASSWDDATE ASC, PASSWDTIME ASC";
	  
  	StatementParameter[] arrParameters = new StatementParameter[1];
	arrParameters[0] = new StatementParameter(sUserId, Types.VARCHAR);
		
	return getData(SELECT_STATEMENT, arrParameters);
  }

	/**
	 * Update USERS table when change password was perfromed
	 * @param sUserId
	 * @param sNewPassword
	 * @param sPasswordDate
	 * @param sPasswordTime
	 * @param sTempPassword
	 * @return feedback according to result from the DB
	 */
	public Feedback updateUSERS_TableForChangePassword(String sUserId, String sNewPassword,
			                    String sPasswordDate, String sPasswordTime, String sTempPassword) 
    {
		 //Explicit cast of the to date bound parameter to its respective datatype is 
		 //mandatory in DB2 and supported in oracle
	    String USERS_TABLE_UPDATE_STATEMENT = 
	                 "UPDATE USERS " +
	                 "SET USERPASSWD = ?, PASSWDDATE = TO_DATE(? , 'yyyy-MM-dd'), TIME= ? ,TEMPPASSWD = ? " +
	                 " WHERE UPPER(USER_ID) = ?";
	  
	    StatementParameter[] arrParameters = new StatementParameter[5];
	    arrParameters[0] = new StatementParameter(sNewPassword, Types.VARCHAR);
	    arrParameters[1] = new StatementParameter(sPasswordDate, Types.VARCHAR);
	    arrParameters[2] = new StatementParameter(sPasswordTime, Types.VARCHAR);
	    arrParameters[3] = new StatementParameter(sTempPassword, Types.NUMERIC);
	    arrParameters[4] = new StatementParameter(sUserId, Types.VARCHAR);
	    
	    return update(USERS_TABLE_UPDATE_STATEMENT, arrParameters, null, null, false, false, null);
	}
    
    
    public Feedback insertSsoUserRecrod(String sUserId, String sUserEntitlementName) { 
        
    	final String INSERT_SSO_USER_RECROD_QUERY = "INSERT INTO USERS\r\n" + 
    			"  (PASSPENDBY,\r\n" + 
    			"   REC_STATUS,\r\n" + 
    			"   PROFILE_CHANGE_STATUS,\r\n" + 
    			"   CHECKDATE,\r\n" + 
    			"   ALERT_LEVEL_PROFILE_ID,\r\n" + 
    			"   PASSWDDATE,\r\n" + 
    			"   FEDNSFTHRS,\r\n" + 
    			"   MAX_FORCE_AMT_APPROVE,\r\n" + 
    			"   PHONE_NO,\r\n" + 
    			"   MSGPENDBY,\r\n" + 
    			"   U_ENT_NAME,\r\n" + 
    			"   QUEPENDBY,\r\n" + 
    			"   USER_ID,\r\n" + 
    			"   FPRINT,\r\n" + 
    			"   LASTLOGIN_DATE,\r\n" + 
    			"   CHECKTIME,\r\n" + 
    			"   BNKPENDBY,\r\n" + 
    			"   MXAMAPPROVE,\r\n" + 
    			"   USER_NAME,\r\n" + 
    			"   MAX_FORCE_AMOUNT,\r\n" + 
    			"   LOGGED_IN,\r\n" + 
    			"   OFFICE,\r\n" + 
    			"   MXAMPENDBY,\r\n" + 
    			"   TEMPPASSWD,\r\n" + 
    			"   EMP_TYPE,\r\n" + 
    			"   PASSAPPROVE,\r\n" + 
    			"   CHECKDATE_WEB,\r\n" + 
    			"   MESSAGEAPPROVE,\r\n" + 
    			"   PASSWORD_CHANGE,\r\n" + 
    			"   MIDDLE_NAME,\r\n" + 
    			"   USERPASSWD,\r\n" + 
    			"   OPERATOR,\r\n" + 
    			"   PENDING_ACTION,\r\n" + 
    			"   TIMESTAMPFORMAT,\r\n" + 
    			"   BUSINESS_AREA,\r\n" + 
    			"   LOC_CNTRY_ID,\r\n" + 
    			"   DEPARTMENT,\r\n" + 
    			"   EFFECTIVE_DATE,\r\n" + 
    			"   APROVED,\r\n" + 
    			"   ACCESSAPPROVE,\r\n" + 
    			"   DEL_PEND_BY,\r\n" + 
    			"   MAX_FORCE_AMT_PEND_BY,\r\n" + 
    			"   EMPID_CONTRACTID,\r\n" + 
    			"   BAD_LOGIN,\r\n" + 
    			"   BANKAPPROVE,\r\n" + 
    			"   MSGNSFTHRS,\r\n" + 
    			"   COST_CTR,\r\n" + 
    			"   TIME,\r\n" + 
    			"   TIME_STAMP,\r\n" + 
    			"   UPDATE_DATE,\r\n" + 
    			"   TRACE_LEVEL_SPECIAL,\r\n" + 
    			"   COST_CTR_MGR,\r\n" + 
    			"   MAX_AMOUNT,\r\n" + 
    			"   FIRST_NAME,\r\n" + 
    			"   EMAIL_ADDRESS,\r\n" + 
    			"   ACCPENDBY,\r\n" + 
    			"   QUEUEAPPROVE,\r\n" + 
    			"   SUSPENDED,\r\n " +
    			"	UID_USERS,\r\n " +
    			"	LANG)\r\n" + 
    			"  SELECT CAST(NULL AS VARCHAR(10))," + //--PASSPENDBY\r\n" + 
    			"         'AC'," + //--REC_STATUS\r\n" + 
    			"         'NO'," + //--PROFILE_CHANGE_STATUS\r\n" + 
    			"         CAST(NULL AS VARCHAR(10))," + //--CHECKDATE\r\n" + 
    			"         CAST(NULL AS VARCHAR(10))," + // --ALERT_LEVEL_PROFILE_ID\r\n" + 
    			"         CAST(NULL AS VARCHAR(10))," + // --PASSWDDATE\r\n" + 
    			"         0," + // --FEDNSFTHRS\r\n" + 
    			"         0," + // --MAX_FORCE_AMT_APPROVE\r\n" + 
    			"         CAST(NULL AS VARCHAR(10))," + // --PHONE_NO\r\n" + 
    			"         CAST(NULL AS VARCHAR(10))," + //  --MSGPENDBY\r\n" + 
    			"         USER_ENTITLEMENT.U_ENT_NAME," + // --U_ENT_NAME\r\n" + 
    			"         CAST(NULL AS VARCHAR(10))," + // --QUEPENDBY\r\n" + 
    			"         ?," + // --userID\r\n" + 
    			"         CAST(NULL AS VARCHAR(10))," + // --FPRINT\r\n" + 
    			"         CAST(NULL AS VARCHAR(10))," + // --LASTLOGIN_DATE\r\n" + 
    			"         CAST(NULL AS VARCHAR(10))," + // --CHECKTIME\r\n" + 
    			"         CAST(NULL AS VARCHAR(10))," + // --BNKPENDBY\r\n" + 
    			"         0," + // --MXAMAPPROVE\r\n" + 
    			"         'SSO'," + // --USER_NAME\r\n" + 
    			"         0," + // --MAX_FORCE_AMOUNT\r\n" + 
    			"         0," + // --LOGGED_IN\r\n" + 
    			"         USER_ENTITLEMENT.OFFICE," + // --OFFICE\r\n" + 
    			"         CAST(NULL AS VARCHAR(10))," + // --MXAMPENDBY\r\n" + 
    			"         0," + // --TEMPPASSWD\r\n" + 
    			"         ''," + // --EMP_TYPE\r\n" + 
    			"         CAST(NULL AS VARCHAR(10))," + // --PASSAPPROVE\r\n" + 
    			"         CAST(NULL AS VARCHAR(10))," + // --CHECKDATE_WEB\r\n" + 
    			"         CAST(NULL AS VARCHAR(10))," + // --MESSAGEAPPROVE\r\n" + 
    			"         CAST(NULL AS VARCHAR(10))," + // --PASSWORD_CHANGE\r\n" + 
    			"         ''," + // --MIDDLE_NAME\r\n" + 
    			"         'SsoDummyPass'," + // --USERPASSWD\r\n" + 
    			"         CAST(NULL AS VARCHAR(10))," + // --OPERATOR\r\n" + 
    			"         'PN'," + // --PENDING_ACTION\r\n" + 
    			"         CAST(NULL AS VARCHAR(10))," + // --TIMESTAMPFORMAT\r\n" + 
    			"         0," + //--BUSINESS_AREA\r\n" + 
    			"         CAST(NULL AS VARCHAR(10))," + // --LOC_CNTRY_UD\r\n" + 
    			"         USER_ENTITLEMENT.DEPARTMENT," + // --DEPARTMENT\r\n" + 
    			"         CAST(NULL AS VARCHAR(10))," + // --EFFECTIVE DATE \r\n" + 
    			"         0," + // --APROVED \r\n" + 
    			"         CAST(NULL AS VARCHAR(10))," + // --ACCESSAPPROVE\r\n" + 
    			"         CAST(NULL AS VARCHAR(10))," + // --DEL_PEND_BY\r\n" + 
    			"         CAST(NULL AS VARCHAR(10))," + // --MAX_FORCE_AMT_PEND_BY\r\n" + 
    			"         '1'," + // + // -- EMPID_CONTRACTID\r\n" + 
    			"         0," + // --BAD_LOGIN\r\n" + 
    			"         CAST(NULL AS VARCHAR(10))," + // --BANKAPPROVE\r\n" + 
    			"         0," + // --MSGNSFTHRS\r\n" + 
    			"         CAST(NULL AS VARCHAR(10))," + // --COST_CTR\r\n" + 
    			"         CAST(NULL AS VARCHAR(10))," + // --TIME\r\n" + 
    			"         CAST(NULL AS VARCHAR(10))," + // --TIME_STAMP\r\n" + 
    			"         CAST(NULL AS VARCHAR(10))," + // --UPDATE_DATE\r\n" + 
    			"         0," + // --TRACE_LEVEL_SPECIAL\r\n" + 
    			"         ''," + // --COST_CTR_MGR\r\n" + 
    			"         0," + // --MAX_AMOUNT\r\n" + 
    			"         'SSO'," + // --FIRST_NAME\r\n" + 
    			"         ''," + //--EMAIL_ADDRESS\r\n" + 
    			"         CAST(NULL AS VARCHAR(10))," + // --ACCPENDBY\r\n" + 
    			"         CAST(NULL AS VARCHAR(10))," + // --QUEUEAPPROVE\r\n" + 
    			"         0," + //--SUSPENDED,r\n" +
    			"		  ?," + // --UID_USERS,\r\n" +
    			"         CAST(NULL AS VARCHAR(10)) " + //--LANG\r\n "	+ 
    			"    FROM USER_ENTITLEMENT \r\n " + 
    			"   WHERE U_ENT_NAME = ?" ;
        
    	final StatementParameter userIdStatemnetParameter = new StatementParameter(sUserId, Types.VARCHAR) ; 
    	
        //if the user id was found not to exist in the db, insert its record and retreive it         
        StatementParameter[] arrParameters = new StatementParameter[] { 
        		userIdStatemnetParameter, 
        		userIdStatemnetParameter, 
                new StatementParameter(sUserEntitlementName, Types.VARCHAR)
        } ;
        
        return super.update(INSERT_SSO_USER_RECROD_QUERY, arrParameters, null, null, false, false, null);
    }//EOM
    
    public Feedback updateUserUentName(String sUserId,String sUserEntitlementName) {
        String UPDATE_USER_WITH_NEW_ENTITLEMENT_NAME_QUERY = "UPDATE USERS SET (U_ENT_NAME, OFFICE, DEPARTMENT) =" +
                "(SELECT USER_ENTITLEMENT.U_ENT_NAME, USER_ENTITLEMENT.OFFICE, USER_ENTITLEMENT.DEPARTMENT " +
                "FROM USER_ENTITLEMENT " +
                "WHERE USER_ENTITLEMENT.U_ENT_NAME = ?) " +
           "WHERE UPPER(USERS.USER_ID) = ?" ;
        
        //if the user id was found not to exist in the db, insert its record and retreive it         
        StatementParameter[] arrParameters = new StatementParameter[] { 
              new StatementParameter(sUserEntitlementName, Types.VARCHAR), 
              new StatementParameter(sUserId, Types.VARCHAR),
        } ;
        
        return super.update(UPDATE_USER_WITH_NEW_ENTITLEMENT_NAME_QUERY, arrParameters, null, null, false, false, null); 
    }//EOM
    
    public DTODataHolder getUserDetails(String sUserID)
    {
        final String GET_USER_DATA_SELECT_STATEMENT = "SELECT  OFFICE, DEPARTMENT, UID_USERS FROM USERS WHERE UPPER(USER_ID) = ? " ;   
    
      String sFinalSelectStatement = GET_USER_DATA_SELECT_STATEMENT ;
      
      StatementParameter[] arrParameters = new StatementParameter[1];
      arrParameters[0] = new StatementParameter();
      arrParameters[0].init(sUserID, Types.VARCHAR);      
           
      
      return getData(sFinalSelectStatement, arrParameters, -1/*noOfRows -- as many as possible*/);
    }//EOM
}