package backend.core.module.security.businessobjects;

import java.util.HashMap;

import javax.transaction.UserTransaction;

import com.fundtech.cache.entities.WebSessionInfo;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.security.UserLoginData;
import com.fundtech.datacomponent.request.UserCredentials;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.datacomponent.response.SimpleResponseDataComponent;
import com.fundtech.util.GlobalUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.dataaccess.dto.DTODataHolder;
import backend.services.cache.entitlements.EntitlementsDataFactory;

public class BOSsoSecurity extends BOSecurity
{

	private final static Logger logger = LoggerFactory.getLogger(BOSsoSecurity.class);
    //used to indicate invalid credentials
    private static final DTODataHolder DTO_INVALID_USER_RECORD ; 
  
    static { 
        DTO_INVALID_USER_RECORD = new DTODataHolder() ;
        DTO_INVALID_USER_RECORD.getFeedBack().setFailure() ; 
        DTO_INVALID_USER_RECORD.getFeedBack().setErrorCode(ERROR_CODE_USER_INVALID) ;
    }//EO static block
    
    public BOSsoSecurity() {
        super();
    }//EOC
    
    public SimpleResponseDataComponent login(UserCredentials userCredentials){
       
      String sUserID = userCredentials.getUserName() ; 
      String sUserEntitlementName  = userCredentials.getAdditionalParamValue(UserCredentials.KEY_ROLE_NAME) ;
         
      

      String sIP = userCredentials.getIP() ;
             
      SimpleResponseDataComponent response = new SimpleResponseDataComponent();
      
      UserTransaction[] arrTransactionHolder = new UserTransaction[1];
      Feedback feedback = startTransaction(arrTransactionHolder);
      
      // Successfull transaction opening.
      if(feedback.isSuccessful())
      {
        response = this.doLogin(sUserID, sUserEntitlementName, sIP, arrTransactionHolder, feedback);
      }
      
      // Failure transcation opening.
      else
      {
        response.setFeedback(feedback);
      }
      
      
      
      return response;
    }//EOM

	private String[] getDepShow(UserEntitlementData userEntitlementData) {
				String sORIG_PERM_PROF_DEPARTMENT = userEntitlementData.getORIG_PERM_PROF_DEPARTMENT();
				
				String[] sORIG_PERM_PROF_DEPARTMENTArray = sORIG_PERM_PROF_DEPARTMENT.split("@@@");
				
				return sORIG_PERM_PROF_DEPARTMENTArray;
	}
    /**
     * Performs login.
     */
      
    private SimpleResponseDataComponent doLogin(String sUserID, String sUserEntitlementName, 
                                                String sIP,
                                                UserTransaction[] arrTransactionHolder,
                                                Feedback feedback)
    {
      
      
      
      SimpleResponseDataComponent response = new SimpleResponseDataComponent();
      
      UserLoginData userLoginData = null;
      
      boolean[] arrInvalidUserID = new boolean[1];
      boolean bCommitTransaction=false;
      //As an SSO user is not guaranteed to exist in the USERS table prior to his first login 
      //the method here will perform an insert or update 
      //Guy Segev 13/05/2007 --> as the user profiles are not defined or accessed through the application 
      //the user might not exist in the db as of yet, therefore, update the user details if exists 
      //or insert a skelleton user profile so that the flow could continue as normal. 
      //TODO: currently, the user will not be deleted from the table on logout.
      try
      {
	      DTODataHolder dtoUsers = this.getUserProfile(sUserID, arrInvalidUserID, sUserEntitlementName);
      
      feedback = dtoUsers.getFeedBack();
      
      // Success.
      if(feedback.isSuccessful())
      {
        userLoginData = new UserLoginData(sUserID, sIP);
        
        final WebSessionInfo webSessionInfo = new WebSessionInfo() ; 
        feedback = performLogin(sUserID, sUserEntitlementName, sIP, userLoginData, dtoUsers, webSessionInfo);
        
        // Successfull login.
        if(feedback.isSuccessful())
        {
          // Sets department data.
          UserEntitlementData userEntitlementData = EntitlementsDataFactory.getInstance().getUserEntitlementData(userLoginData.getUserEntitlementName());
          String sPERM_PROF_DEPARTMENT = userEntitlementData.getPERM_PROF_DEPARTMENT();
          String[] sORIG_PERM_PROF_DEPARTMENT_SHOW = getDepShow(userEntitlementData);
          setDepartmentData(userLoginData, sPERM_PROF_DEPARTMENT,sORIG_PERM_PROF_DEPARTMENT_SHOW);
          
          // Sets user preferences.
          this.setUserPreferences(userLoginData);
          
          // Sets default business date.
          this.setDefaultBusinessDate(userLoginData);
          
          // Updates returned value.
          response.setDataArray(new Object[]{userLoginData});
        }
        
        // Failure login.
        else
        {
          
          response.setFeedback(feedback);
        }
      }
      
      // Failure getting USERS record for passed user.
      else
      {
        response.setFeedback(feedback);
      }
      
      boolean bSuccessfullLoginProcess = response.getFeedback().isSuccessful();
        
	      bCommitTransaction = bSuccessfullLoginProcess ; // removed code --> || bUserShouldBeSuspended;
      }
      catch(Throwable e)
      {
    	  logger.error("doLogin",e);
      }
      finally
      {
	      // Transaction commit/rollback.
	      Feedback fbTransaction = endTransaction(arrTransactionHolder[0], bCommitTransaction);
	      if(!fbTransaction.isSuccessful())  
	      {
	        response.setFeedback(fbTransaction);
	      }
      }
            
      
      
      return response;
    }//EOM 
    
    /**
     * Hook method invoked within the getUserData() and will either insert or rertieve the user's data.
     * @see backend.core.module.security.businessobjects.BOSecurity#getUserRecord(java.lang.String, java.lang.String)
     */
    protected DTODataHolder getUserRecord(String sUserId, String sUserEntitlementName) { 

        Feedback feedback  =  null ;
        boolean bRequireRefectch = false ;
        String sPersistedUentName = null ;
        
        //step 1: Attempt to rertieve an existing user record for the user id.
        DTODataHolder dtoUserRecord = super.getUserRecord(sUserId, null) ;
        
        //if failure, return the faulty one 
        if(!dtoUserRecord.isFeedBackSuccess()) return DTO_INVALID_USER_RECORD ; 
        
        //step 2: if the user does not exist insert the user
        if(dtoUserRecord.isEmpty()) { 
            
            //the u_ent_name would be replaced with the proper u_ent_name
            feedback = this.m_daoSecurity.insertSsoUserRecrod(sUserId, sUserEntitlementName) ;
           
            //if failure, return the empty one 
            if(!feedback.isSuccessful()) return DTO_INVALID_USER_RECORD ; 

            //set the refectch record flag
            bRequireRefectch = true ; 
            
        }else { //EO if there was no such user in the system 
        
            //step 3: compare the persisted u_ent_name with the formal args one, and if different, 
            //update the u_ent_name in the DB  (this will update the office and the department as well
            sPersistedUentName = dtoUserRecord.getColumnData(COLUMN_USERS_U_ENT_NAME) ;
            
            if(sUserEntitlementName != null && !sUserEntitlementName.equals(sPersistedUentName)) {
               
                //the u_ent_name would be replaced with the proper u_ent_name
                feedback = this.m_daoSecurity.updateUserUentName(sUserId, sUserEntitlementName) ;
                
                //if failure, return the empty one 
                if(!feedback.isSuccessful()) return DTO_INVALID_USER_RECORD; 
                
                //set the refectch record flag
                bRequireRefectch = true ; 
            }//EO else if the unt names were not the same
            
        }//EO else if the user record existed 
        
//      Step 4: if the bRequireRefectch is true, 
        //fetch the user record again after the synchronization --> if the user
        //entitlement name was invalid, return the DTO_INVALID_USER_RECORD
        if(bRequireRefectch)  {
            dtoUserRecord = super.getUserRecord(sUserId, null) ; 
            
            sPersistedUentName = dtoUserRecord.getColumnData(COLUMN_USERS_U_ENT_NAME) ;
            
            if(!sPersistedUentName.equals(sPersistedUentName))  dtoUserRecord = DTO_INVALID_USER_RECORD ;
                
        }//EO if bRequireRefectch is true, 
                
        return dtoUserRecord ;
    }//EOM   
 
    /**
     * Performs login.
     */
    protected Feedback performLogin(String sUserID, 
									String sUserEntitlementName, 
									String sIP,
                                    UserLoginData userLoginData, 
                                    DTODataHolder dtoUsers,
                                    final WebSessionInfo webSessionInfo)
    {
      
      
      Feedback feedback = new Feedback();
      
      feedback = this.checkUserStatus(dtoUsers, userLoginData, webSessionInfo);
      
      if(feedback.isSuccessful())
      {
        feedback = getUserProfiles(userLoginData);
      }

      // Either we have problems with the user status, or retrieving user profiles didn't succeed.
      if(!feedback.isSuccessful())
      {
          feedback.setErrorCode(ERROR_CODE_GENERAL);
      }
      
      if(feedback.isSuccessful())
      {
        // Sets the user as logged in.
        feedback = this.setUserLoggedIn(userLoginData, webSessionInfo);
        
        // Cleans the WEB_PROFILE_LOCK table from records with this user ID.
        this.cleanUserIDExistingLockRecords(sUserID);
      }
      
      
      
      return feedback;
    }
    
    
    /**
     * * Sets the user as logged in to the system.
     * Jul 30, 2009
     * Guys
     *
     * @param userLoginData
     * @param webSessionInfo
     * @return
     */
    
    protected final Feedback setUserLoggedIn(final UserLoginData userLoginData, final WebSessionInfo webSessionInfo){
      
      final String sUserID = userLoginData.getUserID();
      
      
      
      Feedback feedback = new Feedback();
      
      //ensure that the hub region was loaded prior to possibly invoking the child's get metadata for the first time  
      CacheKeys.WebSessionInfoKey.getId() ; 
      
      // Removes existing, (if really exists), session info for this user ID.
      CacheKeys.UserWebSessionInfoKey.removeSingle(sUserID) ; 

	  // Generates a unique session ID for this user.
	  String sSessionID =  GlobalUtils.generateGUIDRandom() ; //generateSessionID(sUserID);
	  userLoginData.setSessionID(sSessionID);
	   webSessionInfo.setSessionID(sSessionID) ; 
	  
	  // Saves session info into WebSessionInfo cache.
	  feedback = this.configureNStoreSessionInfo(userLoginData, webSessionInfo);
      
      // Updates the USERS table.
      if(feedback.isSuccessful())
      {
        feedback = updateUserAsLoggedin(userLoginData);
      }
      
      if(!feedback.isSuccessful())
      {
        logger.error(GlobalUtils.getFeedbackString(feedback));
      }
      
      
      
      return feedback;
    }//EOM
    
    /**
     * Updates the USERS table.
     */
    private Feedback updateUserAsLoggedin(UserLoginData userLoginData){
      String sUserID = userLoginData.getUserID();
      
      
   
      Feedback feedback = m_daoSecurity.setUserLoggedIn(sUserID) ;
      
      
      
      return feedback;
    }//EOM
    
    
    /**
     * Checks the user status, (temp password, password date, suspension status, etc).
     */
    protected Feedback checkUserStatus(DTODataHolder dtoUsers, 
                                     UserLoginData userLoginData,
                                     final WebSessionInfo webSessionInfo)
    {
      String sUserID = userLoginData.getUserID();
      
      
      Feedback feedback = new Feedback();
      
      // The parallel C++ method is 'MapUsersDBToFTUser'.
      feedback = this.updateUserLoginData(dtoUsers, userLoginData);
            
      // Updates related WebSessionInfo object.
      if(feedback.isSuccessful())
      {
        this.updateWebSessionInfoHM(webSessionInfo, userLoginData);
      }
      
      // Checks if user is active.
      if (feedback.isSuccessful())
      {
    	  feedback = checkUserIsActive(userLoginData, (String) dtoUsers.getColumnData(COLUMN_USERS_REC_STATUS));
      }

      // Checks if user is already logged in if yes remove old session.
      if (feedback.isSuccessful())
      {
    	  checkUserLoggedInSSO(sUserID, userLoginData, feedback);
      }      
      
      // Checks if user is suspended.
      if (feedback.isSuccessful())
      {
    	  HashMap hmData = dtoUsers.getDataRow();
    	  checkUserSuspended(sUserID, userLoginData, feedback, hmData);
      }
		
      
      
      return feedback;
    }
    
    /**
	 * Checks if user is already logged in.
	 */
	protected void checkUserLoggedInSSO(String sUserID, UserLoginData userLoginData, Feedback feedback) {
		final String TRACE_MESSAGE = "The user is currently logged in. SSO login's previous user session will be cleaned";

		final WebSessionInfo webSessionInfo = CacheKeys.UserWebSessionInfoKey.getSingle(sUserID);

		// User is already logged in from another machine or browser.
		if (webSessionInfo != null){
			CacheKeys.UserWebSessionInfoKey.removeSingle(sUserID);
			logger.info(TRACE_MESSAGE);
		}//EO if the user was already logged in
	}
}
