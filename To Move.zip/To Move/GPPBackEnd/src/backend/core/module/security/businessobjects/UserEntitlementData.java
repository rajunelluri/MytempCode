package backend.core.module.security.businessobjects;



import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.cxf.common.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.services.cache.ASCacheFactory;
import backend.util.ServerConstants;
import backend.util.ServerUtils;

/*
 * Name:		UserEntitlementData
 * Description: Class to encapsulate user entitlement data 
 * Company:		Fundtech Israel
 * Author:		Asaf Levy
 * Date:		21/01/07
 */
public class UserEntitlementData
{

  private final static Logger logger = LoggerFactory.getLogger(UserEntitlementData.class);
  private String m_sUserEntitlementName;
  
  private String m_sORIG_PERM_PROF_MSG;
  private String m_sORIG_PERM_PROF_DEPARTMENT;
  private String m_sORIG_PERM_PROF_RULE_TYPES;
  private String m_sORIG_PERM_PROF_QUEUE;
  private String m_sORIG_PERM_PROF_ACCESS;
  private String m_sORIG_PERM_PROF_ALERTS;
 // private String m_sORIG_PERM_RULE_TYPES;
  private String m_sPERM_PROF_MSG;
  private String m_sPERM_PROF_DEPARTMENT;
  private String m_sPERM_PROF_QUEUE;
  private String m_sPERM_PROF_ACCESS;
  private String m_sPERM_PROF_ALERTS;
  private String m_sPERM_PROF_BUTTONS;
  private String m_sPERM_PROF_RULE_TYPES;
  private String m_sPERM_PROF_RULE_TYPES_NO_SYSTEM_RULES;
  private String m_sPERM_WRITE_RULE_TYPES;
  private String m_sPERM_WRITE_RULE_TYPES_NO_SYSTEM_RULES;

  private String m_sORIG_PERM_PROF_QUEUE_NOUDQ;
  private String m_sORIG_PERM_PROF_QUEUE_NOUDQ_HV_MESSAGES; // HV = high value.
  private String m_sORIG_PERM_PROF_QUEUE_NOUDQ_LV_MESSAGES; // LV = low value.
  
  private String m_sORIG_PERM_PROF_OFFICE;
  private String m_sPERM_PROF_OFFICE;
  private String m_sApproveAccessLevels;
  private String[] m_arrOfficeData;
  private String[] m_arrBusinessDatesForOffices;
  private String m_sOffice;
  
  private String m_sMessageProfileName;
  private String m_sAccessProfileName;
  private String m_sDepartmentProfileName;
  private String m_sRuleTypesProfileName;
  private String m_sAlertsProfileName;
  private String m_sQueueProfileName;
  
  // HashMap in which: key - permission level type.
  //                   value - permission profile name, (e.g. 'FPS ALL').
  private Map<String, String> m_hmPermissionLevelTypeToPermissionProfileName;
  
  // Includes all access levels for this UserEntitlementData object; it will be 
  // updated each time the 'm_sORIG_PERM_PROF_ACCESS' class mmeber is updated.
  private Set<String> m_hsAccessLevels;
  
  public static String PERMISSION_LEVEL_TYPE_MESSAGE = "MESSAGE_LEVEL_PROFILE";
  public static String PERMISSION_LEVEL_TYPE_ACCESS = "ACCESS_LEVEL_PROFILE";
  public static String PERMISSION_LEVEL_TYPE_DEPARTMENT = "DEPARTMENT_LEVEL_PROFILE";
  public static String PERMISSION_LEVEL_TYPE_RULE_TYPE = "PRULE_TYPE_LEVEL_PROFILE";
  public static String PERMISSION_LEVEL_TYPE_ALERTS = "ALERT_LEVEL_PROFILE";
  public static String PERMISSION_LEVEL_TYPE_QUEUE = "QUEUE_LEVEL_PROFILE";
  
  public static List<String> LIST_PERMISSION_LEVEL_TYPES = Arrays.asList(new String[]{PERMISSION_LEVEL_TYPE_MESSAGE,
                                                                              PERMISSION_LEVEL_TYPE_ACCESS,
                                                                              PERMISSION_LEVEL_TYPE_DEPARTMENT,
                                                                              PERMISSION_LEVEL_TYPE_RULE_TYPE,
                                                                              PERMISSION_LEVEL_TYPE_ALERTS,
                                                                              PERMISSION_LEVEL_TYPE_QUEUE});
  
  // Dedicated helper object for synchronization needed in the 'refreshPermissionsStrings'
  // method. A zero element array is used because such an array is cheaper to
  // create than any other object.
  private static byte[] m_arrRefreshPermissionsSynchronizedLockHelper = new byte[0];
  
  // Trace constants.
  private static final String TRACE_REFRESH_PERMISSIONS_STRING_START = "EntitlementsDataFactory.refreshPermissionsStrings - START";
  private static final String TRACE_REFRESH_PERMISSIONS_STRING_END = "EntitlementsDataFactory.refreshPermissionsStrings - END";
  
  private static final String PERMISSION_LEVEL_TYPE = "; Permission level type - ";
  private static final String LEVEL_PROFILE_NAME = "; Level profile name - ";

  
  
  /**
   * Empty constructor.
   */
  public UserEntitlementData()
  {
  }

  /**
   * Constructor.
   */
  public UserEntitlementData(String sUserEntitlementName)
  {
    m_sUserEntitlementName = sUserEntitlementName;
  }
  
  public void setUserEntitlementName(String sUserEntitlementName)
  {
    m_sUserEntitlementName = sUserEntitlementName;
  }

  public void setORIG_PERM_PROF_MSG(String sORIG_PERM_PROF_MSG)
  {
    m_sORIG_PERM_PROF_MSG = sORIG_PERM_PROF_MSG;
  }
  
  public void setORIG_PERM_PROF_DEPARTMENT(String sORIG_PERM_PROF_DEPARTMENT)
  {
    m_sORIG_PERM_PROF_DEPARTMENT = sORIG_PERM_PROF_DEPARTMENT;
  }
  
  public void setORIG_PERM_PROF_RULE_TYPES(String sORIG_PERM_PROF_RULE_TYPES)
  {
    m_sORIG_PERM_PROF_RULE_TYPES = sORIG_PERM_PROF_RULE_TYPES;
  }

  public void setORIG_PERM_PROF_QUEUE(String sORIG_PERM_PROF_QUEUE)
  {
    m_sORIG_PERM_PROF_QUEUE = sORIG_PERM_PROF_QUEUE;
  }

  public void setORIG_PERM_PROF_ACCESS(String sORIG_PERM_PROF_ACCESS)
  {
    m_sORIG_PERM_PROF_ACCESS = sORIG_PERM_PROF_ACCESS;
    setAccessLevelsHS();
  }
  
  
    
  
  /*
   * Creates HashSet of access levels for this UserEntitlementData object.
   * NOTE: the access levels don't contain READ/WRITE data, (i.e. 0/1).
   */
  private void setAccessLevelsHS()
  {
    if(   m_sORIG_PERM_PROF_ACCESS != null 
       && !m_sORIG_PERM_PROF_ACCESS.equals(ServerConstants.EMPTY_STRING))
    {
      m_hsAccessLevels = ServerUtils.getHashSetFromDelimitedString(m_sORIG_PERM_PROF_ACCESS, ServerConstants.PERMISSIONS_DELIMITER, true, 3, false);
    }
    
    else
    {
      m_hsAccessLevels = new HashSet<String>();
    }
  }
  
  public void setORIG_PERM_PROF_ALERTS(String sORIG_PERM_PROF_ALERTS)
  {
    m_sORIG_PERM_PROF_ALERTS = sORIG_PERM_PROF_ALERTS;
  }

  public void setPERM_PROF_MSG(String sPERM_PROF_MSG)
  {
    m_sPERM_PROF_MSG = sPERM_PROF_MSG;
  }

  public void setPERM_PROF_DEPARTMENT(String sPERM_PROF_DEPARTMENT)
  {
    m_sPERM_PROF_DEPARTMENT = sPERM_PROF_DEPARTMENT;
  }

  public void setPERM_PROF_RULE_TYPES(String sPERM_PROF_RULE_TYPES)
  {
    m_sPERM_PROF_RULE_TYPES = sPERM_PROF_RULE_TYPES;
  }
  
  public void setPERM_PROF_RULE_TYPES_NO_SYSTEM_RULES(String sPERM_PROF_RULE_TYPES_NO_SYSTEM_RULES)
  {
    m_sPERM_PROF_RULE_TYPES_NO_SYSTEM_RULES = sPERM_PROF_RULE_TYPES_NO_SYSTEM_RULES;
  }

  public void setPERM_WRITE_RULE_TYPES(String sPERM_WRITE_RULE_TYPES)
  {
    m_sPERM_WRITE_RULE_TYPES = sPERM_WRITE_RULE_TYPES;
  }
  
  public void setPERM_WRITE_RULE_TYPES_NO_SYSTEM_RULES(String sPERM_WRITE_RULE_TYPES_NO_SYSTEM_RULES)
  {
 	m_sPERM_WRITE_RULE_TYPES_NO_SYSTEM_RULES = sPERM_WRITE_RULE_TYPES_NO_SYSTEM_RULES;
  }
  
  public void setPERM_PROF_QUEUE(String sPERM_PROF_QUEUE)
  {
    m_sPERM_PROF_QUEUE = sPERM_PROF_QUEUE;
  }

  public void setPERM_PROF_ACCESS(String sPERM_PROF_ACCESS)
  {
    m_sPERM_PROF_ACCESS = sPERM_PROF_ACCESS;
  }
  
  public void setPERM_PROF_ALERTS(String sPERM_PROF_ALERTS)
  {
    m_sPERM_PROF_ALERTS = sPERM_PROF_ALERTS;
  }

  public void setPERM_PROF_BUTTONS(String sPERM_PROF_BUTTONS)
  {
    m_sPERM_PROF_BUTTONS = sPERM_PROF_BUTTONS;
  }

  public void setORIG_PERM_PROF_QUEUE_NOUDQ(String sORIG_PERM_PROF_QUEUE_NOUDQ)
  {
    m_sORIG_PERM_PROF_QUEUE_NOUDQ = sORIG_PERM_PROF_QUEUE_NOUDQ;
    
    // Sets related m_sORIG_PERM_PROF_QUEUE_NOUDQ class members to null.
    m_sORIG_PERM_PROF_QUEUE_NOUDQ_LV_MESSAGES = null;
    m_sORIG_PERM_PROF_QUEUE_NOUDQ_HV_MESSAGES = null;
  }

  public void setORIG_PERM_PROF_OFFICE(String sORIG_PERM_PROF_OFFICE)
  {
    m_sORIG_PERM_PROF_OFFICE = sORIG_PERM_PROF_OFFICE;
  }
  
  public void setApproveAccessLevels(String sApproveAccessLevels)
  {
    m_sApproveAccessLevels = sApproveAccessLevels;
  }

  public void setOffice(String sOffice)
  {
    m_sOffice = sOffice;
  }
  
  public String getOffice()
  {
    return m_sOffice;
  }

  public String getUserEntitlementName()
  {
    return m_sUserEntitlementName;
  }
  
  public String getORIG_PERM_PROF_MSG()
  {
    return m_sORIG_PERM_PROF_MSG;
  }
  
  public String getORIG_PERM_PROF_DEPARTMENT()
  {
    return m_sORIG_PERM_PROF_DEPARTMENT;
  }
  
  public String getORIG_PERM_PROF_QUEUE()
  {
    return m_sORIG_PERM_PROF_QUEUE;
  }
  
  public String getORIG_PERM_PROF_RULE_TYPES()
  {
    return m_sORIG_PERM_PROF_RULE_TYPES;
  }

  public String getORIG_PERM_PROF_ACCESS()
  {
    return m_sORIG_PERM_PROF_ACCESS;
  }

  public String getORIG_PERM_PROF_ALERTS()
  {
    return m_sORIG_PERM_PROF_ALERTS;
  }

  public String getPERM_PROF_MSG()
  {
    return m_sPERM_PROF_MSG;
  }

  public String getPERM_PROF_DEPARTMENT()
  {
    return m_sPERM_PROF_DEPARTMENT;
  }
  
  public String getPERM_PROF_RULE_TYPES()
  {
    return m_sPERM_PROF_RULE_TYPES;
  }
  
  public String getPERM_PROF_RULE_TYPES_NO_SYSTEM_RULES()
  {
    return m_sPERM_PROF_RULE_TYPES_NO_SYSTEM_RULES;
  }
  
  public String getPERM_WRITE_RULE_TYPES()
  {
    return m_sPERM_WRITE_RULE_TYPES;
  }
  
  public String getPERM_WRITE_RULE_TYPES_NO_SYSTEM_RULES()
  {
    return m_sPERM_WRITE_RULE_TYPES_NO_SYSTEM_RULES;
  }

  public String getPERM_PROF_QUEUE()
  {
    return m_sPERM_PROF_QUEUE;
  }

  public String getPERM_PROF_ACCESS()
  {
    return m_sPERM_PROF_ACCESS;
  }
  
  public String getPERM_PROF_ALERTS()
  {
    return m_sPERM_PROF_ALERTS;
  }

  public String getPERM_PROF_BUTTONS()
  {
    return m_sPERM_PROF_BUTTONS;
  }

  public String getORIG_PERM_PROF_QUEUE_NOUDQ()
  {
    return m_sORIG_PERM_PROF_QUEUE_NOUDQ;
  }

  public String getORIG_PERM_PROF_QUEUE_NOUDQ_HV_MESSAGES()
  {
    if(m_sORIG_PERM_PROF_QUEUE_NOUDQ_HV_MESSAGES == null)
    {
      initializeRelated_ORIG_PERM_PROF_QUEUE_NOUDQ_Members();
    }

    return m_sORIG_PERM_PROF_QUEUE_NOUDQ_HV_MESSAGES;
  }

  public String getORIG_PERM_PROF_QUEUE_NOUDQ_LV_MESSAGES()
  {
    if(m_sORIG_PERM_PROF_QUEUE_NOUDQ_LV_MESSAGES == null)
    {
      initializeRelated_ORIG_PERM_PROF_QUEUE_NOUDQ_Members();
    }
    
    return m_sORIG_PERM_PROF_QUEUE_NOUDQ_LV_MESSAGES;
  }
  
  /**
   * 
   */
  private void initializeRelated_ORIG_PERM_PROF_QUEUE_NOUDQ_Members()
  {
    final String DELIMITER = "','";
    
    HashMap<String, Object> hmLowHighValueStatuses = ASCacheFactory.getInstance().getLowHighValueStatusesHM();
  String[] arrORIG_PERM_PROF_QUEUE_NOUDQ_Statuses = StringUtils.isEmpty( m_sORIG_PERM_PROF_QUEUE_NOUDQ) ? new String[] {} :
		ServerUtils.getStringArrayFromDelimitedString(m_sORIG_PERM_PROF_QUEUE_NOUDQ.substring(1, m_sORIG_PERM_PROF_QUEUE_NOUDQ.length()-1), DELIMITER);
    
    StringBuffer sbORIG_PERM_PROF_QUEUE_NOUDQ_LV_MESSAGES = new StringBuffer();
    StringBuffer sbORIG_PERM_PROF_QUEUE_NOUDQ_HV_MESSAGES = new StringBuffer();
    
    int iLength = arrORIG_PERM_PROF_QUEUE_NOUDQ_Statuses.length;
    for(int i=0; i<iLength; i++)
    {
      String sStatus = arrORIG_PERM_PROF_QUEUE_NOUDQ_Statuses[i];
      
      Integer intLowValue = (Integer)hmLowHighValueStatuses.get(sStatus);
      
      if(intLowValue != null)
      {
        int iIntValue = intLowValue.intValue();
        
        // LOW value status or LOW/HIGH value status.
        if(iIntValue == 0 || iIntValue == 2)
        {
          sbORIG_PERM_PROF_QUEUE_NOUDQ_LV_MESSAGES.append(ServerConstants.APOSTROPHE)
                                                  .append(sStatus).append(ServerConstants.APOSTROPHE);
          
          if(i < (iLength-1))
          {
            sbORIG_PERM_PROF_QUEUE_NOUDQ_LV_MESSAGES.append(ServerConstants.COMMA);
          }
        }
        
        // HIGH value status or LOW/HIGH value status.
        if(iIntValue == 1 || iIntValue == 2)
        {
          sbORIG_PERM_PROF_QUEUE_NOUDQ_HV_MESSAGES.append(ServerConstants.APOSTROPHE)
                                                  .append(sStatus).append(ServerConstants.APOSTROPHE);

          if(i < (iLength-1))
          {
            sbORIG_PERM_PROF_QUEUE_NOUDQ_HV_MESSAGES.append(ServerConstants.COMMA);
          }
        }
      }
    }

    // Initializes the class members.
    m_sORIG_PERM_PROF_QUEUE_NOUDQ_LV_MESSAGES = sbORIG_PERM_PROF_QUEUE_NOUDQ_LV_MESSAGES.toString();
    m_sORIG_PERM_PROF_QUEUE_NOUDQ_HV_MESSAGES = sbORIG_PERM_PROF_QUEUE_NOUDQ_HV_MESSAGES.toString();
    
    if(m_sORIG_PERM_PROF_QUEUE_NOUDQ_LV_MESSAGES.endsWith(ServerConstants.COMMA))
    {
      m_sORIG_PERM_PROF_QUEUE_NOUDQ_LV_MESSAGES = m_sORIG_PERM_PROF_QUEUE_NOUDQ_LV_MESSAGES.substring(0, m_sORIG_PERM_PROF_QUEUE_NOUDQ_LV_MESSAGES.length()-1);
    }
    
    if(m_sORIG_PERM_PROF_QUEUE_NOUDQ_HV_MESSAGES.endsWith(ServerConstants.COMMA))
    {
      m_sORIG_PERM_PROF_QUEUE_NOUDQ_HV_MESSAGES = m_sORIG_PERM_PROF_QUEUE_NOUDQ_HV_MESSAGES.substring(0, m_sORIG_PERM_PROF_QUEUE_NOUDQ_HV_MESSAGES.length()-1);
    }
  }

  public String getORIG_PERM_PROF_OFFICE()
  {
    return m_sORIG_PERM_PROF_OFFICE;
  }
  
  public String getPERM_PROF_OFFICE()
  {
    return m_sPERM_PROF_OFFICE;
  }

  public String getApproveAccessLevels()
  {
    return m_sApproveAccessLevels;
  }

  public String[] getOfficeData()
  {
    return m_arrOfficeData;
  }
  
  public String[][] getOfficesAndBusinessDates()
  {
    return new String[][]{m_arrOfficeData,m_arrBusinessDatesForOffices};
  } 
  
 
  public void setOfficeData(String[] arrOfficeData)
  {
    m_arrOfficeData = arrOfficeData;
    m_sPERM_PROF_OFFICE = initPERM_PROF_OFFICE(arrOfficeData);
  }
  
   public void setOfficesAndBusinessDates(String[] arrOfficeData,String[] arrBusinessDatesForOffices)
  {
     setOfficeData(arrOfficeData);
     m_arrBusinessDatesForOffices = arrBusinessDatesForOffices;
  } 
   
  private String initPERM_PROF_OFFICE(String[] arrOfficeData)
  {
    StringBuilder sbPERM_PROF_OFFICE = new StringBuilder();
    
    for(int i=0; i<arrOfficeData.length; i++)
    {
      sbPERM_PROF_OFFICE.append(ServerConstants.APOSTROPHE).append(arrOfficeData[i])
                        .append(ServerConstants.APOSTROPHE).append(ServerConstants.COMMA);
    }
    sbPERM_PROF_OFFICE.deleteCharAt(sbPERM_PROF_OFFICE.length()-1);
    
    return sbPERM_PROF_OFFICE.toString();
  }
  
  public String getMessageProfileName()
  {
    return m_sMessageProfileName;
  }
  
  public String getAccessProfileName()
  {
    return m_sAccessProfileName;
  }

  public String getDepartmentProfileName()
  {
    return m_sDepartmentProfileName;
  }
  
  public String getRuleTypeProfileName()
  {
    return m_sRuleTypesProfileName;
  }

  public String getAlertsProfileName()
  {
    return m_sAlertsProfileName;
  }

  public String getQueueProfileName()
  {
    return m_sQueueProfileName;
  }
  
  public void setMessageProfileName(String sMessageProfileName)
  {
    m_sMessageProfileName = sMessageProfileName;
  }
  
  public void setAccessProfileName(String sAccessProfileName)
  {
    m_sAccessProfileName = sAccessProfileName;
  }

  public void setDepartmentProfileName(String sDepartmentProfileName)
  {
    m_sDepartmentProfileName = sDepartmentProfileName;
  }
    
  public void setRuleTypesProfileName(String sRuleTypesProfileName)
  {
    m_sRuleTypesProfileName = sRuleTypesProfileName;
  }
  
  public void setAlertsProfileName(String sAlertsProfileName)
  {
    m_sAlertsProfileName = sAlertsProfileName;
  }

  public void setQueueProfileName(String sQueueProfileName)
  {
    m_sQueueProfileName = sQueueProfileName;
  }
  
  /**
   * Called from 'EntitlementsDataFactory.refershEntitlementDataFactorySelective' method.
   * Returns the profile name for the passed permission level type.
   */
  public String getEntitlementPermissionProfileName(String sPermissionLevelType)
  {
    
    if(m_hmPermissionLevelTypeToPermissionProfileName == null)
    {
      m_hmPermissionLevelTypeToPermissionProfileName = new HashMap<String, String>();
      m_hmPermissionLevelTypeToPermissionProfileName.put(PERMISSION_LEVEL_TYPE_MESSAGE, m_sMessageProfileName);
      m_hmPermissionLevelTypeToPermissionProfileName.put(PERMISSION_LEVEL_TYPE_ACCESS, m_sAccessProfileName);
      m_hmPermissionLevelTypeToPermissionProfileName.put(PERMISSION_LEVEL_TYPE_DEPARTMENT, m_sDepartmentProfileName);
      m_hmPermissionLevelTypeToPermissionProfileName.put(PERMISSION_LEVEL_TYPE_RULE_TYPE, m_sRuleTypesProfileName);
      m_hmPermissionLevelTypeToPermissionProfileName.put(PERMISSION_LEVEL_TYPE_ALERTS, m_sAlertsProfileName);
      m_hmPermissionLevelTypeToPermissionProfileName.put(PERMISSION_LEVEL_TYPE_QUEUE, m_sQueueProfileName);
    }
    
    return m_hmPermissionLevelTypeToPermissionProfileName.get(sPermissionLevelType);
  }
  
  /**
   * Called from 'EntitlementsDataFactory.refershEntitlementDataFactorySelective' method.
   * Returns the entitlement permissions string for the passed permission level type.
   */
  public String getEntitlementPermissions(String sPermissionLevelType)
  {
    String sEntitlementPermissions = null;
    
    if(PERMISSION_LEVEL_TYPE_MESSAGE.equals(sPermissionLevelType))
    {
      sEntitlementPermissions = m_sORIG_PERM_PROF_MSG;
    }
    
    else if(PERMISSION_LEVEL_TYPE_ACCESS.equals(sPermissionLevelType))
    {
      sEntitlementPermissions = m_sORIG_PERM_PROF_ACCESS;
    }

    else if(PERMISSION_LEVEL_TYPE_DEPARTMENT.equals(sPermissionLevelType))
    {
      sEntitlementPermissions = m_sORIG_PERM_PROF_DEPARTMENT;
    }
    
    else if(PERMISSION_LEVEL_TYPE_RULE_TYPE.equals(sPermissionLevelType))
    {
      sEntitlementPermissions = m_sORIG_PERM_PROF_RULE_TYPES;
    }
    
    else if(PERMISSION_LEVEL_TYPE_ALERTS.equals(sPermissionLevelType))
    {
      sEntitlementPermissions = m_sORIG_PERM_PROF_ALERTS;
    }

    else if(PERMISSION_LEVEL_TYPE_QUEUE.equals(sPermissionLevelType))
    {
      sEntitlementPermissions = m_sORIG_PERM_PROF_QUEUE;
    }
    
    return sEntitlementPermissions;
  }
  
  /**
   * Gets permission level type and updates reletad permissions strings class members.
   */
  public void refreshPermissionsStrings(String sPermissionLevelType, 
                                        String[] arrNewStringPermissions,
                                        String sLevelProfileName)
  {
    String sTraceStart = new StringBuffer(TRACE_REFRESH_PERMISSIONS_STRING_START)
                                  .append(PERMISSION_LEVEL_TYPE).append(sPermissionLevelType)
                                  .append(LEVEL_PROFILE_NAME).append(sLevelProfileName).toString();
    
    logger.info(sTraceStart);
    
    synchronized(m_arrRefreshPermissionsSynchronizedLockHelper)
    {
      if(PERMISSION_LEVEL_TYPE_MESSAGE.equals(sPermissionLevelType))
      {
        m_sORIG_PERM_PROF_MSG = arrNewStringPermissions[0];
        m_sPERM_PROF_MSG = arrNewStringPermissions[1];
        m_sMessageProfileName = sLevelProfileName;
      }
      
      else if(PERMISSION_LEVEL_TYPE_ACCESS.equals(sPermissionLevelType))
      {
        m_sORIG_PERM_PROF_ACCESS = arrNewStringPermissions[0];
        setAccessLevelsHS();
        
        m_sPERM_PROF_ACCESS = arrNewStringPermissions[1];
        m_sAccessProfileName = sLevelProfileName;
      }
  
      else if(PERMISSION_LEVEL_TYPE_DEPARTMENT.equals(sPermissionLevelType))
      {
        m_sORIG_PERM_PROF_DEPARTMENT = arrNewStringPermissions[0];
        m_sPERM_PROF_DEPARTMENT = arrNewStringPermissions[1];
        m_sDepartmentProfileName = sLevelProfileName;
      }
        
      else if(PERMISSION_LEVEL_TYPE_RULE_TYPE.equals(sPermissionLevelType))
      {
      	final String TRACE_RULES_REFRESH = "Refreshs rule types permissions for rule type profile name '{}' - PERM_WRITE_RULE_TYPES: {}, PERM_WRITE_RULE_TYPES_NO_SYSTEM_RULES: {}.";
      	if(logger.isTraceEnabled())
      		logger.info(TRACE_RULES_REFRESH, new Object[]{sLevelProfileName, arrNewStringPermissions[2], arrNewStringPermissions[3]});
      	
        m_sORIG_PERM_PROF_RULE_TYPES = arrNewStringPermissions[0];
        m_sPERM_PROF_RULE_TYPES = arrNewStringPermissions[1];
        m_sPERM_WRITE_RULE_TYPES = arrNewStringPermissions[2];
        m_sPERM_WRITE_RULE_TYPES_NO_SYSTEM_RULES = arrNewStringPermissions[3];
        m_sPERM_PROF_RULE_TYPES_NO_SYSTEM_RULES = arrNewStringPermissions[4];
        m_sRuleTypesProfileName = sLevelProfileName;
      }
      
      else if(PERMISSION_LEVEL_TYPE_ALERTS.equals(sPermissionLevelType))
      {
        m_sORIG_PERM_PROF_ALERTS = arrNewStringPermissions[0];
        m_sPERM_PROF_ALERTS = arrNewStringPermissions[1];
        m_sAlertsProfileName = sLevelProfileName;
      }
  
      else if(PERMISSION_LEVEL_TYPE_QUEUE.equals(sPermissionLevelType))
      {
        m_sORIG_PERM_PROF_QUEUE = arrNewStringPermissions[0];
        m_sPERM_PROF_QUEUE = arrNewStringPermissions[1];
        if(arrNewStringPermissions.length > 2) m_sORIG_PERM_PROF_QUEUE_NOUDQ = arrNewStringPermissions[2];
        
        // Sets related 'm_sORIG_PERM_PROF_QUEUE_NOUDQ' class members to null.
        m_sORIG_PERM_PROF_QUEUE_NOUDQ_LV_MESSAGES = null;
        m_sORIG_PERM_PROF_QUEUE_NOUDQ_HV_MESSAGES = null;
        
        m_sQueueProfileName = sLevelProfileName;
      }
      
      else
      {
        final String ERROR_MESSAGE = "ERROR: UserEntitlementData.refreshPermissionsStrings - got unknown permission level type: ";
        
        String sErrorMessage = new StringBuffer(ERROR_MESSAGE).append(sPermissionLevelType).toString();
        logger.error(sErrorMessage);
      }
    }
    
    logger.info(TRACE_REFRESH_PERMISSIONS_STRING_END); 
  }
  
  /**
   * Returns whether the passed access level is allowed for this UserEntitlementData object.
   */
  public boolean userHasAccessLevel(String sAccessLevel)
  {
    if(m_hsAccessLevels == null)
    {
      setAccessLevelsHS();
    }
    return m_hsAccessLevels.contains(sAccessLevel);
  }

}
