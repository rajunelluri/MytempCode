package backend.core.module.security.businessobjects;

import static com.fundtech.cache.infrastructure.regions.CacheKeys.SystParKey;
import static com.fundtech.util.GlobalUtils.isNullOrEmpty;

import java.lang.reflect.Array;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.transaction.UserTransaction;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import sun.misc.BASE64Encoder;
import backend.PermissionHandler;
import backend.businessobject.proxies.AuthorizeUser;
import backend.businessobject.proxies.SkipInputValidation;
import backend.core.module.BOCoreServices;
import backend.core.module.security.dataaccess.dao.DAOSecurity;
import backend.dataaccess.dto.DTOBoolean;
import backend.dataaccess.dto.DTODataHolder;
import backend.dataaccess.dto.DTOSingleValue;
import backend.paymentprocess.erroraudit.ErrorAuditUtils;
import backend.services.cache.entitlements.EntitlementsDataFactory;
import backend.staticdata.dataaccess.dto.DTOModifiedField;
import backend.util.ServerConstants;

import com.fundtech.annotations.Expose;
import com.fundtech.annotations.Expose.ExposureType;
import com.fundtech.annotations.Wrap;
import com.fundtech.cache.entities.Banks;
import com.fundtech.cache.entities.WebSessionInfo;
import com.fundtech.cache.infrastructure.CacheException;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.cache.syspar.SystemParametersInterface;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.core.paymentprocess.data.fields.DataType;
import com.fundtech.core.paymentprocess.errorhandling.ProcessError;
import com.fundtech.core.security.Admin;
import com.fundtech.core.security.Admin.CallSource;
import com.fundtech.core.security.UserLoginData;
import com.fundtech.core.security.UserSession;
import com.fundtech.datacomponent.request.PasswordDetails;
import com.fundtech.datacomponent.request.UserCredentials;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.datacomponent.response.GlobalResponseDataComponentText;
import com.fundtech.datacomponent.response.SimpleResponseDataComponent;
import com.fundtech.datacomponent.response.layout.LayoutConstants;
import com.fundtech.errors.ProcessErrorConstants;
import com.fundtech.util.BindingParameter;
import com.fundtech.util.ErrorAuditInputData;
import com.fundtech.util.ExceptionController;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalDateTimeUtil;
import com.fundtech.util.GlobalUtils;
import com.fundtech.util.datetime.DateAndZone;
import com.fundtech.util.datetime.NewASDateTimeUtils;


/**
 * Title: BOSecurity Description: Business object for core security services Company: Fundtech Israel Author: Asaf Levy Date: 19/11/06
 * 
 * @version 1.0
 * @bo.internalInterface
 */
@Wrap

public class BOSecurity extends BOCoreServices
{

	private final static Logger logger = LoggerFactory.getLogger(BOSecurity.class);
	
	
	protected static DAOSecurity m_daoSecurity = new DAOSecurity();
	protected PermissionHandler permissionHandler = new PermissionHandler();
	private static String m_sNonMenuProfilesXML;

	// General constants.
	private static final String DAO_SECURITY_CLASSPATH = "backend.core.module.security.dataaccess.dao.DAOSecurity";
	private static final String SESSION_TYPE_WEB = "WEB";
	private static final String REC_STATUS_AC = "AC";
	private static final String WEBUSERLIV_DEFUALT_VALUE = "300";
	private static final String QUEUE_NAME_GENERIC_SEARCH = "MENUQSRCH";
	private static final String UNLIMITED_PASSWD_CHANGES_DAY = "0";
	private static final int DEFAULT_MAX_PASSWORD_LEN = 8;
	private static final int DEFAULT_MIN_PASSWD_CHAR = 3;
	private static final int DEFAULT_MIN_PASSWD_DIGIT = 3;
	private static final String DEFAULT_NUM_OLD_PASS = "5";

	// ERRORLOG table related constants.
	private static final String SECURITY_MESSAGE_PREFIX = "Security level error- (Security Bean) - ";
	private static final String SECURITY_MODULE = "SecureBean";
	protected static final String ERROR_CODE_27004 = "27004";

	// DEPARTMENT table columns.
	private static final String COLUMN_DEPARTMENT_OFFICE = "OFFICE";

	// OLDPSWDS table columns.
	private static final String COLUMN_OLDPSWDS_PASSWDDATE = "PASSWDDATE";
	private static final String COLUMN_OLDPSWDS_PASSWDTIME = "PASSWDTIME";

	// USERS table columns.
	private static final String COLUMN_USERS_USER_NAME = "USER_NAME";
	private static final String COLUMN_USERS_OFFICE = "OFFICE";
	private static final String COLUMN_USERS_DEPARTMENT = "DEPARTMENT";
	private static final String COLUMN_USERS_BAD_LOGIN = "BAD_LOGIN";
	private static final String COLUMN_USERS_MAX_AMOUNT = "MAX_AMOUNT";
	private static final String COLUMN_USERS_BUSINESS_AREA = "BUSINESS_AREA";
	private static final String COLUMN_USERS_MAX_FORCE_AMOUNT = "MAX_FORCE_AMOUNT";
	protected static final String COLUMN_USERS_U_ENT_NAME = "U_ENT_NAME";
	protected static final String COLUMN_USERS_REC_STATUS = "REC_STATUS";
	private static final String COLUMN_USERS_USERPASSWD = "USERPASSWD";
	private static final String COLUMN_USERS_TEMPPASSWD = "TEMPPASSWD";
	private static final String COLUMN_USERS_PASSWDDATE = "PASSWDDATE";
	private static final String COLUMN_USERS_LOGGED_IN = "LOGGED_IN";
	private static final String COLUMN_USERS_SUSPENDED = "SUSPENDED";
	private static final String COLUMN_USERS_LASTLOGIN_DATE = "LASTLOGIN_DATE";
	private static final String COLUMN_USERS_UID_USERS = "UID_USERS";
    
	// BANKS table columns.
	private static final String COLUMN_BANKS_CALNAME = "CALNAME";
	private static final String COLUMN_BANKS_CURRENCY = "CURRENCY";
	private static final String COLUMN_BANKS_BSNESSDATE = "BSNESSDATE";

	// USER_ENTITLEMENT table columns.
	private static final String COLUMN_USER_ENTITLEMENT_ACCS_PROF = "ACCS_PROF";
	private static final String COLUMN_USER_ENTITLEMENT_MSG_PROF = "MSG_PROF";
	private static final String COLUMN_USER_ENTITLEMENT_Q_PROF = "Q_PROF";
	private static final String COLUMN_USER_ENTITLEMENT_BANK_PROF = "BANK_PROF";
	private static final String COLUMN_USER_ENTITLEMENT_ALERT_PROF = "ALERT_PROF";
	private static final String COLUMN_USER_ENTITLEMENT_RULE_TYPES_PROF = "PRULE_TYPE_PROF";
    private static final String COLUMN_USER_ENTITLEMENT_REC_STATUS = "REC_STATUS";
    
	// USER_VACATION table columns.
	private static final String COLUMN_USER_VACATION_V_START_DATE = "V_START_DATE";
	private static final String COLUMN_USER_VACATION_V_END_DATE = "V_END_DATE";

	// ACCESSPROFILEVIEW view columns.
	private static final String COLUMN_ACCESSPROFILEVIEW_FIELD_NAME = "FIELD_NAME";
	private static final String COLUMN_ACCESSPROFILEVIEW_PERMISIONTYPE = "PERMISIONTYPE";

	// BPROFILE table columns.
	private static final String COLUMN_BPROFILE_OFFICE = "OFFICE";
	private static final String COLUMN_BPROFILE_PERMISIONTYPE = "PERMISIONTYPE";

	// MPROFILE table columns.
	private static final String COLUMN_MPROFILE_MSG_TYPE = "MSG_TYPE";
	private static final String COLUMN_MPROFILE_MSGSUBTYPE = "MSGSUBTYPE";
	private static final String COLUMN_MPROFILE_PERMISIONTYPE = "PERMISIONTYPE";

	// QPROFILE table columns.
	private static final String COLUMN_QPROFILE_MSG_STATUS = "MSG_STATUS";
	private static final String COLUMN_QPROFILE_PERMISIONTYPE = "PERMISIONTYPE";

	// STATUSES table columns.
	private static final String COLUMN_STATUSES_USERDEFINE = "USERDEFINE";

	// ALERT_PROFILES table columns.
	private static final String COLUMN_ALERT_PROFILES_ALERTS_UID = "ALERTS_UID";

	// USER_BUSINESS_AREAS table columns.
	private static final String COLUMN_USER_BUSINESS_AREAS_BUSINESS_AREA = "BUSINESS_AREA";

	// PRULE_TYPE_PROFILES table columns.
	private static final String COLUMN_PRULE_TYPE_PROFILES_RULE_TYPE_ID = "RULE_TYPE_ID";
	
	// PRULE_TYPES table columns.
	private static final String COLUMN_PRULE_TYPES_SYSTEM_IND = "SYSTEM_IND";

	// USERS_EXTRA_DATA table columns.
	private static final String COLUMN_USERS_EXTRA_DATA_DATA_TYPE = "DATA_TYPE";
	private static final String COLUMN_USERS_EXTRA_DATA_LAYOUT_POSITION = "LAYOUT_POSITION";
	private static final String COLUMN_USERS_EXTRA_DATA_FILTER_FIELDS = "FILTER_FIELDS";
	private static final String COLUMN_USERS_EXTRA_DATA_ADDITIONAL_DATA = "ADDITIONAL_DATA";

	// Error codes.
	private static final int ERROR_CODE_INVALID_USER_PASSWORD = 98;
	private static final int ERROR_CODE_USER_TEMP_PASSWORD_CHANGE_REQUIRED = 99;
	private static final int ERROR_CODE_USER_PASSWORD_CHANGE_REQUIRED = 99;

	// Error messages.
	private static final String ERROR_MESSAGE_LOGIN_FAILED = "Login failed";
	private static final String ERROR_MESSAGE_NO_DATA_FOR_USER_ENT_NAME = "No data found for this user entitlement name: ";
	private static final String ERROR_MESSAGE_EMPTY_USER_ENT_NAME = "Empty user entitlement name";
	private static final String ERROR_MESSAGE_SESSION_VIOLATION = "User is NOT logged in";
	private static final String ERROR_MESSAGE_WRONG_USER_PASSWORD_CONFIRM = "The new password and the verify password are not equal.";
	private static final String ERROR_MESSAGE_EMPTY_USER_PASSWORD = "No new password was supplied.";
	private static final String ERROR_MESSAGE_EMPTY_OLDPASSWORD = "No old password was supplied.";
	private static final String ERROR_MESSAGE_NEW_PASSWORD_EQUAL_OLD_PASSWORD = "New password is the same as the old password.";
	private static final String ERROR_MESSAGE_EMPTY_USERNAME = "No User ID was supplied.";
	private static final String ERROR_MESSAGE_EXCEED_LIMIT_PASSWD_CHANGES = "You have exceeded the limit of password changes for one day.\r\nPlease contact your Security Supervisor.";
	private static final String ERROR_MESSAGE_MIN_PASSWD_LEN = "Password length must be at least %s characters.";
	private static final String ERROR_MESSAGE_MAX_PASSWD_LEN = "Password length must be no more than %s characters.";
	private static final String ERROR_MESSAGE_MIN_PASSWD_CHAR = "Passwords must contain at least %s letters.";
	private static final String ERROR_MESSAGE_MIN_PASSWD_DIGIT = "Passwords must contain at least %s numbers.";
	private static final String ERROR_MESSAGE_PASSWD_ALREADY_USED = "This password has been used previously.  You may enter another password.";
	private static final String ERROR_MESSAGE_PASSWD_EQUAL_USERID = "The password must not be the same as the user ID.";
	private static final String ERROR_MESSAGE_PASSWD_HAS_BLANKS = "The password must not contain leading or trailing blanks.";
	private static final String ERROR_MESSAGE_PASSWD_HAS_IDENTICAL_CHARACTERS = "Password must not contain more than two sequential identical characters.";
	private static final String ERROR_MESSAGE_EMPTY_DB_PASSWORD = "User % does not have an old password in the database, contact your system administrator.";
	private static final String ERROR_MESSAGE_WRONG_PASSWORD = "Error while updating new password,wrong password was supplied";

	protected static final int ERROR_CODE_USER_INVALID = 28685;

	/**
	 * Constructor.
	 */
	public BOSecurity()
	{
	}

	// //////////////////////////////////////
	// /////// START LOGIN METHODS //////////
	// //////////////////////////////////////

	/**
	 * Handles user login.
	 */
	public SimpleResponseDataComponent login(UserCredentials credentials)
	{

		String sIP = credentials.getIP();
		String sUserID = credentials.getUserName();
		String sPassword = credentials.getPassword();

		SimpleResponseDataComponent response = new SimpleResponseDataComponent();

		UserTransaction[] arrTransactionHolder = new UserTransaction[1];
		Feedback feedback = startTransaction(arrTransactionHolder);

		// Successfull transaction opening.
		if (feedback.isSuccessful())
		{
			int[] arrBadLoginCountHolder = new int[1];
			response = doLogin(sUserID, sPassword, sIP, arrTransactionHolder, arrBadLoginCountHolder, feedback);
		}

		// Failure transcation opening.
		else
		{
			response.setFeedback(feedback);
		}

		return response;
	}
	
	
	public SimpleResponseDataComponent login(String username,String pwd,String ip)
	{
		
		//create admin instance if doesn't exist
		Admin admin = Admin.getContextAdmin() ; 
		if(admin == null){
			logger.error("No Admin was found, creating a default, anonymous context admin. Note:  subsequent user authorizations will fail!!"); 
			admin = new Admin(GlobalConstants.ANONYMOUS_CONTEXT_ID, CallSource.Gui) ;
		}
		//store admin on local-thread:
		Admin.setContextAdmin(admin) ;

		String sIP = ip;

		String sUserID = username;
		String sPassword = pwd;

		SimpleResponseDataComponent response = new SimpleResponseDataComponent();

		UserTransaction[] arrTransactionHolder = new UserTransaction[1];
		Feedback feedback = startTransaction(arrTransactionHolder);

		// Successfull transaction opening.
		if (feedback.isSuccessful())
		{
			int[] arrBadLoginCountHolder = new int[1];
			response = doLogin(sUserID, sPassword, sIP, arrTransactionHolder, arrBadLoginCountHolder, feedback);
		}

		// Failure transcation opening.
		else
		{
			response.setFeedback(feedback);
		}

		return response;
	}
	
	
	
	
	private String[] getDepShow(UserEntitlementData userEntitlementData) {
				String sORIG_PERM_PROF_DEPARTMENT = userEntitlementData.getORIG_PERM_PROF_DEPARTMENT();
				
				String[] sORIG_PERM_PROF_DEPARTMENTArray = sORIG_PERM_PROF_DEPARTMENT.split("@@@");
				
				return sORIG_PERM_PROF_DEPARTMENTArray;
	}
	/**
	 * Performs login.
	 */

	private SimpleResponseDataComponent doLogin(String sUserID, String sPassword, String sIP,
			UserTransaction[] arrTransactionHolder, int[] arrBadLoginCountHolder, Feedback feedback)
	{
		

		SimpleResponseDataComponent response = new SimpleResponseDataComponent();

		UserLoginData userLoginData = null;

		boolean[] arrInvalidUserID = new boolean[1];
		boolean bSuccessfullLoginProcess=false;
		boolean bUserShouldBeSuspended=false;
		boolean bCommitTransaction=false;
		try
		{
		DTODataHolder dtoUsers = getUserProfile(sUserID, arrInvalidUserID);

		feedback = dtoUsers.getFeedBack();

		// Success.
		if (feedback.isSuccessful())
		{
			userLoginData = new UserLoginData(sUserID, sIP);
			setLastLoginInfo(userLoginData, dtoUsers);
			setBadLoginCount(userLoginData, dtoUsers, arrBadLoginCountHolder);

			final WebSessionInfo webSessionInfo = new WebSessionInfo();
			feedback = performLogin(sUserID, sPassword, sIP, userLoginData, dtoUsers, webSessionInfo);

			// Successfull login.
			if (feedback.isSuccessful())
			{
				// Sets bad login info.
				int iBadLoginCount = userLoginData.getBadLoginCount();
				
				if (iBadLoginCount > 0)
				{
					userLoginData.setBadLoginInfoMessage(new Integer(iBadLoginCount).toString());
				}

				// Sets department data.
				UserEntitlementData userEntitlementData = EntitlementsDataFactory.getInstance().getUserEntitlementData(
						userLoginData.getUserEntitlementName());
				String sPERM_PROF_DEPARTMENT = userEntitlementData.getPERM_PROF_DEPARTMENT();
				
				// get departemnt premission from userEntitlementData
				String[] sORIG_PERM_PROF_DEPARTMENT_SHOW = getDepShow(userEntitlementData);
				
			
				setDepartmentData(userLoginData, sPERM_PROF_DEPARTMENT, sORIG_PERM_PROF_DEPARTMENT_SHOW);

				// Sets user preferences.
				setUserPreferences(userLoginData);

				// Sets default business date.
				setDefaultBusinessDate(userLoginData);
				
				// Sets non menu profiles' XML.
				setNonMenuProfilesXML(userLoginData);

				// Updates returned value.
				response.setDataArray(new Object[] { userLoginData });

				// Writes audit into ACTIVITY_AUDIT table.
				updateACTIVITY_AUDIT_Table(true, userLoginData, null, null, null);
			}

			// Failure login.
			else
			{
				response.setFeedback(feedback);
			}
		}

		// Failure getting USERS record for passed user.
		else
		{
			response.setFeedback(feedback);
		}

			bSuccessfullLoginProcess = response.getFeedback().isSuccessful();
			bUserShouldBeSuspended = userLoginData != null && userLoginData.shouldSuspendUser();
	
			bCommitTransaction = bSuccessfullLoginProcess || bUserShouldBeSuspended;
		}
		catch (Throwable e) 
		{
			logger.error("doGetEntitlementData",e);
			feedback.setFailure();
			feedback.setErrorCode(ERROR_CODE_GENERAL);
			feedback.setErrorText(e.getMessage());
		}
		finally
		{
			// Transaction commit/rollback.
			Feedback fbTransaction = endTransaction(arrTransactionHolder[0], bCommitTransaction);
			if (!fbTransaction.isSuccessful())
			{
				response.setFeedback(fbTransaction);
			}
		}
		// Valid user ID was sent.
		if (!arrInvalidUserID[0])
		{
			// If:
			// 1) Login process has failed.
			// 2) User wasn't suspended during the login process.
			// 3) The bad login count was updated.
			// , than updates the USERS table with the new bad login count.
			if (userLoginData != null && !bSuccessfullLoginProcess && !bUserShouldBeSuspended
					&& userLoginData.getBadLoginCount() > arrBadLoginCountHolder[0])
			{
				updateBadLoginCount(sUserID, userLoginData.getBadLoginCount(), true);
			}
		}

		

		return response;
	}

	/**
	 * Updates the ACTIVITY_AUDIT table.
	 * 
	 * @param bForLogin true - login, false - logout.
	 * @param userLoginData UserLoginData object; will be null when 'bForLogin' is false.
	 * @param sUserID the user ID; can be null for login and in that case the value will be taken from the passed UserLoginData object.
	 * @param sDefaultOffice the default office of the user; can be null for login and in that case the value will be taken from the passed
	 *            UserLoginData object.
	 * @param sLogoutDate logout date; will be null when 'bForLogin' is true.
	 */
	private void updateACTIVITY_AUDIT_Table(boolean bForLogin, UserLoginData userLoginData, String sUserID, String sDefaultOffice, String sLogoutDate)
	{
		// Login.
		final String ACTIVITY_TYPE_LOGIN = "User Login";
		final String ACTIVITY_NAME_LOGIN = "User Login";

		// Logout.
		final String ACTIVITY_TYPE_LOGOUT = "User Logout";
		final String ACTIVITY_NAME_LOGOUT = "User Logout";

		

		sUserID = isNullOrEmpty(sUserID) ? userLoginData.getUserID() : sUserID;
		sDefaultOffice = isNullOrEmpty(sDefaultOffice) ? userLoginData.getDefaultOffice() : sDefaultOffice;

		ErrorAuditInputData eaInputData = bForLogin ? new ErrorAuditInputData(true, Admin.getContextAdmin().getSessionID(), getModuleID(),
				sUserID, sDefaultOffice, ACTIVITY_TYPE_LOGIN, ACTIVITY_NAME_LOGIN, Admin.getContextAdmin().getClientRemoteAddress())
				: new ErrorAuditInputData(true, Admin.getContextAdmin().getSessionID(), getModuleID(), sUserID, sDefaultOffice,
						ACTIVITY_TYPE_LOGOUT, ACTIVITY_TYPE_LOGOUT, Admin.getContextAdmin().getClientRemoteAddress());

		DateAndZone dateAndZone = NewASDateTimeUtils.getCurrentDateAndZoneByOffice(sDefaultOffice);
		eaInputData.setUserStartDateAndTime(dateAndZone.getDate());

		// Login.
		if (bForLogin)
		{
			// Last login date message.
			String sLastLoginDate = userLoginData.getLastLoginDate();
			if (!isNullOrEmpty(sLastLoginDate))
			{
				eaInputData.setErrorCode((long) ProcessErrorConstants.LastLoginDateMessage);
				eaInputData.setNonPaymentsFields(new Object[] { sLastLoginDate });
				ErrorAuditUtils.handleErrorAndAudit(eaInputData);
			}
			//
			// Bad login count.
			int iBadLoginCount = userLoginData.getBadLoginCount();
			if (iBadLoginCount > 0)
			{
				eaInputData.setErrorCode((long) ProcessErrorConstants.BadLoginCountMessage);
				eaInputData.setNonPaymentsFields(new Object[] { sUserID, iBadLoginCount });
				ErrorAuditUtils.handleErrorAndAudit(eaInputData);
			}
		}

		// Logout.
		else
		{
			eaInputData.setErrorCode((long) ProcessErrorConstants.LogoutMessage);
			eaInputData.setNonPaymentsFields(new Object[] { sUserID, sLogoutDate });
			ErrorAuditUtils.handleErrorAndAudit(eaInputData);
		}

		
	}

	/**
	 * Set the user preferences into the passed UserLoginData object.
	 */
	protected void setUserPreferences(UserLoginData userLoginData)
	{
		// Sets static data profiles user preferences.
		setStaticDataProfilesUserPrefs(userLoginData);

		// Sets queue explorer open folders IDs.
		setQExplorerOpenedFoldersIDs(userLoginData);

		// Sets window layout position preferences matrix.
		setWindowsLayoutPositionDataMatrix(userLoginData);

		// // Sets generic search filter data.
		// String sRuleID = setGenericSearchFilterData(userLoginData);
		//    
		// // Sets generic search filter method.
		// if(!sRuleID.equals(ServerConstants.EMPTY_STRING))
		// {
		// setGenericSearchFilterMethod(sRuleID, userLoginData);
		// }

		// Sets generic search data from USERS_EXTRA_DATA table, (layout position and additional data).
		setGenericSearchDataFromUSERS_EXTRA_DATA(userLoginData);
	}

	/**
	 * Returns the max login tries allowed for this user.
	 */
	private int getMaxLoginTries(DTODataHolder dtoUsers)
	{
		final String DEFAULT_MAX_TRIES = "6";

		String sOffice = dtoUsers.getColumnData(COLUMN_USERS_OFFICE);

		String sMaxLoginTries = SystParKey.getSingleParmValue(sOffice, SystemParametersInterface.SYS_PAR_LOGONRETRY);

		if (isNullOrEmpty(sMaxLoginTries))
			sMaxLoginTries = DEFAULT_MAX_TRIES;

		return Integer.valueOf(sMaxLoginTries).intValue();
	}

	/**
	 * Gets a user ID and returns its profile from the USERS table.
	 */
	protected DTODataHolder getUserProfile(String sUserID, boolean[] arrInvalidUserID)
	{
		return this.getUserProfile(sUserID, arrInvalidUserID, null);
	}// EOM

	/**
	 * Gets a user ID and returns its profile from the USERS table.
	 */
	protected DTODataHolder getUserProfile(String sUserID, boolean[] arrInvalidUserID, String sUserEntitlementName)
	{
		

		final String ERROR_MESSAGE_1 = "BOSecurity.getUserProfile - error while retrieving user data; the user ID was not supplied.";
		final String ERROR_MESSAGE_2 = "BOSecurity.getUserProfile - error while retrieving user data; the user ID can't be more than 8 characters.";
		final String ERROR_MESSAGE_3 = "BOSecurity.getUserProfile - error while retrieving user data; the user ID or Role name doesn't exist.";
		final String ERROR_MESSAGE_4 = "BOSecurity.getUserProfile - error while retrieving user data.";

		DTODataHolder dtoUsers = new DTODataHolder();

		Feedback feedback = new Feedback();

		String sErrorText = null;
		boolean bSuccess = true;

		// Invalid/Illegal user ID.
		if (isNullOrEmpty(sUserID))
		{
			bSuccess = false;
			sErrorText = ERROR_MESSAGE_1;
		}

		// User ID is too long.
		else if (sUserID.length() > 8)
		{
			bSuccess = false;
			sErrorText = ERROR_MESSAGE_2;
			arrInvalidUserID[0] = true;
		}

		// Valid user ID.
		else
		{
			// Gets the data for this user from the USERS table (sUserEntitlementName as the entitlement name
			// is not accessible until the fetch)
			dtoUsers = this.getUserRecord(sUserID, sUserEntitlementName);

			// Success.
			if (dtoUsers.isFeedBackSuccess())
			{
				// Invalid user ID.
				if (dtoUsers.isEmpty())
				{
					bSuccess = false;
					sErrorText = ERROR_MESSAGE_3;
					arrInvalidUserID[0] = true;
				}
			}

			// Failure.
			else
			{
				dtoUsers.getFeedBack().setErrorText(ERROR_MESSAGE_4);
				dtoUsers.getFeedBack().setUserErrorText(ERROR_MESSAGE_LOGIN_FAILED);

				logger.error(ERROR_MESSAGE_4);
			}
		}

		// Failure.
		if (!bSuccess)
		{
			feedback.setFailure();
			feedback.setErrorCode(ProcessErrorConstants.PermissionError);
			feedback.setErrorText(sErrorText);
			feedback.setUserErrorText(ERROR_MESSAGE_LOGIN_FAILED);
			dtoUsers.setFeedback(feedback);

			logger.error(sErrorText);
		}

		// Login failed.
		if (!dtoUsers.isFeedBackSuccess())
		{
			final String ERRORLOG_ERROR_MESSAGE = "Login Failed";
			String sMessage = constructErrorMessage(sUserID, ERRORLOG_ERROR_MESSAGE);
			// Feedback feedbackErrorLog = m_daoSecurity.writeToErrorLog(SECURITY_MODULE, sMessage, sUserID, ERROR_CODE_27004, false);
			ErrorAuditUtils.setErrors(ProcessError.getError(ProcessErrorConstants.LoginError, new String[] { sMessage }, ""));

			// if(!feedbackErrorLog.isSuccessful())
			// {
			// logger.error(GlobalUtils.getFeedbackString(feedbackErrorLog));
			// }
		}

		

		return dtoUsers;
	}

	/**
	 * Hook method to be customized by subclasses to deal with update or insert behaviour
	 * 
	 * @param sUseId unique identifyer of the user
	 * @param sUserEntitlementName identifyer of the user's permission set, might be null
	 * @return {@link DTODataHolder} containing the user's record
	 */
	protected DTODataHolder getUserRecord(String sUserID, String sUserEntitlementName)
	{
		return m_daoSecurity.getUserData(sUserID);
	}// EOM

	/**
	 * Constructs an error message to be written into the ERRORLOG table.
	 */
	private String constructErrorMessage(String sUserID, String sErrorMessage)
	{
		final String COMMA_SPACE = ServerConstants.COMMA + ServerConstants.SPACE;

		return new StringBuffer(SECURITY_MESSAGE_PREFIX).append(sUserID).append(COMMA_SPACE).append(sErrorMessage).toString();
	}

	/**
	 * Performs login.
	 */
	protected Feedback performLogin(String sUserID, String sPassword, String sIP, UserLoginData userLoginData,
			DTODataHolder dtoUsers, final WebSessionInfo webSessionInfo)
	{
		

		Feedback feedback = new Feedback();

		feedback = checkUserStatus(sPassword, dtoUsers, userLoginData, webSessionInfo);

		if (feedback.isSuccessful())
		{
			feedback = getUserProfiles(userLoginData);
		}
		
		// Either we have problems with the user status, or retrieving user profiles didn't succeed.
		if (!feedback.isSuccessful())
		{
			int iErrorCode = feedback.getErrorCode();

			// Invalid user password.
			if (iErrorCode == ERROR_CODE_INVALID_USER_PASSWORD)
			{
				int iBadLoginCount = userLoginData.getBadLoginCount();
				int iMaxAllowedLoginFailures = getMaxLoginTries(dtoUsers);

				if (iBadLoginCount < iMaxAllowedLoginFailures)
				{
					final String ERRORLOG_ERROR_MESSAGE = "Login Failed";
					String sMessage = constructErrorMessage(sUserID, ERRORLOG_ERROR_MESSAGE);
					ErrorAuditUtils.setErrors(ProcessError.getError(ProcessErrorConstants.LoginError, new String[] { sMessage }, ""));

					updateBadLoginCount(sUserID, userLoginData.getBadLoginCount(), false);
				}

				// User failed to login more than allowed login tries.
				else
				{
					final String ERRORLOG_ERROR_MESSAGE = "Wrong password entered. User will be suspended";
					String sMessage = constructErrorMessage(sUserID, ERRORLOG_ERROR_MESSAGE);
					ErrorAuditUtils.setErrors(ProcessError.getError(ProcessErrorConstants.LoginError, new String[] { sMessage }, ""));

					final String TRACE_MESSAGE = "User retries to log more than allowed and will be suspended.";
					logger.error(TRACE_MESSAGE);

					suspendUser(userLoginData, sPassword, iBadLoginCount);
				}
			}

			// User needs to change his password.
			else if (iErrorCode == ERROR_CODE_USER_PASSWORD_CHANGE_REQUIRED)
			{
				final String TRACE_MESSAGE = "User needs to change his password.";
				logger.error(TRACE_MESSAGE);

				final String ERRORLOG_ERROR_MESSAGE = ". Need to change his password";
				String sMessage = constructErrorMessage(sUserID, ERRORLOG_ERROR_MESSAGE);
				ErrorAuditUtils.setErrors(ProcessError.getError(ProcessErrorConstants.LoginError, new String[] { sMessage }, ""));
			}

			// No special error code; sets to general error code.
			else
			{
				feedback.setErrorCode(ERROR_CODE_GENERAL);
			}
		}

		if (feedback.isSuccessful())
		{
			// Sets the user as logged in.
			feedback = setUserLoggedIn(userLoginData, webSessionInfo, sPassword);

			// Cleans the WEB_PROFILE_LOCK table from records with this user ID.
			cleanUserIDExistingLockRecords(sUserID);
		}

		

		return feedback;
	}

	/**
	 * Checks the user status, (temp password, password date, suspension status, etc).
	 */
	protected Feedback checkUserStatus(String sUserPassword, DTODataHolder dtoUsers, UserLoginData userLoginData, final WebSessionInfo webSessionInfo)
	{
		String sUserID = userLoginData.getUserID();
		

		Feedback feedback = new Feedback();

		// The parallel C++ method is 'MapUsersDBToFTUser'.
		feedback = updateUserLoginData(dtoUsers, userLoginData);

		// Updates related WebSessionInfo object values.
		if (feedback.isSuccessful())
		{
			updateWebSessionInfoHM(webSessionInfo, userLoginData);
		}

		// Checks if user is active.
		if (feedback.isSuccessful())
		{
			feedback = checkUserIsActive(userLoginData, (String) dtoUsers.getColumnData(COLUMN_USERS_REC_STATUS));
		}

		// Checks if user is on vacation.
		if (feedback.isSuccessful())
		{
			feedback = checkUserOnVacation(sUserID, sUserPassword, userLoginData);
		}

		// Checks the password.
		if (feedback.isSuccessful())
		{
			feedback = checkPassword(dtoUsers, sUserID, sUserPassword, userLoginData);
		}

		

		return feedback;
	}

	/**
	 * Updates the passed UserLoginData object according to the data in the passed 'dtoUsers' parameter.
	 */
	protected Feedback updateUserLoginData(DTODataHolder dtoUsers, UserLoginData userLoginData)
	{
		String sUserID = userLoginData.getUserID();
		

		Feedback feedback = new Feedback();

		HashMap hmData = dtoUsers.getDataRow();

		// User name.
		String sUserName = (String) hmData.get(COLUMN_USERS_USER_NAME);
		userLoginData.setUserName(sUserName);

		// Office.
		String sOffice = (String) hmData.get(COLUMN_USERS_OFFICE);
		userLoginData.setDefaultOffice(sOffice);

		// Department.
		String sDepartment = (String) hmData.get(COLUMN_USERS_DEPARTMENT);
		userLoginData.setDefaultDepartment(sDepartment);

		// Max amount; this might be updated during the 'saveSessionInfo' method.
		String sMaxAmount = (String) hmData.get(COLUMN_USERS_MAX_AMOUNT);
		userLoginData.setMaxAmount(sMaxAmount);

		// Business area.
		String sBusinessArea = (String) hmData.get(COLUMN_USERS_BUSINESS_AREA);
		userLoginData.setDefaultBusinessArea(sBusinessArea);

		// Max amount force NSF.
		String sMaxAmountForceNSF = (String) hmData.get(COLUMN_USERS_MAX_FORCE_AMOUNT);
		userLoginData.setMaxAmountForceNSF(sMaxAmountForceNSF);

		// User entitlement name.
		String sUserEntitlementName = (String) hmData.get(COLUMN_USERS_U_ENT_NAME);
		userLoginData.setUserEntitlementName(sUserEntitlementName);
		feedback = updateUserEntitlementData(sUserEntitlementName, userLoginData);

		

		return feedback;
	}

	/**
	 * Updates the passed UserLoginData object according to the passed user entitlement code.
	 */
	private Feedback updateUserEntitlementData(String sUserEntitlementName, UserLoginData userLoginData)
	{
		final String USER_ERROR_MESSAGE = "Error while retrieving user entitlement data.";

		String sUserID = userLoginData.getUserID();
		

		Feedback feedback = new Feedback();

		// Gets the entitlement data for this user from the USER_ENTITLEMENT table.
		DTODataHolder dtoUserEntitlementData = m_daoSecurity.getUserEntitlementData(sUserEntitlementName);

		if (dtoUserEntitlementData.isEmpty()) {
            dtoUserEntitlementData.setFeedback(dtoUserEntitlementData.getFeedBack().setFailure());
        }
		
		// Success.
		if (dtoUserEntitlementData.isFeedBackSuccess())
		{
			HashMap hmData = dtoUserEntitlementData.getDataRow(0);

			// Access profile.
			String sAccessProfile = (String) hmData.get(COLUMN_USER_ENTITLEMENT_ACCS_PROF);
			userLoginData.setAccessProfile(sAccessProfile);

			// Department profile.
			String sDepartmentProfile = (String) hmData.get(COLUMN_USER_ENTITLEMENT_BANK_PROF);
			userLoginData.setDepartmentProfile(sDepartmentProfile);

			// Queue profile.
			String sQueueProfile = (String) hmData.get(COLUMN_USER_ENTITLEMENT_Q_PROF);
			userLoginData.setQueueProfile(sQueueProfile);

			// Message profile.
			String sMessageProfile = (String) hmData.get(COLUMN_USER_ENTITLEMENT_MSG_PROF);
			userLoginData.setMessageProfile(sMessageProfile);

			// Alert profile.
			String sAlertProfile = (String) hmData.get(COLUMN_USER_ENTITLEMENT_ALERT_PROF);
			userLoginData.setAlertProfile(sAlertProfile);

			// Rule Types profile.
			String sRuleTypesProfile = (String) hmData.get(COLUMN_USER_ENTITLEMENT_RULE_TYPES_PROF);
			userLoginData.setRuleTypesProfile(sRuleTypesProfile);
			
		    // User entitlement status.
            String sUserEntitlementRecStatus = (String) hmData.get(COLUMN_USER_ENTITLEMENT_REC_STATUS);
            userLoginData.setUserEntitlementRecStatus(sUserEntitlementRecStatus);

		}

		// Failure.
		else
		{
			feedback = dtoUserEntitlementData.getFeedBack();
			feedback.setErrorText(USER_ERROR_MESSAGE);
			feedback.setUserErrorText(USER_ERROR_MESSAGE);
		}

		

		return feedback;
	}

	/**
	 * 
	 */
	protected void updateWebSessionInfoHM(final WebSessionInfo webSessionInfo, UserLoginData userLoginData)
	{
		String sUserID = userLoginData.getUserID();
		

		webSessionInfo.setUserID(userLoginData.getUserID());
		webSessionInfo.setUEntName(userLoginData.getUserEntitlementName());
		webSessionInfo.setMaxAmountForceNSF(userLoginData.getMaxAmountForceNSF());
		webSessionInfo.setDefualtBusinessArea(userLoginData.getDefaultBusinessArea());
		webSessionInfo.setMaxAmountForceNSF(userLoginData.getMaxAmount());
		webSessionInfo.setDefaultOffice(userLoginData.getDefaultOffice());
		webSessionInfo.setDefaultDepartment(userLoginData.getDefaultDepartment());
		webSessionInfo.setSessionType(SESSION_TYPE_WEB);

		
	}

	/**
	 * Checks if the user is active according to the REC_STATUS column value.
	 */
	protected Feedback checkUserIsActive(UserLoginData userLoginData, String sUserRecStatus)
	{
		final String ERROR_MESSAGE = "The specified user is not active";

		String sUserID = userLoginData.getUserID();

		

		Feedback feedback = new Feedback();

		if (!REC_STATUS_AC.equalsIgnoreCase(sUserRecStatus))
		{
			feedback.setFailure();
			feedback.setErrorText(ERROR_MESSAGE);
			feedback.setUserErrorText(ERROR_MESSAGE);

			logger.error(ERROR_MESSAGE);

			userLoginData.incrementBadLoginCount();
		}

		

		return feedback;
	}

	/**
	 * checks if the passed user ID is on vacation.
	 */
	private Feedback checkUserOnVacation(String sUserID, String sUserPassword, UserLoginData userLoginData)
	{
		final String ERROR_MESSAGE = "User is on vacation, and has been suspended. Please contact your system adminstrator.";
		final String VACATION_START_DATE = "Vacation START date - ";
		final String VACATION_END_DATE = ". Vacation END date - ";
		final String CURRENT_DATE = ". CURRENT date - ";

		

		Feedback feedback = new Feedback();

		// Gets the vacation data for this user from the USER_VACATION table.
		DTODataHolder dtoUserVacationData = m_daoSecurity.getUserVacationData(sUserID);

		// Success and there is data for this user.
		if (dtoUserVacationData.isFeedBackSuccess() && !dtoUserVacationData.isEmpty())
		{
			HashMap hmData = dtoUserVacationData.getDataRow(0);

			SimpleDateFormat simpleDateFormat = GlobalDateTimeUtil.getSimpleDateFormatByFormat(GlobalDateTimeUtil.STATIC_DATA_DATE);

			String sVacationStartDate = (String) hmData.get(COLUMN_USER_VACATION_V_START_DATE);
			String sVacationEndDate = (String) hmData.get(COLUMN_USER_VACATION_V_END_DATE);
			String sCurrentDate = simpleDateFormat.format(new Date());

			String sDates = new StringBuffer(VACATION_START_DATE).append(sVacationStartDate).append(VACATION_END_DATE).append(sVacationEndDate)
					.append(CURRENT_DATE).append(sCurrentDate).toString();
			logger.trace(sDates);

			if (GlobalDateTimeUtil.isCurrentDateBetweenTwoDates(sVacationStartDate, sVacationEndDate, simpleDateFormat))
			{
				feedback.setFailure();
				feedback.setErrorText(ERROR_MESSAGE);
				feedback.setUserErrorText(ERROR_MESSAGE);

				logger.error(ERROR_MESSAGE);

				userLoginData.incrementBadLoginCount();

				suspendUser(userLoginData, sUserPassword, userLoginData.getBadLoginCount());
			}
		}

		// Failure.
		else
		{
			feedback = dtoUserVacationData.getFeedBack();
		}

		

		return feedback;
	}

	/**
	 * Suspends the passed user ID.
	 */
	private Feedback suspendUser(UserLoginData userLoginData, String sUserPassword, int iLoginFailuresCount)
	{
		final String ERROR_MESSAGE_1 = "Error while updating USERS table to suspend user.";
		final String ERROR_MESSAGE_2 = "Failed to insert new password to OLDPSWDS table.";

		String sUserID = userLoginData.getUserID();

		

		userLoginData.setShouldSuspendUser(true);

		Feedback feedback = m_daoSecurity.setUserAsSuspended(sUserID, String.valueOf(iLoginFailuresCount));

		if (feedback.isSuccessful())
		{
			String sEncryptedPassword = getEncryptedPassword(sUserPassword);

			// The combination of user ID and password doesn't exist yet in the OLDPSWDS table.
			if (!(m_daoSecurity.doesPasswordExistInOLDPSWDS_Table(sUserID, sEncryptedPassword)).getValue())
			{
				String sPasswordDate = m_daoSecurity.getFormattedSystemDateFromDatabase(null, GlobalDateTimeUtil.STATIC_DATA_DATE);
				String sPasswordTime = m_daoSecurity.getSystemTimeFromDatabase();

				feedback = m_daoSecurity.updateOLDPSWDS_Table(sUserID, sUserPassword, sPasswordDate, sPasswordTime);

				if (!feedback.isSuccessful())
				{
					feedback.setErrorText(ERROR_MESSAGE_2);
				}
			}
		}

		else
		{
			feedback.setErrorText(ERROR_MESSAGE_1);
		}

		

		return feedback;
	}

	/**
	 * Checks the user password.
	 */
	private Feedback checkPassword(DTODataHolder dtoUsers, String sUserID, String sUserPassword, UserLoginData userLoginData)
	{
		

		Feedback feedback = new Feedback();

		// Invalid user password.
		if (isNullOrEmpty(sUserPassword))
		{
			final String ERROR_MESSAGE = "Login failed";
			final String TRACE_ERROR_MESSAGE = "ERROR: no password.";

			feedback.setFailure();
			feedback.setErrorCode(ERROR_CODE_INVALID_USER_PASSWORD);
			feedback.setErrorText(ERROR_MESSAGE);
			feedback.setUserErrorText(ERROR_MESSAGE);
			logger.error(TRACE_ERROR_MESSAGE);
		}

		HashMap hmData = dtoUsers.getDataRow();

		String sTempPassword = (String) hmData.get(COLUMN_USERS_TEMPPASSWD);
		String sPasswordDate = (String) hmData.get(COLUMN_USERS_PASSWDDATE);

		// Password validation should be done first and then rest of the validation should be done
		// (i.e. do rest of the validation if user logged in with valid password)
		if (feedback.isSuccessful())
		{
			String sEncryptedPassword = getEncryptedPassword(sUserPassword);

			// The user password as in the USERS table.
			String sUSERS_Password = (String) hmData.get(COLUMN_USERS_USERPASSWD);

			if (!validatePassword(sUserID, sEncryptedPassword, sUSERS_Password))
			{
				feedback.setFailure();
				feedback.setErrorCode(ERROR_CODE_INVALID_USER_PASSWORD);
				feedback.setErrorText(ERROR_MESSAGE_LOGIN_FAILED);
				feedback.setUserErrorText(ERROR_MESSAGE_LOGIN_FAILED);
				logger.error(ERROR_MESSAGE_LOGIN_FAILED);

				userLoginData.incrementBadLoginCount();
			}
		}

		// TEMPPASSWD is non-zero, but PASSWDDATE is empty.
		if (feedback.isSuccessful())
		{
			if (!sTempPassword.equals(ServerConstants.ZERO_VALUE) && sPasswordDate.equals(ServerConstants.EMPTY_STRING))
			{
				final String ERROR_MESSAGE = "Temporary user password is true, but no 'password date period' is defined";
				final String TRACE_ERROR_MESSAGE = "Temporary user password error - TEMPPASSWD is true, but PASSWDDATE is empty.";

				feedback.setFailure();
				feedback.setErrorText(ERROR_MESSAGE);
				feedback.setUserErrorText(ERROR_MESSAGE);
				logger.error(TRACE_ERROR_MESSAGE);
			}
		}

		// Checks if user is already logged in.
		if (feedback.isSuccessful())
		{
			checkUserLoggedIn(sUserID, userLoginData, feedback);
		}

		// Checks if user is suspended.
		if (feedback.isSuccessful())
		{
			checkUserSuspended(sUserID, userLoginData, feedback, hmData);
		}

		// Checks the temporary password.
		if (feedback.isSuccessful())
		{
			final String ERROR_MESSAGE_TEMP_PASSWORD = "The temporary password must be changed";

			final String ERROR_MESSAGE_PASSWORD_EXPIRED = "The password has expired and must be changed";
			final String TRACE_ERROR_MESSAGE_PASSWORD_DAYS = "Password days error - password date is too old: ";

			// Temp password flag is true.
			if (!sTempPassword.equals(ServerConstants.ZERO_VALUE))
			{
				feedback.setFailure();
				feedback.setErrorCode(ERROR_CODE_USER_TEMP_PASSWORD_CHANGE_REQUIRED);
				feedback.setErrorText(ERROR_MESSAGE_TEMP_PASSWORD);
				feedback.setUserErrorText(ERROR_MESSAGE_TEMP_PASSWORD);
				logger.error(ERROR_MESSAGE_TEMP_PASSWORD);

				final String ERRORLOG_ERROR_MESSAGE = "User forced to change his password, temp password flag is on";
				String sMessage = constructErrorMessage(sUserID, ERRORLOG_ERROR_MESSAGE);
				ErrorAuditUtils.setErrors(ProcessError.getError(ProcessErrorConstants.LoginError, new String[] { sMessage }, ""));

			}

			// TODO - talk with Leonid: what is 'if ( m_pFTUsersApp->GetPassDays() > -1 )'
			// in 'GetUserStatus' method.
			if (false)
			{
				if (feedback.getErrorCode() != ERROR_CODE_USER_TEMP_PASSWORD_CHANGE_REQUIRED
						&& feedback.getErrorCode() != ERROR_CODE_USER_PASSWORD_CHANGE_REQUIRED)
				{
					// Password date field isn't empty.
					if (!sPasswordDate.equals(ServerConstants.EMPTY_STRING))
					{
						// Password date has passed.
						if (GlobalDateTimeUtil.isPastDate(sPasswordDate, GlobalDateTimeUtil.STATIC_DATA_DATE))
						{
							feedback.setFailure();
							feedback.setErrorCode(ERROR_CODE_USER_PASSWORD_CHANGE_REQUIRED);
							feedback.setErrorText(ERROR_MESSAGE_PASSWORD_EXPIRED);
							feedback.setUserErrorText(ERROR_MESSAGE_PASSWORD_EXPIRED);

							String sTraceMessage = new StringBuffer(TRACE_ERROR_MESSAGE_PASSWORD_DAYS).append(sPasswordDate).toString();
							logger.error(sTraceMessage);

							final String ERRORLOG_ERROR_MESSAGE = "User forced to change his password (Password days parameter)";
							String sMessage = constructErrorMessage(sUserID, ERRORLOG_ERROR_MESSAGE);
							ErrorAuditUtils.setErrors(ProcessError.getError(ProcessErrorConstants.LoginError, new String[] { sMessage }, ""));

						}
					}

					// Password date field is empty.
					else
					{
						feedback.setFailure();
						feedback.setErrorCode(ERROR_CODE_USER_PASSWORD_CHANGE_REQUIRED);
						feedback.setErrorText(ERROR_MESSAGE_PASSWORD_EXPIRED);
						feedback.setUserErrorText(ERROR_MESSAGE_PASSWORD_EXPIRED);
						logger.error(ERROR_MESSAGE_PASSWORD_EXPIRED);

						final String ERRORLOG_ERROR_MESSAGE = "User does not have a password date and so forced to change his password";
						String sMessage = constructErrorMessage(sUserID, ERRORLOG_ERROR_MESSAGE);
						ErrorAuditUtils.setErrors(ProcessError.getError(ProcessErrorConstants.LoginError, new String[] { sMessage }, ""));

					}
				}
			}

			if (feedback.isSuccessful())
			{
				String sEncryptedPassword = getEncryptedPassword(sUserPassword);

				// The user password as in the USERS table.
				String sUSERS_Password = (String) hmData.get(COLUMN_USERS_USERPASSWD);

				if (!validatePassword(sUserID, sEncryptedPassword, sUSERS_Password))
				{
					feedback.setFailure();
					feedback.setErrorCode(ERROR_CODE_INVALID_USER_PASSWORD);
					feedback.setErrorText(ERROR_MESSAGE_LOGIN_FAILED);
					feedback.setUserErrorText(ERROR_MESSAGE_LOGIN_FAILED);
					logger.error(ERROR_MESSAGE_LOGIN_FAILED);

					userLoginData.incrementBadLoginCount();
				}
			}
		}

		

		return feedback;
	}

	/**
	 * Checks if user is suspended.
	 */
	protected void checkUserSuspended(String sUserID, UserLoginData userLoginData, Feedback feedback, HashMap hmData) {
		final String ERROR_MESSAGE = "User is suspended.";
		final String USER_ERROR_MESSAGE = "You are suspended from Global PAYplus; please contact your system adminstrator";

		String sSuspended = (String) hmData.get(COLUMN_USERS_SUSPENDED);

		// User is suspended.
		if (!sSuspended.equals(ServerConstants.ZERO_VALUE))
		{
			feedback.setFailure();
			feedback.setErrorText(ERROR_MESSAGE);
			feedback.setUserErrorText(USER_ERROR_MESSAGE);
			logger.error(ERROR_MESSAGE);

			userLoginData.incrementBadLoginCount();

			final String ERRORLOG_ERROR_MESSAGE = "User is suspended, can not logged in until un-suspended";
			String sMessage = constructErrorMessage(sUserID, ERRORLOG_ERROR_MESSAGE);
			ErrorAuditUtils.setErrors(ProcessError.getError(ProcessErrorConstants.LoginError, new String[] { sMessage }, ""));

		}
	}

	/**
	 * Checks if user is already logged in.
	 */
	protected void checkUserLoggedIn(String sUserID, UserLoginData userLoginData, Feedback feedback) {
		final String ERROR_MESSAGE = "The user is currently logged in";

		final WebSessionInfo webSessionInfo = CacheKeys.UserWebSessionInfoKey.getSingle(sUserID);

		// User is already logeed in from another machine or browser.
		if (webSessionInfo != null){
			 
			feedback.setFailure();
			feedback.setErrorText(ERROR_MESSAGE);
			feedback.setUserErrorText(ERROR_MESSAGE);
			logger.error(ERROR_MESSAGE);

			userLoginData.incrementBadLoginCount();
		}//EO if the user was already loggedin
	}

	/**
	 * Gets the user password and returns an encryption of it.
	 * The encryption is done by 2 steps:
	 * 1. Encode the password using Java.Security.MessageDigest class  with algorithm "SHA-256"
	 * 	  @link http://download.oracle.com/javase/1.4.2/docs/api/java/security/MessageDigest.html 
	 * 	  This class provides the functionality of a message digest algorithm. ( secure one-way hash functions that take arbitrary-sized data and output a fixed-length hash value E.G.  MD5 or SHA).
	 *    The initialization of MessageDigest using getInstance(String algorithm), uses the package provide implementation of the algorithm, but if it's not available, other packages are searched for the algorithm implementation.
	 * 2. Encode again the 1'st step result (of 32 bytes) by using the sun.misc.BASE64Encoder.
 	 * 
	 * Those functions are called by using   java.lang.reflect.Method.invoke() 
	 * (Reflection is used to invoke a method when name of the method is supplied at run time) 
	 * @link http://download.oracle.com/javase/1.4.2/docs/api/java/lang/reflect/Method.html 
	 */
	public static String getEncryptedPassword(String sUserPassword)
	{

		String sPassword = ServerConstants.EMPTY_STRING;
		try
		{
            MessageDigest md = MessageDigest.getInstance(GlobalConstants.ENCODE_ALGORITHM);
            BASE64Encoder en = new BASE64Encoder();                                       
            
            md.update(sUserPassword.getBytes("UTF-8"));
            
            sPassword = en.encode(md.digest());
            
            md.reset();

		}
		catch (Exception e)
		{
			ExceptionController.getInstance().handleException(e, BOSecurity.class);
		}// EO catch block

		return sPassword;
	}// EOM

	/**
	 * Returns if the passed passwords are valid or not.
	 */
	private boolean validatePassword(String sUserID, String sEncryptedPassword, String sUSERS_Password)
	{
		final String ERROR_MESSAGE_INVALID_PASSWORD = "Password isn't valid !!!";
		final String PASSWORDS_INFO = "Encrypted password & database password are: ";
		final String MESSAGE_VALID_PASSWORD = "Password is valid.";

		

		boolean bValid = true;

		if (isNullOrEmpty(sEncryptedPassword) || isNullOrEmpty(sUSERS_Password) || !sEncryptedPassword.equals(sUSERS_Password))
		{
			logger.error(ERROR_MESSAGE_INVALID_PASSWORD);

			String sPasswordsInfo = new StringBuffer(PASSWORDS_INFO).append(sEncryptedPassword).append(ServerConstants.COMMA).append(sUSERS_Password)
					.toString();

			logger.error(sPasswordsInfo);

			bValid = false;
		}

		else
		{
			logger.trace(MESSAGE_VALID_PASSWORD);
		}

		

		return bValid;
	}

	/**
	 * Checks if the user ID is already logged in through the WEB.
	 */
	private boolean userIsAlreadyLoggedIn(String sUserID)
	{
		

		boolean bUserIsAlreadyLoggedIn = false;

		// Gets the WEBUSERLIV system parameter value.
		String sWebUserAlive = SystParKey.getSingleParmValue(SystemParametersInterface.SYS_PAR_WEBUSERLIV);

		sWebUserAlive = sWebUserAlive != null && !sWebUserAlive.equals(ServerConstants.EMPTY_STRING) ? sWebUserAlive : WEBUSERLIV_DEFUALT_VALUE;

		float fWebUserAlive = new Float(sWebUserAlive).floatValue() * 100 * (float) 1.5;

		if ((m_daoSecurity.userIsAlreadyLoggedIn(sUserID, new Float(fWebUserAlive))).getValue())
		{
			bUserIsAlreadyLoggedIn = true;
		}

		

		return bUserIsAlreadyLoggedIn;
	}

	/**
	 * Gets the user profiles and updates the passed UserLoginData object.
	 */
	protected Feedback getUserProfiles(UserLoginData userLoginData)
	{
		String sUserID = userLoginData.getUserID();
		

		Feedback feedback = new Feedback();

		String sUserEntitlementName = userLoginData.getUserEntitlementName();

		// Checks if there is already user entitlement data for this user entitlement name;
		// If there is, than there is no need run continue with creating all profiles
		// since we'll get the same results that already exist in the cache.
		UserEntitlementData userEntitlementData = null;
		//setting it to null always due to defect QC # 18096 TAT : Liquidity tab is visible/non-visible. when entitlement is changed in a clustered mode.
		//EntitlementsDataFactory.getInstance().getUserEntitlementData(sUserEntitlementName);

		// No data in the cache yet for this user entitlement name.
		if (userEntitlementData == null)
		{
			userEntitlementData = new UserEntitlementData(sUserEntitlementName);

			// Access profile.
			feedback = getUserAccessProfileData(userLoginData, userEntitlementData);

			// Department profile.
			if (feedback.isSuccessful())
			{
				feedback = getUserDepartmentProfileData(userLoginData, userEntitlementData);
			}

			// Office permissions.
			if (feedback.isSuccessful())
			{
				feedback = getUserOfficePermissionsData(userLoginData, userEntitlementData);
			}

			// Message profile.
			if (feedback.isSuccessful())
			{
				feedback = getUserMessageProfileData(userLoginData, userEntitlementData);
			}

			// Queue profile.
			if (feedback.isSuccessful())
			{
				feedback = getUserQueueProfileData(userLoginData, userEntitlementData);
			}

			// Alert profile.
			if (feedback.isSuccessful())
			{
				feedback = getUserAlertProfileData(userLoginData, userEntitlementData);
			}

			// Buttons permissions.
			if (feedback.isSuccessful())
			{
				feedback = getUserButtonsPermissionsData(userLoginData, userEntitlementData);
			}

			// Approve access levels permissions.
			if (feedback.isSuccessful())
			{
				feedback = getApproveAccessLevelsData(userLoginData, userEntitlementData);
			}

			// Rule types profile.
			if (feedback.isSuccessful())
			{
				feedback = getUserRuleTypesData(userLoginData, userEntitlementData);
			}

			// sets default office according to the one in USERS table.
			userEntitlementData.setOffice(userLoginData.getDefaultOffice());

			// Updates the application server cache.
			EntitlementsDataFactory.getInstance().updateDataHM(sUserEntitlementName, userEntitlementData);
		}

		// There is already data in the cache for this user entitlement name; we just
		// need to update the UserLoginData object.
//		else
//		{
//			// Access profile.
//			userLoginData.setAccessProfilePermissions(userEntitlementData.getORIG_PERM_PROF_ACCESS());
//
//			// Office permissions.
//			userLoginData.setOfficePermissions(userEntitlementData.getORIG_PERM_PROF_OFFICE());
//
//			String[][] officesAndBusinessDates = userEntitlementData.getOfficesAndBusinessDates();
//			userLoginData.setOfficesAndBusinessDates(officesAndBusinessDates[0], officesAndBusinessDates[1]);
//
//			// Department permissions.
//			userLoginData.setDepartmentProfilePermissions(userEntitlementData.getORIG_PERM_PROF_DEPARTMENT());
//
//			// Message permissions.
//			userLoginData.setMessageProfilePermissions(userEntitlementData.getORIG_PERM_PROF_MSG());
//
//			// Queue profile.
//			userLoginData.setQueueProfilePermissions(userEntitlementData.getORIG_PERM_PROF_QUEUE());
//
//			// Alert profile.
//			userLoginData.setAlertProfilePermissions(userEntitlementData.getORIG_PERM_PROF_ALERTS());
//
//			// Rule types profile.
//			userLoginData.setRuleTypesProfilePermissions(userEntitlementData.getORIG_PERM_PROF_RULE_TYPES());
//		}

		// Business area options.
		if (feedback.isSuccessful())
		{
			feedback = getUserBusinessAreaOptions(userLoginData);
		}

		

		return feedback;
	}

	/**
	 * Updates the USERS.BAD_LOGIN column.
	 */
	private void updateBadLoginCount(String sUserID, int iBadLoginCount, boolean bOpenTransaction)
	{
		

		UserTransaction[] arrTransactionHolder = null;
		Feedback feedback = new Feedback();

		// Successfull transaction opening.
		if (bOpenTransaction)
		{
			arrTransactionHolder = new UserTransaction[1];
			feedback = startTransaction(arrTransactionHolder);
		}
		boolean bSuccess=false;
		if (feedback.isSuccessful())
		{
			try
			{
			feedback = m_daoSecurity.updateBadLoginCount(sUserID, iBadLoginCount);

			bSuccess = feedback.isSuccessful();

			if (!bSuccess)
			{
				logger.error(GlobalUtils.getFeedbackString(feedback));
			}
			}
			catch (Throwable e)
			{
				logger.error("updateBadLoginCount",e);
				feedback.setFailure();
				feedback.setErrorCode(ERROR_CODE_GENERAL);
				feedback.setErrorText(e.getMessage());
			}
			finally
			{
				// Closes the opened transaction.
				if (bOpenTransaction)
				{
					feedback = endTransaction(arrTransactionHolder[0], bSuccess);
	
					if (!feedback.isSuccessful())
					{
						logger.error(GlobalUtils.getFeedbackString(feedback));
					}
				}
			}
		}

		
	}

	/**
	 * Gets the user access profile and updates the passed 'hmWebSessionInfoData' HashMap parameter.
	 */
	private Feedback getUserAccessProfileData(UserLoginData userLoginData, UserEntitlementData userEntitlementData)
	{
		final String ERROR_MESSAGE = "User access profile name is empty !!!";

		String sUserID = userLoginData.getUserID();

		

		Feedback feedback = new Feedback();

		String sAccessProfile = userLoginData.getAccessProfile();

		// Accees profile is empty.
		if (isNullOrEmpty(sAccessProfile))
		{
			logger.error(ERROR_MESSAGE);
		}

		else
		{
			DTODataHolder dtoAccessProfileData = m_daoSecurity.getUserAccessProfileData(sAccessProfile);

			if (dtoAccessProfileData.getFeedBack().isSuccessful())
			{
				String[] arrAccessProfileData = prepareAccessProfileData(sUserID, dtoAccessProfileData);

				userEntitlementData.setAccessProfileName(sAccessProfile);
				userEntitlementData.setORIG_PERM_PROF_ACCESS(arrAccessProfileData[0]);
				userEntitlementData.setPERM_PROF_ACCESS(arrAccessProfileData[1]);

				userLoginData.setAccessProfilePermissions(arrAccessProfileData[0]);
			}

			else
			{
				feedback = dtoAccessProfileData.getFeedBack();
			}
		}

		

		return feedback;
	}

	/**
	 * NOTE: This method is also called from the EntitlementsDataFactory class, for which the sent user ID is 'EntitlementsDataFactory'. Prepares the
	 * access profile data. Example for the prepared string array: Index 0 - "10000(1)@@@100001(1)@@@100002(1)". Index 1 -
	 * "'10000','100001','100002','100003','100004'".
	 */
	@SkipInputValidation
	public String[] prepareAccessProfileData(String sUserID, DTODataHolder dtoAccessProfileData)
	{
		String[] arrAccessProfileData = new String[2];

		StringBuffer sbORIG_PERM_PROF_ACCESS = new StringBuffer();
		StringBuffer sbPERM_PROF_ACCESS = new StringBuffer();

		ArrayList alData = dtoAccessProfileData.getDataAL();
		int iSize = alData.size();

		for (int i = 0; i < iSize; i++)
		{
			HashMap hmCurrentRow = (HashMap) alData.get(i);

			String sPermissionType = ((String) hmCurrentRow.get(COLUMN_ACCESSPROFILEVIEW_PERMISIONTYPE)).trim();

			// If we have empty value, we don't add this access level.
			if (!sPermissionType.equals(ServerConstants.EMPTY_STRING))
			{
				String sAccessLevel = (String) hmCurrentRow.get(COLUMN_ACCESSPROFILEVIEW_FIELD_NAME);
				sPermissionType = sPermissionType.equalsIgnoreCase(ServerConstants.PERMISSION_WRITE) ? ServerConstants.PERMISSION_WRITE_SUFFIX
						: ServerConstants.PERMISSION_READ_SUFFIX;

				// ORIG_PERM_PROF_ACCESS update.
				sbORIG_PERM_PROF_ACCESS.append(sAccessLevel).append(sPermissionType);

				// PERM_PROF_ACCESS update.
				sbPERM_PROF_ACCESS.append(ServerConstants.APOSTROPHE).append(sAccessLevel).append(ServerConstants.APOSTROPHE);

				if (i < (iSize - 1))
				{
					sbORIG_PERM_PROF_ACCESS.append(ServerConstants.PERMISSIONS_DELIMITER);
					sbPERM_PROF_ACCESS.append(ServerConstants.COMMA);
				}
			}
		}

		arrAccessProfileData[0] = sbORIG_PERM_PROF_ACCESS.toString();
		arrAccessProfileData[1] = sbPERM_PROF_ACCESS.toString();

		return arrAccessProfileData;
	}

	/**
	 * Gets the user bank profile and updates the passed 'hmWebSessionInfoData' HashMap parameter.
	 */
	private Feedback getUserDepartmentProfileData(UserLoginData userLoginData, UserEntitlementData userEntitlementData)
	{
		final String ERROR_MESSAGE = "User department profile name is empty !!!";

		String sUserID = userLoginData.getUserID();

		

		Feedback feedback = new Feedback();

		String sDepartmentProfile = userLoginData.getDepartmentProfile();

		// Department profile is empty.
		if (isNullOrEmpty(sDepartmentProfile))
		{
			logger.error(ERROR_MESSAGE);
		}

		else
		{
			DTODataHolder dtoDepartmentProfileData = m_daoSecurity.getUserDepartmentProfileData(sDepartmentProfile);

			if (dtoDepartmentProfileData.getFeedBack().isSuccessful())
			{
				String[] arrDepartmentProfileData = prepareDepartmentProfileData(sUserID, dtoDepartmentProfileData);

				userEntitlementData.setDepartmentProfileName(sDepartmentProfile);
				userEntitlementData.setORIG_PERM_PROF_DEPARTMENT(arrDepartmentProfileData[0]);
				userEntitlementData.setPERM_PROF_DEPARTMENT(arrDepartmentProfileData[1]);

				userLoginData.setDepartmentProfilePermissions(arrDepartmentProfileData[0]);
			}

			else
			{
				feedback = dtoDepartmentProfileData.getFeedBack();
			}
		}

		

		return feedback;
	}

	/**
	 * NOTE: This method is also called from the EntitlementsDataFactory class, for which the sent user ID is 'EntitlementsDataFactory'. Prepares the
	 * department profile data. Example for the prepared string array: Index 0 - "...(1)@@@999(1)@@@LDN(0)@@@NA1(1)@@@TKY(1)". Index 1 -
	 * "'...','999','LDN','NA1','TKY'".
	 */
	@SkipInputValidation
	public String[] prepareDepartmentProfileData(String sUserID, DTODataHolder dtoDepartmentProfileData)
	{
		String[] arrDepartmentProfileData = new String[2];

		StringBuffer sbORIG_PERM_PROF_DEPARTMENT = new StringBuffer();
		StringBuffer sbPERM_PROF_DEPARTMENT = new StringBuffer();
		int y = 0;
		ArrayList alData = dtoDepartmentProfileData.getDataAL();
		int iSize = alData.size();

		for (int i = 0; i < iSize; i++)
		{
			HashMap hmCurrentRow = (HashMap) alData.get(i);

			String sPermissionType = ((String) hmCurrentRow.get(COLUMN_BPROFILE_PERMISIONTYPE)).trim();

			// If we have empty value, we don't add this department.
			if (!sPermissionType.equals(ServerConstants.EMPTY_STRING))
			{
				String sOffice = (String) hmCurrentRow.get(COLUMN_BPROFILE_OFFICE);
				sPermissionType = sPermissionType.equalsIgnoreCase(ServerConstants.PERMISSION_WRITE) ? ServerConstants.PERMISSION_WRITE_SUFFIX
						: ServerConstants.PERMISSION_READ_SUFFIX;

				// ORIG_PERM_PROF_DEPARTMENT update.
				sbORIG_PERM_PROF_DEPARTMENT.append(sOffice).append(sPermissionType);

				// PERM_PROF_DEPARTMENT update.
				sbPERM_PROF_DEPARTMENT.append(ServerConstants.APOSTROPHE).append(sOffice).append(ServerConstants.APOSTROPHE);

				if (i < (iSize - 1))
				{
					sbORIG_PERM_PROF_DEPARTMENT.append(ServerConstants.PERMISSIONS_DELIMITER);
					sbPERM_PROF_DEPARTMENT.append(ServerConstants.COMMA);
				}
			}
		}

		arrDepartmentProfileData[0] = sbORIG_PERM_PROF_DEPARTMENT.toString();
		arrDepartmentProfileData[1] = sbPERM_PROF_DEPARTMENT.toString();

		return arrDepartmentProfileData;
	}

	@SkipInputValidation
	public String[] prepareRuleTypeProfileData(String sUserID, DTODataHolder dtoRuleTypeProfileData)
	{
		String[] arrRuleTypeProfileData = new String[5];

		StringBuffer sbORIG_PERM_PROF_RULE_TYPE = new StringBuffer();
		StringBuffer sbPERM_PROF_RULE_TYPE = new StringBuffer();
		StringBuffer sbPERM_WRITE_RULE_TYPE = new StringBuffer();
		StringBuffer sbPERM_WRITE_RULE_TYPE_NO_SYSTEM_RULES = new StringBuffer();
		StringBuffer sbPERM_PROF_RULE_TYPE_NO_SYSTEM_RULES = new StringBuffer();
		
		ArrayList alData = dtoRuleTypeProfileData.getDataAL();
		int iSize = alData.size();

		for (int i = 0; i < iSize; i++)
		{
			HashMap hmCurrentRow = (HashMap) alData.get(i);

			String sPermissionType = ((String) hmCurrentRow.get(COLUMN_BPROFILE_PERMISIONTYPE)).trim();

			// If we have empty value, we don't add this rule.
			if (!sPermissionType.equals(ServerConstants.EMPTY_STRING))
			{
				String sRuletypeId = (String) hmCurrentRow.get(COLUMN_PRULE_TYPE_PROFILES_RULE_TYPE_ID);
				String sSystemInd = (String) hmCurrentRow.get(COLUMN_PRULE_TYPES_SYSTEM_IND);
				
				if(sPermissionType.equalsIgnoreCase(ServerConstants.PERMISSION_WRITE))
				{
					sPermissionType = ServerConstants.PERMISSION_WRITE_SUFFIX;
					
					// All rule types (with WRITE permissions) inc. system rules, (used for DEVELOPMENT mode)
					if(sbPERM_WRITE_RULE_TYPE.length() > 0)
					{
						sbPERM_WRITE_RULE_TYPE.append(ServerConstants.COMMA);
					}
					sbPERM_WRITE_RULE_TYPE.append(sRuletypeId);
					
 				  // All rule types (with WRITE permissions) without system rules, (used for DEPLOYMENT mode)
					if(sSystemInd.equals(ServerConstants.ZERO_VALUE))
					{
						if(sbPERM_WRITE_RULE_TYPE_NO_SYSTEM_RULES.length() > 0)
						{
							sbPERM_WRITE_RULE_TYPE_NO_SYSTEM_RULES.append(ServerConstants.COMMA);
						}
						sbPERM_WRITE_RULE_TYPE_NO_SYSTEM_RULES.append(sRuletypeId);
					}
				}
				else
				{
					sPermissionType = ServerConstants.PERMISSION_READ_SUFFIX;
				}

				// ORIG_PERM_PROF_RULE_TYPE update.
				sbORIG_PERM_PROF_RULE_TYPE.append(sRuletypeId).append(sPermissionType);

				// PERM_PROF_RULE_TYPE update.
				// All rule types (with any permission) inc. system rules, (used for DEVELOPMENT mode)
				sbPERM_PROF_RULE_TYPE.append(sRuletypeId);
				
				// PERM_PROF_RULE_TYPE_NO_SYSTEM_RULES
				// All rule types (with any permission) without system rules, (used for DEPLOYMENT mode)
				if(sSystemInd.equals(ServerConstants.ZERO_VALUE))
				{
					if(sbPERM_PROF_RULE_TYPE_NO_SYSTEM_RULES.length() > 0)
					{
						sbPERM_PROF_RULE_TYPE_NO_SYSTEM_RULES.append(ServerConstants.COMMA);
					}
					sbPERM_PROF_RULE_TYPE_NO_SYSTEM_RULES.append(sRuletypeId);
				}

				if (i < (iSize - 1))
				{
					sbORIG_PERM_PROF_RULE_TYPE.append(ServerConstants.PERMISSIONS_DELIMITER);
					sbPERM_PROF_RULE_TYPE.append(ServerConstants.COMMA);
				}
			}
		}

		arrRuleTypeProfileData[0] = sbORIG_PERM_PROF_RULE_TYPE.toString();
		arrRuleTypeProfileData[1] = sbPERM_PROF_RULE_TYPE.toString();
		arrRuleTypeProfileData[2] = sbPERM_WRITE_RULE_TYPE.toString();
		arrRuleTypeProfileData[3] = sbPERM_WRITE_RULE_TYPE_NO_SYSTEM_RULES.toString();
		arrRuleTypeProfileData[4] = sbPERM_PROF_RULE_TYPE_NO_SYSTEM_RULES.toString();

		return arrRuleTypeProfileData;
	}

	/**
	 * Gets the user office profile and updates the passed 'hmWebSessionInfoData' HashMap parameter.
	 */
	private Feedback getUserOfficePermissionsData(UserLoginData userLoginData, UserEntitlementData userEntitlementData)
	{
		String sUserID = userLoginData.getUserID();

		

		Feedback feedback = new Feedback();

		String sPERM_PROF_DEPARTMENT = userEntitlementData.getPERM_PROF_DEPARTMENT();

		DTODataHolder dtoUserOfficePermissionsData = m_daoSecurity.getUserOfficePermissionsData(sPERM_PROF_DEPARTMENT);

		if (dtoUserOfficePermissionsData.getFeedBack().isSuccessful())
		{
			String sOfficePermissionsData = prepareOfficePermissionsData(userLoginData, null, userEntitlementData, dtoUserOfficePermissionsData);

			userEntitlementData.setORIG_PERM_PROF_OFFICE(sOfficePermissionsData);
			userLoginData.setOfficePermissions(sOfficePermissionsData);
		}

		

		return feedback;
	}

	/**
	 * NOTE: This method is also called from the EntitlementsDataFactory class, for which the sent user ID is 'EntitlementsDataFactory'. Prepares the
	 * office permissions data. Example for the prepared string: "JP1@@@NAM@@@TW2@@@XXX@@@". In addition, it updates the passed UserLoginData with
	 * office String[].
	 */
	@SkipInputValidation
	public String prepareOfficePermissionsData(UserLoginData userLoginData, String sUserID, UserEntitlementData userEntitlementData,
			DTODataHolder dtoUserOfficePermissionsData)
	{
		sUserID = userLoginData != null ? userLoginData.getUserID() : sUserID;

		StringBuffer sbORIG_PERM_PROF_OFFICE = new StringBuffer();

		ArrayList alData = dtoUserOfficePermissionsData.getDataAL();
		int iSize = alData.size();

		String[] arrOffices = new String[iSize];
		String[] arrBusinessDates;

		for (int i = 0; i < iSize; i++)
		{
			HashMap hmCurrentRow = (HashMap) alData.get(i);

			String sOffice = (String) hmCurrentRow.get(COLUMN_DEPARTMENT_OFFICE);

			sbORIG_PERM_PROF_OFFICE.append(sOffice).append(ServerConstants.PERMISSIONS_DELIMITER);

			arrOffices[i] = sOffice;
		}

		String sDefaultBusinessDate = userLoginData != null ? userLoginData.getDefaultBusinessDate() :
		GlobalDateTimeUtil.dateToStaticDataString(CacheKeys.banksKey.getSingle(ServerConstants.DEFAULT_SERVER_OFFICE_NAME).getBsnessdate());
			
    arrBusinessDates = attachBusinessDateToOffice(arrOffices, sDefaultBusinessDate);
    
		if(userLoginData != null) userLoginData.setOfficesAndBusinessDates(arrOffices, arrBusinessDates);
		userEntitlementData.setOfficesAndBusinessDates(arrOffices, arrBusinessDates);

		return sbORIG_PERM_PROF_OFFICE.toString();
	}

	/**
	 * Gets the user message profile and updates the passed 'hmWebSessionInfoData' HashMap parameter.
	 */
	private Feedback getUserMessageProfileData(UserLoginData userLoginData, UserEntitlementData userEntitlementData)
	{
		final String ERROR_MESSAGE = "User message profile name is empty !!!";

		String sUserID = userLoginData.getUserID();

		

		Feedback feedback = new Feedback();

		String sMessageProfile = userLoginData.getMessageProfile();

		// Message profile is empty.
		if (isNullOrEmpty(sMessageProfile))
		{
			logger.error(ERROR_MESSAGE);
		}

		else
		{
			DTODataHolder dtoMessageProfileData = m_daoSecurity.getUserMessageProfileData(sMessageProfile);

			if (dtoMessageProfileData.getFeedBack().isSuccessful())
			{
				String[] arrMessageProfileData = prepareMessageProfileData(sUserID, dtoMessageProfileData);

				userEntitlementData.setMessageProfileName(sMessageProfile);
				userEntitlementData.setORIG_PERM_PROF_MSG(arrMessageProfileData[0]);
				userEntitlementData.setPERM_PROF_MSG(arrMessageProfileData[1]);

				userLoginData.setMessageProfilePermissions(arrMessageProfileData[0]);
			}

			else
			{
				feedback = dtoMessageProfileData.getFeedBack();
			}
		}

		

		return feedback;
	}

	/**
	 * NOTE: This method is also called from the EntitlementsDataFactory class, for which the sent user ID is 'EntitlementsDataFactory'. Prepares the
	 * message profile data. Example for the prepared string array: Index 0 -
	 * "TLX(1)@@@???(1)@@@012(1)@@@019(1)@@@094(1)@@@100(1)@@@100BBK(1)@@@100BNF(1)". Index 1 -
	 * "'TLX','???','012','019','094','100','100BBK','100BNF','100CB2'".
	 */
	@SkipInputValidation
	public String[] prepareMessageProfileData(String sUserID, DTODataHolder dtoMessageProfileData)
	{
		final String MESSAGE_TYPE_QUESTION_MARKS = "???";

		String[] arrMessageProfileData = new String[2];

		StringBuffer sbORIG_PERM_PROF_MSG = new StringBuffer();
		StringBuffer sbPERM_PROF_MSG = new StringBuffer();

		ArrayList alData = dtoMessageProfileData.getDataAL();
		int iSize = alData.size();

		for (int i = 0; i < iSize; i++)
		{
			HashMap hmCurrentRow = (HashMap) alData.get(i);

			String sPermissionType = ((String) hmCurrentRow.get(COLUMN_BPROFILE_PERMISIONTYPE)).trim();

			// If we have empty value, we don't add this message type.
			if (!sPermissionType.equals(ServerConstants.EMPTY_STRING))
			{
				String sMessageType = (String) hmCurrentRow.get(COLUMN_MPROFILE_MSG_TYPE);
				String sMessageSubType = (String) hmCurrentRow.get(COLUMN_MPROFILE_MSGSUBTYPE);

				sPermissionType = sPermissionType.equalsIgnoreCase(ServerConstants.PERMISSION_WRITE) ? ServerConstants.PERMISSION_WRITE_SUFFIX
						: ServerConstants.PERMISSION_READ_SUFFIX;

				if (!sMessageType.equals(ServerConstants.EMPTY_STRING) && !MESSAGE_TYPE_QUESTION_MARKS.equals(sMessageType))
				{
					// ORIG_PERM_PROF_MSG update.
					sbORIG_PERM_PROF_MSG.append(sMessageType).append(sMessageSubType).append(sPermissionType);

					// PERM_PROF_MSG update.
					sbPERM_PROF_MSG.append(ServerConstants.APOSTROPHE).append(sMessageType).append(sMessageSubType)
							.append(ServerConstants.APOSTROPHE);

					if (i < (iSize - 1))
					{
						sbORIG_PERM_PROF_MSG.append(ServerConstants.PERMISSIONS_DELIMITER);
						sbPERM_PROF_MSG.append(ServerConstants.COMMA);
					}
				}
			}
		}

		arrMessageProfileData[0] = sbORIG_PERM_PROF_MSG.toString();
		arrMessageProfileData[1] = sbPERM_PROF_MSG.toString();

		return arrMessageProfileData;
	}

	/**
	 * Gets the user queue profile and updates the passed 'hmWebSessionInfoData' HashMap parameter.
	 */
	private Feedback getUserQueueProfileData(UserLoginData userLoginData, UserEntitlementData userEntitlementData)
	{
		final String ERROR_MESSAGE = "User queue profile name is empty !!!";

		String sUserID = userLoginData.getUserID();

		

		Feedback feedback = new Feedback();

		String sQueueProfile = userLoginData.getQueueProfile();

		// Queue profile is empty.
		if (isNullOrEmpty(sQueueProfile))
		{
			logger.error(ERROR_MESSAGE);
		}

		else
		{
			DTODataHolder dtoQueueProfileData = m_daoSecurity.getUserQueueProfileData(sQueueProfile);

			if (dtoQueueProfileData.getFeedBack().isSuccessful())
			{
				String[] arrQueueProfileData = prepareQueueProfileData(sUserID, dtoQueueProfileData);

				userEntitlementData.setQueueProfileName(sQueueProfile);
				userEntitlementData.setORIG_PERM_PROF_QUEUE(arrQueueProfileData[0]);
				userEntitlementData.setPERM_PROF_QUEUE(arrQueueProfileData[1]);
				userEntitlementData.setORIG_PERM_PROF_QUEUE_NOUDQ(arrQueueProfileData[2]);

				userLoginData.setQueueProfilePermissions(arrQueueProfileData[0]);
			}

			else
			{
				feedback = dtoQueueProfileData.getFeedBack();
			}
		}

		

		return feedback;
	}

	/**
	 * NOTE: This method is also called from the EntitlementsDataFactory class, for which the sent user ID is 'EntitlementsDataFactory'. Prepares the
	 * queue profile data. Example for the prepared string array: Index 0 -
	 * "ASD_FA_R(1)@@@CLS(1)@@@DEX_SWF(1)@@@EB_PMTS(1)@@@FED_CHPS(1)@@@FED_DRAW(1)@@@FED_ROF(1)". Index 1 -
	 * "'ASD_FA_R','CLS','DEX_SWF','EB_PMTS','FED_CHPS','FED_DRAW','FED_ROF'".
	 */
	@SkipInputValidation
	public String[] prepareQueueProfileData(String sUserID, DTODataHolder dtoQueueProfileData)
	{
		String[] arrQueueProfileData = new String[3];

		StringBuffer sbORIG_PERM_PROF_QUEUE = new StringBuffer();
		StringBuffer sbPERM_PROF_QUEUE = new StringBuffer();
		StringBuffer sbORIG_PERM_PROF_QUEUE_NOUDQ = new StringBuffer();

		ArrayList alData = dtoQueueProfileData.getDataAL();
		int iSize = alData.size();

		for (int i = 0; i < iSize; i++)
		{
			HashMap hmCurrentRow = (HashMap) alData.get(i);

			String sPermissionType = ((String) hmCurrentRow.get(COLUMN_QPROFILE_PERMISIONTYPE)).trim();

			// If we have empty value, we don't add this status.
			if (!sPermissionType.equals(ServerConstants.EMPTY_STRING))
			{
				String sMessageStatus = (String) hmCurrentRow.get(COLUMN_QPROFILE_MSG_STATUS);
				sPermissionType = sPermissionType.equalsIgnoreCase(ServerConstants.PERMISSION_WRITE) ? ServerConstants.PERMISSION_WRITE_SUFFIX
						: ServerConstants.PERMISSION_READ_SUFFIX;

				String sUserDefine = (String) hmCurrentRow.get(COLUMN_STATUSES_USERDEFINE);

				if (!sMessageStatus.equals(ServerConstants.EMPTY_STRING))
				{
					// ORIG_PERM_PROF_QUEUE update.
					sbORIG_PERM_PROF_QUEUE.append(sMessageStatus).append(sPermissionType);

					// PERM_PROF_QUEUE update.
					sbPERM_PROF_QUEUE.append(ServerConstants.APOSTROPHE).append(sMessageStatus).append(ServerConstants.APOSTROPHE);

					if (i < (iSize - 1))
					{
						sbORIG_PERM_PROF_QUEUE.append(ServerConstants.PERMISSIONS_DELIMITER);
						sbPERM_PROF_QUEUE.append(ServerConstants.COMMA);
					}

					// ORIG_PERM_PROF_QUEUE_NOUDQ update.
					if (sUserDefine.equals(ServerConstants.ZERO_VALUE))
					{
						sbORIG_PERM_PROF_QUEUE_NOUDQ.append(ServerConstants.APOSTROPHE).append(sMessageStatus).append(ServerConstants.APOSTROPHE);
						//
						if (i < (iSize - 1))
						{
							sbORIG_PERM_PROF_QUEUE_NOUDQ.append(ServerConstants.COMMA);
						}
					}
				}
			}
		}

		//
		String sORIG_PERM_PROF_QUEUE_NOUDQ = sbORIG_PERM_PROF_QUEUE_NOUDQ.toString();
		if (sORIG_PERM_PROF_QUEUE_NOUDQ.endsWith(ServerConstants.COMMA))
		{
			sORIG_PERM_PROF_QUEUE_NOUDQ = sbORIG_PERM_PROF_QUEUE_NOUDQ.substring(0, sbORIG_PERM_PROF_QUEUE_NOUDQ.length() - 1);
		}

		arrQueueProfileData[0] = sbORIG_PERM_PROF_QUEUE.toString();
		arrQueueProfileData[1] = sbPERM_PROF_QUEUE.toString();
		arrQueueProfileData[2] = sORIG_PERM_PROF_QUEUE_NOUDQ;

		return arrQueueProfileData;
	}

	/**
	 * Gets the user alert profile and updates the passed 'hmWebSessionInfoData' HashMap parameter.
	 */
	private Feedback getUserAlertProfileData(UserLoginData userLoginData, UserEntitlementData userEntitlementData)
	{
		final String ERROR_MESSAGE = "User alert profile name is empty !!!";

		String sUserID = userLoginData.getUserID();

		Feedback feedback = new Feedback();

		String sAlertProfile = userLoginData.getAlertProfile();

		// Alert profile is empty.
		if (isNullOrEmpty(sAlertProfile))
		{
			logger.error(ERROR_MESSAGE);
		}

		else
		{
			DTODataHolder dtoAlertProfileData = m_daoSecurity.getUserAlertProfileData(sAlertProfile, userLoginData.getUserID());

			if (dtoAlertProfileData.getFeedBack().isSuccessful())
			{
				String[] arrAlertProfileData = prepareAlertProfileData(sUserID, dtoAlertProfileData);

				userEntitlementData.setAlertsProfileName(sAlertProfile);
				userEntitlementData.setORIG_PERM_PROF_ALERTS(arrAlertProfileData[0]);
				userEntitlementData.setPERM_PROF_ALERTS(arrAlertProfileData[1]);

				userLoginData.setAlertProfilePermissions(arrAlertProfileData[0]);
			}

			else
			{
				feedback = dtoAlertProfileData.getFeedBack();
			}
		}

		return feedback;
	}

	/**
	 * NOTE: This method is also called from the EntitlementsDataFactory class, for which the sent user ID is 'EntitlementsDataFactory'. Prepares the
	 * alert profile data. Example for the prepared string array: Index 0 - "304@@@305@@@306". Index 1 - "'304','305','306'".
	 */
	@SkipInputValidation
	public String[] prepareAlertProfileData(String sUserID, DTODataHolder dtoAlertProfileData)
	{
		String[] arrAlertProfileData = new String[2];

		StringBuffer sbORIG_PERM_PROF_ALERTS = new StringBuffer();
		StringBuffer sbPERM_PROF_ALERTS = new StringBuffer();

		ArrayList alData = dtoAlertProfileData.getDataAL();
		int iSize = alData.size();

		for (int i = 0; i < iSize; i++)
		{
			HashMap hmCurrentRow = (HashMap) alData.get(i);

			String sAlertID = (String) hmCurrentRow.get(COLUMN_ALERT_PROFILES_ALERTS_UID);

			if (!sAlertID.equals(ServerConstants.EMPTY_STRING))
			{
				// ORIG_PERM_PROF_ALERTS update.
				sbORIG_PERM_PROF_ALERTS.append(sAlertID);

				// PERM_PROF_ALERTS update.
				sbPERM_PROF_ALERTS.append(ServerConstants.APOSTROPHE).append(sAlertID).append(ServerConstants.APOSTROPHE);

				if (i < (iSize - 1))
				{
					sbORIG_PERM_PROF_ALERTS.append(ServerConstants.PERMISSIONS_DELIMITER);
					sbPERM_PROF_ALERTS.append(ServerConstants.COMMA);
				}
			}
		}

		arrAlertProfileData[0] = sbORIG_PERM_PROF_ALERTS.toString();
		arrAlertProfileData[1] = sbPERM_PROF_ALERTS.toString();

		return arrAlertProfileData;
	}

	/**
	 * Gets the user buttons permissions and updates the passed 'hmWebSessionInfoData' HashMap parameter.
	 */
	private Feedback getApproveAccessLevelsData(UserLoginData userLoginData, UserEntitlementData userEntitlementData)
	{
		String sUserID = userLoginData.getUserID();
		

		Feedback feedback = new Feedback();

		String sAccessProfile = userLoginData.getAccessProfile();

		DTODataHolder dtoApproveAccessLevelsData = m_daoSecurity.getApproveAccessLevelsData(sAccessProfile);

		if (dtoApproveAccessLevelsData.getFeedBack().isSuccessful())
		{
			String sApproveAccessLevelsData = prepareApproveAccessLevelsData(userLoginData.getUserID(), dtoApproveAccessLevelsData);

			userEntitlementData.setApproveAccessLevels(sApproveAccessLevelsData);
		}

		else
		{
			feedback = dtoApproveAccessLevelsData.getFeedBack();
		}

		

		return feedback;
	}

	/**
	 * Gets the user rule types and updates the passed 'hmWebSessionInfoData' HashMap parameter.
	 */
	private Feedback getUserRuleTypesData(UserLoginData userLoginData, UserEntitlementData userEntitlementData)
	{

		final String ERROR_MESSAGE = "User Rule type profile name is empty !!!";
		String sUserID = userLoginData.getUserID();
		
		Feedback feedback = new Feedback();
		String sRuleTypeProfile = userLoginData.getRuleTypesProfile();

		// Department profile is empty.
		if (isNullOrEmpty(sRuleTypeProfile))
		{
			logger.error(ERROR_MESSAGE);
		}

		else
		{
			DTODataHolder dtoRuletypeProfileData = m_daoSecurity.getUserRuleTypeProfileData(sRuleTypeProfile);

			if (dtoRuletypeProfileData.getFeedBack().isSuccessful())
			{
				String[] arrRuleTypeProfileData = prepareRuleTypeProfileData(sUserID, dtoRuletypeProfileData);

				userEntitlementData.setRuleTypesProfileName(sRuleTypeProfile);// DepartmentProfileName(sDepartmentProfile);
				userEntitlementData.setORIG_PERM_PROF_RULE_TYPES(arrRuleTypeProfileData[0]);
				userEntitlementData.setPERM_PROF_RULE_TYPES(arrRuleTypeProfileData[1]);
				userEntitlementData.setPERM_WRITE_RULE_TYPES(arrRuleTypeProfileData[2]);
				userEntitlementData.setPERM_WRITE_RULE_TYPES_NO_SYSTEM_RULES(arrRuleTypeProfileData[3]);
				userEntitlementData.setPERM_PROF_RULE_TYPES_NO_SYSTEM_RULES(arrRuleTypeProfileData[4]);
				userLoginData.setRuleTypesProfilePermissions(arrRuleTypeProfileData[0]);
			}

			else
			{
				feedback = dtoRuletypeProfileData.getFeedBack();
			}
		}

		

		return feedback;
	}// getApproveRuleTypesData

	/**
	 * NOTE: This method is also called from the EntitlementsDataFactory class, for which the sent user ID is 'EntitlementsDataFactory'. Prepares the
	 * approve access levels permissions data. This string will be used when getting the approvals screen for each user. Example for the prepared
	 * string: "40016@40017@40021@40024@".
	 */
	@SkipInputValidation
	public String prepareApproveAccessLevelsData(String sUserID, DTODataHolder dtoApproveAccessLevelsData)
	{
		final String COLUMN_APPROVE_ACCS_LVL = "FIELD_NAME";

		StringBuffer sbApproveAccessLevels = new StringBuffer();

		ArrayList alData = dtoApproveAccessLevelsData.getDataAL();
		int iSize = alData.size();

		for (int i = 0; i < iSize; i++)
		{
			HashMap hmCurrentRow = (HashMap) alData.get(i);

			String sApproveAccessLevel = (String) hmCurrentRow.get(COLUMN_APPROVE_ACCS_LVL);

			sbApproveAccessLevels.append(sApproveAccessLevel).append(ServerConstants.AT_SIGN);
		}

		return sbApproveAccessLevels.toString();
	}

	/**
	 * Gets the user buttons permissions and updates the passed 'hmWebSessionInfoData' HashMap parameter.
	 */
	private Feedback getUserButtonsPermissionsData(UserLoginData userLoginData, UserEntitlementData userEntitlementData)
	{
		String sUserID = userLoginData.getUserID();
		

		Feedback feedback = new Feedback();

		String sAccessProfile = userLoginData.getAccessProfile();

		DTODataHolder dtoButtonsPermissionsData = m_daoSecurity.getUserButtonsPermissionsData(sAccessProfile);

		if (dtoButtonsPermissionsData.getFeedBack().isSuccessful())
		{
			String sButtonsPermissionsData = prepareButtonsPermissionsData(sUserID, dtoButtonsPermissionsData);

			userEntitlementData.setPERM_PROF_BUTTONS(sButtonsPermissionsData);
		}

		else
		{
			feedback = dtoButtonsPermissionsData.getFeedBack();
		}

		

		return feedback;
	}

	/**
	 * NOTE: This method is also called from the EntitlementsDataFactory class, for which the sent user ID is 'EntitlementsDataFactory'. Prepares the
	 * buttons permissions data. Example for the prepared string: "40016(1)@@@,40017@W,40021@W,40024@W,40046@W,40051@W,40066@W".
	 */
	@SkipInputValidation
	public String prepareButtonsPermissionsData(String sUserID, DTODataHolder dtoButtonsPermissionsData)
	{
		StringBuffer sbPERM_PROF_BUTTONS = new StringBuffer();

		ArrayList alData = dtoButtonsPermissionsData.getDataAL();
		int iSize = alData.size();

		for (int i = 0; i < iSize; i++)
		{
			HashMap hmCurrentRow = (HashMap) alData.get(i);

			String sAccessLevel = (String) hmCurrentRow.get(COLUMN_ACCESSPROFILEVIEW_FIELD_NAME);

			String sPermissionType = ((String) hmCurrentRow.get(COLUMN_ACCESSPROFILEVIEW_PERMISIONTYPE)).trim();

			sPermissionType = (ServerConstants.PERMISSION_WRITE.equals(sPermissionType) ? ServerConstants.PERMISSION_WRITE_SUFFIX
					: ServerConstants.PERMISSION_READ_SUFFIX);

			sbPERM_PROF_BUTTONS.append(sAccessLevel).append(sPermissionType);

			if (i < (iSize - 1))
			{
				sbPERM_PROF_BUTTONS.append(ServerConstants.PERMISSIONS_DELIMITER);
			}
		}

		return sbPERM_PROF_BUTTONS.toString();
	}

	/**
	 * Gets the user business area options and updates the passed UserLoginData parameter.
	 */
	private Feedback getUserBusinessAreaOptions(UserLoginData userLoginData)
	{
		final String ERROR_MESSAGE = "No business area options for user ";

		String sUserID = userLoginData.getUserID();
		

		Feedback feedback = new Feedback();

		DTODataHolder dtoUserBAOptions = m_daoSecurity.getUserBusinessAreaOptions(sUserID);

		if (dtoUserBAOptions.getFeedBack().isSuccessful())
		{
			if (!dtoUserBAOptions.isEmpty())
			{
				ArrayList alBAOptions = dtoUserBAOptions.getDataAL();
				int iSize = alBAOptions.size();

				String[] arrBAOptions = new String[iSize];

				for (int i = 0; i < iSize; i++)
				{
					arrBAOptions[i] = (String) ((HashMap) alBAOptions.get(i)).get(COLUMN_USER_BUSINESS_AREAS_BUSINESS_AREA);
				}

				userLoginData.setBusinessAreaOptions(arrBAOptions);
			}

			// No BA options for this user.
			else
			{
				String sErrorMessage = new StringBuffer(ERROR_MESSAGE).append(sUserID).toString();
				logger.error(sErrorMessage);
			}
		}

		else
		{
			feedback = dtoUserBAOptions.getFeedBack();
		}

		

		return feedback;
	}

	/**
	 * Sets the last login info into the passed UserLoginData obejct.
	 */
	private void setLastLoginInfo(UserLoginData userLoginData, DTODataHolder dtoUsers)
	{
		HashMap hmData = dtoUsers.getDataRow();

		String sLastLoginDate = (String) hmData.get(COLUMN_USERS_LASTLOGIN_DATE);

		userLoginData.setLastLoginDate(sLastLoginDate);
	}

	/**
	 * Sets the bad login count into the passed UserLoginData obejct.
	 */
	private void setBadLoginCount(UserLoginData userLoginData, DTODataHolder dtoUsers, int[] arrBadLoginCountHolder)
	{
		String sBadLoginCount = dtoUsers.getColumnData(COLUMN_USERS_BAD_LOGIN);

		if (sBadLoginCount.equals(ServerConstants.EMPTY_STRING))
		{
			sBadLoginCount = ServerConstants.ZERO_VALUE;
		}

		int iBadLoginCount = Integer.valueOf(sBadLoginCount).intValue();
		userLoginData.setBadLoginCount(iBadLoginCount);
		arrBadLoginCountHolder[0] = iBadLoginCount;
	}

	/**
	 * Sets the user as logged in to the system.
	 */
	private Feedback setUserLoggedIn(UserLoginData userLoginData, final WebSessionInfo webSessionInfo, String sPassword)
	{
		String sUserID = userLoginData.getUserID();

		

		Feedback feedback = new Feedback();
		removeMessagesLock(CacheKeys.UserWebSessionInfoKey.getSingle(Admin.getContextAdmin()));
		// Removes existing, (if really exists), session info for this user ID.
		CacheKeys.UserWebSessionInfoKey.removeSingle(sUserID);

		// Generates a unique session ID for this user.
		String sSessionID = GlobalUtils.generateGUIDRandom() ;//generateSessionID(sUserID);
		userLoginData.setSessionID(sSessionID);
		webSessionInfo.setSessionID(sSessionID);

		// set the session id in the admin context so that from this moment on it will be used
		// for logging
		Admin.getContextAdmin().setSessionId(sSessionID);
		Admin.getContextAdmin().setWebSessionInfo(webSessionInfo);

		// configures session info with the data in the userLoginData and puts in cache .
		feedback = this.configureNStoreSessionInfo(userLoginData, webSessionInfo);

		// Updates the USERS table.
		if (feedback.isSuccessful())
		{
			feedback = updateUSERS_TableForLogin(userLoginData, sPassword);
		}

		if (!feedback.isSuccessful())
		{
			logger.error(GlobalUtils.getFeedbackString(feedback));
		}
		else
		{
			// set the webSessionInfo's loggedin flag
			webSessionInfo.login();
		}// /EO else if the users table update was successful

		

		return feedback;
	}

	
	/**
	 * Generates a unique session ID.
	 * 
	 * @bo.internalInterface
	
	@Expose(type = ExposureType.InternalInterface)
	public String generateSessionID(String sUserID)
	{
		

		StringBuffer sbSessionID = new StringBuffer();

		final int MAX_INT_VALUE = 2147483647;
		final int SESSION_ID_LENGTH = 32;
		final String ERROR_MESSAGE = "Couldn't get sys time from database; using 'new Date().getTime()' instead...";
		final String GENERATED_SESSION_ID = "Generated session ID: ";

		DTOSingleValue dto = m_daoSecurity.getUniqueSysTimeFromDB();
		Feedback feedback = dto.getFeedBack();

		// This value is used to initialize the pseudo-random number generator, (aka PRNG),
		// of the JVM for random alghorithm use.
		long lSeed;

		if (feedback.isSuccessful())
		{
			lSeed = Long.parseLong(dto.getValue());
		}
		else
		// failure
		{
			// Trace.
			logger.error(ERROR_MESSAGE);
			lSeed = new java.util.Date().getTime();
		}

		Random random = new Random(lSeed);

		for (int i = 0; i < SESSION_ID_LENGTH; i++)
		{
			// The following 3 lines are the equivalent to the following C++ line in
			// 'pay_dbfuncs.GenerateSessionID' method: "j = (int) Nn * rand() / (RAND_MAX + 1.0);"
			//
			int iNextInt = random.nextInt(MAX_INT_VALUE);
			float f = (float) ((float) iNextInt / (MAX_INT_VALUE + 1));
			int iCurrIndex = (int) (SESSION_ID_PROPER_CHARS_LENGTH * f);
			iCurrIndex = Math.abs(iCurrIndex);

			// Appends to the StringBuffer the char from the created index.
			sbSessionID.append(SESSION_ID_PROPER_CHARS[iCurrIndex]);
		}

		StringBuffer sb = new StringBuffer(GENERATED_SESSION_ID).append(sbSessionID);
		infoTrace(sbSessionID.toString());

		

		return sbSessionID.toString();
	}
	 */

	/**
	 * Cleans the WEB_PROFILE_LOCK table from records with this user ID. 
	 * TODO: 1. remove all the pdos from the local regions and release their respective locks in the remote regions
	 */
	@Expose(type = ExposureType.InternalInterface)
	public final void cleanUserIDExistingLockRecords(final String sUserID)
	{
		

		final Feedback feedback = m_daoSecurity.cleanUserIDExistingLockRecords(sUserID);

		if (!feedback.isSuccessful())
			logger.error(feedback.getErrorText());

		
	}// EOM

	/**
	 * Saves data into the WEBSESSION_INFO table.
	 */
	protected final Feedback configureNStoreSessionInfo(UserLoginData userLoginData, final WebSessionInfo webSessionInfo)
	{

		
		final String sUserID = userLoginData.getUserID();

		final String sOffice = webSessionInfo.getDefaultOffice();

		// Gets additiona data from BANKS table.
		final DTODataHolder dtoAdditionalDataFromBANKS = m_daoSecurity.getAdditionalDataFromBANKS(sOffice);
		Feedback feedback = dtoAdditionalDataFromBANKS.getFeedBack();
		//    
		if (feedback.isSuccessful())
		{
			HashMap hmData = dtoAdditionalDataFromBANKS.getDataRow();

			String sDefaultCalendar = (String) hmData.get(COLUMN_BANKS_CALNAME);
			webSessionInfo.setDeafultCalendar(sDefaultCalendar);

			String sBaseCurrency = (String) hmData.get(COLUMN_BANKS_CURRENCY);
			webSessionInfo.setBaseCurrency(sBaseCurrency);

			String sBusinessDate = (String) hmData.get(COLUMN_BANKS_BSNESSDATE);
			sBusinessDate = GlobalDateTimeUtil.getFormattedDateString(sBusinessDate, GlobalDateTimeUtil.STATIC_DATA_DATE_TIME,
					GlobalDateTimeUtil.DATE_FORMAT_US);
			webSessionInfo.setBusinessDate(sBusinessDate);
		}// EO if the additional data from banks load was successful

		// Gets default value date from CURRENCY_BU table.
		if (feedback.isSuccessful())
		{
			String sCurrency = webSessionInfo.getBaseCurrency();
			final DTOSingleValue dto = m_daoSecurity.getDefaultValueDateFromCURRENCY_BU(sCurrency, sOffice);

			feedback = dto.getFeedBack();

			if (feedback.isSuccessful())
			{
				String sValueDateOffset = dto.getValue();
				webSessionInfo.setValueDateOffset((sValueDateOffset == null ? null : Integer.valueOf(sValueDateOffset)));
			}
		}

		// Sets limit type and max amount.
		if (feedback.isSuccessful())
		{
			feedback = setLimitTypeAndMaxAmountValues(userLoginData, webSessionInfo);
		}

		if (feedback.isSuccessful())
		{
			// store the websessionInfo instance in cache and in the current admin
			Admin.getContextAdmin().setWebSessionInfo(webSessionInfo);
			CacheKeys.WebSessionInfoKey.putSingle(webSessionInfo);
		}

		// Failure during one of the previous steps.
		/*
		 * if(!feedback.isSuccessful()) { logger.error(GlobalUtils.getFeedbackString(feedback)); if(feedback.getException() !=
		 * null) { logger.error(feedback.getException().getMessage()); } }
		 */

		

		return feedback;
	}

	/**
	 * Updates the USERS table.
	 */
	private Feedback updateUSERS_TableForLogin(UserLoginData userLoginData, String sPassword)
	{
		String sUserID = userLoginData.getUserID();

		

		Feedback feedback = m_daoSecurity.updateUSERS_TableForLogin(sUserID);

		

		return feedback;
	}

	/**
	 * 
	 */
	private final Feedback setLimitTypeAndMaxAmountValues(UserLoginData userLoginData, final WebSessionInfo webSessionInfo)
	{
		final String NONE = "None";
		final String USER = "USER";
		final String TERMINAL = "TERMINAL";
		final String MAX_PAYMENT_ALLOWED_UNLIMITED = "-1";

		Feedback feedback = new Feedback();
		
		String sUSERS_MAX_AMOUNT = userLoginData.getMaxAmount();
		boolean bZeroOrEmpty_USERS_MAX_AMOUNT =    sUSERS_MAX_AMOUNT.equals(ServerConstants.ZERO_VALUE)
		                                        || sUSERS_MAX_AMOUNT.equals(ServerConstants.EMPTY_STRING);
		webSessionInfo.setMaxPaymentAllowed(!bZeroOrEmpty_USERS_MAX_AMOUNT ? sUSERS_MAX_AMOUNT : MAX_PAYMENT_ALLOWED_UNLIMITED);
		
		String sUSERS_MAX_AMOUNT_FORCE_NSF = userLoginData.getMaxAmountForceNSF();
		boolean bZeroOrEmpty_USERS_MAX_AMOUNT_FORCE_NSF =    sUSERS_MAX_AMOUNT_FORCE_NSF.equals(ServerConstants.ZERO_VALUE)
		                                                  || sUSERS_MAX_AMOUNT_FORCE_NSF.equals(ServerConstants.EMPTY_STRING);
		webSessionInfo.setMaxAmountForceNSF(!bZeroOrEmpty_USERS_MAX_AMOUNT_FORCE_NSF ? sUSERS_MAX_AMOUNT_FORCE_NSF : MAX_PAYMENT_ALLOWED_UNLIMITED);

		return feedback;
	}

	/**
	 * Sets the passed UserLoginData object with department data.
	 */
	protected void setDepartmentData(UserLoginData userLoginData, String sPERM_PROF_DEPARTMENT, String[] sORIG_PERM_PROF_DEPARTMENT_SHOW)
	{
		String sUserID = userLoginData.getUserID();
		final String COLUMN_DEPARTMENTCODE = "DEPARTMENTCODE";
		final String ALL = "1";
		

		DTODataHolder dtoDepartmentData = m_daoSecurity.getDepartmentData(sPERM_PROF_DEPARTMENT);
		ArrayList alDepartmentData = dtoDepartmentData.getDataAL();
		int iSize = alDepartmentData.size();
		HashMap departments = new HashMap();
		//add all department names to HashMap
		for(String dep : sORIG_PERM_PROF_DEPARTMENT_SHOW) {
			departments.put(dep.substring(0,dep.indexOf('(')),dep);
		}
		HashMap onlyAllPremissionDep = new HashMap();
		for (int i = 0; i < iSize; i++)
		{
			HashMap hmCurrentRow = (HashMap) alDepartmentData.get(i);
			String sDepartmentCode = (String) hmCurrentRow.get(COLUMN_DEPARTMENTCODE);
			String  foundDepartment = (String)departments.get(sDepartmentCode);
			if(foundDepartment != null) {
				String isALL = foundDepartment.substring(foundDepartment.indexOf('(')+1, foundDepartment.indexOf(')'));
				if(isALL.equals(ALL)) {
					onlyAllPremissionDep.put(sDepartmentCode,sDepartmentCode);
				}
			}
		}
		Feedback feedback = dtoDepartmentData.getFeedBack();

		if (feedback.isSuccessful())
		{
			userLoginData.setDepartmentData(getDepartmentDataMatrix(dtoDepartmentData.getDataAL(), userLoginData.getDefaultOffice(),onlyAllPremissionDep));
		}

		else
		{
			logger.error(GlobalUtils.getFeedbackString(feedback));
		}

		
	}

	/**
	 * Returns department data matrix.
	 */
	private Object[][] getDepartmentDataMatrix(ArrayList alDepartmentData, String sDefaultOffice,HashMap OnlyAllPremisionDep)
	{
		final String COLUMN_OFFICE = "OFFICE";
		final String COLUMN_NCC = "NCC";
		final String COLUMN_DEPARTMENTCODE = "DEPARTMENTCODE";
	        final String COLUMN_CUST_CODE = "CUST_CODE";
		final String COLUMN_SWIFT_ID = "SWIFT_ID";
		final String COLUMN_DESCRIPTION = "DESCRIPTION";
		final String ALL = "1";
		final String READ_ONLY = "0";

		Object[][] arrDepartmentData = new Object[0][0];

		if (!alDepartmentData.isEmpty())
		{
			String sDefaultOfficeBusinessDate = null;
			Banks banks = CacheKeys.banksKey.getSingle(sDefaultOffice);
			if (banks != null && banks.getBsnessdate() != null)
			{
				sDefaultOfficeBusinessDate = GlobalDateTimeUtil.dateToStaticDataString(banks.getBsnessdate());
			}

			int iSize = alDepartmentData.size();
			arrDepartmentData = new Object[iSize][8];

			for (int i = 0; i < iSize; i++)
			{
				HashMap hmCurrentRow = (HashMap) alDepartmentData.get(i);

				String sOffice = (String) hmCurrentRow.get(COLUMN_OFFICE);
				arrDepartmentData[i][0] = sOffice;

				String sNCC = (String) hmCurrentRow.get(COLUMN_NCC);
				arrDepartmentData[i][1] = sNCC;

				String sDepartmentCode = (String) hmCurrentRow.get(COLUMN_DEPARTMENTCODE);
				arrDepartmentData[i][2] = sDepartmentCode;
				//add 0/1 to combo data
				if(OnlyAllPremisionDep.get(sDepartmentCode) != null) {
					arrDepartmentData[i][7] = ALL;
				}
				else
				{
					arrDepartmentData[i][7] = READ_ONLY;
				}
				String sCustCode = (String) hmCurrentRow.get(COLUMN_CUST_CODE);
				arrDepartmentData[i][3] = sCustCode;

				String sDefBusinessDate = null;
				banks = CacheKeys.banksKey.getSingle(sOffice);
				if (banks != null && banks.getBsnessdate() != null)
				{
					sDefBusinessDate = GlobalDateTimeUtil.dateToStaticDataString(banks.getBsnessdate());
				}
				else
				{
					sDefBusinessDate = sDefaultOfficeBusinessDate;
				}
				arrDepartmentData[i][4] = sDefBusinessDate;
				
		                String sBic = (String) hmCurrentRow.get(COLUMN_SWIFT_ID);
		                arrDepartmentData[i][5] = sBic;
		                
                String sDepartmentDesc = (String) hmCurrentRow.get(COLUMN_DESCRIPTION);
                arrDepartmentData[i][6] = sDepartmentDesc;
				
				
			}

			arrDepartmentData = GlobalUtils.flipMatrix(arrDepartmentData);
		}

		return arrDepartmentData;
	}

	/**
	 * Sets the static data profiles preferences for this user.
	 */
	private void setStaticDataProfilesUserPrefs(UserLoginData userLoginData)
	{
		String sUserID = userLoginData.getUserID();

		

		DTODataHolder dtoStaticDataProfilesUserPrefs = m_daoSecurity.getStaticDataProfilesUserPrefs(userLoginData.getUserID());

		Feedback feedback = dtoStaticDataProfilesUserPrefs.getFeedBack();

		if (feedback.isSuccessful())
		{
			Object[][] arrStaticDataProfilesPreferencesData = prepareStaticDataProfilesPrefsDataMatrix(sUserID, dtoStaticDataProfilesUserPrefs);
			userLoginData.setStaticDataProfilesPreferencesData(arrStaticDataProfilesPreferencesData);
		}

		else
		{
			logger.error(GlobalUtils.getFeedbackString(feedback));
		}

		
	}

	/**
	 * Prepares the static data profiles' preferences data matrix.
	 */
	private Object[][] prepareStaticDataProfilesPrefsDataMatrix(String sUserID, DTODataHolder dtoStaticDataProfilesUserPrefs)
	{
		

		ArrayList alData = dtoStaticDataProfilesUserPrefs.getDataAL();
		int iSize = alData.size();

		Object[][] arrStaticDataProfilesPreferencesData = new Object[0][0];

		if (iSize > 0)
		{
			arrStaticDataProfilesPreferencesData = new Object[iSize][4];

			for (int i = 0; i < iSize; i++)
			{
				HashMap hmCurrentRow = (HashMap) alData.get(i);

				String sDataType = (String) hmCurrentRow.get(COLUMN_USERS_EXTRA_DATA_DATA_TYPE);
				arrStaticDataProfilesPreferencesData[i][0] = sDataType;

				String sLayoutPosition = (String) hmCurrentRow.get(COLUMN_USERS_EXTRA_DATA_LAYOUT_POSITION);
				arrStaticDataProfilesPreferencesData[i][1] = sLayoutPosition;

				String sFilterFields = (String) hmCurrentRow.get(COLUMN_USERS_EXTRA_DATA_FILTER_FIELDS);

				arrStaticDataProfilesPreferencesData[i][2] = sFilterFields;

				String sAdditionalData = (String) hmCurrentRow.get(COLUMN_USERS_EXTRA_DATA_ADDITIONAL_DATA);
				arrStaticDataProfilesPreferencesData[i][3] = sAdditionalData;
			}
		}

		

		return arrStaticDataProfilesPreferencesData;
	}

	/**
	 * Sets queue explorer open folders IDs.
	 */
	private void setQExplorerOpenedFoldersIDs(UserLoginData userLoginData)
	{
		String sUserID = userLoginData.getUserID();

		

		DTOSingleValue dtoSingleValue = m_daoSecurity.getQExplorerOpenedFoldersIDs(userLoginData.getUserID());

		Feedback feedback = dtoSingleValue.getFeedBack();

		if (feedback.isSuccessful())
		{
			userLoginData.setQExplorerOpenedFoldersIDs(dtoSingleValue.getValue());
		}

		else
		{
			logger.error(GlobalUtils.getFeedbackString(feedback));
		}

		
	}

	/**
	 * Sets window layout position preferences matrix.
	 */
	private void setWindowsLayoutPositionDataMatrix(UserLoginData userLoginData)
	{
		String sUserID = userLoginData.getUserID();

		

		DTODataHolder dtoWindowsLayoutPositionData = m_daoSecurity.getWindowsLayoutPositionData(sUserID);

		Feedback feedback = dtoWindowsLayoutPositionData.getFeedBack();

		if (feedback.isSuccessful())
		{
			Object[][] arrWindowsLayoutPositionPreferencesData = prepareWindowsLayoutPositionPrefsDataMatrix(sUserID, dtoWindowsLayoutPositionData);
			userLoginData.setWindowsLayoutPositionPreferencesData(arrWindowsLayoutPositionPreferencesData);
		}

		else
		{
			logger.error(GlobalUtils.getFeedbackString(feedback));
		}

		
	}

	/**
	 * Prepares the windows layout position data matrix.
	 */
	private Object[][] prepareWindowsLayoutPositionPrefsDataMatrix(String sUserID, DTODataHolder dtoWindowsLayoutPositionData)
	{
		

		ArrayList alData = dtoWindowsLayoutPositionData.getDataAL();
		int iSize = alData.size();

		Object[][] arrWindowsLayoutPositionPreferencesData = new Object[0][0];

		if (iSize > 0)
		{
			arrWindowsLayoutPositionPreferencesData = new Object[iSize][2];

			for (int i = 0; i < iSize; i++)
			{
				HashMap hmCurrentRow = (HashMap) alData.get(i);

				String sDataType = (String) hmCurrentRow.get(COLUMN_USERS_EXTRA_DATA_DATA_TYPE);
				arrWindowsLayoutPositionPreferencesData[i][0] = sDataType;

				String sLayoutPosition = (String) hmCurrentRow.get(COLUMN_USERS_EXTRA_DATA_LAYOUT_POSITION);
				arrWindowsLayoutPositionPreferencesData[i][1] = sLayoutPosition;
			}
		}

		

		return arrWindowsLayoutPositionPreferencesData;
	}
	
	/**
	 * Sets generic search data from USERS_EXTRA_DATA table, (layout position and additional data).
	 */
	private void setGenericSearchDataFromUSERS_EXTRA_DATA(UserLoginData userLoginData)
	{
		String sUserID = userLoginData.getUserID();

		

		DTODataHolder dtoGenericSearchDataFromUSERS_EXTRA_DATA = m_daoSecurity.getDataFromUSERS_EXTRA_DATA(QUEUE_NAME_GENERIC_SEARCH, sUserID);

		Feedback feedback = dtoGenericSearchDataFromUSERS_EXTRA_DATA.getFeedBack();

		if (feedback.isSuccessful() && !dtoGenericSearchDataFromUSERS_EXTRA_DATA.isEmpty())
		{
			HashMap hmData = dtoGenericSearchDataFromUSERS_EXTRA_DATA.getDataRow();

			String sLayoutPosition = (String) hmData.get(COLUMN_USERS_EXTRA_DATA_LAYOUT_POSITION);
			userLoginData.setGenericSearchLayoutPosition(sLayoutPosition);

			String sAdditionalData = (String) hmData.get(COLUMN_USERS_EXTRA_DATA_ADDITIONAL_DATA);
			userLoginData.setGenericSearchOtherCriteria(sAdditionalData);
		}

		else
		{
			logger.error(GlobalUtils.getFeedbackString(feedback));
		}

		
	}

	/**
	 * Sets the default business date.
	 */
	protected void setDefaultBusinessDate(UserLoginData userLoginData)
	{
		String sUserID = userLoginData.getUserID();

		

		DTOSingleValue dtoSingleValue = m_daoSecurity.getDefaultBusinessDate(userLoginData.getDefaultOffice());

		Feedback feedback = dtoSingleValue.getFeedBack();

		if (feedback.isSuccessful())
		{
			userLoginData.setDefaultBusinessDate(dtoSingleValue.getValue());
		}

		else
		{
			logger.error(GlobalUtils.getFeedbackString(feedback));
		}

		
	}
	
	/**
	 * 
	 */
	private void setNonMenuProfilesXML(UserLoginData userLoginData)
	{
		if(m_sNonMenuProfilesXML == null)
		{
			initNonMenuProfilesXML();
		}
		
		userLoginData.setNonMenuProfilesXML(m_sNonMenuProfilesXML);
	}
	
	/**
	 * 
	 */
	private void initNonMenuProfilesXML()
	{
		final String NON_MENU_PROFILES = "NON_MENU_PROFILES";
		final String PROFILE = "PROFILE";
		final String COLUMN_PROFILE_ID = "PROFILE_ID";
		final String COLUMN_SCREEN_ALIAS = "SCREEN_ALIAS";
		
		final String[] ARR_ATTRIBUTES = {COLUMN_PROFILE_ID, COLUMN_SCREEN_ALIAS};
		
		
		
		StringBuilder sb = new StringBuilder();
		StringBuilder sbProfiles = new StringBuilder();
		DTODataHolder dtoNonMenuProfilesData = m_daoSecurity.getNonMenuProfilesData();

		String sProfileID, sScreenAlias;

		Feedback feedback = dtoNonMenuProfilesData.getFeedBack();
		
		if (feedback.isSuccessful())
		{
			ArrayList alData = dtoNonMenuProfilesData.getDataAL();
			int iSize = alData.size();
			
			for(int i=0; i<iSize; i++)
			{
				HashMap hmCurrentRow = (HashMap)alData.get(i);
				
				sProfileID = (String)hmCurrentRow.get(COLUMN_PROFILE_ID);
				sScreenAlias = (String)hmCurrentRow.get(COLUMN_SCREEN_ALIAS);
				
				// For example: <PROFILE ID="420" SCREEN_ALIAS="Prules system actions">
				sbProfiles.append(GlobalResponseDataComponentText.getWellFormedMinimizedTagWithAttributes(PROFILE, ARR_ATTRIBUTES, new String[]{sProfileID, sScreenAlias}));
			}
		}
		
		m_sNonMenuProfilesXML = GlobalResponseDataComponentText.getWellFormedTag(NON_MENU_PROFILES, sbProfiles.toString());
		
		
	}

	// ///////////////////////////////////////
	// ///////// END LOGIN METHODS ///////////
	// ///////////////////////////////////////

	// ///////////////////////////////////////
	// /////// START LOGOUT METHODS //////////
	// ///////////////////////////////////////

	/**
	 * Handles user logout.
	 */
	@SkipInputValidation
	@AuthorizeUser(returnWebSessionInfo = true)
	public SimpleResponseDataComponent logout()
	{

		SimpleResponseDataComponent response = new SimpleResponseDataComponent();

		UserTransaction[] arrTransactionHolder = new UserTransaction[1];
		Feedback feedback = startTransaction(arrTransactionHolder);

		// Successfull transaction opening.
		if (feedback.isSuccessful())
		{
			response = doLogout(arrTransactionHolder);
		}

		// Failure transcation opening.
		else
		{
			response.setFeedback(feedback);
		}

		return response;
	}

	/**
	 * Performs logout. Note: user athorization is performed in the interface method
	 */
	private SimpleResponseDataComponent doLogout(UserTransaction[] arrTransactionHolder)
	{
		

		SimpleResponseDataComponent response = new SimpleResponseDataComponent();

		String sUserID = ServerConstants.EMPTY_STRING;
		boolean bSuccessfullLogoutProcess=false;
		Feedback feedback = new Feedback();
		try
		{
		final WebSessionInfo webSessionInfo = Admin.getContextAdmin().getWebSessionInfo();

		// Got back actual WebSessionInfo object.
		if (webSessionInfo != null)
		{
			sUserID = webSessionInfo.getUserID();

			// Update USERS table; sets the user as logged out. ( this functionality is still required
			// for the Users profile select list using the the logged_in creiteria (admin viewing all logged in users))
			feedback = m_daoSecurity.updateUSERS_TableForLogout(sUserID);

			if (feedback.isSuccessful())
			{
				removeMessagesLock(webSessionInfo);
				// update the webSessionInfo instance and remove it from the distribued cache
				CacheKeys.WebSessionInfoKey.removeSingle(webSessionInfo);

				// TODO: clean all the locks using caches
				// Cleans locked records by this user ID.
				cleanUserIDExistingLockRecords(sUserID);

				// Logout message.
				String sLogoutDate = m_daoSecurity.getFormattedSystemDateFromDatabase(null, GlobalDateTimeUtil.STATIC_DATA_DATE_TIME);
				BindingParameter[] arrBindingParameters = new BindingParameter[] { new BindingParameter(sUserID, DataType.STRING),
						new BindingParameter(sLogoutDate, DataType.DATE_TIME) };
				String sOffice = webSessionInfo.getDefaultOffice();
				String sLogoutMessage = ErrorAuditUtils.loadErrorAuditText((long) ProcessErrorConstants.LogoutMessage, sOffice, arrBindingParameters);
				logger.trace(sLogoutMessage);

				// Writes audit into ACTIVITY_AUDIT table.
				updateACTIVITY_AUDIT_Table(false, null, sUserID, sOffice, sLogoutDate);
			}
		}

		// No actual WebSessionInfo object.
		else
		{
			final String ERROR_MESSAGE = "User is NOT logged in";

			feedback.setFailure();
			feedback.setErrorCode(ERROR_CODE_GENERAL);
			feedback.setErrorText(ERROR_MESSAGE);
			feedback.setUserErrorText(ERROR_MESSAGE);
			response.setFeedback(feedback);

			logger.error(ERROR_MESSAGE);
		}

			bSuccessfullLogoutProcess = response.getFeedback().isSuccessful();
		}
		catch (Throwable e)
		{
			logger.error("doLogout",e);
			feedback.setFailure();
			feedback.setErrorCode(ERROR_CODE_GENERAL);
			feedback.setErrorText(e.getMessage());
		}
		finally
		{
			// Transaction commit/rollback.
			Feedback fbTransaction = endTransaction(arrTransactionHolder[0], bSuccessfullLogoutProcess);
			if (!fbTransaction.isSuccessful())
			{
				response.setFeedback(fbTransaction);
			}
		}

		

		return response;
	}

	private void removeMessagesLock(final WebSessionInfo webSessionInfo)
	{
		if (webSessionInfo != null)
		{
			List<String> mids = webSessionInfo.getMids();
			List<PDO> pdos = new ArrayList<PDO>();
			PDO pdo;
			for (String mid : mids)
			{
				pdo = PaymentDataFactory.newPDO();
				pdo.setMID(mid);
				pdo.setOwnerContextId(webSessionInfo.getSessionID());
				pdo.setThinMode(true);
				pdos.add(pdo);
			}
			try
			{
				CacheKeys.ProcessPDOKey.removeFromLocalAndPropagateToRemote(pdos);
			}
			catch (CacheException e)
			{
				ExceptionController.getInstance().handleException(e, null);
			}
		}
	}

	// ////////////////////////////////////////
	// ///////// END LOGOUT METHODS ///////////
	// ////////////////////////////////////////

	/**
	 * Returns the session data for one user
	 */
	@AuthorizeUser(returnWebSessionInfo = true)
	public SimpleResponseDataComponent getOneUserSessionData()
	{
		SimpleResponseDataComponent response = new SimpleResponseDataComponent();

		final WebSessionInfo webSessionInfo = Admin.getContextAdmin().getWebSessionInfo();

		boolean bEmptyUserEntitlementName = false;
		boolean bNoDataForUserEntitlementName = false;
		boolean bSessionViolation = false;

		String sUserEntitlementName = null;

		Feedback feedback = new Feedback();

		// Got back actual WebSessionInfo object
		if (webSessionInfo != null)
		{
			sUserEntitlementName = webSessionInfo.getUEntName();

			if (!sUserEntitlementName.equals(ServerConstants.EMPTY_STRING))
			{
				UserEntitlementData userEntitlementData = EntitlementsDataFactory.getInstance().getUserEntitlementData(sUserEntitlementName);

				// There is actual data for this entitlement name.
				if (userEntitlementData != null)
				{
					UserSession userSession = new UserSession(userEntitlementData.getORIG_PERM_PROF_QUEUE(), userEntitlementData
							.getORIG_PERM_PROF_ALERTS(), userEntitlementData.getORIG_PERM_PROF_OFFICE(), userEntitlementData.getOffice(),
							userEntitlementData.getORIG_PERM_PROF_ACCESS(), userEntitlementData.getAccessProfileName());

					// Updates returned value.
					response.setDataArray(new Object[] { userSession });
				}

				else
				{
					bNoDataForUserEntitlementName = true;
				}
			}

			// Empty user entitlement name.
			else
			{
				bEmptyUserEntitlementName = true;
			}
		}

		// No actual WebSessionInfo object; i.e. this user isn't logged in.
		else
		{
			bSessionViolation = true;
		}
		// Some failure.
		if (bNoDataForUserEntitlementName || bEmptyUserEntitlementName || bSessionViolation)
		{
			String sErrorMessage = null;

			if (bNoDataForUserEntitlementName)
			{
				sErrorMessage = new StringBuffer(ERROR_MESSAGE_NO_DATA_FOR_USER_ENT_NAME).append(sUserEntitlementName).toString();
			}
			else if (bEmptyUserEntitlementName)
			{
				sErrorMessage = ERROR_MESSAGE_EMPTY_USER_ENT_NAME;
			}
			else
			// bSessionViolation
			{
				sErrorMessage = ERROR_MESSAGE_SESSION_VIOLATION;
			}

			feedback.setFailure();
			feedback.setErrorCode(ERROR_CODE_GENERAL);
			feedback.setErrorText(sErrorMessage);
			feedback.setUserErrorText(sErrorMessage);
			response.setFeedback(feedback);

			logger.error(sErrorMessage);
		}

		return response;
	}

	@AuthorizeUser(returnWebSessionInfo = true)
	public SimpleResponseDataComponent keepUserAlive()
	{

		final SimpleResponseDataComponent response = new SimpleResponseDataComponent();
		Feedback feedback = response.getFeedback();

		final WebSessionInfo webSessionInfo = Admin.getContextAdmin().getWebSessionInfo();

		// No actual WebSessionInfo object; i.e. this user isn't logged in.
		if (webSessionInfo == null)
		{
			feedback.setFailure();
			feedback.setErrorCode(ERROR_CODE_SESSION_VIOLATION);
			feedback.setErrorText(ERROR_MESSAGE_SESSION_VIOLATION);
			feedback.setUserErrorText(ERROR_MESSAGE_SESSION_VIOLATION);
			response.setFeedback(feedback);
		}// EOM

		return response;

	}// EOM

	/**
   * 
   */
	public SimpleResponseDataComponent changePassword(PasswordDetails passwordDetails,
			Boolean bEventChangePasswordAtLogin ) {
  
		SimpleResponseDataComponent response = new SimpleResponseDataComponent();

		UserTransaction[] arrTransactionHolder = new UserTransaction[1];
		Feedback feedback = startTransaction(arrTransactionHolder);
		boolean bCommitTransaction=false;
		// Successfull transaction opening.
		if (feedback.isSuccessful()) {
			try
			{
				if (!bEventChangePasswordAtLogin) {
					this.isUserAuthorized(feedback);
				}// EO if the event was triggered prior to logging in
	
				if (feedback.isSuccessful()) {
					final Admin admin = Admin.getContextAdmin();
					feedback = performChangePassword(admin.getSessionID(), passwordDetails.getUsername(),
							passwordDetails.getOldPassword(), passwordDetails.getNewPassword(), passwordDetails.getConfirmedPassword());
				}
	
				response.setFeedback(feedback);
				bCommitTransaction = feedback.isSuccessful();
			}
			catch (Throwable e)
			{
				logger.error("changePassword",e);
				feedback.setFailure();
				feedback.setErrorCode(ERROR_CODE_GENERAL);
				feedback.setErrorText(e.getMessage());
			}
			finally
			{
				// Transaction commit/rollback.
				Feedback fbTransaction = endTransaction(arrTransactionHolder[0], bCommitTransaction);
				if (!fbTransaction.isSuccessful()) {
					response.setFeedback(fbTransaction);
				}
			}
		}

		// Failure transcation opening.
		else {
			response.setFeedback(feedback);
		}

		return response;
	}
	/**
	 * this function chack if password is valid and change his password in DB
	 */
	private Feedback performChangePassword(String sSessionId, String sUserID, String sOldPassword, String sNewPassword, String sNewPasswordConfirm)
	{
		

		Feedback feedback = new Feedback();
		ArrayList<String> allErrMsg = new ArrayList<String>();
		
		feedback = validateChangePasswordRequestParams(sSessionId, sUserID, sOldPassword, sNewPassword, sNewPasswordConfirm, allErrMsg);

		if (feedback.isSuccessful())
		{
			feedback = validatePasswordChangesToday(sSessionId, sUserID,allErrMsg);

			feedback = validateNewPasswordProperties(sSessionId, sUserID, sNewPassword, allErrMsg);

			feedback = checkValidPassword(sSessionId, sUserID, sNewPassword, allErrMsg);
		}
		
		if(allErrMsg.size() > 0)
		{
			feedback.setUserErrorText(arrayToString(allErrMsg.toArray(),','));
			feedback.m_bIsSuccessful = false;
		}

		if (feedback.isSuccessful() && !(allErrMsg.size() > 0))
		{
			feedback = updateDBRecordsForChangePassword(sSessionId, sUserID, sNewPassword, sOldPassword);
		}

		return feedback;
	}
	
	/**
	 * Validate password for reset password flow and create new user flow
	 * @param sSessionId
	 * @param sUserID
	 * @param sNewPassword
	 * @param sNewPasswordConfirm
	 * @param newUser true for new user, false for reset password for existing user
	 * @return
	 */
	public Feedback validatePasswordForNewUserAndReset(String sSessionId, String sUserID, String sNewPassword, String sNewPasswordConfirm, boolean newUser){
		
		Feedback feedback = new Feedback();
		

		if (feedback.isSuccessful())
		{
			feedback = validateNewPasswordProperties(sSessionId, sUserID, sNewPassword, newUser);
		}

		if (feedback.isSuccessful())
		{
			feedback = checkValidPassword(sSessionId, sUserID, sNewPassword, newUser);
		}
		
		return feedback;
	}
	

	/**
	 * Validates the change password request parameters.
	 */
	private Feedback validateChangePasswordRequestParams(String sSessionId, String sUserID, String sOldPassword, String sNewPassword,
			String sNewPasswordConfirm, ArrayList<String> allErrMsg)
	{
		

		Feedback feedback = new Feedback();

		if (feedback.isSuccessful())
		{
			if (sUserID.length() == 0)
			{
				configureErrorFeedback(ERROR_CODE_GENERAL, ERROR_MESSAGE_EMPTY_USERNAME, feedback);
				allErrMsg.add(feedback.getUserErrorText());
			}
			
			if (sOldPassword.length() == 0)
			{
				configureErrorFeedback(ERROR_CODE_GENERAL, ERROR_MESSAGE_EMPTY_OLDPASSWORD, feedback);
				allErrMsg.add(feedback.getUserErrorText());
			}
		
			if (sNewPassword.length() == 0)
			{
				configureErrorFeedback(ERROR_CODE_GENERAL, ERROR_MESSAGE_EMPTY_USER_PASSWORD, feedback);
				allErrMsg.add(feedback.getUserErrorText());
			}
		
			if (sNewPassword.equals(sOldPassword))
			{
				configureErrorFeedback(ERROR_CODE_GENERAL, ERROR_MESSAGE_NEW_PASSWORD_EQUAL_OLD_PASSWORD, feedback);
				allErrMsg.add(feedback.getUserErrorText());
			}
		
			if (!sNewPassword.equals(sNewPasswordConfirm))
			{
				configureErrorFeedback(ERROR_CODE_GENERAL, ERROR_MESSAGE_WRONG_USER_PASSWORD_CONFIRM, feedback);
				allErrMsg.add(feedback.getUserErrorText());
			}
		}

		// Stands for the password in the database.
		String sUSERPASSWD = null;

		if (feedback.isSuccessful())
		{
			boolean[] arrInvalidUserID = new boolean[1];
			DTODataHolder dtoUsers = getUserProfile(sUserID, arrInvalidUserID);
			feedback = dtoUsers.getFeedBack();

			sUSERPASSWD = dtoUsers.getColumnData(COLUMN_USERS_USERPASSWD);

			if (sUSERPASSWD.length() == 0)
			{
				String sMsgError = ERROR_MESSAGE_EMPTY_DB_PASSWORD.replaceFirst(GlobalConstants.PERCENTAGE_SIGN, sUserID);
				configureErrorFeedback(ERROR_CODE_GENERAL, sMsgError, feedback);
			}
		}

		if (feedback.isSuccessful())
		{
			if (!sUSERPASSWD.equals(getEncryptedPassword(sOldPassword)))
			{
				configureErrorFeedback(ERROR_CODE_GENERAL, ERROR_MESSAGE_WRONG_PASSWORD, feedback);
			}
		}

		

		return feedback;
	}


	/**
	 * Updates USERS and OLDPSWDS tables with appropriate values.
	 */
	private Feedback updateDBRecordsForChangePassword(String sSessionId, String sUserID, String sNewPassword, String sOldPassword)
	{
		
		DTODataHolder dtoUserDetails = new DTODataHolder();
		String sOffice = null;
		String sDepartment = null;
		String sUidUsers = null;
		String note = GlobalConstants.EMPTY_STRING;
		

		String sPasswordDate = m_daoSecurity.getFormattedSystemDateFromDatabase(null, GlobalDateTimeUtil.STATIC_DATA_DATE);
		String sPasswordTime = m_daoSecurity.getSystemTimeFromDatabase();

		String sEncryptedOldPassword = getEncryptedPassword(sOldPassword);
		String sEncryptedPassword = getEncryptedPassword(sNewPassword);
		Feedback feedback = m_daoSecurity.updateOLDPSWDS_Table(sUserID, sEncryptedPassword, sPasswordDate, sPasswordTime);

		if (feedback.isSuccessful())
		{
			String sTempPassword = GlobalConstants.ZERO_VALUE;
			feedback = m_daoSecurity.updateUSERS_TableForChangePassword(sUserID, sEncryptedPassword, sPasswordDate, sPasswordTime, sTempPassword);
		}
		
		//updating the PROFILE_UPDATE and PROFILE_UPDATE_DETAILS tables for auditing purpose
		if (feedback.isSuccessful())
		{
			dtoUserDetails =  m_daoSecurity.getUserDetails(sUserID); //this.getUserRecord(sUserID, sUserEntitlementName);
			
			sOffice = dtoUserDetails.getColumnData(COLUMN_USERS_OFFICE);
			sDepartment = dtoUserDetails.getColumnData(COLUMN_USERS_DEPARTMENT);
			sUidUsers = dtoUserDetails.getColumnData(COLUMN_USERS_UID_USERS);
			
			DTOModifiedField ModifiedFields = new DTOModifiedField(COLUMN_USERS_USERPASSWD, sEncryptedOldPassword, sEncryptedPassword);
			
			feedback = profileUserAudit(LayoutConstants.PROFILE_ID_USERS, sOffice, new DTOModifiedField[]{ModifiedFields}, note, sDepartment, sUserID,sUidUsers);
		}

		

		return feedback;
	}

	/**
	 * Check password validation like password with no blanks and password not as user id and doesn't have more than 2 sequence chars.
	 */
	private Feedback checkValidPassword(String sSessionId, String sUserID, String sNewPassword, boolean newUser){
		Feedback feedback = new Feedback();
		if (!newUser){
			feedback = validateNewPasswordAgainstOldPasswords(sSessionId, sUserID, sNewPassword);
		}

		if (feedback.isSuccessful())
		{
			if (sNewPassword.toUpperCase().equals(sUserID))
			{
				configureErrorFeedback(ERROR_CODE_GENERAL, ERROR_MESSAGE_PASSWD_EQUAL_USERID, feedback);
			}
		}

		if (feedback.isSuccessful())
		{
			if (!sNewPassword.trim().equals(sNewPassword))
			{
				configureErrorFeedback(ERROR_CODE_GENERAL, ERROR_MESSAGE_PASSWD_HAS_BLANKS, feedback);
			}
		}

		// Check if the new password has more than 2 sequence chars.
		if (feedback.isSuccessful())
		{
			int iSeqChars = 1;
			char cLastChar = sNewPassword.charAt(0);

			for (int iCounter = 1; iCounter < sNewPassword.length(); iCounter++)
			{
				char cCurrentChar = sNewPassword.charAt(iCounter);
				if (cCurrentChar == cLastChar)
				{
					iSeqChars++;
				}

				else
				{
					iSeqChars = 1;
				}

				cLastChar = cCurrentChar;

				if (iSeqChars == 3)
				{
					configureErrorFeedback(ERROR_CODE_GENERAL, ERROR_MESSAGE_PASSWD_HAS_IDENTICAL_CHARACTERS, feedback);
					break;
				}
			}
		}

		

		return feedback;
	}
	
	/**
	 * Check password validation like password with no blanks and password not as user id and doesn't have more than 2 sequence chars.
	 */
	private Feedback checkValidPassword(String sSessionId, String sUserID, String sNewPassword, boolean newUser, ArrayList<String> allErrMsg){
		Feedback feedback = new Feedback();
		if (!newUser){
			feedback = validateNewPasswordAgainstOldPasswords(sSessionId, sUserID, sNewPassword);
		}

		if (feedback.isSuccessful())
		{
			if (sNewPassword.toUpperCase().equals(sUserID))
			{
				configureErrorFeedback(ERROR_CODE_GENERAL, ERROR_MESSAGE_PASSWD_EQUAL_USERID, feedback);
				allErrMsg.add(feedback.getUserErrorText());
			}

			if (!sNewPassword.trim().equals(sNewPassword))
			{
				configureErrorFeedback(ERROR_CODE_GENERAL, ERROR_MESSAGE_PASSWD_HAS_BLANKS, feedback);
				allErrMsg.add(feedback.getUserErrorText());
			}
		}

		// Check if the new password has more than 2 sequence chars.
		feedback = checkSequenceChars(sNewPassword, feedback, allErrMsg);

		return feedback;
	}
	
	private Feedback checkSequenceChars(String sNewPassword, Feedback feedback, ArrayList<String> allErrMsg)
	{
		int iSeqChars = 1;
		char cLastChar = sNewPassword.charAt(0);

		for (int iCounter = 1; iCounter < sNewPassword.length(); iCounter++)
		{
			char cCurrentChar = sNewPassword.charAt(iCounter);
			if (cCurrentChar == cLastChar)
			{
				iSeqChars++;
			}

			else
			{
				iSeqChars = 1;
			}

			cLastChar = cCurrentChar;

			if (iSeqChars == 3)
			{
				configureErrorFeedback(ERROR_CODE_GENERAL, ERROR_MESSAGE_PASSWD_HAS_IDENTICAL_CHARACTERS, feedback);
				allErrMsg.add(feedback.getUserErrorText());
				break;
			}
		}
		return feedback;
	}

	
	private Feedback checkValidPassword(String sSessionId, String sUserID, String sNewPassword, ArrayList<String> allErrMsg){
		return checkValidPassword(sSessionId, sUserID, sNewPassword, false, allErrMsg);
	}
	
	/**
	 * Validates the new password against the old passwords in OLDPSWDS table.
	 */
	private Feedback validateNewPasswordAgainstOldPasswords(String sSessionId, String sUserID, String sNewPassword)
	{
		

		Feedback feedback = new Feedback();

		String sEncryptedNewPassword = getEncryptedPassword(sNewPassword);
		DTODataHolder dtoOLDPSWDS_Data = m_daoSecurity.get_OLDPSWDS_Data(sUserID);

		String sOffice = null;
		DTODataHolder dtoUsers = null;

		// Gets the user's data.
		if (feedback.isSuccessful())
		{
			boolean[] arrInvalidUserID = new boolean[1];
			dtoUsers = getUserProfile(sUserID, arrInvalidUserID);
			feedback = dtoUsers.getFeedBack();
		}

		// Deletes old passwords in case there are more than defined number in the NUMOLDPASS system parameter.
		if (feedback.isSuccessful())
		{
			// Gets user's office.
			sOffice = dtoUsers.getColumnData(COLUMN_USERS_OFFICE);

			int iNumOfExistingOldPasswords = dtoOLDPSWDS_Data.getRowsNumber();
			String sNUMOLDPASS = SystParKey.getSingleParmValue(sOffice, SystemParametersInterface.SYS_PAR_NUMOLDPASS);

			if (isNullOrEmpty(sNUMOLDPASS) || sNUMOLDPASS.equals(GlobalConstants.ZERO_VALUE))
			{
				sNUMOLDPASS = DEFAULT_NUM_OLD_PASS;
			}

			int iNumOfPasswordsToRemove = iNumOfExistingOldPasswords - Integer.parseInt(sNUMOLDPASS) + 1;

			if (iNumOfPasswordsToRemove > 0)
			{
				String sPASSWDDATE, sPASSWDTIME;

				for (int i = 0; i < iNumOfPasswordsToRemove; i++)
				{
					sPASSWDDATE = dtoOLDPSWDS_Data.getColumnDataByRow(COLUMN_OLDPSWDS_PASSWDDATE, i);
					sPASSWDTIME = dtoOLDPSWDS_Data.getColumnDataByRow(COLUMN_OLDPSWDS_PASSWDTIME, i);

					feedback = m_daoSecurity.deleteOldPasswordsFromOLDPSWDS_Table(sUserID, sPASSWDDATE, sPASSWDTIME);
				}
			}
		}

		// Checks if the new passsword equals to old password.
		if (feedback.isSuccessful())
		{
			String sPasswordDB = dtoUsers.getColumnData(COLUMN_USERS_USERPASSWD);

			if (sPasswordDB.equals(sEncryptedNewPassword))
			{
				configureErrorFeedback(ERROR_CODE_GENERAL, ERROR_MESSAGE_PASSWD_ALREADY_USED, feedback);
			}
		}

		// Checks if the new passsword exists in OLDPSWDS table.
		if (feedback.isSuccessful())
		{
			DTOBoolean dtoPasswordExists = m_daoSecurity.doesPasswordExistInOLDPSWDS_Table(sUserID, sEncryptedNewPassword);
			feedback = dtoPasswordExists.getFeedBack();

			if (feedback.isSuccessful())
			{
				if (dtoPasswordExists.getValue())
				{
					configureErrorFeedback(ERROR_CODE_GENERAL, ERROR_MESSAGE_PASSWD_ALREADY_USED, feedback);
				}
			}
		}

		

		return feedback;
	}

	/**
	 * returns an array of Business Date (as Strings) according to the Offices array gicen as a parameter
	 */
	private String[] attachBusinessDateToOffice(String[] arrOffices, String sDefaultBusinessDate)
	{
		if (arrOffices == null)
			return null;

		String[] a_oOfficeBsnssDate = new String[arrOffices.length];
		String sBusinessDate;
		Banks banks;

		if (a_oOfficeBsnssDate != null)
			for (int i = 0; i < arrOffices.length; i++)
			{
				banks = CacheKeys.banksKey.getSingle(arrOffices[i]);
				if (banks != null && banks.getBsnessdate() != null)
				{
					sBusinessDate = GlobalDateTimeUtil.dateToStaticDataString(banks.getBsnessdate());
				}
				else
				{
					sBusinessDate = sDefaultBusinessDate;
				}
				a_oOfficeBsnssDate[i] = sBusinessDate;
			}
		return a_oOfficeBsnssDate;
	}

	/**
	 * Validates that user can chnage the password today.
	 */
	private Feedback validatePasswordChangesToday(String sSessionId, String sUserID, ArrayList<String> allErrMsg)
	{
		

		boolean[] arrInvalidUserID = new boolean[1];
		DTODataHolder dtoUsers = getUserProfile(sUserID, arrInvalidUserID);

		Feedback feedback = dtoUsers.getFeedBack();

		// Success.
		if (feedback.isSuccessful())
		{
			String sOffice = dtoUsers.getColumnData(COLUMN_USERS_OFFICE);

			String sNumPassPerDay = SystParKey.getSingleParmValue(sOffice, SystemParametersInterface.SYS_PAR_NUMPSWDDAY);

			if (isNullOrEmpty(sNumPassPerDay) || sNumPassPerDay.equals(UNLIMITED_PASSWD_CHANGES_DAY))
			{
				final String strUnlimitedPasswdChanges = "Value of NUMPSWDDAY system parameter allows unlimited number of password changes per day !!!";
				logger.warn(strUnlimitedPasswdChanges);
			}

			else
			{
				DTOSingleValue dto = m_daoSecurity.getNumUserPasswordsChangesToday(sUserID);
				feedback = dto.getFeedBack();

				if (feedback.isSuccessful())
				{
					int iNumUserPasswordChangesToday = Integer.parseInt(dto.getValue());
					if (iNumUserPasswordChangesToday >= Integer.parseInt(sNumPassPerDay))
					{
						configureErrorFeedback(ERROR_CODE_GENERAL, ERROR_MESSAGE_EXCEED_LIMIT_PASSWD_CHANGES, feedback);
						allErrMsg.add(feedback.getUserErrorText());
					}
				}
			}
		}

		

		return feedback;
	}

	/**
	 * Validates new password properties like length and num of digits/letters.
	 */
	private Feedback validateNewPasswordProperties(String sSessionId, String sUserID, String sNewPassword, boolean newUser)
	{
		

		boolean[] arrInvalidUserID = new boolean[1];
		DTODataHolder dtoUsers = getUserProfile(sUserID, arrInvalidUserID);
		Feedback feedback = new Feedback();
		if (!newUser){
			feedback = dtoUsers.getFeedBack();
		}

		if (feedback.isSuccessful())
		{
			// Gets user's office.
			String sOffice = dtoUsers.getColumnData(COLUMN_USERS_OFFICE);

			// Gets all related system parameters.
			String sMaxPasswordLen = SystParKey.getSingleParmValue(sOffice, SystemParametersInterface.SYS_PAR_MAXPASSLEN);
			int iMaxPasswordLen = isNullOrEmpty(sMaxPasswordLen) ? DEFAULT_MAX_PASSWORD_LEN : Integer.valueOf(sMaxPasswordLen).intValue();
			//
			String sMinPasswordChars = SystParKey.getSingleParmValue(sOffice, SystemParametersInterface.SYS_PAR_MINPASSCHR);
			int iMinPasswordChars = isNullOrEmpty(sMinPasswordChars) ? DEFAULT_MIN_PASSWD_CHAR : Integer.valueOf(sMinPasswordChars).intValue();
			//
			String sMinPasswordDigits = SystParKey.getSingleParmValue(sOffice, SystemParametersInterface.SYS_PAR_MINPASSDIG);
			int iMinPasswordDigits = isNullOrEmpty(sMinPasswordDigits) ? DEFAULT_MIN_PASSWD_DIGIT : Integer.valueOf(sMinPasswordDigits).intValue();
			//
			int iMinPasswordLen = iMinPasswordChars + iMinPasswordDigits;

			// Checks min length of the new password.
			if (sNewPassword.length() < iMinPasswordLen)
			{
				configureErrorFeedback(ERROR_CODE_GENERAL, String.format(ERROR_MESSAGE_MIN_PASSWD_LEN, iMinPasswordLen), feedback);
			}

			// Checks max length of new password.
			else if (sNewPassword.length() > iMaxPasswordLen)
			{
				configureErrorFeedback(ERROR_CODE_GENERAL, String.format(ERROR_MESSAGE_MAX_PASSWD_LEN, iMaxPasswordLen), feedback);
			}

			// Checks min digits and letters in the new password.
			else
			{
				int iNumDigits = 0, iNumLetters = 0;

				int iPassLength = sNewPassword.length();
				for (int iCounter = 0; iCounter < iPassLength; iCounter++)
				{
					if (Character.isDigit(sNewPassword.charAt(iCounter)))
					{
						iNumDigits++;
					}
					else if (Character.isLetter(sNewPassword.charAt(iCounter)))
					{
						iNumLetters++;
					}
				}

				if (iNumDigits < iMinPasswordDigits)
				{
					configureErrorFeedback(ERROR_CODE_GENERAL, String.format(ERROR_MESSAGE_MIN_PASSWD_DIGIT, iMinPasswordDigits), feedback);
				}

				else if (iNumLetters < iMinPasswordChars)
				{
					configureErrorFeedback(ERROR_CODE_GENERAL, String.format(ERROR_MESSAGE_MIN_PASSWD_CHAR, iMinPasswordChars), feedback);
				}
			}
		}

		

		return feedback;
	}
	
	/**
	 * Validates new password properties like length and num of digits/letters.
	 */
	private Feedback validateNewPasswordProperties(String sSessionId, String sUserID, String sNewPassword, boolean newUser, ArrayList<String> allErrMsg)
	{
		

		boolean[] arrInvalidUserID = new boolean[1];
		DTODataHolder dtoUsers = getUserProfile(sUserID, arrInvalidUserID);
		Feedback feedback = new Feedback();
		if (!newUser){
			feedback = dtoUsers.getFeedBack();
		}

		if (feedback.isSuccessful())
		{
			// Gets user's office.
			String sOffice = dtoUsers.getColumnData(COLUMN_USERS_OFFICE);

			// Gets all related system parameters.
			String sMaxPasswordLen = SystParKey.getSingleParmValue(sOffice, SystemParametersInterface.SYS_PAR_MAXPASSLEN);
			int iMaxPasswordLen = isNullOrEmpty(sMaxPasswordLen) ? DEFAULT_MAX_PASSWORD_LEN : Integer.valueOf(sMaxPasswordLen).intValue();
			//
			String sMinPasswordChars = SystParKey.getSingleParmValue(sOffice, SystemParametersInterface.SYS_PAR_MINPASSCHR);
			int iMinPasswordChars = isNullOrEmpty(sMinPasswordChars) ? DEFAULT_MIN_PASSWD_CHAR : Integer.valueOf(sMinPasswordChars).intValue();
			//
			String sMinPasswordDigits = SystParKey.getSingleParmValue(sOffice, SystemParametersInterface.SYS_PAR_MINPASSDIG);
			int iMinPasswordDigits = isNullOrEmpty(sMinPasswordDigits) ? DEFAULT_MIN_PASSWD_DIGIT : Integer.valueOf(sMinPasswordDigits).intValue();
			//
			int iMinPasswordLen = iMinPasswordChars + iMinPasswordDigits;

			// Checks min length of the new password.
			if (sNewPassword.length() < iMinPasswordLen)
			{
				configureErrorFeedback(ERROR_CODE_GENERAL, String.format(ERROR_MESSAGE_MIN_PASSWD_LEN, iMinPasswordLen), feedback);
				allErrMsg.add(feedback.getUserErrorText());
			}

			// Checks max length of new password.
			else if (sNewPassword.length() > iMaxPasswordLen)
			{
				configureErrorFeedback(ERROR_CODE_GENERAL, String.format(ERROR_MESSAGE_MAX_PASSWD_LEN, iMaxPasswordLen), feedback);
				allErrMsg.add(feedback.getUserErrorText());
			}

			// Checks min digits and letters in the new password.
			feedback = checkDigitsAndLetters(sNewPassword, iMinPasswordDigits, iMinPasswordChars, feedback, allErrMsg);
			
		}

		return feedback;
	}
	
	private Feedback checkDigitsAndLetters(String sNewPassword, int iMinPasswordDigits, int iMinPasswordChars, Feedback feedback, ArrayList<String> allErrMsg)
	{
		int iNumDigits = 0, iNumLetters = 0;

		int iPassLength = sNewPassword.length();
		for (int iCounter = 0; iCounter < iPassLength; iCounter++)
		{
			if (Character.isDigit(sNewPassword.charAt(iCounter)))
			{
				iNumDigits++;
			}
			else if (Character.isLetter(sNewPassword.charAt(iCounter)))
			{
				iNumLetters++;
			}
		}

		if (iNumDigits < iMinPasswordDigits)
		{
			configureErrorFeedback(ERROR_CODE_GENERAL, String.format(ERROR_MESSAGE_MIN_PASSWD_DIGIT, iMinPasswordDigits), feedback);
			allErrMsg.add(feedback.getUserErrorText());
		}

		if (iNumLetters < iMinPasswordChars)
		{
			configureErrorFeedback(ERROR_CODE_GENERAL, String.format(ERROR_MESSAGE_MIN_PASSWD_CHAR, iMinPasswordChars), feedback);
			allErrMsg.add(feedback.getUserErrorText());
		}
		return feedback;
	}
	
	private Feedback validateNewPasswordProperties(String sSessionId, String sUserID, String sNewPassword, ArrayList<String> allErrMsg){
		return validateNewPasswordProperties(sSessionId, sUserID, sNewPassword, false, allErrMsg);
	}

	/**
   * 
   */
	@AuthorizeUser
	public SimpleResponseDataComponent getUserData(String sUserID)
	{
		SimpleResponseDataComponent response = new SimpleResponseDataComponent();

		Feedback feedback = null;
		final Admin admin = Admin.getContextAdmin();

		final String sErrorMessagePrefix = this.getClass().getName() + ".getUserData() --> error whilst invoking ";
		final String USER_PROFILES_RETRIEVAL_ERROR_MSG = sErrorMessagePrefix + "getUserProfiles()";
		final String USER_PROFILE_RETRIEVAL_ERROR_MSG = sErrorMessagePrefix + "getUserProfile()";
		final String U_ENT_NAME_RETRIEVAL_ERROR_MSG = sErrorMessagePrefix + "getUserEntitlementName()";

		try
		{
			boolean bHadOperationSucceeded = true;

			String sUserEntitlmentName = null;

			UserLoginData userLoginData = new UserLoginData(sUserID, admin.getCallSource().toString(), null);

			// set an empty string to the lastlogin
			userLoginData.setLastLoginInfo(GlobalConstants.EMPTY_STRING);

			// retrieve the user entitlement name.
			DTODataHolder dtoUserRecord = this.m_daoSecurity.getUserData(sUserID);

			sUserEntitlmentName = dtoUserRecord.getColumnData(COLUMN_USERS_U_ENT_NAME);

			// If the operaiton failed - return the feedback in the response
			if (!dtoUserRecord.isFeedBackSuccess() || (sUserEntitlmentName == null || (sUserEntitlmentName.equals(GlobalConstants.EMPTY_STRING))))
				return this.configureErrorResponse(U_ENT_NAME_RETRIEVAL_ERROR_MSG, feedback, false);

			// Set the entitlement name in the userLoginData.
			userLoginData.setUserEntitlementName(sUserEntitlmentName);

			// get the UserEntitlementData from the cache
			UserEntitlementData userEntitlementData = EntitlementsDataFactory.getInstance().getUserEntitlementData(sUserEntitlmentName);

			// get the rest of the user data
			feedback = this.getUserProfiles(userLoginData);

			// if the feedback is failure bail
			if (!feedback.isSuccessful())
				return this.configureErrorResponse(USER_PROFILES_RETRIEVAL_ERROR_MSG, feedback, false);

			userLoginData.setSessionID(admin.getSessionID());

			// invoke the hook method which will select the current entitlement credential
			// expected by the get getUserProfile method.
			String sGetUserDataEntitlementCredential = sUserEntitlmentName;

			// get the user profile (defaults)
			DTODataHolder dtoUsers = this.getUserProfile(sUserID, new boolean[1], sGetUserDataEntitlementCredential);

			// if the feedback is failure bail
			if (!feedback.isSuccessful())
				return this.configureErrorResponse(USER_PROFILE_RETRIEVAL_ERROR_MSG, feedback, false);

			// set the default department office and other defaults
			feedback = updateUserLoginData(dtoUsers, userLoginData);

			// set the default business date
			this.setDefaultBusinessDate(userLoginData);

			// set the department data in the loginData
			String[] sORIG_PERM_PROF_DEPARTMENT_SHOW = getDepShow(userEntitlementData);
			this.setDepartmentData(userLoginData, userEntitlementData.getPERM_PROF_DEPARTMENT(),sORIG_PERM_PROF_DEPARTMENT_SHOW);

			// Sets user preferences.
			this.setUserPreferences(userLoginData);

			// Sets default business date.
			this.setDefaultBusinessDate(userLoginData);

			// Updates returned value.
			response.setDataArray(new Object[] { userLoginData });

			// finally set the feedback in the response and return it
			if (feedback != null)
				response.setFeedback(feedback);
		}

		catch (Exception e)
		{
			response = this.configureErrorResponse(e.getMessage(), new Feedback(), true);
			logger.error(e.getMessage());
			return response;
		}// EO catch block ;

		return response;
	}
	
	public Map<String, Map<String,String>> getAccessLevelMap(){
		Feedback feedback = new Feedback();
		Map<String, Map<String,String>> result = new HashMap<String, Map<String,String>>(); 
		result.put("PROFILES", permissionHandler.getProfileIDtoAccessLevelMap(feedback)) ;
		result.put("TASKS", permissionHandler.getTaskIDAccessLevelMap(feedback)) ;
		result.put("MENU_ITEMS",permissionHandler.getMenuItemIDAccessLevelMap(feedback));
		return result;
	}
	
	private final <T> String arrayToString(final T[] arr, final char chrDelimiter) {
		  final StringBuilder builder = new StringBuilder("") ;
		  
		  int iPrimitiveArrayLength = -1; 
		  Class<?> clsItem = null ; 
		  for(T ele : arr) { 
			  if(ele == null) { 
				  builder.append("null") ;
			  }else { 
				  clsItem = ele.getClass() ;  
				  if(clsItem.isArray()) {
					  if(clsItem.getComponentType().isPrimitive()) { 
						  iPrimitiveArrayLength = Array.getLength(ele) ; 
						  for(int i=0 ; i < iPrimitiveArrayLength; i++) {
							  builder.append(Array.get(ele, i)) ; 
						  }//EO while there are more elements in the primitive array 
					  }else builder.append(arrayToString((T[])ele, chrDelimiter)) ; 
				  }else builder.append(ele.toString()) ; 
			  }//EO else if not null 
			  builder.append("\n") ;
		  }//EO while there are more elements in the array 
		  
		  return builder.toString() ; 
	  }//EOM 

}
