package backend.core.module.security.businessobjects;

import com.fundtech.cache.entities.WebSessionInfo;
import com.fundtech.cache.infrastructure.CreateCacheValueInterface;
import com.fundtech.core.security.Admin;
import com.fundtech.util.GlobalUtils;

public class CreateAuditUserCahceValue extends CreateSoapHeaderUserCahceValue implements CreateCacheValueInterface<WebSessionInfo> {
	
	protected WebSessionInfo m_applicationUserMetadata ; 
	
	public CreateAuditUserCahceValue (final WebSessionInfo applicationUserMetadata) {
		this.m_applicationUserMetadata = applicationUserMetadata ; 
	}
	public WebSessionInfo createCacheValue(Object key) {
		 
		final String sessionId  = GlobalUtils.generateGUID() ;
		WebSessionInfo auditWsi = (WebSessionInfo)this.m_applicationUserMetadata.clone(key.toString(),sessionId );    
		auditWsi.setExistInDB(false);
		
		Admin.getContextAdmin().setWebSessionInfo(auditWsi);
		Admin.getContextAdmin().setSessionId(sessionId);
		return auditWsi;
	}
	
	

}
