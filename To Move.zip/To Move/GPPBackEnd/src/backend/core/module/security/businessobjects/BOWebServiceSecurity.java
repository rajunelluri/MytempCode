package backend.core.module.security.businessobjects;

import static com.fundtech.errors.ProcessErrorConstants.WsLoginFailure;
import static com.fundtech.util.GlobalUtils.isNullOrEmpty;
 
import backend.dataaccess.dto.DTOBoolean;
import backend.dataaccess.dto.DTODataHolder;

import com.fundtech.cache.entities.WebSessionInfo;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.security.Admin;
import com.fundtech.core.security.UserLoginData;
import com.fundtech.datacomponent.request.UserCredentials;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.datacomponent.response.SimpleResponseDataComponent;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BOWebServiceSecurity extends BOSsoSecurity {

	private final static Logger logger = LoggerFactory.getLogger(BOWebServiceSecurity.class);
	
	protected static final String ERROR_MESSAGE = "Web Service login failed --> ";
 	protected static final CreateSoapHeaderUserCahceValue m_appServerIdCacheHandler = new CreateSoapHeaderUserCahceValue() ;
	
	public SimpleResponseDataComponent login(final UserCredentials userCredentials){		

		SimpleResponseDataComponent response = new SimpleResponseDataComponent();
		String sAuditUserID = userCredentials.getAuditUsername() ; 
		String sAppUserID = userCredentials.getUserName(); 
		String sUserEntitlementName  = userCredentials.getAdditionalParamValue(UserCredentials.KEY_ROLE_NAME) ;		
		
		Feedback feedback = response.getFeedback() ;
		
		//if audit user id is null or empty set it to the value of user Id
		if (isNullOrEmpty(sAuditUserID)) { 
			sAuditUserID = sAppUserID;
			logger.debug("Deriving audit from app user '{}' as not provided", sAppUserID); 
		}//EO if audit user id is null or empty 
		
		//check if soap header userId already had a web session info
		WebSessionInfo appUserWebSessionInfo = CacheKeys.WebSessionInfoKey.getSingle(sAppUserID);
		
		//if the app websession info was already cached (loggedin) 
		if (appUserWebSessionInfo != null) {
			
			logger.debug("BOWebServiceSecurity - app user wsi exists in cache"); 
			//Check if the user is Suspended or not
			DTOBoolean isSuspended = m_daoSecurity.isUserSuspended(sAppUserID);
			feedback = isSuspended.getFeedBack();

			if (feedback.isSuccessful())
			{
				if (isSuspended.getValue())
				{
					this.setFailure(response, WsLoginFailure, "soap user is suspended");
				}
				else {
					//fail as the user must be in DB
					if (!appUserWebSessionInfo.getExistInDB()) 
					{
						this.setFailure(response, WsLoginFailure, "soap user doesn't exists in DB");
					}//EO if the app user does not exist in the database 
				}
			}
		//Else if the app user id was not yet cached (loggedin) 
		}else {
			
			logger.debug("BOWebServiceSecurity - app user wsi doesn't exist in cache"); 
			final int [] affecttedRows = new int [1];
			
			//update the users table 
			feedback = m_daoSecurity.setActiveUserLoggedIn(sAppUserID,affecttedRows);
			
			//EO if the users table loggedin column update was successful 
			if (feedback.isSuccessful()) {
				
				//if user doesn't exist in DB set feedback to failure add error and return it				
				if (affecttedRows[0] == 0) {
					this.setFailure(response, feedback, WsLoginFailure, "soap user doesn't exist in DB or user is suspended or active");
				}else{	    				
					logger.debug("BOWebServiceSecurity - app user exists in DB");
				
					//login with app user user and cche for future references 
					appUserWebSessionInfo = CacheKeys.WebSessionInfoKey.getAndPut(m_appServerIdCacheHandler, sAppUserID);
					 
				}//EO else if the app user did not exist in DB 
			}//EO if the users table loggedin column update was successful 	
			else { 
				this.setFailure(response, feedback, WsLoginFailure, feedback.getErrorText());
			}//EO else setting active user loggedin 
		}//EO else if the app user was not yet loggedin
		
		//if app user get&cache was successful 
		if(response.getFeedback().isSuccessful()) { 
			
			//the entitlement must be the same - in case the entitlement was supplied in header
			//check that is is the same as stored in DB, else set the user entitlement as stored in DB
			final String dtoUserEntitlementName = appUserWebSessionInfo.getUEntName();
			
			//if the user entitlement was not provided use the cached one else ensure that the input and the cached 
			//values are the same 
			if (GlobalUtils.isNullOrEmpty(sUserEntitlementName)) sUserEntitlementName = dtoUserEntitlementName;
			else if (!dtoUserEntitlementName.equalsIgnoreCase(sUserEntitlementName)) {
				this.setFailure(response, WsLoginFailure, "app user entitlement is does not match app user definition");
			}//EO else if the user entitlement was provided in the input 
			
			//if the app and audit users are not the same, create the respective audit websessioninfo and update its websession info instance 
			//else simply use the app user websessioninfo 
			final WebSessionInfo auditUserWebSessionInfo = (sAuditUserID.equals(sAppUserID) ? appUserWebSessionInfo : 
							CacheKeys.WebSessionInfoKey.getAndPut(new CreateAuditUserCahceValue(appUserWebSessionInfo), sAuditUserID) 
						) ; 
			
			if (auditUserWebSessionInfo != null) {
				Admin.getContextAdmin().setWebSessionInfo(auditUserWebSessionInfo);
				feedback = this.updateUserData(auditUserWebSessionInfo, sAppUserID);
				
				if(!feedback.isSuccessful()) { 
					this.setFailure(response, feedback, WsLoginFailure, feedback.getErrorText());
				}//EO if update user data operation had failed 
				
			}else {
				this.setFailure(response, WsLoginFailure, "- after login - audit web session info is null after login!!!!");
			}//EO else if construction and caching of the audit user had failed 
			
		}//EO if app user get&cache was successful 
		  
		return response;
	}//EOM

	/**
	 * Update user data by calling to getUserProfile, updateUserLoginData and getUserProfiles methods
	 */
	protected final Feedback updateUserData(final WebSessionInfo auditWebSessionInfo, final String appUserId) {
		Admin admin = Admin.getContextAdmin();
		UserLoginData userLoginData = new UserLoginData(auditWebSessionInfo.getUserID(),admin.getCallSource().toString(), null);
		userLoginData.setLastLoginInfo(GlobalConstants.EMPTY_STRING);
		userLoginData.setUserEntitlementName(auditWebSessionInfo.getUEntName());

		boolean[] arrInvalidUserID = new boolean[1];
		DTODataHolder dtoUsers = getUserProfile(appUserId, arrInvalidUserID, auditWebSessionInfo.getUEntName());
		Feedback feedback = dtoUsers.getFeedBack();

		// Success.
		if (feedback.isSuccessful()) {
			feedback = updateUserLoginData(dtoUsers,userLoginData);
			// Check if the user entitlement is on HOLD
			if(userLoginData.getUserEntitlementRecStatus().equals("HD")) {
			  feedback.setErrorText("soap user's entitlement in database is suspended or inactive");
			  feedback.setFailure();
			}
			if (feedback.isSuccessful()) {
				getUserProfiles(userLoginData);
			}
		}
		return feedback;
	}//EOM
	
	protected final Feedback setFailure(final SimpleResponseDataComponent response, final int errorCode, final String sTraceErrorMsg) {
		return this.setFailure(response, response.getFeedback(), errorCode, sTraceErrorMsg) ; 
	}//EOM 
	
	protected final Feedback setFailure(final SimpleResponseDataComponent response, Feedback feedback, final int errorCode, final String sTraceErrorMsg) {
		
		logger.error(ERROR_MESSAGE + sTraceErrorMsg); 
		
		if(feedback == null) feedback = response.getFeedback() ;
		else response.setFeedback(feedback) ; 
		
		feedback.setFailure();
		feedback.setErrorCode(errorCode);
		feedback.setErrorText(GlobalUtils.getEditedErrorText(errorCode));
		feedback.setUserErrorText(GlobalUtils.getEditedErrorText(errorCode));
		
		return feedback ; 
	}//EOM
	
}//EOC 


