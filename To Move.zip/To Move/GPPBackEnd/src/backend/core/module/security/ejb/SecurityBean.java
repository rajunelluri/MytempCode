/*
 * Created on 08/05/2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package backend.core.module.security.ejb;
 
import java.util.Map;

import javax.ejb.Stateless;

import backend.core.SuperSLSB;
import backend.core.module.security.ejbinterfaces.Security;
import backend.core.module.security.ejbinterfaces.SecurityLocal;
import backend.services.cache.ASCacheFactory;
import backend.services.cache.SecurityModuleFactory;

import com.fundtech.annotations.DataSource;
import com.fundtech.annotations.Expose;
import com.fundtech.annotations.Wrap;
import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.request.PasswordDetails;
import com.fundtech.datacomponent.request.UserCredentials;
import com.fundtech.datacomponent.response.SimpleResponseDataComponent;
import com.fundtech.util.GlobalConstants.LoginModeType;

/**
 * XDoclet-based session bean.  The class must be declared
 * public according to the EJB specification.
 *
 * To generate the EJB related files to this EJB:
 *		- Add Standard EJB module to XDoclet project properties
 *		- Customize XDoclet configuration for your appserver
 *		- Run XDoclet
 *
 * Below are the xdoclet-related tags needed for this EJB.
 * 
 * @ejb.bean name="Security"
 *           display-name="Name for Security"
 *           description="Description for Security"
 *           jndi-name="ejb/SecurityBean"
 *           local-jndi-name="ejb/SecurityBeanLocal"
 *           type="Stateless"
 *           view-type="both"
 *           transaction-type="Bean"
 *           common-business-interface="true" 
 *           
 * @ejb.business.interface         
 *           
 * @ejb.resource-ref jndi-name="${datasource.jndi}"
 *           res-ref-name="${datasource.jndi}"   
 *           res-type="javax.sql.DataSource"
 *           res-auth="Application"
 */
@Wrap(datasources={@DataSource(datasourceJndiKey="active")}, tx="Bean")
@Stateless  
public class SecurityBean extends SuperSLSB<Security> implements SecurityLocal, backend.core.module.security.ejbinterfaces.Security {
  
  public SecurityBean(){
    super(); 
    
    //initial creation of the bo in accordance with the default login mode
    this.m_bo = SecurityModuleFactory.getInstance().getBOSecurity(
            LoginModeType.getWebLoginMode(), 
            this.m_bo) ;
  }//EOM 
  
  /**
   * Performs Integrated login.
   * 
   * @ejb.business  
   */
  @Expose
  public SimpleResponseDataComponent login(final Admin admin, UserCredentials credentials){ 
   
    //initialised here through the SecurityModuleFactory
    //in case of runtime modification of the login mode 
     m_bo  = SecurityModuleFactory.getInstance().getBOSecurity(credentials.getLoginMode(), this.m_bo) ;
      
    return m_bo.login(admin, credentials);
  }
   
  /**
   * Performs logout.
   * 
   * @ejb.business  
   */
  @Expose
  public SimpleResponseDataComponent logout(final Admin admin)
  {
    return m_bo.logout(admin);
  }
  
  /**
   * Returns the session data for the current active users.
   * 
   * @ejb.business  
   */
  @Expose
  public SimpleResponseDataComponent getUsersSessionData(final Admin admin)
  {
    return m_bo.getUsersSessionData(admin);
  }
  
  /**
   * Returns the session data for one user.
   * 
   * @ejb.business  
   */
  @Expose
  public SimpleResponseDataComponent getOneUserSessionData(final Admin admin)
  {      
    return m_bo.getOneUserSessionData(admin);
  }
  
  /**
   * Performs keep user alive.
   * 
   * @ejb.business  
   */
  @Expose
  public SimpleResponseDataComponent keepUserAlive(final Admin admin)
  {
    return m_bo.keepUserAlive(admin);
  }
  /**
   * Performs change password.
   * 
   * @ejb.business  
   */
  @Expose
  public SimpleResponseDataComponent changePassword(final Admin  admin,PasswordDetails passwordDetails,Boolean isEventChangePasswordAtLogin)
  {
    return m_bo.changePassword(admin,passwordDetails,isEventChangePasswordAtLogin);
  }
  
  /**
   *  Aggregates and constructs the userLogin data required for a non login operations such as internal system cleanup 
   *  tasks
   * @param admin
   * @param sUserId
   * 
   * @ejb.business  
   */
  @Expose
  public SimpleResponseDataComponent getUserData(final Admin admin, String sUserId)  { 
      return m_bo.getUserData(admin, sUserId) ;
  }
  
  /**
   *  Aggregates and constructs the userLogin data required for a non login operations such as internal system cleanup 
   *  tasks
   * @param admin
   * @param sUserId
   * 
   * @ejb.business  
   */
  @Expose
  public Map<String, Map<String,String>> getAccessLevelMap()  { 
	  return m_bo.getAccessLevelMap();
  }
}