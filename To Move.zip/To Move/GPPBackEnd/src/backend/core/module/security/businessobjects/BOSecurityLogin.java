package backend.core.module.security.businessobjects;

import static com.fundtech.cache.infrastructure.regions.CacheKeys.SystParKey;
import static com.fundtech.util.GlobalUtils.isNullOrEmpty;

import java.security.MessageDigest;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;

import javax.transaction.UserTransaction;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import sun.misc.BASE64Encoder;
import backend.businessobject.proxies.AuthorizeUser;
import backend.businessobject.proxies.SkipInputValidation;
import backend.core.module.BOCoreServices;
import backend.core.module.security.dataaccess.dao.DAOSecurity;
import backend.dataaccess.dto.DTOBoolean;
import backend.dataaccess.dto.DTODataHolder;
import backend.dataaccess.dto.DTOSingleValue;
import backend.paymentprocess.erroraudit.ErrorAuditUtils;
import backend.services.cache.entitlements.EntitlementsDataFactory;
import backend.util.ServerConstants;

import com.fundtech.annotations.Expose;
import com.fundtech.annotations.Expose.ExposureType;
import com.fundtech.annotations.Wrap;
import com.fundtech.cache.entities.Banks;
import com.fundtech.cache.entities.SystPar;
import com.fundtech.cache.entities.WebSessionInfo;
import com.fundtech.cache.entities.WebSessionInfo.LoginType;
import com.fundtech.cache.infrastructure.CacheException;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.cache.syspar.SystemParametersInterface;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.paymentprocess.data.PaymentDataFactory;
import com.fundtech.core.paymentprocess.data.fields.DataType;
import com.fundtech.core.paymentprocess.errorhandling.ProcessError;
import com.fundtech.core.security.Admin;
import com.fundtech.core.security.UserLoginData;
import com.fundtech.core.security.UserSession;
import com.fundtech.datacomponent.request.PasswordDetails;
import com.fundtech.datacomponent.request.UserCredentials;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.datacomponent.response.SimpleResponseDataComponent;
import com.fundtech.errors.ProcessErrorConstants;
import com.fundtech.util.BindingParameter;
import com.fundtech.util.ErrorAuditInputData;
import com.fundtech.util.ExceptionController;
import com.fundtech.util.GlobalConstants;
import com.fundtech.util.GlobalDateTimeUtil;
import com.fundtech.util.GlobalUtils;
import com.fundtech.util.datetime.DateAndZone;
import com.fundtech.util.datetime.NewASDateTimeUtils;


/**
 * Title: BOSecurityLogin Description: Business object for core login and authentication Company: Fundtech Israel Author: Asaf Levy Date: 19/11/06
 * 
 * @version 1.0
 * @bo.internalInterface
 */
@Wrap

public class BOSecurityLogin extends BOCoreServices
{
	private final static Logger logger = LoggerFactory.getLogger(BOSecurityLogin.class);
	
	protected static DAOSecurity m_daoSecurity = new DAOSecurity();

	// General constants.
	private static final String SESSION_TYPE_WEB = "WEB";
	private static final String REC_STATUS_AC = "AC";
	private static final String WEBUSERLIV_DEFUALT_VALUE = "300";
	private static final String UNLIMITED_PASSWD_CHANGES_DAY = "0";
	private static final int DEFAULT_MAX_PASSWORD_LEN = 8;
	private static final int DEFAULT_MAX_USERNAME_LEN = 8;	// TODO: change
	private static final int DEFAULT_MIN_PASSWD_CHAR = 3;
	private static final int DEFAULT_MIN_PASSWD_DIGIT = 3;
	private static final String DEFAULT_NUM_OLD_PASS = "5";
	private static final String DEFAULT_MAX_TRIES = "6";	// Default number of login tries


	// ERRORLOG table related constants.
	private static final String SECURITY_MESSAGE_PREFIX = "Security level error- (Security Bean) - ";
	protected static final String ERROR_CODE_27004 = "27004";

	// OLDPSWDS table columns.
	private static final String COLUMN_OLDPSWDS_PASSWDDATE = "PASSWDDATE";
	private static final String COLUMN_OLDPSWDS_PASSWDTIME = "PASSWDTIME";

	// USERS table columns.
	private static final String COLUMN_USERS_USER_NAME = "USER_NAME";
	private static final String COLUMN_USERS_FIRST_NAME = "FIRST_NAME";
	private static final String COLUMN_USERS_OFFICE = "OFFICE";
	private static final String COLUMN_USERS_DEPARTMENT = "DEPARTMENT";
	private static final String COLUMN_USERS_BAD_LOGIN = "BAD_LOGIN";
	private static final String COLUMN_USERS_LOGGED_IN = "LOGGED_IN";
	private static final String COLUMN_USERS_MAX_AMOUNT = "MAX_AMOUNT";
	private static final String COLUMN_USERS_BUSINESS_AREA = "BUSINESS_AREA";
	private static final String COLUMN_USERS_MAX_FORCE_AMOUNT = "MAX_FORCE_AMOUNT";
	protected static final String COLUMN_USERS_U_ENT_NAME = "U_ENT_NAME";
	protected static final String COLUMN_USERS_REC_STATUS = "REC_STATUS";
	private static final String COLUMN_USERS_USERPASSWD = "USERPASSWD";
	private static final String COLUMN_USERS_TEMPPASSWD = "TEMPPASSWD";
	private static final String COLUMN_USERS_PASSWDDATE = "PASSWDDATE";
	private static final String COLUMN_USERS_SUSPENDED = "SUSPENDED";
	private static final String COLUMN_USERS_LASTLOGIN_DATE = "LASTLOGIN_DATE";

	// USER_ENTITLEMENT table columns.
	private static final String COLUMN_USER_ENTITLEMENT_DEPARTMENT 		= "DEPARTMENT";
	private static final String COLUMN_USER_ENTITLEMENT_OFFICE 			= "OFFICE";
    private static final String COLUMN_USER_ENTITLEMENT_REC_STATUS		= "REC_STATUS";
	
	// BANKS table columns.
	private static final String COLUMN_BANKS_CALNAME = "CALNAME";
	private static final String COLUMN_BANKS_CURRENCY = "CURRENCY";
	private static final String COLUMN_BANKS_BSNESSDATE = "BSNESSDATE";

	// USER_VACATION table columns.
	private static final String COLUMN_USER_VACATION_V_START_DATE = "V_START_DATE";
	private static final String COLUMN_USER_VACATION_V_END_DATE = "V_END_DATE";

	// Error codes.
	public static final int ERROR_CODE_INVALID_USER_PASSWORD = 98;
	public static final int ERROR_CODE_USER_TEMP_PASSWORD_CHANGE_REQUIRED = 99;
	private static final int ERROR_CODE_USER_PASSWORD_CHANGE_REQUIRED = 99;

	// Error messages.
	private static final String ERROR_MESSAGE_LOGIN_FAILED = "Login failed";
	private static final String ERROR_MESSAGE_NO_DATA_FOR_USER_ENT_NAME = "No data found for this user entitlement name: ";
	private static final String ERROR_MESSAGE_EMPTY_USER_ENT_NAME = "Empty user entitlement name";
	private static final String ERROR_MESSAGE_SESSION_VIOLATION = "User is NOT logged in";
	private static final String ERROR_MESSAGE_WRONG_USER_PASSWORD_CONFIRM = "The new password and the verify password are not equal.";
	private static final String ERROR_MESSAGE_EMPTY_USER_PASSWORD = "No new password was supplied.";
	private static final String ERROR_MESSAGE_EMPTY_OLDPASSWORD = "No old password was supplied.";
	private static final String ERROR_MESSAGE_NEW_PASSWORD_EQUAL_OLD_PASSWORD = "New password is the same as the old password";
	private static final String ERROR_MESSAGE_EMPTY_USERNAME = "No User ID was supplied";
	private static final String ERROR_MESSAGE_EXCEED_LIMIT_PASSWD_CHANGES = "You have exceeded the limit of password changes for one day.\r\nPlease contact your Security Supervisor.";
	private static final String ERROR_MESSAGE_MIN_PASSWD_LEN = "Password length must be at least %s characters";
	private static final String ERROR_MESSAGE_MAX_PASSWD_LEN = "Password length must be no more than %s characters";
	private static final String ERROR_MESSAGE_MIN_PASSWD_CHAR = "Passwords must contain at least %s letters";
	private static final String ERROR_MESSAGE_MIN_PASSWD_DIGIT = "Passwords must contain at least %s numbers";
	private static final String ERROR_MESSAGE_PASSWD_ALREADY_USED = "This password has been used previously.  You may enter another password.";
	private static final String ERROR_MESSAGE_PASSWD_EQUAL_USERID = "The password must not be the same as the user ID.";
	private static final String ERROR_MESSAGE_PASSWD_HAS_BLANKS = "The password must not contain leading or trailing blanks.";
	private static final String ERROR_MESSAGE_PASSWD_HAS_IDENTICAL_CHARACTERS = "The password must not contain more than two sequential identical characters.";
	private static final String ERROR_MESSAGE_EMPTY_DB_PASSWORD = "User % does not have an old password in the database, contact your system administrator";
	private static final String ERROR_MESSAGE_WRONG_PASSWORD = "Error while updating new password,wrong password was supplied";
	private static final String ERROR_MESSGAE_INVALID_ROLE	= "Invalid Role";
	private static final String ERROR_MESSGAE_INACTIVE_ROLE	= "Inactive Role";
	private static final String ERRORLOG_MESSAGE_USER_SUSPENDED = "User is suspended, can not logged in until un-suspended";
	private static final String ERROR_MESSAGE_USER_SUSPENDED = "User is suspended.";
	private static final String USER_MESSAGE_USER_SUSPENDED = "You are suspended from Global PAYplus; please contact your system adminstrator";
	
	protected static final int ERROR_CODE_USER_INVALID = 28685;

	
	// NOTE: copied from BOSsoSecurity. note before marge 
	private static final DTODataHolder DTO_INVALID_USER_RECORD ; 
  
    static { 
        DTO_INVALID_USER_RECORD = new DTODataHolder() ;
        DTO_INVALID_USER_RECORD.getFeedBack().setFailure() ; 
        DTO_INVALID_USER_RECORD.getFeedBack().setErrorCode(ERROR_CODE_USER_INVALID) ;
    }//EO static block
	

	/**
	 * Constructor.
	 */
	public BOSecurityLogin()
	{}

	// //////////////////////////////////////
	// /////// START LOGIN METHODS //////////
	// //////////////////////////////////////
 
	/**
	/** Handles user login. */
	public SimpleResponseDataComponent login(UserCredentials credentials)
	{
		return login(credentials.getUserName(), credentials.getPassword(), credentials.getIP());
	}		
	
	/** Handles user login. */
	// Try new transaction, 
	// Set userLoginData with initial data, 
	// Calls doLogin() 
	public SimpleResponseDataComponent login(String username, String pwd, String ip)
	{
		SimpleResponseDataComponent response = new SimpleResponseDataComponent();
		
		UserTransaction[] arrTransactionHolder = new UserTransaction[1];
		
		Feedback feedback = startTransaction(arrTransactionHolder);

		// Successful start transaction
		if (feedback.isSuccessful()) {
			UserLoginData userLoginData = new UserLoginData(username, ip);
			response = doLogin(pwd, userLoginData, arrTransactionHolder, feedback);
		} 
		// Failure start transaction
		else {
			response.setFeedback(feedback);
		}
		return response;
	}

	
	/** Handles SSO login. 
	 * (In SSO: Single-Sign-On the authentication is done by another system) 
	 * All action within transaction are delegated to doLoginSSO()
	 * */
	public SimpleResponseDataComponent loginSSO(String userId, String userRole, String ip) 
	{
		SimpleResponseDataComponent response = new SimpleResponseDataComponent();

		createAdminIfNotFound();
		
		UserTransaction[] arrTransactionHolder = new UserTransaction[1];
		Feedback feedback = startTransaction(arrTransactionHolder);
		UserLoginData userLoginData=null;
		try
		{
			// Failure start transaction
			if (!feedback.isSuccessful()) {
				response.setFeedback(feedback);
				return response;
			}
	
			// doLoginSSO() all SSO login actions within transaction
			userLoginData = new UserLoginData(userId, ip);
			response = doLoginSSO(userLoginData, userRole);
		}
		catch (Throwable e)
		{
			logger.error("loginSSO",e);
			feedback.setFailure();
			feedback.setErrorCode(ERROR_CODE_GENERAL);
			feedback.setErrorText(e.getMessage());
		}
		finally
		{
			// Transaction commit/rollback.
			feedback = endTransaction(arrTransactionHolder[0], shouldCommitTransaction(response, userLoginData));
			if (!feedback.isSuccessful()) {
				response.setFeedback(feedback);
			}
		}
		
		return response;
	}
	
	// All loginSSO actions within the transaction
	private SimpleResponseDataComponent doLoginSSO(UserLoginData userLoginData, String userRole)
	{
		SimpleResponseDataComponent response = new SimpleResponseDataComponent();
	
		// Role data form DB ( USER_ENTITLEMENT table)
		////////////////////////////////////////////
		DTODataHolder dtoUserEntitlementData = m_daoSecurity.getUserEntitlementData(userRole);
		
		Feedback feedback = new Feedback();
		if (!roleExistAndActive( dtoUserEntitlementData, feedback)){
			response.setFeedback(feedback);
			return response;
		}
		
		// User data from DB (create if don't exist)
		////////////////////////////////////////////////
		String userId = userLoginData.getUserID();
		DTODataHolder dtoUsers = getUserProfile(userId, new boolean[1], true, userRole);
		feedback = dtoUsers.getFeedBack();

		// Failure: getting user from DB
		if (!feedback.isSuccessful()) {
			response.setFeedback(feedback);
			return response;
		}
		
		//set the isLoggedIn value in userLoginData before checkUserLoggedIn, because checkUserLoggedIn uses it
		setIsLoggedIn(userLoginData, dtoUsers);
		
		// Checks if user is already logged in if yes remove old session.
		checkUserLoggedInSSO(userLoginData.getUserID(), userLoginData, feedback);
		
		// User already logged in
		if (!feedback.isSuccessful()) {
			response.setFeedback(feedback);
			return response;
		}
		
		// WebSessionInfo
		updateUserLoginData(dtoUsers, userLoginData);
		updateSSOLoginData(userRole, dtoUserEntitlementData,userLoginData);
		
		setLastLoginInfo(userLoginData, dtoUsers);
		setBadLoginCount(userLoginData, dtoUsers, new int[1]); //TODO: do we need this in SSO login?

		// WebSessionInfo
		final WebSessionInfo webSessionInfo = new WebSessionInfo();
		webSessionInfo.setLoginType(LoginType.SSO);
		webSessionInfo.setUEntName(userRole);
		webSessionInfo.setUserID(userId);
		updateWebSessionInfoHM(webSessionInfo, userLoginData);
		
		feedback = handleSuccessfulLogin(userLoginData, webSessionInfo);			

		if (feedback.isSuccessful()) {
			setBadLoginInfo(userLoginData, userId);
			successfulLogin(response, userLoginData);				
		} else {
			response.setFeedback(feedback);				
		}
		return response;
	}

	boolean roleExistAndActive(DTODataHolder dtoUserEntitlementData, Feedback feedback)
	{
		// Failure: Role does NOT exist
		if (dtoUserEntitlementData.isEmpty()){
			feedback.setFailure();
			feedback.setErrorText(ERROR_MESSGAE_INVALID_ROLE);
			feedback.setUserErrorText(ERROR_MESSGAE_INVALID_ROLE);
			logger.error(ERROR_MESSGAE_INVALID_ROLE);
			return false;
		}

		HashMap hmData = dtoUserEntitlementData.getDataRow();
		String recStatus = (String) hmData.get(COLUMN_USER_ENTITLEMENT_REC_STATUS);

		// Failure: Role inactive
		if (!REC_STATUS_AC.equalsIgnoreCase(recStatus))	{
			feedback.setFailure();
			feedback.setErrorText(ERROR_MESSGAE_INACTIVE_ROLE);
			feedback.setUserErrorText(ERROR_MESSGAE_INACTIVE_ROLE);
			logger.error(ERROR_MESSGAE_INACTIVE_ROLE);
			return false;
		}
		
		return true;
	}
	
	
	// Get User data from DB
	// Update UserLoginData with DB data 
	// Set login info 
	// Call performLogin()
	// commit/rollback transaction
	private SimpleResponseDataComponent doLogin(String sPassword, 
												UserLoginData userLoginData,
												UserTransaction[] arrTransactionHolder, 
												Feedback feedback)
	{
		// parameters
		SimpleResponseDataComponent response = new SimpleResponseDataComponent();
		int[] arrBadLoginCountHolder= new int[1];
		boolean[] arrInvalidUserID 	= new boolean[1];
		boolean isSuccessfulLoginProcess = false;
		boolean isUserShouldBeSuspended = false;
		boolean isCommitTransaction = false;
		String sUserID ="";
		try
		{
			sUserID = userLoginData.getUserID();
			
		// Get User data from DB
		DTODataHolder dtoUsers = getUserProfile(sUserID, arrInvalidUserID);

		feedback = dtoUsers.getFeedBack();

		if (feedback.isSuccessful())
		{
			updateUserLoginData(dtoUsers, userLoginData);
			setIsLoggedIn(userLoginData, dtoUsers);
			setLastLoginInfo(userLoginData, dtoUsers);
			setBadLoginCount(userLoginData, dtoUsers, arrBadLoginCountHolder);

			feedback = performLogin(sPassword, userLoginData, dtoUsers);

			if (feedback.isSuccessful()) {
				setBadLoginInfo(userLoginData, sUserID);
				successfulLogin(response, userLoginData);				
			} else {
				response.setFeedback(feedback);				
			}
		}

		// Failure getting USERS record from DB for the passed user.
		else {
			response.setFeedback(feedback);
			updateFailedLoginAuditActivity(userLoginData, userLoginData.getDefaultOffice(), ERROR_MESSAGE_LOGIN_FAILED);
		}

			// Should commit?
			isSuccessfulLoginProcess = response.getFeedback().isSuccessful();
			isUserShouldBeSuspended = userLoginData != null && userLoginData.shouldSuspendUser();
			isCommitTransaction = isSuccessfulLoginProcess || isUserShouldBeSuspended;
			
			if (isSuccessfulLoginProcess){
				updateACTIVITY_AUDIT_Table(true, userLoginData, sUserID, null, null);
			}
		}
		catch (Throwable e)
		{
			logger.error("doLogin",e);
			feedback.setFailure();
			feedback.setErrorCode(ERROR_CODE_GENERAL);
			feedback.setErrorText(e.getMessage());
		
		}
		finally
		{
			// Transaction commit/rollback.
			Feedback fbTransaction = endTransaction(arrTransactionHolder[0], isCommitTransaction);
			if (!fbTransaction.isSuccessful()) {
				response.setFeedback(fbTransaction);
			}
		}
		
		updateBadLoginCountIfNeeded(sUserID, arrInvalidUserID, userLoginData, isSuccessfulLoginProcess, isUserShouldBeSuspended, arrBadLoginCountHolder);
		
		return response;
	}

	boolean shouldCommitTransaction(SimpleResponseDataComponent response, UserLoginData userLoginData)
	{
		boolean isSuccessfulLoginProcess = response.getFeedback().isSuccessful();
		boolean isUserShouldBeSuspended = userLoginData != null && userLoginData.shouldSuspendUser();
		boolean shouldCommitTransaction = isSuccessfulLoginProcess || isUserShouldBeSuspended;
		return shouldCommitTransaction;
	}
	

	private void setBadLoginInfo(UserLoginData userLoginData, String sUserID)
	{
		int iBadLoginCount = userLoginData.getBadLoginCount();
		if (iBadLoginCount > 0)
		{
			userLoginData.setBadLoginInfoMessage(new Integer(iBadLoginCount).toString());
		}
	}


	private void successfulLogin(SimpleResponseDataComponent response, UserLoginData userLoginData) {
		response.setDataArray(new Object[] { userLoginData });		
	}
	
	
	private void updateFailedLoginAuditActivity(UserLoginData userLoginData, String office, String message){

		office = isNullOrEmpty(office) ? GlobalConstants.DEFAULT_SERVER_OFFICE_NAME : office;

		Admin admin = Admin.getContextAdmin();
		if (admin == null){
			admin = new Admin(GlobalConstants.ANONYMOUS_CONTEXT_ID, userLoginData.getIP());;
			Admin.setContextAdmin(admin);
		}

		UserTransaction[] arrTransactionHolder = new UserTransaction[1];
		Feedback feedback = startTransaction(arrTransactionHolder);
		try
		{
			ErrorAuditInputData eaInputData = new ErrorAuditInputData(true, Admin.getContextAdmin().getSessionID(), getModuleID(),
					userLoginData.getUserID(), office, "User Login", message, Admin.getContextAdmin().getClientRemoteAddress());
	
			DateAndZone dateAndZone = NewASDateTimeUtils.getCurrentDateAndZoneByOffice(office);
			eaInputData.setUserStartDateAndTime(dateAndZone.getDate());
	
			eaInputData.setErrorCode((long) ProcessErrorConstants.LoginFailed);
			ErrorAuditUtils.handleErrorAndAudit(eaInputData);
	
	
			int iBadLoginCount = userLoginData.getBadLoginCount();
			if (iBadLoginCount > 0)
			{
				eaInputData.setErrorCode((long) ProcessErrorConstants.BadLoginCountMessage);
				eaInputData.setNonPaymentsFields(new Object[] { userLoginData.getUserID(), iBadLoginCount });
				ErrorAuditUtils.handleErrorAndAudit(eaInputData);
			}
		}
		catch (Throwable e)
		{
			logger.error("updateFailedLoginAuditActivity",e);
			feedback.setFailure();
			feedback.setErrorCode(ERROR_CODE_GENERAL);
			feedback.setErrorText(e.getMessage());
		}
		finally
		{
			feedback = endTransaction(arrTransactionHolder[0], true);
			if (!feedback.isSuccessful()) {
				logger.error(GlobalUtils.getFeedbackString(feedback));
			}
		}
	}


	private void updateBadLoginCountIfNeeded(String sUserID,
											 boolean[] arrInvalidUserID, 
											 UserLoginData userLoginData,
											 boolean isSuccessfullLoginProcess, 
											 boolean isUserShouldBeSuspended, 
											 int[] arrBadLoginCountHolder)
	{
	// Valid user ID was sent.
		if (!arrInvalidUserID[0])
		{
			// If:
			// 1) Login process has failed.
			// 2) User wasn't suspended during the login process.
			// 3) The bad login count was updated.
			// , than updates the USERS table with the new bad login count.
			if (userLoginData != null && !isSuccessfullLoginProcess && !isUserShouldBeSuspended
					&& userLoginData.getBadLoginCount() > arrBadLoginCountHolder[0])
			{
				updateBadLoginCount(sUserID, userLoginData.getBadLoginCount(), true);
			}
		}
		
	}

	private Feedback checkRoleExist(String userRole) {
		// Gets the entitlement data for this user from the USER_ENTITLEMENT table.
		DTODataHolder dtoUserEntitlementData = m_daoSecurity.getUserEntitlementData(userRole);
		
		Feedback feedback = new Feedback();

		if (dtoUserEntitlementData.isEmpty()) {
			feedback = dtoUserEntitlementData.getFeedBack();
			feedback.setFailure();
			feedback.setErrorText(ERROR_MESSGAE_INVALID_ROLE);
			feedback.setUserErrorText(ERROR_MESSGAE_INVALID_ROLE);
       }

		return feedback;
	}
	
	/**
	 * Updates the ACTIVITY_AUDIT table.
	 * 
	 * @param bForLogin true - login, false - logout.
	 * @param userLoginData UserLoginData object; will be null when 'bForLogin' is false.
	 * @param sUserID the user ID; can be null for login and in that case the value will be taken from the passed UserLoginData object.
	 * @param sDefaultOffice the default office of the user; can be null for login and in that case the value will be taken from the passed
	 *            UserLoginData object.
	 * @param sLogoutDate logout date; will be null when 'bForLogin' is true.
	 */
	private void updateACTIVITY_AUDIT_Table(boolean bForLogin, UserLoginData userLoginData, String sUserID, String sDefaultOffice, String sLogoutDate)
	{
		// Login.
		final String ACTIVITY_TYPE_LOGIN = "User Login";
		final String ACTIVITY_NAME_LOGIN = "User Login";

		// Logout.
		final String ACTIVITY_TYPE_LOGOUT = "User Logout";

		sUserID = isNullOrEmpty(sUserID) ? userLoginData.getUserID() : sUserID;
		sDefaultOffice = isNullOrEmpty(sDefaultOffice) ? userLoginData.getDefaultOffice() : sDefaultOffice;

		ErrorAuditInputData eaInputData = bForLogin ? new ErrorAuditInputData(true, Admin.getContextAdmin().getSessionID(), getModuleID(),
				sUserID, sDefaultOffice, ACTIVITY_TYPE_LOGIN, ACTIVITY_NAME_LOGIN, Admin.getContextAdmin().getClientRemoteAddress())
				: new ErrorAuditInputData(true, Admin.getContextAdmin().getSessionID(), getModuleID(), sUserID, sDefaultOffice,
						ACTIVITY_TYPE_LOGOUT, ACTIVITY_TYPE_LOGOUT, Admin.getContextAdmin().getClientRemoteAddress());

		DateAndZone dateAndZone = NewASDateTimeUtils.getCurrentDateAndZoneByOffice(sDefaultOffice);
		eaInputData.setUserStartDateAndTime(dateAndZone.getDate());

		// Login.
		if (bForLogin)
		{
			// Last login date message.
			String sLastLoginDate = userLoginData.getLastLoginDate();
			if (!isNullOrEmpty(sLastLoginDate))
			{
				eaInputData.setErrorCode((long) ProcessErrorConstants.LastLoginDateMessage);
				eaInputData.setNonPaymentsFields(new Object[] { sLastLoginDate });
				ErrorAuditUtils.handleErrorAndAudit(eaInputData);
			}
			//
			// Bad login count.
			int iBadLoginCount = userLoginData.getBadLoginCount();
			if (iBadLoginCount > 0)
			{
				eaInputData.setErrorCode((long) ProcessErrorConstants.BadLoginCountMessage);
				eaInputData.setNonPaymentsFields(new Object[] { sUserID, iBadLoginCount });
				ErrorAuditUtils.handleErrorAndAudit(eaInputData);
			}
		}

		// Logout.
		else
		{
			eaInputData.setErrorCode((long) ProcessErrorConstants.LogoutMessage);
			eaInputData.setNonPaymentsFields(new Object[] { sUserID, sLogoutDate });
			ErrorAuditUtils.handleErrorAndAudit(eaInputData);
		}

		
	}

	

	/**
	 * Returns the max login tries allowed for this office.
	 */
	private int getMaxLoginTries(String sOffice)
	{
		String sMaxLoginTries = SystParKey.getSingleParmValue(sOffice, SystemParametersInterface.SYS_PAR_LOGONRETRY);

		if (isNullOrEmpty(sMaxLoginTries))
			sMaxLoginTries = DEFAULT_MAX_TRIES;

		return Integer.valueOf(sMaxLoginTries).intValue();
	}

	/**
	 * Gets a user ID and returns its profile from the USERS table.
	 */
	public DTODataHolder getUserProfile(String sUserID, boolean[] arrInvalidUserID){
		return getUserProfile(sUserID, arrInvalidUserID, false, null);
	}

	
	/**
	 * Gets a user ID and returns its profile from the USERS table.
	 */
	public DTODataHolder getUserProfile(String userId, boolean[] arrInvalidUserID, boolean createIfDontExist, String entitlementName)
	{
		final String ERROR_MESSAGE_1 = "BOSecurityLogin.getUserProfile - error while retrieving user data; the user ID was not supplied.";
		final String ERROR_MESSAGE_2 = "BOSecurityLogin.getUserProfile - error while retrieving user data; the user ID can't be more than 8 characters.";
		final String ERROR_MESSAGE_3 = "BOSecurityLogin.getUserProfile - error while retrieving user data; the user ID or Role name doesn't exist.";
		final String ERROR_MESSAGE_4 = "BOSecurityLogin.getUserProfile - error while retrieving user data.";

		DTODataHolder dtoUsers = new DTODataHolder();

		Feedback feedback = new Feedback();

		String sErrorText = null;
		boolean bSuccess = true;

		// Invalid/Illegal user ID.
		if (isNullOrEmpty(userId))	{
			bSuccess = false;
			sErrorText = ERROR_MESSAGE_1;
			arrInvalidUserID[0] = true;
		}

		// User ID is too long.
		else if (userId.length() > DEFAULT_MAX_USERNAME_LEN) {
			bSuccess = false;
			sErrorText = ERROR_MESSAGE_2;
			arrInvalidUserID[0] = true;
		}

		// Valid user ID.
		else {

			// Gets the data for this user from the USERS table (
			if (createIfDontExist){
				dtoUsers = getOrCreateUserRecord(userId, entitlementName); 
			} else { 
				dtoUsers = getUserRecord(userId);
			}
			
			// Success.
			if (dtoUsers.isFeedBackSuccess())
			{
				// Invalid user ID.
				if (dtoUsers.isEmpty())	{
					bSuccess = false;
					sErrorText = ERROR_MESSAGE_3;
					arrInvalidUserID[0] = true;
				}
			}

			// Failure.
			else  {
				dtoUsers.getFeedBack().setErrorText(ERROR_MESSAGE_4);
				dtoUsers.getFeedBack().setUserErrorText(ERROR_MESSAGE_LOGIN_FAILED);
				logger.error(ERROR_MESSAGE_4);
			}
		}

		// Failure.
		if (!bSuccess) 	{
			feedback.setFailure();
			feedback.setErrorCode(ProcessErrorConstants.PermissionError);
			feedback.setErrorText(sErrorText);
			feedback.setUserErrorText(ERROR_MESSAGE_LOGIN_FAILED);
			dtoUsers.setFeedback(feedback);

			logger.error(sErrorText);
		}

		// Login failed.
		if (!dtoUsers.isFeedBackSuccess()) {
			String sMessage = constructErrorMessage(userId, ERROR_MESSAGE_LOGIN_FAILED);
			// Feedback feedbackErrorLog = m_daoSecurity.writeToErrorLog(SECURITY_MODULE, sMessage, sUserID, ERROR_CODE_27004, false);
			ErrorAuditUtils.setErrors(ProcessError.getError(ProcessErrorConstants.LoginError, new String[] { sMessage }, ""));
		}

		return dtoUsers;
	}

	/**
	 * Hook method to be customized by subclasses to deal with update or insert behaviour
	 * 
	 * @param sUseId unique identifyer of the user
	 * @return {@link DTODataHolder} containing the user's record
	 */
	protected DTODataHolder getUserRecord(String sUserID) {
		return m_daoSecurity.getUserData(sUserID);
	}// EOM

    /**
     * Hook method invoked within the getUserData() and will either insert or rertieve the user's data.
     * @see backend.core.module.security.businessobjects.BOSecurity#getUserRecord(java.lang.String, java.lang.String)
     */
	/* NOTE: this function was copied from BOSsoSecurity (by the name of getUserRecord(). 
	 * only small changes where made. Note for the marge between classes */
    protected DTODataHolder getOrCreateUserRecord(String sUserId, String sUserEntitlementName) { 

        Feedback feedback  =  null ;
        boolean bRequireRefectch = false ;
        String sPersistedUentName = null ;
        
        //step 1: Attempt to rertieve an existing user record for the user id.
        DTODataHolder dtoUserRecord = getUserRecord(sUserId) ;
        
        //if failure, return the faulty one 
        if(!dtoUserRecord.isFeedBackSuccess()) return DTO_INVALID_USER_RECORD ; 
        
        //step 2: if the user does not exist insert the user
        if(dtoUserRecord.isEmpty()) { 
            
            //the u_ent_name would be replaced with the proper u_ent_name
            feedback = this.m_daoSecurity.insertSsoUserRecrod(sUserId, sUserEntitlementName) ;
           
            //if failure, return the empty one 
            if(!feedback.isSuccessful()) return DTO_INVALID_USER_RECORD ; 

            //set the refectch record flag
            bRequireRefectch = true ; 
            
        }else { //EO if there was no such user in the system 
        
            //step 3: compare the persisted u_ent_name with the formal args one, and if different, 
            //update the u_ent_name in the DB  (this will update the office and the department as well
            sPersistedUentName = dtoUserRecord.getColumnData(COLUMN_USERS_U_ENT_NAME) ;
            
            if(sUserEntitlementName != null && !sUserEntitlementName.equals(sPersistedUentName)) {
               
                //the u_ent_name would be replaced with the proper u_ent_name
                feedback = this.m_daoSecurity.updateUserUentName(sUserId, sUserEntitlementName) ;
                
                //if failure, return the empty one 
                if(!feedback.isSuccessful()) return DTO_INVALID_USER_RECORD; 
                
                //set the refectch record flag
                bRequireRefectch = true ; 
            }//EO else if the unt names were not the same
            
        }//EO else if the user record existed 
        
//      Step 4: if the bRequireRefectch is true, 
        //fetch the user record again after the synchronization --> if the user
        //entitlement name was invalid, return the DTO_INVALID_USER_RECORD
        if(bRequireRefectch)  {
            dtoUserRecord = getUserRecord(sUserId) ; 
            
            sPersistedUentName = dtoUserRecord.getColumnData(COLUMN_USERS_U_ENT_NAME) ;
            
            if(!sPersistedUentName.equals(sPersistedUentName))  dtoUserRecord = DTO_INVALID_USER_RECORD ;
                
        }//EO if bRequireRefectch is true, 
                
        return dtoUserRecord ;
    }//EOM   

	
	
	/**
	 * Constructs an error message to be written into the ERRORLOG table.
	 */
	private String constructErrorMessage(String sUserID, String sErrorMessage)
	{
		final String COMMA_SPACE = ServerConstants.COMMA + ServerConstants.SPACE;

		return new StringBuffer(SECURITY_MESSAGE_PREFIX).append(sUserID).append(COMMA_SPACE).append(sErrorMessage).toString();
	}

	/**  Performs login. */
	// checkUserStatuses
	// handleSuccessfulLogin() / handle FailureLogin()
	protected Feedback performLogin(String sPassword, UserLoginData userLoginData, DTODataHolder dtoUsers)
	{
		Feedback feedback = checkUserStatus(sPassword, dtoUsers, userLoginData);
		
		if (feedback.isSuccessful()) {
			final WebSessionInfo webSessionInfo = new WebSessionInfo();
			updateWebSessionInfoHM(webSessionInfo, userLoginData);
			feedback = handleSuccessfulLogin(userLoginData, webSessionInfo);			
		} else {
			handleFailureLogin (sPassword, feedback, userLoginData);
		}

		return feedback;
	}

	
	private Feedback handleSuccessfulLogin( UserLoginData userLoginData, WebSessionInfo webSessionInfo)
	{
	// Sets the user as logged in.
		Feedback feedback = setUserLoggedIn(userLoginData, webSessionInfo);
		// Cleans the WEB_PROFILE_LOCK table from records with this user ID.

		cleanUserIDExistingLockRecords(userLoginData.getUserID());
		return feedback;
	}

	
	private void handleFailureLogin(String sPassword,
									Feedback feedback, 
									UserLoginData userLoginData)
	{
		String sUserID = userLoginData.getUserID();
		int iErrorCode = feedback.getErrorCode();

		// Invalid user password.
		if (iErrorCode == ERROR_CODE_INVALID_USER_PASSWORD)
		{
			int iBadLoginCount = userLoginData.getBadLoginCount();
			int iMaxAllowedLoginFailures = getMaxLoginTries(userLoginData.getDefaultOffice());

			if (iBadLoginCount < iMaxAllowedLoginFailures)
			{
				String sMessage = constructErrorMessage(sUserID, ERROR_MESSAGE_LOGIN_FAILED);
				ErrorAuditUtils.setErrors(ProcessError.getError(ProcessErrorConstants.LoginError, new String[] { sMessage }, ""));
				updateFailedLoginAuditActivity(userLoginData, userLoginData.getDefaultOffice(), ERROR_MESSAGE_LOGIN_FAILED);
				
				updateBadLoginCount(sUserID, userLoginData.getBadLoginCount(), false);
			}

			// User failed to login more than allowed login tries.
			else
			{
				final String ERRORLOG_ERROR_MESSAGE = "Wrong password entered. User will be suspended";
				String sMessage = constructErrorMessage(sUserID, ERRORLOG_ERROR_MESSAGE);
				ErrorAuditUtils.setErrors(ProcessError.getError(ProcessErrorConstants.LoginError, new String[] { sMessage }, ""));
				updateFailedLoginAuditActivity(userLoginData, userLoginData.getDefaultOffice(), ERRORLOG_ERROR_MESSAGE);

				final String TRACE_MESSAGE = "User retries to log more than allowed and will be suspended.";
				logger.error(TRACE_MESSAGE);

				suspendUser(userLoginData, sPassword, iBadLoginCount);
			}
		}

		// User needs to change his password.
		else if (iErrorCode == ERROR_CODE_USER_PASSWORD_CHANGE_REQUIRED)
		{
			final String TRACE_MESSAGE = "User needs to change his password.";
			logger.error(TRACE_MESSAGE);

			final String ERRORLOG_ERROR_MESSAGE = ". Need to change his password";
			String sMessage = constructErrorMessage(sUserID, ERRORLOG_ERROR_MESSAGE);
			ErrorAuditUtils.setErrors(ProcessError.getError(ProcessErrorConstants.LoginError, new String[] { sMessage }, ""));
			updateFailedLoginAuditActivity(userLoginData, userLoginData.getDefaultOffice(), TRACE_MESSAGE);
		}

		// No special error code; sets to general error code.
		else
		{
			if (feedback.getErrorText().equals(ERROR_MESSAGE_USER_SUSPENDED)){
				updateFailedLoginAuditActivity(userLoginData, userLoginData.getDefaultOffice(), ERRORLOG_MESSAGE_USER_SUSPENDED);
			}else{
				feedback.setErrorCode(ERROR_CODE_GENERAL);
				updateFailedLoginAuditActivity(userLoginData, userLoginData.getDefaultOffice(), ERROR_MESSAGE_LOGIN_FAILED);
			}
		}
		
	}

	/**
	 * Checks the user status, (temp password, password date, suspension status, etc).
	 */
	protected Feedback checkUserStatus(String sUserPassword, DTODataHolder dtoUsers, UserLoginData userLoginData)
	{
		String sUserID = userLoginData.getUserID();

		Feedback feedback = checkUserIsActive(userLoginData, (String) dtoUsers.getColumnData(COLUMN_USERS_REC_STATUS));

		if (feedback.isSuccessful()) {
			feedback = checkUserOnVacation(sUserID, sUserPassword, userLoginData);
		}

		if (feedback.isSuccessful()) {
			feedback = checkPassword(dtoUsers, sUserID, sUserPassword, userLoginData);
		}

		return feedback;
	}

	/**
	 * Updates the passed UserLoginData object according to the data in the passed 'dtoUsers' parameter.
	 */
	// The parallel C++ method is 'MapUsersDBToFTUser'.
	protected void updateUserLoginData(DTODataHolder dtoUsers, UserLoginData userLoginData)
	{
		HashMap hmData = dtoUsers.getDataRow();

		// User name.
		String sUserName = (String) hmData.get(COLUMN_USERS_USER_NAME);//last name
		String firstName = (String) hmData.get(COLUMN_USERS_FIRST_NAME);//first name
		sUserName = firstName.concat(" ").concat(sUserName).trim();
		userLoginData.setUserName(sUserName);

		// Office.
		String sOffice = (String) hmData.get(COLUMN_USERS_OFFICE);
		userLoginData.setDefaultOffice(sOffice);

		// Department.
		String sDepartment = (String) hmData.get(COLUMN_USERS_DEPARTMENT);
		userLoginData.setDefaultDepartment(sDepartment);

		// Max amount; this might be updated during the 'saveSessionInfo' method.
		String sMaxAmount = (String) hmData.get(COLUMN_USERS_MAX_AMOUNT);
		userLoginData.setMaxAmount(sMaxAmount);

		// Business area.
		String sBusinessArea = (String) hmData.get(COLUMN_USERS_BUSINESS_AREA);
		userLoginData.setDefaultBusinessArea(sBusinessArea);

		// Max amount force NSF.
		String sMaxAmountForceNSF = (String) hmData.get(COLUMN_USERS_MAX_FORCE_AMOUNT);
		userLoginData.setMaxAmountForceNSF(sMaxAmountForceNSF);

		// User entitlement name.
		String sUserEntitlementName = (String) hmData.get(COLUMN_USERS_U_ENT_NAME);
		userLoginData.setUserEntitlementName(sUserEntitlementName);	
	}

	protected void updateSSOLoginData(String userRole, DTODataHolder dtoUserEntitlementData, UserLoginData userLoginData)
	{
		HashMap hmData = dtoUserEntitlementData.getDataRow();

		// User entitlement name.
		userLoginData.setUserEntitlementName(userRole);	

		// Office.
		String office = (String) hmData.get(COLUMN_USER_ENTITLEMENT_OFFICE);
		userLoginData.setDefaultOffice(office);

		// Department.
		String department = (String) hmData.get(COLUMN_USER_ENTITLEMENT_DEPARTMENT);
		userLoginData.setDefaultDepartment(department);
	
		//TODO: move parameters from users to Entitlement table
//		// Max amount; this might be updated during the 'saveSessionInfo' method.
//		String sMaxAmount = (String) hmData.get(COLUMN_USERS_MAX_AMOUNT);
//		userLoginData.setMaxAmount(sMaxAmount);
//
//		// Business area.
//		String sBusinessArea = (String) hmData.get(COLUMN_USERS_BUSINESS_AREA);
//		userLoginData.setDefaultBusinessArea(sBusinessArea);
//
//		// Max amount force NSF.
//		String sMaxAmountForceNSF = (String) hmData.get(COLUMN_USERS_MAX_FORCE_AMOUNT);
//		userLoginData.setMaxAmountForceNSF(sMaxAmountForceNSF);
	}
	
	/**
	 * 
	 */
	protected void updateWebSessionInfoHM(final WebSessionInfo webSessionInfo, UserLoginData userLoginData)
	{
		webSessionInfo.setUserID(userLoginData.getUserID());
		webSessionInfo.setUEntName(userLoginData.getUserEntitlementName());
		webSessionInfo.setMaxAmountForceNSF(userLoginData.getMaxAmountForceNSF());
		webSessionInfo.setDefualtBusinessArea(userLoginData.getDefaultBusinessArea());
		webSessionInfo.setMaxAmountForceNSF(userLoginData.getMaxAmount());
		webSessionInfo.setDefaultOffice(userLoginData.getDefaultOffice());
		webSessionInfo.setDefaultDepartment(userLoginData.getDefaultDepartment());
		webSessionInfo.setSessionType(SESSION_TYPE_WEB);
	}
	
	/**
	 * Checks if the user is active according to the REC_STATUS column value.
	 */
	protected Feedback checkUserIsActive(UserLoginData userLoginData, String sUserRecStatus)
	{
		final String ERROR_MESSAGE = "The specified user is not active";

		Feedback feedback = new Feedback();

		if (!REC_STATUS_AC.equalsIgnoreCase(sUserRecStatus))
		{
			feedback.setFailure();
			feedback.setErrorText(ERROR_MESSAGE);
			feedback.setUserErrorText(ERROR_MESSAGE);

			logger.error(ERROR_MESSAGE);

			userLoginData.incrementBadLoginCount();
		}

		return feedback;
	}

	/**
	 * checks if the passed user ID is on vacation.
	 */
	private Feedback checkUserOnVacation(String sUserID, String sUserPassword, UserLoginData userLoginData)
	{
		final String ERROR_MESSAGE = "User is on vacation, and has been suspended. Please contact your system adminstrator.";
		final String VACATION_START_DATE = "Vacation START date - ";
		final String VACATION_END_DATE = ". Vacation END date - ";
		final String CURRENT_DATE = ". CURRENT date - ";

		Feedback feedback = new Feedback();

		// Gets the vacation data for this user from the USER_VACATION table.
		DTODataHolder dtoUserVacationData = m_daoSecurity.getUserVacationData(sUserID);

		// Success and there is data for this user.
		if (dtoUserVacationData.isFeedBackSuccess() && !dtoUserVacationData.isEmpty())
		{
			HashMap hmData = dtoUserVacationData.getDataRow(0);
			
			SimpleDateFormat simpleDateFormat = GlobalDateTimeUtil.getSimpleDateFormatByFormat(GlobalDateTimeUtil.STATIC_DATA_DATE);
			
			String sVacationStartDate = (String) hmData.get(COLUMN_USER_VACATION_V_START_DATE);
			String sVacationEndDate = (String) hmData.get(COLUMN_USER_VACATION_V_END_DATE);
			String sCurrentDate = simpleDateFormat.format(new Date());
			
			String sDates = new StringBuffer(VACATION_START_DATE).append(sVacationStartDate).append(VACATION_END_DATE).append(sVacationEndDate)
					.append(CURRENT_DATE).append(sCurrentDate).toString();
			logger.trace(sDates);

			if (GlobalDateTimeUtil.isCurrentDateBetweenTwoDates(sVacationStartDate, sVacationEndDate, simpleDateFormat))
			{
				feedback.setFailure();
				feedback.setErrorText(ERROR_MESSAGE);
				feedback.setUserErrorText(ERROR_MESSAGE);

				logger.error(ERROR_MESSAGE);

				userLoginData.incrementBadLoginCount();

				suspendUser(userLoginData, sUserPassword, userLoginData.getBadLoginCount());
			}
		
		} else {
			feedback = dtoUserVacationData.getFeedBack();
		}

		return feedback;
	}

	/**
	 * Suspends the passed user ID.
	 */
	private Feedback suspendUser(UserLoginData userLoginData, String sUserPassword, int iLoginFailuresCount)
	{
		final String ERROR_MESSAGE_1 = "Error while updating USERS table to suspend user.";
		final String ERROR_MESSAGE_2 = "Failed to insert new password to OLDPSWDS table.";

		String sUserID = userLoginData.getUserID();

		userLoginData.setShouldSuspendUser(true);

		Feedback feedback = m_daoSecurity.setUserAsSuspended(sUserID, String.valueOf(iLoginFailuresCount));

		if (!feedback.isSuccessful())
		{
			feedback.setErrorText(ERROR_MESSAGE_1);
		
		} 
		return feedback;
	}

	/**
	 * Checks the user password.
	 */
	private Feedback checkPassword( DTODataHolder dtoUsers, 
									String sUserID, 
									String sUserPassword, 
									UserLoginData userLoginData)
	{
		Feedback feedback = new Feedback();

		// Invalid user password.
		if (isNullOrEmpty(sUserPassword)) {
			handleNoPasswordSupplied(feedback);
			return feedback;
		}

		HashMap hmData = dtoUsers.getDataRow();

		// Checks if user is suspended.
		if (feedback.isSuccessful()) {
			checkUserSuspended(sUserID, userLoginData, feedback, hmData);
		}
		
		// Password validation should be done first and then rest of the validation should be done
		// (i.e. do rest of the validation if user logged in with valid password)
		if (feedback.isSuccessful()) {
			checkInvalidPassword(hmData, sUserID, sUserPassword, userLoginData, feedback);			
		}
		
		// TEMPPASSWD is non-zero, but PASSWDDATE is empty.
		if (feedback.isSuccessful()) {
			checkTemporaryPassword(sUserID, hmData, feedback);	
		}

		// Not needed! See Defect #55047
		//if (feedback.isSuccessful()) {
		//	checkUserLoggedIn(sUserID, userLoginData, feedback);
		//}
		
		//Check if password is expired
		if (feedback.isSuccessful()){
			checkPasswordExpired(sUserID, hmData, feedback);
		}

		return feedback;
	}
	
	
	/**
	 * Check if user's password is expired and should be changed
	 * @param sUserID
	 * @param hmData
	 * @param feedback
	 */
	private void checkPasswordExpired(String sUserID, HashMap hmData, Feedback feedback){
		SystPar numPassDaysParam = CacheKeys.SystParKey.getSingle(SystemParametersInterface.SYS_PAR_PASSWDDAYS);
		if (numPassDaysParam != null && numPassDaysParam.getParamName() != null && !isNullOrEmpty(numPassDaysParam.getParmValue())){ // system parameter exists
			int numPassDays = Integer.parseInt(numPassDaysParam.getParmValue());
			if (numPassDays != 0){ // zero value means that the validation should NOT be done
				String sPasswordDate = (String) hmData.get(COLUMN_USERS_PASSWDDATE);
				if (sPasswordDate != null && !sPasswordDate.equals(ServerConstants.EMPTY_STRING)){ 
					try {

						logger.debug("PASSWDDAYS is " + numPassDays);
						SimpleDateFormat sdf = new SimpleDateFormat(GlobalDateTimeUtil.STATIC_DATA_DATE);
						Date pswdCreateDate = sdf.parse(sPasswordDate);
						Calendar calendar = GregorianCalendar.getInstance();
						calendar.add(Calendar.DAY_OF_MONTH, -1 * numPassDays);
						if (pswdCreateDate.compareTo(calendar.getTime()) <= 0){ 
							final String ERROR_MESSAGE_EXPIRED_PASSWORD= "The password is expired and must be changed";

							feedback.setFailure();
							feedback.setErrorCode(ERROR_CODE_USER_PASSWORD_CHANGE_REQUIRED);
							feedback.setErrorText(ERROR_MESSAGE_EXPIRED_PASSWORD);
							feedback.setUserErrorText(ERROR_MESSAGE_EXPIRED_PASSWORD);
							logger.error(ERROR_MESSAGE_EXPIRED_PASSWORD);

							final String ERRORLOG_ERROR_MESSAGE = "User forced to change his password, password is expired";
							String sMessage = constructErrorMessage(sUserID, ERRORLOG_ERROR_MESSAGE);
							ErrorAuditUtils.setErrors(ProcessError.getError(ProcessErrorConstants.LoginError, new String[] { sMessage }, ""));
						}
					} catch (ParseException e) {
						logger.error("Could not parse password date", e); 
					}

				}
			}
		}

	}
	

	private void checkTemporaryPassword(String sUserID, HashMap hmData, Feedback feedback)
	{
		String sTempPassword = (String) hmData.get(COLUMN_USERS_TEMPPASSWD);
		String sPasswordDate = (String) hmData.get(COLUMN_USERS_PASSWDDATE);

		if (!sTempPassword.equals(ServerConstants.ZERO_VALUE) && 
				sPasswordDate.equals(ServerConstants.EMPTY_STRING))
		{
			final String ERROR_MESSAGE = "Temporary user password is true, but no 'password date period' is defined";
			final String TRACE_ERROR_MESSAGE = "Temporary user password error - TEMPPASSWD is true, but PASSWDDATE is empty.";

			feedback.setFailure();
			feedback.setErrorText(ERROR_MESSAGE);
			feedback.setUserErrorText(ERROR_MESSAGE);
			logger.error(TRACE_ERROR_MESSAGE);			
		}
		
		// Temp password flag is true.
		else if (!sTempPassword.equals(ServerConstants.ZERO_VALUE))
		{
			final String ERROR_MESSAGE_TEMP_PASSWORD = "The temporary password must be changed";

			feedback.setFailure();
			feedback.setErrorCode(ERROR_CODE_USER_TEMP_PASSWORD_CHANGE_REQUIRED);
			feedback.setErrorText(ERROR_MESSAGE_TEMP_PASSWORD);
			feedback.setUserErrorText(ERROR_MESSAGE_TEMP_PASSWORD);
			logger.error(ERROR_MESSAGE_TEMP_PASSWORD);

			final String ERRORLOG_ERROR_MESSAGE = "User forced to change his password, temp password flag is on";
			String sMessage = constructErrorMessage(sUserID, ERRORLOG_ERROR_MESSAGE);
			ErrorAuditUtils.setErrors(ProcessError.getError(ProcessErrorConstants.LoginError, new String[] { sMessage }, ""));
		}
		
		//checkTemporaryPasswordDepracted(feedback, sUserID, sPasswordDate);
		
	}
	
	private void checkInvalidPassword(	HashMap hmData, 
										String sUserID,
										String sUserPassword,
										UserLoginData userLoginData, 
										Feedback feedback)
	{
		String sEncryptedPassword = getEncryptedPassword(sUserPassword);

		// The user password as in the USERS table.
		String sUSERS_Password = (String) hmData.get(COLUMN_USERS_USERPASSWD);
		boolean isValidPassword = validatePassword(sUserID, sEncryptedPassword, sUSERS_Password);
		if (!isValidPassword)
		{
			feedback.setFailure();
			feedback.setErrorCode(ERROR_CODE_INVALID_USER_PASSWORD);
			feedback.setErrorText(ERROR_MESSAGE_LOGIN_FAILED);
			feedback.setUserErrorText(ERROR_MESSAGE_LOGIN_FAILED);
			logger.error(ERROR_MESSAGE_LOGIN_FAILED);

			userLoginData.incrementBadLoginCount();
		}			
	}

	private void handleNoPasswordSupplied(Feedback feedback)
	{
		final String TRACE_ERROR_MESSAGE = "ERROR: no password.";
		
		feedback.setFailure();
		feedback.setErrorCode(ERROR_CODE_INVALID_USER_PASSWORD);
		feedback.setErrorText(ERROR_MESSAGE_LOGIN_FAILED);
		feedback.setUserErrorText(ERROR_MESSAGE_LOGIN_FAILED);
		logger.error(TRACE_ERROR_MESSAGE);
	}

	/**
	 * Checks if user is suspended.
	 */
	protected void checkUserSuspended(String sUserID, UserLoginData userLoginData, Feedback feedback, HashMap hmData) {

		String sSuspended = (String) hmData.get(COLUMN_USERS_SUSPENDED);

		// User is suspended.
		if (!sSuspended.equals(ServerConstants.ZERO_VALUE))
		{
			feedback.setFailure();
			feedback.setErrorText(ERROR_MESSAGE_USER_SUSPENDED);
			feedback.setUserErrorText(USER_MESSAGE_USER_SUSPENDED);
			logger.error(ERROR_MESSAGE_USER_SUSPENDED);

			userLoginData.incrementBadLoginCount();

			String sMessage = constructErrorMessage(sUserID, ERRORLOG_MESSAGE_USER_SUSPENDED);
			ErrorAuditUtils.setErrors(ProcessError.getError(ProcessErrorConstants.LoginError, new String[] { sMessage }, ""));
		}
	}

	/**
	 * Checks if user is already logged in.
	 */
	protected void checkUserLoggedIn(String sUserID, UserLoginData userLoginData, Feedback feedback) {
		final String ERROR_MESSAGE = "The user is currently logged in";

		final WebSessionInfo webSessionInfo = CacheKeys.UserWebSessionInfoKey.getSingle(sUserID);
		boolean isLoggedInByDB = userLoginData.isLoggedIn();

		// User is already logged in from another machine or browser.
		if ((webSessionInfo != null) && isLoggedInByDB){
			 
			feedback.setFailure();
			feedback.setErrorText(ERROR_MESSAGE);
			feedback.setUserErrorText(ERROR_MESSAGE);
			logger.error(ERROR_MESSAGE);

			//userLoginData.incrementBadLoginCount();
		}//EO if the user was already loggedin
	}

	/**
	 * Gets the user password and returns an encryption of it.
	 * The encryption is done by 2 steps:
	 * 1. Encode the password using Java.Security.MessageDigest class  with algorithm "SHA-256"
	 * 	  [http://download.oracle.com/javase/1.4.2/docs/api/java/security/MessageDigest.html] 
	 * 	  This class provides the functionality of a message digest algorithm. ( secure one-way hash functions that take arbitrary-sized data and output a fixed-length hash value E.G.  MD5 or SHA).
	 *    The initialization of MessageDigest using getInstance(String algorithm), uses the package provide implementation of the algorithm, but if it's not available, other packages are searched for the algorithm implementation.
	 * 2. Encode again the 1'st step result (of 32 bytes) by using the sun.misc.BASE64Encoder.
 	 * 
	 * Those functions are called by using   java.lang.reflect.Method.invoke() 
	 * (Reflection is used to invoke a method when name of the method is supplied at run time) 
	 * [http://download.oracle.com/javase/1.4.2/docs/api/java/lang/reflect/Method.html )]
	 */
	public static String getEncryptedPassword(String sUserPassword)
	{

		String sPassword = ServerConstants.EMPTY_STRING;
		try
		{
            MessageDigest md = MessageDigest.getInstance(GlobalConstants.ENCODE_ALGORITHM);
            BASE64Encoder en = new BASE64Encoder();                                       
            
            md.update(sUserPassword.getBytes("UTF-8"));
            
            sPassword = en.encode(md.digest());
            
            md.reset();

		}
		catch (Exception e)
		{
			ExceptionController.getInstance().handleException(e, BOSecurityLogin.class);
		}// EO catch block

		return sPassword;
	}// EOM

	/**
	 * Returns if the passed passwords are valid or not.
	 */
	private boolean validatePassword(String sUserID, String sEncryptedPassword, String sUSERS_Password)
	{
		final String ERROR_MESSAGE_INVALID_PASSWORD = "Password isn't valid !!!";
		final String PASSWORDS_INFO = "Encrypted password & database password are: ";
		final String MESSAGE_VALID_PASSWORD = "Password is valid.";

		boolean bValid = true;

		if (isNullOrEmpty(sEncryptedPassword) || 
			isNullOrEmpty(sUSERS_Password) 	  || 
			!sEncryptedPassword.equals(sUSERS_Password))
		{
			logger.error(ERROR_MESSAGE_INVALID_PASSWORD);
			String sPasswordsInfo = new StringBuffer(PASSWORDS_INFO)
											.append(sEncryptedPassword)
											.append(ServerConstants.COMMA)
											.append(sUSERS_Password).toString();
			logger.error(sPasswordsInfo);
			bValid = false;
		} else {
			logger.trace(MESSAGE_VALID_PASSWORD);
		}
		return bValid;
	}

	/**
	 * Updates the USERS.BAD_LOGIN column.
	 */
	private void updateBadLoginCount(String sUserID, int iBadLoginCount, boolean bOpenTransaction)
	{
		UserTransaction[] arrTransactionHolder = null;
		Feedback feedback = new Feedback();
		boolean bSuccess=false;
		// Successful transaction opening.
		if (bOpenTransaction) {
			arrTransactionHolder = new UserTransaction[1];
			feedback = startTransaction(arrTransactionHolder);
		}
		try
		{
			if (feedback.isSuccessful())
			{
				feedback = m_daoSecurity.updateBadLoginCount(sUserID, iBadLoginCount);
	
				bSuccess = feedback.isSuccessful();
	
				if (!bSuccess) {
					logger.error(GlobalUtils.getFeedbackString(feedback));
				}
	
			}
		}
		catch (Throwable e)
		{
			logger.error("updateBadLoginCount",e);
			feedback.setFailure();
			feedback.setErrorCode(ERROR_CODE_GENERAL);
			feedback.setErrorText(e.getMessage());
		}
		finally
		{
			// Closes the opened transaction.
			if (bOpenTransaction)
			{
				feedback = endTransaction(arrTransactionHolder[0], bSuccess);

				if (!feedback.isSuccessful()) {
					logger.error(GlobalUtils.getFeedbackString(feedback));
				}
			}
		}
	}

	/**
	 * Sets the last login info into the passed UserLoginData obejct.
	 */
	private void setLastLoginInfo(UserLoginData userLoginData, DTODataHolder dtoUsers)
	{
		HashMap hmData = dtoUsers.getDataRow();

		String sLastLoginDate = (String) hmData.get(COLUMN_USERS_LASTLOGIN_DATE);

		userLoginData.setLastLoginDate(sLastLoginDate);

	}
	
	/**
	 * Sets the bad login count into the passed UserLoginData obejct.
	 */
	private void setBadLoginCount(UserLoginData userLoginData, DTODataHolder dtoUsers, int[] arrBadLoginCountHolder)
	{
		String sBadLoginCount = dtoUsers.getColumnData(COLUMN_USERS_BAD_LOGIN);

		if (sBadLoginCount.equals(ServerConstants.EMPTY_STRING))
		{
			sBadLoginCount = ServerConstants.ZERO_VALUE;
		}

		int iBadLoginCount = Integer.valueOf(sBadLoginCount).intValue();
		userLoginData.setBadLoginCount(iBadLoginCount);
		arrBadLoginCountHolder[0] = iBadLoginCount;
	}
	
	/**
	 * Sets the isLoggedIn into the passed UserLoginData obejct.
	 */
	private void setIsLoggedIn(UserLoginData userLoginData, DTODataHolder dtoUsers)
	{
		String isLoggedIn = dtoUsers.getColumnData(COLUMN_USERS_LOGGED_IN);
		userLoginData.setLoggedIn(!isLoggedIn.equals(ServerConstants.ZERO_VALUE));
	}

	/**
	 * Sets the user as logged in to the system.
	 */
	private Feedback setUserLoggedIn(UserLoginData userLoginData, final WebSessionInfo webSessionInfo )
	{
		String userId = userLoginData.getUserID();
		final Admin admin = new Admin(userId, userLoginData.getIP());
		Admin.setContextAdmin(admin);		

		Feedback feedback = new Feedback();
		
		removeMessagesLock(CacheKeys.UserWebSessionInfoKey.getSingle(admin.getSessionID()));
		// Removes existing, (if really exists), session info for this user ID.
		CacheKeys.UserWebSessionInfoKey.removeSingle(userId);

		// Generates a unique session ID for this user.
		String sSessionID = GlobalUtils.generateGUIDRandom() ;
		userLoginData.setSessionID(sSessionID);
		webSessionInfo.setSessionID(sSessionID);

		// set the session id in the admin context so that from this moment on it will be used
		// for loggi);
		admin.setSessionId(sSessionID);
		admin.setWebSessionInfo(webSessionInfo);
		Admin.setContextAdmin(admin);
		logger.info("Set session if for this login as:[{}]", sSessionID);
		
		// configures session info with the data in the userLoginData and puts in cache .
		feedback = this.configureNStoreSessionInfo(userLoginData, webSessionInfo);

		// Updates the USERS table.
		if (feedback.isSuccessful()) {
			feedback = updateUSERS_TableForLogin(userLoginData);
		}
		if (feedback.isSuccessful()) {
			webSessionInfo.login();			
		}
		else {
			logger.error(GlobalUtils.getFeedbackString(feedback));
		}

		return feedback;
	}

	
	/**
	 * Generates a unique session ID.
	 * 
	 * @bo.internalInterface
	
	@Expose(type = ExposureType.InternalInterface)
	public String generateSessionID(String sUserID)
	{
		

		StringBuffer sbSessionID = new StringBuffer();

		final int MAX_INT_VALUE = 2147483647;
		final int SESSION_ID_LENGTH = 32;
		final String ERROR_MESSAGE = "Couldn't get sys time from database; using 'new Date().getTime()' instead...";
		final String GENERATED_SESSION_ID = "Generated session ID: ";

		DTOSingleValue dto = m_daoSecurity.getUniqueSysTimeFromDB();
		Feedback feedback = dto.getFeedBack();

		// This value is used to initialize the pseudo-random number generator, (aka PRNG),
		// of the JVM for random alghorithm use.
		long lSeed;

		if (feedback.isSuccessful())
		{
			lSeed = Long.parseLong(dto.getValue());
		}
		else
		// failure
		{
			// Trace.
			logger.error(ERROR_MESSAGE);
			lSeed = new java.util.Date().getTime();
		}

		Random random = new Random(lSeed);

		for (int i = 0; i < SESSION_ID_LENGTH; i++)
		{
			// The following 3 lines are the equivalent to the following C++ line in
			// 'pay_dbfuncs.GenerateSessionID' method: "j = (int) Nn * rand() / (RAND_MAX + 1.0);"
			//
			int iNextInt = random.nextInt(MAX_INT_VALUE);
			float f = (float) ((float) iNextInt / (MAX_INT_VALUE + 1));
			int iCurrIndex = (int) (SESSION_ID_PROPER_CHARS_LENGTH * f);
			iCurrIndex = Math.abs(iCurrIndex);

			// Appends to the StringBuffer the char from the created index.
			sbSessionID.append(SESSION_ID_PROPER_CHARS[iCurrIndex]);
		}

		StringBuffer sb = new StringBuffer(GENERATED_SESSION_ID).append(sbSessionID);
		infoTrace(sbSessionID.toString());

		

		return sbSessionID.toString();
	}
	 */

	/**
	 * Cleans the WEB_PROFILE_LOCK table from records with this user ID. 
	 * TODO: 1. remove all the pdos from the local regions and release their respective locks in the remote regions
	 */
	@Expose(type = ExposureType.InternalInterface)
	public final void cleanUserIDExistingLockRecords(final String sUserID)
	{
		final Feedback feedback = m_daoSecurity.cleanUserIDExistingLockRecords(sUserID);

		if (!feedback.isSuccessful())
			logger.error(feedback.getErrorText());		
	}
	
	/**
	 * Saves data into the WEBSESSION_INFO table.
	 */
	// Add webSessionInfo to Admin and to the cache 
	protected final Feedback configureNStoreSessionInfo(UserLoginData userLoginData, final WebSessionInfo webSessionInfo)
	{
		final String sOffice = webSessionInfo.getDefaultOffice();

		// Gets additional data from BANKS table.
		final DTODataHolder dtoAdditionalDataFromBANKS = m_daoSecurity.getAdditionalDataFromBANKS(sOffice);
		Feedback feedback = dtoAdditionalDataFromBANKS.getFeedBack();
		//    
		if (feedback.isSuccessful())
		{
			HashMap hmData = dtoAdditionalDataFromBANKS.getDataRow();

			String sDefaultCalendar = (String) hmData.get(COLUMN_BANKS_CALNAME);
			webSessionInfo.setDeafultCalendar(sDefaultCalendar);

			String sBaseCurrency = (String) hmData.get(COLUMN_BANKS_CURRENCY);
			webSessionInfo.setBaseCurrency(sBaseCurrency);

			String sBusinessDate = (String) hmData.get(COLUMN_BANKS_BSNESSDATE);
			sBusinessDate = GlobalDateTimeUtil.getFormattedDateString(sBusinessDate, GlobalDateTimeUtil.STATIC_DATA_DATE_TIME,
					GlobalDateTimeUtil.DATE_FORMAT_US);
			webSessionInfo.setBusinessDate(sBusinessDate);
		}// EO if the additional data from banks load was successful

		// Gets default value date from CURRENCY_BU table.
		if (feedback.isSuccessful())
		{
			String sCurrency = webSessionInfo.getBaseCurrency();
			final DTOSingleValue dto = m_daoSecurity.getDefaultValueDateFromCURRENCY_BU(sCurrency, sOffice);

			feedback = dto.getFeedBack();

			if (feedback.isSuccessful())
			{
				String sValueDateOffset = dto.getValue();
				webSessionInfo.setValueDateOffset((sValueDateOffset == null ? null : Integer.valueOf(sValueDateOffset)));
			}
		}

		// Sets limit type and max amount.
		if (feedback.isSuccessful()) {
			feedback = setLimitTypeAndMaxAmountValues(userLoginData, webSessionInfo);
		}

		if (feedback.isSuccessful())
		{
			// store the websessionInfo instance in cache and in the current admin
			Admin.getContextAdmin().setWebSessionInfo(webSessionInfo);
			CacheKeys.WebSessionInfoKey.putSingle(webSessionInfo);
			logger.info("Set webssion into distributed cache for this login as:[{}]", webSessionInfo.getSessionID());		
		}

		// Failure during one of the previous steps.
		/*
		 * if(!feedback.isSuccessful()) { logger.error(GlobalUtils.getFeedbackString(feedback)); if(feedback.getException() !=
		 * null) {  logger.error(feedback.getException().getMessage());} }
		 */

		return feedback;
	}

	/**
	 * Updates the USERS table.
	 */
	private Feedback updateUSERS_TableForLogin(UserLoginData userLoginData)
	{
		String sUserID = userLoginData.getUserID();
		Feedback feedback = m_daoSecurity.updateUSERS_TableForLogin(sUserID);
		return feedback;
	}

	/**
	 * 
	 */
	private final Feedback setLimitTypeAndMaxAmountValues(UserLoginData userLoginData, final WebSessionInfo webSessionInfo)
	{
		final String MAX_PAYMENT_ALLOWED_UNLIMITED = "-1";

		Feedback feedback = new Feedback();
		
		String sUSERS_MAX_AMOUNT = userLoginData.getMaxAmount();
		boolean bZeroOrEmpty_USERS_MAX_AMOUNT =    sUSERS_MAX_AMOUNT.equals(ServerConstants.ZERO_VALUE)
		                                        || sUSERS_MAX_AMOUNT.equals(ServerConstants.EMPTY_STRING);
		webSessionInfo.setMaxPaymentAllowed(!bZeroOrEmpty_USERS_MAX_AMOUNT ? sUSERS_MAX_AMOUNT : MAX_PAYMENT_ALLOWED_UNLIMITED);
		
		String sUSERS_MAX_AMOUNT_FORCE_NSF = userLoginData.getMaxAmountForceNSF();
		boolean bZeroOrEmpty_USERS_MAX_AMOUNT_FORCE_NSF =    sUSERS_MAX_AMOUNT_FORCE_NSF.equals(ServerConstants.ZERO_VALUE)
		                                                  || sUSERS_MAX_AMOUNT_FORCE_NSF.equals(ServerConstants.EMPTY_STRING);
		webSessionInfo.setMaxAmountForceNSF(!bZeroOrEmpty_USERS_MAX_AMOUNT_FORCE_NSF ? sUSERS_MAX_AMOUNT_FORCE_NSF : MAX_PAYMENT_ALLOWED_UNLIMITED);

		return feedback;
	}

	/**
	 * Sets the passed UserLoginData object with department data.
	 */
	protected void setDepartmentData(UserLoginData userLoginData, String sPERM_PROF_DEPARTMENT, String[] sORIG_PERM_PROF_DEPARTMENT_SHOW)
	{
		final String COLUMN_DEPARTMENTCODE = "DEPARTMENTCODE";
		final String ALL = "1";
		

		DTODataHolder dtoDepartmentData = m_daoSecurity.getDepartmentData(sPERM_PROF_DEPARTMENT);
		ArrayList alDepartmentData = dtoDepartmentData.getDataAL();
		int iSize = alDepartmentData.size();
		HashMap departments = new HashMap();
		//add all department names to HashMap
		for(String dep : sORIG_PERM_PROF_DEPARTMENT_SHOW) {
			departments.put(dep.substring(0,dep.indexOf('(')),dep);
		}
		HashMap onlyAllPremissionDep = new HashMap();
		for (int i = 0; i < iSize; i++)
		{
			HashMap hmCurrentRow = (HashMap) alDepartmentData.get(i);
			String sDepartmentCode = (String) hmCurrentRow.get(COLUMN_DEPARTMENTCODE);
			String  foundDepartment = (String)departments.get(sDepartmentCode);
			if(foundDepartment != null) {
				String isALL = foundDepartment.substring(foundDepartment.indexOf('(')+1, foundDepartment.indexOf(')'));
				if(isALL.equals(ALL)) {
					onlyAllPremissionDep.put(sDepartmentCode,sDepartmentCode);
				}
			}
		}
		Feedback feedback = dtoDepartmentData.getFeedBack();

		if (feedback.isSuccessful())
		{
			userLoginData.setDepartmentData(getDepartmentDataMatrix(dtoDepartmentData.getDataAL(), userLoginData.getDefaultOffice(),onlyAllPremissionDep));
		}

		else
		{
			logger.error(GlobalUtils.getFeedbackString(feedback));
		}

		
	}

	/**
	 * Returns department data matrix.
	 */
	private Object[][] getDepartmentDataMatrix(ArrayList alDepartmentData, String sDefaultOffice,HashMap OnlyAllPremisionDep)
	{
		final String COLUMN_OFFICE = "OFFICE";
		final String COLUMN_NCC = "NCC";
		final String COLUMN_DEPARTMENTCODE = "DEPARTMENTCODE";
		final String COLUMN_CUST_CODE = "CUST_CODE";
		final String COLUMN_SWIFT_ID = "SWIFT_ID";
		final String COLUMN_DESCRIPTION = "DESCRIPTION";
		final String ALL = "1";
		final String READ_ONLY = "0";

		Object[][] arrDepartmentData = new Object[0][0];

		if (!alDepartmentData.isEmpty())
		{
			String sDefaultOfficeBusinessDate = null;
			Banks banks = CacheKeys.banksKey.getSingle(sDefaultOffice);
			if (banks != null && banks.getBsnessdate() != null) 
			{
				sDefaultOfficeBusinessDate = GlobalDateTimeUtil.dateToStaticDataString(banks.getBsnessdate());
			}

			int iSize = alDepartmentData.size();
			arrDepartmentData = new Object[iSize][8];

			for (int i = 0; i < iSize; i++)
			{
				HashMap hmCurrentRow = (HashMap) alDepartmentData.get(i);

				String sOffice = (String) hmCurrentRow.get(COLUMN_OFFICE);
				arrDepartmentData[i][0] = sOffice;

				String sNCC = (String) hmCurrentRow.get(COLUMN_NCC);
				arrDepartmentData[i][1] = sNCC;

				String sDepartmentCode = (String) hmCurrentRow.get(COLUMN_DEPARTMENTCODE);
				arrDepartmentData[i][2] = sDepartmentCode;
				//add 0/1 to combo data
				if(OnlyAllPremisionDep.get(sDepartmentCode) != null) {
					arrDepartmentData[i][7] = ALL;
				}
				else
				{
					arrDepartmentData[i][7] = READ_ONLY;
				}
				String sCustCode = (String) hmCurrentRow.get(COLUMN_CUST_CODE);
				arrDepartmentData[i][3] = sCustCode;

				String sDefBusinessDate = null;
				banks = CacheKeys.banksKey.getSingle(sOffice);
				if (banks != null && banks.getBsnessdate() != null)
				{
					sDefBusinessDate = GlobalDateTimeUtil.dateToStaticDataString(banks.getBsnessdate());
				}
				else
				{
					sDefBusinessDate = sDefaultOfficeBusinessDate;
				}
				arrDepartmentData[i][4] = sDefBusinessDate;
				
		                String sBic = (String) hmCurrentRow.get(COLUMN_SWIFT_ID);
		                arrDepartmentData[i][5] = sBic;
		                
                String sDepartmentDesc = (String) hmCurrentRow.get(COLUMN_DESCRIPTION);
                arrDepartmentData[i][6] = sDepartmentDesc;
				
				
			}

			arrDepartmentData = GlobalUtils.flipMatrix(arrDepartmentData);
		}

		return arrDepartmentData;
	}

	/**
	 * Prepares the static data profiles' preferences data matrix.
	 */
	
	/**
	 * Sets the default business date.
	 */
	protected void setDefaultBusinessDate(UserLoginData userLoginData)
	{
		DTOSingleValue dtoSingleValue = m_daoSecurity.getDefaultBusinessDate(userLoginData.getDefaultOffice());

		Feedback feedback = dtoSingleValue.getFeedBack();

		if (feedback.isSuccessful()) {
			userLoginData.setDefaultBusinessDate(dtoSingleValue.getValue());
		} else {
			logger.error(GlobalUtils.getFeedbackString(feedback));
		}
	}


	// ///////////////////////////////////////
	// ///////// END LOGIN METHODS ///////////
	// ///////////////////////////////////////

	// ///////////////////////////////////////
	// /////// START LOGOUT METHODS //////////
	// ///////////////////////////////////////

	/**
	 * Handles user logout.
	 */
	@SkipInputValidation
	@AuthorizeUser(returnWebSessionInfo = true)
	public SimpleResponseDataComponent logout()
	{
		SimpleResponseDataComponent response = new SimpleResponseDataComponent();

		UserTransaction[] arrTransactionHolder = new UserTransaction[1];
		Feedback feedback = startTransaction(arrTransactionHolder);

		// Successful transaction opening.
		if (feedback.isSuccessful()) {
			response = doLogout(arrTransactionHolder);
		}

		// Failure transaction opening.
		else {
			response.setFeedback(feedback);
		}

		return response;
	}

	/**
	 * Performs logout. Note: user authorization is performed in the interface method
	 */
	private SimpleResponseDataComponent doLogout(UserTransaction[] arrTransactionHolder)
	{
		boolean bSuccessfullLogoutProcess=false;
		SimpleResponseDataComponent response = new SimpleResponseDataComponent();
		try
		{
	
			String sUserID = ServerConstants.EMPTY_STRING;

		Feedback feedback = new Feedback();
		final WebSessionInfo webSessionInfo = Admin.getContextAdmin().getWebSessionInfo();

		// Got back actual WebSessionInfo object.
		if (webSessionInfo != null)
		{
			sUserID = webSessionInfo.getUserID();

			// Update USERS table; sets the user as logged out. ( this functionality is still required
			// for the Users profile select list using the the logged_in creiteria (admin viewing all logged in users))
			feedback = m_daoSecurity.updateUSERS_TableForLogout(sUserID);

			if (feedback.isSuccessful())
			{
				removeMessagesLock(webSessionInfo);
				// update the webSessionInfo instance and remove it from the distribued cache
				CacheKeys.WebSessionInfoKey.removeSingle(webSessionInfo);

				// TODO: clean all the locks using caches
				// Cleans locked records by this user ID.
				cleanUserIDExistingLockRecords(sUserID);

				// Logout message.
				String sLogoutDate = m_daoSecurity.getFormattedSystemDateFromDatabase(null, GlobalDateTimeUtil.STATIC_DATA_DATE_TIME);
				BindingParameter[] arrBindingParameters = new BindingParameter[] { new BindingParameter(sUserID, DataType.STRING),
						new BindingParameter(sLogoutDate, DataType.DATE_TIME) };
				String sOffice = webSessionInfo.getDefaultOffice();
				String sLogoutMessage = ErrorAuditUtils.loadErrorAuditText((long) ProcessErrorConstants.LogoutMessage, sOffice, arrBindingParameters);
				logger.trace(sLogoutMessage);

				// Writes audit into ACTIVITY_AUDIT table.
				updateACTIVITY_AUDIT_Table(false, null, sUserID, sOffice, sLogoutDate);
			}
		}

		// No actual WebSessionInfo object.
		else
		{
			final String ERROR_MESSAGE = "User is NOT logged in";

			feedback.setFailure();
			feedback.setErrorCode(ERROR_CODE_GENERAL);
			feedback.setErrorText(ERROR_MESSAGE);
			feedback.setUserErrorText(ERROR_MESSAGE);
			response.setFeedback(feedback);

			logger.error(ERROR_MESSAGE);
		}
	
			bSuccessfullLogoutProcess = response.getFeedback().isSuccessful();
		}
		catch(Throwable e)
		{
			logger.error("doLogout",e);
		}
		finally
		{
			// Transaction commit/rollback.
			Feedback fbTransaction = endTransaction(arrTransactionHolder[0], bSuccessfullLogoutProcess);
			if (!fbTransaction.isSuccessful())
			{
				response.setFeedback(fbTransaction);
			}
		}

		

		return response;
	}

	private void removeMessagesLock(final WebSessionInfo webSessionInfo)
	{
		if (webSessionInfo != null)
		{
			List<String> mids = webSessionInfo.getMids();
			List<PDO> pdos = new ArrayList<PDO>();
			PDO pdo;
			for (String mid : mids) {
				pdo = PaymentDataFactory.newPDO();
				pdo.setMID(mid);
				pdo.setOwnerContextId(webSessionInfo.getSessionID());
				pdo.setThinMode(true);
				pdos.add(pdo);
			}
			
			try 
			{
				CacheKeys.ProcessPDOKey.removeFromLocalAndPropagateToRemote(pdos);
			} 
			catch (CacheException e)
			{
				ExceptionController.getInstance().handleException(e, null);
			}
		}
	}

	// ////////////////////////////////////////
	// ///////// END LOGOUT METHODS ///////////
	// ////////////////////////////////////////


	/**
	 * Returns the session data for one user
	 */
	@AuthorizeUser(returnWebSessionInfo = true)
	public SimpleResponseDataComponent getOneUserSessionData()
	{
		SimpleResponseDataComponent response = new SimpleResponseDataComponent();

		final WebSessionInfo webSessionInfo = Admin.getContextAdmin().getWebSessionInfo();

		boolean bEmptyUserEntitlementName = false;
		boolean bNoDataForUserEntitlementName = false;
		boolean bSessionViolation = false;

		String sUserEntitlementName = null;

		Feedback feedback = new Feedback();

		// Got back actual WebSessionInfo object
		if (webSessionInfo != null)
		{
			sUserEntitlementName = webSessionInfo.getUEntName();

			if (!sUserEntitlementName.equals(ServerConstants.EMPTY_STRING))
			{
				UserEntitlementData userEntitlementData = EntitlementsDataFactory.getInstance().getUserEntitlementData(sUserEntitlementName);

				// There is actual data for this entitlement name.
				if (userEntitlementData != null)
				{
					UserSession userSession = new UserSession(userEntitlementData.getORIG_PERM_PROF_QUEUE(), userEntitlementData
							.getORIG_PERM_PROF_ALERTS(), userEntitlementData.getORIG_PERM_PROF_OFFICE(), userEntitlementData.getOffice(),
							userEntitlementData.getORIG_PERM_PROF_ACCESS(), userEntitlementData.getAccessProfileName());

					// Updates returned value.
					response.setDataArray(new Object[] { userSession });
				}

				else
				{
					bNoDataForUserEntitlementName = true;
				}
			}

			// Empty user entitlement name.
			else
			{
				bEmptyUserEntitlementName = true;
			}
		}

		// No actual WebSessionInfo object; i.e. this user isn't logged in.
		else
		{
			bSessionViolation = true;
		}
		// Some failure.
		if (bNoDataForUserEntitlementName || bEmptyUserEntitlementName || bSessionViolation)
		{
			String sErrorMessage = null;

			if (bNoDataForUserEntitlementName)
			{
				sErrorMessage = new StringBuffer(ERROR_MESSAGE_NO_DATA_FOR_USER_ENT_NAME).append(sUserEntitlementName).toString();
			}
			else if (bEmptyUserEntitlementName)
			{
				sErrorMessage = ERROR_MESSAGE_EMPTY_USER_ENT_NAME;
			}
			else
			// bSessionViolation
			{
				sErrorMessage = ERROR_MESSAGE_SESSION_VIOLATION;
			}

			feedback.setFailure();
			feedback.setErrorCode(ERROR_CODE_GENERAL);
			feedback.setErrorText(sErrorMessage);
			feedback.setUserErrorText(sErrorMessage);
			response.setFeedback(feedback);

			logger.error(sErrorMessage);
		}

		return response;
	}

	@AuthorizeUser(returnWebSessionInfo = true)
	public SimpleResponseDataComponent keepUserAlive()
	{
		final SimpleResponseDataComponent response = new SimpleResponseDataComponent();
		Feedback feedback = response.getFeedback();

		final WebSessionInfo webSessionInfo = Admin.getContextAdmin().getWebSessionInfo();

		// No actual WebSessionInfo object; i.e. this user isn't logged in.
		if (webSessionInfo == null)
		{
			feedback.setFailure();
			feedback.setErrorCode(ERROR_CODE_SESSION_VIOLATION);
			feedback.setErrorText(ERROR_MESSAGE_SESSION_VIOLATION);
			feedback.setUserErrorText(ERROR_MESSAGE_SESSION_VIOLATION);
			response.setFeedback(feedback);
		}// EOM

		return response;

	}// EOM

	/**
   * 
   */
	public SimpleResponseDataComponent changePassword(PasswordDetails passwordDetails,
													  Boolean bEventChangePasswordAtLogin ) {
  
		SimpleResponseDataComponent response = new SimpleResponseDataComponent();

		UserTransaction[] arrTransactionHolder = new UserTransaction[1];
		Feedback feedback = startTransaction(arrTransactionHolder);
		boolean bCommitTransaction=false;
		// Successfull transaction opening.
		if (feedback.isSuccessful()) 
		{
			try
			{
				if (!bEventChangePasswordAtLogin) {
					this.isUserAuthorized(feedback);
				}// EO if the event was triggered prior to logging in
	
				if (feedback.isSuccessful()) {
					final Admin admin = Admin.getContextAdmin();
					feedback = performChangePassword(admin.getSessionID(), passwordDetails.getUsername(),
							passwordDetails.getOldPassword(), passwordDetails.getNewPassword(), passwordDetails.getConfirmedPassword());
				}
	
				response.setFeedback(feedback);
	
				bCommitTransaction = feedback.isSuccessful();
			}
			catch(Throwable e)
			{
				logger.error("changePassword",e);
			feedback.setFailure();
			feedback.setErrorCode(ERROR_CODE_GENERAL);
			feedback.setErrorText(e.getMessage());
			}
			finally
			{
				// Transaction commit/rollback.
				Feedback fbTransaction = endTransaction(arrTransactionHolder[0], bCommitTransaction);
				if (!fbTransaction.isSuccessful()) {
					response.setFeedback(fbTransaction);
				}
			}
		}

		// Failure transcation opening.
		else {
			response.setFeedback(feedback);
		}

		return response;
	}

	/**
	 * this function check if password is valid and change his password in DB
	 */
	private Feedback performChangePassword(String sSessionId, String sUserID, String sOldPassword, String sNewPassword, String sNewPasswordConfirm)
	{
		Feedback feedback = new Feedback();

		feedback = validateChangePasswordRequestParams(sSessionId, sUserID, sOldPassword, sNewPassword, sNewPasswordConfirm);

		if (feedback.isSuccessful()) {
			feedback = validatePasswordChangesToday(sSessionId, sUserID);
		}
		if (feedback.isSuccessful()) {
			feedback = validateNewPasswordProperties(sSessionId, sUserID, sNewPassword);
		}
		if (feedback.isSuccessful()) {
			feedback = checkValidPassword(sSessionId, sUserID, sNewPassword);
		}
		if (feedback.isSuccessful()) {
			feedback = updateDBRecordsForChangePassword(sSessionId, sUserID, sNewPassword);
		}

		return feedback;
	}

	/**
	 * Validates the change password request parameters.
	 */
	private Feedback validateChangePasswordRequestParams(String sSessionId, String sUserID, 
														 String sOldPassword, 
														 String sNewPassword, String sNewPasswordConfirm)
	{
		Feedback feedback = new Feedback();

		if (feedback.isSuccessful()) {
			if (sUserID.length() == 0) {
				configureErrorFeedback(ERROR_CODE_GENERAL, ERROR_MESSAGE_EMPTY_USERNAME, feedback);
			}
		}
		if (feedback.isSuccessful()) {
			if (sOldPassword.length() == 0) {
				configureErrorFeedback(ERROR_CODE_GENERAL, ERROR_MESSAGE_EMPTY_OLDPASSWORD, feedback);
			}
		}
		if (feedback.isSuccessful()) {
			if (sNewPassword.length() == 0)	{
				configureErrorFeedback(ERROR_CODE_GENERAL, ERROR_MESSAGE_EMPTY_USER_PASSWORD, feedback);
			}
		}
		if (feedback.isSuccessful()) {
			if (sNewPassword.equals(sOldPassword)) {
				configureErrorFeedback(ERROR_CODE_GENERAL, ERROR_MESSAGE_NEW_PASSWORD_EQUAL_OLD_PASSWORD, feedback);
			}
		}
		if (feedback.isSuccessful()) {
			if (!sNewPassword.equals(sNewPasswordConfirm)) {
				configureErrorFeedback(ERROR_CODE_GENERAL, ERROR_MESSAGE_WRONG_USER_PASSWORD_CONFIRM, feedback);
			}
		}

		// Stands for the password in the database.
		String sUSERPASSWD = null;

		if (feedback.isSuccessful())
		{
			boolean[] arrInvalidUserID = new boolean[1];
			DTODataHolder dtoUsers = getUserProfile(sUserID, arrInvalidUserID);
			feedback = dtoUsers.getFeedBack();

			sUSERPASSWD = dtoUsers.getColumnData(COLUMN_USERS_USERPASSWD);

			if (sUSERPASSWD.length() == 0) {
				String sMsgError = ERROR_MESSAGE_EMPTY_DB_PASSWORD.replaceFirst(GlobalConstants.PERCENTAGE_SIGN, sUserID);
				configureErrorFeedback(ERROR_CODE_GENERAL, sMsgError, feedback);
			}
		}

		if (feedback.isSuccessful()) {
			if (!sUSERPASSWD.equals(getEncryptedPassword(sOldPassword))) {
				configureErrorFeedback(ERROR_CODE_GENERAL, ERROR_MESSAGE_WRONG_PASSWORD, feedback);
			}
		}
		return feedback;
	}

	/**
	 * Updates USERS and OLDPSWDS tables with appropriate values.
	 */
	private Feedback updateDBRecordsForChangePassword(String sSessionId, String sUserID, String sNewPassword)
	{
		String sPasswordDate = m_daoSecurity.getFormattedSystemDateFromDatabase(null, GlobalDateTimeUtil.STATIC_DATA_DATE);
		String sPasswordTime = m_daoSecurity.getSystemTimeFromDatabase();

		String sEncryptedPassword = getEncryptedPassword(sNewPassword);
		Feedback feedback = m_daoSecurity.updateOLDPSWDS_Table(sUserID, sEncryptedPassword, sPasswordDate, sPasswordTime);

		if (feedback.isSuccessful()) 
		{
			String sTempPassword = GlobalConstants.ZERO_VALUE;
			feedback = m_daoSecurity.updateUSERS_TableForChangePassword(sUserID, sEncryptedPassword, sPasswordDate, sPasswordTime, sTempPassword);
		}

		return feedback;
	}

	/**
	 * Check password validation like password with no blanks and password not as user id and doesn't have more than 2 sequence chars.
	 */
	private Feedback checkValidPassword(String sSessionId, String sUserID, String sNewPassword)
	{
		Feedback feedback = validateNewPasswordAgainstOldPasswords(sSessionId, sUserID, sNewPassword);

		if (feedback.isSuccessful()) {
			if (sNewPassword.toUpperCase().equals(sUserID)) {
				configureErrorFeedback(ERROR_CODE_GENERAL, ERROR_MESSAGE_PASSWD_EQUAL_USERID, feedback);
			}
		}

		if (feedback.isSuccessful()) {
			if (!sNewPassword.trim().equals(sNewPassword)) {
				configureErrorFeedback(ERROR_CODE_GENERAL, ERROR_MESSAGE_PASSWD_HAS_BLANKS, feedback);
			}
		}

		// Check if the new password has more than 2 sequence chars.
		if (feedback.isSuccessful())
		{
			int iSeqChars = 1;
			char cLastChar = sNewPassword.charAt(0);

			for (int iCounter = 1; iCounter < sNewPassword.length(); iCounter++)
			{
				char cCurrentChar = sNewPassword.charAt(iCounter);
				if (cCurrentChar == cLastChar) {
					iSeqChars++;
				} else {
					iSeqChars = 1;
				}

				cLastChar = cCurrentChar;

				if (iSeqChars == 3) {
					configureErrorFeedback(ERROR_CODE_GENERAL, ERROR_MESSAGE_PASSWD_HAS_IDENTICAL_CHARACTERS, feedback);
					break;
				}
			}
		}

		return feedback;
	}

	/**
	 * Validates the new password against the old passwords in OLDPSWDS table.
	 */
	private Feedback validateNewPasswordAgainstOldPasswords(String sSessionId, String sUserID, String sNewPassword)
	{
		Feedback feedback = new Feedback();

		String sEncryptedNewPassword = getEncryptedPassword(sNewPassword);
		DTODataHolder dtoOLDPSWDS_Data = m_daoSecurity.get_OLDPSWDS_Data(sUserID);

		String sOffice = null;
		DTODataHolder dtoUsers = null;

		// Gets the user's data.
		if (feedback.isSuccessful())
		{
			boolean[] arrInvalidUserID = new boolean[1];
			dtoUsers = getUserProfile(sUserID, arrInvalidUserID);
			feedback = dtoUsers.getFeedBack();
		}

		// Deletes old passwords in case there are more than defined number in the NUMOLDPASS system parameter.
		if (feedback.isSuccessful())
		{
			// Gets user's office.
			sOffice = dtoUsers.getColumnData(COLUMN_USERS_OFFICE);

			int iNumOfExistingOldPasswords = dtoOLDPSWDS_Data.getRowsNumber();
			String sNUMOLDPASS = SystParKey.getSingleParmValue(sOffice, SystemParametersInterface.SYS_PAR_NUMOLDPASS);

			if (isNullOrEmpty(sNUMOLDPASS) || sNUMOLDPASS.equals(GlobalConstants.ZERO_VALUE)) {
				sNUMOLDPASS = DEFAULT_NUM_OLD_PASS;
			}

			int iNumOfPasswordsToRemove = iNumOfExistingOldPasswords - Integer.parseInt(sNUMOLDPASS) + 1;

			if (iNumOfPasswordsToRemove > 0)
			{
				String sPASSWDDATE, sPASSWDTIME;

				for (int i = 0; i < iNumOfPasswordsToRemove; i++) {
					sPASSWDDATE = dtoOLDPSWDS_Data.getColumnDataByRow(COLUMN_OLDPSWDS_PASSWDDATE, i);
					sPASSWDTIME = dtoOLDPSWDS_Data.getColumnDataByRow(COLUMN_OLDPSWDS_PASSWDTIME, i);

					feedback = m_daoSecurity.deleteOldPasswordsFromOLDPSWDS_Table(sUserID, sPASSWDDATE, sPASSWDTIME);
				}
			}
		}

		// Checks if the new passsword equals to old password.
		if (feedback.isSuccessful()) {
			String sPasswordDB = dtoUsers.getColumnData(COLUMN_USERS_USERPASSWD);

			if (sPasswordDB.equals(sEncryptedNewPassword)) {
				configureErrorFeedback(ERROR_CODE_GENERAL, ERROR_MESSAGE_PASSWD_ALREADY_USED, feedback);
			}
		}

		// Checks if the new passsword exists in OLDPSWDS table.
		if (feedback.isSuccessful())
		{
			DTOBoolean dtoPasswordExists = m_daoSecurity.doesPasswordExistInOLDPSWDS_Table(sUserID, sEncryptedNewPassword);
			feedback = dtoPasswordExists.getFeedBack();

			if (feedback.isSuccessful()) {
				if (dtoPasswordExists.getValue()) {
					configureErrorFeedback(ERROR_CODE_GENERAL, ERROR_MESSAGE_PASSWD_ALREADY_USED, feedback);
				}
			}
		}
		return feedback;
	}

	/**
	 * Validates that user can change the password today.
	 */
	private Feedback validatePasswordChangesToday(String sSessionId, String sUserID)
	{
		boolean[] arrInvalidUserID = new boolean[1];
		DTODataHolder dtoUsers = getUserProfile(sUserID, arrInvalidUserID);

		Feedback feedback = dtoUsers.getFeedBack();

		// Success.
		if (feedback.isSuccessful())
		{
			String sOffice = dtoUsers.getColumnData(COLUMN_USERS_OFFICE);

			String sNumPassPerDay = SystParKey.getSingleParmValue(sOffice, SystemParametersInterface.SYS_PAR_NUMPSWDDAY);

			if (isNullOrEmpty(sNumPassPerDay) || sNumPassPerDay.equals(UNLIMITED_PASSWD_CHANGES_DAY))
			{
				final String strUnlimitedPasswdChanges = "Value of NUMPSWDDAY system parameter allows unlimited number of password changes per day !!!";
				logger.warn(strUnlimitedPasswdChanges);
			}

			else
			{
				DTOSingleValue dto = m_daoSecurity.getNumUserPasswordsChangesToday(sUserID);
				feedback = dto.getFeedBack();

				if (feedback.isSuccessful()) {
					int iNumUserPasswordChangesToday = Integer.parseInt(dto.getValue());
					if (iNumUserPasswordChangesToday >= Integer.parseInt(sNumPassPerDay)) {
						configureErrorFeedback(ERROR_CODE_GENERAL, ERROR_MESSAGE_EXCEED_LIMIT_PASSWD_CHANGES, feedback);
					}
				}
			}
		}

		return feedback;
	}

	/**
	 * Validates new password properties like length and num of digits/letters.
	 */
	private Feedback validateNewPasswordProperties(String sSessionId, String sUserID, String sNewPassword)
	{
		boolean[] arrInvalidUserID = new boolean[1];
		DTODataHolder dtoUsers = getUserProfile(sUserID, arrInvalidUserID);
		Feedback feedback = dtoUsers.getFeedBack();

		if (feedback.isSuccessful())
		{
			// Gets user's office.
			String sOffice = dtoUsers.getColumnData(COLUMN_USERS_OFFICE);

			// Gets all related system parameters.
			String sMaxPasswordLen = SystParKey.getSingleParmValue(sOffice, SystemParametersInterface.SYS_PAR_MAXPASSLEN);
			int iMaxPasswordLen = isNullOrEmpty(sMaxPasswordLen) ? DEFAULT_MAX_PASSWORD_LEN : Integer.valueOf(sMaxPasswordLen).intValue();
			//
			String sMinPasswordChars = SystParKey.getSingleParmValue(sOffice, SystemParametersInterface.SYS_PAR_MINPASSCHR);
			int iMinPasswordChars = isNullOrEmpty(sMinPasswordChars) ? DEFAULT_MIN_PASSWD_CHAR : Integer.valueOf(sMinPasswordChars).intValue();
			//
			String sMinPasswordDigits = SystParKey.getSingleParmValue(sOffice, SystemParametersInterface.SYS_PAR_MINPASSDIG);
			int iMinPasswordDigits = isNullOrEmpty(sMinPasswordDigits) ? DEFAULT_MIN_PASSWD_DIGIT : Integer.valueOf(sMinPasswordDigits).intValue();
			//
			int iMinPasswordLen = iMinPasswordChars + iMinPasswordDigits;

			// Checks min length of the new password.
			if (sNewPassword.length() < iMinPasswordLen)
			{
				configureErrorFeedback(ERROR_CODE_GENERAL, String.format(ERROR_MESSAGE_MIN_PASSWD_LEN, iMinPasswordLen), feedback);
			}

			// Checks max length of new password.
			else if (sNewPassword.length() > iMaxPasswordLen)
			{
				configureErrorFeedback(ERROR_CODE_GENERAL, String.format(ERROR_MESSAGE_MAX_PASSWD_LEN, iMaxPasswordLen), feedback);
			}

			// Checks min digits and letters in the new password.
			else
			{
				int iNumDigits = 0, iNumLetters = 0;

				int iPassLength = sNewPassword.length();
				for (int iCounter = 0; iCounter < iPassLength; iCounter++)
				{
					if (Character.isDigit(sNewPassword.charAt(iCounter))) {
						iNumDigits++;
					} else if (Character.isLetter(sNewPassword.charAt(iCounter))) {
						iNumLetters++;
					}
				}

				if (iNumDigits < iMinPasswordDigits) {
					configureErrorFeedback(ERROR_CODE_GENERAL, String.format(ERROR_MESSAGE_MIN_PASSWD_DIGIT, iMinPasswordDigits), feedback);
				}  else if (iNumLetters < iMinPasswordChars) {
					configureErrorFeedback(ERROR_CODE_GENERAL, String.format(ERROR_MESSAGE_MIN_PASSWD_CHAR, iMinPasswordChars), feedback);
				}
			}
		}

		return feedback;
	}
	
	  /**
	 * Checks if SSO user is already logged in, if yes clean its session.
	 */
	protected void checkUserLoggedInSSO(String sUserID, UserLoginData userLoginData, Feedback feedback) {
		final String TRACE_MESSAGE = "The user is currently logged in. SSO login's previous user session will be cleaned";

		final WebSessionInfo webSessionInfo = CacheKeys.UserWebSessionInfoKey.getSingle(sUserID);

		// User is already logged in from another machine or browser.
		if (webSessionInfo != null){
			CacheKeys.UserWebSessionInfoKey.removeSingle(sUserID);
			logger.info(TRACE_MESSAGE);
		}//EO if the user was already logged in
	}
	
}
