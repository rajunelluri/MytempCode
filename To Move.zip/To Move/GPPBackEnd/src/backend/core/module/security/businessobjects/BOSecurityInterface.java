package backend.core.module.security.businessobjects;

import com.fundtech.core.security.Admin;
import com.fundtech.datacomponent.response.Feedback;

/**
 * internal interface for BOSecurity.
 */
public interface BOSecurityInterface{

	
	
	/** 
	 * Cleans the WEB_PROFILE_LOCK table from records with this user ID. 
	 * TODO: 1. remove all the pdos from the local regions and release their respective locks in the remote regions
	 */
	public void cleanUserIDExistingLockRecords(final Admin admin, java.lang.String sUserID ) ;
	
	/**
	 * Validate password for reset password flow and create new user flow
	 * @param sSessionId
	 * @param sUserID
	 * @param sNewPassword
	 * @param sNewPasswordConfirm
	 * @param newUser true for new user, false for reset password for existing user
	 * @return
	 */
	public Feedback validatePasswordForNewUserAndReset(String sSessionId, String sUserID, String sNewPassword, String sNewPasswordConfirm, boolean newUser);
	
}//EOI  