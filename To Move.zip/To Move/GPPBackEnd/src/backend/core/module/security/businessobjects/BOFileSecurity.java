package backend.core.module.security.businessobjects;

import com.fundtech.cache.entities.WebSessionInfo;
import com.fundtech.cache.infrastructure.regions.CacheKeys;
import com.fundtech.core.security.Admin;
import com.fundtech.core.security.Admin.CallSource;
import com.fundtech.datacomponent.request.UserCredentials;
import com.fundtech.datacomponent.response.Feedback;
import com.fundtech.datacomponent.response.SimpleResponseDataComponent;
import com.fundtech.errors.ProcessErrorConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import backend.dataaccess.dto.DTOBoolean;
import backend.services.cache.entitlements.EntitlementsDataFactory;

public class BOFileSecurity extends BOWebServiceSecurity 
{

	private final static Logger logger = LoggerFactory.getLogger(BOFileSecurity.class);

	@Override
	public SimpleResponseDataComponent login(UserCredentials userCredentials) 
	{
		SimpleResponseDataComponent response = new SimpleResponseDataComponent();
		Feedback feedback = response.getFeedback() ;   
		String auditUserID = userCredentials.getUserName();
		DTOBoolean dtoBool = m_daoSecurity.isUserInDB(auditUserID);
		feedback = dtoBool.getFeedBack();
		WebSessionInfo webSessionInfo = new WebSessionInfo(auditUserID);
		String role = userCredentials.getAdditionalParamValue(UserCredentials.KEY_ROLE_NAME);
		webSessionInfo.setUEntName(role);
		if (feedback.isSuccessful()) 
		{
			if (dtoBool.getValue()) 
			{					
				this.setFailure(response, feedback, ProcessErrorConstants.WsLoginFailure, "audit user must not exist in DB");
			}else
			{
				logger.debug("BOWebServiceSecurity - audit user doesn't exists in DB");
				
				webSessionInfo = CacheKeys.WebSessionInfoKey.getAndPut(new CreateAuditUserCahceValue(webSessionInfo), auditUserID);
//				Change the call source to file in order to ignore permission check for message submit service
				Admin.getContextAdmin().setCallSource(CallSource.File);
				if (webSessionInfo != null) {
					Admin.getContextAdmin().setWebSessionInfo(webSessionInfo);
					 UserEntitlementData userEntitlementData = 
					    	EntitlementsDataFactory.getInstance().getUserEntitlementData(role) ;
					 
					 if (userEntitlementData == null) EntitlementsDataFactory.getInstance().refreshOneEntitlementDataObject(role, null);
				}else {
					setFailure(response, ProcessErrorConstants.WsLoginFailure, "after login - audit web session info is null after login!!!!");
				}
			}
		}
		
		return response;

	}
}
