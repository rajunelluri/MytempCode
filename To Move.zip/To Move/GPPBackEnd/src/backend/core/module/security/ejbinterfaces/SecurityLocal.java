package backend.core.module.security.ejbinterfaces;

import javax.ejb.Local;

/**
 * Local interface for Security.
 */
@Local
public interface SecurityLocal extends Security{} ; 