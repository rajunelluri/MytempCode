package backend.core;

import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.util.concurrent.atomic.AtomicBoolean;

import javax.jms.Message;

import com.fundtech.core.security.Admin;
import com.fundtech.core.security.Admin.CallSource;
import com.fundtech.util.ExceptionController;

import backend.businessobject.proxies.BOProxy;
import backend.businessobject.proxies.interceptors.InterceptorSetType;


public class SuperMDB<T> extends SuperSLSB<T>{

	private String m_sBaseContextID ; 
	private Method m_delegateOnMsgMethod ; 
	
	private final Class<?> m_boClassType ; 
	private final String m_sDelegateOnMessageMethodName ; 
	private final InterceptorSetType m_interceporSet ; 
	private final Class<T> m_primaryInterfaceToImplement ; 
	private final Class<T>[] m_arrInterfacesToImplement ; 
	
	private AtomicBoolean m_bDisposed = new AtomicBoolean(true) ; 
	
	public SuperMDB(final Class<?> boClassType, final String sDelegateOnMessageMethodName) {
		this(boClassType, sDelegateOnMessageMethodName, InterceptorSetType.Complete, null/*primaryInterfaceToImplement*/) ; 
	}//EOM
	
	public SuperMDB(final Class<?> boClassType, final String sDelegateOnMessageMethodName, final InterceptorSetType interceporSet, 
			final Class<T> primaryInterfaceToImplement, Class<T>...arrInterfacesToImplement) { 
		
		//super(boClassType, interceporSet, primaryInterfaceToImplement, arrInterfacesToImplement) ;
		
		//store the init params and use them for lazy initialization. 
		//this is required due to application initialization sequence mandating that most of the 
		//required resources are initialized after the constructor invocation of this class instances 
		this.m_boClassType = boClassType ; 
		this.m_sDelegateOnMessageMethodName = sDelegateOnMessageMethodName ; 
		this.m_interceporSet = interceporSet ; 
		this.m_primaryInterfaceToImplement = primaryInterfaceToImplement ; 
		this.m_arrInterfacesToImplement = arrInterfacesToImplement ; 

	}//EOM
	
	protected void init() {
		if(!this.m_bDisposed.get()) return ; 
				
		this.m_bo = BOProxy.wrap(this.m_boClassType, this.m_interceporSet, null/*init Params map*/,this.m_primaryInterfaceToImplement, 
				this.m_arrInterfacesToImplement) ;
		
		//cache the trace component id derived in the logging interceptor instance to be used as the context id in conjunction with the given 
		//thread id 
		this.m_sBaseContextID = this.getClass().getSimpleName(); 
		
		//cache the delegate's on message method (always passing the admin and the Message as a formal args) 
		try{ 
			final ParameterizedType subclassInterfaceType =  (ParameterizedType)  this.getClass().getGenericSuperclass()   ;
			final Class subClassInterfaceClass = (Class<T>) subclassInterfaceType.getActualTypeArguments()[0] ;
			this.m_delegateOnMsgMethod = subClassInterfaceClass.getDeclaredMethod(this.m_sDelegateOnMessageMethodName, Admin.class, Message.class) ;
		}catch(Exception e) { 
			ExceptionController.getInstance().handleException(e, this) ;
		}//EO catch block 
		
		this.m_bDisposed.set(false) ;  
	}//EOM 
	
	public void onMessage(final Message message) { 

		//first lazilly init the resources if not already initialized 
		if(this.m_bDisposed.get()) this.init() ; 
		
		try{ 
			//create an admin, set in the context and invoke the interceptor's before() 
			final Admin admin = this.invokeBefore(); 
			
			this.m_delegateOnMsgMethod.invoke( this.m_bo, admin, message) ; 
		}catch(Exception e) { 
			ExceptionController.getInstance().handleException(e, this) ;
		}finally{ 

		}//EO catch block 
		
	}//EOM 
	
	private final Admin invokeBefore() { 
		Admin admin = CallSource.System.newAdmin(this.m_sBaseContextID  + '_' + Thread.currentThread().getId()) ;
		
		try{ 
		}catch(Throwable t) { 
			ExceptionController.getInstance().handleException(t, this) ;
			admin = null ;
		}//EO catch block
		
		return admin ; 
	}//EOM 
	
	@Override
	protected void activate() {
		
		try{ 
			//create an admin, set in the context and invoke the interceptor's before() 
			this.invokeBefore(); 
			
			super.activate() ;
		}finally{ 
		}//EO catch block 
	}//EOM
	
	@Override
	protected void dispose() { 
		try{ 
			//create an admin, set in the context and invoke the interceptor's before() 
			this.invokeBefore(); 
			
			super.dispose() ;
		}finally{ 

		}//EO catch block 
	}//EOM 
}//EOM 
