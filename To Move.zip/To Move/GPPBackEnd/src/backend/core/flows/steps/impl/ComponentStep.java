package backend.core.flows.steps.impl;

import java.lang.reflect.Method;
import java.util.Map;

import backend.businessobject.proxies.BOProxy;

import com.fundtech.appServerConfigDefinition.FlowComponentType;
import com.fundtech.appServerConfigDefinition.FlowStepType;
import com.fundtech.core.general.flows.FlowException;
import com.fundtech.core.general.flows.steps.FlowStep;
import com.fundtech.core.general.flows.steps.impl.FlowContext;
import com.fundtech.core.security.Admin;

public class ComponentStep<T> extends FlowStep{

	private Class<T> m_clsInterfaceClass ;
	private String m_sImplClassName ; 
	private T m_componentInstance ; 
	private Method m_method ; 
	
	@SuppressWarnings("unchecked")
	public ComponentStep(final FlowStepType flowStepTypeXbean, final String sFlowId , final String sFlowHierarcyId, 
			final Map mapGlobalInitParams, final FlowContext context) throws FlowException {
		
		super(flowStepTypeXbean, sFlowId, sFlowHierarcyId, mapGlobalInitParams, context) ;
		
		final String sInterfaceName = ((FlowComponentType)flowStepTypeXbean).getInterfaceClass() ; 
		final String sMethodName = ((FlowComponentType)flowStepTypeXbean).getMethod() ; 
		this.m_sImplClassName = ((FlowComponentType)flowStepTypeXbean).getImplClass() ;
		
		try{ 
			final ClassLoader classLoader = Thread.currentThread().getContextClassLoader() ; 
			this.m_clsInterfaceClass = (Class<T>) classLoader.loadClass(sInterfaceName) ;
			final Class<?> implClass = classLoader.loadClass(this.m_sImplClassName) ; 
			this.m_componentInstance = BOProxy.completeDecoration(implClass, this.m_clsInterfaceClass) ;
			this.m_method = m_clsInterfaceClass.getMethod(sMethodName, Admin.class, String.class) ;
		}catch(Throwable t) { 
			this.dispose() ; 
			//throw new FlowException(this.getFlowId(), t) ;
		}//EO catch block 
		
	}//EOM 
	
	@Override
	protected Object doExecuteInner(final Object...args) throws Throwable {
		System.err.printf("Executing interface '%s' with Class '%s'%n", this.m_clsInterfaceClass.getName(), this.m_sImplClassName);
		Object oResponse = null ; 
		try{ 
			oResponse = this.m_method.invoke(this.m_componentInstance, Admin.getContextAdmin(), Admin.getContextPDO().getMID()) ;
		}catch(Throwable t) { 
			throw t ; 
		}//EO catch block 	
		
		return oResponse ; 
	}//EOM 
	
}//EOM  
