package backend.core.flows.steps.impl ; 

import java.util.List;
import java.util.Map;

import com.fundtech.appServerConfigDefinition.FlowIfRuleType;
import com.fundtech.appServerConfigDefinition.FlowStepType;
import com.fundtech.cache.entities.RuleResult;
import com.fundtech.core.general.flows.FlowException;
import com.fundtech.core.general.flows.steps.impl.Flow;
import com.fundtech.core.general.flows.steps.impl.FlowContext;
import com.fundtech.core.paymentprocess.data.PDO;
import com.fundtech.core.security.Admin;
import com.fundtech.util.GlobalUtils;

import backend.businessobject.BOProxies;
import backend.paymentprocess.ruleexecution.businessobjects.BORuleExecutionInterface;


public class FlowIfRuleStep extends Flow{
	
	private static BORuleExecutionInterface m_boRuleEngine ;

	private String m_sRuleTypeId ; 
	private String m_sRuleSubType ; 
	private String[] m_arrObjectIds ; 
	private String m_sExpectedResult ; 
	
	public FlowIfRuleStep(final FlowStepType flowStepTypeXbean, final String sFlowId , final String sFlowHierarcyId, 
			final Map mapGlobalInitParams, final FlowContext context) throws FlowException{
		super(flowStepTypeXbean, sFlowId, sFlowHierarcyId, mapGlobalInitParams, context) ;
		
		this.init( (FlowIfRuleType)flowStepTypeXbean) ; 
	}//EOM 
	
	private final void init(final FlowIfRuleType ruleStepXbean) { 
		
		this.m_sRuleTypeId = ruleStepXbean.getType() + "" ; 
		this.m_sRuleSubType = ruleStepXbean.getSubType() ;
		if(GlobalUtils.isNullOrEmpty(this.m_sRuleSubType)) this.m_sRuleSubType = "0" ;
		this.m_sExpectedResult = ruleStepXbean.getExpected() ; 
		
		this.m_arrObjectIds = ruleStepXbean.getObjects().split(",") ; 
		this.setStepId(String.format("%s('%s'=%s)", this.getStepId(), this.m_sRuleTypeId, this.m_sExpectedResult)) ;
	}//EOM 
	
	@Override
	protected List<RuleResult> doExecuteInner(final Object...args) throws Throwable {
		System.err.printf("Executing if Statement on rule '%s'%n", this.m_sRuleTypeId) ;
		
		try{ 
			if(m_boRuleEngine == null) m_boRuleEngine = BOProxies.m_internalRuleExecutionLogging ;  
			
			final PDO pdo = Admin.getContextPDO(); 
			final String sMID = pdo.getMID() ; 
			//first create the objects array by determining whether any element 
			//is in fact a logical field whose value should be retrieved from the context pdo 
			final int iLength = this.m_arrObjectIds.length ; 
			String[] arrInputObjectIDs = new String[iLength] ;
			
			String sObjectId = null, sLogicalFieldId = null ; 
			for(int i=0; i < iLength; i++) {
				sObjectId = this.m_arrObjectIds[i] ; 
				
				if(sObjectId.indexOf("@@") == -1) arrInputObjectIDs[i] = sObjectId ;
				else { 
					sLogicalFieldId = sObjectId.substring(2, sObjectId.length()-2) ;
					arrInputObjectIDs[i] = pdo.getString(sLogicalFieldId) ;
				}//EO else if logical field place holder 
			}//EO while there are more object ids to iterate over
			
			//finally, execute the rule 
			return  m_boRuleEngine.executeRule(Admin.getContextAdmin(),
					this.m_sRuleTypeId, this.m_sRuleSubType, sMID, arrInputObjectIDs).getResults();
		}catch(Throwable t) { 
			throw t ;
		}//EO catch block 
		
	}//EOM 
	
	@Override
	protected boolean shouldAbort(final Object exeuctionResult) {
		final List<RuleResult> ruleResults = (List<RuleResult> )  exeuctionResult ; 
		return ( ruleResults == null || ruleResults.isEmpty() || !ruleResults.get(0).getAction().equals(this.m_sExpectedResult) ) ;
	}//EOM
	
}//EOC 
