package backend.core.flows;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fundtech.appServerConfigDefinition.FlowType;
import com.fundtech.appServerConfigDefinition.FlowsType;
import com.fundtech.core.general.flows.FlowException;
import com.fundtech.core.general.flows.steps.impl.Flow;
import com.fundtech.core.general.flows.steps.impl.FlowContext;
import com.fundtech.mapping.AbstractConfigProxy;
import com.fundtech.mapping.ConfigFileModificationListener;

public class FlowController implements ConfigFileModificationListener {

	private final Map<String, Flow> m_mapFlows;
	private static FlowController instance ; 
	private final static Logger logger = LoggerFactory.getLogger(FlowController.class);
	private AtomicBoolean m_bDisposed = new AtomicBoolean(true);

	public static final FlowController getInstance() { return (instance == null ? (instance = new FlowController()) : instance) ; }// EOM

	private FlowController() {
		this.m_mapFlows = new HashMap<String, Flow>();

		AbstractConfigProxy.getInstance()
				.registerConfigurationModificationListener(this);
		this.onConfigFileModification();
	}// EOM

	@Override
	public void onConfigFileModification() {
		try {
			this.m_bDisposed.set(true);

			// first clear the flows if any exist
			this.reset();

			final FlowsType flows = AbstractConfigProxy.getInstance().getFlows();
			if (flows == null) return;

			final FlowContext context = new FlowContext();

			Flow flow = null;

			for (FlowType flowXbean : flows.getFlowArray()) {
				flow = new Flow(flowXbean, context);
				m_mapFlows.put(flow.getStepId(), flow);
			}// EO while there are more flows

			this.m_bDisposed.set(false);
		} catch (Throwable fe) {
			logger.error(fe.getMessage()); 
		}// EO catch block
	}// EOM

	public Object executeFlow(final String sFlowId, final Object... args)
			throws FlowException {
		if (this.m_bDisposed.get())
			throw new FlowException(
					"Flow Contoller is Disposed. Aborting flow exeuction");

		final Flow flow = this.m_mapFlows.get(sFlowId);
		if (flow == null)
			throw new FlowException("Flow %s is not defined", sFlowId);
		else
			return flow.execute(args);
	}// EOM

	public final void reset() {
		for (Flow flow : this.m_mapFlows.values()) {
			flow.dispose();
		}// EO while there are more flows

		this.m_mapFlows.clear();
	}// EOM

	@Override
	public final void dispose() {
		if (this.m_bDisposed.get()) return;
		// else
		this.reset();
		instance = null;
	}// EOM

	@Override
	public final boolean isDisposed() {
		return this.m_bDisposed.get();
	}// EOM

}// EOC
