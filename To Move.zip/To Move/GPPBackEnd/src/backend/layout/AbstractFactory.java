package backend.layout;

import java.util.ArrayList;
import java.util.HashMap;

import com.fundtech.core.general.DisposableInterface;
import com.fundtech.datacomponent.response.Feedback;

import backend.dataaccess.dto.DTODataHolder;
import backend.services.cache.ASCacheFactory;
import backend.util.ServerUtils;

/**
 * Title:        AbstractFactory
 * Description:  Abstract factory class all message related factory classes, (or
 *               for any other factory class that fits the class members)
 * Company:      Fundtech Israel
 * @author       Asaf Levy
 * @version      1.0 18/05/08
 */
public abstract class AbstractFactory implements DisposableInterface
{
  // This is the Feedback object that stands for the entire initialization process.
  protected static Feedback m_initializationFeedback;
  
  // For development mode.
  //protected static boolean m_bInRefreshProcessForDevelopmentMode = false;
  
  // For the DisposableInterface.
  protected boolean m_bIsDisposed;
    
  /**
   * Private constructor.
   */
  public AbstractFactory()
  {
    ASCacheFactory.m_setNonOrderedDisposables.add(this);
    initFactoryProcess(getRelatedDTOObject());
  }
  
  /**
   * Initializes all class members.
   */
  protected void initFactoryProcess(DTODataHolder dtoData)
  {
     m_initializationFeedback = dtoData.getFeedBack();
     
     // Initialization succeed.
     if(m_initializationFeedback.isSuccessful())
     {
       initializeClassMembers(dtoData.getDataAL());
     }
     
     // Initialization failure.
     else
     {
       ServerUtils.handleFeedback(m_initializationFeedback);
     }
  }
  
  /**
   * Returns the Feedback object that stands for the initialization process.
   * @return returns the Feedback object that stands for the initialization process.
   */
  public static Feedback getInitializationFeedback()
  {
    return m_initializationFeedback;
  }

  /**
   * DisposableInterface implementation.
   */
  public void dispose() 
  {
    m_bIsDisposed = true;
    disposeInstance();
  }
    
  /**
   * DisposableInterface implementation.
   */
  public boolean isDisposed()
  {
    return m_bIsDisposed;
  }
  
  protected abstract DTODataHolder getRelatedDTOObject();
  protected abstract void initializeClassMembers(ArrayList<HashMap> alData);
  protected abstract void disposeInstance();
}