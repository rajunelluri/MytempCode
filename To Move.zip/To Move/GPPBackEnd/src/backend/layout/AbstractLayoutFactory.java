package backend.layout;

import java.util.HashMap;

import com.fundtech.core.general.DisposableInterface;

import backend.services.cache.ASCacheFactory;

/**
 * Title:        AbstractLayoutFactory
 * Description:  Abstract class for all layout types in the application, (message, profiles etc).
 * Company:      Fundtech Israel
 * @author       Asaf Levy
 * @version      1.0 18/05/08
 */
public abstract class AbstractLayoutFactory implements DisposableInterface
{
  // Boolean that indicates whether this class' initialization was successful.
  // It is initialized to 'true' & in case of initialization failure, it will be
  // set to 'false'. 
  private boolean m_bIsSuccessfulInit = true;

  // For the DisposableInterface.
  private boolean m_bIsDisposed;
  
  /**
   * Constructor.
   */
  public AbstractLayoutFactory()
  {
    ASCacheFactory.m_setNonOrderedDisposables.add(this);
  }
  
  /**
   * Returns whether the initialization of this class was successful.
   * @return returns whether the initialization of this class was successful.
   */
  public boolean isSuccessfulInit()
  {
    return m_bIsSuccessfulInit;
  }
  
  /**
   * Sets the 'm_bIsSuccessfulInit' class member to 'false'.
   * Will be called from the 'StaticDataLayoutFactoryBuilder.processLayoutFactory' 
   * method in case of failure during the layout factory build process.
   */
  public void setInitializationFailure()
  {
    m_bIsSuccessfulInit = false;
  }
  
  /**
   * DisposableInterface implementation.
   */
  public void dispose() 
  {
    m_bIsDisposed = true;
    disposeInstance();
  }
    
  /**
   * DisposableInterface implementation.
   */
  public boolean isDisposed()
  {
    return m_bIsDisposed;
  }
  
  public abstract void setLayoutHM(HashMap hmLayouts);
  public abstract HashMap getLayoutHM();
  protected abstract void disposeInstance();
}
