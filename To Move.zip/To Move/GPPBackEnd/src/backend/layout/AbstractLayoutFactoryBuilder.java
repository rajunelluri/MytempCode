package backend.layout;

import com.fundtech.core.general.DisposableInterface;
import com.fundtech.datacomponent.response.Feedback;

import backend.services.cache.ASCacheFactory;

/**
 * Title:        AbstractLayoutFactoryBuilder
 * Description:  Abstract class for building all kind of layouts in the application,
 *               (profiles, messages, etc)
 * Company:      Fundtech Israel
 * @author       Asaf Levy
 * @version      1.0 18/05/08
 */
public abstract class AbstractLayoutFactoryBuilder implements DisposableInterface
{
  // This is the Feedback object that stands for the entire initialization process.
  protected static Feedback m_initializationFeedback;
  
  // For the DisposableInterface
  private boolean m_bIsDisposed;
  
  /**
   * Constructor.
   */
  public AbstractLayoutFactoryBuilder()
  {
    ASCacheFactory.m_setNonOrderedDisposables.add(this);
  }

  /**
   * Returns the Feedback object that stands for the initialization process.
   * @return returns the Feedback object that stands for the initialization process.
   */
  public static Feedback getInitializationFeedback()
  {
    return m_initializationFeedback;
  }
  
  /**
   * Process the layout factory building process.
   */
  protected void processLayoutFactory()
  {
    boolean bInitializationFailure = false;
     
    initializeCachedFactoryObjects();
     
    // All cached factory objects were initialized successfully; continues
    // with the rest of the process.
    if(m_initializationFeedback.isSuccessful())
    {
      initializeNonCachedNonFactoryObjects();
        
      if(isSuccessfulNonCachedNonFactoryObjectsInitialization())
      {
        prepareLookupStructure();
        freeUnNeededClassMembers();
      }
        
      // Non-cached/non-factory objects initialization failure. 
      else
      {
        bInitializationFailure = true;
      }
    }
      
    // Cached factory objects initialization failure. 
    else
    {
      bInitializationFailure = true;
    }
    
    // Sets relevant class member in the related layout factory class.
    if(bInitializationFailure)
    {
      setLayoutFactoryInitializationFailure();
    }
  }
  
  /**
   * DisposableInterface implementation.
   */
  public void dispose() 
  {
    m_bIsDisposed = true;
    disposeInstance();
  }
    
  /**
   * DisposableInterface implementation.
   */
  public boolean isDisposed()
  {
    return m_bIsDisposed;
  }
  
  protected abstract void initializeCachedFactoryObjects();
  protected abstract void initializeNonCachedNonFactoryObjects();
  protected abstract void prepareLookupStructure();
  protected abstract void freeUnNeededClassMembers();
  protected abstract boolean isSuccessfulNonCachedNonFactoryObjectsInitialization();
  protected abstract void disposeInstance();
  protected abstract void setLayoutFactoryInitializationFailure();
}